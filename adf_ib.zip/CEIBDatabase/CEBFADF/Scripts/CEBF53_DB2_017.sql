-- 
-- *****************************
-- Name :Anusha
-- Date : 17-09-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17413
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB',44000229,0,0,' ','E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( 'a8bdd4f800138978','E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB','en_GB','Follow up cannot be amended, as Recall process is in progress for previous Follow up.','Follow up cannot be amended, as Recall process is in progress for previous Follow up.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_017.sql,v $', '$LastChangedRevision$', 'BFDATA');
