-- 
-- *****************************
-- Name : Chandni Sharma
-- Date : 25-07-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17416
-- Schema : BF
-- Description : script for event code
-- Revision : $Id$
-- *****************************


INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES 
( 'E_TITLE_ID_EXISTS_ADF_IB',44000217,0,0,' ','E_TITLE_ID_EXISTS_ADF_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values
( 'a3bds4f800138889','E_TITLE_ID_EXISTS_ADF_IB','en_GB','Title Id already exists.','Title Id already exists.',0);

------------------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_009.sql,v $', '$LastChangedRevision$', 'BFDATA');
