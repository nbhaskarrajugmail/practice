-- 
-- *****************************
-- Name :Anusha
-- Date : 19-09-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17413
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************
UPDATE BANKFUSION.BFTB_EVENTCODEMSG
SET BFDESIGNTIMEMESSAGE = 'New Follow up cannot be added, until Recall is done for previous Follow up.',
    BFRUNTIMEMESSAGE = 'New Follow up cannot be added, until Recall is done for previous Follow up.'
WHERE BFEVENTCODEID = 'E_FOLLOWUP_NOT_ALLOWED_RECALL_INPROG_IB';

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES ( 'E_NO_TECH_ANALYSIS_DONE_IB',44000230,0,0,' ','E_NO_TECH_ANALYSIS_DONE_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values ( 'a8bdd4f800138778','E_NO_TECH_ANALYSIS_DONE_IB','en_GB','No Technical Analysis done for this deal.','No Technical Analysis done for this deal.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_018.sql,v $', '$LastChangedRevision$', 'BFDATA');
