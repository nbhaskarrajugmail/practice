-- 
-- *****************************
-- Name :Anusha
-- Date : 19-08-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17413
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_EVENTCODE(BFEVENTCODEIDPK,BFEVENTCODENUMBER,BFHANDLEABLE,BFCOLLECTIBLE,BFHANDLER,BFDESCRIPTION,BFSEVERITY,VERSIONNUM)VALUES 
( 'E_DEAL_CANNOT_BE_RECALLED_IB',44000227,0,0,' ','E_DEAL_CANNOT_BE_RECALLED_IB','E',0);

INSERT INTO BFTB_EVENTCODEMSG (BFEVENTCODEMESSAGEIDPK,BFEVENTCODEID,BFLOCALE,BFDESIGNTIMEMESSAGE,BFRUNTIMEMESSAGE,VERSIONNUM)values
( 'a4bdr4f800137229','E_DEAL_CANNOT_BE_RECALLED_IB','en_GB','Deal cannot be recalled.','Deal cannot be recalled.',0);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_013.sql,v $', '$LastChangedRevision$', 'BFDATA');
