-- 
-- *****************************
-- Name :Vinod
-- Date : 12-07-2020
-- Reference : request_id = IBF-17884
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BANKFUSION.BFTB_EVENTCODE
(
  BFEVENTCODEIDPK,
  BFEVENTCODENUMBER,
  BFHANDLEABLE,
  BFCOLLECTIBLE,
  BFHANDLER,
  BFDESCRIPTION,
  BFSEVERITY,
  BFISREADONLY,
  BFUSERCONFIGURABLE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  'E_PARTY_FREEZE_IB',
  44000246,
  0,
  0,
  ' ',
  'E_PARTY_FREEZE_IB',
  'E',
  0,
  1,
  '0',
  0
);

INSERT INTO BANKFUSION.BFTB_EVENTCODEMSG
(
  BFEVENTCODEMESSAGEIDPK,
  BFEVENTCODEID,
  BFLOCALE,
  BFDESIGNTIMEMESSAGE,
  BFRUNTIMEMESSAGE,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  '44000246',
  'E_PARTY_FREEZE_IB',
  'en_GB',
  'Customer is marked as Freeze. Cannot proceed.',
  'Customer is marked as Freeze. Cannot proceed.',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  0
);

-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_022.sql,v $', '$LastChangedRevision$', 'BFDATA');

