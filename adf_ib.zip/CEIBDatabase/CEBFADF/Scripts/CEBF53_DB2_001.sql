-- 
-- *****************************
-- Name : Anusha B
-- Date : 30-04-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17311
-- Schema : BF
-- Description : script for UDF service
-- Revision : $Id$
-- *****************************

INSERT INTO BFTB_UDFSERVICEINFORMATION
(
  BFIDPK,
  BFDISPLAYNAME,
  BFARTEFACTNAME,
  BFDESCRIPTION,
  BFIMPLEMENTATIONTYPE,
  BFSERVICETYPEID,
  VERSIONNUM
)
VALUES
(
  'PickListForPricingMethod',
  'CE_IB_PickListForPricingMethod_SRV',
  'CE_IB_PickListForPricingMethod_SRV',
  'Pick List for Pricing Method',
  1,
  1,
  0
);

INSERT INTO BFTB_UDFSERVICEINFORMATION
(
  BFIDPK,
  BFDISPLAYNAME,
  BFARTEFACTNAME,
  BFDESCRIPTION,
  BFIMPLEMENTATIONTYPE,
  BFSERVICETYPEID,
  VERSIONNUM
)
VALUES
(
  'PickListForProfitMethod',
  'CE_IB_PickListForProfitMethod_SRV',
  'CE_IB_PickListForProfitMethod_SRV',
  'Pick List for Profit Method',
  1,
  1,
  0
);

INSERT INTO BFTB_UDFSERVICEINFORMATION
(
  BFIDPK,
  BFDISPLAYNAME,
  BFARTEFACTNAME,
  BFDESCRIPTION,
  BFIMPLEMENTATIONTYPE,
  BFSERVICETYPEID,
  VERSIONNUM
)
VALUES
(
  'PickListForPaymentFrequency',
  'CE_IB_PickListForPaymentFrequency_SRV',
  'CE_IB_PickListForPaymentFrequency_SRV',
  'Pick List for Payment Frequency',
  1,
  1,
  0
);

INSERT INTO BFTB_UDFSERVICEINFORMATION
(
  BFIDPK,
  BFDISPLAYNAME,
  BFARTEFACTNAME,
  BFDESCRIPTION,
  BFIMPLEMENTATIONTYPE,
  BFSERVICETYPEID,
  VERSIONNUM
)
VALUES
(
  'PickListForProfitDistributionMethod',
  'CE_IB_PickListForProfitDistributionMethod_SRV',
  'CE_IB_PickListForProfitDistributionMethod_SRV',
  'Pick List for Profit Distribution Method',
  1,
  1,
  0
);
------------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_001.sql,v $', '$LastChangedRevision$', 'BFDATA');
