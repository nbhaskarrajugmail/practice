-- 
-- *****************************
-- Name :Aklesh
-- Date : 10-10-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17567
-- Schema : BF
-- Description : script 
-- Revision : $Id$
-- *****************************

INSERT INTO BANKFUSION.BFTB_RULESCREENASSOCIATION
(
  BFASSOCIATIONIDPK,
  BFRULELOGICFILENAME,
  BFARTIFACTNAME,
  BFUDFBONAME,
  VERSIONNUM
)
VALUES
(
  '1bec275b1c51fff',
  'GetUDFForDealExistingAssets.drl',
  'CE_IB_DealExistingAssetsUDFDet',
  NULL,
  0
);
-----------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_024.sql,v $', '$LastChangedRevision$', 'BFDATA');