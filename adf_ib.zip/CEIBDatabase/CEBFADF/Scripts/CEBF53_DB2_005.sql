-- 
-- *****************************
-- Name : Anusha B
-- Date : 20-06-2019
-- Iteration :  IB2.3.0.3
-- Reference : request_id = IBF-17392
-- Schema : BF
-- Description : script for event code
-- Revision : $Id$
-- *****************************


INSERT INTO BANKFUSION.BFTB_UDFSERVICEINFORMATION
(
  BFIDPK,
  BFDISPLAYNAME,
  BFARTEFACTNAME,
  BFDESCRIPTION,
  BFIMPLEMENTATIONTYPE,
  BFSERVICETYPEID,
  VERSIONNUM
)
VALUES
(
  'PickListToGetUsers',
  'CE_IB_PickListToGetUsers_SRV',
  'CE_IB_PickListToGetUsers_SRV',
  'Pick List To get users',
  1,
  1,
  0
);


------------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_005.sql,v $', '$LastChangedRevision$', 'BFDATA');
