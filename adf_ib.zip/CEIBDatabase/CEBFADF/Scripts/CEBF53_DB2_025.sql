--
-- *****************************
-- Name : Shreyanshkumar Bharatkumar Jain
-- Date : 15-July-2020
-- Iteration :  ADFIB 5.5.7
-- Reference : request_id = IBF-17876
-- Schema : BF
-- Description : System notes generation when there is category addition in current category
-- Revision : $Id$
-- *****************************
INSERT INTO BFTB_EVENTCODE
(
  BFEVENTCODEIDPK,
  BFEVENTCODENUMBER,
  BFHANDLEABLE,
  BFCOLLECTIBLE,
  BFHANDLER,
  BFDESCRIPTION,
  BFSEVERITY,
  BFOVERIDESEVERITY,
  BFISREADONLY,
  BFHOSTMODULEID,
  BFUSERCONFIGURABLE,
  BFFRONTOFFICEID,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  'E_NEW_LEVEL_ADDED_CURRENT_CATEGORY',
  44000247,
  0,
  1,
  NULL,
  'New level {0} is added in the current category.',
  'E',
  NULL,
  0,
  NULL,
  1,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  1
);


INSERT INTO BFTB_EVENTCODEMSG
(
  BFEVENTCODEMESSAGEIDPK,
  BFEVENTCODEID,
  BFLOCALE,
  BFDESIGNTIMEMESSAGE,
  BFRUNTIMEMESSAGE,
  BFRECLASTMODIFIEDBY,
  BFRECCREATEDBY,
  BFRECLASTMODIFIEDDATE,
  BFRECCREATEDON,
  BFRECAPPROVEDBY,
  BFRECAPPROVEDDATE,
  BFRECSYSDATE,
  BFRECDELETETDATE,
  VERSIONNUM
)
VALUES
(
  '44000247',
  'E_NEW_LEVEL_ADDED_CURRENT_CATEGORY',
  'en_GB',
  'New level {0} is added in the current category.',
  'New level {0} is added in the current category.',
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  NULL,
  '0',
  1
);

---------------------------------------------
INSERT INTO BFTB_DB_BUILD_HIST (BFSOURCENAME, BFFILEVER, BFCHANGETYPE) 
    VALUES ('$RCSfile: CEBF53_DB2_025.sql,v $', '$LastChangedRevision$', 'BFDATA');