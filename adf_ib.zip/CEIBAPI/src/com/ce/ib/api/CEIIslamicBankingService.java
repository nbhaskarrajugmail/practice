package com.ce.ib.api;

import java.util.ArrayList;

import com.misys.ib.api.bb.dto.IBGetLookUpDetails;

import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRs;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRs;
import bf.com.misys.ce.api.dto.CustomerLiabilities;
import bf.com.misys.ce.api.dto.CustomerLiabilityRs;
import bf.com.misys.ce.api.dto.GenerateScheduleRq;
import bf.com.misys.ce.api.dto.TroubleProjectDetailsRes;
import bf.com.misys.ib.api.bb.dto.GenerateScheduleRes;

/**
 * Implementation for exposed REST services for 'Islamic Banking Service'.
 * @author chandni
 *
 */
public interface CEIIslamicBankingService {

	String getLookUpsForTechAnalysisPurpose(String sContentType);
	String getLookUpsForTechAnalysisSoilType(String sContentType);
	String getLookUpsForTechAnalysisWaterAvailability(String sContentType);
	String getLookUpsForTechAnalysisFarmType(String sContentType);
	String getLookUpsForTechAnalysisWaterMethod(String sContentType);
	String getLookUpsForTechAnalysisStatus(String sContentType);
	String getLookUpsForTechAnalysisMainActivity(String sContentType);
	String getLookUpsForTechAnalysisSeedlingsType(String sContentType);
	String getLookUpsForTechAnalysisForPalm(String sContentType);
	String getLookUpsForFollowUpFarmStatus(String sContentType);
	String getLookUpsForFollowUpStatus(String sContentType); 
	String getAssetCategoriesForDeal(String sContentType, String dealId);
	
	String getLookUpsForTechAnalysisCropType(String sContentType); 
	String getLookUpsForTechAnalysisWellType(String sContentType); 
	String getLookUpsForTechAnalysisWellStatus(String sContentType); 
	String getLookUpsForTechAnalysisFishPort(String sContentType); 
	String getLookUpsForTechAnalysisWellCondition(String sContentType); 
	String getLookUpsForTechAnalysisFishLicenseType(String sContentType); 
	String getLookUpsForTechAnalysisFishLicenseSource(String sContentType); 
	String getLookUpsForTechAnalysisLetterGuardSource(String sContentType); 
	String getLookUpsForTechAnalysisWealthLetterSuorce(String sContentType); 
	GenerateScheduleRes generateSchedule(GenerateScheduleRq generateScheduleRq);
	IBGetLookUpDetails getPaymentFrequency(String dealId);
	String generateProgressReportID(String sContentType);
	CEIBAssetProgressCalculateCostRs assetProgressCalculateCost(CEIBAssetProgressCalculateCostRq req);
	CEIBAssetProgressSelectMachineRs assetProgressSelectMachine(CEIBAssetProgressSelectMachineRq req);
	TroubleProjectDetailsRes getTroubleProjectDtls();
	ArrayList<CustomerLiabilities> getCustomerLiabilities(String customerId);
	CustomerLiabilityRs getCustomerLiabilityDetail(String customerId);
	Boolean checkMachineType(String categoryID);
	String getLookUpsForMachineTypes(String sContentType);
}
