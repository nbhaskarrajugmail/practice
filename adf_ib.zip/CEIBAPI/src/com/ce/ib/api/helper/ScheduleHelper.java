package com.ce.ib.api.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.fatom.GenerateScheduleWithMultipleContracts;
import com.ce.bankfusion.ib.fatom.GetProfitRateAndProfitAmount;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.cfg.dto.SubproductFrequencyDtl;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealPaymentSchedule;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.util.APIUtils;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.api.Util.ApiCommonUtils;
import com.misys.ib.api.bb.dto.IBGetLookUpDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.exceptions.CollectedEventsDialogException;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ce.api.dto.GenerateScheduleRq;
import bf.com.misys.ib.api.bb.dto.GenerateScheduleRes;
import bf.com.misys.ib.api.bb.dto.ScheduleDetailedInfo;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.FinancialInfoDetail;
import bf.com.misys.ib.types.IslamicBankingObject;

public class ScheduleHelper {

	public static final String QUERY_DEAL_SCH_PROFILE_DTLS = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ?";
	public static final String QUERY_DEAL_PAYMENT_SCH = "WHERE " + IBOIB_DLI_DealPaymentSchedule.DEALNO + " = ?";
	public static final int eventCodeValidatingFinancialInf0 = 44000279;
	private static String paymentFreqCode = "Payment Frequency Code";
	private static String paymentFreqDesc = "Payment Frequency Description";
	private static String profitMatrixLookupKey = "PROFITMATRIX";
	private static String profitMatrixID = "profitMatrixID";

	public static GenerateScheduleRes generateSchedule(GenerateScheduleRq generateScheduleRq) {
		GenerateScheduleRes generateScheduleRes = null;
		try {
			IBCommonUtils.getPersistanceFactory().beginTransaction();
			com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal.setApplicationID("IslamicBanking");
			BankFusionThreadLocal.setApplicationID("IslamicBanking");
			IBOIB_DLI_DealDetails dealDetails = init(generateScheduleRq);
			generateScheduleRes = new GenerateScheduleRes();
			FinancialInfoDetail financialInfoDetail = prepareFinancialInfoObj(generateScheduleRq.getDealId());
			//validating the mandatory inputs
			validateMandatoryInputs(generateScheduleRq);

			IslamicBankingObject islamicBankingObject = prepareIslamicBankingObject(dealDetails);

			if (financialInfoDetail != null) {

				GetProfitRateAndProfitAmount getProfitAmountAndProfitRate = new GetProfitRateAndProfitAmount(
						BankFusionThreadLocal.getBankFusionEnvironment());
				getProfitAmountAndProfitRate.setF_IN_financialInfoDetail(financialInfoDetail);
				getProfitAmountAndProfitRate.setF_IN_gracePeriod(1);
				getProfitAmountAndProfitRate.setF_IN_islamicBankingObject(islamicBankingObject);
				getProfitAmountAndProfitRate.setF_IN_paymentFrequency(generateScheduleRq.getPaymentFrequency());
				getProfitAmountAndProfitRate.setF_IN_pricingMethod(generateScheduleRq.getProfitMatrix());
				getProfitAmountAndProfitRate.setF_IN_profitMethod("FLATRATE");
				getProfitAmountAndProfitRate
						.setF_IN_upfrontProfitPercentage(generateScheduleRq.getUpfrontProfitPercentage());
				getProfitAmountAndProfitRate.setF_IN_dealEffectiveDate(generateScheduleRq.getDealEffectiveDate());
				getProfitAmountAndProfitRate.process(BankFusionThreadLocal.getBankFusionEnvironment());

				GenerateScheduleWithMultipleContracts scheduleWithMultipleContracts = new GenerateScheduleWithMultipleContracts(
						IBCommonUtils.getBankFusionEnvironment());
				scheduleWithMultipleContracts.setF_IN_dealEffectiveDate(generateScheduleRq.getDealEffectiveDate());
				scheduleWithMultipleContracts.setF_IN_generateScheduleForDisbursedAssets(false);
				scheduleWithMultipleContracts.setF_IN_isGenScheduleForFutureAssets(false);
				scheduleWithMultipleContracts.setF_IN_islamicBankingObject(islamicBankingObject);
				scheduleWithMultipleContracts.setF_IN_paymentFrequency(generateScheduleRq.getPaymentFrequency());
				scheduleWithMultipleContracts.setF_IN_pricingMethod(generateScheduleRq.getProfitMatrix());
				scheduleWithMultipleContracts.setF_IN_profitMethod("FLATRATE");
				scheduleWithMultipleContracts.process(BankFusionThreadLocal.getBankFusionEnvironment());
				IBCommonUtils.getPersistanceFactory().commitTransaction();

				setGenerateScheduleBasicInfo(dealDetails, generateScheduleRes);
				setSchedulesDetailedInfo(dealDetails, generateScheduleRes);
				persistFinancialInfoUDF(generateScheduleRq, dealDetails, getProfitAmountAndProfitRate);
			}
		} catch (BankFusionException bfe) {
			if (bfe instanceof CollectedEventsDialogException)
				throw bfe;
			BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
			BankFusionThreadLocal.cleanUp();
			BankFusionThreadLocal.cleanUpAllFactories();
		} catch (Exception e) {
			BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
			BankFusionThreadLocal.cleanUp();
			BankFusionThreadLocal.cleanUpAllFactories();
		}

		return generateScheduleRes;

	}

	private static void persistFinancialInfoUDF(GenerateScheduleRq generateScheduleRq,
			IBOIB_DLI_DealDetails dealDetails, GetProfitRateAndProfitAmount getProfitAmountAndProfitRate) {
		try {
			IBCommonUtils.getPersistanceFactory().beginTransaction();
			UserDefinedFields userDefinedFields = new UserDefinedFields();
			userDefinedFields.setAssociatedBoName("IB_DLI_DEALADITIONALDTLS");

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForUpfrontProfitPercentage())) {
				// saving upfrontprofit percentage
				UserDefinedFld upfrontProfitPercentage = new UserDefinedFld();
				upfrontProfitPercentage.setFieldName(CeUtils.getUDFIDForUpfrontProfitPercentage());
				upfrontProfitPercentage.setFieldValue(generateScheduleRq.getUpfrontProfitPercentage());
				userDefinedFields.addUserDefinedField(upfrontProfitPercentage);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForPaymentFrequency())) {
				// saving Payment Frequency
				UserDefinedFld paymentFrequency = new UserDefinedFld();
				paymentFrequency.setFieldName(CeUtils.getUDFIDForPaymentFrequency());
				paymentFrequency.setFieldValue(generateScheduleRq.getPaymentFrequency());
				userDefinedFields.addUserDefinedField(paymentFrequency);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForPricingMethod())) {
				// saving Pricing Method
				UserDefinedFld pricingMethod = new UserDefinedFld();
				pricingMethod.setFieldName(CeUtils.getUDFIDForPricingMethod());
				pricingMethod.setFieldValue(generateScheduleRq.getProfitMatrix());
				userDefinedFields.addUserDefinedField(pricingMethod);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForProfitRate())) {
				// saving Profit Rate
				UserDefinedFld profitRate = new UserDefinedFld();
				profitRate.setFieldName(CeUtils.getUDFIDForProfitRate());
				profitRate.setFieldValue(dealDetails.getF_ProfitRate());
				userDefinedFields.addUserDefinedField(profitRate);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForScheduleProfitPercentage())) {
				// saving Scheduled Profit percentage
				UserDefinedFld scheduledProfitPercentage = new UserDefinedFld();
				scheduledProfitPercentage.setFieldName(CeUtils.getUDFIDForScheduleProfitPercentage());
				scheduledProfitPercentage
						.setFieldValue(new BigDecimal(100).subtract(generateScheduleRq.getUpfrontProfitPercentage()));
				userDefinedFields.addUserDefinedField(scheduledProfitPercentage);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForUpfrontProfitAmnt())) {
				// saving Upfront profit amount
				UserDefinedFld upfrontProfitAmount = new UserDefinedFld();
				upfrontProfitAmount.setFieldName(CeUtils.getUDFIDForUpfrontProfitAmnt());
				upfrontProfitAmount
						.setFieldValue(getProfitAmountAndProfitRate.getF_OUT_upfrontProfitAmount().getCurrencyAmount());
				userDefinedFields.addUserDefinedField(upfrontProfitAmount);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForScheduleProfitAmnt())) {
				// saving Upfront profit amount
				UserDefinedFld scheduledProfitAmount = new UserDefinedFld();
				scheduledProfitAmount.setFieldName(CeUtils.getUDFIDForScheduleProfitAmnt());
				scheduledProfitAmount.setFieldValue(
						getProfitAmountAndProfitRate.getF_OUT_scheduledProfitAmount().getCurrencyAmount());
				userDefinedFields.addUserDefinedField(scheduledProfitAmount);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForProfitAmount())) {
				// saving profit amount
				UserDefinedFld profitAmount = new UserDefinedFld();
				profitAmount.setFieldName(CeUtils.getUDFIDForProfitAmount());
				profitAmount
						.setFieldValue(getProfitAmountAndProfitRate.getF_OUT_scheduledProfitAmount().getCurrencyAmount()
								.add(getProfitAmountAndProfitRate.getF_OUT_upfrontProfitAmount().getCurrencyAmount()));
				userDefinedFields.addUserDefinedField(profitAmount);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForProfitMethod())) {
				// saving Profit Method
				UserDefinedFld profitMethod = new UserDefinedFld();
				profitMethod.setFieldName(CeUtils.getUDFIDForProfitMethod());
				profitMethod.setFieldValue("FLATRATE");
				userDefinedFields.addUserDefinedField(profitMethod);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForUpfrontProfitCollMethod())) {
				// saving upfrontProfitCollection
				UserDefinedFld upfrontProfitCollection = new UserDefinedFld();
				upfrontProfitCollection.setFieldName(CeUtils.getUDFIDForUpfrontProfitCollMethod());
				upfrontProfitCollection.setFieldValue("DEDUCT FROM DISBURSEMENT");
				userDefinedFields.addUserDefinedField(upfrontProfitCollection);
			}

			if (!IBCommonUtils.isNullOrEmpty(CeUtils.getUDFIDForDealEffectiveDate())) {
				// saving dealEffectiveDate
				UserDefinedFld dealEffectiveDate = new UserDefinedFld();
				dealEffectiveDate.setFieldName(CeUtils.getUDFIDForDealEffectiveDate());
				dealEffectiveDate.setFieldValue(generateScheduleRq.getDealEffectiveDate());
				userDefinedFields.addUserDefinedField(dealEffectiveDate);
			}

			IBOIB_DLI_DealAditionalDtls dealAditionalDtls = IBCommonUtils
					.getDealAdditionalDetails(dealDetails.getBoID());
			if (dealAditionalDtls != null) {
				IBOUDFEXTIB_DLI_DealAditionalDtls iboudfextAddtionalDtl = (IBOUDFEXTIB_DLI_DealAditionalDtls) IBCommonUtils
						.getPersistanceFactory()
						.findByPrimaryKey(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, dealAditionalDtls.getBoID(), true);
				IBOUDFEXTIB_DLI_DealAditionalDtls additionalDetailUDF = null;
				additionalDetailUDF = iboudfextAddtionalDtl;
				iboudfextAddtionalDtl.setUserDefinedFields(userDefinedFields);
				IBCommonUtils.getPersistanceFactory().create(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME,
						iboudfextAddtionalDtl);
			}
			IBCommonUtils.getPersistanceFactory().commitTransaction();
		} catch (BankFusionException bfe) {
			if (bfe instanceof CollectedEventsDialogException)
				throw bfe;
			BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
			BankFusionThreadLocal.cleanUp();
			BankFusionThreadLocal.cleanUpAllFactories();
		} catch (Exception e) {
			BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
			BankFusionThreadLocal.cleanUp();
			BankFusionThreadLocal.cleanUpAllFactories();
		}
	}

	private static IBOIB_DLI_DealDetails init(GenerateScheduleRq generateScheduleRq) {
		IBOIB_DLI_DealDetails dealDetails = validateDealId(generateScheduleRq.getDealId());
		if (dealDetails != null && CalendarUtil.isDateNullOrDefaultDate(generateScheduleRq.getDealEffectiveDate())) {
			generateScheduleRq.setDealEffectiveDate(dealDetails.getF_DEALEFFECTIVEDT());
		}
		if (generateScheduleRq.getUpfrontProfitPercentage() == null) {
			generateScheduleRq.setUpfrontProfitPercentage(BigDecimal.ZERO);
		}
		return dealDetails;
	}

	private static FinancialInfoDetail prepareFinancialInfoObj(String dealId) {
		HashMap<String, Object> param = new HashMap<>();
		param.clear();
		param.put("dealNo", dealId);
		HashMap<String, Object> outputParams = MFExecuter.executeMF("IB_IDI_GetFinInfo_SRV",
				IBCommonUtils.getBankFusionEnvironment(), param);
		FinancialInfoDetail financialInfoDetail = (FinancialInfoDetail) outputParams.get("financialInfoDetail");
		if (financialInfoDetail == null || (financialInfoDetail != null
				&& financialInfoDetail.getPrincipleAmtBFCurr().getCurrencyAmount().compareTo(BigDecimal.ZERO) == 0)) {
			IBCommonUtils.raiseUnparameterizedEvent(eventCodeValidatingFinancialInf0);
		} else {
			ExtensionDetails extensionDtls = new ExtensionDetails();
			extensionDtls.setUserExtension(CeUtils.getUserExtension(dealId));
			extensionDtls.setHostExtension(CommonConstants.EMPTY_STRING);
			financialInfoDetail.setExtensionDtls(extensionDtls);
		}
		return financialInfoDetail;
	}

	private static void validateMandatoryInputs(GenerateScheduleRq generateScheduleRq) {
		validatePaymentFrequency(generateScheduleRq);
		validateProfitMatrix(generateScheduleRq);
	}

	private static void validatePaymentFrequency(GenerateScheduleRq generateScheduleRq) {
		ApiCommonUtils.isValidateMandatoryField(generateScheduleRq.getPaymentFrequency(),
				IBConstants.FIELD_PAYMENT_FREQUENCY);
		IBGetLookUpDetails getLookUpDetails = getPaymentFrequency(generateScheduleRq.getDealId());
		if (getLookUpDetails != null && !getLookUpDetails.getRsObject().isEmpty()) {
			List<String> freqList = new ArrayList<>();
			for (Object lookUpDetail : getLookUpDetails.getRsObject()) {
				HashMap<String, Object> frequency = (HashMap<String, Object>) lookUpDetail;
				freqList.add(frequency.get(paymentFreqCode).toString());
			}
			if (!freqList.contains(generateScheduleRq.getPaymentFrequency())) {
				String[] msgArgs = { IBConstants.FIELD_PAYMENT_FREQUENCY, generateScheduleRq.getPaymentFrequency() };
				IBCommonUtils.raiseParametrizedEvent(IBConstants.E_INPUT_TAG_INVALID, msgArgs);
			}
		}
	}

	private static void validateProfitMatrix(GenerateScheduleRq generateScheduleRq) {
		ApiCommonUtils.isValidateMandatoryField(generateScheduleRq.getProfitMatrix(), IBConstants.FIELD_PROFIT_MATRIX);
		IBGetLookUpDetails getLookUpDetails = com.misys.ib.api.helper.LaunchProcessHelper
				.getLookUps(profitMatrixLookupKey);
		if (getLookUpDetails != null && !getLookUpDetails.getRsObject().isEmpty()) {
			List<String> profitMatrixList = new ArrayList<>();
			for (Object lookUpDetail : getLookUpDetails.getRsObject()) {
				HashMap<String, Object> profitMatrix = (HashMap<String, Object>) lookUpDetail;
				profitMatrixList.add(profitMatrix.get(profitMatrixID).toString());
			}
			if (!profitMatrixList.contains(generateScheduleRq.getProfitMatrix())) {
				String[] msgArgs = { IBConstants.FIELD_PROFIT_MATRIX, generateScheduleRq.getProfitMatrix() };
				IBCommonUtils.raiseParametrizedEvent(IBConstants.E_INPUT_TAG_INVALID, msgArgs);
			}
		}
	}

	private static IBOIB_DLI_DealDetails validateDealId(String dealId) {
		IBOIB_DLI_DealDetails dealDetails = null;
		ApiCommonUtils.isValidateMandatoryField(dealId, IBConstants.FIELD_DEAL_ID);
		try {
			dealDetails = IBCommonUtils.getDealDetails(dealId);
		} catch (Exception e) {
			String[] msgArgs = { IBConstants.FIELD_DEAL_ID, dealId };
			IBCommonUtils.raiseParametrizedEvent(IBConstants.E_INPUT_TAG_INVALID, msgArgs);
			e.printStackTrace();
		}
		return dealDetails;
	}

	private static IslamicBankingObject prepareIslamicBankingObject(IBOIB_DLI_DealDetails dealDetails) {
		IslamicBankingObject islamicBankingObject = new IslamicBankingObject();
		islamicBankingObject.setDealID(dealDetails.getBoID());
		islamicBankingObject.setProductID(dealDetails.getF_ProductCode());
		islamicBankingObject.setSubProductID(dealDetails.getF_ProductContextCode());
		islamicBankingObject.setCurrency(dealDetails.getF_IsoCurrencyCode());
		islamicBankingObject.setChannel(ApiCommonUtils.CHANNEL_API);

		return islamicBankingObject;
	}

	private static void setGenerateScheduleBasicInfo(IBOIB_DLI_DealDetails dealDetails,
			GenerateScheduleRes generateScheduleRes) {
		dealDetails = IBCommonUtils.getDealDetails(dealDetails.getBoID());
		generateScheduleRes.setDealPrincipalAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
				.getBFCurrencyAmount(dealDetails.getF_PrincipleAmt(), dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setDealProfitAmount(APIUtils.getAPICurrencyAmount(
				IBCommonUtils.getBFCurrencyAmount(dealDetails.getF_ProfitAmt(), dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setFeeAddedToPrincipal(
				APIUtils.getAPICurrencyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setFeeAddedToProfit(
				APIUtils.getAPICurrencyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setFinanceAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
				.getBFCurrencyAmount(dealDetails.getF_PrincipleAmt(), dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setGraceDays(0);
		generateScheduleRes.setLastInstallmentDate(dealDetails.getF_LastRepaymentDate());
		generateScheduleRes.setRemainingPrinciple(
				APIUtils.getAPICurrencyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setRemainingProfit(
				APIUtils.getAPICurrencyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setScheduledPrinciple(APIUtils.getAPICurrencyAmount(IBCommonUtils
				.getBFCurrencyAmount(dealDetails.getF_PrincipleAmt(), dealDetails.getF_IsoCurrencyCode())));
		generateScheduleRes.setScheduledProfit(APIUtils.getAPICurrencyAmount(
				IBCommonUtils.getBFCurrencyAmount(dealDetails.getF_ProfitAmt(), dealDetails.getF_IsoCurrencyCode())));
	}

	private static void setSchedulesDetailedInfo(IBOIB_DLI_DealDetails dealDetails,
			GenerateScheduleRes generateScheduleRes) {
		ArrayList<Object> param = new ArrayList<>();
		param.add(dealDetails.getBoID());
		List<IBOIB_DLI_ScheduleProfile> scheduleProfile = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME, QUERY_DEAL_SCH_PROFILE_DTLS, param, null, true);

		if (scheduleProfile != null && !scheduleProfile.isEmpty()) {
			ScheduleDetailedInfo scheduleDetailedInfo = new ScheduleDetailedInfo();
			scheduleDetailedInfo.setBaseFactor(scheduleProfile.get(0).getF_BaseFactor());
			scheduleDetailedInfo.setCalculatedProfit(APIUtils.getAPICurrencyAmount(IBCommonUtils.getBFCurrencyAmount(
					scheduleProfile.get(0).getF_ProfitPaymentAMT(), dealDetails.getF_IsoCurrencyCode())));
			scheduleDetailedInfo
					.setCarryOverProfitCollection(scheduleProfile.get(0).getF_ProfitCollectionTypeInGrace());
			scheduleDetailedInfo.setDuration(scheduleProfile.get(0).getF_DurationUnit());
			scheduleDetailedInfo.setDurationUnit(scheduleProfile.get(0).getF_DurationCode());
			scheduleDetailedInfo.setEndDate(scheduleProfile.get(0).getF_scheduleEndDT());
			scheduleDetailedInfo.setFirstPaymentDate(scheduleProfile.get(0).getF_FirstPaymentDT());
			scheduleDetailedInfo.setLastPaymentDate(scheduleProfile.get(0).getF_LastPaymentDT());
			scheduleDetailedInfo.setNoOfPayments(scheduleProfile.get(0).getF_NoOfPayments());
			scheduleDetailedInfo.setPaymentFrequency(scheduleProfile.get(0).getF_FreqUnit());
			scheduleDetailedInfo.setPaymentFrequencyUnit(scheduleProfile.get(0).getF_FreqCode());
			scheduleDetailedInfo.setPaymentOption(scheduleProfile.get(0).getF_PaymentOption());
			scheduleDetailedInfo.setPrinciplePayment(APIUtils.getAPICurrencyAmount(IBCommonUtils.getBFCurrencyAmount(
					scheduleProfile.get(0).getF_PrinciplePaymentAMT(), dealDetails.getF_IsoCurrencyCode())));
			scheduleDetailedInfo.setProfitMatrix(scheduleProfile.get(0).getF_ProfitMatrixID());
			scheduleDetailedInfo.setProfitMethod(scheduleProfile.get(0).getF_EvaluationMethod());
			scheduleDetailedInfo.setProfitPayment(APIUtils.getAPICurrencyAmount(IBCommonUtils.getBFCurrencyAmount(
					scheduleProfile.get(0).getF_ProfitPaymentAMT(), dealDetails.getF_IsoCurrencyCode())));
			scheduleDetailedInfo.setProfitRate(scheduleProfile.get(0).getF_ProfitRate());
			scheduleDetailedInfo.setRoundingOption(scheduleProfile.get(0).getF_RoundingOption());
			scheduleDetailedInfo.setScheduleType(scheduleProfile.get(0).getF_ScheduleType());
			scheduleDetailedInfo.setStartDate(scheduleProfile.get(0).getF_scheduleStartDT());
			scheduleDetailedInfo.setScheduleOption(scheduleProfile.get(0).getF_scheduleOption());

			List<IBOIB_DLI_DealPaymentSchedule> dealPaymentScheduleList = IBCommonUtils.getPersistanceFactory()
					.findByQuery(IBOIB_DLI_DealPaymentSchedule.BONAME, QUERY_DEAL_PAYMENT_SCH, param, null, true);

			// Payment Schedule
			for (IBOIB_DLI_DealPaymentSchedule schedule : dealPaymentScheduleList) {
				bf.com.misys.ib.api.bb.dto.PaymentSchedule paymentSchedule = new bf.com.misys.ib.api.bb.dto.PaymentSchedule();
				paymentSchedule.setBillNumber(schedule.getF_REPAYMENTNUMBER());
				paymentSchedule.setCarryoverProfitAmt(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_CARRYOVERPROFITAMT(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setDate(schedule.getF_PAYMENTDT());
				paymentSchedule.setFeesAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_CHARGEAMT(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setOutstandingPrincipalAmt(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_OUTSTANDINGBALANCE(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setPrincipalAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_PRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setProfitAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_PROFITAMT(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setTotalAmount(APIUtils.getAPICurrencyAmount(IBCommonUtils
						.getBFCurrencyAmount(schedule.getF_REPAYMENTAMT(), dealDetails.getF_IsoCurrencyCode())));
				paymentSchedule.setType(schedule.getF_REPAYMENTTYPE());
				scheduleDetailedInfo.addPaymentSchedule(paymentSchedule);
			}

			scheduleDetailedInfo.setInstructionList(null);

			generateScheduleRes.addSchedules(scheduleDetailedInfo);
		}
	}

	public static IBGetLookUpDetails getPaymentFrequency(String dealId) {
		IBOIB_DLI_DealDetails dealDetails = validateDealId(dealId);
		List looKupValue = new ArrayList<>();
		if (dealDetails != null) {
			String parentReference = com.ce.bankfusion.ib.util.ScheduleUtils
					.getParentReference(dealDetails.getF_ProductContextCode(), dealDetails.getF_ProductCode());

			ListGenericCodeRs paymentFreqGCList = IBCommonUtils.getGCList(parentReference);

			SubproductFrequencyDtl frequencyDtl = com.ce.bankfusion.ib.util.ScheduleUtils
					.getFrequenciesConfiguredAtSubproduct(dealDetails.getF_ProductContextCode());

			if (paymentFreqGCList != null && paymentFreqGCList.getGcCodeDetailsCount() > 0) {
				for (GcCodeDetail gcCodeDetail : paymentFreqGCList.getGcCodeDetails()) {
					if (frequencyDtl != null) {
						if ((gcCodeDetail.getCodeReference().equals("MONTHLY")
								&& frequencyDtl.getMonthlyFrequency().equals("true"))
								|| (gcCodeDetail.getCodeReference().equals("QUARTERLY")
										&& frequencyDtl.getQuarterlyFrequency().equals("true"))
								|| (gcCodeDetail.getCodeReference().equals("HALF-YEARLY")
										&& frequencyDtl.getHalfyearlyFrequency().equals("true"))
								|| (gcCodeDetail.getCodeReference().equals("YEARLY")
										&& frequencyDtl.getYearlyFrequency().equals("true"))) {
							Map<String, Object> lookUpServiceMap = new HashMap<>();
							lookUpServiceMap.put(paymentFreqCode, gcCodeDetail.getCodeReference());
							lookUpServiceMap.put(paymentFreqDesc, gcCodeDetail.getCodeDescription());
							looKupValue.add(lookUpServiceMap);
						}
					} else {
						if (gcCodeDetail.getCodeReference().equals("MONTHLY")
								|| gcCodeDetail.getCodeReference().equals("QUARTERLY")
								|| gcCodeDetail.getCodeReference().equals("HALF-YEARLY")
								|| gcCodeDetail.getCodeReference().equals("YEARLY")) {
							Map<String, Object> lookUpServiceMap = new HashMap<>();
							lookUpServiceMap.put(paymentFreqCode, gcCodeDetail.getCodeReference());
							lookUpServiceMap.put(paymentFreqDesc, gcCodeDetail.getCodeDescription());
							looKupValue.add(lookUpServiceMap);
						}
					}
				}
			}
		}
		IBGetLookUpDetails lookUpKeyRs = new IBGetLookUpDetails();
		lookUpKeyRs.setRsObject(looKupValue);
		return lookUpKeyRs;
	}

}
