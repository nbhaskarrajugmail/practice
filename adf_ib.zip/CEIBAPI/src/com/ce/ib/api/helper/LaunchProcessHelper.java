package com.ce.ib.api.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.util.CeConstants;
import com.google.gson.Gson;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.api.Util.ApiCommonUtils;
import com.misys.ib.api.bb.dto.IBGetLookUpDetails;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class LaunchProcessHelper {

	public static String getLookUpsForTechAnalysisPurpose(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHPURPOSE");
	}

	public static String getLookUpsForTechAnalysisForPalm(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHFORPALM");
	}

	public static String getLookUpsForTechAnalysisSeedlingsType(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHSEEDLINGSTYPE");
	}

	public static String getLookUpsForTechAnalysisMainActivity(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHMAINACTIVITY");
	}

	public static String getLookUpsForTechAnalysisStatus(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHSTATUS");
	}

	public static String getLookUpsForTechAnalysisWaterMethod(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHWATERMETHOD");
	}

	public static String getLookUpsForTechAnalysisWaterAvailability(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHWATERAVAILABILITY");
	}

	public static String getLookUpsForTechAnalysisFarmType(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHFARMTYPE");
	}

	public static String getLookUpsForTechAnalysisSoilType(String sContentType) {
		return getLookupForGCCode(sContentType, "CETECHSOILTYPE");
	}
	
	public static String getLookUpsForFollowUpFarmStatus(String sContentType) {
		return getLookupForGCCode(sContentType, "CEFARMSTATUS");
	}
	
	public static String getLookUpsForFollowUpStatus(String sContentType) {
		List looKupValue = new ArrayList<>();
		Map<String, Object> lookUpServiceMap = null;
		ListGenericCodeRs listGenericCodeRs = IBCommonUtils.getGCList("CEFOLLOWUPSTATUS");
		GcCodeDetail gcCode[] = listGenericCodeRs.getGcCodeDetails();
		for (int i = 0; i < gcCode.length; i++) {
			if(!gcCode[i].getCodeReference().equals(CeConstants.FOLLOWUP_ASSIGN_STATUS_INPROGRESS)) {
				lookUpServiceMap = new HashMap<String, Object>();
				lookUpServiceMap.put("codeValue", gcCode[i].getCodeValue());
				lookUpServiceMap.put("codeDescription", gcCode[i].getCodeDescription());
				lookUpServiceMap.put("codeReference", gcCode[i].getCodeReference());
				looKupValue.add(lookUpServiceMap);
			}
		}

		IBGetLookUpDetails lookUpKeyRs = new IBGetLookUpDetails();
		lookUpKeyRs.setRsObject(looKupValue);
		if (sContentType.equalsIgnoreCase(ApiCommonUtils.CONTENT_TYPE_JSON)) {
			Gson gson = new Gson();
			return gson.toJson(lookUpKeyRs);
		} else {
			return ApiCommonUtils.EMPTY_STRING;
		}
	}
	
	public static String getLookupForGCCode(String sContentType, String lookupAttr) {
		List looKupValue = new ArrayList<>();
		Map<String, Object> lookUpServiceMap = null;
		ListGenericCodeRs listGenericCodeRs = IBCommonUtils.getGCList(lookupAttr);
		GcCodeDetail gcCode[] = listGenericCodeRs.getGcCodeDetails();
		for (int i = 0; i < gcCode.length; i++) {
			lookUpServiceMap = new HashMap<String, Object>();
			lookUpServiceMap.put("codeValue", gcCode[i].getCodeValue());
			lookUpServiceMap.put("codeDescription", gcCode[i].getCodeDescription());
			lookUpServiceMap.put("codeReference", gcCode[i].getCodeReference());
			looKupValue.add(lookUpServiceMap);
		}

		IBGetLookUpDetails lookUpKeyRs = new IBGetLookUpDetails();
		lookUpKeyRs.setRsObject(looKupValue);
		if (sContentType.equalsIgnoreCase(ApiCommonUtils.CONTENT_TYPE_JSON)) {
			Gson gson = new Gson();
			return gson.toJson(lookUpKeyRs);
		} else {
			return ApiCommonUtils.EMPTY_STRING;
		}
	}

	public static String generateProgressReportID() {
		HashMap<String, String> inputParams = new HashMap<String, String>();
		inputParams.put("reportID", CommonConstants.EMPTY_STRING);
		HashMap<String, String> ouputParams=null;
		try {
			ouputParams = MFExecuter.executeMF("CE_IB_GenerateProgReportID_SRV",
					 inputParams,BankFusionThreadLocal.getUserLocator().getStringRepresentation());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ouputParams!=null?ouputParams.get("reportID"):CommonConstants.EMPTY_STRING;
	}
}
