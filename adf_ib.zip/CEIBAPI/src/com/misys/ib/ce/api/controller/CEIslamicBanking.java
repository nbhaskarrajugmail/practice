package com.misys.ib.ce.api.controller;


import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ce.ib.api.CEIIslamicBankingService;
import com.misys.fbp.common.util.FBPServiceAppContext;
import com.misys.ib.api.bb.dto.IBGetLookUpDetails;

import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRs;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRs;
import bf.com.misys.ce.api.dto.CustomerLiabilities;
import bf.com.misys.ce.api.dto.CustomerLiabilityRs;
import bf.com.misys.ce.api.dto.GenerateScheduleRq;
import bf.com.misys.ce.api.dto.TroubleProjectDetailsRes;
import bf.com.misys.ib.api.bb.dto.GenerateScheduleRes;
/**
 * REST controller for 'Islamic Banking Service'.
 * 
 * @author chandni
 * 
 */

@RestController
@RequestMapping("/service/ce/ib")
public class CEIslamicBanking {

    private final CEIIslamicBankingService ceislamicBankingService = (CEIIslamicBankingService) FBPServiceAppContext.getInstance()
            .getApplicationContext().getBean("ceislamicBankingService");

    private static final String HEADER = "Accept=text/plain;charset=utf-8";
    
    @RequestMapping(value = "/getTechPurposeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechPurposeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisPurpose(sContentType);
    }
    
    @RequestMapping(value = "/getTechSoilTypeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechSoilTypeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisSoilType(sContentType);
    }
    @RequestMapping(value = "/getTechSeedlingsList", method = RequestMethod.GET, headers = HEADER)
    public String getTechSeedlingsList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisSeedlingsType(sContentType);
    }
    @RequestMapping(value = "/getTechMainActivityList", method = RequestMethod.GET, headers = HEADER)
    public String getTechMainActivityList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisMainActivity(sContentType);
    }
    @RequestMapping(value = "/getTechStatusList", method = RequestMethod.GET, headers = HEADER)
    public String getTechStatusList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisStatus(sContentType);
    }
    @RequestMapping(value = "/getTechForPalmList", method = RequestMethod.GET, headers = HEADER)
    public String getTechForPalmList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisForPalm(sContentType);
    }
    @RequestMapping(value = "/getTechWaterMethodList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWaterMethodList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWaterMethod(sContentType);
    }
    @RequestMapping(value = "/getTechFarmTypeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechFarmTypeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisFarmType(sContentType);
    }
    @RequestMapping(value = "/getTechWaterAvailabilityList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWaterAvailabilityList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWaterAvailability(sContentType);
    }
    @RequestMapping(value = "/getFollowUpFarmStatusList", method = RequestMethod.GET, headers = HEADER)
    public String getFollowUpFarmStatusList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForFollowUpFarmStatus(sContentType);
    }
    @RequestMapping(value = "/getFollowUpStatusList", method = RequestMethod.GET, headers = HEADER)
    public String getFollowUpStatusList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForFollowUpStatus(sContentType);
    }
    @RequestMapping(value = "/getAssetCategoriesForDeal", method = RequestMethod.GET, headers = HEADER)
    public String getAssetCategoriesForDeal(@RequestHeader(value = "Content-Type")
    String sContentType,@RequestBody String dealId) {
        return ceislamicBankingService.getAssetCategoriesForDeal(sContentType, dealId);
    }
    @RequestMapping(value = "/getTechCropTypeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechCropTypeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisCropType(sContentType);
    }
    @RequestMapping(value = "/getTechWellTypeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWellTypeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWellType(sContentType);
    }
    @RequestMapping(value = "/getTechWellStatusList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWellStatusList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWellStatus(sContentType);
    }
    @RequestMapping(value = "/getTechFishPortList", method = RequestMethod.GET, headers = HEADER)
    public String getTechFishPortList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisFishPort(sContentType);
    }
    @RequestMapping(value = "/getTechWellConditionList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWellConditionList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWellCondition(sContentType);
    }
    @RequestMapping(value = "/getTechFishLicenseTypeList", method = RequestMethod.GET, headers = HEADER)
    public String getTechFishLicenseTypeList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisFishLicenseType(sContentType);
    }
    @RequestMapping(value = "/getTechFishLicenseSourceList", method = RequestMethod.GET, headers = HEADER)
    public String getTechFishLicenseSourceList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisFishLicenseSource(sContentType);
    }
    @RequestMapping(value = "/getTechLetterGuardSourceList", method = RequestMethod.GET, headers = HEADER)
    public String getTechLetterGuardSourceList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisLetterGuardSource(sContentType);
    }
    @RequestMapping(value = "/getTechWealthLetterSuorceList", method = RequestMethod.GET, headers = HEADER)
    public String getTechWealthLetterSuorceList(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForTechAnalysisWealthLetterSuorce(sContentType);
    }
    @PostMapping(path = "/generateCustomizedSchedule")
    public GenerateScheduleRes generateSchedule(@RequestBody GenerateScheduleRq generateScheduleReq) {
        return ceislamicBankingService.generateSchedule(generateScheduleReq);
    }
    @GetMapping(path = "/getPaymentFrequency/{dealId}")
    public IBGetLookUpDetails getPaymentFrequency(@PathVariable(required = true) String dealId) {
        return ceislamicBankingService.getPaymentFrequency(dealId);
    }
    @RequestMapping(value = "/generateProgressReportID", method = RequestMethod.GET, headers = HEADER)
    public String generateProgressReportID(@RequestHeader(value = "Content-Type")
    String sContentType) {
    	return ceislamicBankingService.generateProgressReportID(sContentType);
    }
    @PostMapping(value = "/assetProgressCalculateCost")
    public CEIBAssetProgressCalculateCostRs assetProgressCalculateCost(@RequestBody CEIBAssetProgressCalculateCostRq req) {
    	return ceislamicBankingService.assetProgressCalculateCost(req);
    }
    @PostMapping(value = "/assetProgressSelectMachine")
    public CEIBAssetProgressSelectMachineRs assetProgressSelectMachine(@RequestBody CEIBAssetProgressSelectMachineRq req) {
    	return ceislamicBankingService.assetProgressSelectMachine(req);
    }
    @GetMapping(value = "/getTroubleProjectDetails")
    public TroubleProjectDetailsRes getTroubleProjectDtls() {
        return ceislamicBankingService.getTroubleProjectDtls();
    }
    @GetMapping(value = "/getCustomerLiabilites/{customerId}")
    public ArrayList<CustomerLiabilities> getCustomerLiabilities(@PathVariable(required = true) String customerId) {
        return ceislamicBankingService.getCustomerLiabilities(customerId);
    }
    
    @GetMapping(value = "/getCustomerLiabilityDetail/{customerId}")
    public CustomerLiabilityRs getCustomerLiabilityDetail(@PathVariable(required = true) String customerId) {
        return ceislamicBankingService.getCustomerLiabilityDetail(customerId);
    }
    
    @GetMapping(value = "/checkMachineType/{categoryID}")
    public Boolean checkMachineType(@PathVariable(required = true) String categoryID) {
        return ceislamicBankingService.checkMachineType(categoryID);
    }
    @RequestMapping(value = "/getMachineTypes", method = RequestMethod.GET, headers = HEADER)
    public String getMachineTypes(@RequestHeader(value = "Content-Type")
    String sContentType) {
        return ceislamicBankingService.getLookUpsForMachineTypes(sContentType);
    }
}