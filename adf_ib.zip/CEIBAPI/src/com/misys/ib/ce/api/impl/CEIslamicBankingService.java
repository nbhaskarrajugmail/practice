package com.misys.ib.ce.api.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.ce.bankfusion.ib.fatom.AssetProgressMachineMatchingFatom;
import com.ce.bankfusion.ib.fatom.CalculatePricingCostForAssetProgress;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.TransferOfDebtReqUtils;
import com.ce.ib.api.CEIIslamicBankingService;
import com.ce.ib.api.helper.LaunchProcessHelper;
import com.ce.ib.api.helper.ScheduleHelper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_ProductAssetConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.fbp.common.util.FBPService;
import com.misys.ib.api.Util.ApiCommonUtils;
import com.misys.ib.api.bb.dto.IBGetLookUpDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ce.api.dto.AssetDetailsList;
import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressCalculateCostRs;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRq;
import bf.com.misys.ce.api.dto.CEIBAssetProgressSelectMachineRs;
import bf.com.misys.ce.api.dto.CustomerLiabilities;
import bf.com.misys.ce.api.dto.CustomerLiabilitiesExt;
import bf.com.misys.ce.api.dto.CustomerLiabilityRs;
import bf.com.misys.ce.api.dto.FollowUpAssetDetails;
import bf.com.misys.ce.api.dto.GenerateScheduleRq;
import bf.com.misys.ce.api.dto.MachineDetails;
import bf.com.misys.ce.api.dto.TroubleProjectDetails;
import bf.com.misys.ce.api.dto.TroubleProjectDetailsRes;
import bf.com.misys.ib.api.bb.dto.AdditionalFieldInfo;
import bf.com.misys.ib.api.bb.dto.AssetAttributeInfo;
import bf.com.misys.ib.api.bb.dto.CurrencyAmount;
import bf.com.misys.ib.api.bb.dto.GenerateScheduleRes;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressPricingDtl;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AsstCategory;
import bf.com.misys.ib.types.ContextIDs;
import bf.com.misys.ib.types.IslamicBankingObject;

/**
 * Implementation for exposed REST services for 'Islamic Banking Service'.
 * 
 * @author chandni
 * 
 */

@FBPService(serviceId = "ceislamicBankingService", applicationId = "CEIBAPI", isExpose=true)
public class CEIslamicBankingService implements CEIIslamicBankingService {

	private static final transient Log LOGGER = LogFactory.getLog(CEIslamicBankingService.class.getName());

	@Override
	public String getLookUpsForTechAnalysisSoilType(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisSoilType(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisWaterAvailability(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisWaterAvailability(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisFarmType(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisFarmType(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisWaterMethod(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisWaterMethod(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisStatus(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisStatus(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisMainActivity(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisMainActivity(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisSeedlingsType(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisSeedlingsType(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisForPalm(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisForPalm(sContentType);
	}

	@Override
	public String getLookUpsForTechAnalysisPurpose(String sContentType) {
		return LaunchProcessHelper.getLookUpsForTechAnalysisPurpose(sContentType);
	}

	@Override
	public String getLookUpsForFollowUpFarmStatus(String sContentType) {
		return LaunchProcessHelper.getLookUpsForFollowUpFarmStatus(sContentType);
	}

	@Override
	public String getLookUpsForFollowUpStatus(String sContentType) {
		return LaunchProcessHelper.getLookUpsForFollowUpStatus(sContentType);
	}

	@Override
	public String getAssetCategoriesForDeal(String sContentType, String dealId) {
		LOGGER.info("Entering into getAssetCategoriesForDeal");
		ObjectMapper mapper = new ObjectMapper();
		String inputDealId = "";
		try {
			JsonNode jsonObject = mapper.readTree(dealId);
			inputDealId = mapper.treeToValue(jsonObject.get("dealId"), String.class);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (inputDealId == null || inputDealId.trim().length() == 0) {
			ApiCommonUtils.isValidateMandatoryField(inputDealId, IBConstants.FIELD_DEAL_ID);
		}

		AssetDetailsList assetDetailsList = new AssetDetailsList();
		List<FollowUpAssetDetails> assetDtlsList = new ArrayList<>();
		String dealAssetDtlsQuery = "WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " =? ORDER BY "
				+ IBOIB_DLI_DealAssetDtls.ASSETDETAILSID + " ASC";
		ArrayList<String> param = new ArrayList<>();
		param.clear();
		param.add(inputDealId);
		List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = (ArrayList<IBOIB_DLI_DealAssetDtls>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, dealAssetDtlsQuery, param, null, true);
		if (dealAssetDtls != null && !dealAssetDtls.isEmpty()) {
			for (IBOIB_DLI_DealAssetDtls dealAssetDtlsBO : dealAssetDtls) {
				FollowUpAssetDetails vFollowUpAssetDetails = new FollowUpAssetDetails();
				vFollowUpAssetDetails.setAssetId(dealAssetDtlsBO.getF_ASSETDETAILSID());

				IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory()
						.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, dealAssetDtlsBO.getF_ASSETDETAILSID(), true);
		
				vFollowUpAssetDetails.setAssetName(assetDetails.getF_ASSETNAME());

				vFollowUpAssetDetails.setStatus(assetDetails.getF_STATUS());
				if (!assetDetails.getF_STATUS().equals(IBConstants.ASSET_STATUS_ACTIVE)
						&& !assetDetails.getF_STATUS().equals(IBConstants.ASSET_STATUS_INACTIVE)) {
					ListGenericCodeRs genricCodes = IBCommonUtils.getGCList(IBConstants.ASSETSTATUS);
					for (GcCodeDetail gcCodeDetails : genricCodes.getGcCodeDetails()) {
						if (assetDetails.getF_STATUS().equals(gcCodeDetails.getCodeReference())) {
							vFollowUpAssetDetails.setStatus(gcCodeDetails.getCodeDescription());
							break;
						}
					}
				}

				// to get asset attributes and additional fields
				AssetUDF[] assetUDFs = CeUtils.getAssetAttributes(dealAssetDtlsBO.getF_ASSETDETAILSID(), inputDealId);
				HashMap<String, Object> assetUDFMap = CeUtils
						.getAssetUDFForAPI(vFollowUpAssetDetails.getAssetCategory().getCategory(), inputDealId, assetUDFs);

				if (assetUDFMap != null && !assetUDFMap.isEmpty()) {
					vFollowUpAssetDetails.setAdditionalInfo((List<AdditionalFieldInfo>) assetUDFMap.get("additionalFieldInfoList"));
					vFollowUpAssetDetails.setAssetAttributeInfo((List<AssetAttributeInfo>) assetUDFMap.get("assetAttributeList"));
				}

				assetDtlsList.add(vFollowUpAssetDetails);
			}
		}
		assetDetailsList.setAssetDetailsList(assetDtlsList);
		try {
			LOGGER.info("Exiting from getAssetCategoriesForDeal");
			mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
			return mapper.writeValueAsString(assetDetailsList);
		} catch (JsonProcessingException e) {
			LOGGER.info("JsonProcessingException while parsing the object from getAssetCategoriesForDeal");
			e.printStackTrace();
		}
		LOGGER.info("Exiting from getAssetCategoriesForDeal");
		return ApiCommonUtils.EMPTY_STRING;
	}

	@Override
	public String getLookUpsForTechAnalysisCropType(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CECROPTYPE");
	}

	@Override
	public String getLookUpsForTechAnalysisWellType(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEWELLTYPE");
	}

	@Override
	public String getLookUpsForTechAnalysisWellStatus(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEWELLSTATUS");
	}

	@Override
	public String getLookUpsForTechAnalysisFishPort(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEFISHPORT");
	}

	@Override
	public String getLookUpsForTechAnalysisWellCondition(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEWELLCONDITION");
	}

	@Override
	public String getLookUpsForTechAnalysisFishLicenseType(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEFISHLICENSETYPE");
	}

	@Override
	public String getLookUpsForTechAnalysisFishLicenseSource(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEFISHLICENSESOURCE");
	}

	@Override
	public String getLookUpsForTechAnalysisLetterGuardSource(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CELETTERGUARDSOURCE");
	}

	@Override
	public String getLookUpsForTechAnalysisWealthLetterSuorce(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEWEALTHLETTERSOURCE");
	}
	
	@Override
	public IBGetLookUpDetails getPaymentFrequency(String dealId) {
		return ScheduleHelper.getPaymentFrequency(dealId);
	}
	
	@Override
	public GenerateScheduleRes generateSchedule(GenerateScheduleRq generateScheduleRq) {
		return ScheduleHelper.generateSchedule(generateScheduleRq);
	}

	@Override
	public String generateProgressReportID(String sContentType) {
		return LaunchProcessHelper.generateProgressReportID();
	}
	@Override
	public String getLookUpsForMachineTypes(String sContentType) {
		return LaunchProcessHelper.getLookupForGCCode(sContentType, "CEMACHINETYPE");
	}
	@Override
	public CEIBAssetProgressCalculateCostRs assetProgressCalculateCost(CEIBAssetProgressCalculateCostRq req) {
		CEIBAssetProgressCalculateCostRs assetProgressCalculateCostRs = new CEIBAssetProgressCalculateCostRs();
		CalculatePricingCostForAssetProgress costForAssetProgress = new CalculatePricingCostForAssetProgress();
		AsstCategory assetCategory = new AsstCategory();
		assetCategory.setCategorization(req.getAssetCategory().getCategorization());
		assetCategory.setCategory(req.getAssetCategory().getCategory());
		assetCategory.setSubCategory(req.getAssetCategory().getSubCategory());
		costForAssetProgress.setF_IN_assetCategory(assetCategory );
		costForAssetProgress.setF_IN_assetID(req.getAssetID());
		costForAssetProgress.setF_IN_attribute7(req.getAttribute7());
		costForAssetProgress.setF_IN_attribute8(req.getAttribute8());
		costForAssetProgress.setF_IN_attribute9(req.getAttribute9());
		costForAssetProgress.setF_IN_GROUPCD(req.getGroupCD());
		IslamicBankingObject islamicBankingObject = prepareIslamicBankingObject(req.getDealID());
		costForAssetProgress.setF_IN_islamicBankingObject(islamicBankingObject );
		costForAssetProgress.setF_IN_LISTSER(req.getListSer());
		costForAssetProgress.setF_IN_originalFinalCost(req.getOriginalFinalCost());
		costForAssetProgress.setF_IN_originalStudyCost(req.getOriginalStudyCost());
		costForAssetProgress.setF_IN_TOOLNO(req.getToolNO());
		costForAssetProgress.process(IBCommonUtils.getBankFusionEnvironment());
		assetProgressCalculateCostRs.setCalculatedCost(costForAssetProgress.getF_OUT_assetCost());
		assetProgressCalculateCostRs.setCalculatedFinalCost(costForAssetProgress.getF_OUT_finalCalculatedCost());
		assetProgressCalculateCostRs.setErrMsg(costForAssetProgress.getF_OUT_errorMsg());
		assetProgressCalculateCostRs.setOkValue(costForAssetProgress.isF_OUT_okValue());
		assetProgressCalculateCostRs.setProgressPercentage(costForAssetProgress.getF_OUT_progressPercent());
		return assetProgressCalculateCostRs;
	}

	private IslamicBankingObject prepareIslamicBankingObject(String dealID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        
        IslamicBankingObject islamicBankingObject = null;

        IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
        IBOIB_CFG_ProcessConfig processConfig =
                (IBOIB_CFG_ProcessConfig) factory.findByPrimaryKey(IBOIB_CFG_ProcessConfig.BONAME, dealDetails.getF_PROCESSCONFIGID(), true);
        islamicBankingObject = new IslamicBankingObject();
        islamicBankingObject.setAmount(CommonConstants.BIGDECIMAL_ZERO);
        islamicBankingObject.setApprovalDecision(CommonConstants.EMPTY_STRING);
        // islamicBankingObject.setChargeAmount(dealDetails.get);
        ContextIDs conetextIDs = new ContextIDs();
        islamicBankingObject.setConetextIDs(conetextIDs);
        islamicBankingObject.setControllerMFName(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setCurrency(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setCustomerName(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setDealID(dealID);
        islamicBankingObject.setInitiationDate(SystemInformationManager.getInstance().getBFBusinessDate());
        islamicBankingObject.setIsDealEnquiry(false);
        islamicBankingObject.setIsLastTask(false);
        islamicBankingObject.setMode(IBConstants.BB_MODE_NORMAL);
        islamicBankingObject.setPhaseID(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setParentDealID(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setProcessConfigID(dealDetails.getF_PROCESSCONFIGID());
        islamicBankingObject.setProductID(dealDetails.getF_ProductCode());
        islamicBankingObject.setSubProductID(dealDetails.getF_ProductContextCode());
        islamicBankingObject.setTransactionID(dealID);
        islamicBankingObject.setTransactionName(processConfig.getF_PROCESSNAME());
        islamicBankingObject.setTerm(CommonConstants.INTEGER_ZERO);
        islamicBankingObject.setTermCode(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setUserID(BankFusionThreadLocal.getUserId());
		islamicBankingObject.setProfitAmount(CommonConstants.BIGDECIMAL_ZERO);
        if (dealDetails != null) {
            islamicBankingObject.setAmount(dealDetails.getF_DealAmt());
            islamicBankingObject.setCurrency(dealDetails.getF_IsoCurrencyCode());
            islamicBankingObject.setInitiationDate(dealDetails.getF_DealInitDate());
            islamicBankingObject.setTerm(dealDetails.getF_DealTerm());
            islamicBankingObject.setTermCode(dealDetails.getF_DEALTERMCODE());
        }
		return islamicBankingObject;
	}

	@Override
	public CEIBAssetProgressSelectMachineRs assetProgressSelectMachine(CEIBAssetProgressSelectMachineRq req) {
		CEIBAssetProgressSelectMachineRs assetProgressSelectMachineRs = new CEIBAssetProgressSelectMachineRs();
		List<MachineDetails> machineDetails = new ArrayList<MachineDetails>();
		AssetProgressMachineMatchingFatom matchingfatom =new AssetProgressMachineMatchingFatom(IBCommonUtils.getBankFusionEnvironment());
		AssetProgressDetails assetProgressDetails = new AssetProgressDetails();
		assetProgressDetails.setMachineNumber(req.getMachineNumber());
		assetProgressDetails.setMachineType(req.getMachineType());
		assetProgressDetails.setPriceListNumber(req.getPriceListNumber());
		assetProgressDetails.setPriceListYear(req.getPriceListYear());
		AsstCategory assetCategory = new AsstCategory();
		assetCategory.setCategorization(req.getAssetCategory().getCategorization());
		assetCategory.setCategory(req.getAssetCategory().getCategory());
		assetCategory.setSubCategory(req.getAssetCategory().getSubCategory());
		assetProgressDetails.setAssetCategory(assetCategory);
		matchingfatom.setF_IN_assetProgressDtl(assetProgressDetails );
		matchingfatom.setF_IN_mode("MATCH");
		matchingfatom.process(IBCommonUtils.getBankFusionEnvironment());
		for (AssetProgressPricingDtl assetProgressPricingDtl : matchingfatom.getF_OUT_foundAssetProgressPricingList().getAssetRegistryList()) {
			MachineDetails details = new MachineDetails();
			details.setAssetSerial(assetProgressPricingDtl.getAssetSerial());
			details.setExtensionIndicator(assetProgressPricingDtl.getExtensionIndicator());
			details.setModel(assetProgressPricingDtl.getModel());
			details.setPrice(assetProgressPricingDtl.getPrice());
			details.setPricingAssetID(assetProgressPricingDtl.getPricingAssetID());
			details.setPricingListID(assetProgressPricingDtl.getPricingListID());
			machineDetails.add(details);
		}
		assetProgressSelectMachineRs.setMachineDetails(machineDetails );
		return assetProgressSelectMachineRs;
	}

    @Override
    public TroubleProjectDetailsRes getTroubleProjectDtls() {
        TroubleProjectDetailsRes res = new TroubleProjectDetailsRes();
        List<TroubleProjectDetails> projectList = new ArrayList<>();
        //1st set
        String whereClause = "WHERE " + IBOIB_DLI_DealDetails.Status + " = ?";
        ArrayList<String> params = new ArrayList<>();
        params.add(CeConstants.DEAL_STATUS_TROUBLED_PROJECT_REQ);
        List<IBOIB_DLI_DealDetails> deals = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOIB_DLI_DealDetails.BONAME, whereClause, params, null, false);
        HashSet<String> dealsIncluded = new HashSet<>();
        if(null != deals && !deals.isEmpty())
        {
        	String statusDesc = CeUtils.getDealStatusDesc(CeConstants.DEAL_STATUS_TROUBLED_PROJECT_REQ);
        	for(IBOIB_DLI_DealDetails deal : deals)
        	{
        		TroubleProjectDetails troubledProjDtls = new TroubleProjectDetails();
        		troubledProjDtls.setDealId(deal.getBoID());
        		troubledProjDtls.setDealStatus(statusDesc);
        		troubledProjDtls.setUdf(TransferOfDebtReqUtils.readTroubledProjectReqUDFs(deal.getBoID(),deal.getF_IsoCurrencyCode()));
        		projectList.add(troubledProjDtls);
        		dealsIncluded.add(deal.getBoID());
        	}
        }
        
        //2nd set
        whereClause = "WHERE " + IBOCE_IB_TransferOfDebtDtls.IBTRBLPRJTRQSTED + " = ?";
        params.clear();
        params.add("Y");
        List<IBOCE_IB_TransferOfDebtDtls> TDDoneDeals = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_TransferOfDebtDtls.BONAME, whereClause, params, null, false);
        if(null != TDDoneDeals && !TDDoneDeals.isEmpty())
        {
        	HashMap<String, String> dealStatusMap = new HashMap<>();
        	for(IBOCE_IB_TransferOfDebtDtls TDDoneDeal : TDDoneDeals)
        	{
        		if(!dealsIncluded.contains(TDDoneDeal.getF_IBOLDDEALID()))
        		{
        			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(TDDoneDeal.getF_IBOLDDEALID());
        			TroubleProjectDetails troubledProjDtls = new TroubleProjectDetails();
        			troubledProjDtls.setDealId(dealDetails.getBoID());
        			if(dealStatusMap.containsKey(dealDetails.getF_Status()))
        			{
        				troubledProjDtls.setDealStatus(dealStatusMap.get(dealDetails.getF_Status()));
        			}
        			else
        			{
        				String statusDesc = CeUtils.getDealStatusDesc(dealDetails.getF_Status());
        				dealStatusMap.put(dealDetails.getF_Status(), statusDesc);
        				troubledProjDtls.setDealStatus(statusDesc);
        			}
        			troubledProjDtls.setUdf(TransferOfDebtReqUtils.readTroubledProjectReqUDFs(dealDetails.getBoID(),dealDetails.getF_IsoCurrencyCode()));
        			projectList.add(troubledProjDtls);
        		}
        	}
        }
        
        res.setTroubledProjDtls(projectList);
        return res;
    }
    
    @Override
	public ArrayList<CustomerLiabilities> getCustomerLiabilities(String customerId) {
		
		ArrayList<CustomerLiabilities> custLiablitiesResponse = new ArrayList<>();
		for (bf.com.misys.ib.types.CustomerLiabilities eachCustomerLiabilities : CeUtils
				.getCustomerLiabilities(customerId)) {
			CustomerLiabilities custLiabilites = new CustomerLiabilities();
			custLiabilites.setDealAccountID(eachCustomerLiabilities.getDealAccountID());
			custLiabilites.setDealId(eachCustomerLiabilities.getDealId());
			CurrencyAmount liabilityAmt = new CurrencyAmount();
			liabilityAmt.setAmount(eachCustomerLiabilities.getLiabilityAmount().getCurrencyAmount());
			liabilityAmt.setCurrency(eachCustomerLiabilities.getLiabilityAmount().getCurrencyCode());
			CurrencyAmount liabilityToBePaid = new CurrencyAmount();
			liabilityToBePaid.setAmount(eachCustomerLiabilities.getLiabilityToBePaid().getCurrencyAmount());
			liabilityToBePaid.setCurrency(eachCustomerLiabilities.getLiabilityToBePaid().getCurrencyCode());
			custLiabilites.setLiabilityAmount(liabilityAmt);
			custLiabilites.setLiabilityToBePaid(liabilityToBePaid);
			//custLiabilites.setPurchaseOrderID(eachCustomerLiabilities.getPurchaseOrderID());
			custLiabilites.setUserRole(eachCustomerLiabilities.getUserRole());
			custLiabilites.setUserRoleID(eachCustomerLiabilities.getPurchaseOrderID());
			custLiablitiesResponse.add(custLiabilites);
		}

		return custLiablitiesResponse;

	}
    
    @Override
	public CustomerLiabilityRs getCustomerLiabilityDetail(String customerId) {
    	ArrayList<CustomerLiabilitiesExt> liabilities = CeUtils.getCustomerLiabilityDetail(customerId);
		Comparator<CustomerLiabilitiesExt> cm2=Comparator.comparing(CustomerLiabilitiesExt::getDuedate);  
		Collections.sort(liabilities,cm2); 
    	CustomerLiabilityRs customerLiabilityRs = new CustomerLiabilityRs();
    	customerLiabilityRs.setLiabilities(liabilities);
    	return customerLiabilityRs;
	}
    
    
    
    @Override
   	public Boolean checkMachineType(String categoryID) {
    	
    	String MACHINE_TYPE_ASSET_QUERY = " where "+IBOIB_IBF_ProductAssetConfig.ASSETCATEGORYID+" = ? and "+IBOIB_IBF_ProductAssetConfig.PRODUCTID+" = ?";

    	ArrayList<String> queryParams = new ArrayList<String>();
		queryParams.add(categoryID);
		queryParams.add(CeConstants.MACHINE_TYPE_ASSET_PRODUCTID);
		List<IBOIB_IBF_ProductAssetConfig> productAssetConfigList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOIB_IBF_ProductAssetConfig.BONAME, MACHINE_TYPE_ASSET_QUERY, queryParams, null,
						true);
		if (productAssetConfigList != null && !productAssetConfigList.isEmpty()) {
			return true;
		}
    	else {
			return false;	
		}	
    }
}