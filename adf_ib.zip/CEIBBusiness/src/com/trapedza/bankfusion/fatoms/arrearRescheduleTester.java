package com.trapedza.bankfusion.fatoms;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.fbe.common.util.CommonUtil;
import com.misys.ub.common.lending.LendingConstants;
import com.misys.ub.common.lending.LendingUtils;
import com.misys.ub.common.lending.LoanScheduleUtils;
import com.misys.ub.lending.persistence.LoanPlanFinderMethods;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractarrearRescheduleTester;

import bf.com.misys.cbs.types.Amount;
import bf.com.misys.cbs.types.ArrearPayments;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.cbs.types.ManualRepaymentSchedule;
import bf.com.misys.cbs.types.ManualScheduleAmendmentInput;
import bf.com.misys.cbs.types.ProfitAmendmentInput;

public class arrearRescheduleTester extends AbstractarrearRescheduleTester {

	public VectorTable repaymentDtls = new VectorTable();
	public VectorTable scheduleDtls = new VectorTable();

	public arrearRescheduleTester(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		String mode = getF_IN_mode();
		String accountID = getF_IN_accountiD();
		if ("POPULATE".equalsIgnoreCase(mode)) {
			createRepaymentAndScheduleVector(accountID, env);
			setF_OUT_repaymentsData(repaymentDtls);
			setF_OUT_scheduleData(scheduleDtls);
		} else if("ADD_SCHEDULE".equalsIgnoreCase(mode)){
			scheduleDtls = getF_IN_scheduleData();
			HashMap scheduleMap = new HashMap<>();
			scheduleMap.put("AMENDED", false);
			scheduleMap.put("PAYMENTDATE", LendingUtils.getDefaultDate());
			scheduleMap.put("REPAYMENTNUMBER", 0);
			scheduleMap.put("PRINCIPALDUE", new BigDecimal("0.00"));
			scheduleMap.put("INTERESTDUE", new BigDecimal("0.00"));
			scheduleMap.put("CURRENCY", new BigDecimal("0.00"));
			scheduleDtls.addAll(new VectorTable(scheduleMap));
			setF_OUT_scheduleData(scheduleDtls);
		}else if("PROCESS".equalsIgnoreCase(mode)){
			prepareAndProcessAmedmentRq(accountID, getF_IN_repaymentsData(), getF_IN_scheduleData(),
					getF_IN_fixedInterestAmt(), isF_IN_onlyScheduleAmendment(), env);
		}
	}

	public void createRepaymentAndScheduleVector(String accountID, BankFusionEnvironment env) {
		List<IBOLoanRepayments> repaymentsList = LoanPlanFinderMethods.getUnpaidRepayments(accountID, env);
		for (IBOLoanRepayments repayment : repaymentsList) {
			HashMap repaymentMap = new HashMap<>();
			repaymentMap.put("FLAG", CommonConstants.EMPTY_STRING);
			repaymentMap.put("NEWDATE", LendingUtils.getDefaultDate() );
			repaymentMap.put("DUEDATE", repayment.getF_DUEDATE());
			repaymentMap.put("REPAYMENTNUMBER", repayment.getF_REPAYMENTNUMBER());
			repaymentMap.put("PRINCIPALDUE", repayment.getF_PRINCIPALDUE());
			repaymentMap.put("INTERESTDUE", repayment.getF_INTERESTDUE());
			repaymentMap.put("PENALTYINTDUE", repayment.getF_PENLATYINTERESTDUE());
			repaymentMap.put("PENALTYINTPAID", repayment.getF_PENALTYINTERESTPAID());
			repaymentMap.put("INTERESTPAID", repayment.getF_INTERESTPAID());
			repaymentMap.put("PRINCIPALPAID", repayment.getF_PRINCIPALPAID());
			repaymentMap.put("CURRENCY", repayment.getF_ISOCURRENCYCODE());
			repaymentDtls.addAll(new VectorTable(repaymentMap));
		}
		int nextRepay = repaymentsList.get(repaymentsList.size() - 1).getF_REPAYMENTNUMBER() +1;
		ArrayList reArrangeParams = new ArrayList(1);
		reArrangeParams.add(accountID);
		reArrangeParams.add(nextRepay);
		List<IBOLN_LEN_LoanSchedule> loanScheduleLIst = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOLN_LEN_LoanSchedule.BONAME,
				LoanScheduleUtils.LOAN_SCHEDULE_WHERE_CLAUSE_BY_ACCOUNTID_AND_REPAYNUMBER, reArrangeParams, null, true);

		for (IBOLN_LEN_LoanSchedule loanSchedule : loanScheduleLIst) {
			HashMap scheduleMap = new HashMap<>();
			scheduleMap.put("AMENDED", false);
			scheduleMap.put("PAYMENTDATE", loanSchedule.getF_PAYMENTDT());
			scheduleMap.put("REPAYMENTNUMBER", loanSchedule.getF_REPAYMENTNUMBER());
			scheduleMap.put("PRINCIPALDUE", loanSchedule.getF_CAPITALAMT());
			scheduleMap.put("INTERESTDUE", loanSchedule.getF_INTERESTAMT());
			scheduleMap.put("CURRENCY", loanSchedule.getF_CURRENCYCODE());
			scheduleDtls.addAll(new VectorTable(scheduleMap));
		}

	}

	public void prepareAndProcessAmedmentRq(String accountID, VectorTable repaymentsData, VectorTable scheduleData,
			BigDecimal fixedIntAmount, boolean onlyScheduleAmendment, BankFusionEnvironment env) {
		ManualScheduleAmendmentInput manualScheduleAmendmentInput = new ManualScheduleAmendmentInput();
		manualScheduleAmendmentInput.setLoanAccountNo(accountID);
		manualScheduleAmendmentInput.setAvoidHostScheduleValidation(true);
		BigDecimal totalInterest = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal totalCapital = CommonConstants.BIGDECIMAL_ZERO;
		int repayCount = 0;
		String currency = CommonConstants.EMPTY_STRING;
		int counter = 0;
		if (repaymentsData.size() > 0) {
			for (int i = 0; i < repaymentsData.size(); i++) {
				HashMap repaymentMap = repaymentsData.getRowTags(i);
				if (CommonUtil.checkIfNotNullOrEmpty((String) repaymentMap.get("FLAG"))) {
					ArrearPayments arrearPay = new ArrearPayments();
					arrearPay.setDueDate((java.sql.Date) repaymentMap.get("DUEDATE"));
					Date newDueDate = (java.sql.Date) repaymentMap.get("NEWDATE");
					arrearPay.setNewDueDate(CommonUtil.checkIfInvalidDate(newDueDate) ? null :newDueDate);
					arrearPay
							.setAmendFlag(((String) repaymentMap.get("FLAG")).equalsIgnoreCase("A") ? "AMEND" : "SKIP");
					arrearPay.setRepaymentNumber((Integer) repaymentMap.get("REPAYMENTNUMBER"));
					Currency principal = new Currency();
					principal.setIsoCurrencyCode((String) repaymentMap.get("CURRENCY"));
					principal.setAmount((BigDecimal) repaymentMap.get("PRINCIPALDUE"));
					arrearPay.setNewPrincipalDue(principal);
					Currency interest = new Currency();
					interest.setIsoCurrencyCode((String) repaymentMap.get("CURRENCY"));
					interest.setAmount((BigDecimal) repaymentMap.get("INTERESTDUE"));
					arrearPay.setNewInterestDue(interest);
					Currency penaltyInt = new Currency();
					penaltyInt.setIsoCurrencyCode((String) repaymentMap.get("CURRENCY"));
					penaltyInt.setAmount((BigDecimal) repaymentMap.get("PENALTYINTDUE"));
					arrearPay.setNewPenaltyInterestDue(penaltyInt);
					manualScheduleAmendmentInput.addArrearPayments(counter, arrearPay);
					counter++;
				}
			}
		}

		if (scheduleData.size() > 0) {
			for (int i = 0; i < scheduleData.size(); i++) {
				HashMap scheduleMap = scheduleData.getRowTags(i);
				if ((boolean) scheduleMap.get("AMENDED")) {
					ManualRepaymentSchedule manualSchedule = new ManualRepaymentSchedule();
					Amount principal = new Amount();
					principal.setAmountEdited((BigDecimal) scheduleMap.get("PRINCIPALDUE"));
					principal.setIsoCurrencyCode((String) scheduleMap.get("CURRENCY"));
					currency = principal.getIsoCurrencyCode();
					totalCapital = totalCapital.add(principal.getAmountEdited());
					manualSchedule.setCapitalAmount(principal);
					Amount interest = new Amount();
					interest.setAmountEdited((BigDecimal) scheduleMap.get("INTERESTDUE"));
					interest.setIsoCurrencyCode((String) scheduleMap.get("CURRENCY"));
					totalInterest = totalInterest.add(interest.getAmountEdited());
					manualSchedule.setCapitalAmount(principal);
					manualSchedule.setInterestAmt(interest);
					manualSchedule.setPaymentDate((Date) scheduleMap.get("PAYMENTDATE"));
					manualSchedule.setRepaymentNumber((Integer) scheduleMap.get("REPAYMENTNUMBER"));
					manualScheduleAmendmentInput.addManualRepaymentSchedule(repayCount, manualSchedule);
					repayCount++;
				}
			}
		} else {
			EventsHelper.handleEvent(40180493, new Object[] {}, new HashMap(), env);
		}

		Amount totalprinc = new Amount();
		totalprinc.setAmountEdited(totalCapital);
		totalprinc.setIsoCurrencyCode(currency);
		Amount totalInt = new Amount();
		totalInt.setAmountEdited(totalInterest);
		totalInt.setIsoCurrencyCode(currency);
		manualScheduleAmendmentInput.setTotalInterestAmount(totalInt);
		manualScheduleAmendmentInput.setTotalPrincipalAmount(totalprinc);
		manualScheduleAmendmentInput.setTotalNoOfPayments(repayCount);

		ProfitAmendmentInput fixedIntAmendment = new ProfitAmendmentInput();
		fixedIntAmendment.setManualScheduleAmendmentInput(manualScheduleAmendmentInput);
		fixedIntAmendment.setLoanAccID(accountID);
		fixedIntAmendment.setIsRateReview(true);
		Amount interestAMount = new Amount();
		interestAMount.setAmountEdited(fixedIntAmount);
		interestAMount.setIsoCurrencyCode(currency);
		fixedIntAmendment.setInterestAmount(interestAMount);

		HashMap<String, Object> params = new HashMap<String, Object>();
		if (onlyScheduleAmendment) {
			//params.put("eventMode", LendingConstants.MANUAL_AMENDMENT_MODE);
			params.put("ManualScheduleAmendmentInput", manualScheduleAmendmentInput);
			MFExecuter.executeMF("UB_LEN_ManualScheduleAmend_SRV", env, params);
		} else {
			params.put("FixedInterestAmendmentRq", fixedIntAmendment);
			MFExecuter.executeMF("UB_LEN_FixedInterestAmendment_SRV", env, params);
		}
		setF_OUT_status("Success");

	}
}
