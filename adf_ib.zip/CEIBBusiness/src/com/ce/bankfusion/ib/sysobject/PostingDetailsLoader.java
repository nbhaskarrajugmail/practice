package com.ce.bankfusion.ib.sysobject;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.objectloader.AbstractGenericExecutor;
import com.misys.cbs.objectloader.DbStep;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_FIN_AmortizationDetails;

import bf.com.misys.ib.types.PostingDetails;
import bf.com.misys.ib.types.ProductConfiguration;

public class PostingDetailsLoader extends AbstractGenericExecutor {

	private List<PostingDetails> doTheStuff(String dealId) {
		PostingDetails postingDetails = new PostingDetails();
		List<PostingDetails> returns = new ArrayList<PostingDetails>();
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
		if (null != dealDetails) {
			ProductConfiguration productDetails = IBCommonUtils.loadProductConfiguration(dealId);
			postingDetails.setDeferredIncomeAcc(RescheduleUtils.getDeferredIncomeAccPseudonym());
			ArrayList<String> params = new ArrayList<String>();
			String whereClause = "WHERE " + IBOUB_FIN_AmortizationDetails.ACCOUNTID+ " =? " ;
			params.add(dealDetails.getF_DealAccountId());
			postingDetails.setIsNonFrontLoadedManual(
					RescheduleUtils.isNonFrontLoadedManual(dealDetails.getF_ProductContextCode(),
							dealDetails.getF_DealAccountId(), productDetails.getIsHostScheduleGenerator()));
			postingDetails.setIsNonFrontLoadedManual(
					RescheduleUtils.isNonFrontLoadedManual(dealDetails.getF_ProductContextCode(),
							dealDetails.getF_DealAccountId(), productDetails.getIsHostScheduleGenerator()));
			if (!postingDetails.getIsNonFrontLoadedManual() && !productDetails.getIsHostScheduleGenerator()) {
				List<IBOUB_FIN_AmortizationDetails> amortizationDetailsList = BankFusionThreadLocal
						.getPersistanceFactory()
						.findByQuery(IBOUB_FIN_AmortizationDetails.BONAME, whereClause, params, null, true);
				if (null != amortizationDetailsList && !amortizationDetailsList.isEmpty())
					postingDetails.setEarnedAccount(amortizationDetailsList.get(0).getF_EARNEDACCOUNTID());
			} else if (postingDetails.getIsNonFrontLoadedManual()) {
				postingDetails
						.setEarnedAccount(RescheduleUtils.getInterestRecAccountID(dealDetails.getF_DealAccountId(),
								dealDetails.getF_BranchSortCode(), dealDetails.getF_IsoCurrencyCode()));
			}
			postingDetails.setReschEarnedAcc(RescheduleUtils.getRescheduleEarnedAccPseudonym());
			postingDetails.setReschReceivableAcc(RescheduleUtils.getRescheduleReceivableAccPseudonym());
			BigDecimal remReschProfitAmt = getRemainingRescheduleProfitAmt(dealId);
			postingDetails.setReschRemaingProfitAmt(remReschProfitAmt);
			postingDetails.setUnEarnedAccount(RescheduleUtils.getUnearnedAccPseudonym());
			postingDetails.setUpfrontIncomeAcc(RescheduleUtils.getUpfrontIncomeAccPseudonym());
			returns.add(postingDetails);
		}
		return returns;

	}

	public BigDecimal getRemainingRescheduleProfitAmt(String dealId) {
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);
		List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);
		BigDecimal totalScheduleFeesAmount = BigDecimal.ZERO;
		BigDecimal totalScheduleFeesPaidAmount = BigDecimal.ZERO;
		if (breakupDtls != null && !breakupDtls.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : breakupDtls) {

				totalScheduleFeesAmount = totalScheduleFeesAmount.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				totalScheduleFeesPaidAmount = totalScheduleFeesPaidAmount
						.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());

			}
		}
		BigDecimal remReschProfitAmt = totalScheduleFeesAmount.subtract(totalScheduleFeesPaidAmount);
		return remReschProfitAmt;
	}

	public void print() {
	}

	@Override
	public void initialize(DbStep paramDbStep) {

	}

	@Override
	public List executeAndPopulate(Map<String, Object> paramMap) {
		String dealId = (String) paramMap.get("dealId");

		if (dealId != null)
			return doTheStuff(dealId);
		return null;
	}

}
