package com.ce.bankfusion.ib.sysobject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOPayDetail;
import com.misys.cbs.objectloader.AbstractGenericExecutor;
import com.misys.cbs.objectloader.DbStep;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.systemparameters.DealIssuePOPaymentDetails;

public class IssuePOPayDtlsLoader extends AbstractGenericExecutor {

	private static String PAYMENTS_BY_ISSUEPO = " WHERE "+IBOCE_IB_IssuePOPayDetail.IBPURCHASEORDERID+" = ?";
    public List execute1(String boname, String query) {
        return null;

    }

    private List<Object> doTheStuff(String purchaseOrderId) {
    	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        ArrayList<String> param = new ArrayList<String>();
        param.add(purchaseOrderId);
        List<IBOCE_IB_IssuePOPayDetail> payDetailListDB = factory.findByQuery(IBOCE_IB_IssuePOPayDetail.BONAME, PAYMENTS_BY_ISSUEPO, param, null, true);
        List<Object> dealIssuePOPayDetailsList = new ArrayList<Object>();
        if (null != payDetailListDB) {
	        for(IBOCE_IB_IssuePOPayDetail payDetailDB : payDetailListDB) {
	        	DealIssuePOPaymentDetails paymentDetail = new DealIssuePOPaymentDetails();
				paymentDetail.setPurchaseOrderID(payDetailDB.getF_IBPURCHASEORDERID());
				paymentDetail.setPaymentOption(payDetailDB.getF_IBPAYMENTOPTION());
				paymentDetail.setBeneficiaryName(payDetailDB.getF_IBCUSTOMERNAME());
				paymentDetail.setThirdPartyID(payDetailDB.getF_IBTHIRDPARTYID());
				paymentDetail.setRelationshipPartyID(payDetailDB.getF_IBRELATIONSHIPID());
				paymentDetail.setBeneficiaryBank(payDetailDB.getF_IBBENIFICIARYBANK());
				paymentDetail.setBeneficiaryIBAN(payDetailDB.getF_IBIBAN());
				paymentDetail.setDebitBank(payDetailDB.getF_IBDEBITBANK());
				paymentDetail.setDebitAccount(payDetailDB.getF_IBDEBITACCOUNTID());
				paymentDetail.setDebitIBANAccount(payDetailDB.getF_IBDEBITBANKIBAN());
				
				paymentDetail.setPaymentAmount(payDetailDB.getF_IBPAYMENTAMOUNT());
				
				paymentDetail.setRemainingPaymentAmount(payDetailDB.getF_IBPENDINGAMOUNT());
				
				paymentDetail.setInvoiceNumber(payDetailDB.getF_IBINVOICENUMBER());
				paymentDetail.setInvoiceDate(payDetailDB.getF_IBINVOICEDATE());
				paymentDetail.setPaymentCurrency(payDetailDB.getF_IBCURRENCYCODE());
				paymentDetail.setPaymentExchangeRate(payDetailDB.getF_IBEXCHANGERATE());
				
				paymentDetail.setPaymentAmountInOtherCurrency(payDetailDB.getF_IBAMOUNTINFX());
				
				paymentDetail.setTransferID(payDetailDB.getF_IBTRANSFERID());
				paymentDetail.setTransferDate(payDetailDB.getF_IBTRANSFERDATE());
				paymentDetail.setPaymentNotes(payDetailDB.getF_IBNOTES());
				dealIssuePOPayDetailsList.add(paymentDetail);
			}
        }
        return dealIssuePOPayDetailsList;
    }


    public void print() {
    }

    @Override
    public void initialize(DbStep paramDbStep) {
        // TODO Auto-generated method stub

    }

    @Override
    public List executeAndPopulate(Map<String, Object> paramMap) {
        // TODO Auto-generated method stub

        Object purchaseOrderID = paramMap.get("purchaseOrderID");
        if (purchaseOrderID != null)
            return doTheStuff(purchaseOrderID.toString());
        return null;
    }

}
