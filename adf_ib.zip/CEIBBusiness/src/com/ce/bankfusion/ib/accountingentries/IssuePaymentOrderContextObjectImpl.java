package com.ce.bankfusion.ib.accountingentries;

import java.util.ArrayList;
import java.util.List;

import com.misys.bankfusion.ib.accountingentries.IContextObjectPreparator;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class IssuePaymentOrderContextObjectImpl implements IContextObjectPreparator {

    @Override
    public List<Object> getContextObject(String context, String objectId) {

        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

        IBOIB_TXN_PAYRECDETAIL payRecDtl = (IBOIB_TXN_PAYRECDETAIL) factory.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, objectId, true);
        List<Object> returnObject = new ArrayList<>();
        returnObject.add(payRecDtl);
        return returnObject;

    }

}
