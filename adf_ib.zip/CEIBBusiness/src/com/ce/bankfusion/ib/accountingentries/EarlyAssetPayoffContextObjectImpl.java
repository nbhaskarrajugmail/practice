package com.ce.bankfusion.ib.accountingentries;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.misys.bankfusion.ib.accountingentries.IContextObjectPreparator;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.util.IBCommonUtils;

public class EarlyAssetPayoffContextObjectImpl implements IContextObjectPreparator {

	public static final String SELECT_PAYMENTRECEIVEDTLS = " WHERE " + IBOIB_TXN_PAYRECDETAIL.TRANSACTIONID + " = ?"
			+ " AND " + IBOIB_TXN_PAYRECDETAIL.DEALNO + " = ? " + " AND " + IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + " = ? ";

	public static final String AMOUNT_TYPE = "EARLYASSETPAYOFF";

	@Override
	public List<Object> getContextObject(String context, String objectId) {

		List<Object> returnObject = new ArrayList<>();
		IBOCE_IB_EarlyAssetPayoffDtls earlyAssetPayoffDtls = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
				.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_EarlyAssetPayoffDtls.BONAME, objectId, true);
		returnObject.add(earlyAssetPayoffDtls);

		if (earlyAssetPayoffDtls != null) {
			IBOIB_TXN_PAYRECDETAIL payRecDtlObj = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
					.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, earlyAssetPayoffDtls.getF_IBPAYRECDETAILID(),
							true);
			returnObject.add(payRecDtlObj);
		}

		return returnObject;
	}

}
