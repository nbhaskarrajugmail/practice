/**
 * 
 */
package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.sql.Date;

import org.apache.commons.lang3.StringUtils;

import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ub.common.lending.LendingConstants;
import com.trapedza.bankfusion.core.BFCurrencyValue;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ce.api.dto.TroubleProjectUDFDtls;
import bf.com.misys.ib.api.bb.dto.CurrencyAmount;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;

/**
 * @author chethabn
 *
 */
public final class TransferOfDebtReqUtils {

	private TransferOfDebtReqUtils() {
	}

	/**
	 * check whether the deal is active or not
	 * 
	 * @return boolean
	 */
	public static final boolean isDealActive(String dealNumber) {
		boolean isDealActive = false;
		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealNumber);
		if (null != readLoanDetailsRs && null != readLoanDetailsRs.getDealDetails()
				&& null != readLoanDetailsRs.getDealDetails().getLoanBasicDetails()) {
			isDealActive = StringUtils.isEmpty(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getLoanStatus());
					//checkActiveLoanStatus(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getLoanStatus());
		}
		return isDealActive;
	}

	/**
	 * check the deal is in arrear by deal id
	 * 
	 * @param dealNumber
	 * @return
	 */
	public static final boolean isArrearDeal(String dealNumber) {

		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(dealNumber);
		boolean isArrear = false;
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getPaymentScheduleCount() > 0) {
			for (LoanPayments loanPayments : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
				if (loanPayments.getRepaymentStatus().equals(CeConstants.REPAYMENT_STATUS_ARREAR)) {
					isArrear = true;
					break;
				}
			}
		}
		/*if(!isArrear) {
			//TODO: Chethan BN  Update the valid event codes
			IBCommonUtils.raiseUnparameterizedEvent(40310261);
		}*/
		return isArrear;
	}

	private static boolean checkActiveLoanStatus(String loanStatus) {
		boolean active = false;
		switch (loanStatus) {
		case LendingConstants.LOAN_STATUS_NORMAL:
		case LendingConstants.LOAN_STATUS_ARREARS:
		case LendingConstants.LOAN_STATUS_FOR_REVERSAL:
		case LendingConstants.LOAN_STATUS_FUNDRELEASED:
		case LendingConstants.LOAN_STATUS_RESTRUCTURED:
		case LendingConstants.LOAN_STATUS_RENEGOTIATED:
		case LendingConstants.LOAN_STATUS_SETTLEMENTREQUESTED:
		case LendingConstants.LOAN_STATUS_PARTIAL_WRITEOFF:
			active = true;
			break;
		default:
			active = false;
			break;

		}
		return active;
	}
	
	public static TroubleProjectUDFDtls readTroubledProjectReqUDFs(String dealNo, String currCode)
    {
    	TroubleProjectUDFDtls udfs = new TroubleProjectUDFDtls();
    	IBOUDFEXTIB_DLI_DealDetails dealUDDtls = CeUtils.getDealDetailsExtensionDtls(dealNo);

    	UserDefinedFields userDefinedFields = dealUDDtls.getUserDefinedFields();
    	if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
    		for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
    			if(getUDFID(CeConstants.TROUBLED_PROJECT_REQ_PORTAL_STATUS_UDF).equals(userDefinedFld.getFieldName()))
    					{
    				udfs.setPortalStatus(null != userDefinedFld.getFieldValue()?(String) userDefinedFld.getFieldValue():null);
    			}
    			else if(getUDFID(CeConstants.TROUBLED_PROJECT_REQ_STOP_DATE_UDF).equals(userDefinedFld.getFieldName()))
    			{
    				udfs.setDateOfStop(null != userDefinedFld.getFieldValue()?(Date)userDefinedFld.getFieldValue():null);
    			}
    			else if(getUDFID(CeConstants.TROUBLED_PROJECT_REQ_APRVL_DATE_UDF).equals(userDefinedFld.getFieldName()))
    			{
    				udfs.setDateOfApproval(null != userDefinedFld.getFieldValue()?(Date)userDefinedFld.getFieldValue():null);
    			}
    			else if(getUDFID(CeConstants.TROUBLED_PROJECT_REQ_PAST_AMT_UDF).equals(userDefinedFld.getFieldName()))
    			{
    				CurrencyAmount curAmt = new CurrencyAmount();
    		    	curAmt.setCurrency(currCode);
    		    	BigDecimal amount = (null != userDefinedFld.getFieldValue()?new BigDecimal(userDefinedFld.getFieldValue().toString()):null);
    		    	curAmt.setAmount((new BFCurrencyValue(currCode, amount, null)).getRoundedAmount());
    		    	udfs.setPastDueAmount(curAmt);
    			}
    		}
    	}
    	return udfs;
    }
	
	public static String getUDFID(String fieldRef)
	{
			String udfID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
					CeConstants.UDFPROPERTY, fieldRef, "",
					CeConstants.ADFIBCONFIGLOCATION);
			return udfID;
	}
}
