package com.ce.bankfusion.ib.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealHoldDtls;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;

public class DealHoldUtil {
	
	private static final Log LOGGER = LogFactory.getLog(DealHoldUtil.class);
	
	private static String isDealHoldQuery = " WHERE " + IBOCE_IB_DealHoldDtls.IBDEALID + " = ? " + " AND "
			+ IBOCE_IB_DealHoldDtls.IBSTATUS + " = ? ";

	/** 
	 * This method will check the status of the deal from deal hold details and returns true if hold and viceversa
	 * Returns the reason if deal is on hold
	 * @param dealId
	 * @return String
	 */
	public static String isDealOnHold(String dealId) {
		String reason = null;
		if (!IBCommonUtils.isValidString(dealId)) {
			LOGGER.info("Deal is empty so returning null");
			return null;
		}
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(CeConstants.DEAL_STATUS_HOLD);
		List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
		if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
			reason = holdDtlsList.get(CommonConstants.INTEGER_ZERO).getF_IBHOLDREASON();
			LOGGER.info("Deal is on hold: "+dealId);
		}
		return reason;
	}
	
	/**get
	 * This method marks the deal as hold. It will inserts a record in DealHoldDetails table
	 * @param dealId
	 * @param reason
	 */
	public static void holdDeal(String dealId, String reason) {
		if(StringUtils.isNotEmpty(isDealOnHold(dealId))) {
			LOGGER.info("The deal is already on hold :"+dealId);
			return;
		}
		IBOCE_IB_DealHoldDtls dealHoldDetails = (IBOCE_IB_DealHoldDtls) IBCommonUtils.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_DealHoldDtls.BONAME);
		dealHoldDetails.setBoID(GUIDGen.getNewGUID());
		dealHoldDetails.setF_IBDEALID(dealId);
		dealHoldDetails.setF_IBSTATUS(CeConstants.DEAL_STATUS_HOLD);
		dealHoldDetails.setF_IBHOLDREASON(reason);
		dealHoldDetails.setF_IBCREATEDBY(BankFusionThreadLocal.getUserId());
		dealHoldDetails.setF_IBCREATEDDATE(IBCommonUtils.getBFBusinessDate());
		IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_DealHoldDtls.BONAME, dealHoldDetails);
	}
	
	/**
	 * This method requests the deal as Unhold. It will update a record in DealHoldDetails table against dealid and marks the action as requested
	 * @param dealId
	 * @param reason
	 */
	public static void requestUnHoldDeal(String dealId, String reason) {
		
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(CeConstants.DEAL_STATUS_HOLD);
		List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
		if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
			IBOCE_IB_DealHoldDtls dealHoldDetails = holdDtlsList.get(CommonConstants.INTEGER_ZERO);
			dealHoldDetails.setF_IBUNHOLDREASON(reason);
			dealHoldDetails.setF_IBACTION(CeConstants.DEAL_STATUS_UNHOLD_REQUESTED);
			dealHoldDetails.setF_IBMODIFIEDBY(BankFusionThreadLocal.getUserId());
			dealHoldDetails.setF_IBMODIFIEDDATE(IBCommonUtils.getBFBusinessDate());
		}
	}
	/**
	 * This method approves the deal as Unhold. It will update a record in DealHoldDetails table against dealid and marks the action as approved and status as unhold
	 * @param dealId
	 * @param reason
	 */
	public static void approveUnHoldDeal(String dealId, String reason) {
		
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(CeConstants.DEAL_STATUS_HOLD);
		List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
		if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
			IBOCE_IB_DealHoldDtls dealHoldDetails = holdDtlsList.get(CommonConstants.INTEGER_ZERO);
			dealHoldDetails.setF_IBUNHOLDREASON(reason);
			dealHoldDetails.setF_IBACTION(CeConstants.DEAL_STATUS_UNHOLD_APPROVED);
			dealHoldDetails.setF_IBSTATUS(CeConstants.DEAL_STATUS_UNHOLD);
			dealHoldDetails.setF_IBMODIFIEDBY(BankFusionThreadLocal.getUserId());
			dealHoldDetails.setF_IBMODIFIEDDATE(IBCommonUtils.getBFBusinessDate());
		}
	}
	
	/**
	 * This method requests the deal as Unhold. It will update a record in DealHoldDetails table against dealid and marks the action as requested
	 * @param dealId
	 * @param reason
	 */
	public static void reverseRequestUnHoldDeal(String dealId) {
		
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(CeConstants.DEAL_STATUS_HOLD);
		List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
		if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
			IBOCE_IB_DealHoldDtls dealHoldDetails = holdDtlsList.get(CommonConstants.INTEGER_ZERO);
			dealHoldDetails.setF_IBUNHOLDREASON(StringUtils.EMPTY);
			dealHoldDetails.setF_IBACTION(StringUtils.EMPTY);
			dealHoldDetails.setF_IBMODIFIEDBY(BankFusionThreadLocal.getUserId());
			dealHoldDetails.setF_IBMODIFIEDDATE(IBCommonUtils.getBFBusinessDate());
		}
	}
	/**
	 * This method approves the deal as Unhold. It will update a record in DealHoldDetails table against dealid and marks the action as approved and status as unhold
	 * @param dealId
	 * @param reason
	 */
	public static void reverseApproveUnHoldDeal(String dealId) {
		
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(CeConstants.DEAL_STATUS_HOLD);
		List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
		if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
			IBOCE_IB_DealHoldDtls dealHoldDetails = holdDtlsList.get(CommonConstants.INTEGER_ZERO);
			dealHoldDetails.setF_IBACTION(CeConstants.DEAL_STATUS_UNHOLD_REQUESTED);
			dealHoldDetails.setF_IBSTATUS(CeConstants.DEAL_STATUS_HOLD);
			dealHoldDetails.setF_IBMODIFIEDBY(BankFusionThreadLocal.getUserId());
			dealHoldDetails.setF_IBMODIFIEDDATE(IBCommonUtils.getBFBusinessDate());
		}
	}
}
