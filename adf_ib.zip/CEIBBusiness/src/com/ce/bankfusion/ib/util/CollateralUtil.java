package com.ce.bankfusion.ib.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.webservice.common.util.WebServiceInvocationHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.fbe.collateral.msgs.SearchCollateralTypeRq;
import bf.com.misys.fbe.collateral.msgs.SearchCollateralTypeRs;
import bf.com.misys.fbe.collateral.types.CollateralTypeDetails;
import bf.com.misys.fbe.customer.collateral.CustomerCollateralDetails;
import bf.com.misys.fbe.customer.collateral.CustomerCollateralDetailsRs;

public class CollateralUtil {
    public static final String AUTHENTICATION_PROVIDER = "AuthenticationProvider";
    public static final String UB_COL_PERSIST_COLLATERAL_DTLS_API_SRVWS_WSDL = "bfweb/services/UB_COL_PersistCollateralDtlsAPI_SRVWS?wsdl";
    public static final String UB_COL_PERSIST_COLLATERAL_DTLS_API_SRV = "UB_COL_PersistCollateralDtlsAPI_SRV";
    public static final String FALSE_STRING = "false";
    public static final String IB_HOST_URL = "IB_HOST_URL";
    public static final String REQUSEST_TYPE_REFERENCE = "REQ_TYP";
    public static final String REQUSEST_TYPE_NONPERSONAL ="Non-Personal";
    public static final String REQUSEST_TYPE_PERSONAL ="Personal";
    public static final String REQUSEST_TYPE_NOEVALUATION   ="No-Evaluation";
    public static final String UB_COL_SEARCH_COLLATERAL_TYPES_API_SRVWS_WSDL = "bfweb/services/UB_COL_SearchCollateralTypes_SRVWS?wsdl";
    public static final String UB_COL_SEARCH_COLLATERAL_TYPES_API_SRV = "UB_COL_SearchCollateralTypes_SRV";
    public static final String REQ_TYP_EXISTING = "Existing";
    public static final String PERSONALEXPIRYDATE = "PERSONALEXPIRYDATE";
    public static final String NONPERSONALEXPIRYDATE = "NONPERSONALEXPIRYDATE";
    public static final String NOELALUATIONEXPIRYDATE = "NOELALUATIONEXPIRYDATE";
    public static final String CUSTOM_COLLATERAL_CONF_FILE = "conf/business/customCollateral.properties";

    public static final String PERSONAL_COLLATERAL_TYPES = "PersonalCollateralTypes";
    public static final String NON_PERSONAL_COLLATERAL_TYPES = "Non-PersonalCollateralTypes";
    public static final String NO_EVALUATION_COLLATERAL_TYPES = "NoEvaluationCollateralTypes";
      
    public static final String UDF_PERSONAL_GUARANTORS_CUSTOMER_NUMBER = "_PERSONAL_GUARANTORS_CUSTOMER_NUMBER";
    public static final String UDF_NONPERSONAL_TITLE_DEED_NO = "_NONPERSONAL_TITLE_DEED_NO";
    public static final String UDF_NONPERSONAL_TITLE_DEED_TYPE = "_NONPERSONAL_TITLE_DEED_TYPE";
    public static final String UDF_NONPERSONAL_TITLE_DEED_SOURCE = "_NONPERSONAL_TITLE_DEED_SOURCE";
    public static final String UDF_NONPERSONAL_TITLE_DEED_YEAR = "_NONPERSONAL_TITLE_DEED_YEAR";
    public static final String UDF_NONPERSONAL_LAND_PLAN_NO = "_NONPERSONAL_LAND_PLAN_NO";
    public static final String UDF_NONPERSONAL_LAND_PLOT_NO = "_NONPERSONAL_LAND_PLOT_NO";
    
    public static final int E_COLLATERAL_DOC_DATE_MANDATORY_CEIB = 44000271;
    public static final int E_COLLATERAL_DOC_NUMBER_MANDATORY_CEIB = 44000272;
    public static final int E_COLLATERAL_DOC_SOURCE_MANDATORY_CEIB = 44000273;
    public static final int E_COLLATERAL_TYPE_MANDATORY_CEIB = 44000274;
    public static final int E_COLLATERAL_EXPIRY_DATE_MANDATORY_CEIB = 44000275;
    public static final int E_COLLATERAL_REQUEST_MANDATORY_CEIB = 44000276;
    public static final int E_COLLATERAL_EXPIRY_DATE_RANGE_CEIB = 44000277;
    public static final int E_COLLATERAL_REQUEST_PROMPT_CEIB = 44000278;
    public static final String COLLATERAL_STATUS = "ACTIVE";
    public static final String COLLATERAL_SYSTEM_STATUS_POSTED = "POSTED";
    public static final String COLLATERAL_SYSTEM_STATUS_NOTPOSTED = "NOTPOSTED";
    public static final String TITLE_DEED_TYPE_GC_REFERENCE = "TITLEDEEDTYPE";
    public static final String TITLE_DEED_SOURCE_GC_REFERENCE = "TITLEDEEDSOURCE";
    public static final String ERROR = "E";
    
    public static CustomerCollateralDetailsRs callPersistCollateralApi(CustomerCollateralDetails customerCollateralDetails, BankFusionEnvironment env) {
        Log LOGGER = LogFactory.getLog(CollateralUtil.class.getName());
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        LOGGER.info((gson.toJson(customerCollateralDetails)).replace("\"", " ").replace(",", "")
                .replace("_", "\t"));
        LOGGER.info(
                "------------------------customerCollateralDetails-------------------------");
        LOGGER.info((gson.toJson(customerCollateralDetails)).replace("\"", " ").replace(",", "")
                .replace("_", "\t"));
        String hostURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                IB_HOST_URL, FALSE_STRING);
        Map result = (Map) WebServiceInvocationHelper.invokeSynchronousCallGeneric(customerCollateralDetails, hostURL + UB_COL_PERSIST_COLLATERAL_DTLS_API_SRVWS_WSDL,
                UB_COL_PERSIST_COLLATERAL_DTLS_API_SRV);
        CustomerCollateralDetailsRs rs = (CustomerCollateralDetailsRs) result.get("customerCollateralDetailsRs");
        LOGGER.info((gson.toJson(rs)).replace("\"", " ").replace(",", "")
                .replace("_", "\t"));
        LOGGER.info(
                "------------------------CustomerCollateralDetailsRs-------------------------");
        LOGGER.info((gson.toJson(rs)).replace("\"", " ").replace(",", "")
                .replace("_", "\t"));
        return rs;
    }
    public static ListGenericCodeRs getAllCollateralTypes(BankFusionEnvironment env) {
        ListGenericCodeRs listGenericCodeRs = new ListGenericCodeRs();
        SearchCollateralTypeRs resp = callCollateralTypesApi(env);
        if(resp.getColTypeDetailsListCount()>0)
        {
            for(CollateralTypeDetails collateralTypeDetails :resp.getColTypeDetailsList())
            {
                GcCodeDetail gcCodeDetail = new GcCodeDetail();
                gcCodeDetail.setCodeReference(collateralTypeDetails.getCollateralTypeBasicDetails().getColType());
                gcCodeDetail.setCodeValue(collateralTypeDetails.getCollateralTypeBasicDetails().getColType());
                gcCodeDetail.setCodeDescription(collateralTypeDetails.getCollateralTypeBasicDetails().getColTypeDesc());
                listGenericCodeRs.addGcCodeDetails(gcCodeDetail);
            }
        }
        return listGenericCodeRs;
        
    }

    public static SearchCollateralTypeRs callCollateralTypesApi(BankFusionEnvironment env) {
        String hostURL = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                IB_HOST_URL, FALSE_STRING);
        
        SearchCollateralTypeRq searchCollateralTypeRq = (SearchCollateralTypeRq) intializeDefaultvalues(
                new SearchCollateralTypeRq());
        Map result = (Map) WebServiceInvocationHelper.invokeSynchronousCallGeneric(searchCollateralTypeRq, hostURL + UB_COL_SEARCH_COLLATERAL_TYPES_API_SRVWS_WSDL,
                UB_COL_SEARCH_COLLATERAL_TYPES_API_SRV);
       
        SearchCollateralTypeRs rs = (SearchCollateralTypeRs) result.get("searchCollateralTypeRs");
        return rs;
    }
    public static Object intializeDefaultvalues(Object req) {
        Field[] fooFields = req.getClass().getDeclaredFields();
        try {
            for (Field fooField : fooFields) {
                fooField.setAccessible(true);
                if (fooField.getType() == String.class) {
                    fooField.set(req, IBConstants.EMPTY_STRING);
                }
                if (fooField.getType() == Boolean.class) {
                    fooField.set(req, Boolean.FALSE);
                }
                if (fooField.getType() == Date.class) {
                    fooField.set(req, null);
                }
                if (fooField.getType() == Integer.class) {
                    fooField.set(req, BigDecimal.ZERO.intValue());
                }
                if (fooField.getType() == BigDecimal.class) {
                    fooField.set(req, BigDecimal.ZERO);
                }
                if (fooField.getType() == Currency.class) {
                    Currency currency = new Currency();
                    currency.setAmount(BigDecimal.ZERO);
                    currency.setIsoCurrencyCode(IBConstants.EMPTY_STRING);
                    fooField.set(req, currency);
                }
                if (fooField.getType() == Currency.class) {
                    Currency currency = new Currency();
                    currency.setAmount(BigDecimal.ZERO);
                    currency.setIsoCurrencyCode(IBConstants.EMPTY_STRING);
                    fooField.set(req, currency);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return req;
    }
}

