package com.ce.bankfusion.ib.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebt;
import com.ce.bankfusion.ib.fatom.GetProfitRateAndProfitAmount;
import com.ce.ib.cfg.dto.SubproductFrequency;
import com.ce.ib.cfg.dto.SubproductFrequencyDtl;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.ib.schedule.payments.DrawdownDetails;
import bf.com.misys.ib.schedule.payments.PaymentSchedule;
import bf.com.misys.ib.schedule.types.DrawDownAndDownPaymentDetails;
import bf.com.misys.ib.schedule.types.ScheduleBasicInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfo;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class ScheduleUtils {

	private static final Log LOGGER = LogFactory.getLog(ScheduleUtils.class);
	private static String whereClauseForbreakUp = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + "= ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBASSETID + "= ? ";
	public static BigDecimal hundred = new BigDecimal(100);
	public static final String QUERY_DEAL_ADDITIONAL_DTLS = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + " = ? ";
	
	public static ScheduleBasicInfo prepareScheduleInfoObj(Date lastPaymentDate, Date dealEffectiveDate,
			Date dealStartDate, BFCurrencyAmount dealPrincipalAmount) {
		ScheduleBasicInfo scheduleBasicInfo = new ScheduleBasicInfo();
		scheduleBasicInfo.setDealEffectiveDate(dealEffectiveDate);
		scheduleBasicInfo.setDealStartDate(dealStartDate);
		scheduleBasicInfo.setGraceDays(0);
		scheduleBasicInfo.setLastInstallmentDate(lastPaymentDate);
		scheduleBasicInfo.setDealAmt(dealPrincipalAmount);
		scheduleBasicInfo.setDealPrincipleAmt(dealPrincipalAmount);
		scheduleBasicInfo.setDealProfitAmt(IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO,
				dealPrincipalAmount.getCurrencyCode()));
		scheduleBasicInfo.setProfitChargesDealOverHeadCost(IBCommonUtils
				.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO, dealPrincipalAmount.getCurrencyCode()));
		scheduleBasicInfo.setProfitCost(dealPrincipalAmount);
		scheduleBasicInfo.setRemainingPrinciple(IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO,
				dealPrincipalAmount.getCurrencyCode()));
		scheduleBasicInfo.setRemainingProfit(IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO,
				dealPrincipalAmount.getCurrencyCode()));
		scheduleBasicInfo.setScheduledPrinciple(dealPrincipalAmount);
		scheduleBasicInfo.setScheduledProfit(IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO,
				dealPrincipalAmount.getCurrencyCode()));
		return scheduleBasicInfo;
	}

	public static ScheduleDetailedInfo prepareScheduleDetailedInfoObj(BFCurrencyAmount assetPrincipal,
			Date assetScheduleStartDate, Date assetLastPaymentDate, String paymentFrequency, String pricingMethod,
			String profitMethod, String baseFactor) {

		long noOfMonths = CalendarUtil.getMonthsBetweenDate1AndDate2(assetLastPaymentDate, assetScheduleStartDate);

		ScheduleDetailedInfo scheduleDetailedInfoObj = new ScheduleDetailedInfo();
		scheduleDetailedInfoObj.setBaseFactor(baseFactor);
		scheduleDetailedInfoObj.setCalculatedProfit(CeUtils.getZeroAmount(assetPrincipal.getCurrencyCode()));
		scheduleDetailedInfoObj.setNoOfPayment(0);
		scheduleDetailedInfoObj.setPaymentFrequencyCode(paymentFrequency);
		scheduleDetailedInfoObj.setPaymentFrequencyUnit(1);
		scheduleDetailedInfoObj.setPaymentOption(DealInitiationConstants.DEALINIT_CONST_NONE);
		scheduleDetailedInfoObj.setPrinciplePayment(assetPrincipal);
		scheduleDetailedInfoObj.setPrinciplePaymentAll(true);
		scheduleDetailedInfoObj.setProfitAmt(CeUtils.getZeroAmount(assetPrincipal.getCurrencyCode()));
		scheduleDetailedInfoObj.setProfitMatrixId(pricingMethod);
		scheduleDetailedInfoObj.setProfitMethod(profitMethod);
		scheduleDetailedInfoObj.setProfitPayment(CeUtils.getZeroAmount(assetPrincipal.getCurrencyCode()));
		scheduleDetailedInfoObj.setProfitPaymentAll(true);
		scheduleDetailedInfoObj.setScheduleDurationCode("Month");
		scheduleDetailedInfoObj.setScheduleDurationUnit((int) noOfMonths);
		scheduleDetailedInfoObj.setLastPaymentDate(assetLastPaymentDate);
		scheduleDetailedInfoObj.setScheduleEndDate(assetLastPaymentDate);
		scheduleDetailedInfoObj.setScheduleType(DealInitiationConstants.DEALINIT_CONST_GRACE);
		scheduleDetailedInfoObj.setScheduleStartDate(assetScheduleStartDate);
		scheduleDetailedInfoObj.setScheduleOption(DealInitiationConstants.DEALINIT_CONST_GENERATE);
		scheduleDetailedInfoObj.setInstallementAmt(CeUtils.getZeroAmount(assetPrincipal.getCurrencyCode()));
		
		return scheduleDetailedInfoObj;
	}

	public static DrawDownAndDownPaymentDetails prepareDrawdownAndPaymentDtlsForAsset(
			BFCurrencyAmount assetPrincipalAmount, Date dealStartDate) {
		DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails = new DrawDownAndDownPaymentDetails();
		DrawdownDetails vDrawdownDetails = new DrawdownDetails();
		vDrawdownDetails.setDrawdownAmount(assetPrincipalAmount.getCurrencyAmount());
		vDrawdownDetails.setDrawdownDate(dealStartDate);
		drawDownAndDownPaymentDetails.addDrawdownDetails(vDrawdownDetails);
		return drawDownAndDownPaymentDetails;
	}

	public static HashMap<String, BigDecimal> getProfitAmountAndProfitRate(BFCurrencyAmount assetPrincipalAmount,
			Date dealEffectiveDate, Date assetScheduleStartDate, Date assetLastPaymentDate, String paymentFrequency,
			String profitMethod, String pricingMethod, IslamicBankingObject islamicBankingObject) {

		HashMap<String, BigDecimal> profitAmountAndProfitRate = new HashMap<>();

		ProductConfiguration productConfiguration = IBCommonUtils
				.loadProductConfiguration(islamicBankingObject.getProductID(), islamicBankingObject.getSubProductID());
		ScheduleBasicInfo scheduleBasicInfo = prepareScheduleInfoObj(assetLastPaymentDate, dealEffectiveDate,
				assetScheduleStartDate, assetPrincipalAmount);
		
		String basefactor = productConfiguration.getGeneralParameters().getBaseFactor();
		ScheduleDetailedInfo scheduleDetailedInfoObj = prepareScheduleDetailedInfoObj(assetPrincipalAmount,
				assetScheduleStartDate, assetLastPaymentDate, paymentFrequency, pricingMethod, profitMethod,
				basefactor);
		boolean skipProfitCalculation = false;
		if (!IBCommonUtils.isNullOrEmpty(islamicBankingObject.getDealID())) {
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
			if(dealDetails != null && !IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId())) {
				IBOIB_DLI_ScheduleProfile scheduleProfile = IBCommonUtils.getScheduleProfileOfRepaymentType(islamicBankingObject.getDealID());
				if(scheduleProfile != null) {
					basefactor = scheduleProfile.getF_BaseFactor();
					scheduleDetailedInfoObj.setProfitRate(scheduleProfile.getF_ProfitRate());
					scheduleDetailedInfoObj.setBaseFactor(scheduleProfile.getF_BaseFactor());
					if (BigDecimal.ZERO.compareTo(scheduleProfile.getF_ProfitRate()) == 0)
					{
						skipProfitCalculation = true;
						profitAmountAndProfitRate.put("profitAmount",BigDecimal.ZERO );
						profitAmountAndProfitRate.put("profitRate", BigDecimal.ZERO);
					}
						
				}
			}
		}
		if(!skipProfitCalculation)
		{
			DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails = prepareDrawdownAndPaymentDtlsForAsset(
					assetPrincipalAmount, assetScheduleStartDate);

			HashMap outputParams = CeUtils.prepareCalculateProfitRq(scheduleDetailedInfoObj, scheduleBasicInfo,
					productConfiguration, drawDownAndDownPaymentDetails, islamicBankingObject, pricingMethod,
					profitMethod, basefactor);

			Currency profileCalculatedProfit = (Currency) outputParams.get("CalculatedProfit");

			profitAmountAndProfitRate.put("profitAmount", profileCalculatedProfit.getAmount());
			profitAmountAndProfitRate.put("profitRate", (BigDecimal) outputParams.get("ProfitRate"));
		}
		return profitAmountAndProfitRate;
	}

	public static HashMap<String, BigDecimal> getAssetProfitAmount(Date dealEffectiveDate, String assetId,
			String paymentFrequency, String profitMethod, String pricingMethod,
			IslamicBankingObject islamicBankingObject, BFCurrencyAmount assetPrincipalAmount,
			ReadAssetData readAssetData) {

		HashMap<String, BigDecimal> profitAmountAndProfitRate = new HashMap<>();
		Date assetScheduleStartDate = CeUtils.getScheduleStartDate(dealEffectiveDate, "YEARLY",
				CeUtils.getDisbursementPeriodForAsset(readAssetData, assetId));

		Date assetLastPaymentDate = CeUtils.getLastPaymentDate(assetScheduleStartDate, paymentFrequency, readAssetData,
				islamicBankingObject.getDealID(), assetId);

		Properties confProperties = new Properties();
		String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
        String filePath = confPath.concat(CeConstants.EXLUCDE_DISBURSE_PERIOD_PRICINGMATRIXID);
        loadConfigPricingMatrixProperties(filePath, confProperties);
        
        if(pricingMethod!=null && pricingMethod.equals(confProperties.getProperty("ExcludeDisbursePeriod"))) {
        	profitAmountAndProfitRate = ScheduleUtils.getProfitAmountAndProfitRate(assetPrincipalAmount, dealEffectiveDate,
        			assetScheduleStartDate, assetLastPaymentDate, paymentFrequency, profitMethod, pricingMethod,
    				islamicBankingObject);
        }else {
        	profitAmountAndProfitRate = ScheduleUtils.getProfitAmountAndProfitRate(assetPrincipalAmount, dealEffectiveDate,
    				dealEffectiveDate, assetLastPaymentDate, paymentFrequency, profitMethod, pricingMethod,
    				islamicBankingObject);
        }

		return profitAmountAndProfitRate;
	}
	
	public static void loadConfigPricingMatrixProperties(String absoluteFilePath, Properties confProperties) {
        try {
        	
            FileReader reader = new FileReader(absoluteFilePath);
            if (reader != null) {
                confProperties.load(reader);
            } else {
                LOGGER.error("Config File for Pricing Matrix (conf/business/configPricingMatrix.properties) not found");
                throw new FileNotFoundException("property file '" + absoluteFilePath + "' not found in the classpath");
            }
        } catch (Exception e) {
            LOGGER.error("Error occured in reading the conf/business/configPricingMatrix.properties file : " + e);
        }
    }

	public static SubproductFrequencyDtl getFrequenciesConfiguredAtSubproduct(String subproductId) {
		String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
		String filePath = confPath.concat("conf/business/subproductFrequency.xml");
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(SubproductFrequency.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			InputStream inStream = new FileInputStream(filePath);
			SubproductFrequency subproductFrequency = (SubproductFrequency) jaxbUnmarshaller.unmarshal(inStream);
			if (subproductFrequency != null) {
				for (SubproductFrequencyDtl subproductFreqDtl : subproductFrequency.getSubproductFrequencyDtl()) {
					if (!IBCommonUtils.isNullOrEmpty(subproductId)
							&& subproductFreqDtl.getSubproductId().equals(subproductId)) {
						return subproductFreqDtl;
					}
				}
			}
		} catch (JAXBException | FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

	public static String getParentReference(String subproductId, String productId) {
		String parentReference;
		boolean isHostScheduleGenerator = IBCommonUtils.loadProductConfiguration(productId, subproductId)
				.getIsHostScheduleGenerator();

		if (isHostScheduleGenerator) {
			parentReference = CeConstants.IBHOSTFREQCODE;
		} else {
			parentReference = CeConstants.IBREPAYMENTFREQUENCY;
		}

		return parentReference;
	}

	public static boolean validateDealEffDateLessThanStartDate(Date dealEffectiveDate, Date dealStartDate) {
		boolean raiseEvent = false;
		if (!CalendarUtil.isDateNullOrDefaultDate(dealEffectiveDate)
				&& CalendarUtil.IsDate1GreaterThanDate2(dealStartDate, dealEffectiveDate))
			raiseEvent = true;
		return raiseEvent;
	}

	public static boolean validateDealEffDateIfNWD(Date dealEffectiveDate, String dealId) {
		boolean raiseEvent = false;
		if (CalendarUtil.isNonWorkingDayBasedOnNWP(dealEffectiveDate, dealId))
			raiseEvent = true;
		return raiseEvent;
	}

	public static BigDecimal getAssetOutstandingPrincipalAmount(ReadLoanDetailsRs readLoanDetailsRs, String dealId,
			String assetId) {
		BigDecimal principalAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(dealId);
		queryParams.add(assetId);
		List<IBOCE_IB_PaymentSchBreakup> resultSet = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClauseForbreakUp, queryParams, null, true);

		if (resultSet != null && !resultSet.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : resultSet) {
				totalAssetCost = totalAssetCost.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
				principalAmountPaid = principalAmountPaid.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID())
						.add(paymentSchBreakup.getF_IBSUBSIDYAMTPAID());
			}
		}
		if (totalAssetCost.subtract(principalAmountPaid).compareTo(BigDecimal.ZERO) > 0)
			return totalAssetCost.subtract(principalAmountPaid);
		else
			return totalAssetCost;
	}

	public static BigDecimal getAssetOutstandingProfitAmount(ReadLoanDetailsRs readLoanDetailsRs, String dealId,
			String assetId) {
		BigDecimal profitAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetProfitAmount = BigDecimal.ZERO;
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(dealId);
		queryParams.add(assetId);
		List<IBOCE_IB_PaymentSchBreakup> resultSet = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClauseForbreakUp, queryParams, null, true);

		if (resultSet != null && !resultSet.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : resultSet) {
				totalAssetProfitAmount = totalAssetProfitAmount.add(paymentSchBreakup.getF_IBPROFITAMT());
				profitAmountPaid = profitAmountPaid.add(paymentSchBreakup.getF_IBPROFITAMTPAID());
			}
		}
		if (totalAssetProfitAmount.subtract(profitAmountPaid).compareTo(BigDecimal.ZERO) > 0)
			return totalAssetProfitAmount.subtract(profitAmountPaid);
		else
			return totalAssetProfitAmount;
	}
	
	public static BigDecimal getAssetExistingProfitAmount(String dealId,
			String assetId) {
		BigDecimal totalAssetProfitAmount = BigDecimal.ZERO;
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(dealId);
		queryParams.add(assetId);
		List<IBOCE_IB_PaymentSchBreakup> resultSet = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClauseForbreakUp, queryParams, null, true);

		if (resultSet != null && !resultSet.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : resultSet) {
				totalAssetProfitAmount = totalAssetProfitAmount.add(paymentSchBreakup.getF_IBPROFITAMT());
			}
		}
		return totalAssetProfitAmount;
	}

	public static void updateDealAdditionalDetails(ScheduleDetailedInfo[] scheduleDetailedInfoList, String dealId) {

		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);

		List<IBOIB_DLI_DealAditionalDtls> dealAddtionalDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, QUERY_DEAL_ADDITIONAL_DTLS, params, null, false);
		for (IBOIB_DLI_DealAditionalDtls updateDealaddtionalDtls : dealAddtionalDtls) {
			updateDealaddtionalDtls.setF_CONSTRUCTIONEQUIVALENTRATE(null);
			updateDealaddtionalDtls.setF_GRACEEQUIVALENTRATE(null);
			updateDealaddtionalDtls.setF_REPAYMENTEQUIVALENTRATE(null);
			for (ScheduleDetailedInfo scheduleDetailedInfo : scheduleDetailedInfoList) {
				updateDealaddtionalDtls.setF_ProfitType(scheduleDetailedInfo.getProfitMethod());
				updateDealaddtionalDtls.setF_ProfitMatrixId(scheduleDetailedInfo.getProfitMatrixId());
				if (DealInitiationConstants.DEALINIT_CONST_CONSTRUCTION.equals(scheduleDetailedInfo.getScheduleType()))
					updateDealaddtionalDtls.setF_CONSTRUCTIONEQUIVALENTRATE(scheduleDetailedInfo.getEquivalentRate());
				else if (DealInitiationConstants.DEALINIT_CONST_GRACE.equals(scheduleDetailedInfo.getScheduleType()))
					updateDealaddtionalDtls.setF_GRACEEQUIVALENTRATE(scheduleDetailedInfo.getEquivalentRate());
				else if (DealInitiationConstants.DEALINIT_CONST_REPAYMENT
						.equals(scheduleDetailedInfo.getScheduleType()))
					updateDealaddtionalDtls.setF_REPAYMENTEQUIVALENTRATE(scheduleDetailedInfo.getEquivalentRate());

			}

			updateDealaddtionalDtls.setF_SCHEDULEMODIFYDATE(IBCommonUtils.getBFBusinessDateTime());
		}
	}

	public static List<String> getAssetIdFromTransferOfDebt(String dealId) {
		ArrayList<String> param = new ArrayList<>();
		String[] arrOfStr = null;
		List<String> assets = new ArrayList<>();
		String findByDealId = " WHERE " + IBOCE_IB_TransferOfDebt.IBORIGINALDEALID + " = ? ORDER BY "
				+ IBOCE_IB_TransferOfDebt.IBRECCREATEDON + " ASC";
		param.add(dealId);
		List<IBOCE_IB_TransferOfDebt> result = null;
		result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_TransferOfDebt.BONAME, findByDealId,
				param, null, true);
		if (null != result && !result.isEmpty()) {
			for (IBOCE_IB_TransferOfDebt transferOfDebt : result) {
				String disbursedAssets = transferOfDebt.getF_IBDISBURSEDASSETS();
				arrOfStr = disbursedAssets.split("\\|");
			}
			assets = Arrays.asList(arrOfStr);
		}
		return assets;
	}

	public static void bulkDeleteBreakupData(String dealId) {
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		String whereClause = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
		BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_PaymentSchBreakup.BONAME, whereClause,
				params);
	}

	public static void sortPaymentSchedule(ArrayList<PaymentSchedule> paymentScheduleList) {

		Collections.sort(paymentScheduleList, new Comparator<PaymentSchedule>() {

			public int compare(PaymentSchedule o1, PaymentSchedule o2) {
				if (o1 == null || o2 == null) {
					return 0;
				}

				if (o1.getRepaymentDate() == null || o2.getRepaymentDate() == null) {
					return 0;
				}

				return o1.getRepaymentDate().toString().compareTo(o2.getRepaymentDate().toString());
			}
		});
	}

	public static void sortCEPaymentSchedule(ArrayList<CePaymentSchedule> paymentScheduleList) {

		Collections.sort(paymentScheduleList, new Comparator<CePaymentSchedule>() {

			public int compare(CePaymentSchedule o1, CePaymentSchedule o2) {
				if (o1 == null || o2 == null) {
					return 0;
				}

				if (o1.getRepaymentDate() == null || o2.getRepaymentDate() == null) {
					return 0;
				}

				return o1.getRepaymentDate().toString().compareTo(o2.getRepaymentDate().toString());
			}
		});
	}

	public static void persistPaymentScheduleBreakup(String dealId, String assetId, ReadAssetData readAssetData,
			PaymentSchedule paymentSchedule, boolean isInlcudeSubsidy) {

		String assetSubsidyPercentage = CeUtils.getAssetSubsidyPercentage(readAssetData, assetId);
		if (assetSubsidyPercentage.equals(CommonConstants.EMPTY_STRING)) {
			assetSubsidyPercentage = "0.00";
		}
		IBOCE_IB_PaymentSchBreakup paymentSchBreakup = (IBOCE_IB_PaymentSchBreakup) (BankFusionThreadLocal
				.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentSchBreakup.BONAME));
		paymentSchBreakup.setBoID(IBCommonUtils.getNewGUID());
		paymentSchBreakup.setF_IBASSETID(assetId);
		paymentSchBreakup.setF_IBBILLDATE(paymentSchedule.getRepaymentDate());
		paymentSchBreakup.setF_IBDEALID(dealId);
		paymentSchBreakup.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMT(paymentSchedule.getPrincipleAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBPROFITAMT(paymentSchedule.getProfitAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBSCHEDULEFEEAMT(paymentSchedule.getFeeAmt().getCurrencyAmount());
		paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
		if (isInlcudeSubsidy) {
			paymentSchBreakup.setF_IBSUBSIDYAMNT((paymentSchedule.getPrincipleAmt().getCurrencyAmount()
					.multiply(new BigDecimal(assetSubsidyPercentage))).divide(hundred, 0, RoundingMode.FLOOR));
		}
		BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_PaymentSchBreakup.BONAME, paymentSchBreakup);
	}
	public static void persistPaymentScheduleBreakupHistoryTable(String dealId, String assetId, ReadAssetData readAssetData,
			PaymentSchedule paymentSchedule, boolean isInlcudeSubsidy) {

		String assetSubsidyPercentage = CeUtils.getAssetSubsidyPercentage(readAssetData, assetId);
		if (assetSubsidyPercentage.equals(CommonConstants.EMPTY_STRING)) {
			assetSubsidyPercentage = "0.00";
		}
		IBOCE_IB_PaymentScheduleHistory newPaymentScheduleHistory = (IBOCE_IB_PaymentScheduleHistory) (BankFusionThreadLocal
				.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentScheduleHistory.BONAME));
		newPaymentScheduleHistory.setF_IBASSETID(assetId);
		newPaymentScheduleHistory.setF_IBDEALID(dealId);
		newPaymentScheduleHistory.setF_IBPRINCIPALAMOUNT(paymentSchedule.getPrincipleAmt().getCurrencyAmount());
		newPaymentScheduleHistory.setF_IBPROFITAMOUNT(paymentSchedule.getProfitAmt().getCurrencyAmount());
		newPaymentScheduleHistory.setF_IBREPAYMENTDATE(paymentSchedule.getRepaymentDate());
		newPaymentScheduleHistory.setF_IBRESCHEDULEID(dealId);
		newPaymentScheduleHistory.setF_IBSCHEDULEFEESAMOUNT(paymentSchedule.getFeeAmt().getCurrencyAmount());
		newPaymentScheduleHistory.setF_IBREPAYMENTSTATUS(IBConstants.REPAYMENT_STATUS_UNPAID);
		if (isInlcudeSubsidy) {
			newPaymentScheduleHistory.setF_IBSUBSIDYAMOUNT((paymentSchedule.getPrincipleAmt().getCurrencyAmount()
					.multiply(new BigDecimal(assetSubsidyPercentage))).divide(hundred, 0, RoundingMode.FLOOR));
		}
		BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_PaymentScheduleHistory.BONAME, newPaymentScheduleHistory);
	}

}
