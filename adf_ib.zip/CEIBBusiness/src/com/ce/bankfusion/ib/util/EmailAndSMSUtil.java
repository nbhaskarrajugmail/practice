package com.ce.bankfusion.ib.util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SMSHistory;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.subsystem.messaging.runtime.impl.SmppMessageSender;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.fatoms.GenerateMessageContent;

import bf.com.misys.bankfusion.attributes.EmailTemplateDetails;
import bf.com.misys.cbs.services.ReadModuleConfigurationRq;
import bf.com.misys.cbs.services.ReadModuleConfigurationRs;
import bf.com.misys.cbs.types.ModuleKeyRq;
import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.ib.spi.types.CustomerDetails;
import bf.com.misys.ib.types.EmailParams;

public class EmailAndSMSUtil {
	private static final transient Log LOG = LogFactory.getLog(EmailAndSMSUtil.class.getName());
	
	
	public static void sendEmailAndSMS(String dealID, String emailTemplateID, String smsTemplateID, String subject, Map<String, String> paramAndValues, List<String> partyIds) {
		EmailParams emailParams = new EmailParams();
		HashMap<String, String> map = new HashMap<>();
		for(Entry<String, String> entry : paramAndValues.entrySet()) {
			map.put(entry.getKey(), entry.getValue());
		}
		emailParams.setUserExtension(map);
		List<String> toAddress = new ArrayList<>();
		String toList = populateSenderList(partyIds, toAddress);
        sendEmailSMS(emailParams, emailTemplateID, smsTemplateID, subject, toList, toAddress);
        saveIntoSMSHistory(IBCommonUtils.getBFBusinessDate(), dealID, paramAndValues.values().toString(), toAddress.toString());
	}
	
	/**
     * @param smsEmailMap
     * @param emailSMSParameters
     * @param emlBusinessData
     */
    private static void sendEmailSMS(EmailParams emlBusinessData, String emailTemplateID, String smsTemplateID, String subject, String toList, List<String> toAddress) {

            HashMap<String, Object> paramsargupdate = new HashMap<String, Object>();
            paramsargupdate.put(IBConstants.BCCLIST, new ArrayList<>());
            paramsargupdate.put(IBConstants.BUSINESSDATA, emlBusinessData);
            paramsargupdate.put(IBConstants.CCLIST, new ArrayList<>());
            paramsargupdate.put(IBConstants.FROMADDRESS, BankFusionPropertySupport
                .getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, "FromEmailAddress", "false"));
            paramsargupdate.put(IBConstants.MAILBODYTEMPLATE, emailTemplateID);
            paramsargupdate.put(IBConstants.MAILSUBJECT, subject);
            paramsargupdate.put(IBConstants.TOADDRESS, toList);
            if (LOG.isInfoEnabled()) {
                LOG.info("Sending Email to TO: " + toList);
            }
            if (readModuleConfiguration().equals("false")) {
                try {
                    executeMF("CB_ACC_SendEmail_SRV", paramsargupdate);
                } catch (Exception e) {
                    LOG.error(e.getLocalizedMessage());
                    IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
                        .getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
                    Event repayValidation = new Event();
                    repayValidation.setEventNumber(35000166);
                    businessEventsService.handleEvent(repayValidation);
                }
            } else {
                executeMF("CB_ACC_SendEmail_SRV", paramsargupdate);
            }

            // Sending SMS
            GenerateMessageContent gmc = new GenerateMessageContent(BankFusionThreadLocal.getBankFusionEnvironment());

            EmailTemplateDetails templateDetails = new EmailTemplateDetails();
            templateDetails.setBusinessDataMap(emlBusinessData);
            templateDetails.setTemplateName(smsTemplateID);
            templateDetails.setLocale("");
            gmc.setF_IN_EmailTemplateDetails(templateDetails);

            gmc.process(BankFusionThreadLocal.getBankFusionEnvironment());

            StringBuffer smsContent = new StringBuffer(gmc.getF_OUT_MessageData().toString());

            if (LOG.isInfoEnabled()) {
                LOG.info("SMS Content " + smsContent);
                LOG.info("Sending SMS to " + toList);
            }


            for (String smsRecepient : toAddress) {
                if (!(smsRecepient.replaceAll("\\s+", "").equals(IBConstants.EMPTY_STRING)))
                    SmppMessageSender.send(smsContent.toString(), smsRecepient);
            }



    }
    /**
     * @param mfName
     * @param paramsargupdate
     * @return
     */
    @SuppressWarnings("rawtypes")
    private static HashMap executeMF(String mfName, HashMap<String, Object> paramsargupdate) {
        HashMap listDataMap =
            MFExecuter.executeMF(mfName, paramsargupdate, BankFusionThreadLocal.getUserLocator().getStringRepresentation());
        return listDataMap;
    }
    private static String readModuleConfiguration() {
        ReadModuleConfigurationRq readModuleConfigurationRq = new ReadModuleConfigurationRq();

        ModuleKeyRq moduleKeyRq = new ModuleKeyRq();
        moduleKeyRq.setKey("SMSEMAILVALIDATION");
        moduleKeyRq.setModuleId(IBConstants.MODULEID_IB);
        readModuleConfigurationRq.setModuleKeyRq(moduleKeyRq);

        HashMap param = new HashMap();
        param.put("ReadModuleConfigurationRq", readModuleConfigurationRq);

        HashMap<String, Object> outputParams =
            MFExecuter.executeMF(IBConstants.READ_MODULE_CONF, BankFusionThreadLocal.getBankFusionEnvironment(), param);
        ReadModuleConfigurationRs readModuleConfigurationRs = (ReadModuleConfigurationRs) outputParams.get("ReadModuleConfigurationRs");

        return readModuleConfigurationRs.getModuleConfigDetails().getValue();
    }
    
    public static void saveIntoSMSHistory(Date date, String dealID, String paramValues, String toList) {
    	try {
    	 IPersistenceObjectsFactory factory = BankFusionThreadLocal
    			.getPersistanceFactory();
    	IBOCE_IB_SMSHistory smsHistory = (IBOCE_IB_SMSHistory) factory.getStatelessNewInstance(IBOCE_IB_SMSHistory.BONAME);

    	smsHistory.setBoID(GUIDGen.getNewGUID());
    	smsHistory.setF_IBDATE(date);
    	smsHistory.setF_IBDEALID(dealID);
    	smsHistory.setF_IBSMSCONTENTVALUES(paramValues);
    	smsHistory.setF_IBTOLIST(toList);
		factory.create(IBOCE_IB_SMSHistory.BONAME,
				smsHistory);
    	}catch(Exception e) {
    		LOG.error("Error occured in inserting into sms history", e);
    	}
    }
    
    /**
     * @param dealInfoEmailSMSDetails
     * @param customerList
     * @param isGuarantor
     * @return
     */
    private static String populateSenderList(List<String> partyIds, List<String> toAddress) {
    	String toList = "";
        for (String customerID : partyIds) {
            CustomerDetails custDetaildFromParty =
                IBCommonUtils.getPartyDetailsFromPartyID(customerID, BankFusionThreadLocal.getBankFusionEnvironment());
            if(custDetaildFromParty == null || custDetaildFromParty.getContactDetails() == null) {
            	continue;
            }

            if (null != custDetaildFromParty.getContactDetails().getContactEmailId()) {
                if (toList==null || toList.equals(IBConstants.EMPTY_STRING))
                    toList = custDetaildFromParty.getContactDetails().getContactEmailId();
                else
                	toList = toList.concat(IBConstants.ADDRESS_REGEX)
                        .concat(custDetaildFromParty.getContactDetails().getContactEmailId());
            }
            if (null != custDetaildFromParty.getContactDetails().getContactMobileNum()) {
                if(toAddress == null) {
                	toAddress = new ArrayList<>();
                }
                toAddress.add(custDetaildFromParty.getContactDetails().getContactMobileNum());
            }
        }
        return toList;
    }
    
    public static String getCustomerName(String dealID) {
		String customerName = "";
		try{
			IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(dealID);
			if (null != dealCustomerDetail) {
				customerName = PanelUtils.readPartyDetails(dealCustomerDetail.getF_CUSTOMERID());
			}
		}catch(Exception e) {
			LOG.error("Unable to find the customer details for deal :"+dealID);
		}

        return customerName;
    }
    
    public static List<String> getPartyIds(String dealID) {
    	List<String> partyIds = new ArrayList<>();
    	String DEAL_RELATION_SQL = " WHERE "+ IBOCE_IB_DealRelationshipDetails.IBDEALID +" = ? AND "+IBOCE_IB_DealRelationshipDetails.IBRELATIONSHIPTYPE+" = ?";
    	String notifyRelationshipType = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
    			CeConstants.REPAYMENT_REMINDER_PROPERTY_FILE, "notify", "",
    			CeConstants.ADFIBCONFIGLOCATION);
    	try{
    		for(String relationType : notifyRelationshipType.split(",")) {
    			ArrayList params = new ArrayList<>();
    			params.add(dealID);
    			params.add(relationType);
    			List<IBOCE_IB_DealRelationshipDetails> details = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, DEAL_RELATION_SQL, params, null, true);
    			if(details != null && !details.isEmpty()) {
    				partyIds.add(details.get(0).getF_IBPARTYID());
    			}
    		}
    	}catch(Exception e) {
    		LOG.error("Unable to find the customer details for deal :"+dealID);
    	}
    	
    	return partyIds;
    }
    
    public static void getFeeAccountAndAmount(String dealID, StringBuffer billAccount, StringBuffer billAmount) {
    	String query = "select CEBILLACCT, CEBILLCYCLE, CEBILLAMT, CEBILLVATAMT from CUSTOMEXTN.CETB_BILLINVOICE where CEBILLINVOICENO in (select CEIBFEESPAYMENTINVOICENOPK from CUSTOMEXTN.CE_IBTB_FEESPAYMENTSTATUS where CEIBDEALID = ? ) order by CEBILLGENDATE desc";
    	try {
			Connection con = BankFusionThreadLocal.getPersistanceFactory().getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, dealID);
			ResultSet result = ps.executeQuery();
			if(result!=null && result.next()) {
				billAccount.append(result.getString(1)).append(result.getString(2));
				billAmount.append(String.valueOf(result.getDouble(3)+result.getDouble(4)));
				return;
			}
		} catch (Exception e) {
			LOG.error(e);
		}
    }
    
    public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("customer", "bhaskar");
		map.put("loanaccount", "123456");
		map.put("email", "askldjf@akjsdf.com");
		map.put("telephone", "345346456");
		System.out.println(map.values().toString());
	}

}
