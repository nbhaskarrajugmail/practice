package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ConfigureSearchPage;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.EarlyAssetPayoffCollDtls;
import bf.com.misys.ib.types.EarlyAssetPayoffCollection;
import bf.com.misys.ib.types.EarlyAssetPayoffDtls;
import bf.com.misys.ib.types.IslamicBankingObject;

public class EarlyAssetPayoffUtils {

	private static String earlyAssetPayoffQuery = " WHERE " + IBOCE_IB_EarlyAssetPayoffDtls.IBDEALID + " = ? " + " AND "
			+ IBOCE_IB_EarlyAssetPayoffDtls.IBSTATUS + " = ? ";
	private static String dealAssetDtlsQuery = " WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " =?";

	public static IBOCE_IB_EarlyAssetPayoffDtls getAssetPayoffExistingObjStatusNotCompleted(String dealId,
			boolean isRecallProcess) {

		if (!IBCommonUtils.isValidString(dealId)) {
			return null;
		}
		IBOCE_IB_EarlyAssetPayoffDtls assetPayOffObj = null;
		ArrayList<String> dealStatusList = new ArrayList<>();
		dealStatusList.add(RescheduleConstants.STATUS_COMPLETED);
		dealStatusList.add(IBConstants.DECISION_RETURNED);
		dealStatusList.add(IBConstants.DECISION_REJECTED);
		dealStatusList.add(IBConstants.DECISION_CANCELLED);
		dealStatusList.add(IBConstants.DECISION_REVERSED);

		StringBuffer assetPayoffDetailQuery = new StringBuffer();
		assetPayoffDetailQuery.append(" WHERE " + IBOCE_IB_EarlyAssetPayoffDtls.IBDEALID + " = ? AND "
				+ IBOCE_IB_EarlyAssetPayoffDtls.IBISRECALLACTION + " = ? ");
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);

		if (isRecallProcess)
			params.add("Y");
		else
			params.add("N");

		assetPayoffDetailQuery.append(" AND ");
		assetPayoffDetailQuery.append(IBOCE_IB_EarlyAssetPayoffDtls.IBSTATUS);
		assetPayoffDetailQuery.append(" NOT IN (");

		for (String dealStatus : dealStatusList) {
			assetPayoffDetailQuery.append("?,");
			params.add(dealStatus);
		}
		assetPayoffDetailQuery.replace(assetPayoffDetailQuery.lastIndexOf(","), assetPayoffDetailQuery.length(),
				CommonConstants.EMPTY_STRING);
		assetPayoffDetailQuery.append(")");

		List<IBOCE_IB_EarlyAssetPayoffDtls> assetPayoffDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
				IBOCE_IB_EarlyAssetPayoffDtls.BONAME, assetPayoffDetailQuery.toString(), params, null, false);

		if (assetPayoffDtlsList != null && assetPayoffDtlsList.size() > CommonConstants.INTEGER_ZERO) {
			assetPayOffObj = assetPayoffDtlsList.get(CommonConstants.INTEGER_ZERO);
		}

		return assetPayOffObj;

	}

	public static List<IBOCE_IB_EarlyAssetPayoffDtls> getReschReqExistingObjStatusCompleted(String dealId) {
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		params.add(RescheduleConstants.STATUS_COMPLETED);

		List<IBOCE_IB_EarlyAssetPayoffDtls> assetPayoffDtls = (List) BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_EarlyAssetPayoffDtls.BONAME, earlyAssetPayoffQuery, params, null, false);

		return assetPayoffDtls;
	}

	public static void validateAssetPayoffMultipleRequests(String dealNumber) {

		IBOCE_IB_EarlyAssetPayoffDtls completedAssetPayoffRequest = getAssetPayoffExistingObjStatusNotCompleted(
				dealNumber, false);

		if (completedAssetPayoffRequest != null)
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_EARLY_ASSET_PAYOFF_REQ_ALREADY_EXISTS_ADF_IB);
	}

	public static void validateRecallMultipleRequests(String dealNumber) {

		IBOCE_IB_EarlyAssetPayoffDtls completedAssetPayoffRequest = getAssetPayoffExistingObjStatusNotCompleted(
				dealNumber, true);

		if (completedAssetPayoffRequest != null)
			IBCommonUtils.raiseUnparameterizedEvent(44000364);
	}

	public static void validateArrearDeal(ReadLoanDetailsRs readLoanDetailsRs) {
		boolean isArrear = false;
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getPaymentScheduleCount() > 0) {
			for (LoanPayments loanPayments : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
				if (loanPayments.getRepaymentStatus().equals(CeConstants.REPAYMENT_STATUS_ARREAR))
					isArrear = true;
			}
		}
		if (isArrear)
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_LOAN_ARREAR_STATE_ACTIVITY_NOT_ALLOWED_ADF_IB);
	}

	public static boolean isAssetPayOffProcess(String searchPageId) {
		if (!IBCommonUtils.isNullOrEmpty(searchPageId)) {
			IBOIB_CFG_ConfigureSearchPage searchPageObj = (IBOIB_CFG_ConfigureSearchPage) BankFusionThreadLocal
					.getPersistanceFactory().findByPrimaryKey(IBOIB_CFG_ConfigureSearchPage.BONAME, searchPageId, true);
			if (searchPageObj != null && searchPageObj.getF_ACTION().equals(CeConstants.ASSET_PAYOFF_PAGE_ACTION))
				return true;
		}
		return false;
	}

	public static void validateDealDisbursementAmount(ReadLoanDetailsRs readLoanDetailsRs) {
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getLoanBasicDetails()
				.getTotalDisbursementAmount().compareTo(BigDecimal.ZERO) == 0)
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_HAS_NO_ASSETS_DISBURSED_IB);
	}

	public static String getAssetStatus(String assetId) {
		String assetStatus = CommonConstants.EMPTY_STRING;
		IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetId, true);
		if (assetDetails != null)
			return assetDetails.getF_STATUS();
		return assetStatus;
	}

	public static boolean execRuleForRecallProcess(String dealId) {
		String ruleId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.WRKFLOW_RULES_PROPERTY_FILE, CeConstants.RECALLPRC_WRKFLOWRULE, "",
				CeConstants.ADFIBCONFIGLOCATION);
		String ruleOutput = "";
		RuleExecRsData ruleResponse = IBCommonUtils.getRuleAndExecute(ruleId, dealId);
		if (null != ruleResponse && null != ruleResponse.getRuleData()) {
			List<String> responseList = (List<String>) ruleResponse.getRuleData();
			if (ruleResponse.getRuleType().equals(IBConstants.RULE_TYPE_CONDITION_CONSTANT)
					&& ruleResponse.getRuleData() != null && responseList.size() > CommonConstants.INTEGER_ZERO
					&& responseList.get(CommonConstants.INTEGER_ZERO) != null) {
				ruleOutput = String.valueOf(responseList.get(CommonConstants.INTEGER_ZERO));
				if (ruleOutput.equalsIgnoreCase("true"))
					return true;
			}
		}
		return false;
	}

	public static void validateAssetSelectCount(EarlyAssetPayoffDtls earlyAssetPayoffDtls, String dealId,
			boolean isAssetPayOffProcess, String BBMode) {
		if (!BBMode.equals(IBConstants.VIEWMODE) && isAssetPayOffProcess) {
			int selectedAssetCount = 0;
			int leftoverAssets = validateNoOfAssetsForAssetPayoff(dealId);
			for (EarlyAssetPayoffCollection assetPayoffColl : earlyAssetPayoffDtls.getEarlyAssetPayoffCollection()) {
				if (assetPayoffColl.isSelect())
					++selectedAssetCount;
			}
			if (selectedAssetCount == leftoverAssets) {
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_USE_EARLY_SETTLEMENT_ADF_IB);
			}
			if(selectedAssetCount == 0) {
				IBCommonUtils.raiseUnparameterizedEvent(44000378);
			}
		}
	}

	public static int validateNoOfAssetsForAssetPayoff(String dealId) {
		int noOfAssetsForAssetPayoff = 0;
		ArrayList<String> param = new ArrayList<>();
		param.add(dealId);
		List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = (ArrayList<IBOIB_DLI_DealAssetDtls>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, dealAssetDtlsQuery, param, null, true);
		if (dealAssetDtls != null && !dealAssetDtls.isEmpty()) {
			for (IBOIB_DLI_DealAssetDtls assetDtls : dealAssetDtls) {
				if (!CeConstants.ASSETSTATUS_EARLYPAIDOFF
						.equals(EarlyAssetPayoffUtils.getAssetStatus(assetDtls.getF_ASSETDETAILSID()))
						&& !CeConstants.ASSETSTATUS_RECALL
						.equals(EarlyAssetPayoffUtils.getAssetStatus(assetDtls.getF_ASSETDETAILSID()))
						&& !DealFollowUpUtils.isAssetToBeRecalled(dealId, assetDtls.getF_ASSETDETAILSID()))
					++noOfAssetsForAssetPayoff;
			}
			if (noOfAssetsForAssetPayoff <= 0)
				IBCommonUtils.raiseUnparameterizedEvent(44000365);
		}
		return noOfAssetsForAssetPayoff;
	}

	public static void validateNoOfAssetsForRecall(String dealId) {
		int assetToBeRecalled = 0;
		ArrayList<String> param = new ArrayList<>();
		param.add(dealId);
		List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = (ArrayList<IBOIB_DLI_DealAssetDtls>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, dealAssetDtlsQuery, param, null, true);
		if (dealAssetDtls != null && !dealAssetDtls.isEmpty()) {
			for (IBOIB_DLI_DealAssetDtls assetDtls : dealAssetDtls) {
				if (!CeConstants.ASSETSTATUS_EARLYPAIDOFF
						.equals(EarlyAssetPayoffUtils.getAssetStatus(assetDtls.getF_ASSETDETAILSID()))
						&& !CeConstants.ASSETSTATUS_RECALL
						.equals(EarlyAssetPayoffUtils.getAssetStatus(assetDtls.getF_ASSETDETAILSID()))
						&& DealFollowUpUtils.isAssetToBeRecalled(dealId, assetDtls.getF_ASSETDETAILSID()))
					++assetToBeRecalled;
			}
			if (assetToBeRecalled <= 0)
				IBCommonUtils.raiseUnparameterizedEvent(44000363);
		}
	}

	public static void insertPayrecDetails(EarlyAssetPayoffCollDtls assetPayoffCollDtls,
			IslamicBankingObject islamicBankingObject) {

		// updatePayRecDtlsId
		IBOCE_IB_EarlyAssetPayoffDtls earlyAssetPayoffDtlObj = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
				.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_IB_EarlyAssetPayoffDtls.BONAME, islamicBankingObject.getTransactionID(), true);
		if (earlyAssetPayoffDtlObj != null && !IBCommonUtils.isNullOrEmpty(earlyAssetPayoffDtlObj.getF_IBPAYRECDETAILID())) {
			String whereClauseForPayRecDtl = " WHERE " + IBOIB_TXN_PAYRECDETAIL.PAYRECDETAILID + " = ? ";
			ArrayList<String> params = new ArrayList<>();
			params.add(earlyAssetPayoffDtlObj.getF_IBPAYRECDETAILID());

			IBCommonUtils.getPersistanceFactory().bulkDelete(IBOIB_TXN_PAYRECDETAIL.BONAME, whereClauseForPayRecDtl,
					params);
		}

		String payRecDetailsId = GUIDGen.getNewGUID();
		IBOIB_TXN_PAYRECDETAIL payRecDetailInsert = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
				.getStatelessNewInstance(IBOIB_TXN_PAYRECDETAIL.BONAME);
		payRecDetailInsert.setBoID(payRecDetailsId);
		payRecDetailInsert.setF_ACCOUNTID(assetPayoffCollDtls.getInternalAccountNum());
		payRecDetailInsert.setF_AMOUNTTYPE(CeConstants.PAYMENTAMOUNTTYPE_EARLYASSETPAYOFF);
		payRecDetailInsert.setF_DEALNO(assetPayoffCollDtls.getDealId());
		payRecDetailInsert.setF_EQUIVALENTAMOUNT(assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount());
		payRecDetailInsert.setF_EXCHANGERATE(BigDecimal.ONE);
		payRecDetailInsert.setF_EXCHANGERATETYPE(CommonConstants.EMPTY_STRING);
		payRecDetailInsert.setF_LastMaintainedUser(IBCommonUtils.getUserId());
		payRecDetailInsert.setF_NARRATIVE(assetPayoffCollDtls.getNarrative());
		payRecDetailInsert.setF_OUTSTANDINGAMOUNT(BigDecimal.ZERO);
		payRecDetailInsert.setF_PARENTPAYRECDETAILID(CommonConstants.EMPTY_STRING);
		payRecDetailInsert.setF_PAYMENTMETHOD(assetPayoffCollDtls.getPaymentMethod());
		payRecDetailInsert.setF_STEPID(islamicBankingObject.getStepID());
		payRecDetailInsert.setF_TRANSACTIONAMOUNT(assetPayoffCollDtls.getTotalSubsidyPaid().getCurrencyAmount());
		payRecDetailInsert.setF_TRANSACTIONCURRENCY(islamicBankingObject.getCurrency());
		payRecDetailInsert.setF_TRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
		payRecDetailInsert.setF_TRANSACTIONID(islamicBankingObject.getTransactionID());
		payRecDetailInsert.setF_TRANSACTIONSTATUS(IBConstants.TRANSACTIONSTATUS_SCHEDULED);
		payRecDetailInsert.setF_TRANSACTOINTYPE(IBConstants.TRANSACTIONTYPE_REC);
		payRecDetailInsert.setF_VALUEDTTM(IBCommonUtils.getBFBusinessDateTime());
		IBCommonUtils.getPersistanceFactory().create(IBOIB_TXN_PAYRECDETAIL.BONAME, payRecDetailInsert);

		if (earlyAssetPayoffDtlObj != null) {
			earlyAssetPayoffDtlObj.setF_IBPAYRECDETAILID(payRecDetailsId);
		}
	}

}
