package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AgricultureRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_BuildingDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ExistingRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_NoEvaluationRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PersonalRequestDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ResidentialRquestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TitleDeedDtlsForEvaluation;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TreeDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_WellDetails;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.job.IBFOnlineJob;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CollateralRequestDtlsUtils {

               private static final Log LOGGER = LogFactory.getLog(SadadPaymentUtils.class);
               public static final String COLLATERAL_QUERY= " NOT IN ('RETURN','REJECT','CANCEL','REVERSED')";

               public static List<IBOCE_IB_CollateralRevaluationDetails> readCollateralRequestDtls(IslamicBankingObject ibObj) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

                              StringBuilder whereClause = new StringBuilder(" WHERE CEIBDEALID = ? ");
                                  //AND CEIBSTEPSTATUS NOT IN ('RETURN','REJECT','CANCEL','REVERSED')") ;
                              ArrayList<String> queryParams = new ArrayList<String>();
                              queryParams.add(ibObj.getDealID());
                              if(null != ibObj.getTransactionID() && !ibObj.getTransactionID().equals(ibObj.getDealID())) {
                                  if(!whereClause.toString().contains(ibObj.getTransactionID())) {
                                  whereClause.append("OR "+IBOCE_IB_CollateralRevaluationDetails.IBTRANSACTIONID+" = '"+ ibObj.getTransactionID()+"'");
                              }
                                  }else {
                                  whereClause.append(" AND ("+IBOCE_IB_CollateralRevaluationDetails.IBTRANSACTIONID+" ='' OR "+ IBOCE_IB_CollateralRevaluationDetails.IBTRANSACTIONID + " IS NULL)" );
                              }
                              List<IBOCE_IB_CollateralRevaluationDetails> collateralReqDtls = factory
                                                            .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause.toString(), queryParams, null, true);
                              
                              return collateralReqDtls;
               }

               public static IBOCE_IB_DealRelationshipDetails fetchDealRelationshipDtlByReqId(String requestId) {

                              IBOCE_IB_DealRelationshipDetails dealRelationshipDetails = null;
                              IBOCE_IB_PersonalRequestDtls ib_PersonalRequestDtls = CollateralRequestDtlsUtils
                                                            .readPersonalRequestDtls(requestId);
                              String dealRelationShipDtlsQuery = " WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALRELATIONSHIPDTLID
                                                            + "= ? ";
                              ArrayList<String> paramList = new ArrayList<String>();
                              paramList.add(ib_PersonalRequestDtls.getF_IBRELATIONSIPDTLSID());
                              List<IBOCE_IB_DealRelationshipDetails> resultSet = IBCommonUtils.getPersistanceFactory()
                                                            .findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery, paramList, null, true);

                              if (resultSet != null && !resultSet.isEmpty()) {
                                             dealRelationshipDetails = resultSet.get(0);
                              }
                              return dealRelationshipDetails;

               }
               public static IBOCE_IB_DealRelationshipDetails fetchDealRelationshipDtlByID(String relationshipId) {

                              IBOCE_IB_DealRelationshipDetails dealRelationshipDetails = null;
                              String dealRelationShipDtlsQuery = " WHERE " + IBOCE_IB_DealRelationshipDetails.IBDEALRELATIONSHIPDTLID
                                                            + " = ?";
                              ArrayList<String> paramList = new ArrayList<String>();
                              paramList.add(relationshipId);
                              List<IBOCE_IB_DealRelationshipDetails> resultSet = IBCommonUtils.getPersistanceFactory()
                                                            .findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery, paramList, null, true);

                              if (resultSet != null && !resultSet.isEmpty()) {
                                             dealRelationshipDetails = resultSet.get(0);
                              }
                              return dealRelationshipDetails;

               }

               
               public static IBOCE_IB_PersonalRequestDtls readPersonalRequestDtls(String requestId) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              List<IBOCE_IB_PersonalRequestDtls> completePersonalRqDtls = new ArrayList<IBOCE_IB_PersonalRequestDtls>();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_PersonalRequestDtls> personalReqDtls = new ArrayList<IBOCE_IB_PersonalRequestDtls>();
                              IBOCE_IB_PersonalRequestDtls eachPersonalReqDtl = null;
                              String whereClause = " WHERE CEIBREQUESTID = ?";
                              queryParams.clear();
                              queryParams.add(requestId);

                              personalReqDtls = factory.findByQuery(IBOCE_IB_PersonalRequestDtls.BONAME, whereClause, queryParams, null,
                                                            true);
                              if (personalReqDtls.size() > 0) {
                                             eachPersonalReqDtl = personalReqDtls.get(0);
                              }

                              return eachPersonalReqDtl;
               }

               public static IBOCE_IB_ResidentialRquestDetails readResidentRequestDtls(
                                             IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_ResidentialRquestDetails> residentReqDtls = new ArrayList<IBOCE_IB_ResidentialRquestDetails>();
                              IBOCE_IB_ResidentialRquestDetails eachResidentReqDtl = null;
                              String requestid = eachTitleDeedRqDtls.getF_IBREQUESTID();
                              List<IBOCE_IB_TitleDeedDtlsForEvaluation> titledeeddtls = readTitleDeedDtlsForEvaluation(requestid);
                              String whereClause = " WHERE" + " " + IBOCE_IB_TitleDeedDtlsForEvaluation.IBREQUESTID + " = ?" + " AND "
                                                            + IBOCE_IB_TitleDeedDtlsForEvaluation.IBTITLEDEEDID + " = ?" + " AND "
                                                            + IBOCE_IB_TitleDeedDtlsForEvaluation.IBEVALUATIONID + " = ?";
                              queryParams.clear();
                              queryParams.add(requestid);
                              queryParams.add(eachTitleDeedRqDtls.getF_IBTITLEDEEDID());
                              queryParams.add(eachTitleDeedRqDtls.getF_IBEVALUATIONID());
                              residentReqDtls = factory.findByQuery(IBOCE_IB_ResidentialRquestDetails.BONAME, whereClause, queryParams, null,
                                                            true);
                              if (residentReqDtls.size() > 0) {
                                             eachResidentReqDtl = residentReqDtls.get(0);
                              }
                              return eachResidentReqDtl;
                              
               }

               public static IBOCE_IB_AgricultureRequestDetails readAgricultureRequestDtls(
                                             IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              List<IBOCE_IB_AgricultureRequestDetails> completeAgricultureRqDtls = new ArrayList<IBOCE_IB_AgricultureRequestDetails>();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_AgricultureRequestDetails> agricultureReqDtls = new ArrayList<IBOCE_IB_AgricultureRequestDetails>();
                              IBOCE_IB_AgricultureRequestDetails eachAgricultureReqDtl = null;

                              String requestid = eachTitleDeedRqDtls.getF_IBREQUESTID();

                              List<IBOCE_IB_TitleDeedDtlsForEvaluation> titledeeddtls = readTitleDeedDtlsForEvaluation(requestid);
                              String whereClause = " WHERE" + " " + IBOCE_IB_TitleDeedDtlsForEvaluation.IBREQUESTID + " = ?" + " AND "
                                                            + IBOCE_IB_TitleDeedDtlsForEvaluation.IBTITLEDEEDID + " = ?" + " AND "
                                                            + IBOCE_IB_TitleDeedDtlsForEvaluation.IBEVALUATIONID + " = ?";
                              queryParams.clear();
                              queryParams.add(requestid);
                              queryParams.add(eachTitleDeedRqDtls.getF_IBTITLEDEEDID());
                              queryParams.add(eachTitleDeedRqDtls.getF_IBEVALUATIONID());
                              agricultureReqDtls = factory.findByQuery(IBOCE_IB_AgricultureRequestDetails.BONAME, whereClause, queryParams,
                                                            null, true);
                              if (agricultureReqDtls.size() > 0) {
                                             eachAgricultureReqDtl = agricultureReqDtls.get(0);
                              }

                              return eachAgricultureReqDtl;
               }

               public static List<IBOCE_IB_TitleDeedDtlsForEvaluation> readTitleDeedDtlsForEvaluation(String requestid) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              List<IBOCE_IB_TitleDeedDtlsForEvaluation> completeTitleDeedDtls = new ArrayList<IBOCE_IB_TitleDeedDtlsForEvaluation>();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_TitleDeedDtlsForEvaluation> titleDeedDtls = new ArrayList<IBOCE_IB_TitleDeedDtlsForEvaluation>();
                              IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedDtl = null;
                              String whereClause = " WHERE" + " " + IBOCE_IB_TitleDeedDtlsForEvaluation.IBREQUESTID + " = ?";
                              queryParams.clear();
                              queryParams.add(requestid);
                              

                              titleDeedDtls = factory.findByQuery(IBOCE_IB_TitleDeedDtlsForEvaluation.BONAME, whereClause, queryParams, null,
                                                            true);
                              for(IBOCE_IB_TitleDeedDtlsForEvaluation eachDeed : titleDeedDtls) {
                                  if (titleDeedDtls!=null && titleDeedDtls.size() > 0) {
                                      eachTitleDeedDtl = eachDeed;
                                      completeTitleDeedDtls.add(eachTitleDeedDtl);
                       }
                              }
                              
                              

                              return completeTitleDeedDtls;
               }

               public static List<IBOCE_IB_WellDetails> readWellRequestDtls(IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeed,
                                             String agricultureId) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_WellDetails> wellDetails = new ArrayList<IBOCE_IB_WellDetails>();
                              String whereClause = " WHERE" + " " + IBOCE_IB_WellDetails.IBREQUESTID + " = ?" + " AND "
                                                            + IBOCE_IB_WellDetails.IBTITLEDEEDID + " = ?" + " AND " + IBOCE_IB_WellDetails.IBEVALUATIONID + " = ?";
                                                            
                                                            //+ " AND " + IBOCE_IB_WellDetails.IBAGRICULTUREDTLSID + " = ?";
                              queryParams.clear();
                              queryParams.add(eachTitleDeed.getF_IBREQUESTID());
                              queryParams.add(eachTitleDeed.getF_IBTITLEDEEDID());
                              queryParams.add(eachTitleDeed.getF_IBEVALUATIONID());
                             // queryParams.add(agricultureId);
                              wellDetails = factory.findByQuery(IBOCE_IB_WellDetails.BONAME, whereClause, queryParams, null, true);

                              return wellDetails;
               }

               public static List<IBOCE_IB_BuildingDetails> readBuildingDtls(IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeed,
                                             String agricultureId) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_BuildingDetails> buildingDetails = new ArrayList<IBOCE_IB_BuildingDetails>();
                              String whereClause = " WHERE" + " " + IBOCE_IB_BuildingDetails.IBREQUESTID + " = ?" + " AND "
                                                            + IBOCE_IB_BuildingDetails.IBTITLEDEEDID + " = ?" + " AND " + IBOCE_IB_BuildingDetails.IBEVALUATIONID
                                                            + " = ?"; //+ " AND " + IBOCE_IB_BuildingDetails.IBAGREECULTUREDTLSID + " = ?";
                              queryParams.clear();
                              queryParams.add(eachTitleDeed.getF_IBREQUESTID());
                              queryParams.add(eachTitleDeed.getF_IBTITLEDEEDID());
                              queryParams.add(eachTitleDeed.getF_IBEVALUATIONID());
                              //queryParams.add(agricultureId);
                              buildingDetails = factory.findByQuery(IBOCE_IB_BuildingDetails.BONAME, whereClause, queryParams, null, true);

                              return buildingDetails;
               }

               public static List<IBOCE_IB_TreeDetails> readTreeDtls(IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeed,
                                             String agricultureId) {

                              IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
                              ArrayList<String> queryParams = new ArrayList<String>();
                              List<IBOCE_IB_TreeDetails> treeDetails = new ArrayList<IBOCE_IB_TreeDetails>();
                              String whereClause = " WHERE" + " " + IBOCE_IB_TreeDetails.IBREQUESTID + " = ?" + " AND "
                                                            + IBOCE_IB_TreeDetails.IBTITLEDEEDID + " = ?" + " AND " + IBOCE_IB_TreeDetails.IBEVALUATIONID + " = ?";
                                                     //      + " AND " + IBOCE_IB_TreeDetails.IBAGREECULTUREDTLSID + " = ?";
                              queryParams.clear();
                              queryParams.add(eachTitleDeed.getF_IBREQUESTID());
                              queryParams.add(eachTitleDeed.getF_IBTITLEDEEDID());
                              queryParams.add(eachTitleDeed.getF_IBEVALUATIONID());
                              //queryParams.add(agricultureId);
                              treeDetails = factory.findByQuery(IBOCE_IB_TreeDetails.BONAME, whereClause, queryParams, null, true);

                              return treeDetails;
               }
               
               public static BigDecimal readPersonalRequestAvailableBalance() {
                              
                              String allowedAvailableBalance = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.PERSONAL_REQUEST_CONF_FILE,
                           CeConstants.PERSONAL_REQUEST_AVAILABLE_BALANCE, "", CeConstants.ADFIBCONFIGLOCATION);
                              BigDecimal availableBalance=new BigDecimal(allowedAvailableBalance);
                              
                              return availableBalance;
               }
               
               public static BigDecimal getAvailableBalancePersonal(CollateralRequestDetails collateralReqDtls, String customerID)
    {
        BigDecimal totalCoverValue = new BigDecimal(0);
        BigDecimal balance = new BigDecimal(0);



        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();



        String whereLoanClause = "WHERE "+ IBOLendingFeature.LOANREFERENCE +" = ? ";
        String whereClause = "WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBCUSTOMERID + " = ? AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTTYPE + " = ? AND " + IBOCE_IB_CollateralRevaluationDetails.IBCOLLATERALID + " = ? ";
        
        ArrayList<String> queryParams = new ArrayList<String>();
        queryParams.add(customerID);
        queryParams.add("Personal");
        queryParams.add(collateralReqDtls.getCollateralID());
        List<IBOCE_IB_CollateralRevaluationDetails> collateralDealDtls = factory.findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause, queryParams, null, true);
        if(collateralDealDtls!=null){            
            for (IBOCE_IB_CollateralRevaluationDetails eachCollDtlsFromDB : collateralDealDtls) {            
                String dealID=eachCollDtlsFromDB.getF_IBDEALID();
                ArrayList<String> params = new ArrayList<String>();
                params.add(dealID);        
                List<IBOLendingFeature> lendingFeature = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME, whereLoanClause, params, null, true);            
                if(lendingFeature!=null){
                    for(IBOLendingFeature lendingData: lendingFeature){
                        if(lendingData.getF_REDUCINGPRINCIPAL().compareTo(BigDecimal.ZERO)==1){
                            List<IBOCE_IB_CollateralRevaluationDetails> collateralDtls = factory.findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause, queryParams, null, true);
                            if(collateralDtls!=null){            
                                for (IBOCE_IB_CollateralRevaluationDetails CollDtlsFromDB : collateralDealDtls) {                                                
                                    totalCoverValue= totalCoverValue.add(CollDtlsFromDB.getF_IBCOVERVALUE());
                                }
                            }
                        }
                    }
                }    
            }
            BigDecimal availableBalance = CollateralRequestDtlsUtils.readPersonalRequestAvailableBalance();
            balance = availableBalance.subtract(totalCoverValue);
        }
        return balance;
    }
}
