package com.ce.bankfusion.ib.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;

public class AssetProgressUtil {
	
	private static final Log LOGGER = LogFactory.getLog(AssetProgressUtil.class);
	private static String REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBDEALNO+" = ?";
	private static String GET_ASSETPROGRESS_BY_REPORT = " WHERE "+IBOCE_IB_AssetProgressDtl.IBREPORTID+" = ?";
	private static String GET_ASSETPROGRESS_BY_REPORT_ASSET = " WHERE "+IBOCE_IB_AssetProgressDtl.IBREPORTID+" = ? AND "+IBOCE_IB_AssetProgressDtl.IBASSETID+"=? ORDER BY ";
	
	public static AssetProgressReportDetails getAssetReportDetails(String dealID, String currency){
		AssetProgressReportDetails assetProgressReportDetails = new AssetProgressReportDetails();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, REPORTS_BY_DEAL_QUERY, params, null, true);
		for(IBOCE_IB_AssetProgressReport report : assetProgressReportList) {
			AssetProgressReport assetProgressReport = new AssetProgressReport();
			assetProgressReport.setReportID(report.getF_IBREPORTID());
			assetProgressReport.setDealID(report.getF_IBDEALNO());
			assetProgressReport.setCoordinateMatch(report.isF_IBISCOORDINATESMATCH());
			assetProgressReport.setInspectorName(report.getF_IBINSPECTOR());
			assetProgressReport.setReviewerName(report.getF_IBREVIEWER());
			assetProgressReport.setProgressVisitDateG(report.getF_IBVISITDATEG());
			assetProgressReport.setProgressVisitDateH(report.getF_IBVISITDATEH());
			assetProgressReport.setReportNotes(report.getF_IBNOTES());
			assetProgressReport.setDisbursementNumber(report.getF_IBDISBURSEMENTNO());
			assetProgressReport.setTotalProgressPercentage(report.getF_IBTOTALPROGRESSPERCENT());
			assetProgressReport.setLastDisbursement(report.isF_IBISLASTDISBURSED());
			assetProgressReport.setProgressVisitDone(report.isF_IBISVISITDONE());
			assetProgressReport.setReportStatus(report.getF_IBSTATUS());
			BFCurrencyAmount amount = new BFCurrencyAmount();
			amount.setCurrencyAmount(report.getF_IBTOTALDISBURSEDAMT());
			amount.setCurrencyCode(currency);
			assetProgressReport.setTotalDisbursementAmount(amount);
			assetProgressReportDetails.addAssetProgressReportList(assetProgressReport);
		}
		return assetProgressReportDetails;
	}
	
	public static AssetProgressReportDetails getAssetProgressDetails(String reportID, String currency){
		AssetProgressReportDetails assetProgressReportDetails = new AssetProgressReportDetails();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(reportID);
		List<IBOCE_IB_AssetProgressDtl> assetProgressList = factory.findByQuery(IBOCE_IB_AssetProgressDtl.BONAME, GET_ASSETPROGRESS_BY_REPORT, params, null, true);
		for(IBOCE_IB_AssetProgressDtl progressDtl : assetProgressList) {
			AssetProgressDetails assetProgressDtl = new AssetProgressDetails();
			assetProgressDtl.setReportID(progressDtl.getF_IBREPORTID());
			assetProgressDtl.setAssetID(progressDtl.getF_IBASSETID());
			assetProgressDtl.setInvoiceRequired(progressDtl.isF_IBISINVOICE());
			BFCurrencyAmount invoiceamount = new BFCurrencyAmount();
			invoiceamount.setCurrencyAmount(progressDtl.getF_IBINVOICEAMT());
			invoiceamount.setCurrencyCode(currency);
			assetProgressDtl.setInvoiceAmount(invoiceamount);
			assetProgressDtl.setInvoiceCompletionPercentage(progressDtl.getF_IBCOMPLETIONPERCENT());
			assetProgressDtl.setPriceListNumber(progressDtl.getF_IBPRICELISTNO());
			assetProgressDtl.setPriceListYear(progressDtl.getF_IBPRICELISTYEAR());
			assetProgressDtl.setMachineNumber(progressDtl.getF_IBMACHINENO());
			assetProgressDtl.setMachineType(progressDtl.getF_IBMACHINETYPE());
			assetProgressDtl.setAttribute7(progressDtl.getF_IBATTR7());
			assetProgressDtl.setAttribute8(progressDtl.getF_IBATTR8());
			assetProgressDtl.setAttribute9(progressDtl.getF_IBATTR9());
			BFCurrencyAmount calculatedCost = new BFCurrencyAmount();
			calculatedCost.setCurrencyAmount(progressDtl.getF_IBACCUMULATEDCALCCOST());
			calculatedCost.setCurrencyCode(currency);
			assetProgressDtl.setAccumulatedCalculatedCost(calculatedCost);
			BFCurrencyAmount finalCost = new BFCurrencyAmount();
			finalCost.setCurrencyAmount(progressDtl.getF_IBACCUMULATEDFINALCOST());
			finalCost.setCurrencyCode(currency);
			assetProgressDtl.setAccumulatedFinalCost(finalCost);
			
			
			assetProgressDtl.setAssetNotes(progressDtl.getF_IBADDITIONALNOTES());
			assetProgressDtl.setNorthCoordinate(progressDtl.getF_IBNORTHCOORDINATE());
			assetProgressDtl.setNorthCoordinateO(progressDtl.getF_IBNORTHCOORDINATEO());
			assetProgressDtl.setEastCoordinate(progressDtl.getF_IBEASTCOORDINATE());
			assetProgressDtl.setEastCoordinateO(progressDtl.getF_IBEASTCOORDINATEO());
			assetProgressDtl.setBoatMachineNumber(progressDtl.getF_IBADDNLNUMBER());
			assetProgressDtl.setBoatMachineName(progressDtl.getF_IBADDNLNAME());
			assetProgressDtl.setBoatSerialNumber(progressDtl.getF_IBADDNLSERIALNO());
			assetProgressReportDetails.addAssetProgressDetailsList(assetProgressDtl);
		}
		return assetProgressReportDetails;
	}

	public static Map<String,BigDecimal> getPreviousReportsCosts(AssetProgressReport[] assetProgressReportList,
			String assetID) {
		Map<String, BigDecimal> costMap = new HashMap<String, BigDecimal>();
		costMap.put("CALCULATEDCOST", BigDecimal.ZERO);
		costMap.put("FINALCOST", BigDecimal.ZERO);
		costMap.put("ALLOWEDFINALCOST", BigDecimal.ZERO);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		for (int i = assetProgressReportList.length; i >=1 ; --i) {
			AssetProgressReport assetProgressReport = assetProgressReportList[i-1];

			if (!assetProgressReport.getReportStatus().equals("New")) {
				ArrayList<String> params = new ArrayList<>();
				params.add(assetProgressReport.getReportID());
				List<IBOCE_IB_AssetProgressDtl> assetProgressList = factory
						.findByQuery(IBOCE_IB_AssetProgressDtl.BONAME, GET_ASSETPROGRESS_BY_REPORT, params, null, true);
				for (IBOCE_IB_AssetProgressDtl progressDtl : assetProgressList) {
					if (progressDtl.getF_IBASSETID().equals(assetID)) {
						costMap.put("CALCULATEDCOST",
								costMap.get("CALCULATEDCOST").add(progressDtl.getF_IBACCUMULATEDCALCCOST()));
						costMap.put("FINALCOST",
								costMap.get("FINALCOST").add(progressDtl.getF_IBACCUMULATEDFINALCOST()));
						costMap.put("ALLOWEDFINALCOST",
								costMap.get("ALLOWEDFINALCOST").add(progressDtl.getF_IBALLOWEDFINALCOST()));
					}
				}
			}
			if(costMap.get("FINALCOST").compareTo(BigDecimal.ZERO)>CommonConstants.INTEGER_ZERO)
				break;
			
		}
		//for (AssetProgressReport assetProgressReport : assetProgressReportList) {}
		return costMap;
	}
	
	public static void getValidateStudyValues(AssetProgressReportDetails assetProgressReportDetails, String assetID,
			BigDecimal attribute7, BigDecimal attribute8, BigDecimal attribute9, BigDecimal studyAttribute7,
			BigDecimal studyAttribute8, BigDecimal studyAttribute9) {

		BigDecimal attr7 = BigDecimal.ZERO;
		BigDecimal attr8 = BigDecimal.ZERO;
		BigDecimal attr9 = BigDecimal.ZERO;

		/*if ((attribute7.compareTo(studyAttribute7) > CommonConstants.INTEGER_ZERO)
				|| (attribute8.compareTo(studyAttribute8) > CommonConstants.INTEGER_ZERO)
				|| (attribute9.compareTo(studyAttribute9) > CommonConstants.INTEGER_ZERO)) {
			IBCommonUtils.raiseUnparameterizedEvent(44000421);
		}*/

		if (assetProgressReportDetails.getAssetProgressReportList() != null
				&& assetProgressReportDetails.getAssetProgressReportList().length > CommonConstants.INTEGER_ZERO) {
			int disbursementNumber = assetProgressReportDetails.getAssetProgressReportList().length;
			for (AssetProgressReport assetProgressReport : assetProgressReportDetails.getAssetProgressReportList()) {
				if (assetProgressReport.getDisbursementNumber() == disbursementNumber) {
					IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
					ArrayList<String> params = new ArrayList<>();
					params.add(assetProgressReport.getReportID());
					params.add(assetID);
					String GET_ASSETPROGRESS_BY_REPORT_ASSET = " WHERE " + IBOCE_IB_AssetProgressDtl.IBREPORTID
							+ " = ? AND " + IBOCE_IB_AssetProgressDtl.IBASSETID + "=?";
					List<IBOCE_IB_AssetProgressDtl> assetProgressList = factory.findByQuery(
							IBOCE_IB_AssetProgressDtl.BONAME, GET_ASSETPROGRESS_BY_REPORT_ASSET, params, null, true);
					if (assetProgressList != null && !assetProgressList.isEmpty()) {
						for (IBOCE_IB_AssetProgressDtl progressDtl : assetProgressList) {
							if(progressDtl.getF_IBATTR7()!=null)
								attr7 = progressDtl.getF_IBATTR7();
							if(progressDtl.getF_IBATTR8()!=null)
								attr8 = progressDtl.getF_IBATTR8();
							if(progressDtl.getF_IBATTR9()!=null)
								attr9 = progressDtl.getF_IBATTR9();
						}
					}
				}
			}
			if((attribute7.compareTo(studyAttribute7) == CommonConstants.INTEGER_ZERO)
					|| (attribute8.compareTo(studyAttribute8)== CommonConstants.INTEGER_ZERO)
					|| (attribute9.compareTo(studyAttribute9) == CommonConstants.INTEGER_ZERO)) {
				System.out.println("Last progress report");
				
			}
			else if ((attribute7.compareTo(attr7) < CommonConstants.INTEGER_ZERO)
					|| (attribute8.compareTo(attr8) < CommonConstants.INTEGER_ZERO)
					|| (attribute9.compareTo(attr9) < CommonConstants.INTEGER_ZERO)) {
				IBCommonUtils.raiseUnparameterizedEvent(44000423);
			}
		}
	}
}
