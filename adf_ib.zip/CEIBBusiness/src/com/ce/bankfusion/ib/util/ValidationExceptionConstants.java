package com.ce.bankfusion.ib.util;

public class ValidationExceptionConstants {
	
	public static final String STATUS_APPROVED = "APPROVED";
    public static final String STATUS_INTERMEDIARY_APPROVAL = "APPROVAL";
    public static final String STATUS_INTERMEDIARY_REJECTION = "REJECTION";
    public static final String STATUS_REJECTED = "REJECTED";
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_NEW = "NEW";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_APPROVAL = "APPROVAL";
    public static final String ACTION_WARNING_NOTE = "NOTE";
    public static final String VALIDATION_CACHE_KEY = "VALIDATION_LIST";
    public static final String VALIDATION_CACHE_TYPE = "CUSTIB";
    public static final String VALIDATION_WARNING_PROCESSED = "PROCESSED";
    public static final String DEAL_VAL_EXCP_BB_ID = "VALIDATIONEXCEPTIONS";
    public static final String SYSTEM_NOTE_CONTEXT = "Validation";
    public static final String CI_VALIDATION_CONF_ID = "CONTEXT_ID_VALIDATION_CONF_ID";
    public static final String CI_ORIG_USER = "CONTEXT_ID_ORIG_USER_ID";
    
    public static final String PROPERTIES_FILE = "conf/business/validationException.properties";
    public static final String APPROVAL_PROCESSCONFIGID = "approvalProcessConfigID";
    public static final String APPROVAL_SEARCHPAGEID = "approvalSearchPageID";
    
    
    public static final String NORMAL_LOAN_PROCESS = "normalLoanProcess";
    public static final String NORMAL_LOAN_ORIGINATION_PROCESS = "normalLoanOriginationProcess";
    
    public static final String NORMAL_LOAN_TYPE = "normalLoan";
    public static final String SPECIAL_LOAN_TYPE = "specialLoan";
    
    public static final String ASSET_CATEGORY_ID = "parentCategoryID";
    public static final String PORTAL_STATUS = "portalStatus";
   
    /*
     * warning processing event - parameterized
     */
    public static final Integer W_VALIDATION_WARNING_EVENT = 44000316;
    /*
     * stop processing event - parameterized
     */
    public static final Integer E_VALIDATION_STOP_EVENT = 44000317;
    /*
     * Approver mandatory for action type Approval
     */
    public static final Integer E_APPROVER_MANDATORY = 44000318;
    /*
     * Duplicate entry not allowed for the combination of Validation, Process and Step.
     */
    public static final Integer E_DUPLICATE_VALIDATION_CONF = 44000319;
    /*
     * New row is already present
     */
    public static final Integer E_NEW_ROW_PRESENT = 44000320;
    /*
     * All validation exceptions needs to be actioned
     */
    public static final Integer E_ALL_VALEXCP_NOT_ACTIONED = 44000321;
    /*
     * Validation implementation class loading failed for the validation id {}. 
     */
    public static final Integer E_VALIDATION_LOADING_FAILED = 44000322;
    /*
     * Validation processing failed for the validation id {}.
     */
    public static final Integer E_VALIDATION_PROCESSING_FAILED = 44000323; 
    
    public static final Integer I_CONFIG_REMOVED = 35100139;
    public static final Integer I_CONFIG_SAVED = 35100137;
    public static final Integer I_CONFIG_AMENDED = 35100011;
}
