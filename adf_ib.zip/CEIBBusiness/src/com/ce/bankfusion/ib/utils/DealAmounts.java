package com.ce.bankfusion.ib.utils;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;

public class DealAmounts {

	private BFCurrencyAmount dueAmount;

	private BFCurrencyAmount remainingAmount;

	public BFCurrencyAmount getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(BFCurrencyAmount dueAmount) {
		this.dueAmount = dueAmount;
	}

	public BFCurrencyAmount getRemainingAmount() {
		return remainingAmount;
	}

	public void setRemainingAmount(BFCurrencyAmount remainingAmount) {
		this.remainingAmount = remainingAmount;
	}
}