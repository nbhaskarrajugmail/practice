package com.ce.bankfusion.ib.utils;

import java.math.BigDecimal;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;

public class ADFUtils {
	public static DealAmounts getDealAmounts(String dealId) {
		System.err.println();
		DealAmounts dealAmounts = new DealAmounts();
		BigDecimal dueAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal remainingAmount = CommonConstants.BIGDECIMAL_ZERO;
		BFCurrencyAmount bfDueAmount = new BFCurrencyAmount();
		bfDueAmount.setCurrencyAmount(dueAmount);
		BFCurrencyAmount bfRemainingAmount = new BFCurrencyAmount();
		bfRemainingAmount.setCurrencyAmount(remainingAmount);
		ReadLoanDetailsRs readLoanRs = null;
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
									row.getRepaymentDate())) {
						bf.com.misys.ib.spi.types.PaymentSchedule paymentSchedule = new bf.com.misys.ib.spi.types.PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						dueAmount = dueAmount.add(paymentSchedule.getRepaymentAmt());

					} else {
						bf.com.misys.ib.spi.types.PaymentSchedule paymentSchedule = new bf.com.misys.ib.spi.types.PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						remainingAmount = remainingAmount.add(paymentSchedule.getRepaymentAmt());

					}
				}
				bfDueAmount.setCurrencyAmount(dueAmount);
				bfRemainingAmount.setCurrencyAmount(remainingAmount);

			}

		}
		dealAmounts.setDueAmount(bfDueAmount);
		dealAmounts.setRemainingAmount(bfRemainingAmount);
		return dealAmounts;
	}
}
