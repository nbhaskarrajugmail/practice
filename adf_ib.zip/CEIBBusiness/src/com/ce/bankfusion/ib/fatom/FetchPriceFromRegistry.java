/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FetchPriceFromRegistry;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetRegistryDtl;
import bf.com.misys.ib.types.AssetRegistryList;

/**
 * @author Aklesh
 *
 */
public class FetchPriceFromRegistry extends AbstractCE_IB_FetchPriceFromRegistry {

	private static final long serialVersionUID = 7137308733675905581L;
	private transient final static Log LOGGER = LogFactory.getLog(FetchPriceFromRegistry.class.getName());

	public FetchPriceFromRegistry(BankFusionEnvironment env) {
		super(env);

	}

	public FetchPriceFromRegistry() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		getF_IN_pricingListAssetCfg();

		String query = " WHERE " + IBOCE_IB_RegistryAssetCfg.IBASSETCATEGORY + " = ? AND "
				+ IBOCE_IB_RegistryAssetCfg.IBMACHINETYPE + "=? AND " 
				+ IBOCE_IB_RegistryAssetCfg.IBVENDORID + "=?";
		ArrayList params = new ArrayList();

		params.add(getF_IN_pricingListAssetCfg().getAssetCategory().getCategory());
		params.add(getF_IN_pricingListAssetCfg().getMachineType());
		//params.add(getF_IN_pricingListAssetCfg().getModel());
		params.add(getF_IN_pricingListAssetCfg().getMachineNumber());// This will be used to pass VenderID since this is
																	// not part of the object used

		if (getF_IN_pricingListAssetCfg().getAttribute1() != null
				&& getF_IN_pricingListAssetCfg().getAttribute1() != 0) {
			query = query + " AND " + IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE1 + " <=? ";
			params.add(getF_IN_pricingListAssetCfg().getAttribute1());
			LOGGER.info("Attribute9 : " + getF_IN_pricingListAssetCfg().getAttribute1());
		}
		if (getF_IN_pricingListAssetCfg().getAttribute2() != null
				&& getF_IN_pricingListAssetCfg().getAttribute2() != 0) {
			query = query + " AND " + IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE2 + " <=? ";
			params.add(getF_IN_pricingListAssetCfg().getAttribute2());
			LOGGER.info("Attribute7 : " + getF_IN_pricingListAssetCfg().getAttribute2());
		}
		if (getF_IN_pricingListAssetCfg().getAttribute3() != null
				&& getF_IN_pricingListAssetCfg().getAttribute3() != 0) {
			query = query + " AND " + IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE3 + " <=? ";
			params.add(getF_IN_pricingListAssetCfg().getAttribute3());
			LOGGER.info("Attribute8 : " + getF_IN_pricingListAssetCfg().getAttribute3());
		}

		LOGGER.info("Query for matching the asset registries :" + query);
		List<IBOCE_IB_RegistryAssetCfg> registryAssetConfigList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_RegistryAssetCfg.BONAME, query, params, null, false);
		getF_OUT_assetRegistryList().removeAllAssetRegistryList();
		if (registryAssetConfigList != null && registryAssetConfigList.size() > CommonConstants.INTEGER_ZERO) {
			if (registryAssetConfigList.size() == CommonConstants.INTEGER_ONE) {
				IBOCE_IB_RegistryAssetCfg registryAssetConfig = registryAssetConfigList.get(0);
				BFCurrencyAmount price = new BFCurrencyAmount();
				price.setCurrencyAmount(IBCommonUtils.scaleAmount("SAR", registryAssetConfig.getF_IBPRICE()));
				price.setCurrencyCode("SAR");
				getF_OUT_pricingListAssetCfg().setPrice(price);
				getF_OUT_pricingListAssetCfg().setRegistryId(registryAssetConfig.getF_IBREGISTRYID());
				getF_OUT_pricingListAssetCfg().setModel(registryAssetConfig.getF_IBMODEL());
			} else {
				AssetRegistryList assetRegistryList = new AssetRegistryList();
				for(IBOCE_IB_RegistryAssetCfg assetCfg:registryAssetConfigList) {
					AssetRegistryDtl assetRegistryDtl=new AssetRegistryDtl();
					BFCurrencyAmount price = new BFCurrencyAmount();
					price.setCurrencyAmount(assetCfg.getF_IBPRICE());
					price.setCurrencyCode("SAR");
					assetRegistryDtl.setAssetSerial(assetCfg.getBoID());
					assetRegistryDtl.setModel(assetCfg.getF_IBMODEL());
					assetRegistryDtl.setPrice(price);
					assetRegistryDtl.setVendorId(assetCfg.getF_IBVENDORID());
					assetRegistryDtl.setVendorName(assetCfg.getF_IBVENDORNAME());
					assetRegistryDtl.setRegistryID(assetCfg.getF_IBREGISTRYID());
					assetRegistryDtl.setRegistrySerial(assetCfg.getBoID());
					assetRegistryDtl.setSelect(false);
					assetRegistryList.addAssetRegistryList(assetRegistryDtl);
				}
				setF_OUT_assetRegistryList(assetRegistryList);
			}
		}

	}

}
