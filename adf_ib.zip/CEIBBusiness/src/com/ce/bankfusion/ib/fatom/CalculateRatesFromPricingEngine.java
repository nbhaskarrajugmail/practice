package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateRatesFromPricingEngine;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetThirdPartyDetails;

public class CalculateRatesFromPricingEngine extends AbstractCE_IB_CalculateRatesFromPricingEngine {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(CalculateRatesFromPricingEngine.class);

	public CalculateRatesFromPricingEngine(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		String v_dealno = getF_IN_islamicBankingObject().getDealID();
		AssetThirdPartyDetails assetThirdPartyDetails = getF_IN_assetThirdPartyDetails();
		String v_toolno = assetThirdPartyDetails.getToolNO().toString();
		String v_grp_cd = assetThirdPartyDetails.getGroupCD().toString();
		String v_var1 = assetThirdPartyDetails.getAttribute1().toString();
		String v_var2 = assetThirdPartyDetails.getAttribute2().toString();
		String v_var3 = assetThirdPartyDetails.getAttribute3().toString();
		String v_var4 = assetThirdPartyDetails.getAttribute4().toString();
		String v_var5 = assetThirdPartyDetails.getAttribute5().toString();
		IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME,
						assetThirdPartyDetails.getAssetCategory().getCategory(), true);
		String v_cur_listser = assetCategory.getF_CATEGORYNAME();
		String v_bld = "0";
		String v_prjtyp = "0";
		String v_stdy_ach_flg = "1";
		if(getF_IN_studyAchFlag()!=null) {
			v_stdy_ach_flg = String.valueOf(getF_IN_studyAchFlag());
		}
		try {
			switch (v_grp_cd) {
			case "0":
				// return v_res1 out number , v_res2 out number , v_res3 out number ,
				// v_res4 out number, okval out boolean , msg out varchar2
				String spResponse1 = ADFTechGrantAssetUtils.prepareSP2(v_toolno, v_grp_cd, v_var1, v_var2, v_var3,
						v_var4, v_var5, v_cur_listser, v_prjtyp, v_stdy_ach_flg, v_dealno);
				;
				setF_OUT_assetThirdPartyDetails(setOutputParameters(spResponse1));
				break;
			// 46
			case "46":

				// return v_res1 out number , v_res2 out number , v_res3 out number ,
				// v_res4 out number, okval out boolean , msg out varchar2
				String spResponse2 = ADFTechGrantAssetUtils.prepareSP2(v_toolno, v_grp_cd, v_var1, v_var2, v_var3,
						v_var4, v_var5, v_cur_listser, v_bld, v_stdy_ach_flg, v_dealno);
				setF_OUT_assetThirdPartyDetails(setOutputParameters(spResponse2));
				break;
			// 21,25,26,35,40
			case "21":
			case "25":
			case "26":
			case "35":
			case "40":
				// return v_res1 out number , v_res2 out number , v_res3 out number ,
				// v_res4 out number, v_txt_res out varchar2, okval out boolean, msg out
				// varchar2
				String spResponse4 = ADFTechGrantAssetUtils.prepareSP4(v_toolno, v_grp_cd, v_var1, v_var2, v_var3,
						v_var4, v_var5, v_cur_listser, v_stdy_ach_flg, v_dealno);
				setF_OUT_assetThirdPartyDetails(setOutputParameters(spResponse4));
				break;
			case "29":
				// return v_res1 out number , v_res2 out number , v_res3 out number ,
				// v_res4 out number, v_txt_res out varchar2, okval out boolean, msg out
				// varchar2
				String spResponse5 = ADFTechGrantAssetUtils.prepareSP1(v_toolno, v_grp_cd, v_var1, v_var2, v_var3,
						v_var4, v_var5, v_cur_listser, v_stdy_ach_flg, v_dealno);
				setF_OUT_assetThirdPartyDetails(setOutputParameters(spResponse5));
				break;
			// Missing in Seq 11,14,16,22,23,24,27,30,36,54
			// for others
			/*
			 * case "1": case "2": case "3": case "4": case "5": case "6": case "7": case
			 * "8": case "9": case "10": case "12": case "13": case "15": case "17": case
			 * "18": case "19": case "20": case "28": case "29": case "31": case "32": case
			 * "33": case "34": case "37": case "38": case "39": case "41": case "42": case
			 * "43": case "44": case "45": case "47": case "48": case "49": case "50": case
			 * "51": case "52": case "53": case "55": case "56":
			 */
			default:
				// return v_res1 out number , v_res2 out number ,v_res3 out number,
				// v_res4 out number, okval out boolean , msg out varchar2
				String spResponse3 = ADFTechGrantAssetUtils.prepareSP3(v_toolno, v_grp_cd, v_var1, v_var2, v_var3,
						v_var4, v_var5, v_cur_listser, v_stdy_ach_flg, v_dealno);
				setF_OUT_assetThirdPartyDetails(setOutputParameters(spResponse3));
				break;

			}
		} catch (Exception exception) {
			setF_OUT_errorRes(exception.getLocalizedMessage());
			setF_OUT_okValue(false);
			LOGGER.error(exception.getLocalizedMessage());
		}
		// ADFTechGrantAssetUtils.removeGrantApprovalCalculated(dealNo, assetSelected);

	}

	private AssetThirdPartyDetails setOutputParameters(String spResponse) {
		String spResponseValues[] = spResponse.split("\\|");
		String attribute6 = spResponseValues[0];
		String attribute7 = spResponseValues[1];
		String attribute8 = spResponseValues[2];
		String attribute9 = spResponseValues[3];
		String okValue = spResponseValues.length == 5 ? spResponseValues[4] : "t";

		if (attribute6.equals("") || attribute6.equals("null"))
			attribute6 = "0";
		if (attribute7.equals("") || attribute7.equals("null"))
			attribute7 = "0";
		if (attribute8.equals("") || attribute8.equals("null"))
			attribute8 = "0";
		if (attribute9.equals("") || attribute9.equals("null"))
			attribute9 = "0";

		AssetThirdPartyDetails assetThirdPartyDetails = getF_IN_assetThirdPartyDetails();
		assetThirdPartyDetails.setAttribute6(new BigDecimal(attribute6));
		assetThirdPartyDetails.setAttribute7(new BigDecimal(attribute7));
		assetThirdPartyDetails.setAttribute8(new BigDecimal(attribute8));
		assetThirdPartyDetails.setAttribute9(new BigDecimal(attribute9));
		BFCurrencyAmount assetStudyCost = new BFCurrencyAmount();
		assetStudyCost.setCurrencyAmount(new BigDecimal(attribute6));
		assetThirdPartyDetails.setAssetStudyCost(assetStudyCost);
		assetThirdPartyDetails.setDisplayCost(assetStudyCost);
		if (okValue.equals("f") && spResponseValues.length == 6) {
			String errorRes = spResponseValues[5];
			setF_OUT_errorRes(errorRes);
		}
		setF_OUT_okValue(okValue.equals("f") ? false : true);
		return assetThirdPartyDetails;
	}
}
