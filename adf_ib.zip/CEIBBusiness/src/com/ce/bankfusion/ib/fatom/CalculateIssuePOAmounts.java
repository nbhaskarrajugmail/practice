/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateIssuePOAmounts;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_FeesConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.fatom.LoadFeesToCollect;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.FeeToBeCollected;
import bf.com.misys.ib.types.FeeToBeCollectedList;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PaymentDetails;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;

/**
 * @author Aklesh
 *
 */
public class CalculateIssuePOAmounts extends AbstractCE_IB_CalculateIssuePOAmounts {

	private static final long serialVersionUID = 7137308733675905581L;

	public CalculateIssuePOAmounts(BankFusionEnvironment env) {
		super(env);
	}

	public CalculateIssuePOAmounts() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
		        .getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
		BigDecimal calculatedAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal oustandingAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal initialFeesTaxAmount=CommonConstants.BIGDECIMAL_ZERO;
    BigDecimal adjustmentFeesTaxAmount=CommonConstants.BIGDECIMAL_ZERO;

		IssuePayOrderDtls issuePayOrderDtls = getF_IN_issuePayOrderDtls();
		System.err.println();
    if(null !=getF_IN_purchaseOrderDetails().getFeesToBePaid()){
        initialFeesTaxAmount=CeUtils.calculateTaxOnFees(getF_IN_purchaseOrderDetails().getFeesToBePaid(),CeConstants.INITIAL_FEES_TAX_PERC);
    }
    if(null !=getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid()) {
        adjustmentFeesTaxAmount=CeUtils.calculateTaxOnFees(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid(),CeConstants.ADJUSTMENT_FEES_TAX_PERC);  
    }
		if (getF_IN_mode().equals("SAVEPAYAMOUNT")) {
			for (PaymentDetails paymentDetails : issuePayOrderDtls.getPaymentDetails()) {
				if (!paymentDetails.isSelect()) {
					calculatedAmount = calculatedAmount.add(paymentDetails.getPaymentAmount().getCurrencyAmount());
				}
			}
			calculatedAmount = calculatedAmount.add(getF_IN_amountToBeAdded().getCurrencyAmount());
			if(getF_IN_purchaseOrderDetails().getFinalDisbursementAmount().getCurrencyAmount().compareTo(calculatedAmount)<CommonConstants.INTEGER_ZERO) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000399);
				businessEventsService.handleEvent(raiseEvent);
			}
			if (getF_IN_paymentDetails().getPaymentOption().equals("Third Party") && (getF_IN_paymentDetails().getInvoiceNumber().equals(CommonConstants.EMPTY_STRING)
					|| (getF_IN_paymentDetails().getInvoiceDate()==null||new Date(0).compareTo(getF_IN_paymentDetails().getInvoiceDate())==0))) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000411);
				businessEventsService.handleEvent(raiseEvent);
			}
		}
		if (getF_IN_mode().equals("FINALAMOUNT")) {
			if(getF_IN_purchaseOrderDetails().getFinalDisbursementAmount().getCurrencyAmount().compareTo(CommonConstants.BIGDECIMAL_ZERO)<CommonConstants.INTEGER_ZERO) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000398);
				businessEventsService.handleEvent(raiseEvent);
			}
			for(PaymentDetails paymentDetails:issuePayOrderDtls.getPaymentDetails()) {
				if(!paymentDetails.isSelect())
					calculatedAmount = calculatedAmount.add(paymentDetails.getPaymentAmount().getCurrencyAmount());
			}
			calculatedAmount = getF_IN_purchaseOrderDetails().getFinalDisbursementAmount().getCurrencyAmount().subtract(calculatedAmount);
		}
		if (getF_IN_mode().equals("POAMOUNT")) {
			for (PoAssetDisbursementDetails assets : issuePayOrderDtls.getPoAssetDisbursementDetails()) {
				if (!assets.getSelect()) {
					calculatedAmount = calculatedAmount.add(assets.getCurrentDisbursedAmount().getCurrencyAmount());
				} 
				if (assets.getSelect() && (assets.getOriginalFinalCost().getCurrencyAmount().compareTo(
						getF_IN_amountToBeAdded().getCurrencyAmount().add(assets.getPrevouslyDisbursedAmount()
								.getCurrencyAmount())) < CommonConstants.INTEGER_ZERO)) {
					Event raiseEvent = new Event();
					raiseEvent.setEventNumber(44000393);
					businessEventsService.handleEvent(raiseEvent);
				}
			
			}
			calculatedAmount = calculatedAmount.add(getF_IN_amountToBeAdded().getCurrencyAmount());
	
		 oustandingAmount = calculatedAmount
					.subtract(getF_IN_purchaseOrderDetails().getLiabilityToBePaid().getCurrencyAmount())
					.subtract(getF_IN_purchaseOrderDetails().getTawarooqCommision())
					.subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())
					.subtract(initialFeesTaxAmount)
					.subtract(adjustmentFeesTaxAmount);
		}
		if (getF_IN_mode().equals("LIABILITY")) {
			for (CustomerLiabilities customerLiabilities : issuePayOrderDtls.getCustomerLiabilitiesDtls()) {
				if (!customerLiabilities.getSelect()) {
					calculatedAmount = calculatedAmount
							.add(customerLiabilities.getLiabilityToBePaid().getCurrencyAmount());
				} else if (customerLiabilities.getLiabilityAmount().getCurrencyAmount()
						.compareTo(getF_IN_amountToBeAdded().getCurrencyAmount()) < CommonConstants.INTEGER_ZERO) {
					Event raiseEvent = new Event();
					raiseEvent.setEventNumber(44000394);
					businessEventsService.handleEvent(raiseEvent);
				}
				oustandingAmount = oustandingAmount.add(customerLiabilities.getLiabilityAmount().getCurrencyAmount());

			}
			calculatedAmount = calculatedAmount.add(getF_IN_amountToBeAdded().getCurrencyAmount());
			oustandingAmount = oustandingAmount.subtract(calculatedAmount);
		}
		if (getF_IN_mode().equals("TAWAROOQ")) {
			calculatedAmount = getF_IN_purchaseOrderDetails().getPoAmount().getCurrencyAmount()
					.subtract(getF_IN_purchaseOrderDetails().getLiabilityToBePaid().getCurrencyAmount())
					.subtract(getF_IN_purchaseOrderDetails().getTawarooqCommision())
					.subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())
					.subtract(initialFeesTaxAmount)
          .subtract(adjustmentFeesTaxAmount);
		}
		if (getF_IN_mode().equals("FEES")) {
			calculatedAmount = getF_IN_purchaseOrderDetails().getPoAmount().getCurrencyAmount()
					.subtract(getF_IN_purchaseOrderDetails().getLiabilityToBePaid().getCurrencyAmount())
					.subtract(getF_IN_purchaseOrderDetails().getTawarooqCommision())
					.subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())
          .subtract(initialFeesTaxAmount)
          .subtract(adjustmentFeesTaxAmount);
			oustandingAmount = issuePayOrderDtls.getOutstandingFees().subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid());
			if(issuePayOrderDtls.getOutstandingFees().compareTo(getF_IN_purchaseOrderDetails().getFeesToBePaid())<CommonConstants.INTEGER_ZERO) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000395);
				businessEventsService.handleEvent(raiseEvent);
			}
		}
		if (getF_IN_mode().equals("ADJUSTMENTFEES")) {
			calculatedAmount = getF_IN_purchaseOrderDetails().getPoAmount().getCurrencyAmount()
					.subtract(getF_IN_purchaseOrderDetails().getLiabilityToBePaid().getCurrencyAmount())
					.subtract(getF_IN_purchaseOrderDetails().getTawarooqCommision())
					.subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())
          .subtract(initialFeesTaxAmount)
          .subtract(adjustmentFeesTaxAmount);
			oustandingAmount = issuePayOrderDtls.getOutstandingAdjustmentFees().subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid());
			if(issuePayOrderDtls.getOutstandingAdjustmentFees().compareTo(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())<CommonConstants.INTEGER_ZERO) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000396);
				businessEventsService.handleEvent(raiseEvent);
			}
		}
		if (getF_IN_mode().equals("UPFRONTPROFIT")) {
			calculatedAmount = getF_IN_purchaseOrderDetails().getPoAmount().getCurrencyAmount()
					.subtract(getF_IN_purchaseOrderDetails().getLiabilityToBePaid().getCurrencyAmount())
					.subtract(getF_IN_purchaseOrderDetails().getTawarooqCommision())
					.subtract(getF_IN_purchaseOrderDetails().getFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getAdjustmentFeesToBePaid())
					.subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())
          .subtract(initialFeesTaxAmount)
          .subtract(adjustmentFeesTaxAmount);
			oustandingAmount = issuePayOrderDtls.getOutstandingUpfrontProfit().subtract(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid());
			if(issuePayOrderDtls.getOutstandingUpfrontProfit().compareTo(getF_IN_purchaseOrderDetails().getUpfrontProfitToBePaid())<CommonConstants.INTEGER_ZERO) {
				Event raiseEvent = new Event();
				raiseEvent.setEventNumber(44000397);
				businessEventsService.handleEvent(raiseEvent);
			}
		}
		if (getF_IN_mode().equals("REMAINAMT")) {
			for(PaymentDetails paymentDetails:issuePayOrderDtls.getPaymentDetails()) {
				if(!paymentDetails.isSelect())
					calculatedAmount = calculatedAmount.add(paymentDetails.getPaymentAmount().getCurrencyAmount());
			}
			calculatedAmount = calculatedAmount.add(getF_IN_amountToBeAdded().getCurrencyAmount());
			oustandingAmount = getF_IN_purchaseOrderDetails().getFinalDisbursementAmount().getCurrencyAmount().subtract(calculatedAmount);
			
		}
		BFCurrencyAmount totalAmount = new BFCurrencyAmount();
		totalAmount.setCurrencyAmount(calculatedAmount);
		totalAmount.setCurrencyCode("SAR");
		setF_OUT_totalAmount(totalAmount);
		BFCurrencyAmount outstandingAmount = new BFCurrencyAmount();
		outstandingAmount.setCurrencyAmount(oustandingAmount);
		outstandingAmount.setCurrencyCode("SAR");
		setF_OUT_outstandingAmount(outstandingAmount );
	}


}
