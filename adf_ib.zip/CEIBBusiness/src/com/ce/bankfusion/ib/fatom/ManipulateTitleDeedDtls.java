package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ManipulateTitleDeedDtls;
import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchFarmLandLocationDtlsRsType;
import com.misys.ce.types.SearchFarmLandNeighbourDtlsRsType;
import com.misys.ce.types.SearchParentTitleDeedDtlsRsType;
import com.misys.ce.types.SearchShareHolderDtlsRsType;
import com.misys.ce.types.SearchSplitTitleDeedDtlsRsType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.SearchTitleDeedLocDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.sun.media.jfxmedia.logging.Logger;

import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.services.ListTieredGenericCodeRq;
import bf.com.misys.cbs.services.ListTieredGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.InputListTieredGCRq;

public class ManipulateTitleDeedDtls extends AbstractCE_IB_ManipulateTitleDeedDtls {

  private static final long serialVersionUID = 1L;
  private transient final static Log LOGGER = LogFactory.getLog(ManipulateTitleDeedDtls.class.getName());

  public ManipulateTitleDeedDtls() {
    super();
  }

  public ManipulateTitleDeedDtls(BankFusionEnvironment env) {

  }

  public void process(BankFusionEnvironment env) throws BankFusionException {

    String mode = getF_IN_mode();
    switch (mode) {
    case "NEW":
      addNewRow(env);
      setF_OUT_newRow(true);
      setF_OUT_removeRow(false);
      setF_OUT_saveRow(false);
      break;

    case "SAVE":
      saveRow(env);
      setF_OUT_newRow(false);
      setF_OUT_removeRow(false);
      setF_OUT_saveRow(false);
      break;

    case "REMOVE":
      removeRow();
      setF_OUT_newRow(false);
      setF_OUT_removeRow(false);
      setF_OUT_saveRow(false);
      if(getF_IN_searchTitleDeedDtlsRsType().getListTitleDeedIdDtls().getTitleDeedDetailsCount()==CommonConstants.INTEGER_ZERO) {
        setF_OUT_removeRow(true);
        setF_OUT_saveRow(true);
      }
      
      break;
    default:
      break;

    }
  }

  private void addNewRow(BankFusionEnvironment env) {

    TitleDeedDetailsType deedDetailsType = new TitleDeedDetailsType();
    SearchShareHolderDtlsRsType dtlsRsType = new SearchShareHolderDtlsRsType();
    SearchTitleDeedLocDtlsRsType deedLocDtlsRsType = new SearchTitleDeedLocDtlsRsType();
    SearchParentTitleDeedDtlsRsType parentTitleDeedDtlsRsType = new SearchParentTitleDeedDtlsRsType();
    SearchSplitTitleDeedDtlsRsType searchSplitTitleDeedDtlsRsType = new SearchSplitTitleDeedDtlsRsType();
    SearchFarmLandLocationDtlsRsType farmLandLocationDtlsRsType = new SearchFarmLandLocationDtlsRsType();
    SearchFarmLandNeighbourDtlsRsType farmLandNeighbourDtlsRsType = new SearchFarmLandNeighbourDtlsRsType();

    SearchTitleDeedDtlsRsType newRow = getF_IN_searchTitleDeedDtlsRsType();
    // make the select false
    ListTitleDeedIdDtlsType listTitleDeedIdDtls = newRow.getListTitleDeedIdDtls();
    if (listTitleDeedIdDtls.getTitleDeedDetails().length > 0) {
      for (TitleDeedDetailsType titleDeedDetailsType : listTitleDeedIdDtls.getTitleDeedDetails()) {
        titleDeedDetailsType.setSelect(false);
      }
    }
    TitleDeedDetailsType vTitleDeedDetails = new TitleDeedDetailsType();
    vTitleDeedDetails.setFarmLocation(CommonConstants.EMPTY_STRING);
    vTitleDeedDetails.setTitleDeedIdpk(CommonConstants.EMPTY_STRING);
    vTitleDeedDetails.setTitleDeedNumber(CommonConstants.EMPTY_STRING);
    vTitleDeedDetails.setSelect(true);
    listTitleDeedIdDtls.addTitleDeedDetails(vTitleDeedDetails);
    newRow.setListTitleDeedIdDtls(listTitleDeedIdDtls);

    setF_OUT_searchFarmLandLocationDtlsRsType(farmLandLocationDtlsRsType);
    setF_OUT_searchFarmLandNeighbourDtlsRsType(farmLandNeighbourDtlsRsType);
    setF_OUT_searchParentTitleDeedDtlsRsType(parentTitleDeedDtlsRsType);
    setF_OUT_searchShareHolderDtlsRsType(dtlsRsType);
    setF_OUT_searchSplitTitleDeedDtlsRsType(searchSplitTitleDeedDtlsRsType);
    setF_OUT_searchTitleDeedLocDtlsRsType(deedLocDtlsRsType);
    setF_OUT_titleDeedDetailsType(deedDetailsType);
    setF_OUT_searchTitleDeedDtlsRsType(newRow);
  }

  private void saveRow(BankFusionEnvironment env) {

      
    SearchTitleDeedDtlsRsType searchTitleDeedDtlsRsType = getF_IN_searchTitleDeedDtlsRsType();
    SearchTitleDeedDtlsRsType outputSearchTitleDeedDtlsRs = new SearchTitleDeedDtlsRsType();
    TitleDeedDetailsType deedDetailsType = getF_IN_titleDeedDetailsType();
    String tdStatus = PartyUtil.getGCReference("TITLEDEEDSTATUS", deedDetailsType.getTitleDeedStatus());
    
    if(tdStatus.equalsIgnoreCase("INACTIVE"))
    {
    	IBCommonUtils.raiseUnparameterizedEvent(44000444);
    }
    validateTitleDeedMainGrid(searchTitleDeedDtlsRsType,deedDetailsType);
    ListTitleDeedIdDtlsType listTitleDeedIdDtls = new ListTitleDeedIdDtlsType();
    if (!StringUtils.isEmpty(deedDetailsType.getTitleDeedIdpk())) {
      for (TitleDeedDetailsType eachTitleDeed : searchTitleDeedDtlsRsType.getListTitleDeedIdDtls()
          .getTitleDeedDetails()) {
        if (eachTitleDeed.isSelect()) {
          validateTitleDeed(deedDetailsType, env);
          eachTitleDeed.setAreaSize(deedDetailsType.getAreaSize());
          eachTitleDeed.setDicissionStatus(deedDetailsType.getDicissionStatus());
          eachTitleDeed.setTitleDeedIdpk(deedDetailsType.getTitleDeedIdpk());
          eachTitleDeed.setTitleDeedNumber(deedDetailsType.getTitleDeedNumber());
          eachTitleDeed.setTitleDeedYear(deedDetailsType.getTitleDeedYear());
          eachTitleDeed.setTitleDeedSource(deedDetailsType.getTitleDeedSource());
          eachTitleDeed.setTitleDeedType(deedDetailsType.getTitleDeedType());
          eachTitleDeed.setLandPlanNumber(deedDetailsType.getLandPlanNumber());
          eachTitleDeed.setLandPlotNumber(deedDetailsType.getLandPlotNumber());
          eachTitleDeed.setFarmLocation(deedDetailsType.getFarmLocation());
          eachTitleDeed.setFarmLocationDescription(deedDetailsType.getFarmLocationDescription());
          eachTitleDeed.setLinkedToCollateral(deedDetailsType.getLinkedToCollateral());
          eachTitleDeed.setNotes(deedDetailsType.getNotes());
          eachTitleDeed.setReasonForChange(deedDetailsType.getReasonForChange());
          eachTitleDeed.setRetailIndex(deedDetailsType.getRetailIndex());
          eachTitleDeed.setSplitIndicator(deedDetailsType.getSplitIndicator());
          eachTitleDeed.setStatus(deedDetailsType.getStatus());
          eachTitleDeed.setTitleDeedStatus(deedDetailsType.getTitleDeedStatus());
          eachTitleDeed.setTransactionDate(deedDetailsType.getTransactionDate());
          eachTitleDeed.setTransactionNotes(deedDetailsType.getTransactionNotes());
          eachTitleDeed.setTransactionType(deedDetailsType.getTransactionType());
          eachTitleDeed.setValidFrom(deedDetailsType.getValidFrom());
          eachTitleDeed.setValidTo(deedDetailsType.getValidTo());
          eachTitleDeed.setValidFromHijri(deedDetailsType.getValidFromHijri());
          eachTitleDeed.setValidToHijri(deedDetailsType.getValidToHijri());
          eachTitleDeed.setVersionNumber(deedDetailsType.getVersionNumber());
        }

        listTitleDeedIdDtls.addTitleDeedDetails(eachTitleDeed);
 
      }
    }
    outputSearchTitleDeedDtlsRs.setListTitleDeedIdDtls(listTitleDeedIdDtls);
    setF_OUT_searchTitleDeedDtlsRsType(outputSearchTitleDeedDtlsRs);
  }
  
  private void validateTitleDeedMainGrid(SearchTitleDeedDtlsRsType searchTitleDeedDtlsRsType, TitleDeedDetailsType listTitleDeedIdDtls)
  {
    String titleDeedWhere = " WHERE "+IBOCE_TITLEDEEDSPLITDTLS.TITLEDEEDID + " = ?";
    for (TitleDeedDetailsType eachTitleDeed : searchTitleDeedDtlsRsType.getListTitleDeedIdDtls()
        .getTitleDeedDetails())
    {
      if(eachTitleDeed.getTitleDeedIdpk().equals(listTitleDeedIdDtls.getTitleDeedIdpk()))
      {
        IBCommonUtils.raiseUnparameterizedEvent(44000268);
        
      }
    }
    ArrayList<String> param = new ArrayList<String>();
    param.clear();
    param.add(listTitleDeedIdDtls.getTitleDeedIdpk());
    List<IBOCE_TITLEDEEDSPLITDTLS> titleSplitDetails = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDSPLITDTLS.BONAME, titleDeedWhere, param, null, true);
    if(titleSplitDetails!=null && (!titleSplitDetails.isEmpty())){
      IBCommonUtils.raiseUnparameterizedEvent(44000415);
      //once the title deed is split into other title deeds, this main title cannot be linked to a deal anymore
    }
    
  }

    private void validateTitleDeed(TitleDeedDetailsType deedDetailsType, BankFusionEnvironment env) {

        boolean flag = false;
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String dealID = getF_IN_islamicBankingObject().getDealID();
        if (dealID != null) {
            IBOIB_DLI_DealDetails dealDetails =
                (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
            String dealBranchCode = dealDetails.getF_BranchSortCode();
            TitleDeedDetailsType tileDeedDetails = getF_IN_titleDeedDetailsType();
            String farmLocation = tileDeedDetails.getFarmLocation();
            LOGGER.info("deal branch code is: " + dealBranchCode + " farmLocation is " + farmLocation);
            ListTieredGenericCodeRs gcResp = getTieredGC("BRANCHNAME_FL", dealBranchCode);
            if (null != gcResp && null != gcResp.getListTieredCodes()) {
                GcCodeDetail[] gcCodeDetails = gcResp.getListTieredCodes().getGcCodeDetails();
                if (null != gcCodeDetails && gcCodeDetails.length > 0) {
                    for (GcCodeDetail gcCodeDetail : gcCodeDetails) {
                        LOGGER.info("generic code for childs are: " + gcCodeDetail.getCodeReference());
                        if (gcCodeDetail.getCodeReference().equals(farmLocation)) {
                            flag = true;
                        }
                    }

                }
            }

            if (flag == false) {
                IBCommonUtils.raiseUnparameterizedEvent(44000264);

            }
        } else {
            IBCommonUtils.raiseUnparameterizedEvent(35100059);
        }

    }
  
  @SuppressWarnings("unchecked")
    private static ListTieredGenericCodeRs getTieredGC(String parent, String node) {
        HashMap outputParams =null;
        try {
            HashMap inputParams = new HashMap();
            ListTieredGenericCodeRq parentrequest = new ListTieredGenericCodeRq();
            InputListTieredGCRq inputListTieredGCRq = new InputListTieredGCRq();
            inputListTieredGCRq.setCbParentReference(parent);
            inputListTieredGCRq.setCbNodeReference(node);
            parentrequest.setInputListTieredGCRq(inputListTieredGCRq);
            inputParams.put("listTieredGenericCodeRq", parentrequest);
            outputParams = MFExecuter.executeMF("CB_GCD_ListTieredGenericCode_SRV", inputParams,BankFusionThreadLocal.getUserLocator().getStringRepresentation());
        }
        catch (Exception e) {
           e.printStackTrace();
        }
        ListTieredGenericCodeRs listGenericCodeRs = null;
        if (null != outputParams) {
            listGenericCodeRs = (ListTieredGenericCodeRs) outputParams.get("listTieredGenericCodeRs");
        }
        return listGenericCodeRs;
    }

  private void removeRow() {
    TitleDeedDetailsType deedDetailsType = new TitleDeedDetailsType();
    SearchShareHolderDtlsRsType dtlsRsType = new SearchShareHolderDtlsRsType();
    SearchTitleDeedLocDtlsRsType deedLocDtlsRsType = new SearchTitleDeedLocDtlsRsType();
    SearchParentTitleDeedDtlsRsType parentTitleDeedDtlsRsType = new SearchParentTitleDeedDtlsRsType();
    SearchSplitTitleDeedDtlsRsType searchSplitTitleDeedDtlsRsType = new SearchSplitTitleDeedDtlsRsType();
    SearchFarmLandLocationDtlsRsType farmLandLocationDtlsRsType = new SearchFarmLandLocationDtlsRsType();
    SearchFarmLandNeighbourDtlsRsType farmLandNeighbourDtlsRsType = new SearchFarmLandNeighbourDtlsRsType();

      SearchTitleDeedDtlsRsType searchTitleDeedDtlsRsType = getF_IN_searchTitleDeedDtlsRsType();
      for (TitleDeedDetailsType eachTitleDeed : searchTitleDeedDtlsRsType.getListTitleDeedIdDtls()
              .getTitleDeedDetails()) {
          if (eachTitleDeed.isSelect()) {
              searchTitleDeedDtlsRsType.getListTitleDeedIdDtls().removeTitleDeedDetails(eachTitleDeed);
          }
      }
      if (searchTitleDeedDtlsRsType.getListTitleDeedIdDtls().getTitleDeedDetailsCount() > 0) {
          int sizeOfList = searchTitleDeedDtlsRsType.getListTitleDeedIdDtls().getTitleDeedDetailsCount();
          searchTitleDeedDtlsRsType.getListTitleDeedIdDtls().getTitleDeedDetails(sizeOfList-1).setSelect(true);
      }

      setF_OUT_searchTitleDeedDtlsRsType(searchTitleDeedDtlsRsType);
      if(searchTitleDeedDtlsRsType.getListTitleDeedIdDtls().getTitleDeedDetailsCount()==0)
    {
      setF_OUT_searchFarmLandLocationDtlsRsType(farmLandLocationDtlsRsType);
      setF_OUT_searchFarmLandNeighbourDtlsRsType(farmLandNeighbourDtlsRsType);
      setF_OUT_searchParentTitleDeedDtlsRsType(parentTitleDeedDtlsRsType);
      setF_OUT_searchShareHolderDtlsRsType(dtlsRsType);
      setF_OUT_searchSplitTitleDeedDtlsRsType(searchSplitTitleDeedDtlsRsType);
      setF_OUT_searchTitleDeedLocDtlsRsType(deedLocDtlsRsType);
      setF_OUT_titleDeedDetailsType(deedDetailsType);
    } }
}
