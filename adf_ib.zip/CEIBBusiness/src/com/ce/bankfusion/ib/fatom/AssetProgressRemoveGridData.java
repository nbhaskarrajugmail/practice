package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressRemoveGridData;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;

public class AssetProgressRemoveGridData extends AbstractCE_IB_AssetProgressRemoveGridData {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public AssetProgressRemoveGridData(BankFusionEnvironment env) {
        super(env);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        AssetProgressReportDetails assetProgressReportDetails = getF_IN_assetProgressReportDetails();
        AssetProgressReport[] reportList = assetProgressReportDetails.getAssetProgressReportList();
        if (null == reportList || reportList.length == 0) {
            assetProgressReportDetails.removeAllAssetProgressDetailsList();
            setF_OUT_assetProgressReportDetails(
                (AssetProgressReportDetails) IBCommonUtils.intializeDefaultvalues(assetProgressReportDetails));
        } else {
            AssetProgressReport report = assetProgressReportDetails.getAssetProgressReportList(0);
            report.setSelect(true);
            setF_OUT_assetProgressReportDetails(assetProgressReportDetails);
        }
    }

}
