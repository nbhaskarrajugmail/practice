package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetLatestTitleDeedDetailsOfCollateral;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_GetLatestTitleDeedDetailsOfCollateral;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CollateralUtil;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CreateCollateralRqDetails;
import edu.emory.mathcs.backport.java.util.Arrays;

public class GetLatestTitleDeedDetailsOfCollateral extends AbstractCE_IB_GetLatestTitleDeedDetailsOfCollateral
        implements ICE_IB_GetLatestTitleDeedDetailsOfCollateral {

    private static final String COMMA = ",";

    public GetLatestTitleDeedDetailsOfCollateral() {
        // TODO Auto-generated constructor stub
    }

    public GetLatestTitleDeedDetailsOfCollateral(BankFusionEnvironment env) {
        super(env);

    }

    private static final transient Log LOGGER = LogFactory.getLog(GetLatestTitleDeedDetailsOfCollateral.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method-->" + getF_IN_titleDeedIDPK());
        getTitleDeedDetails();
        prepareCollateralTypes();
        LOGGER.info("Exiting from process method-->" + getF_IN_titleDeedIDPK());
    }

    private void prepareCollateralTypes() {
        LOGGER.info("Entering into prepareCollateralTypes method");
        if (getF_IN_createCollateralRqDetailsList().getCreateCollateralRqDetailsListCount() > 0) {
            for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralRqDetailsList()
                    .getCreateCollateralRqDetailsList()) {
                if (createCollateralRqDetails.isSelect() && IBCommonUtils.isNotEmpty(createCollateralRqDetails.getRequestType()))
                    setF_IN_requestType(createCollateralRqDetails.getRequestType());
            }

        }
        if (getF_IN_allCollateralGCList().getGcCodeDetailsCount() > 0
                && IBCommonUtils.isNotEmpty(getF_IN_allCollateralGCList().getGcCodeDetails(0).getCodeReference())
                && IBCommonUtils.isNotEmpty(getF_IN_requestType())) {
            String[] collateralTypes = null;
            if (CollateralUtil.REQUSEST_TYPE_NOEVALUATION.equals(getF_IN_requestType())) {
                collateralTypes = BankFusionPropertySupport
                        .getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                                CollateralUtil.NO_EVALUATION_COLLATERAL_TYPES, "", CeConstants.ADFIBCONFIGLOCATION)
                        .split(COMMA);
            }
            else if (CollateralUtil.REQUSEST_TYPE_NONPERSONAL.equals(getF_IN_requestType())) {
                collateralTypes = BankFusionPropertySupport
                        .getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                                CollateralUtil.NON_PERSONAL_COLLATERAL_TYPES, "", CeConstants.ADFIBCONFIGLOCATION)
                        .split(COMMA);
            }
            else if (CollateralUtil.REQUSEST_TYPE_PERSONAL.equals(getF_IN_requestType())) {
                collateralTypes = BankFusionPropertySupport
                        .getPropertyBasedOnConfLocation(CollateralUtil.CUSTOM_COLLATERAL_CONF_FILE,
                                CollateralUtil.PERSONAL_COLLATERAL_TYPES, "", CeConstants.ADFIBCONFIGLOCATION)
                        .split(COMMA);
            }
            getF_OUT_collateralTypesGCList().removeAllGcCodeDetails();
            /*if (null == collateralTypes) {
                getF_OUT_collateralTypesGCList().setGcCodeDetails(getF_IN_allCollateralGCList().getGcCodeDetails());
            }
            else {*/
                List<String> collateralTypesList = Arrays.asList(collateralTypes);
                for (GcCodeDetail gcCodeDtls : getF_IN_allCollateralGCList().getGcCodeDetails()) {
                    if (collateralTypesList.contains(gcCodeDtls.getCodeReference())) {
                        getF_OUT_collateralTypesGCList().addGcCodeDetails(gcCodeDtls);
                    }
                }
            /*}*/
        }
        LOGGER.info("Exiting from prepareCollateralTypes method");
    }

    private void getTitleDeedDetails() {
        LOGGER.info("Entering into getTitleDeedDetails method");
        if(getF_IN_createCollateralRqDetailsList().getCreateCollateralRqDetailsListCount()>0)
        {
            for(CreateCollateralRqDetails createCollateralRqDetails: getF_IN_createCollateralRqDetailsList().getCreateCollateralRqDetailsList())
            {
                if(createCollateralRqDetails.isSelect() && IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID()))
                {
                    IBOCE_IB_CollateralRevaluationDetails createRequestCollateralDetails = (IBOCE_IB_CollateralRevaluationDetails) factory
                            .findByPrimaryKey(IBOCE_IB_CollateralRevaluationDetails.BONAME,createCollateralRqDetails.getRequestID() , true);
                    if (null != createRequestCollateralDetails ) {
                       setF_IN_titleDeedIDPK(createRequestCollateralDetails.getF_IBTITLEDEEDIDPK());
                    }
                }
            }
        }
        if (CollateralUtil.REQUSEST_TYPE_NONPERSONAL.equals(getF_IN_requestType())
                && IBCommonUtils.isNotEmpty(getF_IN_titleDeedIDPK())) {
            IBOCE_IB_DealCollateralDtls createCollateralDetails = (IBOCE_IB_DealCollateralDtls) factory
                    .findByPrimaryKey(IBOCE_IB_DealCollateralDtls.BONAME, getF_IN_collateralID(), true);
            if(null != createCollateralDetails && CollateralUtil.COLLATERAL_SYSTEM_STATUS_POSTED.equals(createCollateralDetails.getF_IBSYSTEMSTATUS()))
            {
                getF_OUT_titleDeedDetails().setLandPlotNum(createCollateralDetails.getF_IBTITLEDEEEDPLOTNUM());
                getF_OUT_titleDeedDetails().setPlan(createCollateralDetails.getF_IBTITLEDEEEDPLANNO());
                getF_OUT_titleDeedDetails().setTitleDeedNum(createCollateralDetails.getF_IBTITLEDEEDNUM());
                getF_OUT_titleDeedDetails().setType(IBCommonUtils.getGCChildDesc(
                        CollateralUtil.TITLE_DEED_TYPE_GC_REFERENCE, createCollateralDetails.getF_IBTITLEDEEEDTYPE()));
                getF_OUT_titleDeedDetails().setSource(IBCommonUtils.getGCChildDesc(
                        CollateralUtil.TITLE_DEED_SOURCE_GC_REFERENCE, createCollateralDetails.getF_IBTITLEDEEEDSOURCE()));
                getF_OUT_titleDeedDetails().setYear(createCollateralDetails.getF_IBTITLEDEEEDYEAR());
            }
            else
            {
            Map inputParams = new HashMap();
            SearchTitleDeedDtlsRqType rq = new SearchTitleDeedDtlsRqType();
            rq.setTitleDeedId(getF_IN_titleDeedIDPK());
            rq.setPartyId("");
            inputParams.put("searchTitleDeedDtlsRqType", rq);
            try {
                HashMap outputParams = MFExecuter.executeMF("CE_FilterTitleDeedDtl_SRV",
                        BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
                SearchTitleDeedDtlsRsType rs = (SearchTitleDeedDtlsRsType) outputParams.get("searchTitleDeedDtlsRs");
                if (rs != null && rs.getListTitleDeedIdDtls() != null) {
                    TitleDeedDetailsType vtitleDeedDetail = rs.getListTitleDeedIdDtls().getTitleDeedDetails(0);
                        if (IBCommonUtils.isNotEmpty(vtitleDeedDetail.getTitleDeedIdpk())) {
                            getF_OUT_titleDeedDetails().setLandPlotNum(vtitleDeedDetail.getLandPlotNumber());
                            getF_OUT_titleDeedDetails().setPlan(vtitleDeedDetail.getLandPlanNumber());
                            getF_OUT_titleDeedDetails().setTitleDeedNum(vtitleDeedDetail.getTitleDeedNumber());
                            getF_OUT_titleDeedDetails().setType(IBCommonUtils.getGCChildDesc(
                                    CollateralUtil.TITLE_DEED_TYPE_GC_REFERENCE, vtitleDeedDetail.getTitleDeedType()));
                            getF_OUT_titleDeedDetails().setSource(IBCommonUtils.getGCChildDesc(
                                    CollateralUtil.TITLE_DEED_SOURCE_GC_REFERENCE, vtitleDeedDetail.getTitleDeedSource()));
                            getF_OUT_titleDeedDetails().setYear(String.valueOf(vtitleDeedDetail.getTitleDeedYear()));
                        }
                }
            }
            catch (Exception e) {
                LOGGER.error("Exception in process method-->" + e.getMessage());
                e.printStackTrace();
            }
            }
            setF_OUT_titleDeedDetailsPanelVisibility(true);
        }
        else {
            setF_OUT_titleDeedDetailsPanelVisibility(false);
        }
        LOGGER.info("Exiting from getTitleDeedDetails method");
    }

}
