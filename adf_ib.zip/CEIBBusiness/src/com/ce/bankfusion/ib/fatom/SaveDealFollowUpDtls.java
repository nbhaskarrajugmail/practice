package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpAssetDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpCropDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveDealFollowUpDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.dealfollowup.dtls.ib.types.DealFollowUpDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpCropDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails;

public class SaveDealFollowUpDtls extends AbstractCE_IB_SaveDealFollowUpDtls {

	public SaveDealFollowUpDtls(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		if (isF_IN_isPersist()) {
			persistDealFollowUpDtls();
		} else {
			saveDealFollowUpDtls();
		}
	}

	private void saveDealFollowUpDtls() {
		DealFollowUpDetails dealFollowUpDetails = getF_IN_hiddenDealFollowUpDetails();
		if (getF_IN_dealFollowUpDetails() != null && getF_IN_dealFollowUpDetails().getFollowUpDetailsCount() > 0) {
			for (FollowUpDetails followUpDetails : getF_IN_dealFollowUpDetails().getFollowUpDetails()) {
				if (followUpDetails.isSelect()) {
					getF_IN_followUpDetail().setCustomerStatus(followUpDetails.getCustomerStatus());
					getF_IN_followUpDetail().setDateOfTechnicalReport(followUpDetails.getDateOfTechnicalReport());
					getF_IN_followUpDetail().setDealId(followUpDetails.getDealId());
					getF_IN_followUpDetail().setDealStatus(followUpDetails.getDealStatus());
					getF_IN_followUpDetail().setFarmStatus(followUpDetails.getFarmStatus());
					getF_IN_followUpDetail().setFollowUpDate(followUpDetails.getFollowUpDate());
					getF_IN_followUpDetail().setFollowUpDone(followUpDetails.isFollowUpDone());
					getF_IN_followUpDetail().setFollowUpId(followUpDetails.getFollowUpId());
					getF_IN_followUpDetail().setFollowUpOutsideTheSheet(followUpDetails.isFollowUpOutsideTheSheet());
					getF_IN_followUpDetail().setFollowUpStatus(followUpDetails.getFollowUpStatus());
					getF_IN_followUpDetail().setInspectorName(followUpDetails.getInspectorName());
					getF_IN_followUpDetail().setTechnicalReportId(followUpDetails.getTechnicalReportId());
					getF_IN_followUpDetail().setTechnicalReportInspector(followUpDetails.getTechnicalReportInspector());
					
					getF_IN_followUpDetail().setCropType(followUpDetails.getCropType());
					getF_IN_followUpDetail().setNonSoudiEmployee(followUpDetails.getNonSoudiEmployee());
					getF_IN_followUpDetail().setProductionCapacity(followUpDetails.getProductionCapacity());
					getF_IN_followUpDetail().setProjectStatus(followUpDetails.getProjectStatus());
					getF_IN_followUpDetail().setSoudiEmployee(followUpDetails.getSoudiEmployee());
					getF_IN_followUpDetail().setTotalEmployee(followUpDetails.getTotalEmployee());
					getF_IN_followUpDetail().setWaterUsage(followUpDetails.getWaterUsage());
				}
			}
		}
		replaceFollowupAssetDtlsInHiddenGrid(dealFollowUpDetails);
		replaceFollowupCropDtlsInHiddenGrid(dealFollowUpDetails);
		setF_OUT_hiddenDealFollowUpDetails(dealFollowUpDetails);
	}

	private void replaceFollowupCropDtlsInHiddenGrid(DealFollowUpDetails dealFollowUpDetails) {
		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpCropDetailsCount() > 0) {
			for (FollowUpCropDetails followUpCropDetails : dealFollowUpDetails.getFollowUpCropDetails()) {
				if (followUpCropDetails.getFollowUpId().equals(getF_IN_followUpDetail().getFollowUpId()))
					dealFollowUpDetails.removeFollowUpCropDetails(followUpCropDetails);
			}
		}

		if (dealFollowUpDetails != null && getF_IN_dealFollowUpDetails() != null
				&& getF_IN_dealFollowUpDetails().getFollowUpCropDetailsCount() > 0) {
			for (FollowUpCropDetails followUpCropDetails : getF_IN_dealFollowUpDetails().getFollowUpCropDetails()) {
				dealFollowUpDetails.addFollowUpCropDetails(followUpCropDetails);
			}
		}

	}

	private void replaceFollowupAssetDtlsInHiddenGrid(DealFollowUpDetails dealFollowUpDetails) {
		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpAssetDetailsCount() > 0) {
			for (FollowUpAssetDetails followUpAssetDetails : dealFollowUpDetails.getFollowUpAssetDetails()) {
				if (followUpAssetDetails.getFollowUpId().equals(getF_IN_followUpDetail().getFollowUpId()))
					dealFollowUpDetails.removeFollowUpAssetDetails(followUpAssetDetails);
			}
		}
		if (dealFollowUpDetails != null && getF_IN_dealFollowUpDetails() != null
				&& getF_IN_dealFollowUpDetails().getFollowUpAssetDetailsCount() > 0) {
			for (FollowUpAssetDetails followUpAssetDetails : getF_IN_dealFollowUpDetails().getFollowUpAssetDetails()) {
				dealFollowUpDetails.addFollowUpAssetDetails(followUpAssetDetails);
			}
		}

	}

	private void persistDealFollowUpDtls() {
		DealFollowUpDetails dealFollowUpDetails = getF_IN_hiddenDealFollowUpDetails();
		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0) {
			for (FollowUpDetails followUpDetails : dealFollowUpDetails.getFollowUpDetails()) {
				if (CalendarUtil.IsDate1EqualsToDate2(followUpDetails.getFollowUpDate(),
						IBCommonUtils.getBFBusinessDate()) && !followUpDetails.isFollowUpDone()) {
					persistFollowUpDtl(followUpDetails);
					persistFollowUpAssetDtl(followUpDetails);
					persistFollowUpCropDtl(followUpDetails);
				}
			}
		}
	}

	private void persistFollowUpCropDtl(FollowUpDetails followUpDetails) {
		if (followUpDetails != null) {
			String whereClause = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpCropDtls.IBDEALFOLLOWUPID
					+ " = ?";
			ArrayList<String> params = new ArrayList<>();
			params.add(followUpDetails.getFollowUpId());
			BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_DealFollowUpCropDtls.BONAME, whereClause,
					params);
			//BankFusionThreadLocal.getPersistanceFactory().commitTransaction();

			if (getF_IN_hiddenDealFollowUpDetails() != null
					&& getF_IN_hiddenDealFollowUpDetails().getFollowUpCropDetailsCount() > 0) {
				for (FollowUpCropDetails followUpCropDetails : getF_IN_hiddenDealFollowUpDetails()
						.getFollowUpCropDetails()) {
					if (followUpCropDetails.getFollowUpId().equals(followUpDetails.getFollowUpId())) {
						IBOCE_IB_DealFollowUpCropDtls dealFollowUpCropDtls = (IBOCE_IB_DealFollowUpCropDtls) BankFusionThreadLocal
								.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_DealFollowUpCropDtls.BONAME);
						dealFollowUpCropDtls.setBoID(IBCommonUtils.getNewGUID());//same IDPK of CE_IBTB_TECHNICALCROPDTLS table
						dealFollowUpCropDtls.setF_IBCROPID(followUpCropDetails.getCropId());
						dealFollowUpCropDtls.setF_IBDEALFOLLOWUPID(followUpCropDetails.getFollowUpId());
						dealFollowUpCropDtls
								.setF_IBEXPECTEDREVENUE(followUpCropDetails.getExpectedRevenue().getCurrencyAmount());
						dealFollowUpCropDtls.setF_IBUSEDAREAINFOLLOWUPREP(
								followUpCropDetails.getUsedAreaInFollowUpReport() == null ? BigDecimal.ZERO
										: followUpCropDetails.getUsedAreaInFollowUpReport());
						BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_DealFollowUpCropDtls.BONAME,
								dealFollowUpCropDtls);
					}
				}
			}
		}
	}

	private void persistFollowUpAssetDtl(FollowUpDetails followUpDetails) {
		if (followUpDetails != null) {
			String whereClause = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpAssetDtls.IBFOLLOWUPID + " = ?";
			ArrayList<String> params = new ArrayList<>();
			params.add(followUpDetails.getFollowUpId());
			BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_DealFollowUpAssetDtls.BONAME, whereClause,
					params);
			//BankFusionThreadLocal.getPersistanceFactory().commitTransaction();

			if (getF_IN_hiddenDealFollowUpDetails() != null
					&& getF_IN_hiddenDealFollowUpDetails().getFollowUpAssetDetailsCount() > 0) {
				for (FollowUpAssetDetails followUpAssetDetails : getF_IN_hiddenDealFollowUpDetails()
						.getFollowUpAssetDetails()) {
					if (followUpAssetDetails.getFollowUpId().equals(followUpDetails.getFollowUpId())) {
						IBOCE_IB_DealFollowUpAssetDtls dealFollowUpAssetDtls = (IBOCE_IB_DealFollowUpAssetDtls) BankFusionThreadLocal
								.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_DealFollowUpAssetDtls.BONAME);
						dealFollowUpAssetDtls.setBoID(IBCommonUtils.getNewGUID());
						dealFollowUpAssetDtls.setF_IBASSETEXIST(followUpAssetDetails.getAssetExist());
						dealFollowUpAssetDtls.setF_IBASSETID(followUpAssetDetails.getAssetId());
						dealFollowUpAssetDtls.setF_IBFOLLOWUPID(followUpAssetDetails.getFollowUpId());
						dealFollowUpAssetDtls.setF_IBFOLLOWUPNOTES(followUpAssetDetails.getNotes());
						dealFollowUpAssetDtls.setF_IBMACHINENUMBER(followUpAssetDetails.getMachineNumber());
						dealFollowUpAssetDtls
								.setF_IBSPECIFICATIONSONSITE(followUpAssetDetails.getSpecificationsOnSite());
						BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_DealFollowUpAssetDtls.BONAME,
								dealFollowUpAssetDtls);
						/*CeUtils.persistAssetUDFs(followUpDetails.getDealId(), followUpAssetDetails.getAssetId(),
								getF_IN_hiddenDealFollowUpDetails().getFollowUpAssetUDFs());*/
					}
				}
			}
		}
	}

	private void persistFollowUpDtl(FollowUpDetails followUpDetails) {

		if (followUpDetails != null) {
			String whereClause = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealFollowUpDtls.IBFOLLOWUPDTLSID + " = ?";
			ArrayList<String> params = new ArrayList<>();
			params.add(followUpDetails.getFollowUpId());
			BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_DealFollowUpDtls.BONAME, whereClause,
					params);
			//BankFusionThreadLocal.getPersistanceFactory().commitTransaction();

			IBOCE_IB_DealFollowUpDtls dealFollowUpDtls = (IBOCE_IB_DealFollowUpDtls) BankFusionThreadLocal
					.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_DealFollowUpDtls.BONAME);
			dealFollowUpDtls.setBoID(followUpDetails.getFollowUpId());
			dealFollowUpDtls.setF_IBDEALID(followUpDetails.getDealId());
			dealFollowUpDtls.setF_IBFOLLOWUPOUTSIDESHEET(followUpDetails.getFollowUpOutsideTheSheet());
			dealFollowUpDtls.setF_IBFARMSTATUS(followUpDetails.getFarmStatus());
			dealFollowUpDtls.setF_IBFOLLOWUPSTATUS(followUpDetails.getFollowUpStatus());
			dealFollowUpDtls.setF_IBCUSTOMERSTATUS(followUpDetails.getCustomerStatus());
			dealFollowUpDtls.setF_IBTECHREPORTID(followUpDetails.getTechnicalReportId());
			dealFollowUpDtls.setF_IBFOLLOWUPDONE(followUpDetails.getFollowUpDone());
			dealFollowUpDtls.setF_IBINSPECTORNAME(followUpDetails.getInspectorName());
			dealFollowUpDtls.setF_IBFOLLOWUPDATE(IBCommonUtils.getBFBusinessDateTime());
			
			dealFollowUpDtls.setF_IBCROPTYPE(followUpDetails.getCropType());
			dealFollowUpDtls.setF_IBNONSOUDIEMPLOYEE(followUpDetails.getNonSoudiEmployee());
			dealFollowUpDtls.setF_IBPRODUCTIONCAPACITY(followUpDetails.getProductionCapacity());
			dealFollowUpDtls.setF_IBPROJECTSTATUS(followUpDetails.getProjectStatus());
			dealFollowUpDtls.setF_IBSOUDIEMPLOYEE(followUpDetails.getSoudiEmployee());
			dealFollowUpDtls.setF_IBTOTALEMPLOYEE(followUpDetails.getTotalEmployee());
			dealFollowUpDtls.setF_IBWATERUSAGE(followUpDetails.getWaterUsage());
			
			IBOCE_IB_FollowUpListConf followUpAssignConf = DealFollowUpUtils.getFollowUpConfObj(followUpDetails.getDealId());
			if(followUpAssignConf != null) {
				dealFollowUpDtls.setF_IBFOLLOWUPASSIGNUSER(followUpAssignConf.getF_IBINSPECTORNAME());
			}
			BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_IB_DealFollowUpDtls.BONAME, dealFollowUpDtls);
		}
	}
}
