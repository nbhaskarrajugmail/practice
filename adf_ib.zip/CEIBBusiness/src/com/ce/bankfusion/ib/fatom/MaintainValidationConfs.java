package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_MaintainValidationConfs;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.constants.CommonsEventCodes;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.Validation;
import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationConfList;

public class MaintainValidationConfs extends AbstractCE_IB_MaintainValidationConfs{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8861418520201903566L;
	public MaintainValidationConfs()
	{
		super();
	}
	public MaintainValidationConfs(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();
		switch(context)
		{
		case "NEWROW" :
			addRow();
			break;
		case "SAVEROW" :
			saveValidationConf();
			break;
		case "DELETEROW" :
			deleteValidationConf();
			break;
		case "DUPLICATEROW" :
			addRowWithDuplicationOfSelected();
			break;
		case "ROWSELECT" :
			rowSelectEvent();
			break;
		default :
			break;


		}
	}
	private void rowSelectEvent() {
		disableFields();
		repopulateStepList();
		
	}
	private void repopulateStepList() {
		ValidationConfList validationCofList = getF_IN_validationConfList();
		if(null != validationCofList && null != validationCofList.getValidationConf())
		{
			for(ValidationConf eachConf : validationCofList.getValidationConf())
			{
				if(eachConf.isSelect())
				{
					if(StringUtils.isNotBlank(eachConf.getProcessID()))
					{
						setF_OUT_genericCodeListRs(ValidationsUtil.getStepList(eachConf.getProcessID()));
					}
					if(StringUtils.isNotBlank(eachConf.getValidationID()))
					{
						Validation validation = ValidationsUtil.getValidation(eachConf.getValidationID());
						String desc = (null!=validation)?validation.getDescription():CommonConstants.EMPTY_STRING;
						setF_OUT_validationDesc(desc);
					}
					ValidationConf validationConf = new ValidationConf();
					validationConf.setActionType(eachConf.getActionType());
					validationConf.setValidationID(eachConf.getValidationID());
					setF_OUT_validationConf(validationConf);
					break;
				}
			}
		}
		
	}
	private void disableFields() {
		ValidationConfList validationCofList = getF_IN_validationConfList();
		boolean disablefilterBasedOnBranch = true;
		boolean disableUserSearch = true;
		if(null != validationCofList && null != validationCofList.getValidationConf())
		{
			for(ValidationConf eachConf : validationCofList.getValidationConf())
			{
				if(eachConf.isSelect())
				{
					if(ValidationExceptionConstants.ACTION_APPROVAL.equals(eachConf.getActionType()))
					{
						disableUserSearch = false;
						if(null != eachConf.isIsGroup() && eachConf.isIsGroup())
						{
							disablefilterBasedOnBranch = false;
						}
					}
					break;
				}
			}
		}
		setF_OUT_disableUserSearch(disableUserSearch);
		setF_OUT_disablefilterBasedOnBranch(disablefilterBasedOnBranch);
	}
	private void addRowWithDuplicationOfSelected() {
		//if no row is selected or list empty - an empty row will be added
		ValidationConfList validationCofList = getF_IN_validationConfList();
		ValidationConf selectedConf = new ValidationConf();
		if(null != validationCofList && null != validationCofList.getValidationConf())
		{
			for(ValidationConf eachConf : validationCofList.getValidationConf())
			{
				if(eachConf.isSelect())
				{
					selectedConf = eachConf;
				}
				eachConf.setSelect(false);
			}
		}
		ValidationConf newConf = new ValidationConf();
		newConf.setSelect(true);
		newConf.setValidationID(selectedConf.getValidationID());
		newConf.setActionType(selectedConf.getActionType());
		newConf.setApprovalUserID(selectedConf.getApprovalUserID());
		newConf.setApprovalUserName(selectedConf.getApprovalUserName());
		newConf.setIsFilterBasedOnBranch(selectedConf.isIsFilterBasedOnBranch());
		newConf.setIsGroup(selectedConf.isIsGroup());
		validationCofList.addValidationConf(newConf);
		setF_OUT_validationConfList(validationCofList);
		
	}
	private void deleteValidationConf() {
		//If the deleting conf is present in the DB, it will removed from DB
		//else only row in the screen will be deleted
		ValidationConfList validationCofList = getF_IN_validationConfList();
		if(null != validationCofList && null != validationCofList.getValidationConf())
		{
			for(ValidationConf eachConf : validationCofList.getValidationConf())
			{
				if(eachConf.isSelect())
				{
					ValidationsUtil.deleteValidationConf(eachConf);
					validationCofList.removeValidationConf(eachConf);
					break;
				}
			}
		}
		if(validationCofList.getValidationConfCount() > 0)
		{
			validationCofList.getValidationConf(0).setSelect(true);
		}
		setF_OUT_validationConfList(validationCofList);
	}
	private void saveValidationConf() {
		//The new conf will be saved to the DB
		//If save is clicked with New row, then a row will be added to the existing grid
		boolean gridRowSelected = false;
		ValidationConfList validationCofList = getF_IN_validationConfList();
		ValidationConf selectedConfFromScalar = getF_IN_validationConf();
		if(StringUtils.isBlank(selectedConfFromScalar.getValidationConfID()))
		{
			validateForDuplication(selectedConfFromScalar);
			
		}
		validateForMandatoryFields(selectedConfFromScalar);
		for(ValidationConf eachConf : validationCofList.getValidationConf())
		{
			if(eachConf.isSelect())
			{
				gridRowSelected = true;
				ValidationsUtil.saveOrUpdate(selectedConfFromScalar);
				eachConf.setActionType(selectedConfFromScalar.getActionType());
				eachConf.setApprovalUserID(selectedConfFromScalar.getApprovalUserID());
				eachConf.setApprovalUserName(selectedConfFromScalar.getApprovalUserName());
				eachConf.setIsFilterBasedOnBranch(selectedConfFromScalar.isIsFilterBasedOnBranch());
				eachConf.setIsGroup(selectedConfFromScalar.getIsGroup());
				eachConf.setProcessID(selectedConfFromScalar.getProcessID());
				eachConf.setStepID(selectedConfFromScalar.getStepID());
				eachConf.setValidationID(selectedConfFromScalar.getValidationID());
				eachConf.setValidationConfID(selectedConfFromScalar.getValidationConfID());
				break;
			}
		}
		if(!gridRowSelected)
		{
			ValidationsUtil.saveOrUpdate(selectedConfFromScalar);
			selectedConfFromScalar.setSelect(true);
			validationCofList.addValidationConf(selectedConfFromScalar);
		}
		setF_OUT_validationConfList(validationCofList);
	}
	private void validateForMandatoryFields(ValidationConf selectedConfFromScalar) {
		if(StringUtils.isBlank(selectedConfFromScalar.getProcessID()) ||
				StringUtils.isBlank(selectedConfFromScalar.getStepID()) ||
				StringUtils.isBlank(selectedConfFromScalar.getValidationID()) ||
				StringUtils.isBlank(selectedConfFromScalar.getActionType()) )
		{
			IBCommonUtils.raiseUnparameterizedEvent(CommonsEventCodes.E_MANDATORY_FIELDS_IB);
		}
		
		if(ValidationExceptionConstants.ACTION_APPROVAL.equals(selectedConfFromScalar.getActionType()) 
				&& StringUtils.isBlank(selectedConfFromScalar.getApprovalUserID()))
		{
			IBCommonUtils.raiseUnparameterizedEvent(ValidationExceptionConstants.E_APPROVER_MANDATORY);
		}
	}
	private void validateForDuplication(ValidationConf newConfForSave) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_ValidationConfiguration.IBVALIDATIONID + " = ? AND "
				+ IBOCE_IB_ValidationConfiguration.IBPROCESSCONFIGID + " = ? AND "
				+ IBOCE_IB_ValidationConfiguration.IBSTEPID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(newConfForSave.getValidationID());
		params.add(newConfForSave.getProcessID());
		params.add(newConfForSave.getStepID());
		List<IBOCE_IB_ValidationConfiguration> existingConfs = factory.findByQuery(IBOCE_IB_ValidationConfiguration.BONAME, whereClause, params, null, false);
		if(null != existingConfs && !existingConfs.isEmpty())
		{
			IBCommonUtils.raiseUnparameterizedEvent(ValidationExceptionConstants.E_DUPLICATE_VALIDATION_CONF);
		}
	}
	private void addRow() {
		ValidationConfList validationCofList = getF_IN_validationConfList();
		if(null != validationCofList && null != validationCofList.getValidationConf())
		{
			for(ValidationConf eachConf : validationCofList.getValidationConf())
			{
				if(StringUtils.isBlank(eachConf.getValidationID()))
				{
					IBCommonUtils.raiseUnparameterizedEvent(ValidationExceptionConstants.E_NEW_ROW_PRESENT);
				}
				eachConf.setSelect(false);
			}
		}
		ValidationConf newConf = new ValidationConf();
		newConf.setSelect(true);
		validationCofList.addValidationConf(newConf);
		setF_OUT_validationConfList(validationCofList);
	}

}
