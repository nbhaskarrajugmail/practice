/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOAssetDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DefaultIssuePOData;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetails;
import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PaymentDetails;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.PurchaseOrderDetails;

/**
 * @author Aklesh
 *
 */
public class DefaultIssuePOData extends AbstractCE_IB_DefaultIssuePOData {

	private static final long serialVersionUID = 7137308733675905581L;
	
	private static final String WHERE_CLAUSE_POS_FOR_SAME_REPORT = "WHERE " + IBOCE_IB_IssuePODetail.IBREPORTID + "=? ";
	private static final String WHERE_PO_ASSETS_FOR_SAME_REPORT = "WHERE " + IBOCE_IB_IssuePOAssetDetail.IBPURCHASEORDERID + "=? AND "+ IBOCE_IB_IssuePOAssetDetail.IBASSETID + "=? ";
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	public DefaultIssuePOData(BankFusionEnvironment env) {
		super(env);
	}

	public DefaultIssuePOData() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
		        .getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
		IslamicBankingObject bankingObject = getF_IN_islamicBankingObject();
		IssuePayOrderDtls issuePayOrderDtls = getF_OUT_issuePayOrderDtls();
		PurchaseOrderDetails purchaseOrderDetails = getF_OUT_purchaseOrderDetails();
		String purchaseOrderID = getF_IN_purhaseOrderID();
		String hijriDate = CommonConstants.EMPTY_STRING;
		Date businessDate = new Date(0);
		if (CommonConstants.EMPTY_STRING.equals(purchaseOrderID)) {
			for(PurchaseOrderDetails orderDetails:getF_IN_issuePayOrderDtls().getPurchaseOrderDetails()) {
				if(orderDetails.getPoStatus().equals("New")||orderDetails.getPoStatus().equals("Approved")) {
					Event raiseEvent = new Event();
					raiseEvent.setEventNumber(44000400);
					businessEventsService.handleEvent(raiseEvent);
				}
			}
			CustomAutoNumFatom autoNum = new CustomAutoNumFatom(env);
			autoNum.setF_IN_BONAME("CE_IB_IssuePaymentOrder");
			autoNum.setF_IN_Prefix("PO_");
			autoNum.process(env);
			purchaseOrderID = autoNum.getF_OUT_PrimKey();
			businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
			ConvertGregorianToHijriDate gregorianToHijriDate = new ConvertGregorianToHijriDate();
			gregorianToHijriDate.setF_IN_gregorianDate(businessDate);
			gregorianToHijriDate.process(env);
			hijriDate = gregorianToHijriDate.getF_OUT_hijriDate();
			purchaseOrderDetails.setPoDateH(hijriDate);
			purchaseOrderDetails.setDealId(bankingObject.getDealID());
			purchaseOrderDetails.setPoDateG(businessDate);
			purchaseOrderDetails.setPurchaseOrderID(purchaseOrderID);
			purchaseOrderDetails.setPoStatus("New");
			purchaseOrderDetails.setTawarooqCommision(CommonConstants.BIGDECIMAL_ZERO);
			purchaseOrderDetails.setAdjustmentFeesToBePaid(getF_IN_outstandingAdjustmentFees());
			purchaseOrderDetails.setFeesToBePaid(getF_IN_outstandingFees());
			purchaseOrderDetails.setUpfrontProfitToBePaid(getF_IN_outstandingUpfrontProfit());
			String reportID = CommonConstants.EMPTY_STRING;
			BigDecimal prAmount = CommonConstants.BIGDECIMAL_ZERO;
			
			AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(env);
			assetProgressingFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
			assetProgressingFatom.setF_IN_mode("RETRIEVE");
			assetProgressingFatom.process(env);
			
			for(AssetProgressReport assetProgressReport: assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportList()) {
				if(assetProgressReport.getReportStatus().equals("Processed")) {
					reportID = assetProgressReport.getReportID();
					prAmount = assetProgressReport.getTotalDisbursementAmount().getCurrencyAmount();
				}
			}
			
			if (reportID != null && !reportID.isEmpty()) {
				purchaseOrderDetails.setProgressReportID(reportID);
				BigDecimal previousPOAmount =CommonConstants.BIGDECIMAL_ZERO; 
				for(PurchaseOrderDetails assetDisbursementDetails: getF_IN_issuePayOrderDtls().getPurchaseOrderDetails()) {
					if(assetDisbursementDetails.getProgressReportID().equals(reportID))
						previousPOAmount = previousPOAmount.add(assetDisbursementDetails.getPoAmount().getCurrencyAmount());
				}
				BFCurrencyAmount progressReportAmount = new BFCurrencyAmount();
				progressReportAmount.setCurrencyAmount(prAmount);
				progressReportAmount.setCurrencyCode(bankingObject.getCurrency());
				purchaseOrderDetails.setProgressReportAmount(progressReportAmount);
				BigDecimal newPOAmount = progressReportAmount.getCurrencyAmount().subtract(previousPOAmount);
				purchaseOrderDetails.getPoAmount().setCurrencyAmount(newPOAmount);
				BigDecimal tawarooqCommision = new BigDecimal(IBCommonUtils.getModuleConfigurationValue("IB", "TawarooqComissionAmount").getValue());
				purchaseOrderDetails.setTawarooqCommision(tawarooqCommision);
				issuePayOrderDtls.removeAllPoAssetDisbursementDetails();
				for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
						.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
					if (assetProgressDetails.getReportID().equals(reportID)) {
						PoAssetDisbursementDetails vPoAssetDisbursementDetails = new PoAssetDisbursementDetails();

						vPoAssetDisbursementDetails.setAssetCategory(assetProgressDetails.getAssetCategory());
						vPoAssetDisbursementDetails.setAssetID(assetProgressDetails.getAssetID());
						BFCurrencyAmount defaultAmount = new BFCurrencyAmount();
						defaultAmount.setCurrencyCode(bankingObject.getCurrency());
						vPoAssetDisbursementDetails.setCurrentDisbursedAmount(defaultAmount);
						BFCurrencyAmount originalAssetStudyCost = new BFCurrencyAmount();
						originalAssetStudyCost.setCurrencyCode(bankingObject.getCurrency());
						originalAssetStudyCost
								.setCurrencyAmount(assetProgressDetails.getNetCalculatedCost().getCurrencyAmount());
						vPoAssetDisbursementDetails.setOriginalAssetStudyCost(originalAssetStudyCost);
						BFCurrencyAmount originalFinalCost = new BFCurrencyAmount();
						originalFinalCost.setCurrencyCode(bankingObject.getCurrency());
						originalFinalCost.setCurrencyAmount(assetProgressDetails.getNetFinalCost().getCurrencyAmount());
						
						vPoAssetDisbursementDetails.setOriginalFinalCost(originalFinalCost);
						vPoAssetDisbursementDetails.setPendingDisbursedAmount(defaultAmount);
						vPoAssetDisbursementDetails.setPrevouslyDisbursedAmount(
								getPreviousDisbursedAmount(purchaseOrderDetails.getProgressReportID(),
										assetProgressDetails.getAssetID(), bankingObject.getCurrency()));
						BigDecimal newDisbursementAmt = assetProgressDetails.getFinalCostAfterDeduction().getCurrencyAmount().subtract(vPoAssetDisbursementDetails.getPrevouslyDisbursedAmount().getCurrencyAmount());
						vPoAssetDisbursementDetails.getCurrentDisbursedAmount().setCurrencyAmount(newDisbursementAmt);
						vPoAssetDisbursementDetails.setPurchaseOrderID(purchaseOrderID);
						vPoAssetDisbursementDetails.setSelect(false);
						issuePayOrderDtls.addPoAssetDisbursementDetails(vPoAssetDisbursementDetails);
					}
				}
				issuePayOrderDtls.removeAllCustomerLiabilitiesDtls();
				ListGenericCodeRs associationTypes = IBCommonUtils.getGCList("ASSCTYPE");
				ListGenericCodeRs relationshipTypes = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
				Map<String, String> gcCodes = new HashMap<>();
				for (GcCodeDetails gcCodeDetails : associationTypes.getGcCodeDetails()) {
					gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
				}
				for (GcCodeDetails gcCodeDetails : relationshipTypes.getGcCodeDetails()) {
					gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
				}
				IBOIB_IDI_DealCustomerDetail customerDtls = IBCommonUtils.getDealPrimaryPartyDetails(getF_IN_islamicBankingObject().getDealID());
				String partyId = customerDtls.getF_CUSTOMERID();
				ArrayList<HashMap> dealInfos = CeUtils.getDealIdsByCustomerId(partyId);
				BigDecimal liabilitytoBepaid = CommonConstants.BIGDECIMAL_ZERO;
				if (null != dealInfos && dealInfos.size() > 0) {
					for (int i = 0; i < dealInfos.size(); i++) {
						IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(
								IBOIB_DLI_DealDetails.BONAME, (String) dealInfos.get(i).get("dealId"), true);
						if (null != dealDetails && dealDetails.getF_DealAccountId() != null && !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {
							CustomerLiabilities eachCustLiab = new CustomerLiabilities();
							eachCustLiab.setDealId((String) dealInfos.get(i).get("dealId"));
							BigDecimal outstandingAmt = CeUtils.getOutstandingAmt(eachCustLiab.getDealId());
							BFCurrencyAmount bfCurrencyAmount = new BFCurrencyAmount();
							bfCurrencyAmount.setCurrencyCode(bankingObject.getCurrency());
							bfCurrencyAmount.setCurrencyAmount(outstandingAmt);
							eachCustLiab.setLiabilityAmount(bfCurrencyAmount);
							eachCustLiab.setLiabilityToBePaid(bfCurrencyAmount);
							eachCustLiab.setDealAccountID(dealDetails.getF_DealAccountId());
							eachCustLiab.setSelect(false);
							String userRoleRef = (String) dealInfos.get(i).get("userRole");
							eachCustLiab.setUserRole(gcCodes.get(userRoleRef));
							if (outstandingAmt.compareTo(BigDecimal.ZERO) > 0) {
								issuePayOrderDtls.addCustomerLiabilitiesDtls(eachCustLiab);
								liabilitytoBepaid = liabilitytoBepaid.add(outstandingAmt);
							}
						}
					}
					BFCurrencyAmount liabilitytoBePaid = new BFCurrencyAmount();
					liabilitytoBePaid.setCurrencyCode(bankingObject.getCurrency());
					liabilitytoBePaid.setCurrencyAmount(liabilitytoBepaid);
					purchaseOrderDetails.setLiabilityToBePaid(liabilitytoBePaid);
				}
				BFCurrencyAmount finalDisbursementAmount = new BFCurrencyAmount();
				finalDisbursementAmount.setCurrencyCode(bankingObject.getCurrency());
				BigDecimal initialFeesTaxAmount=BigDecimal.ZERO;
		    BigDecimal adjustmentFeesTaxAmount=BigDecimal.ZERO;
				if(null !=purchaseOrderDetails.getFeesToBePaid()){
		        initialFeesTaxAmount=CeUtils.calculateTaxOnFees(purchaseOrderDetails.getFeesToBePaid(),CeConstants.INITIAL_FEES_TAX_PERC);
		    }
		    if(null !=purchaseOrderDetails.getAdjustmentFeesToBePaid()) {
		        adjustmentFeesTaxAmount=CeUtils.calculateTaxOnFees(purchaseOrderDetails.getAdjustmentFeesToBePaid(),CeConstants.ADJUSTMENT_FEES_TAX_PERC);  
		    }
		    BigDecimal upfrontProfitamt = purchaseOrderDetails.getPoAmount().getCurrencyAmount().multiply(new BigDecimal(10)).divide(new BigDecimal(100));
				BigDecimal finalAmount = purchaseOrderDetails.getPoAmount().getCurrencyAmount()
						.subtract(purchaseOrderDetails.getAdjustmentFeesToBePaid())
						.subtract(purchaseOrderDetails.getTawarooqCommision())
						.subtract(purchaseOrderDetails.getFeesToBePaid())
						.subtract(purchaseOrderDetails.getUpfrontProfitToBePaid())
						.subtract(purchaseOrderDetails.getLiabilityToBePaid().getCurrencyAmount())
						.subtract(initialFeesTaxAmount)
	          .subtract(adjustmentFeesTaxAmount);
				finalDisbursementAmount.setCurrencyAmount(finalAmount);
				purchaseOrderDetails.setFinalDisbursementAmount(finalDisbursementAmount );
				issuePayOrderDtls.removeAllPaymentDetails();
			} else if (CeUtils.checkIfCooperativeParty(getF_IN_islamicBankingObject().getDealID())
					&& getF_IN_issuePayOrderDtls().getPurchaseOrderDetailsCount() == CommonConstants.INTEGER_ZERO) {
				purchaseOrderDetails.setProgressReportID("AdvancePayment");
				BigDecimal cooperativeAssPartyPerc =new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
						CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.CO_OPERATIVE_ASSOCIATION_PERCENTAGE, "",
						CeConstants.ADFIBCONFIGLOCATION));
				issuePayOrderDtls.removeAllCustomerLiabilitiesDtls();
				issuePayOrderDtls.removeAllPoAssetDisbursementDetails();
				issuePayOrderDtls.removeAllPaymentDetails();
				AssetInfoAndStudyFatom assetAndStudyFatom = new AssetInfoAndStudyFatom(env);
				assetAndStudyFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
				assetAndStudyFatom.setF_IN_mode("READ");
				assetAndStudyFatom.process(env);
				AssetThirdPartyDetails[] assetTPDetails = assetAndStudyFatom.getF_OUT_assetThirdPartyDetailsList()
						.getAssetThirdPartyDetails();
				for (AssetThirdPartyDetails assetThirdPartyDetails : assetTPDetails) {
					if (null != assetThirdPartyDetails.isReplaced() && !assetThirdPartyDetails.isReplaced()) {
						
						BigDecimal assetCost = assetThirdPartyDetails.getFinalCost().getCurrencyAmount()
								.multiply(cooperativeAssPartyPerc).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
						PoAssetDisbursementDetails vPoAssetDisbursementDetails = new PoAssetDisbursementDetails();

						vPoAssetDisbursementDetails.setAssetCategory(assetThirdPartyDetails.getAssetCategory());
						vPoAssetDisbursementDetails.setAssetID(assetThirdPartyDetails.getAssetSerial());
						BFCurrencyAmount defaultAmount = new BFCurrencyAmount();
						defaultAmount.setCurrencyCode(bankingObject.getCurrency());
						vPoAssetDisbursementDetails.setCurrentDisbursedAmount(defaultAmount);
						BFCurrencyAmount originalAssetStudyCost = new BFCurrencyAmount();
						originalAssetStudyCost.setCurrencyCode(bankingObject.getCurrency());
						originalAssetStudyCost.setCurrencyAmount(assetCost);
						vPoAssetDisbursementDetails.setOriginalAssetStudyCost(originalAssetStudyCost);
						BFCurrencyAmount originalFinalCost = new BFCurrencyAmount();
						originalFinalCost.setCurrencyCode(bankingObject.getCurrency());
						originalFinalCost.setCurrencyAmount(assetCost);

						vPoAssetDisbursementDetails.setOriginalFinalCost(originalFinalCost);
						vPoAssetDisbursementDetails.setPendingDisbursedAmount(defaultAmount);
						vPoAssetDisbursementDetails.setPrevouslyDisbursedAmount(defaultAmount);
						vPoAssetDisbursementDetails.getCurrentDisbursedAmount().setCurrencyAmount(assetCost);
						vPoAssetDisbursementDetails.setPurchaseOrderID(purchaseOrderID);
						vPoAssetDisbursementDetails.setSelect(false);
						issuePayOrderDtls.addPoAssetDisbursementDetails(vPoAssetDisbursementDetails);
						prAmount = prAmount.add(assetCost);
					}
				}
				BFCurrencyAmount progressReportAmount = new BFCurrencyAmount();
				progressReportAmount.setCurrencyAmount(prAmount);
				progressReportAmount.setCurrencyCode(bankingObject.getCurrency());
				purchaseOrderDetails.setProgressReportAmount(progressReportAmount);
				purchaseOrderDetails.setPoAmount(progressReportAmount);
				purchaseOrderDetails.setFinalDisbursementAmount(progressReportAmount);
			}else {
				issuePayOrderDtls.removeAllPoAssetDisbursementDetails();
				issuePayOrderDtls.removeAllCustomerLiabilitiesDtls();
				issuePayOrderDtls.removeAllPaymentDetails();
			}
			
			
		} else {
			IssuePayOrderDtls payOrderDtls= getF_IN_issuePayOrderDtls();
			//purchaseOrderID
			issuePayOrderDtls.removeAllCustomerLiabilitiesDtls();
			issuePayOrderDtls.removeAllPaymentDetails();
			issuePayOrderDtls.removeAllPoAssetDisbursementDetails();
			for(PoAssetDisbursementDetails poAssetDisbursementDetails:payOrderDtls.getPoAssetDisbursementDetails()) {
				if(poAssetDisbursementDetails.getPurchaseOrderID().equals(purchaseOrderID)) {
					issuePayOrderDtls.addPoAssetDisbursementDetails(poAssetDisbursementDetails);
				}
			}
			for(CustomerLiabilities customerLiabilities:payOrderDtls.getCustomerLiabilitiesDtls()) {
				if(customerLiabilities.getPurchaseOrderID().equals(purchaseOrderID)) {
					issuePayOrderDtls.addCustomerLiabilitiesDtls(customerLiabilities);
				}
			}
			for(PaymentDetails paymentDetails:payOrderDtls.getPaymentDetails()) {
				if(paymentDetails.getPurchaseOrderID().equals(purchaseOrderID)) {
					issuePayOrderDtls.addPaymentDetails(paymentDetails);
				}
				
			}
		}

	}

	

	private BFCurrencyAmount getPreviousDisbursedAmount(String progressReportID, String assetID,String currency) {
		BigDecimal previousDisbursedAmount = CommonConstants.BIGDECIMAL_ZERO;
		BFCurrencyAmount amount = new BFCurrencyAmount();
		
		ArrayList<String> params = new ArrayList();
		params.add(progressReportID);
		List<IBOCE_IB_IssuePODetail> progressReport = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_IssuePODetail.BONAME, WHERE_CLAUSE_POS_FOR_SAME_REPORT, params, null);
		for (IBOCE_IB_IssuePODetail iboce_IB_IssuePODetail : progressReport) {
			params.clear();
			params.add(iboce_IB_IssuePODetail.getF_IBPURCHASEORDERID());
			params.add(assetID);
			List<IBOCE_IB_IssuePOAssetDetail> poAssetProgress = IBCommonUtils.getPersistanceFactory()
					.findByQuery(IBOCE_IB_IssuePOAssetDetail.BONAME, WHERE_PO_ASSETS_FOR_SAME_REPORT, params, null);
			for (IBOCE_IB_IssuePOAssetDetail iboce_IB_IssuePOAssetDetail : poAssetProgress) {
				previousDisbursedAmount = previousDisbursedAmount.add(iboce_IB_IssuePOAssetDetail.getF_IBAMOUNT());
			}
		}
		amount.setCurrencyAmount(previousDisbursedAmount);
		amount.setCurrencyCode(currency);
		return amount;
	}

	/*private BigDecimal getOutstandingAmt(String dealId) {

		BigDecimal outstandingAmt = BigDecimal.ZERO;
		ReadLoanDetailsRs readLoanRs = null;
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| IBCommonUtils.getBFBusinessDate().equals(row.getRepaymentDate())) {
						PaymentSchedule paymentSchedule = new PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						outstandingAmt = outstandingAmt.add(paymentSchedule.getRepaymentAmt());

					}
				}
			}

			// outstandingAmt =
			// readLoanRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount();

			for (LoanPayments paymentSch : readLoanRs.getDealDetails().getPaymentSchedule()) {
				if (paymentSch.getRepaymentDate().equals(IBCommonUtils.getBFBusinessDate())
						&& paymentSch.getRepaymentAmtUnPaid().compareTo(BigDecimal.ZERO) > 0) {
					EarlyAssetPayoffUtils assetPayoffUtils = new EarlyAssetPayoffUtils();
					List<IBOCE_IB_EarlyAssetPayoffDtls> earlyAssetDtls = assetPayoffUtils
							.getReschReqExistingObjStatusCompleted(dealId);
					if (null != earlyAssetDtls && earlyAssetDtls.size() > 0) {
						Timestamp earlyAssetDate = earlyAssetDtls.get(0).getF_IBRECLASTMODIFIEDDATE();
						if (earlyAssetDate.equals(IBCommonUtils.getBFBusinessDateTime())) {
							outstandingAmt = outstandingAmt.add(paymentSch.getRepaymentAmtUnPaid());
						}
					}
				}
			}
		}
		return IBCommonUtils.scaleAmount(getF_IN_islamicBankingObject().getCurrency(), outstandingAmt);
	}*/

	/*private ArrayList getDealIdsByCustomerId(IslamicBankingObject islamicBankingObject) {

		ArrayList dealInfos = new ArrayList<>();
		List<String> relationshipTypeslist = new ArrayList<>();
		String dealId = islamicBankingObject.getDealID();
		IBOIB_IDI_DealCustomerDetail customerDtls = IBCommonUtils.getDealPrimaryPartyDetails(dealId);
		String partyId = customerDtls.getF_CUSTOMERID();
		ArrayList params = new ArrayList();
		params.add(partyId);
		List<IBOIB_IDI_DealCustomerDetail> customerDeals = (List<IBOIB_IDI_DealCustomerDetail>) factory
				.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, GET_DEALID_BY_CUST, params, null, true);
		if (null != customerDeals && customerDeals.size() > 0) {
			for (int i = 0; i < customerDeals.size(); i++) {
				HashMap dealDtls = new HashMap<>();
				String userRole = customerDeals.get(i).getF_ASSOCIATIONTYPE();
				String eachDealIdByCustomer = customerDeals.get(i).getF_DEALID();

				dealDtls.put("userRole", userRole);
				dealDtls.put("dealId", eachDealIdByCustomer);
				dealInfos.add(dealDtls);
			}
		}
		String relationshipTypes = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.RELATIONSHIP_TYPES_CONF_FILE, CeConstants.RELATIONSHIP_TYPES, "",
				CeConstants.ADFIBCONFIGLOCATION);

		if (relationshipTypes != null && !relationshipTypes.isEmpty()) {
			relationshipTypeslist = IBCommonUtils.isNotEmpty(relationshipTypes)? Arrays.asList(relationshipTypes.split(",")): new ArrayList<String>();
		}
		List<IBOCE_IB_DealRelationshipDetails> dealsFromRelationship = (List<IBOCE_IB_DealRelationshipDetails>) factory
				.findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, GET_DEALID_FROM_RELATIONSHIP, params, null, true);
		for (IBOCE_IB_DealRelationshipDetails iboce_IB_DealRelationshipDetails : dealsFromRelationship) {
			if (relationshipTypeslist.contains(iboce_IB_DealRelationshipDetails.getF_IBRELATIONSHIPTYPE())) {
				HashMap dealDtls = new HashMap<>();
				String userRole = iboce_IB_DealRelationshipDetails.getF_IBRELATIONSHIPTYPE();
				String eachDealIdByCustomer = iboce_IB_DealRelationshipDetails.getF_IBDEALID();

				dealDtls.put("userRole", userRole);
				dealDtls.put("dealId", eachDealIdByCustomer);
				dealInfos.add(dealDtls);
			}
		}
		return dealInfos;
	}*/
}
