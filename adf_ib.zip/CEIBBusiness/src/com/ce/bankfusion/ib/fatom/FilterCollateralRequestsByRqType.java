package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FilterCollateralRequestsByRqType;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_FilterCollateralRequestsByRqType;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CreateCollateralRqDetails;

public class FilterCollateralRequestsByRqType extends AbstractCE_IB_FilterCollateralRequestsByRqType
        implements ICE_IB_FilterCollateralRequestsByRqType {
    public FilterCollateralRequestsByRqType() {
        // TODO Auto-generated constructor stub
    }

    public FilterCollateralRequestsByRqType(BankFusionEnvironment env) {
        super(env);

    }

    private static final transient Log LOGGER = LogFactory.getLog(GetLatestTitleDeedDetailsOfCollateral.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method DealId -->" + getF_IN_ibObject().getDealID() + "Request Type-->"
                + getF_IN_RequestTypeFilter());
        getCollaterRequestsByRequestType();
        LOGGER.info("Exiting from process method DealId -->" + getF_IN_ibObject().getDealID() + "Request Type-->"
                + getF_IN_RequestTypeFilter());

    }

    private void getCollaterRequestsByRequestType() {
        LOGGER.info("Entering into getCollateralRequestDetails method-->" + getF_IN_ibObject().getDealID());
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + "= ? ");
        ArrayList<String> params = new ArrayList<String>();
        prepareQuery(queryCondition, params);
        queryCollateralReqDetails(queryCondition, params);
        LOGGER.info("Exiting from getCollateralRequestDetails method-->" + getF_IN_ibObject().getDealID());
    }

    private void prepareQuery(StringBuffer queryCondition, ArrayList<String> params) {
        params.add(getF_IN_ibObject().getDealID());
        if(IBCommonUtils.isNotEmpty(getF_IN_RequestTypeFilter()))
        {
            queryCondition.append(" AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTTYPE + " = ? ");
            params.add(getF_IN_RequestTypeFilter());
        }
        for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralRqDetailsList()
                .getCreateCollateralRqDetailsList()) {
            if (IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID())/* && !createCollateralRqDetails.isSelect()*/) {
                queryCondition.append(" AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTID + " != ? ");
                params.add(createCollateralRqDetails.getRequestID());
            }
        }
    }

    private void queryCollateralReqDetails(StringBuffer queryCondition, ArrayList<String> params) {
        List<IBOCE_IB_CollateralRevaluationDetails> createRequestCollateralDetails = (List<IBOCE_IB_CollateralRevaluationDetails>) factory
                .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, queryCondition.toString(), params, null, false);
        getF_OUT_collateralRequestDetailsList().removeAllCollateralRequestDetailsList();
        if (null != createRequestCollateralDetails && !createRequestCollateralDetails.isEmpty()) {
            for (IBOCE_IB_CollateralRevaluationDetails reqCollateralDtls : createRequestCollateralDetails) {
                CollateralRequestDetails collateralRequestDetails = new CollateralRequestDetails();
                collateralRequestDetails.setRequestID(reqCollateralDtls.getBoID());
                BFCurrencyAmount availableAmt = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBAVAILABLEBALANCE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setAvailableBalance(availableAmt);
                collateralRequestDetails.setCategoryType(reqCollateralDtls.getF_IBCATEGORYTYPE());
                // collateralRequestDetails.setCollateralID(reqCollateralDtls.getF_COLLATERALID());
                BFCurrencyAmount coverValue = IBCommonUtils.getBFCurrencyAmount(reqCollateralDtls.getF_IBCOVERVALUE(),
                        getF_IN_ibObject().getCurrency());
                collateralRequestDetails.setCoverValue(coverValue);
                collateralRequestDetails.setDescription(reqCollateralDtls.getF_IBDESCRIPTION());
                collateralRequestDetails.setRequestType(reqCollateralDtls.getF_IBREQUESTTYPE());
                collateralRequestDetails.setTitleDeedIDPK(reqCollateralDtls.getF_IBTITLEDEEDIDPK());
                collateralRequestDetails.setTitleDeedNum(reqCollateralDtls.getF_IBTITLEDEEDNUM());
				ListGenericCodeRs lsGenericCodesReq = IBCommonUtils.getGCList("REQ_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesReq.getGcCodeDetails()) {
					if (reqCollateralDtls.getF_IBREQUESTTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setRequestTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}
				ListGenericCodeRs lsGenericCodesCat = IBCommonUtils.getGCList("CATEGORY_TYP");
				for (GcCodeDetail gcCode : lsGenericCodesCat.getGcCodeDetails()) {
					if (reqCollateralDtls.getF_IBCATEGORYTYPE().equals(gcCode.getCodeReference())) {
						collateralRequestDetails.setCategoryTypeDesc(gcCode.getCodeDescription());
						break;
					}
				}

                collateralRequestDetails.setSelect(false);
                getF_OUT_collateralRequestDetailsList().addCollateralRequestDetailsList(collateralRequestDetails);
            }
        }
    }

}
