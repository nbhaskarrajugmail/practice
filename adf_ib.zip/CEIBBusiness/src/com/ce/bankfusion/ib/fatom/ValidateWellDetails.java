package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalWell;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateWellDetails;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;

public class ValidateWellDetails extends AbstractCE_IB_ValidateWellDetails {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final transient Log LOG = LogFactory.getLog(SaveTechAreaDtls.class.getName());
	private static final int INVALID_OLD_CONTRACT_ID = 44000236;
	private static final int COORDINATES_MANDATARY_FOR_SELECTED_WELSTATUS = 44000238;
	private static final int INVALID_COMBINATION_CONTRACT_ID_SERNO = 44000237;
	private static final String whereQuery = " WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " =?";
	private static final String whereWellQuery = " WHERE " + IBOCE_IB_TechnicalWell.IBREFERENCENUMBER + " =?";

	public ValidateWellDetails(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		TechnicalWellDtl technicalWellDtl = getF_IN_TechnicalWellDtl();
		String dealID = technicalWellDtl.getOldContractID();
		boolean isSerialNoValid = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		if (!dealID.equals(CommonConstants.EMPTY_STRING)) {
			IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
					.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
			if (dealDetails == null) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(INVALID_OLD_CONTRACT_ID, new Object[] {},
						LOG, env);
			}
		}
		if (!technicalWellDtl.getOldBranchCode().equals(CommonConstants.EMPTY_STRING)) {
			int serialNo = Integer.parseInt(technicalWellDtl.getOldBranchCode());
			ArrayList<String> param = new ArrayList<>();
			param.add(dealID);
			List<IBOCE_IB_TechnicalFarm> farmDtls = (ArrayList<IBOCE_IB_TechnicalFarm>) IBCommonUtils
					.getPersistanceFactory().findByQuery(IBOCE_IB_TechnicalFarm.BONAME, whereQuery, param, null, true);
			for (IBOCE_IB_TechnicalFarm iboce_IB_TechnicalFarm : farmDtls) {
				ArrayList<String> wellParam = new ArrayList<>();
				wellParam.add(iboce_IB_TechnicalFarm.getBoID());
				List<IBOCE_IB_TechnicalWell> wellDtls = (ArrayList<IBOCE_IB_TechnicalWell>) IBCommonUtils
						.getPersistanceFactory()
						.findByQuery(IBOCE_IB_TechnicalWell.BONAME, whereWellQuery, wellParam, null, true);
				for (IBOCE_IB_TechnicalWell iboce_IB_TechnicalWell : wellDtls) {
					if (serialNo == iboce_IB_TechnicalWell.getF_IBSERIALNUMBER()) {
						isSerialNoValid = true;
					}
				}
			}
			if (!isSerialNoValid) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(INVALID_COMBINATION_CONTRACT_ID_SERNO,
						new Object[] {}, LOG, env);
			}
		}
		
		String wellStatus = technicalWellDtl.getWellStatus();
		if (wellStatus.equals("1") && ((technicalWellDtl.getEastCoordinate() == null)
				|| (technicalWellDtl.getEastCoordinateO() == null) || (technicalWellDtl.getNorthCoordinate() == null)
				|| (technicalWellDtl.getNorthCoordinateO() == null))) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(COORDINATES_MANDATARY_FOR_SELECTED_WELSTATUS,
					new Object[] {}, LOG, env);
		}

	}
}
