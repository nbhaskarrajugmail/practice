package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetPartyNationalId;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class GetPartyNationalId extends AbstractCE_IB_GetPartyNationalId {

	private static final Log LOGGER = LogFactory.getLog(GetPartyNationalId.class);

	private static final String FIND_PARTY_PERSONAL_DET = "WHERE " + IBOPT_PFN_PersonalDetails.INTERNALPARTYID + " = ?";

	public GetPartyNationalId(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		ArrayList<String> params = new ArrayList<String>();
		params.add(getF_IN_partyId());
		List<IBOPT_PFN_PersonalDetails> partyPersonalDetails = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_PARTY_PERSONAL_DET, params, null, true);
		if (partyPersonalDetails != null)
			setF_OUT_partyNationalId(partyPersonalDetails.get(0).getF_NATIONALID());

	}
}
