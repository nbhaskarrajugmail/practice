/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: DealInitiationLoadHeaderData.java,v.1.0,Oct 27, 2014 2:21:41 PM Aklesh S
 *
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ConfigureSearchPage;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_InquiryProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_CMN_DealInitiationHeaderData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.IslamicProcesses.Processes;
import com.trapedza.bankfusion.core.BFCurrencyValue;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFImage;

public class CEDealInitiationLoadHeaderData extends AbstractIB_CMN_DealInitiationHeaderData {

	private static final long serialVersionUID = 1L;

	transient IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	private static final String NEW = "NEW";

	private static final String DEALSTATUS = "DEALSTATUS";

	private String statusDesc = CommonConstants.EMPTY_STRING;

	public CEDealInitiationLoadHeaderData() {
	}

	public CEDealInitiationLoadHeaderData(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		String correlationId = getF_IN_corelationID();
		String[] splitted = PanelUtils.splitGUID(correlationId);
		String dealID = splitted[2];
		String searchPageID = splitted[3];
		IBOCE_IB_DealReschedule dealReschObj = null;
		IBOIB_DLI_DealDetails dealDetails;
		String parentDealNumber = getF_IN_parentDealID();

		setDefaultOuput(searchPageID, dealID);

		dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
		if (dealDetails != null) {
			setHeaderFromDealDet(dealDetails);
		} else {
			IBOIB_IDI_DealCustomerDetail dealCustomerDetail = null;

			if (IBCommonUtils.isNotEmpty(parentDealNumber)) {
				dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(parentDealNumber);

				if (null != dealCustomerDetail) {
					setF_OUT_customerName(PanelUtils.readPartyDetails(dealCustomerDetail.getF_CUSTOMERID()));
				}
			}
		}

		dealReschObj = RescheduleUtils.getReschReqExistingObjStatusNotCompleted(dealID);
		if ((dealReschObj != null) && (dealDetails != null)) {
			setHeaderFromDealReschedule(dealReschObj, dealDetails);
		}

		isWhatIfProcess(correlationId);

	}

	private void setDefaultOuput(String searchPageID, String dealID) {
		String searchAction = CommonConstants.EMPTY_STRING;
		IBOIB_CFG_ConfigureSearchPage searchPage = (IBOIB_CFG_ConfigureSearchPage) factory
				.findByPrimaryKey(IBOIB_CFG_ConfigureSearchPage.BONAME, searchPageID, true);
		if (searchPage != null) {
			searchAction = searchPage.getF_ACTION();
		}

		if (!(searchAction.equals(Processes.PAYTOTHIRDPARTY.toString()) || (searchPageID.equals(IBConstants.STANDALONE)
				&& CommonConstants.EMPTY_STRING.equals(searchAction)))) {
			setF_OUT_dealId(dealID);
		} else {
			String resultSchema = CommonConstants.EMPTY_STRING;
			setF_OUT_dealId(CommonConstants.EMPTY_STRING);
			if (null != searchPage) {
				IBOIB_CFG_InquiryProfile inquiryProfile = ((IBOIB_CFG_InquiryProfile) factory
						.findByPrimaryKey(IBOIB_CFG_InquiryProfile.BONAME, searchPage.getF_RESULTPROFILEID(), true));
				if (null != inquiryProfile)
					resultSchema = inquiryProfile.getF_RESULTSCHEMA();
			}
			if (searchAction.equals(Processes.PAYTOTHIRDPARTY.toString()) && !(resultSchema.equals("THIRD PARTY"))) {
				setF_OUT_dealId(dealID);
			}

		}

		BFImage custImage = new BFImage();
		custImage.setImageContent(PanelUtils.imagetoByteArray(getF_IN_imageLocation()));
		setF_OUT_customerImage(custImage);
		statusDesc = PanelUtils.getCodeDescr(NEW, DEALSTATUS);
		if (!(searchPageID.equals(IBConstants.STANDALONE) && CommonConstants.EMPTY_STRING.equals(searchAction))) {
			setF_OUT_status(statusDesc);
		}
		setF_OUT_dealAmount(null);
		setF_OUT_dealBranch(CommonConstants.EMPTY_STRING);
		setF_OUT_newStartDate(null);
		setF_OUT_newEndDate(null);
		setF_OUT_productID(CommonConstants.EMPTY_STRING);
		setF_OUT_remainingPrincipal(null);
		setF_OUT_remainingProfit(null);
		setF_OUT_subProductID(CommonConstants.EMPTY_STRING);
		setF_OUT_tenor(null);
		setF_OUT_customerName(CommonConstants.EMPTY_STRING);
	}

	private void setHeaderFromDealDet(IBOIB_DLI_DealDetails dealDetails) {

		IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils
				.getDealPrimaryPartyDetails(dealDetails.getBoID());

		if (null == dealCustomerDetail && IBCommonUtils.isNotEmpty(dealDetails.getF_ParentDealNo())) {
			dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(dealDetails.getF_ParentDealNo());
		}

		if (null != dealCustomerDetail) {
			setF_OUT_customerName(PanelUtils.readPartyDetails(dealCustomerDetail.getF_CUSTOMERID()));
		}

		if ((dealDetails.getF_DealAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
			BFCurrencyValue curr = new BFCurrencyValue(dealDetails.getF_IsoCurrencyCode(), dealDetails.getF_DealAmt(),
					BankFusionThreadLocal.getUserId());
			setF_OUT_dealAmount(curr.getRoundedAmount());
		}

		String branchDesc = PanelUtils.readBranchDetails(dealDetails.getF_BranchSortCode());
		setF_OUT_dealBranch(branchDesc);
		setF_OUT_newStartDate(dealDetails.getF_DealStartDate());
		if ((dealDetails.getF_LastRepaymentDate())
				.compareTo(dealDetails.getF_DealStartDate()) > CommonConstants.INTEGER_ZERO) {
			setF_OUT_newEndDate(dealDetails.getF_LastRepaymentDate());
		}
		setF_OUT_productID(
				PanelUtils.getCodeDescr(dealDetails.getF_ProductCode(), DealInitiationConstants.PRODUCTNAME));
		if ((dealDetails.getF_PrincipleAmt())
				.compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
			BFCurrencyValue curr = new BFCurrencyValue(dealDetails.getF_IsoCurrencyCode(),
					dealDetails.getF_PrincipleAmt(), BankFusionThreadLocal.getUserId());
			setF_OUT_remainingPrincipal(curr.getRoundedAmount());
		}
		if ((dealDetails.getF_DealTerm()) > CommonConstants.INTEGER_ZERO || (dealDetails.getF_ProfitAmt())
				.compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
			BFCurrencyValue curr = new BFCurrencyValue(dealDetails.getF_IsoCurrencyCode(), dealDetails.getF_ProfitAmt(),
					BankFusionThreadLocal.getUserId());
			setF_OUT_remainingProfit(curr.getRoundedAmount());
		}
		setF_OUT_status(dealDetails.getF_Status().equals(CommonConstants.EMPTY_STRING) ? statusDesc
				: PanelUtils.getCodeDescr(dealDetails.getF_Status(), DEALSTATUS));

		String multiLangSubProductName = PanelUtils.getSubProductDescription(dealDetails.getF_ProductCode(),
				dealDetails.getF_ProductContextCode());
		setF_OUT_subProductID(multiLangSubProductName);
		if ((dealDetails.getF_DealTerm()) > CommonConstants.INTEGER_ZERO) {
			int term = dealDetails.getF_DealTerm();
			String monthsAndDays = CalendarUtil
					.getPeriodDurationInString(dealDetails.getF_DEALEFFECTIVEDT(), dealDetails.getF_LastRepaymentDate())
					.toString();
			setF_OUT_tenor(term);
			setF_OUT_TenorString(monthsAndDays);
		}
		setF_OUT_dealCurrency(dealDetails.getF_IsoCurrencyCode());

	}

	private void isWhatIfProcess(String correlationId) {
		String[] configuration = PanelUtils.splitGUID(correlationId);
		String processConfigID = configuration[1];
		IBOIB_CFG_ProcessConfig processConfig = IBCommonUtils.getProcessConfigByPrimaryKey(processConfigID);
		String procesName = processConfig.getF_PROCESSTYPE();
		if (procesName.equalsIgnoreCase("WHATIF")) {

			setF_OUT_isWhatIf(true);
		}
	}

	private void setHeaderFromDealReschedule(IBOCE_IB_DealReschedule dealReschObj, IBOIB_DLI_DealDetails dealDetails) {
		BigDecimal deltaProfitAmnt = CommonConstants.BIGDECIMAL_ZERO, newProfitAmnt = CommonConstants.BIGDECIMAL_ZERO,
				dealAmnt = CommonConstants.BIGDECIMAL_ZERO;

		deltaProfitAmnt = dealReschObj.getF_IBSCHEDULEFEES();
		newProfitAmnt = dealDetails.getF_ProfitAmt().add(deltaProfitAmnt);
		dealAmnt = dealDetails.getF_PrincipleAmt().add(newProfitAmnt);

		if (deltaProfitAmnt
				.compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
			BFCurrencyValue curr = new BFCurrencyValue(dealDetails.getF_IsoCurrencyCode(), newProfitAmnt,
					BankFusionThreadLocal.getUserId());
			setF_OUT_remainingProfit(curr.getRoundedAmount());
		}

		if ((dealReschObj.getF_IBRESCHINSTALLMENTS()) > CommonConstants.INTEGER_ZERO) {
			String monthsAndDays = CalendarUtil
					.getPeriodDurationInString(dealDetails.getF_DEALEFFECTIVEDT(), dealReschObj.getF_IBMATURITYDATE())
					.toString();
			setF_OUT_TenorString(monthsAndDays);
		}

		if (!CalendarUtil.isDateNullOrDefaultDate(dealReschObj.getF_IBMATURITYDATE())) {
			setF_OUT_newEndDate(dealReschObj.getF_IBMATURITYDATE());
		}

		if ((dealDetails.getF_DealAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
			BFCurrencyValue curr = new BFCurrencyValue(dealDetails.getF_IsoCurrencyCode(), dealAmnt,
					BankFusionThreadLocal.getUserId());
			setF_OUT_dealAmount(curr.getRoundedAmount());
		}
	}
}