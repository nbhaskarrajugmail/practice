package com.ce.bankfusion.ib.fatom;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_getDealCustomerAdditionalInfo;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOUDFEXTPT_PFN_PartyHostExtn;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ib.types.CeDealCustomerInfo;

public class getDealCustomerAdditionalInfo extends AbstractCE_IB_getDealCustomerAdditionalInfo {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(getDealCustomerAdditionalInfo.class);

	public getDealCustomerAdditionalInfo(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		String partyId = getF_IN_partyId();
		CeDealCustomerInfo dealCustInfo = new CeDealCustomerInfo();
		
		boolean freezeStatusFlag = false;
		String freezeReason = StringUtils.EMPTY;
		String financialStatus = StringUtils.EMPTY;
		String documentNumber = StringUtils.EMPTY;
		String documentDate = StringUtils.EMPTY;
		String freezeNotes = StringUtils.EMPTY;
		
		String adfEmployee = StringUtils.EMPTY;
		String customerAge = StringUtils.EMPTY;
		
		boolean validate_DEALINIT = false;
		boolean validate_REQACTIVATE = false;
		boolean validate_INITTECHANALYSIS = false;
		boolean validate_STUDY = false;
		boolean validate_GRANTAPPROVAL = false;
		boolean validate_SIGNCONTRACT = false;
		boolean validate_ASSETPROGRESS = false;
		boolean validate_RelationShipInfo = false;
		
		if(null != partyId && !partyId.equals(StringUtils.EMPTY)) {
					
					try {
						
						// set the factory connection
						IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
						// Filter Query
						String whereClause = " WHERE PTINTERNALPARTYID = ?";
						// Add Parameters
						ArrayList<String> queryParams = new ArrayList<String>();
						queryParams.add(partyId);
						
						List<IBOPT_PFN_PersonalDetails> partyPersonalDtls = factory
								.findByQuery(IBOPT_PFN_PersonalDetails.BONAME, whereClause, queryParams, null, true);
						
						ListGenericCodeRs adfJobTitleGCList = IBCommonUtils.getGCList(CeConstants.ADF_JOBTITLE_PARENT);

						for (IBOPT_PFN_PersonalDetails personalDtls : partyPersonalDtls) {
						if (adfJobTitleGCList != null && adfJobTitleGCList.getGcCodeDetailsCount() > 0) {
							for (GcCodeDetail gcCodeDetail : adfJobTitleGCList.getGcCodeDetails()) {
								
								if(personalDtls.getF_NATIONALID().equalsIgnoreCase(gcCodeDetail.getCodeReference()))
									adfEmployee = gcCodeDetail.getCodeDescription();
								}
							if(!IBCommonUtils.isNullOrEmpty(adfEmployee)) {
								adfEmployee="Yes";
							}
						}
						
						LOGGER.info("DOB of Customer in Hijri "+personalDtls.getF_DATEOFBIRTH());
						LOGGER.info("Current Date in Hijri "+IBCommonUtils.getBFBusinessDate());
						
						Date birthdate = personalDtls.getF_DATEOFBIRTH();
						Date dob = new Date();
						dob.setDate(birthdate.getDate());
						dob.setMonth(birthdate.getMonth());
						dob.setYear(birthdate.getYear());
						LocalDate localDate = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

						HijrahDate hdate = HijrahChronology.INSTANCE
								.date(LocalDate.of(localDate.getYear(), localDate.getMonth(), localDate.getDayOfMonth()));
						
						Date today = new Date();
						today.setDate(IBCommonUtils.getBFBusinessDate().getDate());
						today.setMonth(IBCommonUtils.getBFBusinessDate().getMonth());
						today.setYear(IBCommonUtils.getBFBusinessDate().getYear());
						LocalDate localDate1 = today.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

						HijrahDate hdatetoday = HijrahChronology.INSTANCE
								.date(LocalDate.of(localDate1.getYear(), localDate1.getMonth(), localDate1.getDayOfMonth()));
						
						 LOGGER.info("DOB of Customer in Hijri "+hdate);
						 LOGGER.info("Current Date in Hijri "+hdatetoday);
						 
						 DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
						 
						 Date dobDate = new SimpleDateFormat("yyyy-MM-dd").parse(hdate.format(FOMATTER).toString());
						 
						 Date todayDate = new SimpleDateFormat("yyyy-MM-dd").parse(hdatetoday.format(FOMATTER).toString());
					
						 LOGGER.info("DOB of Customer in Hijri "+dobDate);
						 LOGGER.info("Current Date in Hijri "+todayDate);
						
						customerAge = String.valueOf(calculateAge(dobDate, todayDate));
						}
						
						if(adfEmployee.equalsIgnoreCase(StringUtils.EMPTY)) {
							adfEmployee = "No";
						}

						List<IBOUDFEXTPT_PFN_PartyHostExtn> partyHostExtnDetailsUD = factory
								.findByQuery(IBOUDFEXTPT_PFN_PartyHostExtn.BONAME, whereClause, queryParams, null, true);
						String freezeStatus = StringUtils.EMPTY;
						
						String freezeStatus_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STATUS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeDealInit_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_DEALINIT, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeReqActivate_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_REQACTIVATE, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeInitTechAnalysis_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_INITTECHANALYSIS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeStudy_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_STUDY, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeGrantApproval_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_GRANTAPPROVAL, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeSignContract_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_SIGNCONTRACT, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeAssetProgress_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_STEP_ASSETPROGRESS, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeRelationInfo_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_BB_RELATIONINFO, "", CeConstants.ADFIBCONFIGLOCATION);
						
						String freezeReason_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_REASON, "", CeConstants.ADFIBCONFIGLOCATION);
						String financialStatus_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_FINANCIAL_STATUS, "", CeConstants.ADFIBCONFIGLOCATION);
						String documentNumber_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_DOCNUMBER, "", CeConstants.ADFIBCONFIGLOCATION);
						String documentDate_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_DOCDATE, "", CeConstants.ADFIBCONFIGLOCATION);
						String freezeNotes_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
								CeConstants.UDFPROPERTY, CeConstants.FREEZE_NOTES, "", CeConstants.ADFIBCONFIGLOCATION);
						
						
						// process the results
						for (IBOUDFEXTPT_PFN_PartyHostExtn partyHostExtnDlsUD : partyHostExtnDetailsUD) {
							UserDefinedFields userDefinedFields = partyHostExtnDlsUD.getUserDefinedFields();
							if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
								for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
									
									if (userDefinedFld.getFieldName().equals(freezeStatus_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										freezeStatus = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeReason_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										freezeReason = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(financialStatus_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										financialStatus = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(documentNumber_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										documentNumber = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(documentDate_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										documentDate = userDefinedFld.getFieldValue().toString();
									}
									if (userDefinedFld.getFieldName().equals(freezeNotes_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										freezeNotes = userDefinedFld.getFieldValue().toString();
									}
									
									
									if (userDefinedFld.getFieldName().equals(freezeDealInit_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_DEALINIT = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeReqActivate_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_REQACTIVATE = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeInitTechAnalysis_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_INITTECHANALYSIS = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeStudy_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_STUDY = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeGrantApproval_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_GRANTAPPROVAL = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeSignContract_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_SIGNCONTRACT = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeAssetProgress_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_ASSETPROGRESS = (boolean)userDefinedFld.getFieldValue();
									}
									if (userDefinedFld.getFieldName().equals(freezeRelationInfo_udf)) {
										if(userDefinedFld.getFieldValue()!=null)
										validate_RelationShipInfo = (boolean)userDefinedFld.getFieldValue();
									}
																	
								}
							}
						}
						
						if(freezeStatus.equalsIgnoreCase("Yes")) {
							
							freezeStatusFlag = true;
							
						}
						
					} catch (Exception se) {
						try {
							throw se;
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
			
		}
		ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("BOOLEANYESNO");
    
        for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
            String check = null;
            if(adfEmployee.equals("Yes")) {
                check = "true";
            }else {
                check = "false";
            }
        if(check.equals(gcCode.getCodeReference())){
            dealCustInfo.setAdfEmployee(gcCode.getCodeDescription());
            break;
            }
        
    }
		//dealCustInfo.setAdfEmployee(adfEmployee);
		dealCustInfo.setCustomerAge(customerAge);
		dealCustInfo.setDocDate(documentDate);
		dealCustInfo.setDocNumber(documentNumber);
		dealCustInfo.setFinancialStatus(financialStatus);
		dealCustInfo.setFreezeNotes(freezeNotes);
		dealCustInfo.setFreezeReason(freezeReason);
		dealCustInfo.setFreezeStatus(freezeStatusFlag);
		dealCustInfo.setPartyId(partyId);
		
		dealCustInfo.setValidateAssetProgress(validate_ASSETPROGRESS);
		dealCustInfo.setValidateDealInit(validate_DEALINIT);
		dealCustInfo.setValidateGrantApproval(validate_GRANTAPPROVAL);
		dealCustInfo.setValidateRelationShipInfo(validate_RelationShipInfo);
		dealCustInfo.setValidateReqActivate(validate_REQACTIVATE);
		dealCustInfo.setValidateSignContract(validate_SIGNCONTRACT);
		dealCustInfo.setValidateStudy(validate_STUDY);
		dealCustInfo.setValidateTechAnalysis(validate_INITTECHANALYSIS);
		
		
		
		setF_OUT_ceDealCustomerInfo(dealCustInfo);
				
	}
	
	public int calculateAge(Date birthDate, Date currentDate) {            
			    // validate inputs ...                                                                               
			    DateFormat formatter = new SimpleDateFormat("yyyyMMdd");                           
			    int d1 = Integer.parseInt(formatter.format(birthDate));                            
			    int d2 = Integer.parseInt(formatter.format(currentDate));                          
			    int age = (d2 - d1) / 10000;                                                       
			    return age;                                                                        
	}
	
}