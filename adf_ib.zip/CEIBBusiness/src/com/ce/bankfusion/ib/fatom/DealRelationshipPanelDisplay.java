package com.ce.bankfusion.ib.fatom;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DealRelationshipPanelDisplay;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.cfg.dto.RelationshipDtl;
import com.ce.ib.cfg.dto.RelationshipPanelDisplay;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class DealRelationshipPanelDisplay extends AbstractCE_IB_DealRelationshipPanelDisplay {

	private static final Log LOGGER = LogFactory.getLog(DealRelationshipPanelDisplay.class);

	public DealRelationshipPanelDisplay(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		boolean relationshipTypeConfiguredInXML = false;
		if (!isF_IN_isPartyFrozen()) {
			String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
			String filePath = confPath.concat(CeConstants.RELATIONSHIP_PANEL_DISPLAY_FILE);
			JAXBContext jaxbContext;
			try {
				jaxbContext = JAXBContext.newInstance(RelationshipPanelDisplay.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				InputStream inStream = new FileInputStream(filePath);
				RelationshipPanelDisplay relationshipPanelDisplay = (RelationshipPanelDisplay) jaxbUnmarshaller
						.unmarshal(inStream);
				if (relationshipPanelDisplay != null) {
					for (RelationshipDtl relationshipDtl : relationshipPanelDisplay.getRelationshipDtl()) {
						if (!IBCommonUtils.isNullOrEmpty(getF_IN_relationshipType())
								&& relationshipDtl.getRelationshipType().equals(getF_IN_relationshipType())) {
							relationshipTypeConfiguredInXML = true;
							setF_OUT_displayAgentsPanel(
									relationshipDtl.getDisplayAgents().equals("true") ? Boolean.TRUE : Boolean.FALSE);
							setF_OUT_displayGuaranteeToPayPanel(
									relationshipDtl.getDisplayGuranteeToPay().equals("true") ? Boolean.TRUE
											: Boolean.FALSE);
							setF_OUT_displayPartnersPanel(
									relationshipDtl.getDisplayPartners().equals("true") ? Boolean.TRUE : Boolean.FALSE);
							LOGGER.info(relationshipDtl.toString());
							break;
						}
					}
				}
				if (!IBCommonUtils.isNullOrEmpty(getF_IN_relationshipType()) && !relationshipTypeConfiguredInXML) {
					setF_OUT_displayAgentsPanel(Boolean.TRUE);
					setF_OUT_displayGuaranteeToPayPanel(Boolean.TRUE);
					setF_OUT_displayPartnersPanel(Boolean.TRUE);
				}
			} catch (JAXBException | FileNotFoundException e) {
				LOGGER.error(e.getMessage());
			}
		}
	}
}
