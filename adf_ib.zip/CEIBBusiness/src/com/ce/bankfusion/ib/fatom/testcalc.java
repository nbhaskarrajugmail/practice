package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class testcalc {

	public static void main(String[] args) {
		BigDecimal loanRequestedAmount = new BigDecimal(2000000);
		BigDecimal asset1 = new BigDecimal(2000000);
		BigDecimal asset2 = new BigDecimal(1000000);
		BigDecimal loanApprovedAmount = new BigDecimal(2250000);
		
		BigDecimal OnePercent = loanRequestedAmount.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
		System.out.println(OnePercent);
		BigDecimal participationPercentage = loanApprovedAmount.divide(OnePercent, 2, RoundingMode.HALF_UP);
		System.out.println(participationPercentage);

		BigDecimal asset1approved = (asset1.multiply(participationPercentage)).divide(new BigDecimal(100));
		BigDecimal asset2approved = asset2.multiply(participationPercentage).divide(new BigDecimal(100));
		System.out.println(asset1approved);
		System.out.println(asset2approved);
		System.out.println(asset2approved.add(asset1approved));
	}

}
