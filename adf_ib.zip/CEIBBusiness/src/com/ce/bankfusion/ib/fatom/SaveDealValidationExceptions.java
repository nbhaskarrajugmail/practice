package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveDealValidationExceptions;
import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.DealValidation;
import bf.com.misys.ib.types.DealValidationList;

public class SaveDealValidationExceptions extends AbstractCE_IB_SaveDealValidationExceptions{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2488322184329542868L;

	public SaveDealValidationExceptions()
	{
		super();
	}

	public SaveDealValidationExceptions(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();
		switch(context)
		{
		case "PREPARE" :
			saveDealValidationExceptions();
			break;
		case "APPROVAL" :
			updateApprovalStatus();
			break;
		default:
			break;
		}
	}

	private void updateApprovalStatus() {
		DealValidationList dealValidationExceptionApprovals = getF_IN_dealValidationExceptions();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		DealValidationUtil.validateForUserAction(dealValidationExceptionApprovals);
		for(DealValidation approvals : dealValidationExceptionApprovals.getDealValidations())
		{
			IBOCE_IB_DealValidations dealValidationFromDB = (IBOCE_IB_DealValidations) factory.
					findByPrimaryKey(IBOCE_IB_DealValidations.BONAME, approvals.getDealValidationID(),true);
			if(ValidationExceptionConstants.STATUS_APPROVED.equals(dealValidationFromDB.getF_IBSTATUS()) ||
					ValidationExceptionConstants.STATUS_REJECTED.equals(dealValidationFromDB.getF_IBSTATUS()))
			{
				continue;
			}
			dealValidationFromDB.setF_IBSTATUS(approvals.getStatus());
			dealValidationFromDB.setF_IBAPPROVERCOMMENT(approvals.getApproverComment());
			//dealValidationFromDB.setF_IBAPPROVALUSER(BankFusionThreadLocal.getUserId());
			dealValidationFromDB.setF_RECAPPROVEDBY(BankFusionThreadLocal.getUserId());
			dealValidationFromDB.setF_RECLASTMODIFIEDDATE(SystemInformationManager.getInstance().getBFBusinessDateTime());
			dealValidationFromDB.setF_RECAPPROVEDDATE(SystemInformationManager.getInstance().getBFBusinessDateTime());
			dealValidationFromDB.setF_RECLASTMODIFIEDBY(BankFusionThreadLocal.getUserId());
		}
		
		
	}

	private void saveDealValidationExceptions() {
		DealValidationList dealValidationExceptionApprovals = getF_IN_dealValidationExceptions();
		HashSet<String> activeValidationConfIDs = new HashSet<>();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		for(DealValidation dealValidationExceptions : dealValidationExceptionApprovals.getDealValidations())
		{
			if(StringUtils.isNotBlank(dealValidationExceptions.getDealValidationID()))
			{
				IBOCE_IB_DealValidations dealValidationFromDB = (IBOCE_IB_DealValidations) factory.
						findByPrimaryKey(IBOCE_IB_DealValidations.BONAME, dealValidationExceptions.getDealValidationID(),true);
				dealValidationFromDB.setF_IBADDITIONALDTL(dealValidationExceptions.getAdditionalDtls());
				dealValidationFromDB.setF_RECLASTMODIFIEDDATE(SystemInformationManager.getInstance().getBFBusinessDateTime());
				dealValidationFromDB.setF_RECLASTMODIFIEDBY(BankFusionThreadLocal.getUserId());
				activeValidationConfIDs.add(dealValidationExceptions.getValidationConfID());
			}
			else
			{
				IBOCE_IB_DealValidations newDealValidation = (IBOCE_IB_DealValidations) factory.
						getStatelessNewInstance(IBOCE_IB_DealValidations.BONAME);
				//newDealValidation.setF_IBACTIONTYPE(dealValidationExceptions.getActionType());
				//newDealValidation.setF_IBAPPROVALUSER(dealValidationExceptions.getApprovalUserID());
				newDealValidation.setF_IBADDITIONALDTL(dealValidationExceptions.getAdditionalDtls());
				newDealValidation.setF_IBDEALID(dealValidationExceptions.getDealID());
				newDealValidation.setF_IBSTEPID(dealValidationExceptions.getStepID());
				//newDealValidation.setF_IBVALIDATIONID(dealValidationExceptions.getValidationID());
				newDealValidation.setF_IBPROCESSCONFIGID(dealValidationExceptions.getProcessID());
				newDealValidation.setF_RECCREATEDBY(BankFusionThreadLocal.getUserId());
				newDealValidation.setF_RECSYSDATE(SystemInformationManager.getInstance().getBFSystemDateTime());
				newDealValidation.setF_RECCREATEDON(SystemInformationManager.getInstance().getBFBusinessDateTime());
				newDealValidation.setF_IBSTATUS(dealValidationExceptions.getStatus());
				newDealValidation.setF_IBVALIDATIONCONFID(dealValidationExceptions.getValidationConfID());
				factory.create(IBOCE_IB_DealValidations.BONAME, newDealValidation);
				activeValidationConfIDs.add(dealValidationExceptions.getValidationConfID());
			}
		}
		String deleteQuery = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ? AND "
				+ IBOCE_IB_DealValidations.IBPROCESSCONFIGID + " = ? AND "
				+ IBOCE_IB_DealValidations.IBSTEPID + " = ?";
		if(!activeValidationConfIDs.isEmpty())
		{
			deleteQuery = deleteQuery + " AND "	+ IBOCE_IB_DealValidations.IBVALIDATIONCONFID + " NOT IN ";
		}
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islmaicBankingObj().getDealID());
		params.add(getF_IN_islmaicBankingObj().getProcessConfigID());
		params.add(getF_IN_islmaicBankingObj().getStepID());
		if(!activeValidationConfIDs.isEmpty())
		{
			String notInClause = prepareNotInClause(activeValidationConfIDs);
			deleteQuery = deleteQuery+notInClause;
		}
		factory.bulkDelete(IBOCE_IB_DealValidations.BONAME, deleteQuery,params);
	}

	private String prepareNotInClause(HashSet<String> activeValidationConfIDs) {
		StringBuilder builder = new StringBuilder();
		builder.append("(");
		for(String confID : activeValidationConfIDs)
		{
			builder.append("'"+confID+"',");
		}
		String finalNotInClause = builder.substring(0, builder.length()-1);
		finalNotInClause = finalNotInClause+")";
		return finalNotInClause;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
