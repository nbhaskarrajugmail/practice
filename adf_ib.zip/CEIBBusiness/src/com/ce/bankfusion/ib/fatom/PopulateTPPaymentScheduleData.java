package com.ce.bankfusion.ib.fatom;

import java.sql.Date;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PopulateTPPaymentScheduleData;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.calendar.functions.AddYearsToDate;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.MaintainTPPaymentSchedule;
import com.misys.bankfusion.ib.fatom.ReadAllDealThirdPartyAmounts;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.expression.builder.functions.SubtractDaysFromDate;

import bf.com.misys.ib.msgs.v1r0.ThirdPartyPaymentsReadRs;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.PaymentScheduleThirdPartyDetails;
import bf.com.misys.ib.types.ThirdPartyPaymentsDetails;
import bf.com.misys.ib.types.ThirdPartyPaymentsSchedulesDetails;

public class PopulateTPPaymentScheduleData extends AbstractCE_IB_PopulateTPPaymentScheduleData {

	private static final String YES = "Yes";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String YEAR = "YEAR";

	public PopulateTPPaymentScheduleData(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
		ReadAllDealThirdPartyAmounts readAllDealThirdPartyAmounts = new ReadAllDealThirdPartyAmounts();
		readAllDealThirdPartyAmounts.setF_IN_dealNo(islamicBankingObject.getDealID());
		readAllDealThirdPartyAmounts.process(env);
		
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		Date dealEffectiveDate = getF_IN_dealEffectiveDate();
		if(CalendarUtil.isDateNullOrDefaultDate(getF_IN_dealEffectiveDate())) {
			dealEffectiveDate = dealDetails.getF_DEALEFFECTIVEDT();
		}
		ThirdPartyPaymentsReadRs thirdPartyPaymentsReadRs = readAllDealThirdPartyAmounts
				.getF_OUT_thirdPartyPaymentsReadRs();
		thirdPartyPaymentsReadRs.setDealId(islamicBankingObject.getDealID());
		thirdPartyPaymentsReadRs.removeAllThirdPartyPaymentsSchedulesDtls();
		ReadAssetData readAssetData = CeUtils.readAssetData(islamicBankingObject);

		for (PaymentScheduleThirdPartyDetails paymentScheduleThirdPartyDetails : thirdPartyPaymentsReadRs
				.getPaymentScheduleThirdPartyDetails()) {

			if (isF_IN_regenerateTPPaymentSchedule()
					|| !paymentScheduleThirdPartyDetails.getStatusCBRef()
					.equals(ThirdPartyPaymentScheduleUtil.TP_PAYMENT_STATUS_SCHEDULED)) {
				int maxDisbursementPeriod = CeUtils.getDisbursementPeriodForAsset(readAssetData,
						paymentScheduleThirdPartyDetails.getAssetDetailsId());
				Date paymentDate = AddYearsToDate.run(dealEffectiveDate, maxDisbursementPeriod, YES);
				paymentDate = SubtractDaysFromDate.run(paymentDate, 1);
				ThirdPartyPaymentsDetails thirdPartyPaymentsDtls = paymentScheduleThirdPartyDetails
						.getThirdPartyPaymentsDtls();
				thirdPartyPaymentsDtls.setRegularNoOfPayments(1);
				thirdPartyPaymentsDtls.setRegularPaymentFrequencyMode(YEAR);
				thirdPartyPaymentsDtls.setRegularPaymentFrequencyUnit(1);
				thirdPartyPaymentsDtls.setDeductionDeliveryDate(paymentDate);
				thirdPartyPaymentsDtls.setRegularPaymentStartDate(paymentDate);

				paymentScheduleThirdPartyDetails.setThirdPartyPaymentsDtls(thirdPartyPaymentsDtls);
				paymentScheduleThirdPartyDetails
						.setStatusCBRef(ThirdPartyPaymentScheduleUtil.TP_PAYMENT_STATUS_SCHEDULED);
				paymentScheduleThirdPartyDetails
						.setStatus(IBCommonUtils.getGCChildDesc(IBConstants.TPPAYMENTSCHEDULESTATUS,
								ThirdPartyPaymentScheduleUtil.TP_PAYMENT_STATUS_SCHEDULED));

				ThirdPartyPaymentsSchedulesDetails tpRegularPaymentsScheduleDtls = new ThirdPartyPaymentsSchedulesDetails();
				tpRegularPaymentsScheduleDtls.setThirdPartyID(paymentScheduleThirdPartyDetails.getThirdPartyID());
				tpRegularPaymentsScheduleDtls
						.setThirdPartyOfficeID(paymentScheduleThirdPartyDetails.getThirdPartyOfficeID());
				tpRegularPaymentsScheduleDtls
						.setCurrencyCode(paymentScheduleThirdPartyDetails.getThirdPartyAmount().getCurrencyCode());
				tpRegularPaymentsScheduleDtls.setAssetDetailsId(paymentScheduleThirdPartyDetails.getAssetDetailsId());
				tpRegularPaymentsScheduleDtls.setPaymentNumber(1);
				tpRegularPaymentsScheduleDtls.setPaymentTypeCBRef(IBConstants.PAYMENTSCHEDULETYPE_PAYMENT);
				tpRegularPaymentsScheduleDtls.setSelect(false);
				String regularPaymentGCDesc = IBCommonUtils.getGCChildDesc(IBConstants.TPPAYMENTSCHEDULETYPE_GC,
						IBConstants.PAYMENTSCHEDULETYPE_PAYMENT);
				tpRegularPaymentsScheduleDtls.setPaymentType(regularPaymentGCDesc);
				tpRegularPaymentsScheduleDtls.setPaymentAmount(paymentScheduleThirdPartyDetails.getThirdPartyAmount());
				tpRegularPaymentsScheduleDtls.setPaymentDate(paymentDate);
				thirdPartyPaymentsReadRs.addThirdPartyPaymentsSchedulesDtls(tpRegularPaymentsScheduleDtls);

			}
		}
		MaintainTPPaymentSchedule maintainTPPaymentSchedule = new MaintainTPPaymentSchedule();
		maintainTPPaymentSchedule.setF_IN_tpPaymentScheduleDetail(thirdPartyPaymentsReadRs);
		maintainTPPaymentSchedule.process(env);

	}
}
