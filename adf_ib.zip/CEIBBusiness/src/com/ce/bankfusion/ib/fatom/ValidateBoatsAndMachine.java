package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateBoatsAndMachine;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class ValidateBoatsAndMachine extends AbstractCE_IB_ValidateBoatsAndMachine {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private static final int E_BOATS_AND_MACHINES_MANDATORY_IB = 44000454;

    public ValidateBoatsAndMachine() {
        super();
        // TODO Auto-generated constructor stub
    }

    public ValidateBoatsAndMachine(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        if (getF_IN_toolNo().equals("197") || getF_IN_toolNo().equals("186")) {
            if (IBCommonUtils.isNullOrEmpty(getF_IN_boatMachineName()) || IBCommonUtils.isNullOrEmpty(getF_IN_boatMachineNo())
                || IBCommonUtils.isNullOrEmpty(getF_IN_boatSerialNo()))
                IBCommonUtils.raiseUnparameterizedEvent(E_BOATS_AND_MACHINES_MANDATORY_IB);
        }
    }
}
