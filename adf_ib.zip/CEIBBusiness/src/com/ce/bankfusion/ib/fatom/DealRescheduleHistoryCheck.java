package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DealRescheduleHistoryExists;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class DealRescheduleHistoryCheck extends AbstractCE_IB_DealRescheduleHistoryExists {

	private static final Log LOGGER = LogFactory.getLog(DealRescheduleHistoryCheck.class);

	public DealRescheduleHistoryCheck(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_dealId());

		List<IBOCE_IB_DealReschedule> dealRescheduleDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealReschedule.BONAME, RescheduleUtils.dealRescheduleQuery, params, null, false);
		if (!dealRescheduleDtls.isEmpty()) {
			for (IBOCE_IB_DealReschedule dealReschedule : dealRescheduleDtls) {
				if (dealReschedule.getF_IBRESCHEDULESTATUS().equals("COMPLETED"))
					setF_OUT_displayReschHisPanel(true);
			}
		}
	}
}
