package com.ce.bankfusion.ib.fatom;

import bf.com.misys.ib.ilo.types.UserList;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetUsersByBranchCode;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;

public class GetUsersByBranchCode extends AbstractCE_IB_GetUsersByBranchCode {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public GetUsersByBranchCode() {
        super();
    }

    public GetUsersByBranchCode(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        UserList user = new UserList();
        UserList defaultUser = new UserList();
        boolean isAdmin = CeUtils.isloggedInUserFromAdfFollowUpUserGroup();
        if (!IBCommonUtils.isNullOrEmpty(getF_IN_branchCode())) {
            user = CeUtils.getUserList(getF_IN_branchCode());
            defaultUser =user;
        } else
        {
            if(isAdmin)
               defaultUser = CeUtils.getUserList(CommonConstants.EMPTY_STRING);
            else 
                defaultUser = CeUtils.getUserList(CeUtils.getUserBranchCode());
        }
      
        setF_OUT_defaultUserList(defaultUser);
        setF_OUT_userList(user);
    }
}
