package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AgricultureRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_BuildingDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PersonalRequestDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ResidentialRquestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TitleDeedDtlsForEvaluation;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TreeDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_WellDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadCollateralEvaluation;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.AgricultureDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ResidentialDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class ReadCollateralRequestDetails extends AbstractCE_IB_ReadCollateralEvaluation {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5448706519358856682L;
	private static final Log LOGGER = LogFactory.getLog(ReadCollateralRequestDetails.class);
	public static WellDetailsList wellDtlsMainHidden = new WellDetailsList();
	public static TreesDetailsList treeDtlsMainHidden = new TreesDetailsList();
	public static BuildingsDetailsList buildingDtlsMainHidden = new BuildingsDetailsList();

	public ReadCollateralRequestDetails() {
		super();
	}

	public ReadCollateralRequestDetails(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) {
	   String curCode = getF_IN_islamicBankingObject().getCurrency();
	   wellDtlsMainHidden.removeAllWellDetailsList();
	   treeDtlsMainHidden.removeAllTreesDetailsList();
	   buildingDtlsMainHidden.removeAllBuildingsDetailsList();
		getF_OUT_titleDeedList().removeAllTitleDeedDetailsList();
		getF_OUT_buildingDtlsList().removeAllBuildingsDetailsList();
		getF_OUT_collateralRequestDetailsList().removeAllCollateralRequestDetailsList();
		getF_OUT_coordinatesDtslList().removeAllCoOrdinateDetailsList();
		getF_OUT_ownerList().removeAllOwnersDetailsList();
		getF_OUT_wellDetailsList().removeAllWellDetailsList();
		getF_OUT_hidden_titleDeedDetailsList().removeAllTitleDeedDetailsList();
		getF_OUT_hidden_buildingDtlsList().removeAllBuildingsDetailsList();
		getF_OUT_hidden_treesDtlsList().removeAllTreesDetailsList();
		getF_OUT_hidden_wellDtlsList().removeAllWellDetailsList();
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();

		CollateralRequestDtlsUtils collateralRequestDtlsUtils = new CollateralRequestDtlsUtils();
		List<IBOCE_IB_CollateralRevaluationDetails> collateralRqDtlsFromDB = collateralRequestDtlsUtils
				.readCollateralRequestDtls(ibObj);

		if (collateralRqDtlsFromDB != null) {
			populateCollateralRqDtls(ibObj, collateralRqDtlsFromDB);
		}

	}

	private void populateCollateralRqDtls(IslamicBankingObject ibObj,
			List<IBOCE_IB_CollateralRevaluationDetails> collateralRqDtlsFromDB) {
		BFCurrencyAmount totalCoverValue = new BFCurrencyAmount();
		totalCoverValue.setCurrencyAmount(BigDecimal.ZERO);
		totalCoverValue.setCurrencyCode(ibObj.getCurrency());
		boolean select = true;
		CollateralRequestDetailsList collateralRequestDetailsList = new CollateralRequestDetailsList();
		TitleDeedDetailsList titledeedDtlMain = new TitleDeedDetailsList();
		    IBCommonUtils.intializeDefaultvalues(titledeedDtlMain);
		for (IBOCE_IB_CollateralRevaluationDetails eachCollDtlsFromDB : collateralRqDtlsFromDB) {
			CollateralRequestDetails collateralRequestDetails = new CollateralRequestDetails();
			BFCurrencyAmount availableBalance = new BFCurrencyAmount();
			availableBalance.setCurrencyAmount(eachCollDtlsFromDB.getF_IBAVAILABLEBALANCE());
			availableBalance.setCurrencyCode(ibObj.getCurrency());
			collateralRequestDetails.setAvailableBalance(availableBalance);
			collateralRequestDetails.setCategoryType(eachCollDtlsFromDB.getF_IBCATEGORYTYPE());
			collateralRequestDetails.setCollateralID(eachCollDtlsFromDB.getF_IBCOLLATERALID());
			BFCurrencyAmount covervalue = new BFCurrencyAmount();
			covervalue.setCurrencyAmount(eachCollDtlsFromDB.getF_IBCOVERVALUE());
			covervalue.setCurrencyCode(ibObj.getCurrency());
			//setting the step status
			collateralRequestDetails.setStepStatus(eachCollDtlsFromDB.getF_IBSTEPSTATUS());
			collateralRequestDetails.setCoverValue(covervalue);
			collateralRequestDetails.setDescription(eachCollDtlsFromDB.getF_IBDESCRIPTION());
			collateralRequestDetails.setRequestID(eachCollDtlsFromDB.getBoID());
			collateralRequestDetails.setRequestType(eachCollDtlsFromDB.getF_IBREQUESTTYPE());
			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("REQ_TYP");
			String statusDesc = "";

			for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
				if (collateralRequestDetails.getRequestType().equals(gcCode.getCodeReference())) {
					statusDesc = gcCode.getCodeDescription();
					break;
				}
			}
			collateralRequestDetails.setRequestTypeDesc(statusDesc);
			collateralRequestDetails.setStatus(eachCollDtlsFromDB.getF_IBSTATUS());
			collateralRequestDetails.setTitleDeedIDPK(eachCollDtlsFromDB.getF_IBTITLEDEEDIDPK());
			collateralRequestDetails.setTitleDeedNum(eachCollDtlsFromDB.getF_IBTITLEDEEDNUM());
			PersonalRequestdtls personalRequestdtls = populatePersonalRqDtls(ibObj, eachCollDtlsFromDB.getBoID());
			TitleDeedDetailsList titledeedDtl = 
			populateTitleDeedDtls(ibObj, eachCollDtlsFromDB.getBoID());
			
			
			for(TitleDeedDetails TD : titledeedDtl.getTitleDeedDetailsList()) {
			    titledeedDtlMain.addTitleDeedDetailsList(TD);
			}
			
			
			
			setF_OUT_titleDeedList(titledeedDtl);
			
			
			if(select) {
			    collateralRequestDetails.setSelect(true);
			    select=false;
			}else {
			    collateralRequestDetails.setSelect(false);
			}
			collateralRequestDetails.setPersonalRequest(personalRequestdtls);
			collateralRequestDetailsList.addCollateralRequestDetailsList(collateralRequestDetails);
			if(!eachCollDtlsFromDB.getF_IBSTATUS().equals("DELETED")) {
			totalCoverValue
					.setCurrencyAmount(totalCoverValue.getCurrencyAmount().add(eachCollDtlsFromDB.getF_IBCOVERVALUE()));
			}
		}

		// getF_ou =collateralRequestDetailsList
		setF_OUT_collateralRequestDetailsList(collateralRequestDetailsList);
		setF_OUT_totalCoverValue(totalCoverValue);
		setF_OUT_hidden_titleDeedDetailsList(titledeedDtlMain);
		setF_OUT_hidden_wellDtlsList(wellDtlsMainHidden);
		setF_OUT_hidden_treesDtlsList(treeDtlsMainHidden);
		setF_OUT_hidden_buildingDtlsList(buildingDtlsMainHidden);
		
	}

	public TitleDeedDetailsList populateTitleDeedDtls(IslamicBankingObject ibObj, String requestID) {
		TitleDeedDetailsList titleDeedDtlsList = new TitleDeedDetailsList();
		List<IBOCE_IB_TitleDeedDtlsForEvaluation> titleDeedRqDtlsFromDB = CollateralRequestDtlsUtils
				.readTitleDeedDtlsForEvaluation(requestID);

		if (titleDeedRqDtlsFromDB != null && titleDeedRqDtlsFromDB.size() > 0) {
			for (IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls : titleDeedRqDtlsFromDB) {
				TitleDeedDetails eachTitleDeedUI = new TitleDeedDetails();
				eachTitleDeedUI.setEvaluationId(eachTitleDeedRqDtls.getF_IBEVALUATIONID());
				eachTitleDeedUI.setLandPlotNum(eachTitleDeedRqDtls.getF_IBPLOTNUM());
				eachTitleDeedUI.setPlan(eachTitleDeedRqDtls.getF_IBPLAN());
				eachTitleDeedUI.setRequestID(eachTitleDeedRqDtls.getF_IBREQUESTID());
				ListGenericCodeRs sourceList = IBCommonUtils.getGCList("TITLEDEEDSOURCE");
				String sourceLabel = "";
	      for(GcCodeDetail source : sourceList.getGcCodeDetails()) {
	          if(source.getCodeReference().equals(eachTitleDeedRqDtls.getF_IBSOURCE())){
	              sourceLabel = source.getCodeDescription();
	              break;
	          }
	      }
				
	      if(sourceLabel != "") {
	          eachTitleDeedUI.setSource(sourceLabel);
	      }else {
	          eachTitleDeedUI.setSource(eachTitleDeedRqDtls.getF_IBSOURCE());
	      }
	      
				eachTitleDeedUI.setTitleDeedNum(eachTitleDeedRqDtls.getF_IBTITLEDEEDNUM());
				eachTitleDeedUI.setTitleDeedIDPK(eachTitleDeedRqDtls.getF_IBTITLEDEEDID());
				String typeLabel = "";
				ListGenericCodeRs typeList = IBCommonUtils.getGCList("TITLEDEEDTYPE");
	      for(GcCodeDetail type : typeList.getGcCodeDetails()) {
	          if(type.getCodeReference().equals(eachTitleDeedRqDtls.getF_IBTYPE())){
	              typeLabel = type.getCodeDescription();
	              break;
	          }
	      }
	      if(typeLabel != "") {
	          eachTitleDeedUI.setType(typeLabel);
	      }else {
	          eachTitleDeedUI.setType(eachTitleDeedRqDtls.getF_IBTYPE());
	      }
				
				eachTitleDeedUI.setYear(eachTitleDeedRqDtls.getF_IBYEAR());
				eachTitleDeedUI.setTitleDeedVersionNum(eachTitleDeedRqDtls.getF_IBTITLEDEEDVERSIONNUM());
				//eachTitleDeedUI.setSelect(true);
				ResidentialDetails residentialDetails=populateResidentialRqDtls(ibObj, eachTitleDeedRqDtls);
				AgricultureDetails agricultureDetails = populateAgricultureDtls(ibObj, eachTitleDeedRqDtls);
				
				if(null != residentialDetails.getNetEvaluationValue() && residentialDetails.getNetEvaluationValue().getCurrencyAmount().compareTo(BigDecimal.ZERO)==1) {
				    eachTitleDeedUI.setResidentialDetails(residentialDetails);
				}
				else {
				    eachTitleDeedUI.setAgricultureDetails(agricultureDetails);
				}
				
				
				titleDeedDtlsList.addTitleDeedDetailsList(eachTitleDeedUI);

			}
			// setf
			//setF_OUT_hidden_titleDeedDetailsList(titleDeedDtlsList);
			
		}
		return titleDeedDtlsList;

	}

	private AgricultureDetails populateAgricultureDtls(IslamicBankingObject ibObj,
			IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls) {

		IBOCE_IB_AgricultureRequestDetails agricultureRequestDetails = CollateralRequestDtlsUtils
				.readAgricultureRequestDtls(eachTitleDeedRqDtls);
		AgricultureDetails agricultureDetails = new AgricultureDetails();
		if (agricultureRequestDetails != null) {

			agricultureDetails.setAgricultureDetailsID(agricultureRequestDetails.getBoID());
			agricultureDetails.setDescription(agricultureRequestDetails.getF_IBDESCRIPTION());
			agricultureDetails.setDistanceToMainRoad(agricultureRequestDetails.getF_IBDISTANCETOMAINROAD());
			BFCurrencyAmount dunumPrice = new BFCurrencyAmount();
			dunumPrice.setCurrencyAmount(agricultureRequestDetails.getF_IBDUNUMPRICE());
			dunumPrice.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setDunumPrice(dunumPrice);
			agricultureDetails.setElectricityAvailable(agricultureRequestDetails.isF_IBELECTIRCITYAVAILABLE());
			agricultureDetails.setEligibleToFarm(agricultureRequestDetails.getF_IBELIGIBLETOFARM());
			agricultureDetails.setEvaluationDate(agricultureRequestDetails.getF_IBEVALUATIONDATE());
			agricultureDetails.setEvaluator(agricultureRequestDetails.getF_IBEVALUATOR());
			agricultureDetails.setFarmSizeInDunum(agricultureRequestDetails.getF_IBFARMSIZEINDUNUM());
			agricultureDetails.setInsideFarmRoadType(agricultureRequestDetails.getF_IBINSIDEFARMROADTYPE());
			agricultureDetails.setIsLocationMatching(agricultureRequestDetails.isF_IBISLOCATIONMATCHING());
			agricultureDetails.setIsPlanMatching(agricultureRequestDetails.isF_IBISPLANMATCHING());
			agricultureDetails.setIsPrevMortgageAmt(agricultureRequestDetails.isF_IBISPREVMORTGAGEAMT());
			BFCurrencyAmount landNetValue = new BFCurrencyAmount();
			landNetValue.setCurrencyAmount(agricultureRequestDetails.getF_IBLANDNETVALUE());
			landNetValue.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setLandNetValue(landNetValue);
			BFCurrencyAmount landTotalValue = new BFCurrencyAmount();
			landTotalValue.setCurrencyAmount(agricultureRequestDetails.getF_IBLANDTOTALVALUE());
			landTotalValue.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setLandTotalValue(landTotalValue);
			agricultureDetails.setLastModifiedDate(agricultureRequestDetails.getF_IBRECLASTMODIFIEDDATE());
			BFCurrencyAmount mortgageAmt = new BFCurrencyAmount();
			mortgageAmt.setCurrencyAmount(agricultureRequestDetails.getF_IBMORTGAGEAMT());
			mortgageAmt.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setMortgageAmt(mortgageAmt);
			agricultureDetails.setNearestCityDistance(agricultureRequestDetails.getF_IBNEARESTCITYDISTANCE());
			agricultureDetails.setNearestCityName(agricultureRequestDetails.getF_IBNEARESTCITYNAME());
			BFCurrencyAmount netCoverValue = new BFCurrencyAmount();
			netCoverValue.setCurrencyAmount(agricultureRequestDetails.getF_IBNETCOVERVALUE());
			netCoverValue.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setNetCoverValue(netCoverValue);
			agricultureDetails.setOthers(agricultureRequestDetails.getF_IBOTHERS());
			agricultureDetails.setPhoneAvailable(agricultureRequestDetails.isF_IBPHONEAVAILABLE());
			agricultureDetails.setStatus(agricultureRequestDetails.getF_IBSTATUS());
			BFCurrencyAmount totalCoverValue = new BFCurrencyAmount();
			totalCoverValue.setCurrencyAmount(agricultureRequestDetails.getF_IBTOTALCOVERVALUE());
			totalCoverValue.setCurrencyCode(ibObj.getCurrency());
			agricultureDetails.setTotalCoverValue(totalCoverValue);
			agricultureDetails.setTypeOfRoad(agricultureRequestDetails.getF_IBTYPEOFROAD());
			agricultureDetails.setWaterAvailability(agricultureRequestDetails.getF_IBWATERAVAILABILITY());
			agricultureDetails.setWateringMethod(agricultureRequestDetails.getF_IBWATERINGMETHOD());
			agricultureDetails.setWaterInNeighbourArea(agricultureRequestDetails.getF_IBWATREINNEIGHBOURSAREA());

			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("EVALUATIONSTATUS");
      String statusDesc = "";

      for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
        if (agricultureRequestDetails.getF_IBSTATUS().equals(gcCode.getCodeReference())) {
          statusDesc = gcCode.getCodeDescription();
          break;
        }
      }
      agricultureDetails.setStatusDesc(statusDesc);
			WellDetailsList wellList = new WellDetailsList();
			wellList = populateWellDetails(ibObj, eachTitleDeedRqDtls, agricultureDetails.getAgricultureDetailsID());
			for(WellDetails well : wellList.getWellDetailsList()) {
			    for(WellDetails mainWell : wellDtlsMainHidden.getWellDetailsList()) {
			        if(well.getWellDetailsID().equals(mainWell.getWellDetailsID())) {
			            wellDtlsMainHidden.removeWellDetailsList(well);
			        }
			    }
			    wellDtlsMainHidden.addWellDetailsList(well);
			}
			
			TreesDetailsList treeList = new TreesDetailsList();
			treeList = populateTreesDetails(ibObj, eachTitleDeedRqDtls, agricultureDetails.getAgricultureDetailsID());
			for(TreeDetails tree : treeList.getTreesDetailsList()) {
          for(TreeDetails mainTree : treeDtlsMainHidden.getTreesDetailsList()) {
              if(tree.getTreeDetailsID().equals(mainTree.getTreeDetailsID())) {
                  treeDtlsMainHidden.removeTreesDetailsList(tree);
              }
          }
          treeDtlsMainHidden.addTreesDetailsList(tree);
      }
			
			BuildingsDetailsList buildingList = new BuildingsDetailsList();
			buildingList = populateBuildingDetails(ibObj, eachTitleDeedRqDtls, agricultureDetails.getAgricultureDetailsID());
			for(BuildingDetails building : buildingList.getBuildingsDetailsList()) {
          for(BuildingDetails mainBuilding : buildingDtlsMainHidden.getBuildingsDetailsList()) {
              if(building.getBuildingDetailsID().equals(mainBuilding.getBuildingDetailsID())) {
                  buildingDtlsMainHidden.removeBuildingsDetailsList(building);
              }
          }
          buildingDtlsMainHidden.addBuildingsDetailsList(building);
      }
			
		}
		  //setF_OUT_hidden_wellDtlsList(wellDtlsMainHidden);
  		return agricultureDetails;
	}

	private ResidentialDetails populateResidentialRqDtls(IslamicBankingObject ibObj,
			IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls) {

		IBOCE_IB_ResidentialRquestDetails residentRequestDtls = CollateralRequestDtlsUtils
				.readResidentRequestDtls(eachTitleDeedRqDtls);
		ResidentialDetails residentDetails = new ResidentialDetails();
		
		if (residentRequestDtls != null) {
		    
			residentDetails.setDescription(residentRequestDtls.getF_IBDESCRIPTION());
			residentDetails.setBuildingAge(residentRequestDtls.getF_IBBUILDINGAGE());
			residentDetails.setBuiltArea(residentRequestDtls.getF_IBBUILTAREA());
			residentDetails.setCompoundWallHeight(residentRequestDtls.getF_IBCOMPUNDWALLHEIGHT());
			residentDetails.setConstructionLevel(residentRequestDtls.getF_IBCONSTRUCTIONLEVEL());
			residentDetails.setEvaluationDate(residentRequestDtls.getF_IBEVALUATIONDATE());
			residentDetails.setEvaluator(residentRequestDtls.getF_IBEVALUATOR());
			residentDetails.setHouseNo(residentRequestDtls.getF_IBHOUSENUMBER());
			residentDetails.setIsBuilding(residentRequestDtls.isF_IBISBUILDING());
			residentDetails.setIsLocationMatching(residentRequestDtls.isF_IBISLOCATIONMATCHING());
			residentDetails.setIsPlanMatching(residentRequestDtls.isF_IBISPLANMATCHING());
			residentDetails.setIsPrevMortgageAmt(residentRequestDtls.isF_IBISPREVMORTGAGEAMT());
			residentDetails.setLandArea(residentRequestDtls.getF_IBLANDAREA());
			residentDetails.setLastModifiedDate(residentRequestDtls.getF_IBRECLASTMODIFIEDDATE());
			BFCurrencyAmount mortgageAmt = new BFCurrencyAmount();
			mortgageAmt.setCurrencyAmount(residentRequestDtls.getF_IBMORTGAGEAMT());
			mortgageAmt.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setMortgageAmt(mortgageAmt);
			BFCurrencyAmount netEvalValue = new BFCurrencyAmount();
			netEvalValue.setCurrencyAmount(residentRequestDtls.getF_IBNETEVALUATIONVALUE());
			netEvalValue.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setNetEvaluationValue(netEvalValue);
			residentDetails.setNoOfFloors(residentRequestDtls.getF_IBNUMBEROFFLOORS());
			BFCurrencyAmount pricePerBuildingSqM = new BFCurrencyAmount();
			pricePerBuildingSqM.setCurrencyAmount(residentRequestDtls.getF_IBPRICEPERBUILDINGSQM());
			pricePerBuildingSqM.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setPricePerBuildSqM(pricePerBuildingSqM);
			BFCurrencyAmount pricePerSqM = new BFCurrencyAmount();
			pricePerSqM.setCurrencyAmount(residentRequestDtls.getF_IBPRICEPERSQM());
			pricePerSqM.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setPricePerSqM(pricePerSqM);
			residentDetails.setPropertySize(residentRequestDtls.getF_IBPROPERTYSIZE());
			residentDetails.setQuality(residentRequestDtls.getF_IBQUALITY());
			residentDetails.setResidentialDetailsID(residentRequestDtls.getBoID());
			BFCurrencyAmount shadowPrice = new BFCurrencyAmount();
			shadowPrice.setCurrencyAmount(residentRequestDtls.getF_IBSHADOWPRICE());
			shadowPrice.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setShadowPrice(shadowPrice);
			residentDetails.setShadowSize(residentRequestDtls.getF_IBSHADOWSIZE());
			residentDetails.setStatus(residentRequestDtls.getF_IBSTATUS());
			residentDetails.setStreetName1(residentRequestDtls.getF_IBSTREETNAME1());
			residentDetails.setStreetName2(residentRequestDtls.getF_IBSTREETNAME2());
			residentDetails.setStreetName3(residentRequestDtls.getF_IBSTREETNAME3());
			residentDetails.setStreetName4(residentRequestDtls.getF_IBSTREETNAME4());
			residentDetails.setStreetsTypes(residentRequestDtls.getF_IBSTREETTYPES());
			BFCurrencyAmount totalEvalPrice = new BFCurrencyAmount();
			totalEvalPrice.setCurrencyAmount(residentRequestDtls.getF_IBTOTALEVALUATIONVALUE());
			totalEvalPrice.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setTotalEvaluationValue(totalEvalPrice);
			residentDetails.setUtilityAreaSize(residentRequestDtls.getF_IBUTILITYAREASIZE());
			BFCurrencyAmount utilityPrice = new BFCurrencyAmount();
			utilityPrice.setCurrencyAmount(residentRequestDtls.getF_IBUTILITYPRICE());
			utilityPrice.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setUtilityPrice(utilityPrice);
			BFCurrencyAmount wallPrice = new BFCurrencyAmount();
			wallPrice.setCurrencyAmount(residentRequestDtls.getF_IBWALLPRICE());
			wallPrice.setCurrencyCode(ibObj.getCurrency());
			residentDetails.setWallPrice(wallPrice);
			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("EVALUATIONSTATUS");
      String statusDesc = "";

      for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
        if (residentRequestDtls.getF_IBSTATUS().equals(gcCode.getCodeReference())) {
          statusDesc = gcCode.getCodeDescription();
          break;
        }
      }
      residentDetails.setStatusDesc(statusDesc);
		}

		return residentDetails;
	}

	private WellDetailsList populateWellDetails(IslamicBankingObject ibObj,
			IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls, String agricultureId) {
		List<IBOCE_IB_WellDetails> ib_WellDetails = CollateralRequestDtlsUtils.readWellRequestDtls(eachTitleDeedRqDtls,
				agricultureId);
		WellDetailsList detailsList = new WellDetailsList();
		/*BFCurrencyAmount totalPrice= new BFCurrencyAmount();
    BigDecimal setTotalPrice= BigDecimal.ZERO;*/
		for (IBOCE_IB_WellDetails eachWellDetailsDB : ib_WellDetails) {
			WellDetails eachWellDtl = new WellDetails();
			eachWellDtl.setAgricultureDetailsID(eachWellDetailsDB.getF_IBAGRICULTUREDTLSID());
			eachWellDtl.setAirDepth(eachWellDetailsDB.getF_IBAIRDEPTH());
			eachWellDtl.setDepth(eachWellDetailsDB.getF_IBDEPTH());
			eachWellDtl.setEvaluationId(eachWellDetailsDB.getF_IBEVALUATIONID());
			eachWellDtl.setNotes(eachWellDetailsDB.getF_IBNOTES());
			eachWellDtl.setPrice(IBCommonUtils.getBFCurrencyAmount(eachWellDetailsDB.getF_IBPRICE(), ibObj.getCurrency()));
			eachWellDtl.setRequestID(eachWellDetailsDB.getF_IBREQUESTID());
			eachWellDtl.setSno(eachWellDetailsDB.getF_IBSNO());
			eachWellDtl.setTitleDeedIDPK(eachWellDetailsDB.getF_IBTITLEDEEDID());
			eachWellDtl.setTitleDeedNum(eachWellDetailsDB.getF_IBTITLEDEEDNUM());
			eachWellDtl.setWellDetailsID(eachWellDetailsDB.getBoID());
			eachWellDtl.setWellDiameter(eachWellDetailsDB.getF_IBWELLDIAMETER());
			eachWellDtl.setWellType(eachWellDetailsDB.getF_IBWELLTYPE());
			
			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("WELL_TYP");
      String Desc = "";

      for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
        if (eachWellDetailsDB.getF_IBWELLTYPE().equals(gcCode.getCodeReference())) {
          Desc = gcCode.getCodeDescription();
          break;
        }
      }
      eachWellDtl.setWellTypeDesc(Desc);
      //setTotalPrice=setTotalPrice.add(eachWellDtl.getPrice().getCurrencyAmount());
			detailsList.addWellDetailsList(eachWellDtl);
		}
/*		totalPrice.setCurrencyAmount(setTotalPrice);
    totalPrice.setCurrencyCode(ibObj.getCurrency());
    detailsList.setTotalPrice(totalPrice);*/
		return detailsList;
	}

	private TreesDetailsList populateTreesDetails(IslamicBankingObject ibObj,
			IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls, String agricultureId) {

		List<IBOCE_IB_TreeDetails> ib_TreeDetails = CollateralRequestDtlsUtils.readTreeDtls(eachTitleDeedRqDtls,
				agricultureId);
		TreesDetailsList detailsList = new TreesDetailsList();
		for (IBOCE_IB_TreeDetails eachTreeDtlDB : ib_TreeDetails) {
			TreeDetails eachTreeDtl = new TreeDetails();

			eachTreeDtl.setAgricultureDetailsID(eachTreeDtlDB.getF_IBAGREECULTUREDTLSID());
			eachTreeDtl.setCost(IBCommonUtils.getBFCurrencyAmount(eachTreeDtlDB.getF_IBCOST(), ibObj.getCurrency()));
			eachTreeDtl.setEvaluationId(eachTreeDtlDB.getF_IBEVALUATIONID());
			eachTreeDtl.setNoOfTrees(eachTreeDtlDB.getF_IBNOOFTREES());
			eachTreeDtl.setNotes(eachTreeDtlDB.getF_IBNOTES());
			eachTreeDtl
					.setPricePerTree(IBCommonUtils.getBFCurrencyAmount(eachTreeDtlDB.getF_IBPRICEPERTREE(), ibObj.getCurrency()));
			eachTreeDtl.setRequestID(eachTreeDtlDB.getF_IBREQUESTID());
			eachTreeDtl.setSno(eachTreeDtlDB.getF_IBSNO());
			eachTreeDtl.setTitleDeedIDPK(eachTreeDtlDB.getF_IBTITLEDEEDID());
			eachTreeDtl.setTitleDeedNum(eachTreeDtlDB.getF_IBTITLEDEEDNUM());
			eachTreeDtl.setTreeAge(eachTreeDtlDB.getF_IBTREEAGE());
			eachTreeDtl.setTreeDetailsID(eachTreeDtlDB.getBoID());
			eachTreeDtl.setTreeType(eachTreeDtlDB.getF_IBTREETYPE());
			
			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("TREE_GRP_TYP");
      String Desc = "";

      for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
        if (eachTreeDtlDB.getF_IBTREETYPE().equals(gcCode.getCodeReference())) {
          Desc = gcCode.getCodeDescription();
          break;
        }
      }
      eachTreeDtl.setTreeTypeDesc(Desc);
			
			detailsList.addTreesDetailsList(eachTreeDtl);
		}
		return detailsList;
	}

	private BuildingsDetailsList populateBuildingDetails(IslamicBankingObject ibObj,
			IBOCE_IB_TitleDeedDtlsForEvaluation eachTitleDeedRqDtls, String agricultureId) {
		List<IBOCE_IB_BuildingDetails> ib_BuildingDetails = CollateralRequestDtlsUtils
				.readBuildingDtls(eachTitleDeedRqDtls, agricultureId);
		BuildingsDetailsList detailsList = new BuildingsDetailsList();
		for (IBOCE_IB_BuildingDetails eachBuildingDtlDB : ib_BuildingDetails) {
			BuildingDetails eachBuildingDtl = new BuildingDetails();
			eachBuildingDtl.setAgricultureDetailsID(eachBuildingDtlDB.getF_IBAGREECULTUREDTLSID());
			eachBuildingDtl.setBuildingAge(eachBuildingDtlDB.getF_IBBUILDINGAGE());
			eachBuildingDtl.setBuildingDetailsID(eachBuildingDtlDB.getBoID());
			eachBuildingDtl.setBuildingsize(eachBuildingDtlDB.getF_IBBUILDINGSIZE());
			eachBuildingDtl.setBuildingType(eachBuildingDtlDB.getF_IBBUILDINGTYPE());
			eachBuildingDtl.setCost(IBCommonUtils.getBFCurrencyAmount(eachBuildingDtlDB.getF_IBCOST(), ibObj.getCurrency()));
			eachBuildingDtl.setEvaluationId(eachBuildingDtlDB.getF_IBEVALUATIONID());
			eachBuildingDtl.setNotes(eachBuildingDtlDB.getF_IBNOTES());
			eachBuildingDtl
					.setPricePerSqM(IBCommonUtils.getBFCurrencyAmount(eachBuildingDtlDB.getF_IBPRICEPERSQM(), ibObj.getCurrency()));
			eachBuildingDtl.setRequestID(eachBuildingDtlDB.getF_IBREQUESTID());
			eachBuildingDtl.setSno(eachBuildingDtlDB.getF_IBSNO());
			eachBuildingDtl.setTitleDeedIDPK(eachBuildingDtlDB.getF_IBTITLEDEEDID());
			eachBuildingDtl.setTitleDeedNum(eachBuildingDtlDB.getF_IBTITLEDEEDNUM());
			
			ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("BLD_GRP_TYP");
      String Desc = "";

      for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
        if (eachBuildingDtlDB.getF_IBBUILDINGTYPE().equals(gcCode.getCodeReference())) {
          Desc = gcCode.getCodeDescription();
          break;
        }
      }
      eachBuildingDtl.setBuildingTypeDesc(Desc);
			
			detailsList.addBuildingsDetailsList(eachBuildingDtl);
		}
		return detailsList;
	}

	private PersonalRequestdtls populatePersonalRqDtls(IslamicBankingObject ibObj, String requestId) {

		PersonalRequestdtls personalRequestdtls = new PersonalRequestdtls();
		IBCommonUtils.intializeDefaultvalues(personalRequestdtls);
		IBOCE_IB_PersonalRequestDtls ib_PersonalRequestDtls = CollateralRequestDtlsUtils
				.readPersonalRequestDtls(requestId);
		if (ib_PersonalRequestDtls != null) {

			BFCurrencyAmount availableBalance = new BFCurrencyAmount();
			availableBalance.setCurrencyAmount(ib_PersonalRequestDtls.getF_IBAVAILABLEBALANCE());
			availableBalance.setCurrencyCode(ibObj.getCurrency());
			personalRequestdtls.setAvailableBalance(availableBalance);
			BFCurrencyAmount coverValue = new BFCurrencyAmount();
			coverValue.setCurrencyAmount(ib_PersonalRequestDtls.getF_IBCOVERVALUE());
			coverValue.setCurrencyCode(ibObj.getCurrency());
			personalRequestdtls.setCoverValue(coverValue);
			personalRequestdtls.setDescription(ib_PersonalRequestDtls.getF_IBCOLLATERALDESCRIPTION());
			personalRequestdtls.setRelationShipDtlsID(ib_PersonalRequestDtls.getF_IBRELATIONSIPDTLSID());
			personalRequestdtls.setRelationshipType(ib_PersonalRequestDtls.getF_IBRELATIONSHIPTYPE());
			personalRequestdtls.setRequestID(ib_PersonalRequestDtls.getF_IBREQUESTID());
			IBOCE_IB_DealRelationshipDetails dealRelationshipAgents = CollateralRequestDtlsUtils
					.fetchDealRelationshipDtlByID(ib_PersonalRequestDtls.getF_IBRELATIONSIPDTLSID());

			personalRequestdtls.setCustomerId(dealRelationshipAgents.getF_IBPARTYID());
			personalRequestdtls.setRelationshipType(dealRelationshipAgents.getF_IBRELATIONSHIPTYPE());
			personalRequestdtls.setName(dealRelationshipAgents.getF_IBPARTYNAME());
			personalRequestdtls.setNationalID(dealRelationshipAgents.getF_IBPARTYNATIONALID());

			BFCurrencyAmount pledgeAmt = new BFCurrencyAmount();
			pledgeAmt.setCurrencyAmount(dealRelationshipAgents.getF_IBPLEDGEAMOUNT());
			pledgeAmt.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			personalRequestdtls.setPledgeAmount(pledgeAmt);
			personalRequestdtls.setFromDate(dealRelationshipAgents.getF_IBFROMDATE());
			personalRequestdtls.setToDate(dealRelationshipAgents.getF_IBTODATE());
			personalRequestdtls.setPledgeType(dealRelationshipAgents.getF_IBPLEDGETYPE());
			personalRequestdtls.setSiloYear(dealRelationshipAgents.getF_IBSILOYEAR());
			personalRequestdtls.setSiloArea(dealRelationshipAgents.getF_IBSILOAREA());
		}
		return personalRequestdtls;
	}
}
