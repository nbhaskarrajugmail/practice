package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ManageSerialNumberForWell;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;

public class ManageSerailNumForWell extends AbstractCE_IB_ManageSerialNumberForWell {

	private static final long serialVersionUID = 1L;
	private static final Object NEW = "NEW";

	public ManageSerailNumForWell(BankFusionEnvironment env) {
		super(env);

	}

	public ManageSerailNumForWell() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String operation = getF_IN_Operation();
		TechnicalWellDtlsList technicalWellDtlsListOut = getF_OUT_technicalWellDetailsList();
		TechnicalWellDtlsList technicalWellDtlsList = getF_IN_technicalWellDetailsList();
		technicalWellDtlsListOut.removeAllTechnicalWellDtlList();
		if (operation.equals(NEW)) {
			int serialNumber = technicalWellDtlsList.getTechnicalWellDtlList().length;
			if (technicalWellDtlsList.getPagedQuery().getPagingRequest().getNumberOfRows() != 0)
				serialNumber = technicalWellDtlsList.getPagedQuery().getPagingRequest().getNumberOfRows();

			setF_OUT_serialNumber(serialNumber + 1);
		} else {
			for (int i = 0; i < technicalWellDtlsList.getTechnicalWellDtlList().length; i++) {
				TechnicalWellDtl technicalWellDtl = technicalWellDtlsList.getTechnicalWellDtlList(i);
				if (!technicalWellDtl.isSelect()) {
					technicalWellDtl.setSerialNumber(technicalWellDtlsListOut.getTechnicalWellDtlListCount() + 1);
					technicalWellDtlsListOut.addTechnicalWellDtlList(technicalWellDtl);
				}
			}
		}
	}
}
