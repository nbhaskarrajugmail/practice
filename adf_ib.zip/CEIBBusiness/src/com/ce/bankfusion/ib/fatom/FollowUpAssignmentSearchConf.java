package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FollowUpAssignmentConf;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.msgs.v1r0.ListBranchRq;
import bf.com.misys.cbs.msgs.v1r0.ListBranchRs;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.BranchDetailsShort;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.ListBranchDetailsShort;
import bf.com.misys.ib.ilo.types.UserList;

public class FollowUpAssignmentSearchConf extends AbstractCE_IB_FollowUpAssignmentConf {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public FollowUpAssignmentSearchConf() {
        super();
    }

    public FollowUpAssignmentSearchConf(BankFusionEnvironment env) {
        super(env);
    }

    static IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        boolean isAdmin = CeUtils.isloggedInUserFromAdfFollowUpUserGroup();
        setF_OUT_isLocaleUser(!isAdmin);
        ListBranchDetailsShort listBranch = new ListBranchDetailsShort();
        if (isAdmin) {
            listBranch = getBranchList(env);
            if (null != listBranch) {
                setF_OUT_branchList(listBranch);
                UserList user = CeUtils.getUserList(CommonConstants.EMPTY_STRING);
                setF_OUT_defaultUserList(user);
                setF_OUT_branchListForSearchCriteria(listBranch);
            }
        } else {             
            listBranch = getBranchList(env);
            ListBranchDetailsShort listLocaleBranch = new ListBranchDetailsShort();
            if (null != listBranch) {
                BranchDetailsShort[] br = listBranch.getBranchDetailsShort();            
                for (BranchDetailsShort branch : br) {
                    if (branch.getBranchCode().equals(CeUtils.getUserBranchCode())) {
                        listLocaleBranch.addBranchDetailsShort(branch);
                        branch.setSelect(true);
                        setF_OUT_loggedInUserbranch(branch.getBranchCode());
                        UserList user = CeUtils.getUserList(branch.getBranchCode());
                        setF_OUT_userList(user);
                        setF_OUT_defaultUserList(user);
                    }                    
                }              
                setF_OUT_branchList(listBranch);
                setF_OUT_branchListForSearchCriteria(listLocaleBranch);
            }
        }
    }

    private ListBranchDetailsShort getBranchList(BankFusionEnvironment env) {
        Map param = new HashMap<String, List>();
        ListBranchRq listBranchRq = new ListBranchRq();
        param.put("listBranchRq", listBranchRq);
        HashMap<String, Object> outTags = MFExecuter.executeMF(CeConstants.LIST_ALL_BRANCH_SRV, env, param);
        ListBranchRs listBranchRs = (ListBranchRs) outTags.get("ListBranchRs");
        
        ListGenericCodeRs bankNameGC = IBCommonUtils.getGCList("BRANCHNAME");
        for(BranchDetailsShort branch : listBranchRs.getListBranchDetailsShort().getBranchDetailsShort()) {
            for(GcCodeDetail gcItem : bankNameGC.getGcCodeDetails()) {
                if(branch.getBranchCode().equals(gcItem.getCodeReference())) {
                    branch.setBranchName(gcItem.getCodeDescription());
                    break;
                }
            }
        }
        
        return listBranchRs.getListBranchDetailsShort();

    }

}
