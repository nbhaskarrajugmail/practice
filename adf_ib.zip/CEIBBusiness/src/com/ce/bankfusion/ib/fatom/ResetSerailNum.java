package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ResetSerailNum;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;

public class ResetSerailNum extends AbstractCE_IB_ResetSerailNum {

	private static final long serialVersionUID = 1L;

	public ResetSerailNum(BankFusionEnvironment env) {
		super(env);

	}

	public ResetSerailNum() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {

		Integer serialNum = new Integer(0);
		TechnicalAreaCoordinateDtlList technicalAreaCoordinateDtlList = getF_IN_technicalAreaCoordinateList();
		if (technicalAreaCoordinateDtlList.getTechnicalAreaCoordinateDtlList().length > 0) {
			for (TechnicalAreaCoordinateDtl areaCoordinateDtl : technicalAreaCoordinateDtlList
					.getTechnicalAreaCoordinateDtlList()) {
				if(areaCoordinateDtl.getSerail()!=null)
					serialNum = areaCoordinateDtl.getSerail() + 1;
			}
			setF_OUT_serailNum(serialNum);
		} else {
			serialNum = 1;
			setF_OUT_serailNum(serialNum);
		}
		setF_OUT_resetToFalse(false);
	}
}
