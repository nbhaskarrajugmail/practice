package com.ce.bankfusion.ib.fatom;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpAssetDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpCropDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealFollowUpDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealFollowUpDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.bankfusion.calendar.functions.DaysBetweenTwoDates;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealfollowup.dtls.ib.types.DealFollowUpDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpAssetDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpCropDetails;
import bf.com.misys.dealfollowup.dtls.ib.types.FollowUpDetails;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.AssetUDFsCollection;

public class GetDealFollowUpDtls extends AbstractCE_IB_GetDealFollowUpDtls {

	public GetDealFollowUpDtls(BankFusionEnvironment env) {
		super(env);
	}

	ArrayList<String> param = new ArrayList<>();
	private static String dealFollowupAssetDtlsQuery = CeConstants.QUERYSTRING_WHERE
			+ IBOCE_IB_DealFollowUpAssetDtls.IBFOLLOWUPID + " =?";
	private static String dealFollowupCropDtlsQuery = CeConstants.QUERYSTRING_WHERE
			+ IBOCE_IB_DealFollowUpCropDtls.IBDEALFOLLOWUPID + " =?";
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		DealFollowUpDetails dealFollowUpDetails = null;
		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			dealFollowUpDetails = new DealFollowUpDetails();
			AssetUDFsCollection assetUDFsCollection = new AssetUDFsCollection();
			dealFollowUpDetails.setFollowUpAssetUDFs(assetUDFsCollection);
		}
		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_SELECT)) {
			dealFollowUpDetails = getF_OUT_dealFollowUpDetails();
			dealFollowUpDetails.removeAllFollowUpDetails();
			dealFollowUpDetails.removeAllFollowUpAssetDetails();
			dealFollowUpDetails.removeAllFollowUpCropDetails();
			if (getF_IN_dealFollowUpDetails() != null && getF_IN_dealFollowUpDetails().getFollowUpDetailsCount() > 0) {
				for (FollowUpDetails followUpDetails : getF_IN_dealFollowUpDetails().getFollowUpDetails()) {
					if (followUpDetails.isSelect()) {
						Date followUpdate = new Date(followUpDetails.getFollowUpDate().getTime());
						long diffInDays = DaysBetweenTwoDates.run(followUpdate, IBCommonUtils.getBFBusinessDate(),
								IBCommonUtils.getBankFusionEnvironment());
						getF_IN_followUpDetail().setCustomerStatus(followUpDetails.getCustomerStatus());
						getF_IN_followUpDetail().setDateOfTechnicalReport(followUpDetails.getDateOfTechnicalReport());
						getF_IN_followUpDetail().setDealId(followUpDetails.getDealId());
						getF_IN_followUpDetail().setDealStatus(followUpDetails.getDealStatus());
						getF_IN_followUpDetail().setFarmStatus(followUpDetails.getFarmStatus());
						getF_IN_followUpDetail().setFollowUpDate(followUpDetails.getFollowUpDate());
						getF_IN_followUpDetail().setFollowUpDone(followUpDetails.isFollowUpDone());
						getF_IN_followUpDetail().setFollowUpId(followUpDetails.getFollowUpId());
						getF_IN_followUpDetail()
								.setFollowUpOutsideTheSheet(followUpDetails.isFollowUpOutsideTheSheet());
						getF_IN_followUpDetail().setFollowUpStatus(followUpDetails.getFollowUpStatus());
						getF_IN_followUpDetail().setInspectorName(followUpDetails.getInspectorName());
						getF_IN_followUpDetail().setTechnicalReportId(followUpDetails.getTechnicalReportId());
						getF_IN_followUpDetail()
								.setTechnicalReportInspector(followUpDetails.getTechnicalReportInspector());
						getF_IN_followUpDetail().setCropType(followUpDetails.getCropType());
						getF_IN_followUpDetail().setNonSoudiEmployee(followUpDetails.getNonSoudiEmployee());
						getF_IN_followUpDetail().setSoudiEmployee(followUpDetails.getSoudiEmployee());
						getF_IN_followUpDetail().setTotalEmployee(followUpDetails.getTotalEmployee());
						getF_IN_followUpDetail().setWaterUsage(followUpDetails.getWaterUsage());
						getF_IN_followUpDetail().setProductionCapacity(followUpDetails.getProductionCapacity());
						

						/*
						 * Follow up status either (positive) or (negative and difference between
						 * previous followup date and current business date is greater than configured
						 * period), these Follow ups cannot be amended.
						 */
						if (getF_IN_followUpDetail() != null && (getF_IN_followUpDetail().isFollowUpDone()
								|| (int) diffInDays > DealFollowUpUtils.getFollowUpPeriodConfigured())) {
							setF_OUT_disableAllFields(true);
						}
						if (CeUtils.getBBMode(getF_IN_islamicBankingObject()).equals(IBConstants.VIEWMODE))
							setF_OUT_disableAllFields(true);
					}
				}
			}

		}
		getDealFollowUpDtls(dealFollowUpDetails);
		getDealFollowUpAssetDtls(dealFollowUpDetails);
		getDealFollowUpCropDtls(dealFollowUpDetails);
		getAssetUDFs(dealFollowUpDetails);

		setF_OUT_dealFollowUpDetails(dealFollowUpDetails);
		setF_OUT_isDealFollowUpAmendProcess(
				DealFollowUpUtils.isFollowUpAmendProcess(getF_IN_islamicBankingObject().getSearchPageID()));
	}

	private void getAssetUDFs(DealFollowUpDetails dealFollowUpDetails) {
		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpAssetDetailsCount() > 0) {
			AssetUDFsCollection assetUDFsCollection = new AssetUDFsCollection();
			for (FollowUpAssetDetails followUpAssetDetails : dealFollowUpDetails.getFollowUpAssetDetails()) {
				AssetUDF[] techAssetUDFs = CeUtils.getAssetAttributes(followUpAssetDetails.getAssetId(),
						getF_IN_islamicBankingObject().getDealID());
				for (AssetUDF assetUDF : techAssetUDFs) {
					assetUDFsCollection.addAssetUDFs(assetUDF);
				}
			}
			dealFollowUpDetails.setFollowUpAssetUDFs(assetUDFsCollection);
		}
	}

	private void getDealFollowUpCropDtls(DealFollowUpDetails dealFollowUpDetails) {

		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0) {
				for (FollowUpDetails followUpDetails : dealFollowUpDetails.getFollowUpDetails()) {
					List<IBOCE_IB_DealFollowUpCropDtls> dealFollowUpCropDtls = queryDealFollowUpCropDtls(
							followUpDetails);
					if (dealFollowUpCropDtls != null && !dealFollowUpCropDtls.isEmpty()) {
						for (IBOCE_IB_DealFollowUpCropDtls dealFollowUpCropDtl : dealFollowUpCropDtls) {
							FollowUpCropDetails vFollowUpCropDetails = new FollowUpCropDetails();
							vFollowUpCropDetails.setFollowUpId(followUpDetails.getFollowUpId());
							DealFollowUpUtils.fetchTechnicalCropDtl(dealFollowUpCropDtl.getF_IBCROPID(), vFollowUpCropDetails);
							DealFollowUpUtils.fetchDealFollowUpCropDtl(dealFollowUpCropDtl.getBoID(), vFollowUpCropDetails,
									getF_IN_islamicBankingObject().getCurrency());
							dealFollowUpDetails.addFollowUpCropDetails(vFollowUpCropDetails);
						}
					}
				}
			}
		} else {
			getDealFollowUpCropDtlsOnSelect(dealFollowUpDetails);
		}
	}

	private List<IBOCE_IB_DealFollowUpCropDtls> queryDealFollowUpCropDtls(FollowUpDetails followUpDetails) {
		param.clear();
		param.add(followUpDetails.getFollowUpId());
		List<IBOCE_IB_DealFollowUpCropDtls> dealFollowUpCropDtls = (ArrayList<IBOCE_IB_DealFollowUpCropDtls>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealFollowUpCropDtls.BONAME, dealFollowupCropDtlsQuery, param, null, true);
		return dealFollowUpCropDtls;
	}

	private void getDealFollowUpCropDtlsOnSelect(DealFollowUpDetails dealFollowUpDetails) {
		if (getF_IN_followUpDetail() != null && IBCommonUtils.isNullOrEmpty(getF_IN_followUpDetail().getDealId())) {
			DealFollowUpUtils.initializeFollowUpCropDtls(dealFollowUpDetails, getF_OUT_followUpDetail().getFollowUpId(),
					getF_IN_islamicBankingObject().getDealID(), getF_IN_islamicBankingObject().getCurrency());

		} else {
			if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0
					&& getF_IN_dealFollowUpDetails() != null
					&& getF_IN_dealFollowUpDetails().getFollowUpCropDetailsCount() > 0) {
				for (FollowUpCropDetails followUpCropDetails : getF_IN_dealFollowUpDetails().getFollowUpCropDetails()) {
					if (getF_IN_followUpDetail() != null
							&& getF_IN_followUpDetail().getFollowUpId().equals(followUpCropDetails.getFollowUpId())) {
						dealFollowUpDetails.addFollowUpCropDetails(followUpCropDetails);
					}
				}
			}
		}
	}


	private void getDealFollowUpAssetDtls(DealFollowUpDetails dealFollowUpDetails) {

		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0) {
				for (FollowUpDetails followUpDetails : dealFollowUpDetails.getFollowUpDetails()) {
					param.clear();
					param.add(followUpDetails.getFollowUpId());
					List<IBOCE_IB_DealFollowUpAssetDtls> dealFollowUpAssetDtls = (ArrayList<IBOCE_IB_DealFollowUpAssetDtls>) IBCommonUtils
							.getPersistanceFactory().findByQuery(IBOCE_IB_DealFollowUpAssetDtls.BONAME,
									dealFollowupAssetDtlsQuery, param, null, true);
					if (dealFollowUpAssetDtls != null && !dealFollowUpAssetDtls.isEmpty()) {
						for (IBOCE_IB_DealFollowUpAssetDtls dealFollowUpAssetDtl : dealFollowUpAssetDtls) {
							FollowUpAssetDetails vFollowUpAssetDetails = new FollowUpAssetDetails();
							vFollowUpAssetDetails.setAssetExist(dealFollowUpAssetDtl.isF_IBASSETEXIST());
							vFollowUpAssetDetails.setAssetId(dealFollowUpAssetDtl.getF_IBASSETID());
							vFollowUpAssetDetails.setFollowUpId(dealFollowUpAssetDtl.getF_IBFOLLOWUPID());
							vFollowUpAssetDetails.setMachineNumber(dealFollowUpAssetDtl.getF_IBMACHINENUMBER());
							vFollowUpAssetDetails.setNotes(dealFollowUpAssetDtl.getF_IBFOLLOWUPNOTES());
							vFollowUpAssetDetails
									.setSpecificationsOnSite(dealFollowUpAssetDtl.getF_IBSPECIFICATIONSONSITE());

							DealFollowUpUtils.fetchAssetDetails(getF_IN_islamicBankingObject(),dealFollowUpAssetDtl.getF_IBASSETID(),
									vFollowUpAssetDetails);
							dealFollowUpDetails.addFollowUpAssetDetails(vFollowUpAssetDetails);
						}
					}
				}
			}
		} else {
			getDealFollowUpAssetDtlsOnSelect(dealFollowUpDetails);
		}

	}

	private void getDealFollowUpAssetDtlsOnSelect(DealFollowUpDetails dealFollowUpDetails) {
		if (getF_IN_followUpDetail() != null && IBCommonUtils.isNullOrEmpty(getF_IN_followUpDetail().getDealId())) {
			DealFollowUpUtils.initializeFollowupAssetDtls(getF_IN_islamicBankingObject(), dealFollowUpDetails,
					getF_OUT_followUpDetail().getFollowUpId(), getF_IN_islamicBankingObject().getDealID());
		} else {
			if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0
					&& getF_IN_dealFollowUpDetails() != null
					&& getF_IN_dealFollowUpDetails().getFollowUpAssetDetailsCount() > 0) {
				for (FollowUpAssetDetails followUpAssetDetails : getF_IN_dealFollowUpDetails()
						.getFollowUpAssetDetails()) {
					if (getF_IN_followUpDetail() != null
							&& getF_IN_followUpDetail().getFollowUpId().equals(followUpAssetDetails.getFollowUpId())) {
						dealFollowUpDetails.addFollowUpAssetDetails(followUpAssetDetails);
					}
				}
			}
		}
	}

	public void getDealFollowUpDtls(DealFollowUpDetails dealFollowUpDetails) {
		boolean isDealFollowUpAmendProcess = DealFollowUpUtils
				.isFollowUpAmendProcess(getF_IN_islamicBankingObject().getSearchPageID());
		boolean isFollowUpInProgress = false;
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			List<IBOCE_IB_DealFollowUpDtls> dealFollowUpDtls = DealFollowUpUtils
					.getFollowUpDtlsFromDB(getF_IN_islamicBankingObject().getDealID());
			if (dealFollowUpDtls != null && !dealFollowUpDtls.isEmpty()) {
				for (IBOCE_IB_DealFollowUpDtls dtls : dealFollowUpDtls) {
					getDealFollowUpDtlsOnLoad(dealFollowUpDetails, dealDetails, dtls);
				}
			}
		} else {
			getDealFollowUpDtlsOnSelect(dealDetails);
		}

		if (dealFollowUpDetails != null && dealFollowUpDetails.getFollowUpDetailsCount() > 0) {
			for (FollowUpDetails details : dealFollowUpDetails.getFollowUpDetails()) {
				if (!details.getFollowUpDone()) {
					Date followUpdate = new Date(details.getFollowUpDate().getTime());
					long diffInDays = DaysBetweenTwoDates.run(followUpdate, IBCommonUtils.getBFBusinessDate(),
							IBCommonUtils.getBankFusionEnvironment());
					if ((int) diffInDays <= DealFollowUpUtils.getFollowUpPeriodConfigured())
						isFollowUpInProgress = true;
				}
			}

			dealFollowUpDetails.getFollowUpDetails(dealFollowUpDetails.getFollowUpDetailsCount() - 1).setSelect(true);
		}

		if (isDealFollowUpAmendProcess || isFollowUpInProgress)
			setF_OUT_disableNewFollowUpButton(true);

	}

	private void getDealFollowUpDtlsOnSelect(IBOIB_DLI_DealDetails dealDetails) {
		if (getF_IN_followUpDetail() != null && IBCommonUtils.isNullOrEmpty(getF_IN_followUpDetail().getDealId())) {
			FollowUpDetails vFollowUpDetails = DealFollowUpUtils.initializeFollowUpDetail(dealDetails);
			setF_OUT_followUpDetail(vFollowUpDetails);
		} else {
			setF_OUT_followUpDetail(getF_IN_followUpDetail());
			getF_OUT_dealFollowUpDetails().addFollowUpDetails(getF_IN_followUpDetail());
		}
	}

	private void getDealFollowUpDtlsOnLoad(DealFollowUpDetails dealFollowUpDetails, IBOIB_DLI_DealDetails dealDetails,
			IBOCE_IB_DealFollowUpDtls dtls) {
		IBOCE_IB_TechnicalFarm technicalFarmObj = (IBOCE_IB_TechnicalFarm) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_IB_TechnicalFarm.BONAME, dtls.getF_IBTECHREPORTID(), true);
		Date followUpdate = new Date(dtls.getF_IBFOLLOWUPDATE().getTime());
		FollowUpDetails vFollowUpDetails = new FollowUpDetails();
		vFollowUpDetails.setCustomerStatus(dtls.getF_IBCUSTOMERSTATUS());
		vFollowUpDetails.setDealId(getF_IN_islamicBankingObject().getDealID());
		vFollowUpDetails.setDealStatus(
				IBCommonUtils.getGCChildDesc(DealInitiationConstants.DEALSTATUS, dealDetails.getF_Status()));
		vFollowUpDetails.setFarmStatus(dtls.getF_IBFARMSTATUS());
		vFollowUpDetails.setFollowUpDate(followUpdate);
		vFollowUpDetails.setFollowUpDone(dtls.isF_IBFOLLOWUPDONE());
		vFollowUpDetails.setFollowUpId(dtls.getBoID());
		vFollowUpDetails.setFollowUpOutsideTheSheet(dtls.isF_IBFOLLOWUPOUTSIDESHEET());
		vFollowUpDetails.setFollowUpStatus(dtls.getF_IBFOLLOWUPSTATUS());
		vFollowUpDetails.setInspectorName(dtls.getF_IBINSPECTORNAME());

		vFollowUpDetails.setCropType(dtls.getF_IBCROPTYPE());
		vFollowUpDetails.setNonSoudiEmployee(dtls.getF_IBNONSOUDIEMPLOYEE());
		vFollowUpDetails.setProductionCapacity(dtls.getF_IBPRODUCTIONCAPACITY());
		vFollowUpDetails.setProjectStatus(dtls.getF_IBPROJECTSTATUS());
		vFollowUpDetails.setSoudiEmployee(dtls.getF_IBSOUDIEMPLOYEE());
		vFollowUpDetails.setTotalEmployee(dtls.getF_IBTOTALEMPLOYEE());
		vFollowUpDetails.setWaterUsage(dtls.getF_IBWATERUSAGE());
		
		if (technicalFarmObj != null) {
			vFollowUpDetails.setDateOfTechnicalReport(technicalFarmObj.getF_IBDATE());
			vFollowUpDetails.setTechnicalReportInspector(technicalFarmObj.getF_IBINSPECTOR());
			vFollowUpDetails.setTechnicalReportId(technicalFarmObj.getBoID());
		}

		dealFollowUpDetails.addFollowUpDetails(vFollowUpDetails);
	}

}
