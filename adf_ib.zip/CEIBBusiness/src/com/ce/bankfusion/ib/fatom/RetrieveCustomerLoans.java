/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchTxnNationalIDMap;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_RetrieveCustomerLoans;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ub.common.lending.LendingConstants;
import com.misys.ub.common.lending.LendingUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_EnterpriseDetail;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetails;
import bf.com.misys.ib.types.CustomerDueDetail;
import bf.com.misys.ib.types.CustomerDueDetailsList;

/**
 * @author Aklesh
 *
 */
public class RetrieveCustomerLoans extends AbstractCE_ADF_RetrieveCustomerLoans {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String WHERE_CLAUSE = "WHERE " + IBOCE_ADF_BatchTxnNationalIDMap.BATCHID + "=? ORDER BY "+IBOCE_ADF_BatchTxnNationalIDMap.DUEDATE+" ASC";
	private static final String loanScheduleWhereClause = "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + "=?";

	public RetrieveCustomerLoans(BankFusionEnvironment env) {
		super(env);

	}

	public RetrieveCustomerLoans() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		if (!getF_IN_nationalID().isEmpty()) {
			getF_OUT_customerDueDetailsList().removeAllCustomerDueDetails();
			String batchID = getF_IN_batchID();
			ArrayList params = new ArrayList<>();
			params.add(batchID);
			List<IBOCE_ADF_BatchTxnNationalIDMap> nationalIDMaps = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, WHERE_CLAUSE, params, null, true);
			if (nationalIDMaps != null && !nationalIDMaps.isEmpty()) {
				for (IBOCE_ADF_BatchTxnNationalIDMap loans : nationalIDMaps) {
					CustomerDueDetail customerDueDetail = new CustomerDueDetail();
					customerDueDetail.setBatchID(batchID);
					customerDueDetail.setDealAccountID(loans.getF_LOANACCOUNTID());
					BFCurrencyAmount dueAmount = new BFCurrencyAmount();
					dueAmount.setCurrencyAmount(loans.getF_DUEAMOUNT());
					dueAmount.setCurrencyCode("SAR");
					customerDueDetail.setDueAmount(dueAmount);

					BFCurrencyAmount dueAmountPaid = new BFCurrencyAmount();
					dueAmountPaid.setCurrencyAmount(loans.getF_DUEAMOUNTPAID());
					dueAmountPaid.setCurrencyCode("SAR");
					customerDueDetail.setDueAmountPaid(dueAmountPaid);

					customerDueDetail.setDueDate(loans.getF_DUEDATE());
					customerDueDetail.setProcess(loans.isF_PROCESS());
					customerDueDetail.setUserRole(loans.getF_ROLE());
					customerDueDetail.setTransactionID(loans.getF_TRANSACTIONID());
					getF_OUT_customerDueDetailsList().addCustomerDueDetails(customerDueDetail);
				}
			} else {
			    String partyID = CommonConstants.EMPTY_STRING;
				String FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_PersonalDetails.NATIONALIDTYPEID + " = ? AND "
						+ IBOPT_PFN_PersonalDetails.NATIONALID + " = ? ";
				ArrayList qParams = new ArrayList();
				qParams.add("NATIONAL_ID_001");
				qParams.add(getF_IN_nationalID());
				IBOPT_PFN_PersonalDetails personalDtl = (IBOPT_PFN_PersonalDetails) BankFusionThreadLocal
						.getPersistanceFactory()
						.findFirstByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_CUSTOMERID, qParams, true);
				if (personalDtl != null) {
				    partyID = personalDtl.getBoID();
				}else {
				    FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_EnterpriseDetail.REGISTEREDNUMBER + " = ? ";
	                qParams.clear();
	                qParams.add(getF_IN_nationalID());
	                IBOPT_PFN_EnterpriseDetail enterpriseDetail = (IBOPT_PFN_EnterpriseDetail) BankFusionThreadLocal
	                        .getPersistanceFactory()
	                        .findFirstByQuery(IBOPT_PFN_EnterpriseDetail.BONAME, FIND_CUSTOMERID, qParams, true);
	                if (enterpriseDetail != null) {
	                    partyID = enterpriseDetail.getBoID();
	                }
				}
				setF_OUT_customerDueDetailsList(
                        getCustomerLiabilities(partyID, batchID, getF_IN_totalAvailableAmount()));
			}
		} else {
			getF_OUT_customerDueDetailsList().removeAllCustomerDueDetails();
		}
	}

	public static CustomerDueDetailsList getCustomerLiabilities(String customerId, String batchID,BigDecimal totalAvailableAmount) {
		CustomerDueDetailsList detailsList = new CustomerDueDetailsList();
		String relationshipTypes = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.RELATIONSHIP_TYPES_CONF_FILE, CeConstants.RELATIONSHIP_TYPES, "",
				CeConstants.ADFIBCONFIGLOCATION);
		List<String> relationshipTypeslist = new ArrayList<>();
		if (relationshipTypes != null && !relationshipTypes.isEmpty()) {
			relationshipTypeslist = IBCommonUtils.isNotEmpty(relationshipTypes)
					? Arrays.asList(relationshipTypes.split(","))
					: new ArrayList<String>();
		}
		ListGenericCodeRs associationTypes = IBCommonUtils.getGCList("ASSCTYPE");
		ListGenericCodeRs relationshipTypesGC = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
		Map<String, String> gcCodes = new HashMap<>();
		for (GcCodeDetails gcCodeDetails : associationTypes.getGcCodeDetails()) {
			gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
		}
		for (GcCodeDetails gcCodeDetails : relationshipTypesGC.getGcCodeDetails()) {
			gcCodes.put(gcCodeDetails.getCodeReference(), gcCodeDetails.getCodeDescription());
		}

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<HashMap> dealInfos = CeUtils.getDealIdsByCustomerId(customerId);
		CustomerDueDetailsList CustomerDueDetailList = new CustomerDueDetailsList();
		if (null != dealInfos && dealInfos.size() > 0) {
			for (int i = 0; i < dealInfos.size(); i++) {
				IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
						.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, (String) dealInfos.get(i).get("dealId"), true);
				if (null != dealDetails.getF_DealAccountId()
						&& !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {

					HashMap outstandingAmt = getOutstandingAmt(dealDetails.getF_DealAccountId());
                    BigDecimal outstandingAmount = (BigDecimal) outstandingAmt.get("OUTSTANDINGAMOUNT");
                    // if (outstandingAmount.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
                    String userRoleRef = (String) dealInfos.get(i).get("userRole");
                    CustomerDueDetail customerDueDetail = new CustomerDueDetail();
                    customerDueDetail.setBatchID(batchID);
                    customerDueDetail.setDealAccountID(dealDetails.getF_DealAccountId());
                    BFCurrencyAmount dueAmount = new BFCurrencyAmount();
                    dueAmount.setCurrencyAmount(outstandingAmount);
                    dueAmount.setCurrencyCode("SAR");
                    customerDueDetail.setDueAmount(dueAmount);
                    customerDueDetail.setDueDate((Date) outstandingAmt.get("DUEDATE"));
                    customerDueDetail.setProcess(false);
                    customerDueDetail.setUserRole(userRoleRef);
                    CustomerDueDetailList.addCustomerDueDetails(customerDueDetail);
                    // }
				}
			}
		}
		//gcCodes.get(userRoleRef)
		List<CustomerDueDetail> customerList = new ArrayList<>();
		List<CustomerDueDetail> relationshipList = new ArrayList<>(); 
		List<CustomerDueDetail> sortedRelationshipList = new ArrayList<>(); 
		List<CustomerDueDetail> finalList = new ArrayList<>(); 
		List<CustomerDueDetail> liabilities = Arrays.asList(CustomerDueDetailList.getCustomerDueDetails());
		for (CustomerDueDetail customerDueDetail : liabilities) {
			if(customerDueDetail.getUserRole().equals("PC")) {
				customerList.add(customerDueDetail);
			}else {
				relationshipList.add(customerDueDetail);
			}
		}
		customerList.sort((o1, o2) -> o1.getDueDate().compareTo(o2.getDueDate()));
		for(String type: relationshipTypeslist) {
			for(CustomerDueDetail customerDueDetail:relationshipList) {
				if(customerDueDetail.getUserRole().equals(type))
					sortedRelationshipList.add(customerDueDetail);
			}
		}
		
		finalList.addAll(customerList);
		finalList.addAll(sortedRelationshipList);
		for (CustomerDueDetail customerDueDetail : finalList) {
			BigDecimal amountCanBePaid = BigDecimal.ZERO;
			if(customerDueDetail.getDueAmount().getCurrencyAmount().compareTo(totalAvailableAmount)<=CommonConstants.INTEGER_ZERO) {
				amountCanBePaid = customerDueDetail.getDueAmount().getCurrencyAmount();
				totalAvailableAmount = totalAvailableAmount.subtract(amountCanBePaid);
			}else if(totalAvailableAmount.compareTo(BigDecimal.ZERO)>CommonConstants.INTEGER_ZERO) {
				amountCanBePaid = totalAvailableAmount;
				totalAvailableAmount = totalAvailableAmount.subtract(amountCanBePaid);
			}
			
			BFCurrencyAmount dueAmountPaid = new BFCurrencyAmount();
			dueAmountPaid.setCurrencyAmount(amountCanBePaid);
			dueAmountPaid.setCurrencyCode("SAR");
			customerDueDetail.setDueAmountPaid(dueAmountPaid);
			customerDueDetail.setUserRole(gcCodes.get(customerDueDetail.getUserRole()));
			detailsList.addCustomerDueDetails(customerDueDetail);
		}
		return detailsList;
	}

	private static HashMap getOutstandingAmt(String loanAccountID) {
		HashMap details = new HashMap();
		BigDecimal outstandingAmt = BigDecimal.ZERO;
		Date dueDate = null;
		Map dueAmountMap = null;
		try {
			List<IBOLendingFeature> loanDetaisList = (List<IBOLendingFeature>) FinderMethods
					.findLoanDetailsByAccountID(loanAccountID, BankFusionThreadLocal.getBankFusionEnvironment(), null);
			if (loanDetaisList != null && !loanDetaisList.isEmpty()) {
				IBOLendingFeature loanDetails = loanDetaisList.get(0);
				if (!loanDetails.getF_LOANSTATUS().equals(LendingConstants.LOAN_STATUS_COMPLETED)) {
					dueAmountMap = LendingUtils.getTotalDueAmount(loanAccountID, false, loanDetails,
							BankFusionThreadLocal.getUserSession().getBranchSortCode(), null, false);
				}
			}
			outstandingAmt = (BigDecimal) dueAmountMap.get(LendingConstants.TOTAL_DUE_AMOUNT);
			dueDate = new java.sql.Date(
					((java.util.Date) dueAmountMap.get(LendingConstants.CURRENT_REPAYMENT_DATE)).getTime());
		} catch (Exception e) {
			System.err.println(
					"Error occured while fetching details for Loan:" + loanAccountID + e.getLocalizedMessage());
		}
		details.put("OUTSTANDINGAMOUNT", outstandingAmt);
		details.put("DUEDATE", dueDate);
		return details;
	}
}