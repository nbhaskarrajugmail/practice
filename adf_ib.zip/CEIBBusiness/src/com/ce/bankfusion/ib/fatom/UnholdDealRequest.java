package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UnholdDealRequest;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class UnholdDealRequest extends AbstractCE_IB_UnholdDealRequest {
    
    public UnholdDealRequest() {
        super();
    }
    @SuppressWarnings("deprecation")
    public UnholdDealRequest(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        DealHoldUtil.requestUnHoldDeal(getF_IN_islamicBankingObject().getDealID(), getF_IN_reason());
    }

}
