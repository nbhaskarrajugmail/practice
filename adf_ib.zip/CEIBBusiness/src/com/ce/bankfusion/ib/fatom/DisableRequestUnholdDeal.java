package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DisableRequestUnholdDeal;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DisableRequestUnholdDeal extends AbstractCE_IB_DisableRequestUnholdDeal{

	private static final String BB_ID = "Request Unhold Deal";

	public DisableRequestUnholdDeal() {
		super();
	}
	
    @SuppressWarnings("deprecation")
	public DisableRequestUnholdDeal(BankFusionEnvironment env) {
		super(env);
	}
    
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
    	
    	IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
    	IBOIB_CFG_BuildingBlockConfig buildingBlockConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, ibObject.getProductID(), ibObject.getSubProductID(), ibObject.getStepID(), ibObject.getProcessConfigID());
    	if (buildingBlockConfig.getF_BUILDINGBLOCKMODE().contains(IBConstants.VIEWMODE) || ibObject.isIsDealEnquiry()) {
    		setF_OUT_readOnly(true);
    	}
    	else {
    		setF_OUT_readOnly(false);
    	}
 
    }

}
