package com.ce.bankfusion.ib.fatom;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DocumentSourceForCollateral;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SearchDocumentSourceDtls;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.DocumentSourceDtls;
import com.misys.ce.types.DocumentSourceDtlsRsType;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class SearchDocumentSourceDtls extends AbstractCE_IB_SearchDocumentSourceDtls{
	
	private String documentWhere = "WHERE " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTID + " = ? AND " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTVALUE + " = ? ";
	private String documentSourceWhere = "WHERE " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTID + " LIKE ? OR " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTVALUE + " LIKE ? ORDER BY " + IBOCE_IB_DocumentSourceForCollateral.IBSNO;
	private String documentIdWhere= "WHERE " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTID + " = ? ";
	private String documentValueWhere= "WHERE " + IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTVALUE + " = ? ";
	
	public SearchDocumentSourceDtls(BankFusionEnvironment env) {
		super(env);
	}

	public SearchDocumentSourceDtls() {
		super();
	}

	@Override
	public void process(BankFusionEnvironment env) {

		
		String documentID= getF_IN_documentSourceDtlsRq().getDocumentID();
		String documentValue= getF_IN_documentSourceDtlsRq().getDocumentValue();
		int noOfRows= getF_IN_documentSourceDtlsRq().getPagingInfo().getPagingRequest().getNumberOfRows();
		int requestedPage= getF_IN_documentSourceDtlsRq().getPagingInfo().getPagingRequest().getRequestedPage();
		if(noOfRows==0 || requestedPage==0) {
			noOfRows=20;
			requestedPage=1;
		}
		PagingData pdata = new PagingData(requestedPage, noOfRows);
		pdata.setRequiresTotalPages(true);
        
    	 DocumentSourceDtlsRsType docSrcRs = new DocumentSourceDtlsRsType();
    		 
    		if(!documentID.isEmpty() && documentValue.isEmpty()) {
    			ArrayList<Object> docID = new ArrayList<Object>();
    	        docID.add(documentID);
    			List<IBOCE_IB_DocumentSourceForCollateral>  docIdList= BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DocumentSourceForCollateral.BONAME, documentIdWhere, docID, pdata, false);
    			if(null!=docIdList) {
    				docSrcRs= populateSearchData(docIdList, env);	
    			}
    		}
    		else if(documentID.isEmpty() && !documentValue.isEmpty()) {
    			ArrayList<Object> docValue = new ArrayList<Object>();
    	    	docValue.add(documentValue);
    			List<IBOCE_IB_DocumentSourceForCollateral>  docValueList= BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DocumentSourceForCollateral.BONAME, documentValueWhere, docValue, pdata, false);
    			if(null!=docValueList) {
    				docSrcRs= populateSearchData(docValueList, env);
    			}
    		}
    		else if(!(documentID.isEmpty() && documentValue.isEmpty())) {
    			ArrayList<String> documentSourceParam = new ArrayList<String>();
    			documentSourceParam.add(documentID);
    			documentSourceParam.add(documentValue);
    			List<IBOCE_IB_DocumentSourceForCollateral>  docSrcList= BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DocumentSourceForCollateral.BONAME, documentWhere, documentSourceParam, pdata, false);
    			if(null!=docSrcList) {
    				docSrcRs= populateSearchData(docSrcList, env);
    			}
    		}
    		else {
    			ArrayList<String> docSrcParam = new ArrayList<String>();
    			docSrcParam.add("%");
    			docSrcParam.add("%");
    			 List<IBOCE_IB_DocumentSourceForCollateral> resultSet = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_DocumentSourceForCollateral.BONAME, documentSourceWhere, docSrcParam, pdata, true);
 				if(null!=resultSet) {
 					docSrcRs= populateSearchData(resultSet, env);
 				}
    		}
    		PagedQuery pagedQuery = new PagedQuery();
 		    PagingRequest pagingRequest = new PagingRequest();
 		    pagingRequest.setNumberOfRows(pdata.getPageSize());
 		    pagingRequest.setRequestedPage(pdata.getCurrentPageNumber());
 		    pagingRequest.setTotalPages(pdata.getTotalPages());
 		       
 		    pagedQuery.setPagingRequest(pagingRequest);
 		    docSrcRs.setPagingInfo(pagedQuery);
 		        
 		    setF_OUT_documentSourceDtlsRs(docSrcRs);
    					
   	}
	
	private DocumentSourceDtlsRsType populateSearchData(List<IBOCE_IB_DocumentSourceForCollateral> resultSet,
			BankFusionEnvironment env) {
		DocumentSourceDtlsRsType documentSourceDtlsRs = new DocumentSourceDtlsRsType();
		
		if(resultSet!=null) {
			 for(IBOCE_IB_DocumentSourceForCollateral source: resultSet) {
				 DocumentSourceDtls documentSourceDtls = new DocumentSourceDtls();
				
				 Map resultMap = source.getDataMap();
				 documentSourceDtls.setDocumentID((String) resultMap.get(IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTID));
				 documentSourceDtls.setDocumentValue((String) resultMap.get(IBOCE_IB_DocumentSourceForCollateral.IBDOCUMENTVALUE));
				 documentSourceDtls.setSNo((Integer) resultMap.get(IBOCE_IB_DocumentSourceForCollateral.IBSNO));
				 documentSourceDtlsRs.addListDocumentSourceDtls(documentSourceDtls);
		}
	}
		return documentSourceDtlsRs;
	}
}
