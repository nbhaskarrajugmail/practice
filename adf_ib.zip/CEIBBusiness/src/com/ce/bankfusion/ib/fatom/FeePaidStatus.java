package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FeePaidStatus;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.ib.types.IslamicBankingObject;

public class FeePaidStatus extends AbstractCE_IB_FeePaidStatus {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7448862190871356905L;
	/**
	 * 
	 */
	private static final Log LOGGER = LogFactory.getLog(FeePaidStatus.class);

	public FeePaidStatus(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		IslamicBankingObject bankingObject= getF_IN_islamicBankingObject();
		ErrorResponse errorResponse = new ErrorResponse();
		boolean feesPaid = false;
		boolean feesCollectedManually = false;
		BigDecimal totalAmountToBePaid = BigDecimal.ZERO;
		BigDecimal totalPaidAmount = BigDecimal.ZERO;
		BigDecimal totalDealFeesUnpaidAmount = BigDecimal.ZERO;
		String dealID = bankingObject.getDealID();
		String fee_collection_method = CommonConstants.EMPTY_STRING;
		try {
		fee_collection_method = SadadPaymentUtils.queryDealAditionalDtlsUDCheckSADAD(bankingObject.getDealID());
				
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE "+ IBOCE_IB_FeesPaymentStatus.IBDEALID+"=?" +" AND "+ IBOCE_IB_FeesPaymentStatus.IBFEESPAYMENTISCANCEL+"=?";
		String dealFeesClause = "WHERE "+ IBOIB_DLI_DealAssetChargesdtls.DealNo+"=?" +" AND "+ IBOIB_DLI_DealAssetChargesdtls.FEESCONFIGID+"=?";
		String sadadPaymentCancelledQuery = "WHERE "+IBOCE_IB_SadadPayments.IBDEALID+" = ?" +" AND "+ IBOCE_IB_SadadPayments.IBUSERDELETE+"=?" +" AND "+ IBOCE_IB_SadadPayments.IBSTATUS+"=?";
		String dealAllFeesClause = "WHERE "+ IBOIB_DLI_DealAssetChargesdtls.DealNo+"=?" +" AND "+ IBOIB_DLI_DealAssetChargesdtls.ISWAIVED+"=?";
		ArrayList params = new ArrayList<>();
		params.add(dealID);
		params.add("N");
		LOGGER.info("*********In Fees Paid Loop*******For Deal***"+dealID);
		List<IBOCE_IB_FeesPaymentStatus> feePayments=factory.findByQuery(IBOCE_IB_FeesPaymentStatus.BONAME, whereClause, params, null, false);
		for (IBOCE_IB_FeesPaymentStatus iboce_IB_FeesPaymentStatus : feePayments) {

			if(iboce_IB_FeesPaymentStatus.getF_IBFEESPAYMENTFAMNT().compareTo(iboce_IB_FeesPaymentStatus.getF_IBFEESPAYMENTAMNTPAID())==0) {
				params.clear();
				params.add(dealID);
				params.add(iboce_IB_FeesPaymentStatus.getF_IBFEESPAYMENTFEESID());
				List<IBOIB_DLI_DealAssetChargesdtls> dealFeesList=factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, dealFeesClause, params, null, false);

				for(IBOIB_DLI_DealAssetChargesdtls dealFees: dealFeesList) {
					LOGGER.info("*********Update Fees Status to Paid**********");
					dealFees.setF_CHARGEPAYMENTSTATUS("PAID");
					//currently, as there is no scenario of partial payment, updating the both 
					//unpaidChargeAmt and unpaidTaxAmt as zero 
					dealFees.setF_UNPAIDCHARGEAMOUNT(CommonConstants.BIGDECIMAL_ZERO);
					dealFees.setF_UNPAIDTAXAMOUNT(CommonConstants.BIGDECIMAL_ZERO);
					dealFeesList.set(0, dealFees);
				}
				String sadadPaymentQuery = "WHERE "+IBOCE_IB_SadadPayments.IBINVOICEID+" = ?";
				params.clear();
				params.add(iboce_IB_FeesPaymentStatus.getBoID());
				List<IBOCE_IB_SadadPayments> sadadPaymentList =factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, sadadPaymentQuery, params, null, false);
				if(sadadPaymentList != null && !sadadPaymentList.isEmpty())
				{
					sadadPaymentList.get(0).setF_IBSTATUS(CeConstants.SADAD_PYMT_PAID);
				}
			}
			LOGGER.info("*********In Fees Paid Loop**********");
			totalAmountToBePaid = totalAmountToBePaid.add(iboce_IB_FeesPaymentStatus.getF_IBFEESPAYMENTFAMNT());
			totalPaidAmount = totalPaidAmount.add(iboce_IB_FeesPaymentStatus.getF_IBFEESPAYMENTAMNTPAID());
		}
		
		
		errorResponse.setOVERALLSTATUS("NOTPAID");
		if(totalAmountToBePaid.compareTo(totalPaidAmount)==0) {
			feesPaid = true;
			errorResponse.setOVERALLSTATUS("PAID");
			
		}else {
			feesPaid = false;
		}
		
		//For Cancel Invoice
			
		params.clear();
		params.add(dealID);
		params.add("Y");
		params.add(CeConstants.SADAD_PYMT_CANCELLED);
		List<IBOCE_IB_SadadPayments> sadadPaymentCancelList =factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, sadadPaymentCancelledQuery, params, null, false);
		
		params.clear();
		params.add(dealID);
		params.add("N");
		params.add(CeConstants.SADAD_PYMT_ON_SADAD);
		List<IBOCE_IB_SadadPayments> sadadPaymentList =factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, sadadPaymentCancelledQuery, params, null, false);
		
		
		boolean isSadadCancelled = false;
		boolean isPaymentOnSadad = false;
		
		if(sadadPaymentCancelList != null && !sadadPaymentCancelList.isEmpty())
			isSadadCancelled = true;
		
		if(sadadPaymentList != null && !sadadPaymentList.isEmpty())
			isPaymentOnSadad = true;
		
		params.clear();
		params.add(dealID);
		params.add("N");
		List<IBOIB_DLI_DealAssetChargesdtls> dealFeesList=factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, dealAllFeesClause, params, null, false);
		
		if(!isPaymentOnSadad && isSadadCancelled) {
			
			for(IBOIB_DLI_DealAssetChargesdtls dealFees: dealFeesList) {
				
				if(dealFees.getF_UNPAIDCHARGEAMOUNT() != null)
				totalDealFeesUnpaidAmount =totalDealFeesUnpaidAmount.add(dealFees.getF_UNPAIDCHARGEAMOUNT());
				if(dealFees.getF_UNPAIDTAXAMOUNT() != null)
				totalDealFeesUnpaidAmount =totalDealFeesUnpaidAmount.add(dealFees.getF_UNPAIDTAXAMOUNT());
				
			}
			
			if(totalDealFeesUnpaidAmount.compareTo(BigDecimal.ZERO) > 0) {
				errorResponse.setOVERALLSTATUS("CANCELLED");
			}
		
		}
		// End Cancel Invoice
		
		if(dealFeesList.isEmpty() || !fee_collection_method.equalsIgnoreCase("SADAD")) {
				errorResponse.setOVERALLSTATUS("PAID");
			}
		}
		catch(Exception e)
		{
			LOGGER.error("Error occurred in Sadad Fees Loop.");
		}
		
				
		
		setF_OUT_responseObject(errorResponse);
		setF_OUT_islamicBankingObject(bankingObject);
	}
}