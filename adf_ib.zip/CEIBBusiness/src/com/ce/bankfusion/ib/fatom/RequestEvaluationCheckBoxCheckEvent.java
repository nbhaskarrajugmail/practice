package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RequestEvaluationCheckBoxCheck;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class RequestEvaluationCheckBoxCheckEvent extends AbstractCE_IB_RequestEvaluationCheckBoxCheck {

	private static final long serialVersionUID = 1L;
	private static final transient Log LOG = LogFactory.getLog(RequestEvaluationCheckBoxCheckEvent.class.getName());

	public RequestEvaluationCheckBoxCheckEvent() {
		super();

	}

	public RequestEvaluationCheckBoxCheckEvent(BankFusionEnvironment env) {
		super(env);

	}

	@Override
	public void process(BankFusionEnvironment env) {
		
		setF_OUT_checkBoxCheckEvent(true);

	}
}
