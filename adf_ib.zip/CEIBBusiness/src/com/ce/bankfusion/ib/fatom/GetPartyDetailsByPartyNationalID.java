package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetPartyDetailsByPartyNationalID;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Party;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class GetPartyDetailsByPartyNationalID extends AbstractCE_IB_GetPartyDetailsByPartyNationalID {

	private static final Log LOGGER = LogFactory.getLog(GetPartyDetailsByPartyNationalID.class);
	private static final String FIND_PARTY_PERSONAL_DET = "WHERE " + IBOPT_PFN_PersonalDetails.NATIONALID + " = ?";
	String internalPartyId = CommonConstants.EMPTY_STRING;

	public GetPartyDetailsByPartyNationalID(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		validateNationalId();
		getPartyName();
	}

	private void getPartyName() {
		IBOPT_PFN_Party partyDetails = (IBOPT_PFN_Party) IBCommonUtils.getPersistanceFactory()
				.findByPrimaryKey(IBOPT_PFN_Party.BONAME, internalPartyId, true);
		if (partyDetails != null) {
			setF_OUT_partyID(partyDetails.getBoID());
			setF_OUT_partyName(partyDetails.getF_NAME());
		}
	}

	private void validateNationalId() {
		LOGGER.info("Entered nationalId is" + getF_IN_partyNationalId());
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_partyNationalId());

		List<IBOPT_PFN_PersonalDetails> partyPersonalDetails = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_PARTY_PERSONAL_DET, params, null, true);

		if (partyPersonalDetails == null || partyPersonalDetails.isEmpty()) {
			IBCommonUtils.raiseUnparameterizedEvent(44000249);
		}

		if (partyPersonalDetails != null && !partyPersonalDetails.isEmpty()) {
			internalPartyId = partyPersonalDetails.get(0).getBoID();
		}
	}

}