package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOAssetDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ActivateAndDisbursement;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_FeesConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealFinDisbmntTxnInfo;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealFinancialDisbursementDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentScheduleDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.LoadFeesToCollect;
import com.misys.bankfusion.ib.fatom.ReadSchedules;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.ib.msgs.v1r0.MaintainDisbursementDetails;
import bf.com.misys.ib.schedule.payments.service.GenerateIslamicPaymentScheduleRs;
import bf.com.misys.ib.spi.types.DisbursementAccountDetail;
import bf.com.misys.ib.spi.types.DisbursementScheduleDetail;
import bf.com.misys.ib.spi.types.DisbursementScheduleInputDetails;
import bf.com.misys.ib.spi.types.DisbursementScheduleOutputDetails;
import bf.com.misys.ib.spi.types.DownPaymentAndUtilizationDetail;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.PaymentSchedule;
import bf.com.misys.ib.spi.types.PaymentScheduleList;
import bf.com.misys.ib.spi.types.messages.LoanDetails;
import bf.com.misys.ib.spi.types.messages.MaintainDisbursementDetailsRq;
import bf.com.misys.ib.spi.types.messages.MaintainDisbursementDetailsRs;
import bf.com.misys.ib.spi.types.messages.PostManualCollectionDetailsRq;
import bf.com.misys.ib.spi.types.messages.PostManualCollectionDetailsRs;
import bf.com.misys.ib.spi.types.messages.ReadAccountKeys;
import bf.com.misys.ib.spi.types.messages.ReadAccountRq;
import bf.com.misys.ib.spi.types.messages.ReadAccountRs;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanDetailsInput;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRq;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.DealIDInput;
import bf.com.misys.ib.types.DisbursementInfo;
import bf.com.misys.ib.types.DownPaymentDetails;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.FeeToBeCollected;
import bf.com.misys.ib.types.FeeToBeCollectedList;
import bf.com.misys.ib.types.FinancialInfoDetail;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.PurchaseOrderDetails;
import bf.com.misys.ib.types.RuleInputData;
import bf.com.misys.ib.types.RuleInputRq;
import bf.com.misys.ib.types.SystemObjectOutputDetail;
import bf.com.misys.ib.types.SystemParam;
import bf.com.misys.ib.types.header.RqHeader;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;
import edu.emory.mathcs.backport.java.util.Arrays;

public class ActivateAndDisbursement extends AbstractCE_IB_ActivateAndDisbursement {

	/**
	 * 
	 */
  private static final Log LOGGER = LogFactory.getLog(ActivateAndDisbursement.class);

	private static final long serialVersionUID = 1L;
	private static final String READACCOUNT = "IB_SPI_ReadAccount_SRV";
	private static String currencyCode;
	private IslamicBankingObject islamicBankingObject;
	private IBOIB_DLI_DealDetails dealDetails;
	private ProductConfiguration productDetails;
	CustomerLiabilities[] customerLiability;
	public static String PAYMENTORDER_CONTEXT = "RD_PAYMENTORDER";
	private static final String STATUS_APPROVED = "Approved";
	private static final String STATUS_DISBURSED = "Disbursed";
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	private PoAssetDisbursementDetails[] poAssetDisbursementDtls;
	private static String GET_ISSUEPOASSET_QUERY = " WHERE "+IBOCE_IB_IssuePOAssetDetail.IBPURCHASEORDERID+" = ? AND "+IBOCE_IB_IssuePOAssetDetail.IBASSETID+" = ?";
	private static String GET_REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBDEALNO+" = ? AND "+IBOCE_IB_AssetProgressReport.IBREPORTID+" = ?";
	private ReadLoanDetailsRs readLoanDetails;
	private BigDecimal latestProfitAmount = BigDecimal.ZERO;
	private int E_ISSUE_PO_PROFIT_POSTING_NARRATIVE_IB =44000426;
	MaintainDisbursementDetailsRq maintainDisbursementDetailsRq;
	MaintainDisbursementDetails maintainDisbursementDetails;
	private List<Date> invoiceUpdateDatesList = new ArrayList<Date>();
	
	public ActivateAndDisbursement(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("process method Starts here");
		BigDecimal fullPaymentOrderAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal progReportAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal adjustFeesToBePaid = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal feesToBePaid = CommonConstants.BIGDECIMAL_ZERO;
		String purchaseOrderID = CommonConstants.EMPTY_STRING;
		String progressReportID = CommonConstants.EMPTY_STRING;
		islamicBankingObject = getF_IN_islamicBankingObject();
		dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		productDetails = IBCommonUtils.loadProductConfiguration(islamicBankingObject.getDealID());
		IssuePOFatom issuePOFatom = new IssuePOFatom(env);
		issuePOFatom.setF_IN_islamicBankingObject(islamicBankingObject);
		issuePOFatom.setF_IN_mode("RETRIEVE");
		issuePOFatom.process(env);
		IssuePayOrderDtls issuePaymentOrders = issuePOFatom.getF_OUT_issuePayOrderDtls();
		customerLiability= issuePaymentOrders.getCustomerLiabilitiesDtls();
		poAssetDisbursementDtls = issuePaymentOrders.getPoAssetDisbursementDetails();
		factory = BankFusionThreadLocal.getPersistanceFactory();
		readLoanDetails = IBCommonUtils
				.getLoanDetails(islamicBankingObject.getDealID());
		BigDecimal prevTotalProfitAmount = BigDecimal.ZERO;
		if(BigDecimal.ZERO.compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount())!=0)
			prevTotalProfitAmount = readLoanDetails.getDealDetails().getLoanBasicDetails().getProfitAmt();
		else
			prevTotalProfitAmount = BigDecimal.ZERO;
		//readIssuePayOrderDtls
				//.fetchIssuePODtls(islamicBankingObject.getDealID());
		for(PurchaseOrderDetails purchaseOrder:issuePaymentOrders.getPurchaseOrderDetails()) {
			if(purchaseOrder.getPoStatus().equals(STATUS_APPROVED)) {
				purchaseOrderID = purchaseOrder.getPurchaseOrderID();
				progressReportID = purchaseOrder.getProgressReportID();
				fullPaymentOrderAmount = purchaseOrder.getPoAmount().getCurrencyAmount();
				progReportAmount = purchaseOrder.getProgressReportAmount().getCurrencyAmount();
				adjustFeesToBePaid = purchaseOrder.getAdjustmentFeesToBePaid();
				feesToBePaid = purchaseOrder.getFeesToBePaid();
			}
		}
		//paidFees = issuePaymentOrders.getF_FEESTOBEPAID();
		
		if (fullPaymentOrderAmount.compareTo(BigDecimal.ZERO) > 0) {
			try {
				LOGGER.info("Before calling generateSchedule");
				generateSchedule(env);
				LOGGER.info("generateSchedule Completed");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOGGER.error("Error While generating Schedule");
				e.printStackTrace();
				throw e;
			}
			try {
				LOGGER.info("Before calling financeDisbursementAPI");
				ReadSchedules readSchedules = new ReadSchedules();
				readSchedules.setF_IN_dealId(islamicBankingObject.getDealID());
				readSchedules.process(env);
				maintainDisbursementDetails = readSchedules.getF_OUT_maintainDisbursementDetails();
				financeDisbursementAPI(env, fullPaymentOrderAmount, purchaseOrderID, progressReportID); 
				LOGGER.info("Before calling rescheduleAPI");
				rescheduleAPI(env);
				// collectFeesAPI(env, paidFees);
				ReadLoanDetailsRs readLoanDetailsAfterReschedule = IBCommonUtils
						.getLoanDetails(islamicBankingObject.getDealID());
				latestProfitAmount = readLoanDetailsAfterReschedule.getDealDetails().getLoanBasicDetails().getProfitAmt();
				if (RescheduleUtils.isNonFrontLoadedManual(islamicBankingObject.getSubProductID(),
						dealDetails.getF_DealAccountId(), productDetails.isIsHostScheduleGenerator())) {
					LOGGER.info("Before calling prepareAndDoProfitPosting");
					prepareAndDoProfitPosting(prevTotalProfitAmount, purchaseOrderID, env);
				}
				LOGGER.info("Before calling updateIsDealFullyDisbursed");
				CeUtils.updateIsDealFullyDisbursed(islamicBankingObject.getDealID());
				LOGGER.info("Before calling updateProgressReportAndIssuePODetails");
				updateProgressReportAndIssuePODetails(purchaseOrderID, progressReportID, fullPaymentOrderAmount,
						progReportAmount);
				LOGGER.info("Before calling postFeesAndUpdateTables");
				postFeesAndUpdateTables(feesToBePaid, adjustFeesToBePaid);
				if(!invoiceUpdateDatesList.isEmpty())
				{
					LOGGER.info("Before calling updateInvoiceForRepayment");
					SadadPaymentUtils.updateInvoiceForRepayment(islamicBankingObject.getDealID(),
						dealDetails.getF_DealAccountId(), invoiceUpdateDatesList);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				LOGGER.error("Error While updating Disbursements Details");
				e.printStackTrace();
				filterDisbursedPOAssets(issuePaymentOrders);
				reverseDisbursements(env);
				throw e;
			}
		}
		LOGGER.info("process method Ends here");
	}

	private void filterDisbursedPOAssets(IssuePayOrderDtls issuePaymentOrders) {
		if (BigDecimal.ZERO.compareTo(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()) != 0) {
			for (PoAssetDisbursementDetails poDetails : issuePaymentOrders.getPoAssetDisbursementDetails()) {
				for (PurchaseOrderDetails purchaseOrder : issuePaymentOrders.getPurchaseOrderDetails()) {
					if (purchaseOrder.getPoStatus().equals(STATUS_APPROVED)
							&& poDetails.getPurchaseOrderID().equals(purchaseOrder.getPurchaseOrderID())) {
						issuePaymentOrders.removePoAssetDisbursementDetails(poDetails);
					}
				}
			}
		} else {
			int index = 0;
			for (PoAssetDisbursementDetails poDetails : issuePaymentOrders.getPoAssetDisbursementDetails()) {
				if (index == 0)
					poDetails.getCurrentDisbursedAmount().setCurrencyAmount(
							readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt());
				else
					issuePaymentOrders.removePoAssetDisbursementDetails(poDetails);
				index++;
			}
		}
		poAssetDisbursementDtls = issuePaymentOrders.getPoAssetDisbursementDetails();
	}

	private void reverseDisbursements(BankFusionEnvironment env) {
		ArrayList<DisbursementInfo> preparedDisburseDetails = new ArrayList<DisbursementInfo>();
		List<IBOIB_IDI_DealFinDisbmntTxnInfo> financialDisbursementTransactionInfo = getDealFinDisbursementTxnInfo();
		if (financialDisbursementTransactionInfo.size() > 0) {
			String finaceDtlswhereClause = "WHERE " + IBOIB_IDI_DealFinancialDisbursementDTL.DEALFINDISBMNTTXNINFOID
					+ " = ?";
			ArrayList<String> params = new ArrayList<String>();
			params.clear();
			params.add(financialDisbursementTransactionInfo.get(0).getBoID());
			List<IBOIB_IDI_DealFinancialDisbursementDTL> finDisburseDtls = (List<IBOIB_IDI_DealFinancialDisbursementDTL>) BankFusionThreadLocal
					.getPersistanceFactory().findByQuery(IBOIB_IDI_DealFinancialDisbursementDTL.BONAME,
							finaceDtlswhereClause, params, null, true);
			if (finDisburseDtls.size() > 0) {
				for (IBOIB_IDI_DealFinancialDisbursementDTL finDisburseDtl : finDisburseDtls) {
					DisbursementInfo disburseInfo = new DisbursementInfo();
					disburseInfo.setDisbursementId(finDisburseDtl.getF_HOSTDISBURSEMENTID());
					disburseInfo.setDisbursementStatus(IBConstants.DISBURSEMENT_ACTION_REVERSE);
					preparedDisburseDetails.add(disburseInfo);
				}
			}
		}
		factory.rollbackTransaction();
		factory.beginTransaction();
		if(!preparedDisburseDetails.isEmpty())
		{
			RescheduleLoanRq spiRescheduleLoanRq = new RescheduleLoanRq();
	        RescheduleLoanDetailsInput rescheduleLoanDetailsInput = new RescheduleLoanDetailsInput();
			for (DisbursementScheduleDetail disbursementInfo : maintainDisbursementDetailsRq
					.getDisbursementScheduleInputDetails().getDisbursementScheduleDetails()) {
				if (IBConstants.DISBURSEMENT_ACTION_REVERSE.equals(disbursementInfo.getActionMode())) {
					maintainDisbursementDetailsRq.getDisbursementScheduleInputDetails()
							.removeDisbursementScheduleDetails(disbursementInfo);
				}
				if (IBConstants.DISBURSEMENT_ACTION_EXECUTE.equals(disbursementInfo.getActionMode())) {
					disbursementInfo.setActionMode(IBConstants.DISBURSEMENT_ACTION_REVERSE);
					disbursementInfo.setDisbursementId(preparedDisburseDetails.get(0).getDisbursementId());
					disbursementInfo.setProfitAmonut(BigDecimal.ZERO);
				}
			}
			if (BigDecimal.ZERO.compareTo(
					readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()) == 0) {
				DisbursementScheduleDetail[] disbursementScheduleDtls = prepareDisbursementSchedulDetail(
						maintainDisbursementDetails.getDisbursementInfo(), env);
				if (null != disbursementScheduleDtls && disbursementScheduleDtls.length > 0) {
					for (DisbursementScheduleDetail disbursementScheduleDetail : disbursementScheduleDtls) {
						maintainDisbursementDetailsRq.getDisbursementScheduleInputDetails()
								.addDisbursementScheduleDetails(disbursementScheduleDetail);
					}
				}
			}
			prepareRescheduleAPIInput(rescheduleLoanDetailsInput);
			HashMap params = new HashMap();
			maintainDisbursementDetailsRq.getDisbursementScheduleInputDetails().removeAllPaymentSchedules();
			params.put("maintainDisbursementDetailsRq", maintainDisbursementDetailsRq);
			HashMap outputParams = MFExecuter.executeMF(IBSPIConstants.MAINTAIN_DISBURSEMENT_MFID, env, params);
			MaintainDisbursementDetailsRs maintainDisbursementRs = (MaintainDisbursementDetailsRs) outputParams
					.get(IBSPIConstants.MAINTAIN_DISBURSEMENT_MF_OUTPUT_PARAMNAME);

			if (maintainDisbursementRs != null
					&& maintainDisbursementRs.getRsHeader().getStatus().getOverallStatus().equals("S")) {
				callRescheduleAPI(env, spiRescheduleLoanRq, rescheduleLoanDetailsInput);
			}
		}
	}
	
	private DisbursementScheduleDetail[] prepareDisbursementSchedulDetail(DisbursementInfo[] disbursementDetail,
			BankFusionEnvironment env) {
		boolean firstReadyDisbursementCheckFlag = false;
		ArrayList<DisbursementScheduleDetail> disScheduleDetails = new ArrayList<DisbursementScheduleDetail>();
		for (DisbursementInfo eachDisburse : disbursementDetail) {
			DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
			disbursementScheduleDetail.setActionMode(IBConstants.DISBURSEMENT_ACTION_CREATE);
			disbursementScheduleDetail.setDisbursementAmount(
					IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(),
							eachDisburse.getDisbursementAmount().getCurrencyAmount()));
			disbursementScheduleDetail.setDisbursementCurrency(eachDisburse.getDisbursementAmount().getCurrencyCode());
			disbursementScheduleDetail.setDisbursementDate(eachDisburse.getDisbursementDate());
			disbursementScheduleDetail.setDisbursementId(eachDisburse.getDisbursementId());
			disbursementScheduleDetail.setDisbursementmentNo(eachDisburse.getDisbursementNo());
			disbursementScheduleDetail.setDisbursementNarrative(CommonConstants.EMPTY_STRING);
			if (!productDetails.isIsHostScheduleGenerator() && !firstReadyDisbursementCheckFlag) {
				dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
				disbursementScheduleDetail.setProfitAmonut(dealDetails.getF_ProfitAmt());
				firstReadyDisbursementCheckFlag = true;
			} else {
				disbursementScheduleDetail.setProfitAmonut(BigDecimal.ZERO);
			}
			disbursementScheduleDetail.setDisbursementStatus(eachDisburse.getDisbursementStatus());
			disbursementScheduleDetail.setDisbursementType(IBConstants.DISBURSEMENT_TYPE_MANUAL);

			DisbursementAccountDetail spiDisbursementAccDtl = new DisbursementAccountDetail();

			spiDisbursementAccDtl.setDisbursementAccount(eachDisburse.getDisbursementAccount());
			spiDisbursementAccDtl.setDisbursementAccountFormatType(eachDisburse.getDisbursementAccountType());
			spiDisbursementAccDtl.setDisbursementAmount(
					IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(),
							eachDisburse.getDisbursementAmount().getCurrencyAmount()));
			spiDisbursementAccDtl.setDisbursementMode("2286");
			disbursementScheduleDetail.addDisbursementAccountDetailList(spiDisbursementAccDtl);
			disScheduleDetails.add(disbursementScheduleDetail);
		}
		return disScheduleDetails
				.toArray((DisbursementScheduleDetail[]) new DisbursementScheduleDetail[disScheduleDetails.size()]);
	}

	private void prepareAndDoProfitPosting(BigDecimal prevTotalProfitAmount, String purchaseOrderID, BankFusionEnvironment env) {
		BigDecimal currentDisbProfitAmt = latestProfitAmount.subtract(prevTotalProfitAmount);
		if (currentDisbProfitAmt.compareTo(BigDecimal.ZERO) > 0) {
			String debitAcctId = RescheduleUtils.getInterestRecAccountID(dealDetails.getF_DealAccountId(),
					dealDetails.getF_BranchSortCode(), dealDetails.getF_IsoCurrencyCode());
			String creditAcctId = RescheduleUtils.getUnearnedAcc(dealDetails.getF_BranchSortCode(),
					dealDetails.getF_IsoCurrencyCode());
			String narrative = RescheduleUtils.getEventCodeLocalizedMessage(dealDetails.getF_DealAccountId(), purchaseOrderID,
					E_ISSUE_PO_PROFIT_POSTING_NARRATIVE_IB, env);
			CEUtil ceUtil = new CEUtil();
			String drTxnCode = null;
			String crTxnCode = null;
			drTxnCode = ceUtil.getModuleConfigurationValue(RescheduleUtils.MODULE_NAME_IB, RescheduleUtils.PO_DEBIT_PARAM_NAME);
			crTxnCode = ceUtil.getModuleConfigurationValue(RescheduleUtils.MODULE_NAME_IB, RescheduleUtils.PO_CREDIT_PARAM_NAME);
			RescheduleUtils.callBackOfficePostingRequest(dealDetails.getF_DealAccountId(),
					islamicBankingObject.getDealID(), islamicBankingObject.getTransactionID(), currentDisbProfitAmt,
					creditAcctId, debitAcctId, dealDetails.getF_DealAccountId()+"$"+narrative, drTxnCode, crTxnCode);
		}
	}

	private void postFeesAndUpdateTables(BigDecimal feesToBePaid,BigDecimal adjustFeesToBePaid) {
    	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
    	String transactionID = getF_IN_islamicBankingObject().getTransactionID();
		LoadFeesToCollect loadFeesToCollect = new LoadFeesToCollect(env);
		getF_IN_islamicBankingObject().setTransactionID(getF_IN_islamicBankingObject().getDealID());
		loadFeesToCollect.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		loadFeesToCollect.process(env);
		FeeToBeCollectedList feesToBeCollected = loadFeesToCollect.getF_OUT_FeeToBeCollectedList();
		String intialFeeId= BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
	            CeConstants.INITIAL_FEES_FEESID, "", CeConstants.ADFIBCONFIGLOCATION);
		String adjustmentFeesId= BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
	            CeConstants.ADJUSTMENT_FEES_FEESID, "", CeConstants.ADFIBCONFIGLOCATION);
		for (FeeToBeCollected feeToBeCollected : feesToBeCollected.getFeesToBeCollected()) {
			IBOIB_CFG_FeesConfig feeConfig = (IBOIB_CFG_FeesConfig) BankFusionThreadLocal.getPersistanceFactory()
                    .findByPrimaryKey(IBOIB_CFG_FeesConfig.BONAME, feeToBeCollected.getFeeID(), true);
			if(null != feeConfig)
			{
			if (adjustmentFeesId.equalsIgnoreCase(feeConfig.getF_FEESID()) && adjustFeesToBePaid.compareTo(BigDecimal.ZERO)>0) {
				IBOIB_DLI_DealAssetChargesdtls assetChargesdtls= (IBOIB_DLI_DealAssetChargesdtls) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, feeToBeCollected.getDealAssetChgDtlsID(), true);
				 String taxTobePaidRuleId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
	            CeConstants.ADJUSTMENT_FEES_PAID_TAX_RULE, "", CeConstants.ADFIBCONFIGLOCATION);
	        BigDecimal paidTaxAmt=IBCommonUtils.scaleAmount(assetChargesdtls.getF_ChargeCurrency(), executeFeeRule(taxTobePaidRuleId));
	        assetChargesdtls.setF_UNPAIDCHARGEAMOUNT(assetChargesdtls.getF_UNPAIDCHARGEAMOUNT().subtract(adjustFeesToBePaid));
	        assetChargesdtls.setF_UNPAIDTAXAMOUNT(assetChargesdtls.getF_UNPAIDTAXAMOUNT().subtract(paidTaxAmt));		        
			} 
			else if (intialFeeId.equalsIgnoreCase(feeConfig.getF_FEESID()) && feesToBePaid.compareTo(BigDecimal.ZERO)>0) {
				IBOIB_DLI_DealAssetChargesdtls assetChargesdtls= (IBOIB_DLI_DealAssetChargesdtls) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, feeToBeCollected.getDealAssetChgDtlsID(), true);
			  String taxTobePaidRuleId = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.ISSUE_PAY_ORDER_CONF_FILE,
            CeConstants.INITIAL_FEES_PAID_TAX_RULE, "", CeConstants.ADFIBCONFIGLOCATION);
				BigDecimal paidTaxAmt=IBCommonUtils.scaleAmount(assetChargesdtls.getF_ChargeCurrency(), executeFeeRule(taxTobePaidRuleId));
				assetChargesdtls.setF_UNPAIDCHARGEAMOUNT(assetChargesdtls.getF_UNPAIDCHARGEAMOUNT().subtract(feesToBePaid));
				assetChargesdtls.setF_UNPAIDTAXAMOUNT(assetChargesdtls.getF_UNPAIDTAXAMOUNT().subtract(paidTaxAmt));
			}
			}
		}
		HashMap param = new HashMap();
		param.clear();
		param.put("islamicBankingObject", getF_IN_islamicBankingObject());
		HashMap outputParams = MFExecuter.executeMF("IB_IDI_PostCollectedFees_PRC", env, param);
		getF_IN_islamicBankingObject().setTransactionID(transactionID);
		
	}

	private void updateProgressReportAndIssuePODetails(String purchaseOrderID, String progressReportID,
			BigDecimal fullPaymentOrderAmount, BigDecimal progReportAmount) {
		BigDecimal totalPOAmount = CommonConstants.BIGDECIMAL_ZERO; 
		String WHERE_CLAUSE_POS_FOR_SAME_REPORT = "WHERE " + IBOCE_IB_IssuePODetail.IBREPORTID + "=? ";
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();

		params.add(progressReportID);
		List<IBOCE_IB_IssuePODetail> progressReport = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_IssuePODetail.BONAME, WHERE_CLAUSE_POS_FOR_SAME_REPORT, params, null);
		for (IBOCE_IB_IssuePODetail iboce_IB_IssuePODetail : progressReport) {
			totalPOAmount = totalPOAmount.add(iboce_IB_IssuePODetail.getF_IBPOAMOUNT());
		}
		
		if (progReportAmount.compareTo(totalPOAmount) == CommonConstants.INTEGER_ZERO) {
			params.clear();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add(progressReportID);
			List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory
					.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
			for (IBOCE_IB_AssetProgressReport report : assetProgressReportList) {
				report.setF_IBSTATUS(STATUS_DISBURSED);
			}
		}
		for (PoAssetDisbursementDetails assetDisbursementDetails : poAssetDisbursementDtls) {
			if (purchaseOrderID.equals(assetDisbursementDetails.getPurchaseOrderID())) {
				params.clear();
				params.add(purchaseOrderID);
				params.add(assetDisbursementDetails.getAssetID());
				List<IBOCE_IB_IssuePOAssetDetail> issuePOAssetDetails = factory
						.findByQuery(IBOCE_IB_IssuePOAssetDetail.BONAME, GET_ISSUEPOASSET_QUERY, params, null, true);
				for (IBOCE_IB_IssuePOAssetDetail iboce_IB_IssuePOAssetDetail : issuePOAssetDetails) {
					iboce_IB_IssuePOAssetDetail.setF_IBDISBURSEDAMOUNT(assetDisbursementDetails.getCurrentDisbursedAmount().getCurrencyAmount());
				}
			}
		}
	}
	private void rescheduleAPI(BankFusionEnvironment env) {
        RescheduleLoanRq spiRescheduleLoanRq = new RescheduleLoanRq();
        RescheduleLoanDetailsInput rescheduleLoanDetailsInput = new RescheduleLoanDetailsInput();
        prepareRescheduleAPIInput(rescheduleLoanDetailsInput);
        callRescheduleAPI(env, spiRescheduleLoanRq, rescheduleLoanDetailsInput);
	}

	private void prepareRescheduleAPIInput(RescheduleLoanDetailsInput rescheduleLoanDetailsInput) {
		LoanDetails loanDetails = new LoanDetails();
        dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
        loanDetails.setDealBranch(dealDetails.getF_BranchSortCode());
        String currencyCode = dealDetails.getF_IsoCurrencyCode();
        loanDetails.setDealCurrency(currencyCode);
        loanDetails.setDealID(islamicBankingObject.getDealID());
        loanDetails.setLoanAccountNo(dealDetails.getF_DealAccountId());
        ProductConfiguration productdetails = IBCommonUtils.loadProductConfiguration(islamicBankingObject.getProductID(),
                islamicBankingObject.getSubProductID());
        loanDetails.setIsHostScheduleGenerator(productdetails.isIsHostScheduleGenerator());
        loanDetails.setProductID(islamicBankingObject.getProductID());
        loanDetails.setSubProductID(islamicBankingObject.getSubProductID());
        loanDetails.setRepaymentType(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
        loanDetails.setPaymentStartDate(dealDetails != null ? dealDetails.getF_FirstRepaymentDate() : new Date(0));
        
        rescheduleLoanDetailsInput.setLoanDetails(loanDetails);
        BigDecimal outStandingPrincipal = BigDecimal.ZERO;
        for (PoAssetDisbursementDetails poDetails : poAssetDisbursementDtls) {
				outStandingPrincipal = outStandingPrincipal.add(poDetails.getCurrentDisbursedAmount().getCurrencyAmount());
		}
        loanDetails.setProfitAmt(IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_ProfitAmt()));
        CePaymentSchedule[] paymentSchedules = getNewSchedule(islamicBankingObject.getDealID(), dealDetails.getF_IsoCurrencyCode());
        List<CePaymentSchedule> newScheduleList = Arrays.asList(paymentSchedules);
        Date paymentDateForInvoiceGeneration = RescheduleUtils.getPaymentDateForInvoiceGeneration();
        if (!productdetails.isIsHostScheduleGenerator() && !newScheduleList.isEmpty()) {
            for (CePaymentSchedule paymentSchedule : newScheduleList) {
                LoanPayments loanPayment = new LoanPayments();
                loanPayment.setFeeAmt(IBCommonUtils.scaleAmount(currencyCode, BigDecimal.ZERO));
                loanPayment.setIsoCurrencyCode(currencyCode);
                loanPayment.setPrincipleAmt(
                        IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getPrincipalAmount().getCurrencyAmount()));
                loanPayment.setProfitAmt(IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getProfitAmount()
                        .getCurrencyAmount().add(paymentSchedule.getFeesAmount().getCurrencyAmount())));
                loanPayment.setProfitRate(dealDetails.getF_ProfitRate());
                loanPayment.setRepaymentAmt(
                        IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getTotalRepaymentAmount().getCurrencyAmount()));
                loanPayment.setRepaymentDate(paymentSchedule.getRepaymentDate());
                loanPayment.setRepaymentNo(paymentSchedule.getRepaymentNo());
                loanPayment.setRepaymentType(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
                outStandingPrincipal = outStandingPrincipal.subtract(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
                loanPayment.setOutstandingPrincipalAmt(IBCommonUtils.scaleAmount(currencyCode, outStandingPrincipal));
                rescheduleLoanDetailsInput.addManualPaymentSchedule(loanPayment);
				if(CalendarUtil.IsDate1GreaterThanDate2(paymentDateForInvoiceGeneration,loanPayment.getRepaymentDate()))
                {
                	invoiceUpdateDatesList.add(loanPayment.getRepaymentDate());
                }
            }
        }
	}

	private void callRescheduleAPI(BankFusionEnvironment env, RescheduleLoanRq spiRescheduleLoanRq,
			RescheduleLoanDetailsInput rescheduleLoanDetailsInput) {
		RqHeader rqHeader = new RqHeader();
        spiRescheduleLoanRq.setRescheduleLoanDetailsInput(rescheduleLoanDetailsInput);
        spiRescheduleLoanRq.setRqHeader(rqHeader);
        HashMap<String, Object> param = new HashMap<String, Object>();
        param.put(IBSPIConstants.SCH_AMENDMENT_MF_INPUT_PARAMNAME, spiRescheduleLoanRq);
        MFExecuter.executeMF(IBSPIConstants.SCH_AMENDMENT_MFID, env, param);
	}
	public static CePaymentSchedule[] getNewSchedule(String dealId, String currencyCode) {
		CePaymentSchedule[] cePaymentSchedules = null;
		String schHisQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);

		List<IBOCE_IB_PaymentSchBreakup> schHistory = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, schHisQuery, params, null, false);
		if (schHistory != null && !schHistory.isEmpty()) {
			Map<Date, ArrayList<CePaymentSchedule>> dateAndpaymentScheduleMap = new HashMap();
			for (IBOCE_IB_PaymentSchBreakup paymentScheduleHistory : schHistory) {
				if(CalendarUtil.IsDate1GreaterThanDate2(paymentScheduleHistory.getF_IBBILLDATE(), IBCommonUtils.getBFBusinessDate())
						|| CalendarUtil.IsDate1EqualsToDate2(paymentScheduleHistory.getF_IBBILLDATE(), IBCommonUtils.getBFBusinessDate())) {
					CePaymentSchedule vCurrentSchedule = new CePaymentSchedule();
					vCurrentSchedule.setFeesAmount(IBCommonUtils
							.getBFCurrencyAmount(paymentScheduleHistory.getF_IBSCHEDULEFEEAMT(), currencyCode));
					vCurrentSchedule.setPrincipalAmount(IBCommonUtils
							.getBFCurrencyAmount(paymentScheduleHistory.getF_IBPRINCIPALAMT(), currencyCode));
					vCurrentSchedule.setProfitAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleHistory.getF_IBPROFITAMT(), currencyCode));
					vCurrentSchedule.setRepaymentDate(paymentScheduleHistory.getF_IBBILLDATE());
					vCurrentSchedule.setSubsidyAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleHistory.getF_IBSUBSIDYAMNT(), currencyCode));
					if (dateAndpaymentScheduleMap.containsKey(vCurrentSchedule.getRepaymentDate())) {
						dateAndpaymentScheduleMap.get(vCurrentSchedule.getRepaymentDate()).add(vCurrentSchedule);
					} else {
						ArrayList<CePaymentSchedule> paymentSchedules = new ArrayList<>();
						paymentSchedules.add(vCurrentSchedule);
						dateAndpaymentScheduleMap.put(vCurrentSchedule.getRepaymentDate(), paymentSchedules);
					}
				}
			}
			cePaymentSchedules = new CePaymentSchedule[dateAndpaymentScheduleMap.size()];
			RescheduleUtils.addSameDateRepayments(dateAndpaymentScheduleMap, cePaymentSchedules, currencyCode);
		}
		return cePaymentSchedules;
	}
	private GenerateIslamicPaymentScheduleRs getOnlyFuturePayments(
			GenerateIslamicPaymentScheduleRs generateIslamicPaymentScheduleRs) {
		GenerateIslamicPaymentScheduleRs generateIslamicPaymentScheduleRsOp = new GenerateIslamicPaymentScheduleRs();
		for (bf.com.misys.ib.schedule.payments.PaymentSchedule paymentSchedule : generateIslamicPaymentScheduleRs
				.getPaymentSchedule()) {
			if (paymentSchedule.getRepaymentDate().compareTo(IBCommonUtils.getBFBusinessDate()) >= 0) {
				bf.com.misys.ib.schedule.payments.PaymentSchedule vPaymentSchedule = paymentSchedule;
				generateIslamicPaymentScheduleRsOp.addPaymentSchedule(vPaymentSchedule);
			}
		}
		return generateIslamicPaymentScheduleRsOp;
	}

	private void financeDisbursementAPI(BankFusionEnvironment env, BigDecimal fullPaymentOrderAmount, String purchaseOrderID,String progressReportID) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		maintainDisbursementDetailsRq = new MaintainDisbursementDetailsRq();
		DisbursementScheduleInputDetails disbursementScheduleInputDetails = new DisbursementScheduleInputDetails();
		IBOIB_DLI_DealDetails dealDtl = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		String account = dealDtl.getF_DealAccountId();
		currencyCode = dealDtl.getF_IsoCurrencyCode();
		disbursementScheduleInputDetails.setLoanAccountNumber(account);
		String branch = dealDtl.getF_BranchSortCode();
		disbursementScheduleInputDetails.setBranchId(branch);
		disbursementScheduleInputDetails.setProductId(dealDtl.getF_ProductCode());
		disbursementScheduleInputDetails.setSubProductId(dealDtl.getF_ProductContextCode());

		ReadAccountRq readAccountRq = new ReadAccountRq();
		ReadAccountKeys accountKeys = new ReadAccountKeys();
		accountKeys.setAccountID(account);
		readAccountRq.setAccountKeys(accountKeys);
		//TODO This API call can be avoided
		HashMap params = new HashMap();
		params.put("ReadAccountRq", readAccountRq);
		HashMap output = MFExecuter.executeMF(READACCOUNT, env, params);
		ReadAccountRs readAccountRs = (ReadAccountRs) output.get("ReadAccountRs");
		disbursementScheduleInputDetails.setAccountFormatType(readAccountRs.getAccountDetails().getAccountBasicDetails()
				.getAccountKeys().getInputAccount().getAccountFormatType());
		disbursementScheduleInputDetails.setConstructionEndDate(maintainDisbursementDetails.getConstructEndDate());
		disbursementScheduleInputDetails.setDealId(islamicBankingObject.getDealID());
		disbursementScheduleInputDetails
				.setDisbursementScheduleDetails(prepareDisbursementSchedulDetail(maintainDisbursementDetails, env,fullPaymentOrderAmount));
		disbursementScheduleInputDetails.setDownPaymentAndUtilizationDetails(
				prepareDownPaymentDetails(maintainDisbursementDetails.getDownPaymentDetails(), env));
		// disbursementScheduleInputDetails.setPaymentSchedules(vPaymentSchedulesArray);
		// This set is required only for EQ
		maintainDisbursementDetailsRq.setDisbursementScheduleInputDetails(disbursementScheduleInputDetails);
		param.clear();
		param.put("maintainDisbursementDetailsRq", maintainDisbursementDetailsRq);
		HashMap outputParams = MFExecuter.executeMF(IBSPIConstants.MAINTAIN_DISBURSEMENT_MFID, env, param);
		MaintainDisbursementDetailsRs maintainDisbursementRs = (MaintainDisbursementDetailsRs) outputParams
				.get(IBSPIConstants.MAINTAIN_DISBURSEMENT_MF_OUTPUT_PARAMNAME);
		AssetInfoAndStudyFatom andStudyFatom = new AssetInfoAndStudyFatom(env);
        andStudyFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
        andStudyFatom.setF_IN_mode("RETRIEVE");
        andStudyFatom.process(env);
        AssetThirdPartyDetails [] assetTPDetails= andStudyFatom.getF_OUT_assetThirdPartyDetailsList().getAssetThirdPartyDetails();
		if (maintainDisbursementRs != null
				&& maintainDisbursementRs.getRsHeader().getStatus().getOverallStatus().equals("S")) {

			// update IB tables
			updateDisbursmentInfo(disbursementScheduleInputDetails, maintainDisbursementRs);

			// set Asset status after successful disbursement
			for (PoAssetDisbursementDetails assetDisbursementDetails : poAssetDisbursementDtls) {
				if (assetDisbursementDetails.getPurchaseOrderID().equals(purchaseOrderID)) {

					// set asset status as disbursed
					IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory()
							.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetDisbursementDetails.getAssetID(),
									true);
					BigDecimal totalDisbAmt = BigDecimal.ZERO;
					for (PoAssetDisbursementDetails poDetails : poAssetDisbursementDtls) {
					    if(poDetails.getAssetID().equals(assetDisbursementDetails.getAssetID())) {
					        totalDisbAmt = totalDisbAmt.add(poDetails.getCurrentDisbursedAmount().getCurrencyAmount());
					    }
					}
					BigDecimal originalFinalCost = getAssetOrginalCost(assetTPDetails,assetDisbursementDetails.getAssetID());
					if (progressReportID.equals("AdvancePayment")||originalFinalCost.compareTo(totalDisbAmt) > CommonConstants.INTEGER_ZERO) {
						assetDetails.setF_STATUS("PARTIALLYDISBURSED");
					} else if(originalFinalCost.compareTo(totalDisbAmt)== CommonConstants.INTEGER_ZERO){
					    assetDetails.setF_STATUS(CeConstants.ASSET_STATUS_DISBURSED);
					}

					// get third party payment details table data based on asset id
					List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartyPaymentDtls = getThirdPartyPaymentDtls(
							assetDisbursementDetails.getAssetID());

					for (IBOIB_IDI_ThirdPartyPaymentDetails eachThirdPtyDtl : thirdPartyPaymentDtls) {
						// get third party id pk
						String eachthirdPtyIdPK = eachThirdPtyDtl.getBoID();

						// query on third party payment schedule table and update it as fully paid
						String whereClause = " WHERE "
								+ IBOIB_IDI_ThirdPartyPaymentScheduleDetails.THIRDPTYPAYMMENTDTLSID + "=?";
						ArrayList<String> params1 = new ArrayList<String>();
						params1.clear();
						params1.add(eachthirdPtyIdPK);
						List<IBOIB_IDI_ThirdPartyPaymentScheduleDetails> tPPayScheDtls = (List<IBOIB_IDI_ThirdPartyPaymentScheduleDetails>) factory
								.findByQuery(IBOIB_IDI_ThirdPartyPaymentScheduleDetails.BONAME, whereClause, params1,
										null, false);
						for (IBOIB_IDI_ThirdPartyPaymentScheduleDetails eachTpScheduleDtl : tPPayScheDtls) {
							if (originalFinalCost
									.compareTo(assetDisbursementDetails.getCurrentDisbursedAmount()
											.getCurrencyAmount()) == CommonConstants.INTEGER_ZERO) {
								eachTpScheduleDtl.setF_PAYMENTSTATUS("FULLYPAID");
							} else {
								eachTpScheduleDtl.setF_PAYMENTSTATUS("PARTPAID");
							}
						}
					}

				}
			}

			// call post manual collection API
			List<CustomerLiabilities> liabilities = new ArrayList();
			for (CustomerLiabilities customerLiabilities : customerLiability) {
				if ((purchaseOrderID.equals(customerLiabilities.getPurchaseOrderID()))
						&& (customerLiabilities.getLiabilityToBePaid().getCurrencyAmount()
								.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO)) {
					liabilities.add(customerLiabilities);
				}

			}
			postManualCollection(liabilities, env);
		}

	}

	private BigDecimal getAssetOrginalCost(AssetThirdPartyDetails[] assetTPDetails, String assetID) {
		for (AssetThirdPartyDetails assetThirdPartyDetails : assetTPDetails) {
			if(assetThirdPartyDetails.getAssetSerial().equals(assetID))
				return assetThirdPartyDetails.getFinalCost().getCurrencyAmount();
		}
		return BigDecimal.ZERO;
	}

	private void postManualCollection(List<CustomerLiabilities> liabilities,
			BankFusionEnvironment env) {
		for (CustomerLiabilities liability : liabilities) {
			
				IBOIB_DLI_DealDetails dealDtls = IBCommonUtils
						.getDealDetails(liability.getDealId());
				ReadLoanDetailsRs readLoanDetails = IBCommonUtils
						.getLoanDetails(liability.getDealId());
				DealIDInput dealIdInput = new DealIDInput();
				dealIdInput.setDealID(liability.getDealId());
				dealIdInput.setDealBranch(dealDtls.getF_BranchSortCode());
				dealIdInput.setSubProductID(dealDtls.getF_ProductContextCode());

				AccountInput collectionAccountInput = new AccountInput();

				collectionAccountInput.setAccountID(getAccountIdUDF());
				collectionAccountInput.setAccountFormatType(IBCommonUtils.getAccountFormatType(getAccountIdUDF()));
				AccountInput dealAccountInput = new AccountInput();
				dealAccountInput.setAccountID(dealDtls.getF_DealAccountId());
				dealAccountInput.setAccountFormatType(CeConstants.ACC_FORMAT_TYPE_STA);

				RqHeader rqHeader = new RqHeader();
				rqHeader.setMode(CeConstants.CONST_UPDATE);
				rqHeader.setChecksum(CommonConstants.EMPTY_STRING);

				HashMap<String, Object> inputParams = new HashMap<>();
				PostManualCollectionDetailsRq postManualCollectionDetailsRq = new PostManualCollectionDetailsRq();
				postManualCollectionDetailsRq.setDealInput(dealIdInput);
				postManualCollectionDetailsRq.setFundingAccountID(collectionAccountInput);
				postManualCollectionDetailsRq.setLoanAccountNo(dealAccountInput);
				postManualCollectionDetailsRq.setRqHeader(rqHeader);
				postManualCollectionDetailsRq.setSettlementCurrency(dealDtls.getF_IsoCurrencyCode());
				postManualCollectionDetailsRq.setTransactionID(GUIDGen.getNewGUID());
				postManualCollectionDetailsRq.setValueDate(IBCommonUtils.getBFBusinessDate());
				ExtensionDetails extentionDetails= new ExtensionDetails();
				extentionDetails.setUserExtension(getF_IN_islamicBankingObject().getDealID());
				postManualCollectionDetailsRq.setExtentionDetails(extentionDetails);
				BigDecimal totalRepaymentAmount = liability.getLiabilityToBePaid().getCurrencyAmount();
                PaymentScheduleList paymentScheduleList = new PaymentScheduleList();
			if (readLoanDetails != null && readLoanDetails.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanDetails.getDealDetails().getPaymentSchedule()) {
					if ((CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),row.getRepaymentDate()))
							&& totalRepaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
						PaymentSchedule paymentSchedule = new PaymentSchedule();
						paymentSchedule.setFeeAmt(BigDecimal.ZERO);
						paymentSchedule.setIsoCurrencyCode(dealDetails.getF_IsoCurrencyCode());
						paymentSchedule.setOutstandingPrincipalAmt(BigDecimal.ZERO.setScale(2));
						// if the business date repayment is already partially paid, then remaining
						// amount should be collected as part of this txn
						paymentSchedule.setPrincipleAmt(row.getPrincipalAmtUnpaid().setScale(2));
						paymentSchedule.setProfitAmt(row.getProfitAmtUnpaid().setScale(2));
						paymentSchedule.setProfitRate(dealDtls.getF_ProfitRate());
						if (totalRepaymentAmount.compareTo(row.getRepaymentAmtUnPaid().setScale(2)) >= 0) {
							paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
							totalRepaymentAmount = totalRepaymentAmount
									.subtract(row.getRepaymentAmtUnPaid().setScale(2));
						} else {
							paymentSchedule.setRepaymentAmt(totalRepaymentAmount.setScale(2));
							totalRepaymentAmount = BigDecimal.ZERO;
						}
						paymentSchedule.setRepaymentDate(row.getRepaymentDate());
						paymentSchedule.setRepaymentNo(row.getRepaymentNo());
						paymentSchedule.setRepaymentType(row.getRepaymentType());
						paymentScheduleList.addPaymentSchedule(paymentSchedule);

					}
				}
			}


				if (liability.getLiabilityToBePaid().getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) {
					postManualCollectionDetailsRq.setPaymentSchedule(paymentScheduleList);
					inputParams.put("postManualCollectionDetailsRq", postManualCollectionDetailsRq);

					@SuppressWarnings("unchecked")
					HashMap<String, Object> outputParam = MFExecuter
							.executeMF(CeConstants.POST_MANUAL_COLLECTION_MF_NAME, env, inputParams);
					PostManualCollectionDetailsRs postManualCollectionDetailsRs = (PostManualCollectionDetailsRs) outputParam
							.get("postManualCollectionDetailsRs");
				}

			}
		}
	

	private String getAccountIdUDF() {

		// get the account id from new udf field.
		String account = CeUtils.getCollectionAccountValue(islamicBankingObject.getDealID());

		return account;
	}

	private DownPaymentAndUtilizationDetail[] prepareDownPaymentDetails(DownPaymentDetails[] downPayDetails,
			BankFusionEnvironment env) {

		ArrayList<DownPaymentAndUtilizationDetail> downPaymentDetails = new ArrayList<DownPaymentAndUtilizationDetail>();
		for (DownPaymentDetails downPaymentDtl : downPayDetails) {
			DownPaymentAndUtilizationDetail DownPaymentAndUtilDtl = new DownPaymentAndUtilizationDetail();
			DownPaymentAndUtilDtl.setAmount(IBCommonUtils.scaleAmount(currencyCode,
					downPaymentDtl.getDownPaymentAmount().getCurrencyAmount().abs()));
			DownPaymentAndUtilDtl.setDate(downPaymentDtl.getDownPaymentDate());
			DownPaymentAndUtilDtl.setType(
					(downPaymentDtl.getDownPaymentAmount().getCurrencyAmount().compareTo(BigDecimal.ZERO) > 0) ? "D"
							: "U");
			downPaymentDetails.add(DownPaymentAndUtilDtl);
		}

		return downPaymentDetails.toArray(
				(DownPaymentAndUtilizationDetail[]) new DownPaymentAndUtilizationDetail[downPaymentDetails.size()]);

	}

	private DisbursementScheduleDetail[] prepareDisbursementSchedulDetail(
			MaintainDisbursementDetails maintainDisbursementDetails, BankFusionEnvironment env, BigDecimal fullPaymentOrderAmount) {
		BigDecimal disburseAmount = BigDecimal.ZERO;
		String actionMode = "";
		ArrayList<DisbursementScheduleDetail> disScheduleDetails = new ArrayList<DisbursementScheduleDetail>();
		for (DisbursementInfo eachDisburse : maintainDisbursementDetails.getDisbursementInfo()) {
			disburseAmount = eachDisburse.getDisbursementAmount().getCurrencyAmount();
			actionMode = IBConstants.DISBURSEMENT_ACTION_REVERSE;
			DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
			disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails, eachDisburse, disburseAmount,
					actionMode, env);
			disScheduleDetails.add(disbursementScheduleDetail);
		}

		actionMode = IBConstants.DISBURSEMENT_ACTION_EXECUTE;
		DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
		DisbursementInfo eachDisburse = prepareOneCompleteDisburse(fullPaymentOrderAmount);

		disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails, eachDisburse, fullPaymentOrderAmount,
				actionMode, env);
		disScheduleDetails.add(disbursementScheduleDetail);

		/*
		 * for (DisbursementInfo eachDisburse :
		 * maintainDisbursementDetails.getDisbursementInfo()) { boolean
		 * isDisburseExecuted=false; disburseAmount =
		 * eachDisburse.getDisbursementAmount().getCurrencyAmount(); for (AssetBasicDtls
		 * assetBasicDtls :
		 * readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) { String
		 * assetId = assetBasicDtls.getAssetId(); String isAssetDisbursed =
		 * CeUtils.getAssetIsDisbursed(readAssetData, assetId); if
		 * (isAssetDisbursed.equals("YES") &&
		 * !assetBasicDtls.getAssetStatus().equals("DISBURSED")) {
		 * 
		 * List allThirdPtyIds= new ArrayList();
		 * List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartyPaymentDtls =
		 * getThirdPartyPaymentDtls(assetId);
		 * 
		 * for(IBOIB_IDI_ThirdPartyPaymentDetails eachThirdPtyDtl:thirdPartyPaymentDtls)
		 * { allThirdPtyIds.add(eachThirdPtyDtl.getF_THIRDPARTYID()); } if
		 * (allThirdPtyIds.contains(eachDisburse.getThirdPartyId())) { actionMode =
		 * IBConstants.DISBURSEMENT_ACTION_EXECUTE; DisbursementScheduleDetail
		 * disbursementScheduleDetail = new DisbursementScheduleDetail();
		 * disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails,
		 * eachDisburse, disburseAmount, actionMode, env);
		 * disScheduleDetails.add(disbursementScheduleDetail); isDisburseExecuted=true;
		 * break; } }
		 * 
		 * }
		 * 
		 * if(!isDisburseExecuted) { actionMode =
		 * IBConstants.DISBURSEMENT_ACTION_REVERSE; DisbursementScheduleDetail
		 * disbursementScheduleDetail = new DisbursementScheduleDetail();
		 * disbursementScheduleDetail = disburseAPI(maintainDisbursementDetails,
		 * eachDisburse, disburseAmount, actionMode, env);
		 * disScheduleDetails.add(disbursementScheduleDetail); }
		 * 
		 * 
		 * }
		 */

		return disScheduleDetails
				.toArray((DisbursementScheduleDetail[]) new DisbursementScheduleDetail[disScheduleDetails.size()]);
	}

	private DisbursementInfo prepareOneCompleteDisburse(BigDecimal fullPaymentOrderAmount) {
		DisbursementInfo disbursementInfo = new DisbursementInfo();
		BFCurrencyAmount fullPaymentOrderAmountCurr = new BFCurrencyAmount();
		fullPaymentOrderAmountCurr.setCurrencyAmount(fullPaymentOrderAmount);
		fullPaymentOrderAmountCurr.setCurrencyCode(currencyCode);
		disbursementInfo.setDisbursementAmount(fullPaymentOrderAmountCurr);
		disbursementInfo.setDisbursementDate(IBCommonUtils.getBFBusinessDate());
		disbursementInfo.setDisbursementNo(1);
		disbursementInfo.setDisbursementStatus(IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT);

		return disbursementInfo;
	}

	private List<IBOIB_IDI_ThirdPartyPaymentDetails> getThirdPartyPaymentDtls(String assetId) {
		String whereQuery = " where " + IBOIB_IDI_ThirdPartyPaymentDetails.ASSETDETAILID + "=?";
		ArrayList<String> param = new ArrayList<String>();
		param.add(assetId);
		List<String> paymentDtlsIds = new ArrayList<String>();
		List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartyPaymentDetails = factory
				.findByQuery(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, whereQuery, param, null, true);
		if (null != thirdPartyPaymentDetails) {
			return thirdPartyPaymentDetails;
		}
		return thirdPartyPaymentDetails;
	}

	private DisbursementScheduleDetail disburseAPI(MaintainDisbursementDetails maintainDisbursementDetails,
			DisbursementInfo eachDisburse, BigDecimal disburseAmount, String actionMode, BankFusionEnvironment env) {
		boolean firstReadyDisbursementCheckFlag = false;
		if(BigDecimal.ZERO.compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount())!=0)
			firstReadyDisbursementCheckFlag = true;
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(maintainDisbursementDetails.getDealNo());
		DisbursementScheduleDetail disbursementScheduleDetail = new DisbursementScheduleDetail();
		disbursementScheduleDetail.setActionMode(actionMode);
		disbursementScheduleDetail.setDisbursementAmount(
				IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(), disburseAmount));
		disbursementScheduleDetail.setDisbursementCurrency(eachDisburse.getDisbursementAmount().getCurrencyCode());
		if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_EXECUTE)) {
			disbursementScheduleDetail.setDisbursementDate(IBCommonUtils.getBFBusinessDate());
		} else {
			disbursementScheduleDetail.setDisbursementDate(eachDisburse.getDisbursementDate());
		}

		disbursementScheduleDetail.setDisbursementId(eachDisburse.getDisbursementId());
		disbursementScheduleDetail.setDisbursementmentNo(eachDisburse.getDisbursementNo());
		disbursementScheduleDetail.setDisbursementNarrative(CommonConstants.EMPTY_STRING);
		if (!productDetails.isIsHostScheduleGenerator()
				&& IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT.equals(eachDisburse.getDisbursementStatus())
				&& !firstReadyDisbursementCheckFlag) {

			disbursementScheduleDetail.setProfitAmonut(dealDtls.getF_ProfitAmt());
			firstReadyDisbursementCheckFlag = true;
		} else {
			disbursementScheduleDetail.setProfitAmonut(BigDecimal.ZERO);
		}

		disbursementScheduleDetail.setDisbursementNarrative(CommonConstants.EMPTY_STRING);
		String status = getStatus(actionMode);
		disbursementScheduleDetail.setDisbursementStatus(status);
		disbursementScheduleDetail.setDisbursementType(IBConstants.DISBURSEMENT_TYPE_MANUAL);
		DisbursementAccountDetail spiDisbursementAccDtl = new DisbursementAccountDetail();
		String account = productDetails.getPrincipalReceivingAccount();
		spiDisbursementAccDtl.setDisbursementAccount(account);
		spiDisbursementAccDtl.setDisbursementAccountFormatType(IBCommonUtils.getAccountFormatType(account));
		spiDisbursementAccDtl.setDisbursementAmount(
				IBCommonUtils.scaleAmount(eachDisburse.getDisbursementAmount().getCurrencyCode(), disburseAmount));
		spiDisbursementAccDtl.setDisbursementMode("2286");
		disbursementScheduleDetail.addDisbursementAccountDetailList(spiDisbursementAccDtl);
		return disbursementScheduleDetail;
	}

	private String getStatus(String actionMode) {
		String status = "";

		if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_CREATE)) {
			status = IBConstants.DISBURSEMENT_STATUS_FUTURE_DISBURSEMNT;

		}

		else if (actionMode.equals(IBConstants.DISBURSEMENT_ACTION_EXECUTE)) {
			status = IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT;
		}

		return status;
	}

	private void generateSchedule(BankFusionEnvironment env) {
		String dealId = islamicBankingObject.getDealID();
		HashMap<String, Object> param = new HashMap<>();
		param.clear();
		param.put("dealNo", dealId);
		HashMap<String, Object> outputParams = MFExecuter.executeMF("IB_IDI_GetFinInfo_SRV", env, param);
		FinancialInfoDetail financialInfoDetail = (FinancialInfoDetail) outputParams.get("financialInfoDetail");
		ExtensionDetails extensionDtls = new ExtensionDetails();
		extensionDtls.setUserExtension(CeUtils.getUserExtension(dealId));
		extensionDtls.setHostExtension(CommonConstants.EMPTY_STRING);
		financialInfoDetail.setExtensionDtls(extensionDtls);
		GenerateScheduleWithMultipleContracts generateScheduleWithMultipleContracts = new GenerateScheduleWithMultipleContracts(
				env);
		islamicBankingObject.setChannel("1");
		generateScheduleWithMultipleContracts.setF_IN_islamicBankingObject(islamicBankingObject);
		generateScheduleWithMultipleContracts.setF_IN_paymentFrequency(getPaymentFrequency(financialInfoDetail));
		generateScheduleWithMultipleContracts.setF_IN_pricingMethod(getPricingMethod(financialInfoDetail));
		generateScheduleWithMultipleContracts.setF_IN_profitMethod(getProfitMethod(financialInfoDetail));
		String upfrontProfitPercentage = CeUtils.getUDFIDForUpfrontProfitPercentage();
		
		if (!(financialInfoDetail.getExtensionDtls().getUserExtension() == "")) {
            UserDefinedFields userDefinedFields = (UserDefinedFields) financialInfoDetail.getExtensionDtls().getUserExtension();
            for (UserDefinedFld list : userDefinedFields.getUserDefinedField()) {
                if (list.getFieldValue() != null && !list.getFieldValue().toString().isEmpty()
                    && list.getFieldName().equals(upfrontProfitPercentage))
                	generateScheduleWithMultipleContracts.setF_IN_upfrontProfitPercentage((BigDecimal) list.getFieldValue());
            }
        }
		generateScheduleWithMultipleContracts.setF_IN_generateScheduleForDisbursedAssets(false);
		generateScheduleWithMultipleContracts.setPoAssetDisbursementDtls(poAssetDisbursementDtls);
		generateScheduleWithMultipleContracts.setF_IN_isIncludeSubsidy(true);
		generateScheduleWithMultipleContracts.process(env);
	}

	private void updateDisbursmentInfo(DisbursementScheduleInputDetails disbursementScheduleInputDetails,
			MaintainDisbursementDetailsRs maintainDisbursementRs) {

		IBOIB_IDI_DealFinDisbmntTxnInfo finTransactionInfo;
		List list = getDealFinDisbursementTxnInfo();

		if (list.size() == 0) {
			finTransactionInfo = (IBOIB_IDI_DealFinDisbmntTxnInfo) factory
					.getStatelessNewInstance(IBOIB_IDI_DealFinDisbmntTxnInfo.BONAME);
			finTransactionInfo.setBoID(GUIDGen.getNewGUID());
			finTransactionInfo.setF_DEALNO(getF_IN_islamicBankingObject().getDealID());
			finTransactionInfo.setF_STEPID(getF_IN_islamicBankingObject().getStepID());
			finTransactionInfo.setF_TRANSACTIONID(getF_IN_islamicBankingObject().getTransactionID());
			finTransactionInfo.setF_TRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
			finTransactionInfo.setF_DISBURSEMENTSTATUS(IBConstants.DISBURSEMENT_STATUS_DISBURSED);
			finTransactionInfo.setF_RECCREATEDBY(IBCommonUtils.getUserId());
			finTransactionInfo.setF_RECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
			finTransactionInfo.setF_RECLASTMODIFIEDBY(IBCommonUtils.getUserId());
			finTransactionInfo.setF_RECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
			finTransactionInfo.setF_RECSYSDATE(IBCommonUtils.getBFSystemDateTime());
			factory.create(IBOIB_IDI_DealFinDisbmntTxnInfo.BONAME, finTransactionInfo);
		} else {
			finTransactionInfo = (IBOIB_IDI_DealFinDisbmntTxnInfo) list.get(0);
		}

		String finTransactionInfoId = finTransactionInfo.getBoID();

		Set<String> disbursementIds = new HashSet<String>();

		HashMap<Integer, String> executeInfo = new HashMap<Integer, String>();
		for (DisbursementScheduleDetail eachDisburseDtl : disbursementScheduleInputDetails
				.getDisbursementScheduleDetails()) {
			if (IBConstants.DISBURSEMENT_STATUS_READY_FOR_DISBURSEMENT
					.equals(eachDisburseDtl.getDisbursementStatus())) {
				executeInfo.put(eachDisburseDtl.getDisbursementmentNo(), null);
			}
		}
		// creating the disbursement details
		for (DisbursementScheduleOutputDetails outDisburseDtl : maintainDisbursementRs
				.getDisbursementScheduleOutputDetails()) {
			if (executeInfo.containsKey(outDisburseDtl.getDisbursementNo())
					&& !disbursementIds.contains(outDisburseDtl.getDisbursementId())) {
				IBOIB_IDI_DealFinancialDisbursementDTL finDisbursementDtl = (IBOIB_IDI_DealFinancialDisbursementDTL) factory
						.getStatelessNewInstance(IBOIB_IDI_DealFinancialDisbursementDTL.BONAME);
				finDisbursementDtl.setF_DEALFINDISBMNTTXNINFOID(finTransactionInfoId);
				finDisbursementDtl.setF_HOSTDISBURSEMENTID(outDisburseDtl.getDisbursementId());
				finDisbursementDtl.setF_PAYRECDETAILID((String) executeInfo.get(outDisburseDtl.getDisbursementNo()));
				factory.create(IBOIB_IDI_DealFinancialDisbursementDTL.BONAME, finDisbursementDtl);
				disbursementIds.add(outDisburseDtl.getDisbursementId());
			}
		}

	}

	private List<IBOIB_IDI_DealFinDisbmntTxnInfo> getDealFinDisbursementTxnInfo() {
		String whereClause = "WHERE " + IBOIB_IDI_DealFinDisbmntTxnInfo.STEPID + " = ? AND "
				+ IBOIB_IDI_DealFinDisbmntTxnInfo.TRANSACTIONID + " = ? " + "AND "
				+ IBOIB_IDI_DealFinDisbmntTxnInfo.DEALNO + " = ? AND "
				+ IBOIB_IDI_DealFinDisbmntTxnInfo.DISBURSEMENTSTATUS + "=?";
		ArrayList<String> params = new ArrayList<String>();
		params.add(getF_IN_islamicBankingObject().getStepID());
		params.add(getF_IN_islamicBankingObject().getTransactionID());
		params.add(getF_IN_islamicBankingObject().getDealID());
		params.add(IBConstants.DISBURSEMENT_STATUS_DISBURSED);
		IBOIB_IDI_DealFinDisbmntTxnInfo finTransactionInfo = null;

		List<IBOIB_IDI_DealFinDisbmntTxnInfo> list = factory.findByQuery(IBOIB_IDI_DealFinDisbmntTxnInfo.BONAME, whereClause, params, null, true);
		return list;
	}

	private BigDecimal getProfitRate(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getProfitRate(financialInfoDetail);
	}

	private String getProfitMethod(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getProfitMethod(financialInfoDetail);
	}

	private String getProfitDistributionMethod(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getProfitDistributionMethod(financialInfoDetail);
	}

	private String getPricingMethod(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getPricingMethod(financialInfoDetail);
	}

	private BigDecimal getScheduleProfit(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getScheduleProfit(financialInfoDetail);
	}

	private String getPaymentFrequency(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getPaymentFrequency(financialInfoDetail);
	}

	private Integer getGracePeriodInYears(FinancialInfoDetail financialInfoDetail) {
		return CeUtils.getGraceInPeriod(financialInfoDetail);
	}
	
	 private BigDecimal executeFeeRule(String taxTobePaidRuleId) {
       BigDecimal feeAmount = BigDecimal.ZERO;
       try {
           if (IBCommonUtils.isValidString(taxTobePaidRuleId)
               && IBCommonUtils.isValidRuleId(taxTobePaidRuleId, CommonConstants.EMPTY_STRING)) {

               RuleInputRq ruleInputRq = new RuleInputRq();
               RuleInputData ruleData = new RuleInputData();
               SystemParam systemParam = new SystemParam();
               systemParam.setParamName(IBConstants.DEALID_SYSTEMOBJECT_CONSTANTS);
               systemParam.setParamValue(islamicBankingObject.getDealID());
               ruleData.addInputParam(systemParam);
               ruleData.setRuleId(taxTobePaidRuleId);
               ruleData.addInputData(getDealSysObjectDetails());
               ruleData.setXmlContext("Default");
               ruleInputRq.setRuleInputList(ruleData);

               RuleExecRsData response = IBCommonUtils.executeRule(ruleInputRq);

               if (response.getRuleType().equals(IBConstants.RULE_TYPE_FORMULA_CONSTANTS) && response.getRuleData() != null) {
                   List<String> responseList = (List<String>) response.getRuleData();
                   if (responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
                       feeAmount = new BigDecimal(responseList.get(CommonConstants.INTEGER_ZERO));
                   }
               }
           }
       } catch (Exception exception) {
           LOGGER.info("Rule Exection failed while deriving default Value, Rule ID : " + taxTobePaidRuleId);
       }
       return feeAmount;
   }
	 
  private SystemObjectOutputDetail getDealSysObjectDetails() {

      SystemObjectOutputDetail sysObjectDetail = new SystemObjectOutputDetail();
      sysObjectDetail.setSystemObjectName(IBOIB_DLI_DealDetails.BONAME);

      List<Object> feeDetailsObjList = new ArrayList<>();
      feeDetailsObjList.add(IBCommonUtils.getDealDetails(islamicBankingObject.getDealID()));
      sysObjectDetail.setSystemObjectList(feeDetailsObjList);

      return sysObjectDetail;
  }
}
