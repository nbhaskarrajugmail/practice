package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetRegistryAsstByRegId;
import com.ce.ib.cfg.bo.RegistryAsset;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.RegistryAssetListCfg;
import bf.com.misys.ib.types.RegistryList;

public class GetRegistryAsstByRegId extends AbstractCE_IB_GetRegistryAsstByRegId {
	private static final long serialVersionUID = -5036878092879120299L;

	public GetRegistryAsstByRegId(BankFusionEnvironment env) {
		super(env);

	}

	public GetRegistryAsstByRegId() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		RegistryAsset regAsset = new RegistryAsset();
		RegistryList registryAssetList = getF_IN_registryList();

		String[] str = new String[1];
		str[0] = getF_IN_registryId();
		if(str.length>0) {
		RegistryAssetListCfg[] regAsstRes = regAsset.getRegistryAsstByRegId(str);
		registryAssetList.setRegistryAssetListDtls(regAsstRes);
		}
		setF_OUT_registryList(registryAssetList);
	}
}
