package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressPricingDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressing;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SetDisbursementAmount;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressPricingDtl;
import bf.com.misys.ib.types.AssetProgressPricingList;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetails;

public class SetDisbursementAmountFatom extends AbstractCE_IB_SetDisbursementAmount{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(SetDisbursementAmountFatom.class.getName());
	

	@SuppressWarnings("deprecation")
    public SetDisbursementAmountFatom(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	AssetProgressDetails assetDetail = getF_IN_assetProgressDetail();
    	AssetProgressReportDetails reportDetails = getF_IN_assetProgressReportDetails();
    	for(AssetProgressDetails asset : reportDetails.getAssetProgressDetailsList()) {
    		if(asset.getAssetID().equals(assetDetail.getAssetID()) && asset.getReportID().equals(assetDetail.getReportID())) {
    			asset.setPrevouslyDisbursedAmount(assetDetail.getNetFinalCost());
    		}
    	}
    }

}
