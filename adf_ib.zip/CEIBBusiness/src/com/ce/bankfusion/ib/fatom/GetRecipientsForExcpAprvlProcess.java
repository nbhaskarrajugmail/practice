package com.ce.bankfusion.ib.fatom;

import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetRecipientsForExcpAprvlProcess;
import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.ilo.types.RecipientResponsePayload;
import bf.com.misys.ib.ilo.types.UserDetails;
import bf.com.misys.ib.ilo.types.UserList;
import bf.com.misys.ib.types.ContextIDs;

public class GetRecipientsForExcpAprvlProcess extends AbstractCE_IB_GetRecipientsForExcpAprvlProcess{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 695545455812807800L;
	private static Log LOGGER = LogFactory.getLog(GetRecipientsForExcpAprvlProcess.class);

	public GetRecipientsForExcpAprvlProcess()
	{
		super();
	}
	
	public GetRecipientsForExcpAprvlProcess(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		LOGGER.info("Entered the process : Get Recipients For ExcpAprvlProcess");
		RecipientResponsePayload output = new RecipientResponsePayload();
		UserList userList = new UserList();
		if(DealValidationUtil.readProcessConfigID().equals(getF_IN_islamicBankingObject().getProcessConfigID()))
		{
			ContextIDs contextIDs = getF_IN_islamicBankingObject().getConetextIDs();
			String validationConfID = null;
			String originatingUser = null; 
			if(null != contextIDs)
			{
				for(String contextID : contextIDs.getConetextID())
				{
					if(null != contextID && contextID.contains(ValidationExceptionConstants.CI_VALIDATION_CONF_ID))
					{
						validationConfID = contextID.replace(ValidationExceptionConstants.CI_VALIDATION_CONF_ID, CommonConstants.EMPTY_STRING);
					}
					else if(null != contextID && contextID.contains(ValidationExceptionConstants.CI_ORIG_USER))
					{
						originatingUser = contextID.replace(ValidationExceptionConstants.CI_ORIG_USER, CommonConstants.EMPTY_STRING);
					}
				}
				if(null != validationConfID && null != originatingUser)
				{
					LOGGER.info("Inside Get Recipients For ExcpAprvlProcess : Validation Conf ID : "+validationConfID);
					IBOCE_IB_ValidationConfiguration conf = ValidationsUtil.getValidationConf(validationConfID);
					String approverUserOrGroup = conf.getF_IBAPPROVALUSERID();
					if(!conf.isF_IBGROUP())
					{
						UserDetails userDetails = new UserDetails();
						userDetails.setGroupId(CommonConstants.EMPTY_STRING);
						userDetails.setUserName(approverUserOrGroup);
						userDetails.setSelect(false);
						userList.addUserDetailsList(userDetails );
					}
					else
					{
						Set<String> users = DealValidationUtil.prepareUserList(approverUserOrGroup, conf.isF_IBFILTERBYBRANCH(),
								getF_IN_islamicBankingObject().getDealID());
						users.remove(originatingUser);
						for(String user : users)
						{
							UserDetails userDetails = new UserDetails();
							userDetails.setGroupId(approverUserOrGroup);
							userDetails.setUserName(user);
							userDetails.setSelect(false);
							userList.addUserDetailsList(userDetails);
						}
					}
					LOGGER.info("Inside Get Recipients For ExcpAprvlProcess : userListCount : "+userList.getUserDetailsListCount()+ 
							" for validationConfId : " + validationConfID );
				}
			}
		}
		output.setOwnersList(userList.getUserDetailsList());
		setF_OUT_recipientResponsePayload(output);
	}
}
