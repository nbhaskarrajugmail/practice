package com.ce.bankfusion.ib.fatom;

import java.sql.Date;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDefaultTechFarmDtls;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.technical.dtls.ib.types.TechincalAssetDtlsList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAssetDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalCropDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalFarmDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalWellDtlsList;

public class GetDefaultTechFarmDtls extends AbstractCE_IB_GetDefaultTechFarmDtls {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GetDefaultTechFarmDtls(BankFusionEnvironment env) {
		super(env);

	}

	public GetDefaultTechFarmDtls() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		TechnicalFarmDtl farmDtl = getF_IN_technicalFarmDtl();
		if (farmDtl.getReferenceNumber().equals(CommonConstants.EMPTY_STRING)) {
			String user = BankFusionThreadLocal.getUserId();
			Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
			setF_OUT_defaultUser(user);
			setF_OUT_panelVisibility(true);
			setF_OUT_defaultBusinessDate(businessDate);
			TechnicalAreaDtlList techArea = new TechnicalAreaDtlList();
			setF_OUT_technicalAreaDtlList(techArea);
			TechnicalAreaCoordinateDtlList techAreaCoordinate = new TechnicalAreaCoordinateDtlList();
			setF_OUT_technicalAreaAndCoordinateList(techAreaCoordinate);
			TechnicalCropDtlList techCrop = new TechnicalCropDtlList();
			setF_OUT_technicalCropDtlList(techCrop);
			TechincalAssetDtlsList techAsset = new TechincalAssetDtlsList();
			setF_OUT_technicalAssetDtlList(techAsset);
			TechnicalWellDtlsList techWekkDtls = new TechnicalWellDtlsList();
			setF_OUT_technicalWellDtlsList(techWekkDtls);
			/*TechnicalFarmDtlList defaulTechincalFarmDtl= new TechnicalFarmDtlList();
			defaulTechincalFarmDtl.addTechnicalFarmDtlList(farmDtl);
			setF_OUT_technicalFarmDtlList(defaulTechincalFarmDtl);
		*/

		} else {

			String referenceNum = farmDtl.getReferenceNumber();
			setF_OUT_technicalFarmDtlList(getF_IN_technicalFarmDtls());
			TechnicalAreaDtlList hiddenTechAreaDtls = getF_IN_hiddenTechAreaDtls();
			TechnicalAreaDtlList techAreaDtls = new TechnicalAreaDtlList();
			setTechAreaDtls(hiddenTechAreaDtls,techAreaDtls,referenceNum);
			
			TechnicalAreaCoordinateDtlList hiddenTechCoordinate = getF_IN_hiddenTechAreaCoordinateDtls();
			TechnicalAreaCoordinateDtlList techCoordinateDtls= new TechnicalAreaCoordinateDtlList();
			
			for(TechnicalAreaDtl eachArea:techAreaDtls.getTechnicalAreaDtlList())
			{
				String titleDeedId= eachArea.getTitleDeedId();
			setTechCoordinateDtlsList(hiddenTechCoordinate,techCoordinateDtls,referenceNum,titleDeedId);
			}
			
			TechincalAssetDtlsList hiddenAssetDtls = getF_IN_hiddenTechAssetDtls();
			TechincalAssetDtlsList techAssetDtls = new TechincalAssetDtlsList();
			setTechAssetDtls(hiddenAssetDtls,techAssetDtls,referenceNum);
			
			
			TechnicalCropDtlList hiddenTechCropDtls = getF_IN_hiddenTechCropDtls();
			TechnicalCropDtlList techCropDtls = new TechnicalCropDtlList();
			setTechCropDtls(hiddenTechCropDtls,techCropDtls,referenceNum);
			
			TechnicalWellDtlsList hiddenTechWekkDtls = getF_IN_hiddenTechnicalWellDtlsList();
			TechnicalWellDtlsList techWekkDtls = new TechnicalWellDtlsList();
			setTechWellDtls(hiddenTechWekkDtls, techWekkDtls, referenceNum);
			
			setF_OUT_technicalAreaDtlList(techAreaDtls);
			setF_OUT_technicalAreaAndCoordinateList(techCoordinateDtls);
			setF_OUT_technicalAssetDtlList(techAssetDtls);
			setF_OUT_technicalCropDtlList(techCropDtls);
			setF_OUT_technicalWellDtlsList(techWekkDtls);
			setF_OUT_panelVisibility(true);
			setF_OUT_defaultBusinessDate(farmDtl.getDate());
			setF_OUT_defaultUser(farmDtl.getInspectorName());
			setF_OUT_techReportId(farmDtl.getReferenceNumber());
		}
		setF_OUT_false(false);//checkbox check false

	}

	private void setTechCoordinateDtlsList(TechnicalAreaCoordinateDtlList hiddenTechCoordinate,
			TechnicalAreaCoordinateDtlList techCoordinateDtls, String referenceNum, String titleDeedId) {
		for (TechnicalAreaCoordinateDtl eachCoordinate : hiddenTechCoordinate.getTechnicalAreaCoordinateDtlList()) {
			if (eachCoordinate.getTitleDeedId().equals(titleDeedId) && referenceNum.equals(eachCoordinate.getReferenceNumber())) {
				TechnicalAreaCoordinateDtl coordinateDtl = new TechnicalAreaCoordinateDtl();
				coordinateDtl = eachCoordinate;
				coordinateDtl.setSelect(true);
				techCoordinateDtls.addTechnicalAreaCoordinateDtlList(coordinateDtl);
			}
		}
		
	}

	private void setTechCropDtls(TechnicalCropDtlList hiddenTechCropDtls, TechnicalCropDtlList techCropDtls,
			String referenceNum) {
		for (TechnicalCropDtl eachCrop : hiddenTechCropDtls.getTechnicalCropDtlList()) {
			if (eachCrop.getReferenceNumber().equals(referenceNum)) {
				TechnicalCropDtl cropDtl = new TechnicalCropDtl();
				cropDtl = eachCrop;
				cropDtl.setSelect(true);
				techCropDtls.addTechnicalCropDtlList(cropDtl);
			}
		}
		
	}
	
	private void setTechWellDtls(TechnicalWellDtlsList hiddenTechWellDtls, TechnicalWellDtlsList techWellDtls,
			String referenceNum) {
		for (TechnicalWellDtl eachCrop : hiddenTechWellDtls.getTechnicalWellDtlList()) {
			if (eachCrop.getReferenceNumber().equals(referenceNum)) {
				TechnicalWellDtl wellDtls = new TechnicalWellDtl();
				wellDtls = eachCrop;
				wellDtls.setSelect(true);
				techWellDtls.addTechnicalWellDtlList(wellDtls);;
			}
		}
		
	}

	private void setTechAssetDtls(TechincalAssetDtlsList hiddenAssetDtls, TechincalAssetDtlsList techAssetDtls,
			String referenceNum) {
		for (TechnicalAssetDtl eachAsset : hiddenAssetDtls.getTechincalAssetDtlsList()) {
			if (eachAsset.getReferenceNumber().equals(referenceNum)) {
				TechnicalAssetDtl assetDtl = new TechnicalAssetDtl();
				assetDtl = eachAsset;
				assetDtl.setSelect(true);
				techAssetDtls.addTechincalAssetDtlsList(assetDtl);
			}
		}
	}

	private void setTechAreaDtls(TechnicalAreaDtlList hiddenTechAreaDtls, TechnicalAreaDtlList techAreaDtls,
			String referenceNum) {
		for (TechnicalAreaDtl eachArea : hiddenTechAreaDtls.getTechnicalAreaDtlList()) {
			if (eachArea.getReferenceNumber().equals(referenceNum)) {
				TechnicalAreaDtl areaDtl = new TechnicalAreaDtl();
				areaDtl = eachArea;
				areaDtl.setSelect(true);
				techAreaDtls.addTechnicalAreaDtlList(areaDtl);
			}
		}
	}

}
