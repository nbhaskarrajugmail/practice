/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: PopulateSchInfoOnRevisit.java,v.1.0,Jul 17, 2013 12:22:08 PM deenayak
 *
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.util.Utils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetThirdPartyDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_IDI_PopulateSchInfoDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.trapedza.bankfusion.core.BFCurrencyValue;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.schedule.types.DrawDownAndDownPaymentDetails;
import bf.com.misys.ib.schedule.types.ScheduleBasicInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfoList;
import bf.com.misys.ib.schedule.types.ScheduleGenInput;
import bf.com.misys.ib.schedule.types.WhatIfBasicFinInfo;

public class CEPopulateSchInfoDetails extends AbstractIB_IDI_PopulateSchInfoDetails {

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	private static final long serialVersionUID = 1L;

	public static final String QUERY_DEAL_DTLS = " WHERE " + IBOIB_DLI_DealDetails.DealNo + " = ? ";

	public static final String QUERY_DEAL_ADDITIONAL_DTLS = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + " = ? ";

	public static final String QUERY_THIRDPARTY_DTLS = "WHERE " + IBOIB_DLI_DealAssetThirdPartyDTL.DealNo + " = ? "
			+ "AND " + IBOIB_DLI_DealAssetThirdPartyDTL.AttachmentType + " =? " + "AND "
			+ IBOIB_DLI_DealAssetThirdPartyDTL.AmtInclusionType + " !=? ";

	public static final String QUERY_DEAL_SCH_PROFILE_DTLS = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ?";

	public CEPopulateSchInfoDetails(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		ScheduleDetailedInfoList scheduleDetailedInfoList = new ScheduleDetailedInfoList();
		WhatIfBasicFinInfo whatIfBasicFinInfo = new WhatIfBasicFinInfo();
		ScheduleBasicInfo schedulefBasicFinInfo = new ScheduleBasicInfo();
		DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails = new DrawDownAndDownPaymentDetails();
		drawDownAndDownPaymentDetails
				.setDownPaymentDetails(getF_IN_drawDownAndDownPaymentDetails().getDownPaymentDetails());
		drawDownAndDownPaymentDetails.setDrawdownDetails(getF_IN_drawDownAndDownPaymentDetails().getDrawdownDetails());
		String currencyCode = CommonConstants.EMPTY_STRING;

		ArrayList<Object> param = new ArrayList<>();
		param.add(getF_IN_dealNo());

		IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
				.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, getF_IN_dealNo(), true);
		List<IBOIB_DLI_DealAditionalDtls> dealAddtionalDetails = factory.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME,
				QUERY_DEAL_ADDITIONAL_DTLS, param, null, false);
		List<IBOIB_DLI_ScheduleProfile> scheduleProfile = factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME,
				QUERY_DEAL_SCH_PROFILE_DTLS, param, null, true);

		getF_OUT_instructionsList().removeAllInstructions();
		getF_OUT_customInstructionsList().removeAllCustomizedinstructions();

		Boolean isHostScheduleGenerator = IBCommonUtils.loadProductConfiguration(getF_IN_dealNo())
				.getIsHostScheduleGenerator();
		int jk = 0;
		if (null != dealDetails && null != dealAddtionalDetails) {

			currencyCode = dealDetails.getF_IsoCurrencyCode();
			whatIfBasicFinInfo.setAprRate(dealAddtionalDetails.get(0).getF_APR() != null
					? new BFCurrencyValue(currencyCode, dealAddtionalDetails.get(0).getF_APR(), null).getRoundedAmount()
					: CommonConstants.BIGDECIMAL_ZERO);
			whatIfBasicFinInfo.setChargesDealOverHeadCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_ChargeAmt()),
					currencyCode));
			whatIfBasicFinInfo.setDealAmt(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_DealAmt()), currencyCode));
			whatIfBasicFinInfo.setDealEffectiveDate(dealDetails.getF_DEALEFFECTIVEDT());
			whatIfBasicFinInfo.setDealPrincipleAmt(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_PrincipleAmt()), currencyCode));
			whatIfBasicFinInfo.setDealProfitAmt(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_ProfitAmt()), currencyCode));
			whatIfBasicFinInfo.setDealStartDate(dealDetails.getF_DealStartDate());
			whatIfBasicFinInfo.setGraceDays(dealDetails.getF_GraceDays());
			whatIfBasicFinInfo.setLastInstallmentDate((null != dealDetails.getF_LastRepaymentDate()
					&& dealDetails.getF_LastRepaymentDate().equals(Utils.getDATEValue("1970-01-01")))
							? dealDetails.getF_DealStartDate()
							: dealDetails.getF_LastRepaymentDate());
			whatIfBasicFinInfo.setProfitChargesDealOverHeadCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_PROFITCHARGEAMOUNT()),
					currencyCode));
			whatIfBasicFinInfo.setProfitCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_ProfitCost()),
					currencyCode));
			whatIfBasicFinInfo.setAssetCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_AssetCost()),
					currencyCode));
			whatIfBasicFinInfo.setCostInPrinciple(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_CostInPrinciple()),
					currencyCode));
			whatIfBasicFinInfo.setDownPaymentAmt(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_DownPaymentAmt()),
					currencyCode));
			whatIfBasicFinInfo.setDownPaymentDate(ThirdPartyPaymentScheduleUtil
					.clearDateDefaultValue(dealAddtionalDetails.get(0).getF_DownPaymentDate()));
			whatIfBasicFinInfo.setMiscellaneousExpenses(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_MiscellaneousCost()),
					currencyCode));
			whatIfBasicFinInfo.setPrincipleDiscount(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_DiscountAmt()),
					currencyCode));
			whatIfBasicFinInfo.setProfitAssetCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_PROFITASSETCOST()),
					currencyCode));
			whatIfBasicFinInfo.setCostInProfit(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_CostInProfit()),
					currencyCode));
			whatIfBasicFinInfo.setProfitDiscount(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_ProfitDiscountAmt()),
					currencyCode));
			whatIfBasicFinInfo.setRemainingPrinciple(CeUtils.getZeroAmount(currencyCode));
			whatIfBasicFinInfo.setRemainingProfit(CeUtils.getZeroAmount(currencyCode));
			whatIfBasicFinInfo.setScheduledPrinciple(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_PrincipleAmt()), currencyCode));
			whatIfBasicFinInfo.setScheduledProfit(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_ProfitAmt()), currencyCode));
			whatIfBasicFinInfo.setConstructionProfitAmt(CeUtils.getZeroAmount(currencyCode));

			ArrayList<Object> params = new ArrayList<>();
			params.add(getF_IN_dealNo());
			params.add(IBConstants.TPTATTACHMENTTYPE_DEAL);
			params.add(IBConstants.COSTONLY);

			List<IBOIB_DLI_DealAssetThirdPartyDTL> thirdPartyDtls = factory
					.findByQuery(IBOIB_DLI_DealAssetThirdPartyDTL.BONAME, QUERY_THIRDPARTY_DTLS, params, null, true);

			BigDecimal profitDealOverHeadCost = BigDecimal.ZERO;
			if (thirdPartyDtls != null && !thirdPartyDtls.isEmpty()) {
				for (int i = 0; i < thirdPartyDtls.size(); i++) {
					profitDealOverHeadCost = profitDealOverHeadCost.add(thirdPartyDtls.get(i).getF_Amount());
				}
				whatIfBasicFinInfo.setProfitdealOverHeadCost(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, profitDealOverHeadCost), currencyCode));
			} else {
				whatIfBasicFinInfo.setProfitdealOverHeadCost(IBCommonUtils
						.getBFCurrencyAmount(IBCommonUtils.scaleAmount(currencyCode, BigDecimal.ZERO), currencyCode));
			}

			whatIfBasicFinInfo.setDealOverHeadCost(IBCommonUtils.getBFCurrencyAmount(
					IBCommonUtils.scaleAmount(currencyCode, dealAddtionalDetails.get(0).getF_DealOverHeadCost()),
					currencyCode));

			schedulefBasicFinInfo = ScheduleUtils
					.transformWhatIfScheduleBasicInfoToScheduleBasicInfo(whatIfBasicFinInfo);
		}

		if (null != scheduleProfile && !scheduleProfile.isEmpty()) {
			for (int i = 0; i < scheduleProfile.size(); i++) {
				ScheduleDetailedInfo schDetailedInfo = new ScheduleDetailedInfo();

				IBOIB_DLI_ScheduleProfile schProfile = scheduleProfile.get(i);
				currencyCode = schProfile.getF_DealCurrencyCode();
				schDetailedInfo.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, schProfile.getF_ProfitPaymentAMT()), currencyCode));
				schDetailedInfo.setProfitMatrixId(schProfile.getF_ProfitMatrixID());
				schDetailedInfo.setProfitMethod(schProfile.getF_EvaluationMethod());
				schDetailedInfo.setProfitPayment(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, schProfile.getF_ProfitPaymentAMT()), currencyCode));
				schDetailedInfo.setProfitRate(schProfile.getF_ProfitRate());
				schDetailedInfo.setDefaultProfitRate(schProfile.getF_ProfitRate());
				schDetailedInfo.setRoundingOption(schProfile.getF_RoundingOption());
				schDetailedInfo.setScheduleDurationCode(schProfile.getF_DurationCode());
				schDetailedInfo.setScheduleDurationUnit(schProfile.getF_DurationUnit());
				schDetailedInfo.setScheduleID(schProfile.getBoID());
				schDetailedInfo.setScheduleType(schProfile.getF_ScheduleType());
				schDetailedInfo
						.setGraceProfitResidualAmt(IBCommonUtils.getBFCurrencyAmount(BigDecimal.ZERO, currencyCode));
				schDetailedInfo.setCalculatedProfit(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, schProfile.getF_ProfitPaymentAMT()), currencyCode));
				schDetailedInfo.setNoOfPayment(schProfile.getF_NoOfPayments());
				schDetailedInfo.setPaymentFrequencyCode(schProfile.getF_FreqCode());
				schDetailedInfo.setPaymentFrequencyUnit(schProfile.getF_FreqUnit());
				schDetailedInfo.setPaymentOption(schProfile.getF_PaymentOption());
				schDetailedInfo.setBaseFactor(schProfile.getF_BaseFactor());
				schDetailedInfo.setFactorRate(schProfile.getF_FactorRate());
				schDetailedInfo.setScheduleStartDate(schProfile.getF_scheduleStartDT());
				schDetailedInfo.setScheduleEndDate(schProfile.getF_scheduleEndDT());
				schDetailedInfo.setFirstPaymentDate(schProfile.getF_FirstPaymentDT());
				schDetailedInfo.setFirstPaymentDateWithNWDApplied(schProfile.getF_FirstPaymentDT());
				schDetailedInfo.setLastPaymentDate(schProfile.getF_LastPaymentDT());
				schDetailedInfo.setLastPaymentDateWithNWDApplied(schProfile.getF_LastPaymentDT());
				schDetailedInfo.setInstallementAmt(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, dealDetails.getF_RepaymentAmt()), currencyCode));
				schDetailedInfo.setProfitMethod(schProfile.getF_EvaluationMethod());
				schDetailedInfo.setScheduleOption(schProfile.getF_scheduleOption());
				schDetailedInfo.setGraceProfitCollection(schProfile.getF_ProfitCollectionTypeInGrace());
				schDetailedInfo.setPrinciplePayment(IBCommonUtils.getBFCurrencyAmount(
						IBCommonUtils.scaleAmount(currencyCode, schProfile.getF_PrinciplePaymentAMT()), currencyCode));
				schDetailedInfo.setPrinciplePaymentAll(true);
				schDetailedInfo.setProfitPaymentAll(true);
				schDetailedInfo.setSelect(true);
				scheduleDetailedInfoList.addScheduleDetailedInfoList(schDetailedInfo);
			}
			ScheduleDetailedInfo basicRepaymentProfile = getF_OUT_basicRepaymentProfile();
			ScheduleUtils.setBasicRepaymentProfile(scheduleProfile, basicRepaymentProfile);

			setF_OUT_basicRepaymentProfile(basicRepaymentProfile);
		}

		setF_OUT_whatIfBasicFinInfo(whatIfBasicFinInfo);

		ScheduleGenInput scheduleInput = new ScheduleGenInput();
		scheduleInput.setDrawDownAndDownPaymentDetails(drawDownAndDownPaymentDetails);
		scheduleInput.setScheduleBasicInfo(schedulefBasicFinInfo);
		scheduleInput.setScheduleDetailedInfoList(scheduleDetailedInfoList);
		if (scheduleDetailedInfoList != null && scheduleDetailedInfoList.getScheduleDetailedInfoListCount() > 0) {
			for (ScheduleDetailedInfo detailedInfo : scheduleDetailedInfoList.getScheduleDetailedInfoList()) {
				ScheduleUtils.calculateEquivalentRate(isHostScheduleGenerator, scheduleInput, detailedInfo);
			}
		}

		setF_OUT_scheduleDetailedInfoList(scheduleDetailedInfoList);
	}
}