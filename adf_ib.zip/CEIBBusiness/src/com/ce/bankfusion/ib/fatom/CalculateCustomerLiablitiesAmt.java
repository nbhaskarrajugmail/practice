package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CalculateCustomerLiablitiesAmt;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.IssuePayOrderDtls;

public class CalculateCustomerLiablitiesAmt extends AbstractCE_IB_CalculateCustomerLiablitiesAmt {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final int FEES_GREATER_THAN_OUTSTANDING = 44000221;
	public static final int TOTAL_OUTSTANDING_FEES_HAS_TO_PAID = 44000222;
	private static final transient Log LOG = LogFactory.getLog(CalculateCustomerLiablitiesAmt.class.getName());
	private static final String CHECK = "CHECK";
	private static final String FEESTOBEPAID = "FEESTOBEPAID";
	private static final int DISBURSEMENT_AMT_CANNOT_BE_NEGATIVE = 44000229;

	public CalculateCustomerLiablitiesAmt() {
		super();
	}

	@SuppressWarnings("deprecation")
	public CalculateCustomerLiablitiesAmt(BankFusionEnvironment env) {
		super(env);
	}

	@SuppressWarnings({ "deprecation" })
	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		/*IssuePayOrderDtls issuePayOrderDtls = getF_IN_issuePayOrderDtl();
		IssuePayOrderDtls issuePayOrderDtlsOutput = new IssuePayOrderDtls();
		String mode = getF_IN_mode();
		if (mode.equals(CHECK)) {
			BigDecimal outstandingCustLiab = BigDecimal.ZERO;
			BigDecimal custLiabToBeDeducted = BigDecimal.ZERO;
			for (CustomerLiabilities customerLiabilities : issuePayOrderDtls.getCustomerLiabilitiesDtls()) {

				if (customerLiabilities.getSelect() == true) {
					custLiabToBeDeducted = custLiabToBeDeducted.add(customerLiabilities.getOutstandingAmt());
				} else {
					outstandingCustLiab = outstandingCustLiab.add(customerLiabilities.getOutstandingAmt());
				}
			}

			issuePayOrderDtlsOutput.setOutstandingCustomerLiabilities(outstandingCustLiab);
			issuePayOrderDtlsOutput.setCustomerLiabilitiesToBeDeducted(custLiabToBeDeducted);
			BigDecimal disbursementAmtAfterLiab = issuePayOrderDtls.getPaymentOrderAmt().subtract(custLiabToBeDeducted);
			BigDecimal disbursementAmt = disbursementAmtAfterLiab.subtract(issuePayOrderDtls.getFeesToBePaid());
			if (getF_IN_issuePayOrderDtl().getFeesToBeDeducted().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_issuePayOrderDtl().getFeesToBePaid().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_issuePayOrderDtl().getOutstandingFees().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_issuePayOrderDtl().getOutstandingFeesInDisb().compareTo(BigDecimal.ZERO) == 0
					&& getF_IN_issuePayOrderDtl().getPaidFees().compareTo(BigDecimal.ZERO) == 0) {
				disbursementAmt = issuePayOrderDtls.getPaymentOrderAmt().subtract(custLiabToBeDeducted);
			}
			if (disbursementAmt.compareTo(BigDecimal.ZERO) < 0) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(DISBURSEMENT_AMT_CANNOT_BE_NEGATIVE,
						new Object[] {}, LOG, env);
			}

			issuePayOrderDtlsOutput.setDisbursementAmt(disbursementAmt);
			setF_OUT_issuePayOrderDtl(issuePayOrderDtlsOutput);
		} else if (mode.equals(FEESTOBEPAID)) {
			BigDecimal disbursementAmt = BigDecimal.ZERO;
			BigDecimal outstandingFeesInDisb = BigDecimal.ZERO;

			validateFeesToBePaidAmt(issuePayOrderDtls, env);

			disbursementAmt = issuePayOrderDtls.getPaymentOrderAmt().subtract(issuePayOrderDtls.getPaidFees().add(
					issuePayOrderDtls.getFeesToBePaid()).add(issuePayOrderDtls.getCustomerLiabilitiesToBeDeducted()));
			outstandingFeesInDisb = issuePayOrderDtls.getOutstandingFees()
					.subtract(issuePayOrderDtls.getFeesToBePaid());

			issuePayOrderDtlsOutput.setOutstandingFeesInDisb(outstandingFeesInDisb);
			issuePayOrderDtlsOutput.setDisbursementAmt(disbursementAmt);
			setF_OUT_issuePayOrderDtl(issuePayOrderDtlsOutput);

		}*/
	}

	/*public void validateFeesToBePaidAmt(IssuePayOrderDtls issuePayOrderDtls, BankFusionEnvironment env) {

		// fees to be paid should not be greater than the outstanding amount
		if (issuePayOrderDtls.getFeesToBePaid().compareTo(issuePayOrderDtls.getOutstandingFees()) > 0) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(FEES_GREATER_THAN_OUTSTANDING, new Object[] {},
					LOG, env);
		}

		// validate the customer is paying all the fees if this transaction will be the
		// last disbursement transaction
		ReadLoanDetailsRs readLoanRs = null;
		BigDecimal disbursementAmt = BigDecimal.ZERO;
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(issuePayOrderDtls.getDealId());
		BigDecimal principalAmt = dealDtls.getF_PrincipleAmt();
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(issuePayOrderDtls.getDealId());
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			
			disbursementAmt = readLoanRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount();
			BigDecimal remainingPrincipal = principalAmt.subtract(disbursementAmt);
			if ((remainingPrincipal.compareTo(issuePayOrderDtls.getPaymentOrderAmt()) == 0)
					&& issuePayOrderDtls.getOutstandingFees().compareTo(issuePayOrderDtls.getFeesToBePaid()) != 0) {
				BusinessEventSupport.getInstance().raiseBusinessErrorEvent(TOTAL_OUTSTANDING_FEES_HAS_TO_PAID,
						new Object[] {}, LOG, env);
			}

		}

	}*/
}
