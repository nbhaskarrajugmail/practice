/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchCollTag;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SurplusTransfer;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_GetSurplusAccountDetails;
import com.ce.ib.fatoms.batch.batchcollection.BatchCollectionProcess;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.config.ModuleConfiguration;
import com.misys.ub.fatoms.batch.BatchUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanApplication;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Party;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.fatoms.GetSurplusAmtOnAcc;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.postingengine.gateway.interfaces.IPostingMessage;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.SurplusTransfer;

/**
 * @author Aklesh
 *
 */
public class GetSurplusAccountDetails extends AbstractCE_ADF_GetSurplusAccountDetails {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String PARTY_LOANS_WHERE = "WHERE " + IBOLoanApplication.LEADAPPLICANTCUSTOMERID + "=? ";
	private static final String FIND_SURPLUSACCT_QUERY = "WHERE " + IBOUB_CNF_SurplusAccountDetails.UBACCOUNTID + " = ?";
	public GetSurplusAccountDetails(BankFusionEnvironment env) {
		super(env);

	}

	public GetSurplusAccountDetails() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		if (getF_IN_mode().equals("TOTAL")) {
			BigDecimal totalAmount = BigDecimal.ZERO;
			for (SurplusTransfer surplusTransfer : getF_IN_surplusTransferDetail().getTransferToBankList()) {
				if (surplusTransfer.getSelect())
					totalAmount = totalAmount.add(surplusTransfer.getSurplusBalance());
			}
			getF_OUT_surplusTransferDetail().getSurplusTransferHeader().setTotalTransferAmount(totalAmount);
		} else if (getF_IN_mode().equals("POST")) {
			IBCommonUtils.raiseUnparameterizedEvent(44000806);
			String transactionID = GUIDGen.getNewGUID();

			String debitTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
					"BatchInfo.debitTxnCode");
			String creditTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
					"BatchInfo.creditTxnCode");
			String creditAccountNumber = getF_IN_surplusTransferDetail().getSurplusTransferHeader().getBankAccount();
			ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
			IBOAttributeCollectionFeature creditAccountDetails = FinderMethods
					.getAccountBO(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getBankAccount());
			IPostingMessage debitPostingMessage = BatchCollectionProcess.getFinPostingMessage(creditAccountDetails,
					creditAccountNumber,
					getF_IN_surplusTransferDetail().getSurplusTransferHeader().getTotalTransferAmount(), debitTxnCode,
					"+", transactionID, "", creditAccountNumber, CommonConstants.EMPTY_STRING,getF_IN_surplusTransferDetail().getSurplusTransferHeader().getTransferDate());
			postingMessageList.add(debitPostingMessage);
			for (SurplusTransfer surplusTransfer : getF_IN_surplusTransferDetail().getTransferToBankList()) {
				if (surplusTransfer.getSelect()) {
					IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(surplusTransfer.getSurplusAccount());
					IPostingMessage creditPostingMessage = BatchCollectionProcess.getFinPostingMessage(debitAccountDetails, surplusTransfer.getSurplusAccount(),
							surplusTransfer.getSurplusBalance(), creditTxnCode, "-", transactionID, CommonConstants.EMPTY_STRING,
							surplusTransfer.getSurplusAccount(),CommonConstants.EMPTY_STRING,getF_IN_surplusTransferDetail().getSurplusTransferHeader().getTransferDate());

					postingMessageList.add(creditPostingMessage);
				}
			}
				try {
					BatchCollectionProcess.postTransaction(postingMessageList);
				} catch (Exception exception) {
					throw exception;
				}
			
			
			//TODO Create new table and update with txn ID and Dates
			IBOCE_ADF_SurplusTransfer surplusTransfer = (IBOCE_ADF_SurplusTransfer) factory.getStatelessNewInstance(IBOCE_ADF_SurplusTransfer.BONAME);
			surplusTransfer.setBoID(transactionID);
			surplusTransfer.setF_AMOUNT(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getTotalTransferAmount());
			surplusTransfer.setF_BENEFICIARYBANK(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getBeneficiaryBank());
			surplusTransfer.setF_BENEFICIARYIBAN(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getBeneficiaryIBAN());
			surplusTransfer.setF_BENEFICIARYNAME(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getBeneficiaryName());
			surplusTransfer.setF_DEBITBANK(getF_IN_surplusTransferDetail().getSurplusTransferHeader().getDebitBank());
			surplusTransfer.setF_STATUS(false);
			surplusTransfer.setF_TRANSACTIONBY(BankFusionThreadLocal.getUserId());
			surplusTransfer.setF_TRANSACTIONNDATE(SystemInformationManager.getInstance().getBFBusinessDate());
			factory.create(IBOCE_ADF_SurplusTransfer.BONAME, surplusTransfer);
			
		} else {
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_partyID());
			@SuppressWarnings("unchecked")
			List<IBOLoanApplication> loans = factory.findByQuery(IBOLoanApplication.BONAME, PARTY_LOANS_WHERE, params,
					null, true);
			getF_OUT_surplusTransferDetail().removeAllTransferToBankList();
			int srNo = 1;
			for (IBOLoanApplication iboLoanApplication : loans) {
				SurplusTransfer surplusTransfer = new SurplusTransfer();
				String surplusAccount = CommonConstants.EMPTY_STRING;
				ArrayList<String> param = new ArrayList<String>();
				param.add(iboLoanApplication.getF_LOANACCID());

				List<IBOUB_CNF_SurplusAccountDetails> surplusAccountDtls = factory.findByQuery(
						IBOUB_CNF_SurplusAccountDetails.BONAME, FIND_SURPLUSACCT_QUERY, param, null, true);
				if (surplusAccountDtls != null && !surplusAccountDtls.isEmpty())
					surplusAccount = surplusAccountDtls.get(0).getF_UBSURPLUSACCOUNT();

				IBOAttributeCollectionFeature account = (IBOAttributeCollectionFeature) factory
						.findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, surplusAccount, true);
				if (surplusAccount.isEmpty()
						|| account.getF_CLEAREDBALANCE().compareTo(BigDecimal.ZERO) <= CommonConstants.INTEGER_ZERO)
					continue;

				surplusTransfer.setSurplusBalance(account.getF_CLEAREDBALANCE());
				surplusTransfer.setSurplusAccount(surplusAccount);
				surplusTransfer.setLoanAccountID(iboLoanApplication.getF_LOANACCID());
				surplusTransfer.setSrno(srNo++);
				surplusTransfer.setSelect(false);
				getF_OUT_surplusTransferDetail().addTransferToBankList(surplusTransfer);
			}
			getF_OUT_surplusTransferDetail().getSurplusTransferHeader().setBeneficiaryName(((IBOPT_PFN_Party)factory.findByPrimaryKey(IBOPT_PFN_Party.BONAME, getF_IN_partyID(), true)).getF_NAME());
			getF_OUT_surplusTransferDetail().getSurplusTransferHeader()
					.setTransferDate(SystemInformationManager.getInstance().getBFBusinessDate());
		}
	}
}