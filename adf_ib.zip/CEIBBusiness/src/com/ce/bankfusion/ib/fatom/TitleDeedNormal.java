package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedNormal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.utils.GUIDGen;

public class TitleDeedNormal extends AbstractCE_IB_TitleDeedNormal {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("deprecation")
	public TitleDeedNormal(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ? ";
		TitleDeedDetailsType[] titleDeedMap = getF_IN_titleDeedDtlsList().getTitleDeedDetails();
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetails = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME,
				whereClause, params, null, false);
		if (!getF_IN_bbMode().equalsIgnoreCase("VIEW")) {
			if (titleDeedDetails != null && titleDeedDetails.size() > 0) {
				factory.bulkDelete(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params);
			}
			for (TitleDeedDetailsType r : titleDeedMap) {
				IBOCE_IB_DealTitleDeedDtls dealTitleDeedDtls = (IBOCE_IB_DealTitleDeedDtls) factory
						.getStatelessNewInstance(IBOCE_IB_DealTitleDeedDtls.BONAME);
				// set the datails
				dealTitleDeedDtls.setF_IBDEALNUMBER(getF_IN_islamicBankingObject().getDealID());
				dealTitleDeedDtls.setF_IBTITLEDEEDID(r.getTitleDeedIdpk());
				dealTitleDeedDtls.setF_IBTITLEDEEDVERSIONNUM(String.valueOf(r.getVersionNumber()));
				dealTitleDeedDtls.setF_IBSTATUS("REQUESTED");
				dealTitleDeedDtls.setBoID(GUIDGen.getNewGUID());
				factory.create(IBOCE_IB_DealTitleDeedDtls.BONAME, dealTitleDeedDtls);
			}
		}
	}
}
