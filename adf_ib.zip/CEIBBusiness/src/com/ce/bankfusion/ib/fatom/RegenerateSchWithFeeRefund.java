package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RegenerateSchWithFeeRefund;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_RegenerateSchWithFeeRefund;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleHistoryDetails;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class RegenerateSchWithFeeRefund extends AbstractCE_IB_RegenerateSchWithFeeRefund
        implements ICE_IB_RegenerateSchWithFeeRefund {

    private static final Log LOGGER = LogFactory.getLog(ReadRefundReschFeeDetails.class);
    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public RegenerateSchWithFeeRefund() {
        // TODO Auto-generated constructor stub
    }

    public RegenerateSchWithFeeRefund(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method Deal ID -->" + getF_IN_reschRefundFees().getDealId());
        BigDecimal osRescheduleFeeAmt = getF_IN_reschRefundFees().getRescheduleRequestDetails().getOutstandingFees()
                .getCurrencyAmount();
        BigDecimal refundRescheduleFeeAmt = BigDecimal.ZERO;
        BigDecimal totalFeeAmt = BigDecimal.ZERO;
        BigDecimal refundablePaidRescheduleFee = BigDecimal.ZERO;
        BigDecimal refundableFeeAmount = BigDecimal.ZERO;
        String scheduledDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
				CeConstants.REFUND_STATUS_SCHEDULED);
        String refundDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
    			CeConstants.REFUND_STATUS_REFUNDED);
		
        for (CeRescheduleHistoryDetails rescheduleHistoryDetails : getF_IN_reschRefundFees().getRescheduleHistoryDetails()) {
        	if ((rescheduleHistoryDetails.isSelect())
        			&& rescheduleHistoryDetails.getRescheduleProfitStatus().equals(refundDesc)) {
        		IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_RESCH_REQ_REFUNDED_CEIB);
        	}
            if (CeConstants.MODE_CANCEL.equals(getF_IN_mode()) && rescheduleHistoryDetails.isSelect()) {
                rescheduleHistoryDetails.setRescheduleProfitStatus(IBConstants.EMPTY_STRING);
            }
            if ((CeConstants.MODE_SCHEDULE.equals(getF_IN_mode()) && rescheduleHistoryDetails.isSelect())
                    || rescheduleHistoryDetails.getRescheduleProfitStatus().equals(scheduledDesc)) {
                refundRescheduleFeeAmt = refundRescheduleFeeAmt
                        .add(rescheduleHistoryDetails.getScheduleFeesAmount().getCurrencyAmount());
                refundableFeeAmount = refundableFeeAmount.add(rescheduleHistoryDetails.getFeesAmount().getCurrencyAmount());
            }
            if ((CeConstants.MODE_SCHEDULE.equals(getF_IN_mode()) && rescheduleHistoryDetails.isSelect())) {
                if (BigDecimal.ZERO.compareTo(rescheduleHistoryDetails.getScheduleFeesAmount().getCurrencyAmount()) == 0
                        && BigDecimal.ZERO.compareTo(rescheduleHistoryDetails.getFeesAmount().getCurrencyAmount()) == 0
                        && CeConstants.MODE_SCHEDULE.equals(getF_IN_mode())) {
                    IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_REFUND_ZERO_PROFIT_TO_PROCEED);
                }
                rescheduleHistoryDetails.setRescheduleProfitStatus(scheduledDesc);
                setF_OUT_refundablePaidRescheduleFeeAmt(
                        CeUtils.getZeroAmount(rescheduleHistoryDetails.getRescheduleProfitAmount().getCurrencyCode()));

            }
        }
        getF_OUT_rescheduleHistory().setRescheduleHistoryDetails(getF_IN_reschRefundFees().getRescheduleHistoryDetails());
        if (BigDecimal.ZERO.compareTo(refundRescheduleFeeAmt) == 0 && BigDecimal.ZERO.compareTo(refundableFeeAmount) == 0
                && CeConstants.MODE_SCHEDULE.equals(getF_IN_mode())) {
            // TODO
            IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_REFUND_ZERO_PROFIT_TO_PROCEED);
        }
        else if (BigDecimal.ZERO.compareTo(refundRescheduleFeeAmt) == 0) {
            getF_OUT_dealRescheduleDetails().setNewSchedule(getF_IN_reschRefundFees().getCurrentSchedule());
            getF_OUT_dealRescheduleDetails().getAssetProfileDetails().setAssetBasedPaymentSchedule(
                    getF_IN_reschRefundFees().getAssetProfileDetails().getAssetBasedPaymentSchedule());
        }
        else
        {
	        totalFeeAmt = getTotalFeeAmount(totalFeeAmt);
	        BigDecimal refundedPaidAmount = getAlreadyRefundedPaidFeeAmt();
	        totalFeeAmt =totalFeeAmt.subtract(refundedPaidAmount);
	        osRescheduleFeeAmt = totalFeeAmt.subtract(refundRescheduleFeeAmt);
	        BigDecimal totalOSRescheduleFeeAmt = osRescheduleFeeAmt;
	        if (BigDecimal.ZERO.compareTo(osRescheduleFeeAmt) >= 0 ) {
	            refundablePaidRescheduleFee = makeFeeComponentsZero(refundablePaidRescheduleFee);
	            refundablePaidRescheduleFee =refundablePaidRescheduleFee.subtract(refundedPaidAmount);
	        }
	        else {
	        	refundablePaidRescheduleFee = distributeOSFeeAmount(osRescheduleFeeAmt, totalFeeAmt, refundablePaidRescheduleFee, totalOSRescheduleFeeAmt,refundedPaidAmount);
	        }
	        getF_OUT_refundablePaidRescheduleFeeAmt().setCurrencyAmount(refundablePaidRescheduleFee);
	        prepareNewSchedule();
	        getF_OUT_dealRescheduleDetails().getAssetProfileDetails()
	                .setAssetBasedPaymentSchedule(getF_IN_reschRefundFees().getAssetProfileDetails().getAssetBasedPaymentSchedule());
        }
        if (getF_OUT_dealRescheduleDetails().getNewScheduleCount() > 0)
            setF_OUT_displayNewSchedule(true);
        if (CeConstants.MODE_CANCEL.equals(getF_IN_mode())) {
            if (BigDecimal.ZERO.compareTo(refundRescheduleFeeAmt) == 0 && BigDecimal.ZERO.compareTo(refundableFeeAmount) == 0) {
                setF_OUT_displayNewSchedule(false);
            }
            setF_OUT_disableRefundButton(false);
            setF_OUT_disableCancelRefundButton(true);
        }
        else if (CeConstants.MODE_SCHEDULE.equals(getF_IN_mode())) {
            setF_OUT_disableRefundButton(true);
            setF_OUT_disableCancelRefundButton(false);
        }
        LOGGER.info("Exiting from process method Deal ID -->" + getF_IN_reschRefundFees().getDealId());
    }

    private void prepareNewSchedule() {
        getF_OUT_dealRescheduleDetails().removeAllNewSchedule();
        String fullyPaidDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_FULLY_PAID);
		for (CePaymentSchedule currentSchedule : getF_IN_reschRefundFees().getCurrentSchedule()) {
            if (!fullyPaidDesc
                    .equals(currentSchedule.getStatus())) {
                currentSchedule.getFeesAmount().setCurrencyAmount(BigDecimal.ZERO);
                currentSchedule.getTotalRepaymentAmount().setCurrencyAmount(BigDecimal.ZERO);
            }
            else getF_OUT_dealRescheduleDetails().addNewSchedule(currentSchedule);
        }
        for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_reschRefundFees().getAssetProfileDetails()
                .getAssetBasedPaymentSchedule()) {
            for (CePaymentSchedule scheduleDetails : getF_IN_reschRefundFees().getCurrentSchedule()) {
				if (CalendarUtil.IsDate1EqualsToDate2(scheduleDetails.getRepaymentDate(),
						assetBasedPaymentSchedule.getRepaymentDate())
						&& !fullyPaidDesc
	                    .equals(scheduleDetails.getStatus())) {
					scheduleDetails.getFeesAmount()
							.setCurrencyAmount(scheduleDetails.getFeesAmount().getCurrencyAmount()
									.add(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount()));
					scheduleDetails.getTotalRepaymentAmount()
							.setCurrencyAmount(scheduleDetails.getPrincipalAmount().getCurrencyAmount()
									.add(scheduleDetails.getProfitAmount().getCurrencyAmount())
									.add(scheduleDetails.getFeesAmount().getCurrencyAmount()));
				}
            }
        }
        for(CePaymentSchedule scheduleDetails :getF_IN_reschRefundFees().getCurrentSchedule())
        {
        	 if (!fullyPaidDesc
                     .equals(scheduleDetails.getStatus())) {
        		 getF_OUT_dealRescheduleDetails().addNewSchedule(scheduleDetails);
        		 
        	 }
        }
    }

    private BigDecimal distributeOSFeeAmount(BigDecimal osRescheduleFeeAmt, BigDecimal totalFeeAmt,
            BigDecimal refundablePaidRescheduleFee, BigDecimal totalOSRescheduleFeeAmt, BigDecimal refundedPaidAmount) {
		for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_reschRefundFees().getAssetProfileDetails()
				.getAssetBasedPaymentSchedule()) {
			BigDecimal repaymentFeeAmount = assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount();
			BigDecimal ratio = repaymentFeeAmount.divide(totalFeeAmt, 6, RoundingMode.UP);
			BigDecimal assetRepaymentFeeAmount = new BigDecimal(totalOSRescheduleFeeAmt.multiply(ratio).intValue());
			if ((null == assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount()
					|| assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount().compareTo(
							assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount()) != 0)) {
				BigDecimal scheduleFeePaidAmt = assetBasedPaymentSchedule.getScheduleFeesAmountPaid()
						.getCurrencyAmount();
				BigDecimal scheduleFeeUnPaidAmt = assetBasedPaymentSchedule.getScheduleFeesAmount()
						.getCurrencyAmount().subtract(assetBasedPaymentSchedule.getScheduleFeesAmountPaid()
						.getCurrencyAmount());
				BigDecimal reducedFeeAmount = repaymentFeeAmount.subtract(assetRepaymentFeeAmount);
				// if unpaid Fee amoint is greater than new fee amount then directly amend the schedule fee amount
				if (null != assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount()
						&& scheduleFeeUnPaidAmt.compareTo(reducedFeeAmount) >= 0) {
					osRescheduleFeeAmt = osRescheduleFeeAmt.subtract(assetRepaymentFeeAmount);
					assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(assetRepaymentFeeAmount);
					assetBasedPaymentSchedule.getTotalRepaymentAmount()
							.setCurrencyAmount(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount()
									.add(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount())
									.add(assetRepaymentFeeAmount));

				} else {
					// For partially paid, removing from the unpaid schedule and calculating the
					// refundable amount for the remaining Amt
					assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(scheduleFeePaidAmt);
					assetBasedPaymentSchedule.getTotalRepaymentAmount()
							.setCurrencyAmount(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount()
									.add(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount())
									.add(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount()));
					reducedFeeAmount = reducedFeeAmount.subtract(scheduleFeeUnPaidAmt);
					if (reducedFeeAmount.compareTo(refundedPaidAmount) <= 0) {
						refundedPaidAmount = refundedPaidAmount.subtract(reducedFeeAmount);
					} else {
						refundedPaidAmount = BigDecimal.ZERO;
						refundablePaidRescheduleFee = refundablePaidRescheduleFee.add(reducedFeeAmount);
					}
					osRescheduleFeeAmt = osRescheduleFeeAmt
							.subtract(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount().subtract(reducedFeeAmount));
				}
			} else {
				if (repaymentFeeAmount.compareTo(refundedPaidAmount) <= 0) {
					refundedPaidAmount = refundedPaidAmount.subtract(repaymentFeeAmount);
				} else {
					repaymentFeeAmount = repaymentFeeAmount.subtract(refundedPaidAmount);
					refundedPaidAmount = BigDecimal.ZERO;
					ratio = repaymentFeeAmount.divide(totalFeeAmt, 6, RoundingMode.UP);
					assetRepaymentFeeAmount = new BigDecimal(totalOSRescheduleFeeAmt.multiply(ratio).intValue());
					refundablePaidRescheduleFee = refundablePaidRescheduleFee
							.add(repaymentFeeAmount.subtract(assetRepaymentFeeAmount));
					osRescheduleFeeAmt = osRescheduleFeeAmt.subtract(assetRepaymentFeeAmount);
				}
			}
		}
        if (BigDecimal.ZERO.compareTo(osRescheduleFeeAmt) != 0 || BigDecimal.ZERO.compareTo(refundablePaidRescheduleFee) != 0) {
            for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_reschRefundFees().getAssetProfileDetails()
                    .getAssetBasedPaymentSchedule()) {
				if ((null == assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount()
						|| BigDecimal.ZERO
								.compareTo(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount()
										.subtract(assetBasedPaymentSchedule.getScheduleFeesAmountPaid()
												.getCurrencyAmount())) < 0)) {
					assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(assetBasedPaymentSchedule
							.getScheduleFeesAmount().getCurrencyAmount().add(osRescheduleFeeAmt));
					assetBasedPaymentSchedule.getTotalRepaymentAmount()
                            .setCurrencyAmount(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount()
                                    .add(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount())
                                    .add(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount()));
                    break;
                }
            }
        }
        return refundablePaidRescheduleFee;
    }

	public BigDecimal getAlreadyRefundedPaidFeeAmt() {
		StringBuffer refundReschProfitDetailQuery = new StringBuffer();
		refundReschProfitDetailQuery.append(" WHERE " + IBOCE_IB_REFUNDRESCHDTLS.IBDEALID + " = ? and "+IBOCE_IB_REFUNDRESCHDTLS.IBSYSTEMSTATUS+"=?");
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_reschRefundFees().getDealId());
		params.add(CeConstants.REFUND_STATUS_REFUNDED);
		BigDecimal refundedPaidAmount = BigDecimal.ZERO;
		List<IBOCE_IB_REFUNDRESCHDTLS> refundReschProfitDetailsList = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_REFUNDRESCHDTLS.BONAME, refundReschProfitDetailQuery.toString(), params, null, false);
		if (null != refundReschProfitDetailsList && !refundReschProfitDetailsList.isEmpty()) {
			for(IBOCE_IB_REFUNDRESCHDTLS refundReschDtls:refundReschProfitDetailsList)
			{
				refundedPaidAmount = refundedPaidAmount.add(refundReschDtls.getF_IBPIADSCHEDULEFEEAMT());
			}
		}
		return refundedPaidAmount;
	}

    private BigDecimal makeFeeComponentsZero(BigDecimal refundablePaidRescheduleFee) {
        for (AssetBasedPaymentSchedule assetBasedPaymentSchedule : getF_IN_reschRefundFees().getAssetProfileDetails()
                .getAssetBasedPaymentSchedule()) {
            	BigDecimal newScheduleFeeAmt = (assetBasedPaymentSchedule.getScheduleFeesAmountPaid() != null && assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount() != null)?
            			assetBasedPaymentSchedule.getScheduleFeesAmountPaid().getCurrencyAmount() : BigDecimal.ZERO;
                assetBasedPaymentSchedule.getScheduleFeesAmount().setCurrencyAmount(newScheduleFeeAmt);
                assetBasedPaymentSchedule.getTotalRepaymentAmount()
                        .setCurrencyAmount(assetBasedPaymentSchedule.getPrincipalAmount().getCurrencyAmount()
                                .add(assetBasedPaymentSchedule.getProfitAmount().getCurrencyAmount())
                                .add(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount()));
                refundablePaidRescheduleFee = refundablePaidRescheduleFee
                        .add(assetBasedPaymentSchedule.getScheduleFeesAmount().getCurrencyAmount());
        }
        return refundablePaidRescheduleFee;
    }

    private BigDecimal getTotalFeeAmount(BigDecimal totalFeeAmt) {
        for (CePaymentSchedule paymentSchedule : getF_IN_reschRefundFees().getCurrentSchedule()) {
            totalFeeAmt = totalFeeAmt.add(paymentSchedule.getFeesAmount().getCurrencyAmount());
        }
        return totalFeeAmt;
    }

}
