package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DealRescheduleExecute;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_DealRescheduleExecute;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.ce.sadad.util.jaxb.FeeDetailsType.Fee;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.misys.bankfusion.calendar.functions.SubtractDateFromDate;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.constants.CoreBankingTemplateConstants;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.UpdateFinanceUtil;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleRequestDetails;
import bf.com.misys.ib.spi.types.ArrearLoanPayments;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.LoanDetails;
import bf.com.misys.ib.spi.types.messages.LoanNewTotalDtls;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanDetailsInput;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRq;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRs;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.header.RqHeader;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;
import edu.emory.mathcs.backport.java.util.Arrays;

public class DealRescheduleExecute extends AbstractCE_IB_DealRescheduleExecute implements ICE_IB_DealRescheduleExecute {

    private static final String ARREAR_AMEND_FLAG = "Amend";

	private static final String ARREAR_SKIP = "SKIP";

	private static final String REPAYMENT_STATUS_ARREAR = "ARREAR";

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private static final String DURATION_CODE_MONTH = "Month";

    private static final String REPAYMENT_STRING = "REPAYMENT";

    private static final String REPAYMENT_TYPE = "Repayment";

    private static final int E_HOST_AMOUNTS_CHANGE_CEIB = 44000313;

    public DealRescheduleExecute() {
        // TODO Auto-generated constructor stub
    }

    private static final transient Log LOGGER = LogFactory.getLog(DealRescheduleExecute.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();;

    public DealRescheduleExecute(BankFusionEnvironment env) {
        super(env);
    }

    private boolean isfromReschedule = false;
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process method deal Id ==>" + getF_IN_ibObject().getDealID());
        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_ibObject().getDealID());
        IBOCE_IB_DealReschedule rescheduleDetails = (IBOCE_IB_DealReschedule) factory
                .findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, getF_IN_ibObject().getTransactionID(), true);
        IBOCE_IB_REFUNDRESCHDTLS refundRescheduleDetails = (IBOCE_IB_REFUNDRESCHDTLS) factory
                .findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, getF_IN_ibObject().getTransactionID(), true);
		if(null == refundRescheduleDetails)
        	isfromReschedule  = true;
        CeRescheduleRequestDetails rescheduleRequestDetails = new CeRescheduleRequestDetails();
        if (null != rescheduleDetails && !rescheduleDetails.getF_IBRESCHEDULESTATUS().equals("COMPLETED")) {
            LOGGER.info("Getting reschedule request details from existing object");
            ReadLoanDetailsRs readLoanDetails = IBCommonUtils.getLoanDetails(getF_IN_ibObject().getDealID());
            Date oldRepaymentStartDate = getFirstRepaymentDate(readLoanDetails);
            validateOutStandingAmouts(rescheduleDetails,readLoanDetails);
			if (isfromReschedule) {
				Date firstPaymentDateDerived = RescheduleUtils.getRescheduleMinPaymentDate();
				if (CalendarUtil.IsDate1GreaterThanDate2(firstPaymentDateDerived,
						rescheduleDetails.getF_IBRESCHEDULEPAYMENTDT())) {
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_RESCH_PAYMENT_DATE_MIN_CEIB);
				}
			}
            setDealRescheduleDtls(dealDetails, rescheduleDetails, rescheduleRequestDetails);
            CePaymentSchedule[] paymentSchedules = RescheduleUtils.getNewSchedule(getF_IN_ibObject().getDealID(),
                    getF_IN_ibObject().getTransactionID(), dealDetails.getF_IsoCurrencyCode());
            List<CePaymentSchedule> newScheduleList = Arrays.asList(paymentSchedules);
            RescheduleLoanRq spiRescheduleLoanRq = setRescheduleSPIInput(dealDetails, newScheduleList, rescheduleRequestDetails,readLoanDetails);
            HashMap<String, Object> param = new HashMap<String, Object>();
            param.put(IBSPIConstants.SCH_AMENDMENT_MF_INPUT_PARAMNAME, spiRescheduleLoanRq);
            HashMap<String, Object> outputParams = MFExecuter.executeMF(IBSPIConstants.SCH_AMENDMENT_MFID, env, param);
            RescheduleLoanRs rescheduleLoanRs = (RescheduleLoanRs) outputParams
                    .get(IBSPIConstants.SCH_AMENDMENT_MF_OUTPUT_PARAMNAME);
            if (rescheduleLoanRs != null && rescheduleLoanRs.getRsHeader().getStatus().getOverallStatus().equals("S")) {
                LOGGER.info("Reschedule loan details updation completed for deal id ==>" + getF_IN_ibObject().getDealID());
                LOGGER.info("Updating IB tables after reschedule for deal id ==>" + getF_IN_ibObject().getDealID());
                ReadLoanDetailsRs readLoanAfterReschedule = IBCommonUtils.getLoanDetails(getF_IN_ibObject().getDealID());
                Date newRepaymentStartDate = getFirstRepaymentDate(readLoanAfterReschedule);
                if(!CalendarUtil.IsDate1EqualsToDate2(newRepaymentStartDate, oldRepaymentStartDate))
                {
                    updateLoandetailsWithNewRepaymentStartDate(dealDetails, newRepaymentStartDate);
                }
                updateDealDetailsAndScheduleProfile(newScheduleList, rescheduleRequestDetails, readLoanAfterReschedule);
                updatePaymentScheduleBreakUpDtls(rescheduleRequestDetails.getReschedulePaymentDate());
                updateRescheduleRecord();
                updateInvoices(readLoanAfterReschedule, dealDetails);
                LOGGER.info("Updating IB tables after reschedule Completed for deal id ==>" + getF_IN_ibObject().getDealID());
            }

        }
        LOGGER.info("Exiting from process method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    /**
     * This method will calculate the dates of invoices for today minus offset unpaid dates
     * And updates the invoices
     */
    private void updateInvoices(ReadLoanDetailsRs readLoanAfterReschedule, IBOIB_DLI_DealDetails dealDetails) {
    	LOGGER.info("Entering into updateArrearAndPartiallyPaidInvoices method deal Id ==>" + getF_IN_ibObject().getDealID());
    	List<Date> invoiceUpdateDatesList = new ArrayList<Date>();
    	//For current BD repaymentdate
    	for (LoanPayments loanPayment : readLoanAfterReschedule.getDealDetails().getPaymentSchedule()) {
    		if(CalendarUtil.IsDate1GreaterThanDate2(RescheduleUtils.getPaymentDateForInvoiceGeneration(),loanPayment.getRepaymentDate()) &&
    				!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getCurrentBusinessDate(),loanPayment.getRepaymentDate())){
	        	invoiceUpdateDatesList.add(loanPayment.getRepaymentDate());
	        }
    	}
    	SadadPaymentUtils.updateInvoiceForRepayment(getF_IN_ibObject().getDealID(), dealDetails.getF_DealAccountId(), invoiceUpdateDatesList);
    	LOGGER.info("Exiting from updateArrearAndPartiallyPaidInvoices method deal Id ==>" + getF_IN_ibObject().getDealID());
		
	}

	private void updateLoandetailsWithNewRepaymentStartDate(IBOIB_DLI_DealDetails dealDetails, Date newRepaymentStartDate) {
        LOGGER.info("Entering into updateLoandetailsWithNewRepaymentStartDate method deal Id ==>" + getF_IN_ibObject().getDealID());
        IBOLendingFeature loanDetails = (IBOLendingFeature) factory.findByPrimaryKey(IBOLendingFeature.BONAME,
                dealDetails.getF_DealAccountId(), true);
        loanDetails.setF_FIRSTREPAYMENTDATE(newRepaymentStartDate);
        loanDetails.setF_NEXTDUEDATE(newRepaymentStartDate);
        loanDetails.setF_NEXTINTERESTDUEDT(newRepaymentStartDate);
        loanDetails.setF_UBFIRSTINTERESTDUEDT(newRepaymentStartDate);
        loanDetails.setF_UBFIRSTPRINCIPALDUEDT(newRepaymentStartDate);
        factory.commitTransaction();
        factory.beginTransaction();
        LOGGER.info("Exiting from updateLoandetailsWithNewRepaymentStartDate method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private Date getFirstRepaymentDate(ReadLoanDetailsRs readLoanDetails) {
        LOGGER.info("Entering into getFirstRepaymentDate method deal Id ==>" + getF_IN_ibObject().getDealID());
        Date oldRepaymentStartDate = null;
        for(LoanPayments loanPayment: readLoanDetails.getDealDetails().getPaymentSchedule())
        {
            if(loanPayment.getRepaymentNo() == 1)
            {
                oldRepaymentStartDate = loanPayment.getRepaymentDate();
                break;
            }
        }
        LOGGER.info("Exiting from getFirstRepaymentDate method deal Id ==>" + getF_IN_ibObject().getDealID());
        return oldRepaymentStartDate;
    }

    private void updatePaymentScheduleBreakUpDtls(Date reschedulePaymentDate) {
        LOGGER.info("Entering into updatePaymentScheduleBreakUpDtls method deal Id ==>" + getF_IN_ibObject().getDealID());
        if(isfromReschedule) {
        	deleteFutureInstallmentsInBreakUp(reschedulePaymentDate);
        }
        //deleted the future schedule in reschedule and it will go thru
        //update only partial records need to insert the new schedule
        
        List<IBOCE_IB_PaymentScheduleHistory> paymentSchedules = queryPaymentSchedules();
        if (null != paymentSchedules && !paymentSchedules.isEmpty()) {
            for (IBOCE_IB_PaymentScheduleHistory historyPaymentSchedule : paymentSchedules) {
                if(CalendarUtil.IsDate1GreaterThanDate2(historyPaymentSchedule.getF_IBREPAYMENTDATE(),reschedulePaymentDate)
                		|| CalendarUtil.IsDate1EqualsToDate2(historyPaymentSchedule.getF_IBREPAYMENTDATE(),reschedulePaymentDate)) {
                	if(isfromReschedule) {
                		createNewBreakUpRecord(historyPaymentSchedule);
                	}
                	else {
                		//In case of refund query the payment break up details and update only the schedule fee amounts from schedule 
                		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
                				+ IBOCE_IB_PaymentSchBreakup.IBASSETID + " = ? AND "+IBOCE_IB_PaymentSchBreakup.IBBILLDATE+" = ?";
                		ArrayList params = new ArrayList();
                		params.add(getF_IN_ibObject().getDealID());
                		params.add(historyPaymentSchedule.getF_IBASSETID());
                		params.add(historyPaymentSchedule.getF_IBREPAYMENTDATE());
                		List<IBOCE_IB_PaymentSchBreakup> newPaymentSchedule = factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, true);
                		if(null != newPaymentSchedule && newPaymentSchedule.size()>0) {
                			newPaymentSchedule.get(0).setF_IBSCHEDULEFEEAMT(historyPaymentSchedule.getF_IBSCHEDULEFEESAMOUNT());
                		}
                	}
                }
                   
            }
        }
        factory.commitTransaction();
        factory.beginTransaction();
        LOGGER.info("Exiting from updatePaymentScheduleBreakUpDtls method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private void createNewBreakUpRecord(IBOCE_IB_PaymentScheduleHistory historyPaymentSchedule) {
        LOGGER.info("Entering into createNewBreakUpRecord method deal Id ==>" + getF_IN_ibObject().getDealID());
        IBOCE_IB_PaymentSchBreakup newPaymentSchedule = (IBOCE_IB_PaymentSchBreakup) factory
                .getStatelessNewInstance(IBOCE_IB_PaymentSchBreakup.BONAME);
        newPaymentSchedule.setF_IBASSETID(historyPaymentSchedule.getF_IBASSETID());
        newPaymentSchedule.setF_IBDEALID(getF_IN_ibObject().getDealID());
        newPaymentSchedule.setF_IBPRINCIPALAMT(historyPaymentSchedule.getF_IBPRINCIPALAMOUNT());
        newPaymentSchedule.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
        newPaymentSchedule.setF_IBPROFITAMT(historyPaymentSchedule.getF_IBPROFITAMOUNT());
        newPaymentSchedule.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
        newPaymentSchedule.setF_IBBILLDATE(historyPaymentSchedule.getF_IBREPAYMENTDATE());
        newPaymentSchedule.setF_IBSCHEDULEFEEAMT(historyPaymentSchedule.getF_IBSCHEDULEFEESAMOUNT());
        newPaymentSchedule.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
        newPaymentSchedule.setF_IBSUBSIDYAMNT(historyPaymentSchedule.getF_IBSUBSIDYAMOUNT());
        newPaymentSchedule.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
        factory.create(IBOCE_IB_PaymentSchBreakup.BONAME, newPaymentSchedule);
        LOGGER.info("Exiting from createNewBreakUpRecord method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private void updateRescheduleRecord() {
        LOGGER.info("Entering into updateRescheduleRecord method deal Id ==>" + getF_IN_ibObject().getDealID());
        IBOCE_IB_DealReschedule rescheduleDetailsDB = (IBOCE_IB_DealReschedule) factory
                .findByPrimaryKey(IBOCE_IB_DealReschedule.BONAME, getF_IN_ibObject().getTransactionID(), true);
        rescheduleDetailsDB.setF_IBRESCHEDULESTATUS(RescheduleConstants.STATUS_COMPLETED);
        rescheduleDetailsDB.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
        rescheduleDetailsDB.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
        LOGGER.info("Exiting from updateRescheduleRecord method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private Date getLastRepaymentDate(List<CePaymentSchedule> newScheduleList) {
        LOGGER.info("Entering into getLastRepaymentDate method deal Id ==>" + getF_IN_ibObject().getDealID());
        Date lastRepaymentDate = null;
        CePaymentSchedule lastSchedule;
        if (!newScheduleList.isEmpty()) {
            lastSchedule = newScheduleList.get(newScheduleList.size() - 1);
            lastRepaymentDate = lastSchedule.getRepaymentDate();
        }
        LOGGER.info("Exiting from getLastRepaymentDate method deal Id ==>" + getF_IN_ibObject().getDealID());
        return lastRepaymentDate;
    }

    private void updateDealDetailsAndScheduleProfile(List<CePaymentSchedule> newScheduleList,
            CeRescheduleRequestDetails rescheduleRequestDetails, ReadLoanDetailsRs readLoanAfterReschedule) {
        LOGGER.info("Entering into updateDealDetailsAndScheduleProfile method deal Id ==>" + getF_IN_ibObject().getDealID());
        UpdateFinanceUtil.updateScheduleProfileHist(getF_IN_ibObject().getDealID());
        String hostConfigured = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                IBConstants.IB_HOST, Boolean.FALSE.toString());
        IBOIB_DLI_DealDetails dealDetObj = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME,
                getF_IN_ibObject().getDealID(), true);

        BigDecimal repaymentAmount = BigDecimal.ZERO;
        if (!newScheduleList.isEmpty())
            repaymentAmount = newScheduleList.get(newScheduleList.size() - 1).getTotalRepaymentAmount().getCurrencyAmount();
        Date lastRepaymentDate = getLastRepaymentDate(newScheduleList);
        BigDecimal totalProfitAmount = BigDecimal.ZERO;
        BigDecimal scheduleChargeAmount = BigDecimal.ZERO;

        if (readLoanAfterReschedule != null && readLoanAfterReschedule.getDealDetails().getPaymentScheduleCount() > 0) {
            for (LoanPayments loanPayments : readLoanAfterReschedule.getDealDetails().getPaymentSchedule()) {
                totalProfitAmount = totalProfitAmount.add(loanPayments.getProfitAmt());
                scheduleChargeAmount = scheduleChargeAmount.add(loanPayments.getFeeAmt());
            }
        }

        if (dealDetObj != null) {
            updateDealDetailsTable(readLoanAfterReschedule, hostConfigured, dealDetObj, repaymentAmount, lastRepaymentDate,
                    totalProfitAmount);
        }

        updateScheduleProfile(rescheduleRequestDetails, dealDetObj, lastRepaymentDate, totalProfitAmount);
        LOGGER.info("Exiting from updateDealDetailsAndScheduleProfile method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private void updateScheduleProfile(CeRescheduleRequestDetails rescheduleRequestDetails, IBOIB_DLI_DealDetails dealDetObj,
            Date lastRepaymentDate, BigDecimal totalProfitAmount) {
        LOGGER.info("Entering into updateScheduleProfile method deal Id ==>" + getF_IN_ibObject().getDealID());
        String scheduleProfilesQuery = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ?";
        List<IBOIB_DLI_ScheduleProfile> scheduleProfile = new ArrayList<>();
        ArrayList params = new ArrayList();
        params.add(getF_IN_ibObject().getDealID());
        scheduleProfile = factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME, scheduleProfilesQuery, params, null, true);
        if (scheduleProfile != null && scheduleProfile.size() > 0) {
            IBOIB_DLI_ScheduleProfile repaymentProfile = null;
            for (IBOIB_DLI_ScheduleProfile schProfile : scheduleProfile) {
                if (schProfile.getF_ScheduleType().equals(DealInitiationConstants.DEALINIT_CONST_REPAYMENT))
                    repaymentProfile = schProfile;
            }
            if (repaymentProfile != null && dealDetObj != null) {
                Date scheduleStartDate = repaymentProfile.getF_scheduleStartDT();
                if (CalendarUtil.IsDate1GreaterThanDate2(repaymentProfile.getF_FirstPaymentDT(),
                        rescheduleRequestDetails.getReschedulePaymentDate())) {
                    scheduleStartDate = new Date(
                            ((java.util.Date) IBCommonUtils.getNextPaymentDate(rescheduleRequestDetails.getReschedulePaymentDate(),
                                    rescheduleRequestDetails.getRescheduleFrequency(), 1, -1, 0, false, 0)).getTime());
                    repaymentProfile.setF_FirstPaymentDT(rescheduleRequestDetails.getReschedulePaymentDate());
                    repaymentProfile.setF_scheduleStartDT(scheduleStartDate);
                }
                repaymentProfile.setF_ProfitPaymentAMT(totalProfitAmount);
                repaymentProfile.setF_CALCULATEDPROFIT(totalProfitAmount);
                repaymentProfile.setF_NoOfDays(SubtractDateFromDate.run(lastRepaymentDate, scheduleStartDate));
                long noOfMonths = CalendarUtil.getMonthsBetweenDate1AndDate2(lastRepaymentDate, scheduleStartDate);
                repaymentProfile.setF_DurationCode(DURATION_CODE_MONTH);
                repaymentProfile.setF_DurationUnit((int) noOfMonths);

                repaymentProfile.setF_FreqCode(rescheduleRequestDetails.getRescheduleFrequency());
                repaymentProfile.setF_LastPaymentDT(lastRepaymentDate);
                repaymentProfile.setF_scheduleEndDT(lastRepaymentDate);

                repaymentProfile.setF_NoOfPayments(rescheduleRequestDetails.getTotalNoOfInstallments()
                        - rescheduleRequestDetails.getOutstandingNoOfInstallments()
                        + rescheduleRequestDetails.getNewRemainingInstallments());
            }
        }
        LOGGER.info("Exiting from updateScheduleProfile method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private void updateDealDetailsTable(ReadLoanDetailsRs readLoanAfterReschedule, String hostConfigured,
            IBOIB_DLI_DealDetails dealDetObj, BigDecimal repaymentAmount, Date lastRepaymentDate, BigDecimal totalProfitAmount) {
        LOGGER.info("Entering into updateDealDetailsTable method deal Id ==>" + getF_IN_ibObject().getDealID());
        BigDecimal totalPrincipalAmount = dealDetObj.getF_PrincipleAmt();
        dealDetObj.setF_DealAmt(totalPrincipalAmount.add(totalProfitAmount));
        if (hostConfigured != null && hostConfigured.equals(CoreBankingTemplateConstants.ESSENCE_HOST))
            dealDetObj.setF_DealAmt(readLoanAfterReschedule.getDealDetails().getLoanBasicDetails().getOriginalDealAmount());
        dealDetObj.setF_DealTerm(SubtractDateFromDate.run(lastRepaymentDate, dealDetObj.getF_DealStartDate()));
        dealDetObj.setF_ProfitAmt(totalProfitAmount);
        dealDetObj.setF_RepaymentAmt(repaymentAmount);
        dealDetObj.setF_LastRepaymentDate(lastRepaymentDate);
        dealDetObj.setF_ModificationDTTM(SystemInformationManager.getInstance().getBFBusinessDateTime());
        dealDetObj.setF_ModifiedBy(BankFusionThreadLocal.getBankFusionEnvironment().getUserID());
        LOGGER.info("Exiting from updateDealDetailsTable method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private RescheduleLoanRq setRescheduleSPIInput(IBOIB_DLI_DealDetails dealDetails, List<CePaymentSchedule> newScheduleList,
            CeRescheduleRequestDetails rescheduleRequestDetails, ReadLoanDetailsRs readLoanDetails) {
    	//new tags population, totalnewamounts
        LOGGER.info("Entering into setRescheduleSPIInput method deal Id ==>" + getF_IN_ibObject().getDealID());
        RescheduleLoanRq spiRescheduleLoanRq = new RescheduleLoanRq();
        RescheduleLoanDetailsInput rescheduleLoanDetailsInput = new RescheduleLoanDetailsInput();
        LoanDetails loanDetails = new LoanDetails();
        loanDetails.setDealBranch(dealDetails.getF_BranchSortCode());
        String currencyCode = dealDetails.getF_IsoCurrencyCode();
        loanDetails.setDealCurrency(currencyCode);
        loanDetails.setDealID(getF_IN_ibObject().getDealID());
        loanDetails.setLoanAccountNo(dealDetails.getF_DealAccountId());
        ProductConfiguration productdetails = IBCommonUtils.loadProductConfiguration(getF_IN_ibObject().getProductID(),
                getF_IN_ibObject().getSubProductID());
        loanDetails.setIsHostScheduleGenerator(productdetails.isIsHostScheduleGenerator());
        loanDetails.setProductID(getF_IN_ibObject().getProductID());
        loanDetails.setSubProductID(getF_IN_ibObject().getSubProductID());
        loanDetails.setRepaymentType(REPAYMENT_STRING);
        if(CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), rescheduleRequestDetails.getReschedulePaymentDate())) {
        	loanDetails.setPaymentStartDate(IBCommonUtils.getBFBusinessDate());
        }else {
        	loanDetails.setPaymentStartDate(rescheduleRequestDetails.getReschedulePaymentDate());
        }
        
        if (rescheduleRequestDetails.getOutstandinProfit() != null)
            loanDetails.setProfitAmt(IBCommonUtils.scaleAmount(currencyCode, rescheduleRequestDetails.getOutstandinProfit()
                    .getCurrencyAmount().add(rescheduleRequestDetails.getScheduleFeesAmount().getCurrencyAmount())));
        rescheduleLoanDetailsInput.setLoanDetails(loanDetails);
        BigDecimal outStandingPrincipal = rescheduleRequestDetails.getOutstandinPrincipal().getCurrencyAmount();
        int totalInstallments = 0;
        BigDecimal totalProfit = BigDecimal.ZERO;
        int fullyPaidInstallmentsCount = 0;
        
        for(LoanPayments loanPayment: readLoanDetails.getDealDetails().getPaymentSchedule())
		{
        	if(isfromReschedule && (loanPayment.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_ARREAR) || loanPayment.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_PARTIAL_PAID))) {
        		ArrearLoanPayments arrearLoanPayments = new ArrearLoanPayments();
        		if(BigDecimal.ZERO.compareTo(loanPayment.getProfitAmtPaid()) < 0 || BigDecimal.ZERO.compareTo(loanPayment.getPrincipalAmtPaid()) < 0)
        			arrearLoanPayments.setAmendFlag(ARREAR_AMEND_FLAG);
        		else
        			arrearLoanPayments.setAmendFlag(ARREAR_SKIP);
        		arrearLoanPayments.setRepaymentDate(loanPayment.getRepaymentDate());
        		arrearLoanPayments.setRepaymentNumber(loanPayment.getRepaymentNo());
        		arrearLoanPayments.setNewInterestDue(loanPayment.getProfitAmtPaid());
        		arrearLoanPayments.setNewPrincipalDue(loanPayment.getPrincipalAmtPaid());
        		if(loanPayment.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_PARTIAL_PAID)) {
        			totalInstallments++;
        		}
        		totalProfit = totalProfit.add(loanPayment.getProfitAmtPaid());
        		rescheduleLoanDetailsInput.addArrearPaymentSchedule(arrearLoanPayments);
        	}
        	if(loanPayment.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_FULLY_PAID)) {
        		totalInstallments++;
        		totalProfit = totalProfit.add(loanPayment.getProfitAmt());
        		fullyPaidInstallmentsCount++;
        	}
		}
        if (!productdetails.isIsHostScheduleGenerator() && !newScheduleList.isEmpty()) {
            for (CePaymentSchedule paymentSchedule : newScheduleList) {
            	totalInstallments++;
                LoanPayments loanPayment = new LoanPayments();
                loanPayment.setFeeAmt(IBCommonUtils.scaleAmount(currencyCode, BigDecimal.ZERO));
                loanPayment.setIsoCurrencyCode(currencyCode);
                loanPayment.setPrincipleAmt(
                        IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getPrincipalAmount().getCurrencyAmount()));
                BigDecimal profitAmt = IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getProfitAmount()
                        .getCurrencyAmount().add(paymentSchedule.getFeesAmount().getCurrencyAmount()));
                //i need to plus the paid profit at deal level 
                totalProfit = totalProfit.add(profitAmt);
                loanPayment.setProfitAmt(profitAmt);
                loanPayment.setProfitRate(dealDetails.getF_ProfitRate());
                loanPayment.setRepaymentAmt(
                        IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getTotalRepaymentAmount().getCurrencyAmount()));
                loanPayment.setRepaymentDate(paymentSchedule.getRepaymentDate());
                if(!isfromReschedule) {
                	loanPayment.setRepaymentNo(paymentSchedule.getRepaymentNo()+fullyPaidInstallmentsCount);
                }else {
                	loanPayment.setRepaymentNo(paymentSchedule.getRepaymentNo());
                }
                loanPayment.setRepaymentType(REPAYMENT_TYPE);
                outStandingPrincipal = outStandingPrincipal.subtract(paymentSchedule.getPrincipalAmount().getCurrencyAmount());
                loanPayment.setOutstandingPrincipalAmt(IBCommonUtils.scaleAmount(currencyCode, outStandingPrincipal));
                if(!isfromReschedule && (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), paymentSchedule.getRepaymentDate()))) {
                	ArrearLoanPayments arrearLoanPayments = new ArrearLoanPayments();
                    arrearLoanPayments.setAmendFlag(ARREAR_AMEND_FLAG);
                    arrearLoanPayments.setRepaymentDate(paymentSchedule.getRepaymentDate());
                    arrearLoanPayments.setRepaymentNumber(paymentSchedule.getRepaymentNo()+fullyPaidInstallmentsCount);
                    arrearLoanPayments.setNewInterestDue(profitAmt);
                    arrearLoanPayments.setNewPrincipalDue(IBCommonUtils.scaleAmount(currencyCode, paymentSchedule.getPrincipalAmount().getCurrencyAmount()));
                    rescheduleLoanDetailsInput.addArrearPaymentSchedule(arrearLoanPayments);
                }else {
                	rescheduleLoanDetailsInput.addManualPaymentSchedule(loanPayment);
                }
                
            }
        }
        
        //incase of reschedule
        //from read loan rs arrears, partially paid  and arrear zero
        
        //if rese
        //partially paid and fully paid
        
        //refund
        //add fully paid
        
        
        
        LoanNewTotalDtls loanNewTotalDtls = new LoanNewTotalDtls();
        loanNewTotalDtls.setTotalNoOfIntslmnts(totalInstallments);
        loanNewTotalDtls.setTotalProfitAmt(totalProfit);
        rescheduleLoanDetailsInput.setLoanNewTotalDtls(loanNewTotalDtls);
        RqHeader rqHeader = new RqHeader();
        spiRescheduleLoanRq.setRescheduleLoanDetailsInput(rescheduleLoanDetailsInput);
        spiRescheduleLoanRq.setRqHeader(rqHeader);
        LOGGER.info("--------------------- RescheduleRequest  ---------------------------");
        LOGGER.info("--------------------- Interface XML (Begin) ---------------------------");
        LOGGER.info("--------------------- Interface XML (" + spiRescheduleLoanRq.getClass().getSimpleName()
                + ") ---------------------------");
        // LOGGER.info(convertObjectToXMLString(BankFusionThreadLocal.getBankFusionEnvironment(),
        // Object));
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        LOGGER.info((gson.toJson(spiRescheduleLoanRq)).replace("\"", " ").replace(",", "").replace("_", "\t"));
        LOGGER.info("--------------------- Interface XML (End)   ---------------------------");
        LOGGER.info("Exiting from setRescheduleSPIInput method deal Id ==>" + getF_IN_ibObject().getDealID());
        return spiRescheduleLoanRq;
    }

    private void setDealRescheduleDtls(IBOIB_DLI_DealDetails dealDetails, IBOCE_IB_DealReschedule rescheduleDetails,
            CeRescheduleRequestDetails rescheduleRequestDetails) {
        LOGGER.info("Entering into setDealRescheduleDtls method deal Id ==>" + getF_IN_ibObject().getDealID());
        rescheduleRequestDetails.setCurrentRescheduleProfit(
                IBCommonUtils.getBFCurrencyAmount(rescheduleDetails.getF_IBRESCHEDULEPROFIT(), dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setFeesAmount(
                IBCommonUtils.getBFCurrencyAmount(rescheduleDetails.getF_IBRESCHEDULEPROFIT(), dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setFeesCollectionMethod(rescheduleDetails.getF_IBRESCHEDULECOLLMETHOD());
        rescheduleRequestDetails.setFeesPercentage(new BigDecimal(100).subtract(rescheduleDetails.getF_IBSCHEDULEFEESPER()));
        rescheduleRequestDetails.setIncludeSubsidy(rescheduleDetails.isF_IBINCLUDESUBSIDY());
        rescheduleRequestDetails.setNewRemainingInstallments(rescheduleDetails.getF_IBRESCHINSTALLMENTS());
        rescheduleRequestDetails.setOutstandingNoOfInstallments(rescheduleDetails.getF_IBOUTSTANDINGINSTALLMENTS());
        rescheduleRequestDetails.setOutstandinPrincipal(IBCommonUtils
                .getBFCurrencyAmount(rescheduleDetails.getF_IBOUTSTANDINGPRINCIPAL(), dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setOutstandinProfit(IBCommonUtils.getBFCurrencyAmount(rescheduleDetails.getF_IBOUTSTANDINGPROFIT(),
                dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setRescheduleFrequency(rescheduleDetails.getF_IBRESCHEDULEFREQ());
        rescheduleRequestDetails.setReschedulePaymentDate(rescheduleDetails.getF_IBRESCHEDULEPAYMENTDT());
        rescheduleRequestDetails.setScheduleFeesAmount(
                IBCommonUtils.getBFCurrencyAmount(rescheduleDetails.getF_IBSCHEDULEFEES(), dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setScheduleFeesPercentage(rescheduleDetails.getF_IBSCHEDULEFEESPER());
        rescheduleRequestDetails.setSurplusAmount(
                IBCommonUtils.getBFCurrencyAmount(rescheduleDetails.getF_IBSURPLUSAMOUNT(), dealDetails.getF_IsoCurrencyCode()));
        rescheduleRequestDetails.setTotalNoOfInstallments(rescheduleDetails.getF_IBTOTALINSTBEFRESCH());
        if(rescheduleDetails.getF_IBRESCHEDULETYPE() == null || rescheduleDetails.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_GENERATE)) {
        	rescheduleRequestDetails.setIsGenerate(true);
        }else if(rescheduleDetails.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_POSTPONE)) {
        	rescheduleRequestDetails.setIsPostpone(true);
        }else if(rescheduleDetails.getF_IBRESCHEDULETYPE().equals(CeConstants.RESCHEDULE_TYPE_DISTRIBUTE)) {
        	rescheduleRequestDetails.setIsDistribute(true);
        }
        LOGGER.info("Exiting from setDealRescheduleDtls method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private void validateOutStandingAmouts(IBOCE_IB_DealReschedule rescheduleDetails, ReadLoanDetailsRs readLoanDetails) {
        LOGGER.info("Entering into validateOutStandingAmouts method deal Id ==>" + getF_IN_ibObject().getDealID());
        BigDecimal previousPaidProfitAmnt = BigDecimal.ZERO;
        BigDecimal previousPaidPrincipalAmnt = BigDecimal.ZERO;
        BigDecimal cuurentOutstandingPrincipal = BigDecimal.ZERO;
        BigDecimal currentOutstandingProfit = BigDecimal.ZERO;
        BigDecimal partiallyPaidProfit = BigDecimal.ZERO;
        for(LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
        	/*if (loanPayments.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_ARREAR) && !isfromReschedule) {
                IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_CLEAR_ARREARS_TO_PROCEED);
            }*/
			previousPaidPrincipalAmnt = previousPaidPrincipalAmnt
						.add(loanPayments.getPrincipalAmtPaid());
			previousPaidProfitAmnt = previousPaidProfitAmnt.add(loanPayments.getProfitAmtPaid());
			if (!(loanPayments.getRepaymentStatus().equalsIgnoreCase(CeConstants.PAYMENT_STATUS_FULLY_PAID)) && !isfromReschedule) {
				partiallyPaidProfit = partiallyPaidProfit.add(loanPayments.getProfitAmtPaid());
			}
        }
        cuurentOutstandingPrincipal = readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt().subtract(previousPaidPrincipalAmnt);
        currentOutstandingProfit = readLoanDetails.getDealDetails().getLoanBasicDetails().getProfitAmt().subtract(previousPaidProfitAmnt);
        if(!isfromReschedule)
        	currentOutstandingProfit = currentOutstandingProfit.add(partiallyPaidProfit);
        	
        // Validate the current deal OS principal with the rescheduled outstanding principal
        if (cuurentOutstandingPrincipal
                .compareTo(rescheduleDetails.getF_IBOUTSTANDINGPRINCIPAL()) != 0
                || currentOutstandingProfit.compareTo(
                                rescheduleDetails.getF_IBOUTSTANDINGPROFIT().add(rescheduleDetails.getF_IBOUTSTANDINGFEE())) != 0) {
        	if(isfromReschedule)
        		IBCommonUtils.raiseUnparameterizedEvent(E_HOST_AMOUNTS_CHANGE_CEIB);
        	else
        		IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_REFUND_HOST_AMOUNTS_CHANGE_CEIB);
        }
        LOGGER.info("Exiting from validateOutStandingAmouts method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

    private List<IBOCE_IB_PaymentScheduleHistory> queryPaymentSchedules() {
        LOGGER.info("Entering into queryPaymentSchedules method deal Id ==>" + getF_IN_ibObject().getDealID());
        String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentScheduleHistory.IBDEALID + " = ? AND "
                + IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID + " = ?  ORDER BY " + IBOCE_IB_PaymentScheduleHistory.IBREPAYMENTDATE + " ASC ";
        ArrayList<Object> params = new ArrayList<>();
        params.add(getF_IN_ibObject().getDealID());
        params.add(getF_IN_ibObject().getTransactionID());
        List<IBOCE_IB_PaymentScheduleHistory> schBreakupDtls = factory.findByQuery(IBOCE_IB_PaymentScheduleHistory.BONAME,
                scheduleBreakupQuery, params, null, false);
        LOGGER.info("Exiting from queryPaymentSchedules method deal Id ==>" + getF_IN_ibObject().getDealID());
        return schBreakupDtls;
    }

    private void deleteFutureInstallmentsInBreakUp(Date reschedulePaymentDate) {
    	 LOGGER.info("Entering into deleteFutureInstallmentsInBreakUp method deal Id ==>" + getF_IN_ibObject().getDealID());
    	String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
    	ArrayList<Object> params = new ArrayList<>();
        params.add(getF_IN_ibObject().getDealID());
        List<IBOCE_IB_PaymentSchBreakup> previousBackupDetails = factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME,
        		scheduleBreakupQuery, params, null, false);
        for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : previousBackupDetails) {
			if(CalendarUtil.IsDate1GreaterThanDate2(reschedulePaymentDate, paymentSchBreakup.getF_IBBILLDATE()) || CalendarUtil.IsDate1EqualsToDate2(reschedulePaymentDate, paymentSchBreakup.getF_IBBILLDATE())) {
				if((null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
					&& paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID().compareTo(BigDecimal.ZERO)>0 && paymentSchBreakup.getF_IBSCHEDULEFEEAMT().compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) > 0)
					|| (null != paymentSchBreakup.getF_IBPRINCIPALAMTPAID()
							&& paymentSchBreakup.getF_IBPRINCIPALAMTPAID().compareTo(BigDecimal.ZERO)>0 && paymentSchBreakup.getF_IBPRINCIPALAMT().compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) > 0)
					|| (null != paymentSchBreakup.getF_IBPROFITAMTPAID()
							&& paymentSchBreakup.getF_IBPROFITAMTPAID().compareTo(BigDecimal.ZERO)>0 && paymentSchBreakup.getF_IBPROFITAMT().compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) > 0)
					|| (null != paymentSchBreakup.getF_IBSUBSIDYAMTPAID()
							&& paymentSchBreakup.getF_IBSUBSIDYAMTPAID().compareTo(BigDecimal.ZERO)>0 && paymentSchBreakup.getF_IBSUBSIDYAMNT().compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) > 0&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) < 0)) {
					//case for parttially paid
					paymentSchBreakup.setF_IBSCHEDULEFEEAMT(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
					paymentSchBreakup.setF_IBPRINCIPALAMT(paymentSchBreakup.getF_IBPRINCIPALAMTPAID());
					paymentSchBreakup.setF_IBPROFITAMT(paymentSchBreakup.getF_IBPROFITAMTPAID());
					paymentSchBreakup.setF_IBSUBSIDYAMNT(paymentSchBreakup.getF_IBSUBSIDYAMTPAID());
				}else if((null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						&& paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID().compareTo(BigDecimal.ZERO)==0)
						&& (null != paymentSchBreakup.getF_IBPRINCIPALAMTPAID()
								&& paymentSchBreakup.getF_IBPRINCIPALAMTPAID().compareTo(BigDecimal.ZERO)==0)
						&& (null != paymentSchBreakup.getF_IBPROFITAMTPAID()
								&& paymentSchBreakup.getF_IBPROFITAMTPAID().compareTo(BigDecimal.ZERO)==0)
						&& (null != paymentSchBreakup.getF_IBSUBSIDYAMTPAID()
								&& paymentSchBreakup.getF_IBSUBSIDYAMTPAID().compareTo(BigDecimal.ZERO)==0)) {
					//case for arrears or unpaid
					String deletePaymentBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			                + IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
					ArrayList<Object> deletePBreakupParams = new ArrayList<>();
					deletePBreakupParams.add(getF_IN_ibObject().getDealID());
					deletePBreakupParams.add(paymentSchBreakup.getF_IBBILLDATE());
					factory.bulkDelete(IBOCE_IB_PaymentSchBreakup.BONAME, deletePaymentBreakupQuery, deletePBreakupParams);
				}
			}
        }
       
    	//dont delete the partially paid and update only the unpaid amounts
        //delete only the arrers and unpaid before reschdule repay
        //dont change the fully paid record
        
        
        //if refund
        //only amend the data and that to scheduled unpaid amounts
        String futureScheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
                + IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " >= ? ";
        ArrayList<Object> params1 = new ArrayList<>();
        params1.add(getF_IN_ibObject().getDealID());
        params1.add(reschedulePaymentDate);
        factory.bulkDelete(IBOCE_IB_PaymentSchBreakup.BONAME, futureScheduleBreakupQuery, params1);
        factory.commitTransaction();
        factory.beginTransaction();
        LOGGER.info("Exiting from deleteFutureInstallmentsInBreakUp method deal Id ==>" + getF_IN_ibObject().getDealID());
    }

}
