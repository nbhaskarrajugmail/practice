package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveValidationConfs;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationConfList;

public class SaveValidationConfiguration extends AbstractCE_IB_SaveValidationConfs{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 678931636906796867L;

	public SaveValidationConfiguration()
	{
		super();
	}
	
	public SaveValidationConfiguration(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		ValidationConfList validationConfList = getF_IN_validationConfigurationList();
		for(ValidationConf eachValidationConf : validationConfList.getValidationConf())
		{
			ValidationsUtil.saveOrUpdate(eachValidationConf);
		}
	}
}
