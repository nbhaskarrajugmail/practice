package com.ce.bankfusion.ib.fatom;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineConfigID;
import com.ce.bankfusion.ib.bo.refimpl.CE_IB_PricingEngineRatesID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineConfig;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingEngineRates;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PricingEngineConfigurationService;
import com.ce.bankfusion.ib.util.PricingEngineConfUtil;

import bf.com.misys.cbs.types.events.Event;
import com.trapedza.bankfusion.core.EventsHelper;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.AttrVisibiltyFlags;
import bf.com.misys.ib.types.ListPricingEngineConfsRs;
import bf.com.misys.ib.types.ParamAndRateDtlList;
import bf.com.misys.ib.types.ParamAndRateDtls;
import bf.com.misys.ib.types.PricingEngineConf;

public class PricingEngineConfService extends AbstractCE_IB_PricingEngineConfigurationService{
    private static final long serialVersionUID = 1L;

    public PricingEngineConfService() {
        super();
    }

    public PricingEngineConfService(BankFusionEnvironment env) {

    }

    public void process(BankFusionEnvironment env) throws BankFusionException {
        String mode = getF_IN_mode();

        switch (mode) {
        case "SCALAR_NEW":
            addNewRow(env);
            break;
        case "SCALAR_REMOVE":
            removeRow(env);
            break;
        case "SCALAR_SAVE":
            saveRow(env);
            break;
        case "ROW_SELECTED":
            rowSelected(env);
            break;
        default:
            break;
        }
    }

    private void rowSelected(BankFusionEnvironment env) {
        ListPricingEngineConfsRs ListPricingEngine = getF_IN_ListPricingEngineConf();
        if(ListPricingEngine.getPricingEngineConfListCount()>0) {
        for(PricingEngineConf priEngConf : ListPricingEngine.getPricingEngineConfList()) {
            if(priEngConf.isSelect()) {
                /*priEngConf.setInputFieldsDtls(priEngConf.getInputFieldsDtls());
                priEngConf.setRateDetails(priEngConf.getRateDetails());
                priEngConf.setOutputFieldsDtls(priEngConf.getOutputFieldsDtls());
                priEngConf.setOtherDtls(priEngConf.getOtherDtls());*/
                //set rate and params
            	//set visibility flags
            	if((null != priEngConf.getGroupCD() && priEngConf.getGroupCD() > 0) || (null != priEngConf.getToolNo() && priEngConf.getToolNo()>0) || (null != priEngConf.getListser() && priEngConf.getListser()>0))
            	{
            		ParamAndRateDtlList paramAndRateDtlList = new ParamAndRateDtlList();
            		String whereClause = "WHERE " + IBOCE_IB_PricingEngineRates.GRP_CDPK + " = ? AND "
                			+ IBOCE_IB_PricingEngineRates.TOOLNOPK + " = ? AND " 
                			+ IBOCE_IB_PricingEngineRates.LISTSERPK + " = ?";
                	ArrayList params = new ArrayList<>();
                	params.add(priEngConf.getGroupCD());
                	params.add(priEngConf.getToolNo());
                	params.add(priEngConf.getListser());
                	List<IBOCE_IB_PricingEngineRates> paramAndRateDtls = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_PricingEngineRates.BONAME,
                			whereClause, params, null, false);
                	for(IBOCE_IB_PricingEngineRates paramAndRateDtl : paramAndRateDtls)
                	{
                		CE_IB_PricingEngineRatesID engineRatesID = (CE_IB_PricingEngineRatesID) paramAndRateDtl.getCompositeBOID();
                		ParamAndRateDtls paramAndRateDtlObj = new ParamAndRateDtls();
                		paramAndRateDtlObj.setParm1(engineRatesID.getF_PARM1());
                		paramAndRateDtlObj.setParm2(engineRatesID.getF_PARM2());
                		paramAndRateDtlObj.setParm3(engineRatesID.getF_PARM3());
                		paramAndRateDtlObj.setPrat1(paramAndRateDtl.getF_PRAT1());
                		paramAndRateDtlObj.setPrat2(paramAndRateDtl.getF_PRAT2());
                		paramAndRateDtlObj.setPrat3(paramAndRateDtl.getF_PRAT3());
                		paramAndRateDtlObj.setPrat4(paramAndRateDtl.getF_PRAT4());
                		paramAndRateDtlObj.setPrat5(paramAndRateDtl.getF_PRAT5());
						paramAndRateDtlList.addParamAndRateDtls(paramAndRateDtlObj );
                	}
                	setF_OUT_paramAndRateDtlList(paramAndRateDtlList);
                	AttrVisibiltyFlags attrVisibiltyFlags  = PricingEngineConfUtil.populateAttrNamesAndVisibilty(priEngConf);
                	setF_OUT_attrVisibiltyFlags(attrVisibiltyFlags);
                	setF_OUT_pricingEngineConfOut(priEngConf);
                	setF_OUT_disableAssetSearch(true);
            	}
            	else
            	{
            		setF_OUT_paramAndRateDtlList(new ParamAndRateDtlList());
            		setF_OUT_attrVisibiltyFlags(new AttrVisibiltyFlags());
            		setF_OUT_disableAssetSearch(false);
            	}
            	
            }
         }
        }
        
    }

    private void addNewRow(BankFusionEnvironment env) {
    	if(null != getF_IN_ListPricingEngineConf() && getF_IN_ListPricingEngineConf().getPricingEngineConfListCount() > 0) {
    		ListPricingEngineConfsRs pricingEngineConfList = getF_IN_ListPricingEngineConf();
    		for(PricingEngineConf priEngConf : pricingEngineConfList.getPricingEngineConfList()) {
    			priEngConf.setSelect(false);
    		}
    		PricingEngineConf pricingEngineConfNew = new PricingEngineConf();
    		IBCommonUtils.intializeDefaultvalues(pricingEngineConfNew);
    		pricingEngineConfNew.setSelect(true);
    		pricingEngineConfList.addPricingEngineConfList(pricingEngineConfNew);
    		setF_OUT_ListPricingEngineConf(pricingEngineConfList);
    	}
    	else {
    		PricingEngineConf newRow = new PricingEngineConf();
    		newRow.setSelect(true);
    		IBCommonUtils.intializeDefaultvalues(newRow);
    		ListPricingEngineConfsRs pricingEngineConfList = new ListPricingEngineConfsRs();
    		pricingEngineConfList.addPricingEngineConfList(newRow);
    		setF_OUT_ListPricingEngineConf(pricingEngineConfList);
    	}
    	setF_OUT_new(true);
    	setF_OUT_disableAssetSearch(false);
    }

    private void removeRow(BankFusionEnvironment env) {
        ListPricingEngineConfsRs ListPricingEngine = getF_IN_ListPricingEngineConf();
        for(PricingEngineConf priEngConf : ListPricingEngine.getPricingEngineConfList()) {
            if(priEngConf.isSelect()) {
                ListPricingEngine.removePricingEngineConfList(priEngConf);
                if(null != priEngConf.getGroupCD() && priEngConf.getGroupCD() > 0)
                {
                	//remove from DB
                	CE_IB_PricingEngineConfigID key = new CE_IB_PricingEngineConfigID();
                	key.setF_GRP_CD(priEngConf.getGroupCD());
                	key.setF_LISTSER(priEngConf.getListser());
                	key.setF_TOOLNO(priEngConf.getToolNo());
                	IBCommonUtils.getPersistanceFactory().remove(IBOCE_IB_PricingEngineConfig.BONAME, key);
                	String whereClause = "WHERE " + IBOCE_IB_PricingEngineRates.GRP_CDPK + " = ? AND "
                			+ IBOCE_IB_PricingEngineRates.TOOLNOPK + " = ? AND " 
                			+ IBOCE_IB_PricingEngineRates.LISTSERPK + " = ?";
                	ArrayList deleteParams = new ArrayList<>();
                	deleteParams.add(priEngConf.getGroupCD());
                	deleteParams.add(priEngConf.getToolNo());
                	deleteParams.add(priEngConf.getListser());
                	BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_IB_PricingEngineRates.BONAME, whereClause, deleteParams);
                	Event raiseEvent = new Event();
                  raiseEvent.setEventNumber(44000350);
                  EventsHelper.handleEvent(raiseEvent, env);
                }
            }
        }
        if(ListPricingEngine.getPricingEngineConfListCount()>0) {
            ListPricingEngine.getPricingEngineConfList(ListPricingEngine.getPricingEngineConfListCount()-1).setSelect(true);
        }
        setF_OUT_ListPricingEngineConf(ListPricingEngine);
        setF_OUT_new(false);
        //setF_OUT_remove(true);
    }

    private void saveRow(BankFusionEnvironment env) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        ListPricingEngineConfsRs ListPricingEngine = getF_IN_ListPricingEngineConf();
        PricingEngineConf priEngConfFromScalar;
        for(PricingEngineConf priEngConf : ListPricingEngine.getPricingEngineConfList()) {
            if(priEngConf.isSelect()) {
                priEngConfFromScalar = getF_IN_pricingEngineConf();
                IBOCE_IB_PricingEngineConfig pricingDtls;
                if(StringUtils.isBlank(priEngConfFromScalar.getAssetCategoryID()))
                {
                	//raising asset not selected error
                	IBCommonUtils.raiseUnparameterizedEvent(44000345);
                }
                CE_IB_PricingEngineConfigID key = new CE_IB_PricingEngineConfigID();
                key.setF_GRP_CD(priEngConfFromScalar.getGroupCD());
                key.setF_LISTSER(priEngConfFromScalar.getListser());
                key.setF_TOOLNO(priEngConfFromScalar.getToolNo());
                
                IBOCE_IB_PricingEngineConfig pricingListFromDB = (IBOCE_IB_PricingEngineConfig) IBCommonUtils.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_PricingEngineConfig.BONAME, key, true);
                 
                if(null != pricingListFromDB && priEngConf.getAssetCategoryID().isEmpty())
                {
                	//raising duplicate error
                	IBCommonUtils.raiseUnparameterizedEvent(44000344);
                }
                ListPricingEngine.removePricingEngineConfList(priEngConf);
                priEngConf = priEngConfFromScalar;
                priEngConf.setSelect(true);
                if(null == pricingListFromDB)
                {
                	pricingDtls = (IBOCE_IB_PricingEngineConfig) factory
                      .getStatelessNewInstance(IBOCE_IB_PricingEngineConfig.BONAME);
                	IBCommonUtils.intializeDefaultvalues(pricingDtls);
                    CE_IB_PricingEngineConfigID ID = new CE_IB_PricingEngineConfigID();
                    ID.setF_GRP_CD(priEngConf.getGroupCD());
                    ID.setF_LISTSER(priEngConf.getListser());
                    ID.setF_TOOLNO(priEngConf.getToolNo());
                    pricingDtls.setCompositeBOID(ID);
                    pricingDtls.setF_ASSETCATEGORYID(priEngConf.getAssetCategoryID());
                }
                else
                {
                	pricingDtls = pricingListFromDB;
                }
                  //others
                pricingDtls.setF_CALC_FORMULA1(priEngConf.getOtherDtls().getCalcFormula1());
                pricingDtls.setF_CALC_FORMULA2(priEngConf.getOtherDtls().getCalcFormula2());
                pricingDtls.setF_CALC_FORMULA_EXPL(priEngConf.getOtherDtls().getFormulaExpl());
                pricingDtls.setF_CNT_IND(priEngConf.getOtherDtls().getCntInd());
                  if(priEngConf.getOtherDtls().getHlpInd()) {
                	  pricingDtls.setF_HLP_IND(1);
                  }else {
                	  pricingDtls.setF_HLP_IND(0);
                  }
                  
                  if(priEngConf.getOtherDtls().getNoRule()) {
                	  pricingDtls.setF_NO_RULE(1);
                  }else {
                	  pricingDtls.setF_NO_RULE(0);
                  }
                  
                  if(priEngConf.getOtherDtls().getOutRateInd()) {
                      pricingDtls.setF_OUT_RATE_IND(1);
                  }else {
                      pricingDtls.setF_OUT_RATE_IND(0);
                  }
                  
                  if(priEngConf.getOtherDtls().getPriceCtrl()) {
                      pricingDtls.setF_PRICE_CTRL(1);
                  }else {
                      pricingDtls.setF_PRICE_CTRL(0);
                  }
                  
                  if(priEngConf.getOtherDtls().getPrjInd()) {
                      pricingDtls.setF_PRJ_IND(1);
                  }else {
                      pricingDtls.setF_PRJ_IND(0);
                  }
                  
                  pricingDtls.setF_STOP_DAT(priEngConf.getOtherDtls().getStopDateH());
                  pricingDtls.setF_STOP_DAT_G(priEngConf.getOtherDtls().getStopDateG());
                  if(priEngConf.getOtherDtls().getStopInd()) {
                      pricingDtls.setF_STOP_IND(1);
                  }else {
                      pricingDtls.setF_STOP_IND(0);
                  }
                  
                  pricingDtls.setF_RANK(priEngConf.getOtherDtls().getRank());
                  //input
                  pricingDtls.setF_LBL1_CD(priEngConf.getInputFieldsDtls().getAttr1ID());
                  pricingDtls.setF_LBL2_CD(priEngConf.getInputFieldsDtls().getAttr2ID());
                  pricingDtls.setF_LBL3_CD(priEngConf.getInputFieldsDtls().getAttr3ID());
                  pricingDtls.setF_LBL4_CD(priEngConf.getInputFieldsDtls().getAttr4ID());
                  pricingDtls.setF_LBL5_CD(priEngConf.getInputFieldsDtls().getAttr5ID());
                  
                  //rate
                  pricingDtls.setF_RAT1(priEngConf.getRateDetails().getRate1Value());
                  pricingDtls.setF_RAT1_LBL(priEngConf.getRateDetails().getRate1Desc());
                  pricingDtls.setF_RAT2(priEngConf.getRateDetails().getRate2Value());
                  pricingDtls.setF_RAT2_LBL(priEngConf.getRateDetails().getRate2Desc());
                  pricingDtls.setF_RAT3(priEngConf.getRateDetails().getRate3Value());
                  pricingDtls.setF_RAT3_LBL(priEngConf.getRateDetails().getRate3Desc());
                  pricingDtls.setF_RAT4(priEngConf.getRateDetails().getRate4Value());
                  pricingDtls.setF_RAT4_LBL(priEngConf.getRateDetails().getRate4Desc());
                  pricingDtls.setF_RAT5(priEngConf.getRateDetails().getRate5Value());
                  pricingDtls.setF_RAT5_LBL(priEngConf.getRateDetails().getRate5Desc());
                  pricingDtls.setF_RAT6(priEngConf.getRateDetails().getRate6Value());
                  pricingDtls.setF_RAT6_LBL(priEngConf.getRateDetails().getRate6Desc());
                  
                  //output
                  pricingDtls.setF_RES1_CD(priEngConf.getOutputFieldsDtls().getAttr6ID());
                  if(priEngConf.getOutputFieldsDtls().getAttr6ShowInReport()) {
                      pricingDtls.setF_RES1_SHOW(1);
                  }else {
                      pricingDtls.setF_RES1_SHOW(0);
                  }
                  
                  pricingDtls.setF_RES2_CD(priEngConf.getOutputFieldsDtls().getAttr7ID());
                  if(priEngConf.getOutputFieldsDtls().getAttr7ShowInReport()) {
                      pricingDtls.setF_RES2_SHOW(1);
                  }else {
                      pricingDtls.setF_RES2_SHOW(0);
                  }
                  
                  pricingDtls.setF_RES3_CD(priEngConf.getOutputFieldsDtls().getAttr8ID());
                  
                  if(priEngConf.getOutputFieldsDtls().getAttr8ShowInReport()) {
                      pricingDtls.setF_RES3_SHOW(1);
                  }else {
                      pricingDtls.setF_RES3_SHOW(0);
                  }
                  
                  pricingDtls.setF_RES4_CD(priEngConf.getOutputFieldsDtls().getAttr9ID());
                  
                  if(priEngConf.getOutputFieldsDtls().getAttr9ShowInReport()) {
                      pricingDtls.setF_RES4_SHOW(1);
                  }else {
                      pricingDtls.setF_RES4_SHOW(0);
                  }
                  
                  factory.create(IBOCE_IB_PricingEngineConfig.BONAME, pricingDtls);
                  Event raiseEvent = new Event();
                  raiseEvent.setEventNumber(44000349);
                  EventsHelper.handleEvent(raiseEvent, env);
                  //saving param and rate details
                  if(null != getF_IN_paramAndRateDtlsList() && getF_IN_paramAndRateDtlsList().getParamAndRateDtlsCount() > 0)
                  {
                	  String whereClause = "WHERE " + IBOCE_IB_PricingEngineRates.GRP_CDPK + " = ? AND "
                			  + IBOCE_IB_PricingEngineRates.TOOLNOPK + " = ? AND " 
                			  + IBOCE_IB_PricingEngineRates.LISTSERPK + " = ?";
                	  ArrayList deleteParams = new ArrayList<>();
                	  deleteParams.add(priEngConf.getGroupCD());
                	  deleteParams.add(priEngConf.getToolNo());
                	  deleteParams.add(priEngConf.getListser());
                	  factory.bulkDelete(IBOCE_IB_PricingEngineRates.BONAME, whereClause, deleteParams);
                	  for(ParamAndRateDtls paramRateDtl : getF_IN_paramAndRateDtlsList().getParamAndRateDtls())
                	  {
                		  IBOCE_IB_PricingEngineRates pricingEngineRate = (IBOCE_IB_PricingEngineRates) factory.getStatelessNewInstance(IBOCE_IB_PricingEngineRates.BONAME);
                		  CE_IB_PricingEngineRatesID engineRatesID = new CE_IB_PricingEngineRatesID();
                		  engineRatesID.setF_GRP_CD(priEngConf.getGroupCD());
                		  engineRatesID.setF_LISTSER(priEngConf.getListser());
                		  engineRatesID.setF_TOOLNO(priEngConf.getToolNo());
                		  engineRatesID.setF_PARM1(paramRateDtl.getParm1());
                		  engineRatesID.setF_PARM2(paramRateDtl.getParm2());
                		  engineRatesID.setF_PARM3(paramRateDtl.getParm3());
                		  pricingEngineRate.setF_PRAT1(paramRateDtl.getPrat1());
                		  pricingEngineRate.setF_PRAT2(paramRateDtl.getPrat2());
                		  pricingEngineRate.setF_PRAT3(paramRateDtl.getPrat3());
                		  pricingEngineRate.setF_PRAT4(paramRateDtl.getPrat4());
                		  pricingEngineRate.setF_PRAT5(paramRateDtl.getPrat5());
                		  pricingEngineRate.setCompositeBOID(engineRatesID);
                		  
                		  factory.create(IBOCE_IB_PricingEngineRates.BONAME, pricingEngineRate);
                		  
                	  }
                  }
                  
                  
                  
                  ListPricingEngine.addPricingEngineConfList(priEngConf);
            }
        }
        setF_OUT_ListPricingEngineConf(ListPricingEngine);
        setF_OUT_new(false);
        //setF_OUT_save(true);
    }
}
