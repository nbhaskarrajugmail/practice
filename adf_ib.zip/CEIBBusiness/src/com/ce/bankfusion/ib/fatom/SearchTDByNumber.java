package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SearchTDByNumber;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.PagingData;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.events.Event;

public class SearchTDByNumber extends AbstractCE_IB_SearchTDByNumber {

  private final StringBuilder titleDeedWhere1 = new StringBuilder(" WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS+" = ? AND  " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " LIKE ?");
	private static final Integer PAGE_SIZE = 10;
  private static final Integer PAGE_NO = 1;
  private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
  private Map<String, String> titleDeedSourceMap = null;
  private Map<String, String> titleDeedTypeMap = null;
  private static final String shareHolderWhere = " WHERE " + IBOCE_TITLEDEEDSHAREHOLDER.PARTYID+" = ? ";
  private static final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK+" LIKE ?" + " AND " + IBOCE_TITLEDEEDDETAILS.STATUS+" = ? AND "+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER+ " LIKE ?";
  private static final  String filterByParentWhere = " WHERE " + IBOCE_PARENTTITLEDEEDDTLS.TITLEDEEDID+" LIKE ?";
  private static final int TITLEDEED_NOT_ATTACHED_PARTYID = 44000018;
  
 
	public SearchTDByNumber() {
		super();
	}

	@SuppressWarnings("deprecation")
	public SearchTDByNumber(BankFusionEnvironment env) {

	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
	    
	   int pageSize = PAGE_SIZE;
	    int pageNo = getF_IN_searchTitleDeedDtlsByNumberRq().getPagedQuery().getPagingRequest().getRequestedPage();
	    IPagingData pagingData = null;

	    if (pageSize == 0)
	      pageSize = PAGE_SIZE;
	    if (pageNo == 0)
	      pageNo = PAGE_NO;

	      pagingData = new PagingData(pageNo, pageSize);
	      pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
	      this.fetchAllActiveTitleDeedDtls(pagingData, env);
	}

    private VectorTable fetchAllActiveTitleDeedDtls(IPagingData pagingData, BankFusionEnvironment env) {
       if( getF_IN_searchTitleDeedDtlsByNumberRq().getTitleDeedNumber().getScreenName().equals("linkTitleDeed")){
           String partyID = getF_IN_searchTitleDeedDtlsByNumberRq().getTitleDeedNumber().getPartyID();
           String titleDeedID = "";
          
           ArrayList<String> titleDeedParam = new ArrayList<String>();
           ArrayList<String> shareHolderParam = new ArrayList<String>();
           Boolean filterByParent = true;
           Boolean isSplitTd = true;
        List<IBOCE_TITLEDEEDDETAILS> TDList =  new ArrayList<>();
           SearchTitleDeedDtlsRsType searchTitleDeedRs = new SearchTitleDeedDtlsRsType();
           for(IBOCE_TITLEDEEDDETAILS listItem : TDList) {
               TDList.remove(listItem);
           }
           ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
           
           Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
           Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");
           Map<String,String> titleFarmLocationMap = PartyUtil.getGCMap("BRANCHNAME_FL");

           
           shareHolderParam.clear();
           shareHolderParam.add(partyID);
           List<IBOCE_TITLEDEEDSHAREHOLDER> shareHolderList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
               IBOCE_TITLEDEEDSHAREHOLDER.BONAME, shareHolderWhere, shareHolderParam, null, false);
           if(shareHolderList==null || shareHolderList.isEmpty() ) {
             raiseEvent(TITLEDEED_NOT_ATTACHED_PARTYID, env);
           }
           
           
           for (IBOCE_TITLEDEEDSHAREHOLDER shareHolderType : shareHolderList) {
             
              String titleDeedId = shareHolderType.getF_TITLEDEEDID();
              titleDeedParam.clear();
              titleDeedParam.add(titleDeedId);
              titleDeedParam.add("ACTIVE");
              String num = getF_IN_searchTitleDeedDtlsByNumberRq().getTitleDeedNumber().getTitleDeedNumber();
              titleDeedParam.add("%"+num+"%");
              List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
                           IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
               boolean select = true;
               //TDList;
               for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
                  TDList.add(titleDeedType);
                 TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
                 titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
                 CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
                 titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
                 titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
                 titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
                 titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
                 titleDeedDetailsType.setFarmLocationDescription(PartyUtil
                   .getFarmLocationDesc(titleDeedType.getF_FARMLOCATION(), titleDeedType.getF_BRANCHSORTCODE()));
                 titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
                 titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
                 titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
                 titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
                 titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
                 titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
                 titleDeedDetailsType.setSelect(select);
                 select = false;
                 titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
                 titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
                 titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
                 titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
                 titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
                 titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
                 titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
                 titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
                 titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
                 titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
                 titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
                 titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
                 titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
                 titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
                 titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
                 listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
               }
               
           }
           
           if(filterByParent) {
               ListTitleDeedIdDtlsType listTitleDeedIdDtlsTypeCopy = listTitleDeedIdDtlsType;
               ArrayList<String> filterParentParam = new ArrayList<String>();
               filterParentParam.add("%");
               List<IBOCE_PARENTTITLEDEEDDTLS> titleDeedParentList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
                   IBOCE_PARENTTITLEDEEDDTLS.BONAME, filterByParentWhere, filterParentParam, null, false);
                         for(TitleDeedDetailsType titleDeed : listTitleDeedIdDtlsTypeCopy.getTitleDeedDetails()) {
                       
                       for(IBOCE_PARENTTITLEDEEDDTLS parent : titleDeedParentList) {
                           if(parent.getF_TITLEDEEDID().equals(titleDeed.getTitleDeedIdpk())) {
                               for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
                                   if(parent.getF_TITLEDEEDNUMBER().equals(TD.getTitleDeedNumber())){
                                       //listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
                                       TDList= removeTitleDeedfromList(TDList,TD);
                                   }
                               }
                           }
                       }
                       
                   }
               }
           
           ListTitleDeedIdDtlsType listTDDtlsCopy = listTitleDeedIdDtlsType;
           for (TitleDeedDetailsType titleDeed : listTDDtlsCopy.getTitleDeedDetails()) {
             int titleDeedCount = 0;
             for (TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
               if (titleDeed.getTitleDeedIdpk().equals(TD.getTitleDeedIdpk())) {
                 titleDeedCount++;
               }
               if (titleDeedCount > 1) {

                 listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
                 TDList= removeTitleDeedfromList(TDList,TD);
                 titleDeedCount--;
               }

             }
           }
           
           if(isSplitTd) {
           ArrayList<String> filterSplitParam = new ArrayList<String>();
           String filterSplitWhere = " WHERE " + IBOCE_TITLEDEEDSPLITDTLS.TITLEDEEDID+" LIKE ?";
           filterSplitParam.add("%");
              List<IBOCE_TITLEDEEDSPLITDTLS> titleDeedSplitList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
                  IBOCE_TITLEDEEDSPLITDTLS.BONAME, filterSplitWhere, filterSplitParam, null, false);
              for(IBOCE_TITLEDEEDSPLITDTLS eachTdSplitDtl :titleDeedSplitList)
              {
                for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails())
                {
                  if(eachTdSplitDtl.getF_TITLEDEEDID().equals(TD.getTitleDeedIdpk()))
                  {
                    //listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
                    TDList= removeTitleDeedfromList(TDList,TD);
                  }
                }
              }
             
           }
           //searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
           //setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
          return createResponse(TDList, pagingData, null);
        }else {
        String allowedTitleDeedTypes = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
            CeConstants.TITLE_DEED_TYPES_CONF_FILE, CeConstants.TITLE_DEED_TYPES, "",
            CeConstants.ADFIBCONFIGLOCATION);
        int length = 0;
        if (allowedTitleDeedTypes != null && !allowedTitleDeedTypes.isEmpty()) {
          List<String> titleDeedTypeslist = IBCommonUtils.isNotEmpty(allowedTitleDeedTypes)
              ? Arrays.asList(allowedTitleDeedTypes.split(","))
              : new ArrayList<String>();
              length = titleDeedTypeslist.size();
        for (String titleDeedType : titleDeedTypeslist) {
            if(length ==  titleDeedTypeslist.size() ) {
                titleDeedWhere1.append(" AND (");
            }
            if(length == 1) {
                titleDeedWhere1.append( IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE+" = "+ titleDeedType + " )") ;
                length--;
            }else {
                titleDeedWhere1.append( IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE+" = "+ titleDeedType + " OR ") ;
                length--;
            }
            
          }
        }
        ArrayList<String> titleDeedParam = new ArrayList<String>();

        titleDeedParam.add("ACTIVE");
        String num = getF_IN_searchTitleDeedDtlsByNumberRq().getTitleDeedNumber().getTitleDeedNumber();
        titleDeedParam.add("%"+num+"%");
  List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
              IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere1.toString(), titleDeedParam, pagingData, false);

        return this.createResponse(titleDeedList, pagingData, null);
        }
    }

    private List<IBOCE_TITLEDEEDDETAILS> removeTitleDeedfromList(List<IBOCE_TITLEDEEDDETAILS> tDList, TitleDeedDetailsType tD) {

        List<IBOCE_TITLEDEEDDETAILS> list  = new ArrayList<>(tDList);

        for(IBOCE_TITLEDEEDDETAILS listItem : tDList) {
            CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) listItem.getCompositeBOID();
            if(titledeeddetailsid.getF_TITLEDEEDID().equals(tD.getTitleDeedIdpk())){
                list.remove(listItem);
                break;
            }
        }
        return list;
    }

    private VectorTable createResponse(List<IBOCE_TITLEDEEDDETAILS> titleDeedList, IPagingData pagingData, Object object) {
        VectorTable vectorTable = new VectorTable();

        ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
        SearchTitleDeedDtlsRsType searchTitleDeedRs = new SearchTitleDeedDtlsRsType();

        boolean select = false;

        if (titleDeedList != null) {
          for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
            this.prepareListTitleDeedIdDtlsType(listTitleDeedIdDtlsType, titleDeedType, select);
            select = false;
            Map<String, Object> map = this.prepareMap(titleDeedType);
            VectorTable newRow = new VectorTable(map);
            vectorTable.addAll(newRow);
          }
        } 

        PagedQuery pagedQuery = new PagedQuery();
        PagingRequest pagingRequest = new PagingRequest();
        pagingRequest.setNumberOfRows(pagingData.getPageSize());
        pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
        pagingRequest.setTotalPages(pagingData.getTotalPages());
        pagedQuery.setPagingRequest(pagingRequest);
        pagedQuery.setQueryData(listTitleDeedIdDtlsType);

        Object pageData[] = new Object[4];
        pageData[0] = pagingRequest.getRequestedPage();
        pageData[1] = pagingRequest.getNumberOfRows();
        pageData[2] = pagedQuery.getPagingRequest().getTotalPages();

        vectorTable.setPagingData(pageData);

        searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
        searchTitleDeedRs.setPagingInfo(pagedQuery);
        setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
        setF_OUT_PaginatedData(vectorTable);
        return vectorTable;
    }

    private Map<String, Object> prepareMap(IBOCE_TITLEDEEDDETAILS titleDeedType) {

        Map<String, Object> map = new HashMap<>();
        CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
        map.put("TITLEDEEDIDPK", titledeeddetailsid.getF_TITLEDEEDID());
        map.put("TITLEDEEDVERSIONPK", titledeeddetailsid.getF_TITLEDEEDVERSION());
        map.put("TITLEDEEDSTATUS", titleDeedType.getF_TITLEDEEDSTATUS());
        map.put("TRANSACTIONTYPE", titleDeedType.getF_TRANSACTIONTYPE());
        map.put("RECCREATEDBY", titleDeedType.getF_RECCREATEDBY());
        map.put("VALIDTO", titleDeedType.getF_VALIDTO());
        map.put("VERSIONNUM", titleDeedType.getVersionNum());
        map.put("NOTES", titleDeedType.getF_NOTES());
        map.put("VALIDTOHIJRI", titleDeedType.getF_VALIDTOHIJRI());
        map.put("NOTESFORAMEND", titleDeedType.getF_NOTESFORAMEND());
        map.put("LINKEDTOCOLLATERAL", titleDeedType.getF_LINKEDTOCOLLATERAL());
        map.put("STATUS", titleDeedType.getF_STATUS());
        map.put("RECLASTMODIFIEDBY", titleDeedType.getF_RECLASTMODIFIEDBY());
        map.put("TITLEDEEDYEAR", titleDeedType.getF_TITLEDEEDYEAR());
        map.put("TITLEDEEDNUMBER", titleDeedType.getF_TITLEDEEDNUMBER());
        map.put("RETAILINDEX", titleDeedType.getF_RETAILINDEX());
        map.put("VALIDFROMHIJRI", titleDeedType.getF_VALIDFROMHIJRI());
        map.put("REASONFORCHANGE", titleDeedType.getF_REASONFORCHANGE());
        map.put("LANDPLOTNUMBER", titleDeedType.getF_LANDPLOTNUMBER());
        map.put("RECSYSDATE", titleDeedType.getF_RECSYSDATE());
        map.put("DICISSIONSTATUS", titleDeedType.getF_DICISSIONSTATUS());
        map.put("RECAPPROVEDBY", titleDeedType.getF_RECAPPROVEDBY());
        map.put("RECCREATEDON", titleDeedType.getF_RECCREATEDON());
        map.put("TRANSACTIONDATE", titleDeedType.getF_TRANSACTIONDATE());
        map.put("VALIDFROM", titleDeedType.getF_VALIDFROM());
        map.put("RECLASTMODIFIEDDATE", titleDeedType.getF_RECLASTMODIFIEDDATE());
        map.put("FARMLOCATION", titleDeedType.getF_FARMLOCATION());
        map.put("RECAPPROVEDDATE", titleDeedType.getF_RECAPPROVEDDATE());
        map.put("SPLITINDICATOR", titleDeedType.getF_SPLITINDICATOR());
        map.put("LANDPLANNUMBER", titleDeedType.getF_LANDPLANNUMBER());
        map.put("SELECT", false);
        ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("TITLEDEEDTYPE");
        for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
            if (titleDeedType.getF_TITLEDEEDTYPE().equals(gcCode.getCodeReference())) {
                map.put("TITLEDEEDTYPE",gcCode.getCodeDescription());
                break;
            }
        }
        ListGenericCodeRs lsGenericSource = IBCommonUtils.getGCList("TITLEDEEDSOURCE");
        for (GcCodeDetail gcCode : lsGenericSource.getGcCodeDetails()) {
            if (titleDeedType.getF_TITLEDEEDSOURCE().equals(gcCode.getCodeReference())) {
                map.put("TITLEDEEDSOURCE", gcCode.getCodeDescription());
                break;
            }
        }
        map.put("AREASIZE", titleDeedType.getF_AREASIZE());
        map.put("CompositeBoid", titleDeedType.getCompositeBOID());
        return map;
      }

    private void prepareListTitleDeedIdDtlsType(ListTitleDeedIdDtlsType listTitleDeedIdDtlsType, IBOCE_TITLEDEEDDETAILS titleDeedType,
        boolean select) {
        TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
        titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
        CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
        titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
        titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
        titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
        titleDeedDetailsType.setFarmLocationDescription(PartyUtil
        .getFarmLocationDesc(titleDeedType.getF_FARMLOCATION(), titleDeedType.getF_BRANCHSORTCODE()));
        titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
        titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
        titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
        titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
        titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
        titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
        titleDeedDetailsType.setSelect(select);
        titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
        titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
        titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
        titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
        ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("TITLEDEEDTYPE");
        for (GcCodeDetail gcCode : lsGeneric.getGcCodeDetails()) {
            if (titleDeedType.getF_TITLEDEEDTYPE().equals(gcCode.getCodeReference())) {
                
                titleDeedDetailsType.setTitleDeedType(gcCode.getCodeDescription());
                break;
            }
        }
        ListGenericCodeRs lsGenericSource = IBCommonUtils.getGCList("TITLEDEEDSOURCE");
        for (GcCodeDetail gcCode : lsGenericSource.getGcCodeDetails()) {
            if (titleDeedType.getF_TITLEDEEDSOURCE().equals(gcCode.getCodeReference())) {
                titleDeedDetailsType.setTitleDeedSource(gcCode.getCodeDescription());
                break;
            }
        }

        titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
        titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
        titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
        titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
        titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
        titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
        titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
        titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
        titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
       
        listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
        
    }
    @Override
    public ActivityStepPagingState createActivityStepPagingState() {
      ActivityStepPagingState pagingState = super.createActivityStepPagingState();
      return pagingState;
    }

    @Override
    public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
        @SuppressWarnings("rawtypes") Map map) {

      VectorTable resultVector = new VectorTable();


      int pageSize = PAGE_SIZE;
      int pageNo = PAGE_NO;

      if (map.containsKey("PAGENO")) {
        pageNo = (Integer) map.get("PAGENO");
      }
      if (map.containsKey("NUMBEROFROWS")) {
        pageSize = (Integer) map.get("NUMBEROFROWS");
      }

      IPagingData pagingData = new PagingData(pageNo, pageSize);

      if (pagingData != null) {
        pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
        if (pagingData.getCurrentPageNumber() == 0)
          pagingData.setCurrentPageNumber(pageNo);
        if (pagingData.getPageSize() == 0)
          pagingData.setPageSize(pageSize);

        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);

        resultVector = this.fetchAllActiveTitleDeedDtls(pagingData, env);
      }
      return resultVector;
    }
    
    protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
        Event event = new Event();
        event.setEventNumber(eventNumer);
        EventsHelper eventsHelper = new EventsHelper();
        eventsHelper.handleEvent(event, env);
      }
}
