/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchTxnNationalIDMap;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_ManageRevereseButton;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.CustomerDueDetail;

/**
 * @author Aklesh
 *
 */
public class ManageRevereseButton extends AbstractCE_ADF_ManageRevereseButton {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String WHERE_CLAUSE = "WHERE " + IBOCE_ADF_BatchTxnNationalIDMap.LOANACCOUNTID + "=?";

	public ManageRevereseButton(BankFusionEnvironment env) {
		super(env);

	}

	public ManageRevereseButton() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		CustomerDueDetail customerDueDetails = getF_IN_customerDueDetails();
		String currentBatchRefernce = getF_IN_batchReference();
		// True means disable
		setF_OUT_enableDisableReverse(true);
		if (customerDueDetails.getTransactionID().isEmpty()) {
			setF_OUT_enableDisableReverse(true);
		} else {
			List<IBOCE_BATCHFILEDETAIL> batchFileList = new ArrayList<>();
			List<String> batchIDs = new ArrayList<>();
			ArrayList params = new ArrayList<>();
			params.add(customerDueDetails.getDealAccountID());
			List<IBOCE_ADF_BatchTxnNationalIDMap> nationalIDMaps = factory
					.findByQuery(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, WHERE_CLAUSE, params, null, true);
			if (nationalIDMaps != null && nationalIDMaps.size() > 2) {
				for (IBOCE_ADF_BatchTxnNationalIDMap nationalIDMap : nationalIDMaps) {
					batchIDs.add(nationalIDMap.getF_BATCHID());
				}
				for (String batchID : batchIDs) {
					IBOCE_BATCHTXNDETAIL batchTxn = (IBOCE_BATCHTXNDETAIL) factory.findByPrimaryKey(IBOCE_BATCHTXNDETAIL.BONAME, batchID, true);
					IBOCE_BATCHFILEDETAIL batchFile = (IBOCE_BATCHFILEDETAIL) factory.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, batchTxn.getF_BATCHREF(), true);
					batchFileList.add(batchFile);
				}
				batchFileList.sort((o1, o2) -> o1.getF_RECCREATEDON().compareTo(o2.getF_RECCREATEDON()));
				if (batchFileList.get(batchFileList.size() - 1).getF_BATCHREF().equals(currentBatchRefernce))
					setF_OUT_enableDisableReverse(false);
			}else {
				setF_OUT_enableDisableReverse(false);
			}
			setF_OUT_enableDisableFields(true);
		}
	}
}