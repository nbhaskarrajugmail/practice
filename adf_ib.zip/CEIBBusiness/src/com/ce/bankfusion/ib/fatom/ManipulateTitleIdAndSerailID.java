package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ManipulateTitleIdAndSerailID;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;

public class ManipulateTitleIdAndSerailID extends AbstractCE_IB_ManipulateTitleIdAndSerailID {

	private static final long serialVersionUID = 1L;

	public ManipulateTitleIdAndSerailID(BankFusionEnvironment env) {
		super(env);

	}

	public ManipulateTitleIdAndSerailID() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		TechnicalAreaDtl areaDtl= getF_IN_technicalAreaDtl();
		String titleDeedId=areaDtl.getTitleDeedId();
		setF_OUT_false(false);
		if(titleDeedId.equals(CommonConstants.EMPTY_STRING))
		{
			setF_OUT_resetSerialBoolean(true);
			//set new tag row for serial id
			TechnicalAreaCoordinateDtlList techCoordinate= new TechnicalAreaCoordinateDtlList();
			setF_OUT_techAreaAndCoordinateList(techCoordinate);
			setF_OUT_NEW("NEW");
		}
		else {
			TechnicalAreaCoordinateDtlList techCoordinate= new TechnicalAreaCoordinateDtlList();
			TechnicalAreaCoordinateDtlList hiddenTechCoordinate= getF_IN_hiddenTechAreaCoordinateDtls();
			setF_OUT_resetSerialBoolean(false);
			for (TechnicalAreaCoordinateDtl eachCoordinate : hiddenTechCoordinate.getTechnicalAreaCoordinateDtlList()) {
				if (eachCoordinate.getTitleDeedId().equals(titleDeedId)&& eachCoordinate.getReferenceNumber().equals(areaDtl.getReferenceNumber())) {
					TechnicalAreaCoordinateDtl coordinateDtl = new TechnicalAreaCoordinateDtl();
					coordinateDtl = eachCoordinate;

					techCoordinate.addTechnicalAreaCoordinateDtlList(coordinateDtl);
				}
			}
			
		
			setF_OUT_NEW("EXISTING");
			setF_OUT_techAreaAndCoordinateList(techCoordinate);
		}
	}
}
