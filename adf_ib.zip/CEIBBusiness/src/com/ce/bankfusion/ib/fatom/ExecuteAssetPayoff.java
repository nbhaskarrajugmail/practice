package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ExecuteAssetPayoff;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.calendar.functions.SubtractDateFromDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealClosureDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.CancelPayoffUtil;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.fatoms.PersistSurplusAccAndTxnDetails;
import com.trapedza.bankfusion.fatoms.ValidateAndWithdrawSurplusAmt;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.types.Currency;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.LoanDetails;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanDetailsInput;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRq;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRs;
import bf.com.misys.ib.types.EarlyAssetPayoffCollection;
import bf.com.misys.ib.types.EarlyAssetPayoffDtls;
import bf.com.misys.ib.types.FreqDtls;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.Term;
import bf.com.misys.ib.types.header.RqHeader;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class ExecuteAssetPayoff extends AbstractCE_IB_ExecuteAssetPayoff {

	private IBOIB_DLI_DealDetails dealDetails;
	private boolean businessDatePaymentAlreadyExists = false;
	private boolean isAssetPayOffProcess;
	private boolean isPostingSuccessfull;
	private boolean isScheduleUpdateSuccessfull;
	private ReadLoanDetailsRs readLoanDetails;
	private boolean isCompeleteDealSettlement;
	private LoanPayments businessDatePayment = null;
	private static final String dealRescheduleQuery = " WHERE " + IBOCE_IB_DealReschedule.IBDEALID + "=? " + " AND "
			+ IBOCE_IB_DealReschedule.IBRESCHEDULESTATUS + " = ? ORDER BY "
			+ IBOCE_IB_DealReschedule.IBRECLASTMODIFIEDDATE + " DESC ";
	private static final String dealAssetDtlsQuery = " WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " =?";
	private static final String closureDtlsQuery = " WHERE " + IBOIB_DLI_DealClosureDetails.DEALNO + " =? AND "
			+ IBOIB_DLI_DealClosureDetails.TRANSACTIONID + " =? ";
	
	private static final transient Log LOGGER = LogFactory.getLog(ExecuteAssetPayoff.class.getName());

	public ExecuteAssetPayoff(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		isAssetPayOffProcess = EarlyAssetPayoffUtils
				.isAssetPayOffProcess(getF_IN_islamicBankingObject().getSearchPageID());
		if (isAssetPayOffProcess
				|| (!isAssetPayOffProcess && (getF_IN_islamicBankingObject().getStepID().equals("RECALLAPPROVAL")
						|| (getF_IN_islamicBankingObject().getStepID().equals("RECALLREQUEST") && EarlyAssetPayoffUtils
								.execRuleForRecallProcess(getF_IN_islamicBankingObject().getDealID()))))) {
			LOGGER.info("isAssetpayoffProcess:" + isAssetPayOffProcess);
			dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
			EarlyAssetPayoffDtls assetPayoffDtls = getAssetPayOffDtls(env);
			readLoanDetails = IBCommonUtils.getLoanDetails(getF_IN_islamicBankingObject().getDealID());
			validateSurplusAmount(assetPayoffDtls);
			regenerateSchedule(readLoanDetails, assetPayoffDtls);
			boolean partialAssetPayOff = false;
			for (EarlyAssetPayoffCollection assetPayoffColl : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
				if (!assetPayoffColl.isSelect())
					partialAssetPayOff = true;
			}
			if(!partialAssetPayOff)
				readLoanDetails.getDealDetails().getLoanBasicDetails().setLoanMaturityDate(SystemInformationManager.getInstance().getBFBusinessDate());
			
			updateScheduleInHost(assetPayoffDtls, readLoanDetails, env);
			/*if (isAssetPayOffProcess && !isCompeleteDealSettlement)
				postManualCollection(readLoanDetails, assetPayoffDtls, env);*/
			updateStatus(assetPayoffDtls);
		}
	}

	private void validateSurplusAmount(EarlyAssetPayoffDtls assetPayoffDtls) {
		if (isAssetPayOffProcess && !IBCommonUtils.isNullOrEmpty(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID())) {
			Currency surplusAmount = RescheduleUtils.getSurplusAmount(
					readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID());
			LOGGER.info("Surplus Amount:" + surplusAmount.getAmount());
			LOGGER.info("Total Remaining Amount:" + assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
			if (IBCommonUtils.isNullOrEmpty(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum())) {
				String surplusAccount = CeUtils.getSurplusAccount(
						readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID());
				assetPayoffDtls.getEarlyAssetPayoffCollDtls().setInternalAccountNum(surplusAccount);
				LOGGER.info("Surplus Account:" + surplusAccount);
			}
			if (surplusAmount.getAmount().compareTo(
					assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()) < 0) {
				IBCommonUtils.raiseUnparameterizedEvent(44000361);
			}
		}
	}

	private void recallUpdateTables(EarlyAssetPayoffDtls assetPayoffDtls) {
		if (!isAssetPayOffProcess) {
			IBOCE_IB_FollowUpListConf followUpListConfObj = DealFollowUpUtils
					.getFollowUpConfObj(getF_IN_islamicBankingObject().getDealID());
			followUpListConfObj.setF_IBCURRENTFOLLOWUPSTATUS(CeConstants.FOLLOWUP_STATUS_NEGATIVE);
			followUpListConfObj.setF_IBLASTFOLLOWUPDATE(IBCommonUtils.getBFBusinessDate());
			followUpListConfObj.setF_IBINSPECTORNAME(CommonConstants.EMPTY_STRING);

			if (assetPayoffDtls != null && assetPayoffDtls.getEarlyAssetPayoffCollectionCount() > 0) {
				for (EarlyAssetPayoffCollection assetPayoffCollection : assetPayoffDtls
						.getEarlyAssetPayoffCollection()) {
					IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils.getPersistanceFactory()
							.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetPayoffCollection.getAssetId(), true);
					assetDetails.setF_STATUS(CeConstants.ASSETSTATUS_RECALL);
				}
			}
		}
	}

	private void regenerateSchedule(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls) {
		if (readLoanDetails != null) {
			LOGGER.info("Regenerate Schedule: Begin");
			HashMap<Date, BigDecimal> dateAndPrincipalAmountMap = new HashMap<>();
			HashMap<Date, BigDecimal> dateAndProfitAmountMap = new HashMap<>();

			// looping through the breakup schedule and preparing a map with date and amount
			// that has to be subtracted from original schedule
			getBreakUpSchedule(dateAndPrincipalAmountMap, dateAndProfitAmountMap, assetPayoffDtls);

			// looping through the date and amount map, and subtracting the amount from
			// original schedule
			removeAssetPayoffRepaymentAmounts(dateAndPrincipalAmountMap, dateAndProfitAmountMap, readLoanDetails);

			// add a new repayment with business date and with payment amount to the
			// original schedule
			addNewRepayment(readLoanDetails, assetPayoffDtls);
			LOGGER.info("Regenerate Schedule: End");
		}

	}

	private void updateScheduleInHost(EarlyAssetPayoffDtls assetPayoffDtls, ReadLoanDetailsRs readLoanDetails,
			BankFusionEnvironment env) {
		LOGGER.info("Update Schedule in host: Begin");
		/*isCompeleteDealSettlement = isCompleteDealSettlement(assetPayoffDtls);
		if (isCompeleteDealSettlement) {
			callRescheduleAPI(readLoanDetails, env);
			IBCommonUtils.getPersistanceFactory().commitTransaction();
			IBCommonUtils.getPersistanceFactory().beginTransaction();
			if (isScheduleUpdateSuccessfull) {
				// callEarlySettlementAPI
				addEntryIntoDealClosureDetails(assetPayoffDtls);
				HashMap<String, Object> inputMap = new HashMap<>();
				isScheduleUpdateSuccessfull = CancelPayoffUtil.callingCreateLoanPayoffSPI(
						getF_IN_islamicBankingObject(), inputMap, getF_IN_islamicBankingObject().getTransactionID());
				if (isScheduleUpdateSuccessfull) {
					ArrayList<String> param = new ArrayList<>();
					param.add(getF_IN_islamicBankingObject().getDealID());
					param.add(getF_IN_islamicBankingObject().getTransactionID());
					List<IBOIB_DLI_DealClosureDetails> closureDtls = (ArrayList<IBOIB_DLI_DealClosureDetails>) IBCommonUtils
							.getPersistanceFactory()
							.findByQuery(IBOIB_DLI_DealClosureDetails.BONAME, closureDtlsQuery, param, null, true);
					if (closureDtls != null)
						closureDtls.get(0).setF_STATUS("CLOSED");
				}
			}
		} else {*/
			callRescheduleAPI(readLoanDetails, env);
		//}
		LOGGER.info("Update Schedule in host: End");
	}

	private void callRescheduleAPI(ReadLoanDetailsRs readLoanDetails, BankFusionEnvironment env) {
		RescheduleLoanRq spiRescheduleLoanRq = convertScheduleDetailsToReschSPIType(readLoanDetails);
		HashMap<String, Object> param = new HashMap<>();
		param.clear();
		param.put(IBSPIConstants.SCH_AMENDMENT_MF_INPUT_PARAMNAME, spiRescheduleLoanRq);
		HashMap<String, Object> outputParams = MFExecuter.executeMF(IBSPIConstants.SCH_AMENDMENT_MFID, env, param);
		RescheduleLoanRs scheduleAmendRs = (RescheduleLoanRs) outputParams
				.get(IBSPIConstants.SCH_AMENDMENT_MF_OUTPUT_PARAMNAME);
		if (scheduleAmendRs != null && scheduleAmendRs.getRsHeader().getStatus().getOverallStatus().equals("S"))
			isScheduleUpdateSuccessfull = true;
	}

	private void addEntryIntoDealClosureDetails(EarlyAssetPayoffDtls assetPayoffDtls) {
		IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtl = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
				.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_EarlyAssetPayoffDtls.BONAME,
						getF_IN_islamicBankingObject().getTransactionID(), true);

		IBOIB_DLI_DealClosureDetails dealClosureDetails = (IBOIB_DLI_DealClosureDetails) IBCommonUtils
				.getPersistanceFactory().getStatelessNewInstance(IBOIB_DLI_DealClosureDetails.BONAME);
		dealClosureDetails.setF_ARREARFEE(readLoanDetails.getDealDetails().getLoanBasicDetails().getArrearFeeAmount());
		dealClosureDetails
				.setF_ARREARPRINCIPAL(readLoanDetails.getDealDetails().getLoanBasicDetails().getArrearPrincipalAmt());
		dealClosureDetails
				.setF_ARREARPROFIT(readLoanDetails.getDealDetails().getLoanBasicDetails().getArrearProfitAmt());
		dealClosureDetails.setF_CHECKSUM(readLoanDetails.getRsHeader().getChecksum());
		dealClosureDetails.setF_DEALNO(getF_IN_islamicBankingObject().getDealID());
		dealClosureDetails.setF_FEEAMOUNT(readLoanDetails.getDealDetails().getLoanBasicDetails().getFeeAmount());
		dealClosureDetails.setF_GIFTAMOUNT(BigDecimal.ZERO);
		dealClosureDetails.setF_GIFTPERCENTAGE(BigDecimal.ZERO);
		dealClosureDetails.setF_ISOCURRENCYCODE(getF_IN_islamicBankingObject().getCurrency());
		dealClosureDetails.setF_PAYMENTACCOUNTNO(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum());
		dealClosureDetails.setF_PAYMENTAMOUNT(
				assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
		dealClosureDetails.setF_PAYMENTMETHOD(IBConstants.PAYMENTMETHOD_TRF);
		dealClosureDetails.setF_PAYOFFAMOUNT(
				assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
		dealClosureDetails
				.setF_PRINCIPALAMOUNT(readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt());
		dealClosureDetails.setF_PROFITAMOUNT(readLoanDetails.getDealDetails().getLoanBasicDetails().getProfitAmt());
		dealClosureDetails.setF_RECAPPROVEDBY(assetPayoffDtl.getF_IBRECAPPROVEDBY());
		dealClosureDetails.setF_RECAPPROVEDDATE(assetPayoffDtl.getF_IBRECAPPROVEDDATE());
		dealClosureDetails.setF_RECCREATEDBY(assetPayoffDtl.getF_IBRECCREATEDBY());
		dealClosureDetails.setF_RECCREATEDON(assetPayoffDtl.getF_IBRECCREATEDON());
		dealClosureDetails.setF_RECLASTMODIFIEDBY(assetPayoffDtl.getF_IBRECLASTMODIFIEDBY());
		dealClosureDetails.setF_RECLASTMODIFIEDDATE(assetPayoffDtl.getF_IBRECLASTMODIFIEDDATE());
		dealClosureDetails.setF_RECSYSDATE(IBCommonUtils.getBFSystemDateTime());
		dealClosureDetails.setF_REMAININGINSTALLMENTS(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getRemainingNoOfPayments());
		dealClosureDetails
				.setF_REMUNPAIDFEES(readLoanDetails.getDealDetails().getLoanBasicDetails().getOustandingFeeAmount());
		dealClosureDetails.setF_REMUNPAIDPRINCIPAL(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt());
		dealClosureDetails
				.setF_REMUNPAIDPROFIT(readLoanDetails.getDealDetails().getLoanBasicDetails().getOustandingProfitAmt());
		dealClosureDetails
				.setF_TOTALDEALAMOUNT(readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalDealAmount());
		dealClosureDetails.setF_TOTALDISBURSEMENTAMOUNT(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount());
		dealClosureDetails.setF_TOTALNOOFINSTALLMENTS(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalNoOfPayments());
		dealClosureDetails.setF_TOTALUNDISBURSEMENTAMOUNT(
				readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt()
						.subtract(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()));
		dealClosureDetails.setF_TRANSACTIONID(getF_IN_islamicBankingObject().getTransactionID());
		dealClosureDetails.setF_TRANSACTIONTYPE("EARLYSETTLEMENT");
		dealClosureDetails.setF_VALUEDATE(IBCommonUtils.getBFBusinessDate());
		IBCommonUtils.getPersistanceFactory().create(IBOIB_DLI_DealClosureDetails.BONAME, dealClosureDetails);
	}

	private boolean isCompleteDealSettlement(EarlyAssetPayoffDtls assetPayoffDtls) {
		int selectedAssetCount = 0;
		int leftOverAssetCount = 0;
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = (ArrayList<IBOIB_DLI_DealAssetDtls>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, dealAssetDtlsQuery, param, null, true);

		for (EarlyAssetPayoffCollection assetPayoffColl : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
			if (assetPayoffColl.isSelect())
				++selectedAssetCount;
		}
		if (dealAssetDtls != null && !dealAssetDtls.isEmpty()) {
			for (IBOIB_DLI_DealAssetDtls assetDtls : dealAssetDtls) {
				IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetDtls.getF_ASSETDETAILSID(), true);
				if (assetDetails != null && !assetDetails.getF_STATUS().equals(CeConstants.ASSETSTATUS_EARLYPAIDOFF)
						&& !assetDetails.getF_STATUS().equals(CeConstants.ASSETSTATUS_RECALL)) {
					++leftOverAssetCount;
				}
			}
		}
		if (selectedAssetCount == leftOverAssetCount)
			return true;
		return false;
	}

	private void adjustPaymentScheduleInBreakUp(IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtlsObj,
			EarlyAssetPayoffDtls assetPayoffDtls) {
		String[] assetIds = assetPayoffDtlsObj.getF_IBASSETIDS().split("\\|");
		String paymentSchBreakupQuery = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " =?  AND "
				+ IBOCE_IB_PaymentSchBreakup.IBASSETID + "=? AND " + IBOCE_IB_PaymentSchBreakup.IBPRINCIPALAMTPAID
				+ "= ? AND " + IBOCE_IB_PaymentSchBreakup.IBSUBSIDYAMTPAID + "= ?";
		List assetIdList = Arrays.asList(assetIds);
		if (assetIdList != null && !assetIdList.isEmpty()) {
			Iterator<String> iterator = assetIdList.iterator();
			ArrayList params = new ArrayList<>();
			while (iterator.hasNext()) {
				String assetId = iterator.next();
				params.clear();
				params.add(getF_IN_islamicBankingObject().getDealID());
				params.add(assetId);
				params.add(BigDecimal.ZERO);
				params.add(BigDecimal.ZERO);
				IBCommonUtils.getPersistanceFactory().bulkDelete(IBOCE_IB_PaymentSchBreakup.BONAME,
						paymentSchBreakupQuery, params);
			}
		}

		// adding new repayment entries
		if (assetPayoffDtls != null && assetPayoffDtls.getEarlyAssetPayoffCollectionCount() > 0) {
			for (EarlyAssetPayoffCollection assetPayoffCollection : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
				if (assetPayoffCollection.isSelect()) {
					IBOCE_IB_PaymentSchBreakup paymentSchBreakup = (IBOCE_IB_PaymentSchBreakup) IBCommonUtils
							.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentSchBreakup.BONAME);
					paymentSchBreakup.setBoID(IBCommonUtils.getNewGUID());
					paymentSchBreakup.setF_IBASSETID(assetPayoffCollection.getAssetId());
					paymentSchBreakup.setF_IBBILLDATE(null != businessDatePayment ? businessDatePayment.getRepaymentDate()
							: IBCommonUtils.getBFBusinessDate());
					paymentSchBreakup.setF_IBDEALID(getF_IN_islamicBankingObject().getDealID());
					paymentSchBreakup.setF_IBPRINCIPALAMT(
							assetPayoffCollection.getRemainingAssetCostToBeCollected().getCurrencyAmount());
					paymentSchBreakup.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
					paymentSchBreakup.setF_IBPROFITAMT(
							assetPayoffCollection.getRemainingProfitAmntToBeCollected().getCurrencyAmount());
					paymentSchBreakup.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
					paymentSchBreakup.setF_IBSCHEDULEFEEAMT(
							assetPayoffCollection.getRemainingFeesAmntToBeCollected().getCurrencyAmount());
					paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
					paymentSchBreakup.setF_IBSUBSIDYAMNT(BigDecimal.ZERO);
					paymentSchBreakup.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
					/*if (isAssetPayOffProcess) {
						paymentSchBreakup.setF_IBPRINCIPALAMTPAID(
								assetPayoffCollection.getRemainingAssetCostToBeCollected().getCurrencyAmount());
						paymentSchBreakup.setF_IBPROFITAMTPAID(
								assetPayoffCollection.getRemainingProfitAmntToBeCollected().getCurrencyAmount());
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(
								assetPayoffCollection.getRemainingFeesAmntToBeCollected().getCurrencyAmount());
					}*/
					IBCommonUtils.getPersistanceFactory().create(IBOCE_IB_PaymentSchBreakup.BONAME, paymentSchBreakup);
				}
			}
		}
	}

	private void updateStatus(EarlyAssetPayoffDtls assetPayoffDtls) {
		LOGGER.info("isScheduleUpdateSuccessfull " + isScheduleUpdateSuccessfull);
		LOGGER.info("Update Status: Begin");
		if (isScheduleUpdateSuccessfull) {
			IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtlsObj = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
					.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_EarlyAssetPayoffDtls.BONAME,
							getF_IN_islamicBankingObject().getTransactionID(), true);
			if (assetPayoffDtlsObj != null) {
				assetPayoffDtlsObj.setF_IBSTATUS(CeConstants.ASSET_PAYOFF_STATUS_COMPLETED);
				assetPayoffDtlsObj.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
				assetPayoffDtlsObj.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
				assetPayoffDtlsObj.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
				assetPayoffDtlsObj
						.setF_IBACCOUNTNUMBER(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum());
				adjustPaymentScheduleInBreakUp(assetPayoffDtlsObj, assetPayoffDtls);
				adjustScheduleFeesInReschedule(assetPayoffDtls);
			}

			if (assetPayoffDtls != null && assetPayoffDtls.getEarlyAssetPayoffCollectionCount() > 0) {
				for (EarlyAssetPayoffCollection payoffCollection : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
					if (payoffCollection.getSelect()) {
						IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) IBCommonUtils
								.getPersistanceFactory()
								.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, payoffCollection.getAssetId(), true);
						if (isAssetPayOffProcess)
							assetDetails.setF_STATUS(CeConstants.ASSETSTATUS_EARLYPAIDOFF);
						else
							assetDetails.setF_STATUS(CeConstants.ASSETSTATUS_RECALL);
					}
				}
			}
			if (!isAssetPayOffProcess) {
				IBOCE_IB_FollowUpListConf followUpListConfObj = DealFollowUpUtils
						.getFollowUpConfObj(getF_IN_islamicBankingObject().getDealID());
				followUpListConfObj.setF_IBCURRENTFOLLOWUPSTATUS(CeConstants.FOLLOWUP_STATUS_NEGATIVE);
				followUpListConfObj.setF_IBLASTFOLLOWUPDATE(IBCommonUtils.getBFBusinessDate());
				followUpListConfObj.setF_IBINSPECTORNAME(CommonConstants.EMPTY_STRING);
			}
			ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(getF_IN_islamicBankingObject().getDealID());
			if (isAssetPayOffProcess) {
				IBOIB_DLI_DealDetails dealDetails = IBCommonUtils
						.getDealDetails(getF_IN_islamicBankingObject().getDealID());
				if (dealDetails != null) {
					dealDetails.setF_ProfitAmt(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getProfitAmt());
					dealDetails.setF_DealAmt(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getOriginalDealAmount());
				}
			}
			IBOIB_DLI_ScheduleProfile scheduleProfile = IBCommonUtils.getScheduleProfileOfRepaymentType(getF_IN_islamicBankingObject().getDealID());
			if(scheduleProfile != null) {
				scheduleProfile.setF_CALCULATEDPROFIT(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getProfitAmt());
				scheduleProfile.setF_NoOfPayments(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalNoOfPayments());
				scheduleProfile.setF_ProfitPaymentAMT(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getProfitAmt());
			}
			if (!isAssetPayOffProcess) 
				updateInvoices(readLoanDetailsRs, dealDetails);
		}
		LOGGER.info("Update Status: End");
	}
	private void updateInvoices(ReadLoanDetailsRs readLoanAfterReschedule, IBOIB_DLI_DealDetails dealDetails) {
    	LOGGER.info("Entering into updateArrearAndPartiallyPaidInvoices method deal Id ==>" + dealDetails.getBoID());
    	List<Date> invoiceUpdateDatesList = new ArrayList<Date>();
    	//For current BD repaymentdate
    	for (LoanPayments loanPayment : readLoanAfterReschedule.getDealDetails().getPaymentSchedule()) {
	    	if((null != businessDatePayment && CalendarUtil.IsDate1EqualsToDate2(businessDatePayment.getRepaymentDate(),loanPayment.getRepaymentDate()))
	    			|| (CalendarUtil.IsDate1GreaterThanDate2(RescheduleUtils.getPaymentDateForInvoiceGeneration(),loanPayment.getRepaymentDate())
	    			&& !CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getCurrentBusinessDate(),loanPayment.getRepaymentDate())))
	        {
	        	invoiceUpdateDatesList.add(loanPayment.getRepaymentDate());
	        }
    	}
    	SadadPaymentUtils.updateInvoiceForRepayment(dealDetails.getBoID(), dealDetails.getF_DealAccountId(), invoiceUpdateDatesList);
    	LOGGER.info("Exiting from updateArrearAndPartiallyPaidInvoices method deal Id ==>" + dealDetails.getBoID());
		
	}
	private void adjustScheduleFeesInReschedule(EarlyAssetPayoffDtls assetPayoffDtls) {
		if (isAssetPayOffProcess) {
			BigDecimal rescheduleFeesToBeCorrected = BigDecimal.ZERO;
			if (assetPayoffDtls != null && assetPayoffDtls.getEarlyAssetPayoffCollectionCount() > 0) {
				for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : assetPayoffDtls
						.getEarlyAssetPayoffCollection()) {
					if (earlyAssetPayoffCollection.isSelect()) {
						rescheduleFeesToBeCorrected = rescheduleFeesToBeCorrected
								.add(earlyAssetPayoffCollection.getWaivedOffScheduleFeesAmnt().getCurrencyAmount());
					}
				}
			}
			LOGGER.info("Inside adjustScheduleFeesInReschedule , rescheduleFeesToBeCorrected" +rescheduleFeesToBeCorrected);
			if (rescheduleFeesToBeCorrected.compareTo(BigDecimal.ZERO) > 0) {
				if (!IBCommonUtils.isNullOrEmpty(getF_IN_islamicBankingObject().getDealID())) {
					ArrayList<Object> params = new ArrayList<>();
					params.add(getF_IN_islamicBankingObject().getDealID());
					params.add(RescheduleConstants.STATUS_COMPLETED);

					List<IBOCE_IB_DealReschedule> dealRescheduleDtls = BankFusionThreadLocal.getPersistanceFactory()
							.findByQuery(IBOCE_IB_DealReschedule.BONAME, dealRescheduleQuery, params, null, false);
					if (!dealRescheduleDtls.isEmpty()) {
						for (IBOCE_IB_DealReschedule dealReschedule : dealRescheduleDtls) {
							if (rescheduleFeesToBeCorrected.compareTo(dealReschedule.getF_IBSCHEDULEFEES()) > 0) {
								dealReschedule.setF_IBSCHEDULEFEES(BigDecimal.ZERO);
							}
							rescheduleFeesToBeCorrected = rescheduleFeesToBeCorrected
									.subtract(dealReschedule.getF_IBSCHEDULEFEES());
						}
					}
				}
			}
		}

	}

	private RescheduleLoanRq convertScheduleDetailsToReschSPIType(ReadLoanDetailsRs readLoanDetails) {

		ProductConfiguration productConfiguration = IBCommonUtils
				.loadProductConfiguration(getF_IN_islamicBankingObject().getDealID());

		RescheduleLoanRq spiRescheduleLoanRq = new RescheduleLoanRq();
		RescheduleLoanDetailsInput rescheduleLoanDetailsInput = new RescheduleLoanDetailsInput();
		LoanDetails loanDetails = new LoanDetails();
		loanDetails.setDealBranch(dealDetails.getF_BranchSortCode());
		loanDetails.setDealCurrency(dealDetails.getF_IsoCurrencyCode());
		loanDetails.setDealID(dealDetails.getBoID());
		loanDetails.setLoanAccountNo(dealDetails.getF_DealAccountId());
		loanDetails.setIsHostScheduleGenerator(productConfiguration.getIsHostScheduleGenerator());
		loanDetails.setProductID(dealDetails.getF_ProductCode());
		loanDetails.setSubProductID(dealDetails.getF_ProductContextCode());
		loanDetails.setRepaymentType("REPAYMENT");
		loanDetails.setPaymentStartDate(IBCommonUtils.getBFBusinessDate());
		loanDetails.setEffectiveDate(dealDetails.getF_DEALEFFECTIVEDT());
		loanDetails.setMarginRate(dealDetails.getF_ProfitRate());
		loanDetails.setNoOfPayments(readLoanDetails.getDealDetails().getPaymentScheduleCount());
		loanDetails.setProfitRate(dealDetails.getF_ProfitRate());
		loanDetails.setScheduleEffectiveDate(SystemInformationManager.getInstance().getBFBusinessDate());
		loanDetails.setFirstAmountCanDiffer(false);

		String scheduleProfile = " WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOIB_DLI_ScheduleProfile> scheduleProfileList = null;
		scheduleProfileList = IBCommonUtils.getPersistanceFactory().findByQuery(IBOIB_DLI_ScheduleProfile.BONAME,
				scheduleProfile, params, null, false);
		if (scheduleProfileList != null) {
			for (IBOIB_DLI_ScheduleProfile profileRec : scheduleProfileList)
				if (profileRec.getF_ScheduleType().equals("Repayment")) {
					FreqDtls paymentFreq = new FreqDtls();
					paymentFreq.setFrequencyCode(profileRec.getF_FreqCode());
					paymentFreq.setFrequencyDay(ScheduleUtils.getRepaymentDay(dealDetails.getF_FirstRepaymentDate(),
							dealDetails.getF_RepayFreqcode()));
					paymentFreq.setFrequencyNum(profileRec.getF_FreqUnit());
					loanDetails.setPaymentFreq(paymentFreq);
				}
		}

		Term loanTerm = new Term();
		loanTerm.setPeriodNumber(SubtractDateFromDate.run(
				dealDetails.getF_LastRepaymentDate() != null ? dealDetails.getF_LastRepaymentDate() : new Date(0),
				dealDetails.getF_DEALEFFECTIVEDT() != null ? dealDetails.getF_DEALEFFECTIVEDT() : new Date(0)));
		loanTerm.setPeriodCode(DealInitiationConstants.TERM_DAY);
		loanDetails.setLoanTerm(loanTerm);

		rescheduleLoanDetailsInput.setLoanDetails(loanDetails);
		rescheduleLoanDetailsInput.setManualPaymentSchedule(readLoanDetails.getDealDetails().getPaymentSchedule());

		spiRescheduleLoanRq.setRescheduleLoanDetailsInput(rescheduleLoanDetailsInput);

		RqHeader rqHeader = new RqHeader();
		spiRescheduleLoanRq.setRqHeader(rqHeader);
		return spiRescheduleLoanRq;
	}

	private void addNewRepayment(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls) {
		if (readLoanDetails != null && assetPayoffDtls != null) {
			LOGGER.info("inside addNewRepayment : Begin");
			LOGGER.info("businessDatePaymentAlreadyExists"+businessDatePaymentAlreadyExists);
			BigDecimal profitAmount = assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingProfitAmount()
					.getCurrencyAmount().add(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingFeesAmount()
							.getCurrencyAmount());
			String status = CommonConstants.EMPTY_STRING;
			if(businessDatePayment != null)
			 status = businessDatePayment.getRepaymentStatus();
			// if there is already a business date repayment which is UNPAID in the
			// schedule, then add the
			// total remaining amount to the principal amount
			if (businessDatePaymentAlreadyExists
					&& !IBCommonUtils.isNullOrEmpty(status) && status.equals(IBConstants.REPAYMENT_STATUS_UNPAID)) {
				businessDatePayment.setPrincipleAmt(businessDatePayment.getPrincipleAmt().add(assetPayoffDtls
						.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment
						.setPrincipalAmtUnpaid(businessDatePayment.getPrincipalAmtUnpaid().add(assetPayoffDtls
								.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment.setProfitAmt(businessDatePayment.getProfitAmt().add(profitAmount));
				businessDatePayment.setProfitAmtUnpaid(businessDatePayment.getProfitAmtUnpaid().add(profitAmount));
				businessDatePayment.setRepaymentAmt(businessDatePayment.getRepaymentAmt().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
				businessDatePayment.setRepaymentAmtUnPaid(businessDatePayment.getRepaymentAmtUnPaid().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
			}
			// if there is no business date repayment exists in the current schedule, then
			// add a new repayment
			else {

				businessDatePayment = new LoanPayments();
				businessDatePayment.setIsoCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				businessDatePayment.setFeeAmt(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtUnpaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtUnpaid(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setPrincipleAmt(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setProfitAmt(profitAmount);
				businessDatePayment.setProfitAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setProfitAmtUnpaid(profitAmount);
				businessDatePayment.setProfitRate(dealDetails.getF_ProfitRate());
				businessDatePayment.setRepaymentAmt(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				businessDatePayment.setRepaymentAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setRepaymentAmtUnPaid(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				if (businessDatePaymentAlreadyExists
						&& !IBCommonUtils.isNullOrEmpty(status) && !status.equals(IBConstants.REPAYMENT_STATUS_UNPAID))
					businessDatePayment.setRepaymentDate(
							AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(), 1));
				else
					businessDatePayment.setRepaymentDate(IBCommonUtils.getBFBusinessDate());
				businessDatePayment.setRepaymentStatus(IBConstants.REPAYMENT_STATUS_UNPAID);
				businessDatePayment.setRepaymentType(IBConstants.REPAYMENT);
				readLoanDetails.getDealDetails().addPaymentSchedule(businessDatePayment);
			}
			int hj=0;
			List<LoanPayments> paymentScheduleList = Arrays
					.asList(readLoanDetails.getDealDetails().getPaymentSchedule());

			CeUtils.sortPaymentSchedule(paymentScheduleList);
			readLoanDetails.getDealDetails().removeAllPaymentSchedule();
			for (LoanPayments loanPayments : paymentScheduleList) {
				readLoanDetails.getDealDetails().addPaymentSchedule(loanPayments);
			}
			// outstanding amounts are not required to be set for reschedule
			setOutStandingPrincipalAmnt(readLoanDetails);
		}
	}

	private void setOutStandingPrincipalAmnt(ReadLoanDetailsRs readLoanDetails) {
		int repaymentNo = 0;
		BigDecimal outStandingPrincipalAmnt = readLoanDetails.getDealDetails().getLoanBasicDetails()
				.getOriginalPrincipalAmt();
		for (LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
			++repaymentNo;
			/*
			 * if (!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
			 * loanPayments.getRepaymentDate())) {
			 */
			// loanPayments.setRepaymentNo(repaymentNo);
			loanPayments.setOutstandingPrincipalAmt(outStandingPrincipalAmnt.subtract(loanPayments.getPrincipleAmt()));
			loanPayments.setRepaymentAmt(loanPayments.getPrincipleAmt().add(loanPayments.getProfitAmt()));
			// }
			outStandingPrincipalAmnt = loanPayments.getOutstandingPrincipalAmt();

			/*
			 * if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
			 * loanPayments.getRepaymentDate()))
			 * readLoanDetails.getDealDetails().removePaymentSchedule(loanPayments);
			 */
		}
	}

	private void removeAssetPayoffRepaymentAmounts(HashMap<Date, BigDecimal> dateAndPrincipalAmountMap,
			HashMap<Date, BigDecimal> dateAndProfitAmountMap, ReadLoanDetailsRs readLoanDetails) {
		if (readLoanDetails != null) {
			for (LoanPayments loanPayment : readLoanDetails.getDealDetails().getPaymentSchedule()) {
				if (dateAndPrincipalAmountMap.containsKey(loanPayment.getRepaymentDate())
						&& !loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_FULLY_PAID)) {
					loanPayment.setPrincipleAmt(loanPayment.getPrincipleAmt()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setPrincipalAmtUnpaid(loanPayment.getPrincipalAmtUnpaid()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setProfitAmt(loanPayment.getProfitAmt()
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setProfitAmtUnpaid(loanPayment.getProfitAmtUnpaid()
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
					loanPayment.setRepaymentAmt(loanPayment.getPrincipleAmt().add(loanPayment.getProfitAmt()));
					loanPayment.setRepaymentAmtUnPaid(loanPayment.getRepaymentAmtUnPaid()
							.subtract(dateAndPrincipalAmountMap.get(loanPayment.getRepaymentDate()))
							.subtract(dateAndProfitAmountMap.get(loanPayment.getRepaymentDate())));
				}
				loanPayment.setRepaymentType(IBConstants.REPAYMENT);
				loanPayment.setProfitRate(dealDetails.getF_ProfitRate());
				// while subtracting the asset that is getting payed off, if the repayment
				// amount becomes zero, removing the payment
				if (loanPayment.getPrincipleAmt().compareTo(BigDecimal.ZERO) == 0
						|| loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_FULLY_PAID)
						|| loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_PARTIALLY_PAID))
					readLoanDetails.getDealDetails().removePaymentSchedule(loanPayment);
				if (CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
						loanPayment.getRepaymentDate())) {
					businessDatePaymentAlreadyExists = true;
					businessDatePayment = loanPayment;
				}
			}
		}

	}

	private void getBreakUpSchedule(HashMap<Date, BigDecimal> dateAndPrincipalAmountMap,
			HashMap<Date, BigDecimal> dateAndProfitAmountMap, EarlyAssetPayoffDtls assetPayoffDtls) {
		BigDecimal totalPrincipalAmnt = BigDecimal.ZERO;
		BigDecimal totalProfitAmnt = BigDecimal.ZERO;
		String whereQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " =?";
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_PaymentSchBreakup> paymentScheduleBreakupDtls = (ArrayList<IBOCE_IB_PaymentSchBreakup>) IBCommonUtils
				.getPersistanceFactory().findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereQuery, param, null, true);

		if (paymentScheduleBreakupDtls != null && !paymentScheduleBreakupDtls.isEmpty()) {
			for (EarlyAssetPayoffCollection assetPayoffCollection : assetPayoffDtls.getEarlyAssetPayoffCollection()) {
				for (int i = 0; i < paymentScheduleBreakupDtls.size(); i++) {
					IBOCE_IB_PaymentSchBreakup paymentSchBreakup = paymentScheduleBreakupDtls.get(i);
					if (assetPayoffCollection.isSelect()
							&& paymentSchBreakup.getF_IBASSETID().equals(assetPayoffCollection.getAssetId())
							&& CalendarUtil.IsDate1GreaterThanDate2(paymentSchBreakup.getF_IBBILLDATE(),
									IBCommonUtils.getBFBusinessDate())) {
						totalPrincipalAmnt = paymentSchBreakup.getF_IBPRINCIPALAMT();
						totalProfitAmnt = paymentSchBreakup.getF_IBPROFITAMT()
								.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						if (dateAndPrincipalAmountMap.containsKey(paymentSchBreakup.getF_IBBILLDATE())) {
							totalPrincipalAmnt = dateAndPrincipalAmountMap.get(paymentSchBreakup.getF_IBBILLDATE())
									.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
						}
						if (dateAndProfitAmountMap.containsKey(paymentSchBreakup.getF_IBBILLDATE())) {
							totalProfitAmnt = dateAndProfitAmountMap.get(paymentSchBreakup.getF_IBBILLDATE())
									.add(paymentSchBreakup.getF_IBPROFITAMT()
											.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
						}
						dateAndPrincipalAmountMap.put(paymentSchBreakup.getF_IBBILLDATE(), totalPrincipalAmnt);
						dateAndProfitAmountMap.put(paymentSchBreakup.getF_IBBILLDATE(), totalProfitAmnt);
					}
				}
			}
		}
	}

	private EarlyAssetPayoffDtls getAssetPayOffDtls(BankFusionEnvironment env) {
		GetAssetPayOffDtls assetPayOffDtls = new GetAssetPayOffDtls(env);
		assetPayOffDtls.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		assetPayOffDtls.setF_IN_mode(CeConstants.INPUT_MODE_LOAD);
		assetPayOffDtls.process(env);
		return assetPayOffDtls.getF_OUT_earlyAssetPayoffDtls();
	}

	private void postManualCollection(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls,
			BankFusionEnvironment env) {
		
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
		String status = CommonConstants.EMPTY_STRING;
		ValidateAndWithdrawSurplusAmt validateAndWithdrawSurplusAmt = new ValidateAndWithdrawSurplusAmt(env);
		validateAndWithdrawSurplusAmt.setF_IN_accounntId(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum());
		validateAndWithdrawSurplusAmt.setF_IN_isAPICallForSurplusWithdrawal(true);
		validateAndWithdrawSurplusAmt.setF_IN_isValidateOnly(false);
		//validateAndWithdrawSurplusAmt.setF_IN_paymentAccCash(param);
		//validateAndWithdrawSurplusAmt.setF_IN_paymentAccCheque(param);
		//validateAndWithdrawSurplusAmt.setF_IN_paymentAccDD(param);
		validateAndWithdrawSurplusAmt.setF_IN_paymentAccTransfer(dealDtls.getF_DealAccountId());
		validateAndWithdrawSurplusAmt.setF_IN_paymentMode("2286");
		validateAndWithdrawSurplusAmt.setF_IN_surplusWithdrawAmount(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount());
		validateAndWithdrawSurplusAmt.process(env);
		status=validateAndWithdrawSurplusAmt.getF_OUT_status();
        if(status=="S")
        {
            PersistSurplusAccAndTxnDetails accAndTxnDetails= new PersistSurplusAccAndTxnDetails(env);
            accAndTxnDetails.setF_IN_accountId(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum());
            accAndTxnDetails.setF_IN_withdrawalTrue(true);
            accAndTxnDetails.setF_IN_paymentAccount(dealDtls.getF_DealAccountId());
           
            accAndTxnDetails.setF_IN_paymentMode("2286");
            accAndTxnDetails.setF_IN_surplusAmt(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount());
            accAndTxnDetails.setF_IN_surplusAccount(validateAndWithdrawSurplusAmt.getF_OUT_surplusAccount());
            accAndTxnDetails.setF_IN_reasonOfWithdrawal("");
            accAndTxnDetails.process(env);
        }
		
		/*
		DealIDInput dealIdInput = new DealIDInput();
		dealIdInput.setDealID(getF_IN_islamicBankingObject().getDealID());
		dealIdInput.setDealBranch(dealDtls.getF_BranchSortCode());
		dealIdInput.setSubProductID(dealDtls.getF_ProductContextCode());

		AccountInput collectionAccountInput = new AccountInput();
		collectionAccountInput.setAccountID(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum());
		collectionAccountInput.setAccountFormatType(IBCommonUtils
				.getAccountFormatType(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getInternalAccountNum()));

		AccountInput dealAccountInput = new AccountInput();
		dealAccountInput.setAccountID(dealDtls.getF_DealAccountId());
		dealAccountInput.setAccountFormatType(CeConstants.ACC_FORMAT_TYPE_STA);

		RqHeader rqHeader = new RqHeader();
		rqHeader.setMode(CeConstants.CONST_UPDATE);
		rqHeader.setChecksum(CommonConstants.EMPTY_STRING);

		HashMap<String, Object> inputParams = new HashMap<>();
		PostManualCollectionDetailsRq postManualCollectionDetailsRq = new PostManualCollectionDetailsRq();
		postManualCollectionDetailsRq.setDealInput(dealIdInput);
		postManualCollectionDetailsRq.setFundingAccountID(collectionAccountInput);
		postManualCollectionDetailsRq.setLoanAccountNo(dealAccountInput);
		postManualCollectionDetailsRq.setRqHeader(rqHeader);
		postManualCollectionDetailsRq.setSettlementCurrency(dealDtls.getF_IsoCurrencyCode());
		postManualCollectionDetailsRq.setTransactionID(getF_IN_islamicBankingObject().getTransactionID());
		postManualCollectionDetailsRq.setValueDate(IBCommonUtils.getBFBusinessDate());

		Amount zeroAmount = new Amount();
		zeroAmount.setAmountEdited(BigDecimal.ZERO);
		zeroAmount.setIsoCurrencyCode(dealDtls.getF_IsoCurrencyCode());

		PaymentScheduleList paymentScheduleList = new PaymentScheduleList();
		if (readLoanDetails != null && readLoanDetails.getDealDetails().getPaymentSchedule().length > 0) {
			for (LoanPayments row : readLoanDetails.getDealDetails().getPaymentSchedule()) {
				if (CalendarUtil.IsDate1EqualsToDate2(row.getRepaymentDate(), IBCommonUtils.getBFBusinessDate())) {
					PaymentSchedule paymentSchedule = new PaymentSchedule();
					paymentSchedule.setFeeAmt(BigDecimal.ZERO);
					paymentSchedule.setIsoCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					paymentSchedule.setOutstandingPrincipalAmt(BigDecimal.ZERO.setScale(2));
					// if the business date repayment is already partially paid, then remaining
					// amount should be collected as part of this txn
					paymentSchedule.setPrincipleAmt(row.getPrincipalAmtUnpaid().setScale(2));
					paymentSchedule.setProfitAmt(row.getProfitAmtUnpaid().setScale(2));
					paymentSchedule.setProfitRate(dealDtls.getF_ProfitRate());
					paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
					paymentSchedule.setRepaymentDate(row.getRepaymentDate());
					paymentSchedule.setRepaymentNo(row.getRepaymentNo());
					paymentSchedule.setRepaymentType(row.getRepaymentType());
					paymentScheduleList.addPaymentSchedule(paymentSchedule);
				}
			}
		}
		postManualCollectionDetailsRq.setPaymentSchedule(paymentScheduleList);
		inputParams.put("postManualCollectionDetailsRq", postManualCollectionDetailsRq);

		@SuppressWarnings("unchecked")
		HashMap<String, Object> outputParam = MFExecuter.executeMF(CeConstants.POST_MANUAL_COLLECTION_MF_NAME, env,
				inputParams);
		PostManualCollectionDetailsRs postManualCollectionDetailsRs = (PostManualCollectionDetailsRs) outputParam
				.get("postManualCollectionDetailsRs");
		if (postManualCollectionDetailsRs != null
				&& postManualCollectionDetailsRs.getRsHeader().getStatus().getOverallStatus().equals("S"))
			isPostingSuccessfull = true;*/

		// setF_OUT_hostTransactionID(postManualCollectionDetailsRs.getTransactionID());

	}
}
