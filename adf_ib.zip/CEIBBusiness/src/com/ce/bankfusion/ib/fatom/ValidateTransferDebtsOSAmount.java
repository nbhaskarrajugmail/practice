package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateTransferDebtsOSAmount;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_ValidateTransferDebtsOSAmount;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;

public class ValidateTransferDebtsOSAmount extends AbstractCE_IB_ValidateTransferDebtsOSAmount
		implements ICE_IB_ValidateTransferDebtsOSAmount {
	public ValidateTransferDebtsOSAmount() {
		super();
	}

	public ValidateTransferDebtsOSAmount(BankFusionEnvironment env) {
		super(env);
	}

	private static final transient Log LOGGER = LogFactory.getLog(ValidateTransferDebtsOSAmount.class.getName());
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("Entering into process method");
		String transferDebtsQuery = " WHERE " + IBOCE_IB_TransferOfDebtDtls.IBNEWDEALID + " = ?";
		ArrayList<Object> params = new ArrayList<>();
		params.add(getF_IN_ibObject().getDealID());
		IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls = (IBOCE_IB_TransferOfDebtDtls) factory
				.findFirstByQuery(IBOCE_IB_TransferOfDebtDtls.BONAME, transferDebtsQuery, params, true);
		if (null != transferOfDebtDtls) {
			ReadLoanDetailsRs readLoanDetails = IBCommonUtils.getLoanDetails(transferOfDebtDtls.getF_IBOLDDEALID());
			if (CeConstants.TD_STATUS_SCHEDULED.equals(transferOfDebtDtls.getF_IBTDSTATUS())
					&& (transferOfDebtDtls.getF_IBOSDEALAMT().compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt().
							subtract(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()).
							add(readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt())) != 0
					|| transferOfDebtDtls.getF_IBOSPRINCIPALAMT().compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt().
							subtract(readLoanDetails.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()).
							add(readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt())) != 0
					|| transferOfDebtDtls.getF_IBOSPROFITAMT().compareTo(readLoanDetails.getDealDetails().getLoanBasicDetails().getOustandingProfitAmt()) != 0))
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_VALIDATE_OS_AMOUNTS_CEIB);

		}
		LOGGER.info("Exiting into process method");
	}
}
