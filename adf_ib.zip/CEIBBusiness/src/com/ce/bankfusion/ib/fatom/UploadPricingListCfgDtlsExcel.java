package com.ce.bankfusion.ib.fatom;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UploadPricingListCfgDtlsExcel;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.cfg.bo.PriceList;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.common.functions.CB_CMN_AutoNumber;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.PricingList;
import bf.com.misys.ib.types.PricingListAssetCfg;
import bf.com.misys.ib.types.PricingListCfg;

/**
 * @author chethabn
 * 
 *         Registry configuration excel upload
 *
 */
public class UploadPricingListCfgDtlsExcel extends AbstractCE_IB_UploadPricingListCfgDtlsExcel {
	private static final long serialVersionUID = 7466389691517094749L;
	private static final Log LOGGER = LogFactory.getLog(UploadPricingListCfgDtlsExcel.class);

	public UploadPricingListCfgDtlsExcel(BankFusionEnvironment env) {
		super(env);

	}

	public UploadPricingListCfgDtlsExcel() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		PriceList priceList = new PriceList();

		try {
			priceList.savePricingList(getPricingCfgByExcel());
		} catch (Exception e) {
			LOGGER.error(e);
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(44000205, new Object[] {}, LOGGER,
					IBCommonUtils.getBankFusionEnvironment());
		}
		BusinessEventSupport.getInstance().raiseBusinessInfoEvent(44000210, new Object[] {}, LOGGER,
				IBCommonUtils.getBankFusionEnvironment());
	}

	private PricingList getPricingCfgByExcel() throws IOException {
		String file = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
				"pricingListCfgLocation", "false");
		LOGGER.info(file + "is used to upload Pricing List Configuration");
		// Creating workbook from Excel
		Workbook workbook = null;
		try {
			// workbook = XSSFWorkbook

			try {
				workbook = WorkbookFactory.create(new File(file));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (Exception e) {
			LOGGER.error("The File " + file + " upload is failed " + e);
			throw e;
		}

		return preparePricingListFromExcel(workbook);
	}

	private final PricingList preparePricingListFromExcel(Workbook workbook) throws IOException {
		PricingList pricingList = new PricingList();
		GetVendorNameById byId = new GetVendorNameById();
		if (workbook != null) {
			// get the first sheet
			Sheet sheet = workbook.getSheetAt(0);
			DataFormatter dataFormatter = new DataFormatter();
			List<PricingListCfg> pricingListCfgs = new ArrayList<>();
			List<PricingListAssetCfg> pricingListAssetCfgs = new ArrayList<>();

			// 2. Or you can use a for-each loop to iterate over the rows and columns
			String pricingId = "NO_ID";
			for (int i = 0; i < sheet.getPhysicalNumberOfRows(); i++) {
				if (i >= 1) {
					if (StringUtils.isNotEmpty(dataFormatter.formatCellValue(sheet.getRow(i).getCell(0)))) {
						pricingId = "Price_" + CB_CMN_AutoNumber.run(IBOCE_IB_PricingListCfg.BONAME,
								BankFusionThreadLocal.getBankFusionEnvironment());
						PricingListCfg pricingListCfg = new PricingListCfg();
						pricingListCfg.setPricingListId(pricingId);
						pricingListCfg.setDocumentDate(
								Date.valueOf(dataFormatter.formatCellValue(sheet.getRow(i).getCell(0))));
						pricingListCfg.setDocumentNumber(dataFormatter.formatCellValue(sheet.getRow(i).getCell(1)));
						pricingListCfg.setPriceListYear(
								Integer.valueOf(dataFormatter.formatCellValue(sheet.getRow(i).getCell(2))));
						pricingListCfg.setPricingListDate(
								Date.valueOf(dataFormatter.formatCellValue(sheet.getRow(i).getCell(3))));
						pricingListCfg.setReferenceNumber(dataFormatter.formatCellValue(sheet.getRow(i).getCell(4)));
						String vendorID = dataFormatter.formatCellValue(sheet.getRow(i).getCell(5));
						pricingListCfg.setVendorId(vendorID);
						pricingListCfg.setVendorName(byId.getPartyNameByID(vendorID));
						pricingListCfg.setVendorType(byId.getVendorName(vendorID));
						pricingListCfgs.add(pricingListCfg);
					}

					PricingListAssetCfg pricingListAssetCfg = new PricingListAssetCfg();
					pricingListAssetCfg.setPricingListId(pricingId);
					pricingListAssetCfg.setAssetSerial(CB_CMN_AutoNumber.run(IBOCE_IB_PricingListAssetCfg.BONAME,
							BankFusionThreadLocal.getBankFusionEnvironment()));
					pricingListAssetCfg.setAssetCategory(
							CeUtils.getAssetCategory(dataFormatter.formatCellValue(sheet.getRow(i).getCell(6))));
					pricingListAssetCfg
							.setHorsePower(new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(7))));
					BFCurrencyAmount currency = new BFCurrencyAmount();
					currency.setCurrencyAmount(
							new BigDecimal(dataFormatter.formatCellValue(sheet.getRow(i).getCell(10))));
					currency.setCurrencyCode(SystemInformationManager.getInstance().getBaseCurrencyCode());
					pricingListAssetCfg.setPrice(currency);

					pricingListAssetCfg.setMachineNumber(dataFormatter.formatCellValue(sheet.getRow(i).getCell(8)));
					pricingListAssetCfg.setModel(dataFormatter.formatCellValue(sheet.getRow(i).getCell(9)));
					pricingListAssetCfg.setExtensionIndicator(
							"Y".equals(dataFormatter.formatCellValue(sheet.getRow(i).getCell(11))) ? true : false);
					pricingListAssetCfg.setStatus(dataFormatter.formatCellValue(sheet.getRow(i).getCell(12)));

					pricingListAssetCfg.setMachineType(dataFormatter.formatCellValue(sheet.getRow(i).getCell(13)));
					String attribute1 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(14));
					String attribute2 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(15));
					String attribute3 = dataFormatter.formatCellValue(sheet.getRow(i).getCell(16));
					int attr1 = 0;
					if (!attribute1.equals(""))
						attr1 = new Integer(dataFormatter.formatCellValue(sheet.getRow(i).getCell(14)));

					int attr2 = 0;
					if (!attribute2.equals(""))
						attr1 = new Integer(dataFormatter.formatCellValue(sheet.getRow(i).getCell(15)));

					int attr3 = 0;
					if (!attribute3.equals(""))
						attr1 = new Integer(dataFormatter.formatCellValue(sheet.getRow(i).getCell(16)));

					pricingListAssetCfg.setAttribute1(attr1);
					pricingListAssetCfg.setAttribute2(attr2);
					pricingListAssetCfg.setAttribute3(attr3);
					pricingListAssetCfg.setSelect(true);
					pricingListAssetCfgs.add(pricingListAssetCfg);
				}
			}
			pricingList.setPricingListAssetDtls(
					pricingListAssetCfgs.toArray(new PricingListAssetCfg[pricingListAssetCfgs.size()]));
			pricingList.setPricingListDtls(pricingListCfgs.toArray(new PricingListCfg[pricingListCfgs.size()]));

			workbook.close();
		}
		return pricingList;
	}

}
