/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgCollectAdvPayment;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;

/**
 * @author Aklesh
 *
 */
public class AssetProgCollectAdvPayment extends AbstractCE_IB_AssetProgCollectAdvPayment {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final Log LOGGER = LogFactory.getLog(AssetProgCollectAdvPayment.class);
	private static String GET_ISSUEPO_BY_DEAL_QUERY = " WHERE " + IBOCE_IB_IssuePODetail.IBDEALID + " = ? AND "
			+ IBOCE_IB_IssuePODetail.IBREPORTID + "=?";

	public AssetProgCollectAdvPayment(BankFusionEnvironment env) {
		super(env);

	}

	public AssetProgCollectAdvPayment() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		BigDecimal disbursementAmount = BigDecimal.ZERO;
		if (getF_IN_collectAdvancePayment().equalsIgnoreCase("Yes")) {
			String reportID = getF_IN_reportID();
			AssetProgressReportDetails assetProgressReportDetails = new AssetProgressReportDetails();
			BigDecimal totalAmountProcessed = BigDecimal.ZERO;
			BigDecimal advanceAmountPaid = BigDecimal.ZERO;
			assetProgressReportDetails.removeAllAssetProgressDetailsList();
			// this will be from Screen Data and this will be changed untill we save it once
			// saved we can read it from hidden grid
			for (AssetProgressDetails assetProgressDetails : getF_IN_assetProgressReportDetails()
					.getAssetProgressDetailsList()) {
				if (assetProgressDetails.getReportID().equals(reportID)
						&& assetProgressDetails.getNetFinalCost().getCurrencyAmount()
								.compareTo(CommonConstants.BIGDECIMAL_ZERO) > CommonConstants.INTEGER_ZERO) {
					assetProgressReportDetails.addAssetProgressDetailsList(assetProgressDetails);
					totalAmountProcessed = totalAmountProcessed
							.add(assetProgressDetails.getAllowedFinalCost().getCurrencyAmount());
				}
			}
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add("AdvancePayment");
			List<IBOCE_IB_IssuePODetail> advanceIssuePO = factory.findByQuery(IBOCE_IB_IssuePODetail.BONAME,
					GET_ISSUEPO_BY_DEAL_QUERY, params, null, true);
			if (advanceIssuePO != null && advanceIssuePO.size() > CommonConstants.INTEGER_ZERO) {
				advanceAmountPaid = advanceIssuePO.get(0).getF_IBPOAMOUNT();
			}
			if (totalAmountProcessed.compareTo(advanceAmountPaid) < CommonConstants.INTEGER_ZERO) {
				// Throw exception
			}
			for (AssetProgressDetails assetProgressDetails : assetProgressReportDetails.getAssetProgressDetailsList()) {
				BigDecimal progressContribution = assetProgressDetails.getAllowedFinalCost().getCurrencyAmount()
						.multiply(new BigDecimal(100)).divide(totalAmountProcessed, 10, RoundingMode.HALF_UP);
				BigDecimal deductionAmount = advanceAmountPaid.multiply(progressContribution)
						.divide(new BigDecimal(100), 2, RoundingMode.HALF_UP);
				BigDecimal allowedFinalCost = assetProgressDetails.getAllowedFinalCost().getCurrencyAmount();
				allowedFinalCost = allowedFinalCost.subtract(deductionAmount);
				assetProgressDetails.getAllowedFinalCost().setCurrencyAmount(allowedFinalCost);
				assetProgressDetails.getFinalCostAfterDeduction().setCurrencyAmount(
						allowedFinalCost.subtract(assetProgressDetails.getDeductionAmount().getCurrencyAmount()));
			}
			// Finally update the asset grid
			for (AssetProgressDetails assetProgressDetails : assetProgressReportDetails.getAssetProgressDetailsList()) {
				for (AssetProgressDetails mainProgressDetails : getF_IN_assetProgressReportDetails()
						.getAssetProgressDetailsList()) {
					if (mainProgressDetails.getReportID().equals(reportID)
							&& mainProgressDetails.getAssetID().equals(assetProgressDetails.getAssetID())) {
						mainProgressDetails = assetProgressDetails;
						disbursementAmount = disbursementAmount.add(mainProgressDetails.getAllowedFinalCost().getCurrencyAmount());
					}
				}
			}

		}else {
			for (AssetProgressDetails mainProgressDetails : getF_IN_assetProgressReportDetails()
					.getAssetProgressDetailsList()) {
				mainProgressDetails.setAllowedFinalCost(mainProgressDetails.getNetFinalCost());
				mainProgressDetails.getFinalCostAfterDeduction().setCurrencyAmount(
						mainProgressDetails.getNetFinalCost().getCurrencyAmount().subtract(mainProgressDetails.getDeductionAmount().getCurrencyAmount()));
				disbursementAmount = disbursementAmount.add(mainProgressDetails.getAllowedFinalCost().getCurrencyAmount());
			}
		}

		setF_OUT_assetProgressReportDetails(getF_IN_assetProgressReportDetails());
		setF_OUT_disbursementAmount(disbursementAmount);
	}
}
