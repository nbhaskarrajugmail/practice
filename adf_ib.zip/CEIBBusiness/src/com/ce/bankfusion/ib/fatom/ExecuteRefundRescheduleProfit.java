package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHFEE;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ExecuteRefundRescheduleProfit;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ExecuteRefundRescheduleProfit extends AbstractCE_IB_ExecuteRefundRescheduleProfit {

	public ExecuteRefundRescheduleProfit() {
		super();
	}

	public ExecuteRefundRescheduleProfit(BankFusionEnvironment env) {
		super(env);
	}

	private static final String REFUNDED_STATUS = "REFUNDED";
	private static final String COMPLETED_STATUS = "COMPLETED";
	private static final String SCHEDULED_STATUS = "SCHEDULED";

	private static final transient Log LOGGER = LogFactory.getLog(ExecuteRefundRescheduleProfit.class.getName());

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();;

	@Override
	public void process(BankFusionEnvironment env) {
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		IBOCE_IB_REFUNDRESCHDTLS refundReschDtls = (IBOCE_IB_REFUNDRESCHDTLS) factory
				.findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, ibObject.getTransactionID(), true);
		if (null != refundReschDtls
				&& CeConstants.PAYMENT_MODE_TOSURPLUS.equalsIgnoreCase(refundReschDtls.getF_IBPAYMENTMODE())) {
			updateCustomTablesOnDueDatePosting();
		}
		IBOIB_TXN_PAYRECDETAIL payrecDtlRefundReschDtls = (IBOIB_TXN_PAYRECDETAIL) factory
                .findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME,refundReschDtls.getBoID(),true);
		if(null != payrecDtlRefundReschDtls)
			payrecDtlRefundReschDtls.setF_TRANSACTIONSTATUS("REFUNDED");
		ExecuteRefundFees executeRefundFees = new ExecuteRefundFees();
		executeRefundFees.setF_IN_islamicBankingObject(ibObject);
		executeRefundFees.process(env);
		factory.commitTransaction();
		factory.beginTransaction();
		updateDealRescheduleDtls(ibObject);
		updateRefundReschDtls(ibObject);
		updateRefundReschFee(ibObject);
	}

	public void updateCustomTablesOnDueDatePosting() {
		String loanRepayments_whereClause = "WHERE " + IBOLoanRepayments.PAIDDATE + " =?  and "
				+ IBOLoanRepayments.ACCOUNTID + "=?";
		ArrayList<Object> params = new ArrayList<>();
		params.add(IBCommonUtils.getBFBusinessDate());
		String loanAccountId = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID()).getF_DealAccountId();
		params.add(loanAccountId);
		List<IBOLoanRepayments> loanRepaymentDtls = (List<IBOLoanRepayments>) factory
				.findByQuery(IBOLoanRepayments.BONAME, loanRepayments_whereClause, params, null, true);
		if (loanRepaymentDtls != null && !loanRepaymentDtls.isEmpty()) {
			LOGGER.info("No of repayments found paid/partailly paid in Loan Repayment table with business date: "
					+ IBCommonUtils.getBFBusinessDate() + " is :" + loanRepaymentDtls.size());
			for (IBOLoanRepayments loanRepaymentDtl : loanRepaymentDtls) {
				params.clear();
				params.add(loanRepaymentDtl.getF_ACCOUNTID());
				IBOLendingFeature loanDtls = (IBOLendingFeature) factory.findByPrimaryKey(IBOLendingFeature.BONAME,
						loanRepaymentDtl.getF_ACCOUNTID(), true);
				if (loanDtls != null) {
					params.clear();
					params.add(loanDtls.getF_LOANREFERENCE());
					params.add(loanRepaymentDtl.getF_DUEDATE());
					String breakupDtls_whereClause = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
							+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
					List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
							.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, breakupDtls_whereClause, params, null,
									true);
					if (null != ibPaymentSchResult && !ibPaymentSchResult.isEmpty()) {
						BigDecimal prevReschProfitPaidAmount = RescheduleUtils
								.getPaidRescheduleProfit(getF_IN_islamicBankingObject().getDealID());
						updateScheduleTable(ibPaymentSchResult, loanRepaymentDtl);
						BigDecimal updatedReschProfitPaidAmount = RescheduleUtils
								.getPaidRescheduleProfit(getF_IN_islamicBankingObject().getDealID());
						BigDecimal adjustAmount = updatedReschProfitPaidAmount.subtract(prevReschProfitPaidAmount);
						if (adjustAmount.compareTo(BigDecimal.ZERO) == 1) {
							RescheduleUtils.callRescheduleProfitBackOfficeRequest(loanAccountId,
									getF_IN_islamicBankingObject().getDealID(), loanRepaymentDtl.getBoID(),
									adjustAmount);
						}

					}
				}
			}
		}
	}

	private void updateDealRescheduleDtls(IslamicBankingObject ibObject) {
		String dealRescheduledClause = " WHERE " + IBOCE_IB_DealReschedule.IBRESCHEDULEID + "=?" + " AND "
				+ IBOCE_IB_DealReschedule.IBRESCHEDULESTATUS + "=?";

		ArrayList params = new ArrayList<>();
		params.add(ibObject.getTransactionID());
		params.add(COMPLETED_STATUS);
		List<IBOCE_IB_DealReschedule> dealRescheduledList = factory.findByQuery(IBOCE_IB_DealReschedule.BONAME,
				dealRescheduledClause, params, null, true);

		if (!dealRescheduledList.isEmpty() && dealRescheduledList != null) {
			for (IBOCE_IB_DealReschedule dealRescheduledEach : dealRescheduledList) {
				dealRescheduledEach.setF_IBRESCHEDULESTATUS(REFUNDED_STATUS);
			}
		}
	}

	private void updateRefundReschDtls(IslamicBankingObject ibObject) {
		String dealRefundRescheduleClause = " WHERE " + IBOCE_IB_REFUNDRESCHDTLS.IBREFUNDRESCHDTLSID + "=?" + " AND "
				+ IBOCE_IB_REFUNDRESCHDTLS.IBSYSTEMSTATUS + "=?";

		ArrayList params = new ArrayList<>();
		params.add(ibObject.getTransactionID());
		params.add(SCHEDULED_STATUS);
		List<IBOCE_IB_REFUNDRESCHDTLS> dealRefundRescheduleList = factory.findByQuery(IBOCE_IB_REFUNDRESCHDTLS.BONAME,
				dealRefundRescheduleClause, params, null, true);

		if (!dealRefundRescheduleList.isEmpty() && dealRefundRescheduleList != null) {
			for (IBOCE_IB_REFUNDRESCHDTLS dealRefundRescheduleEach : dealRefundRescheduleList) {
				dealRefundRescheduleEach.setF_IBSYSTEMSTATUS(REFUNDED_STATUS);
			}
		}
	}

	private void updateRefundReschFee(IslamicBankingObject ibObject) {
		String dealRefundRescheduleFeeClause = " WHERE " + IBOCE_IB_REFUNDRESCHFEE.IBREFUNDRESCHDTLSID + "=?" + " AND "
				+ IBOCE_IB_REFUNDRESCHFEE.IBSYSTEMSTATUS + "=?";

		ArrayList params = new ArrayList<>();
		params.add(ibObject.getTransactionID());
		params.add(SCHEDULED_STATUS);
		List<IBOCE_IB_REFUNDRESCHFEE> dealRefundRescheduleFeeList = factory.findByQuery(IBOCE_IB_REFUNDRESCHFEE.BONAME,
				dealRefundRescheduleFeeClause, params, null, true);

		if (!dealRefundRescheduleFeeList.isEmpty() && dealRefundRescheduleFeeList != null) {
			for (IBOCE_IB_REFUNDRESCHFEE dealRefundRescheduleFeeEach : dealRefundRescheduleFeeList) {
				dealRefundRescheduleFeeEach.setF_IBSYSTEMSTATUS(REFUNDED_STATUS);
			}
		}
	}

	private void updatePaymentBreakupTable(BigDecimal principalPaid, BigDecimal profitPaid, String accountId,
			List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult,
			HashMap<String, BigDecimal> assetIdWithPrincipalPercentage,
			HashMap<String, BigDecimal> assetIdWithProfitPercentage) {
		BigDecimal hundred = new BigDecimal(100);
		IBOLendingFeature loanDtls = (IBOLendingFeature) factory.findByPrimaryKey(IBOLendingFeature.BONAME, accountId,
				true);
		String collectionOrderProfile = loanDtls.getF_COLLECTIONORDER();
		BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
		BigDecimal assetProfitPercentage = BigDecimal.ZERO;
		BigDecimal remPrincipalPaid = principalPaid;
		BigDecimal remProfitPaid = profitPaid;
		BigDecimal assetPrincipalPaidAmount = BigDecimal.ZERO;
		BigDecimal assetProfitAndFeesPaidAmount = BigDecimal.ZERO;
		int j = 1;
		boolean isAssetProfitAndFeesFullyPaid = false;
		boolean isAssetPrincipalFullyPaid = false;

		LOGGER.info("Updating breakup table for BillDate : " + ibPaymentSchResult.get(0).getF_IBBILLDATE());
		LOGGER.info("Collection order profile : " + collectionOrderProfile);
		LOGGER.info("Principal Paid : " + principalPaid);
		LOGGER.info("Profit Paid : " + profitPaid);

		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			isAssetProfitAndFeesFullyPaid = false;
			isAssetPrincipalFullyPaid = false;
			assetPrincipalPercentage = assetIdWithPrincipalPercentage.get(paymentSchBreakup.getF_IBASSETID());
			assetProfitPercentage = assetIdWithProfitPercentage.get(paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Principal Percentage / AssetId : " + assetPrincipalPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Profit Percentage / AssetId : " + assetProfitPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());

			assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
					RoundingMode.UP);
			if (j == ibPaymentSchResult.size()) {
				assetProfitAndFeesPaidAmount = remProfitPaid;
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				assetPrincipalPaidAmount = remPrincipalPaid;
			} else {
				assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetPrincipalPaidAmount.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMT()) >= 0) {
					assetPrincipalPaidAmount = paymentSchBreakup.getF_IBPRINCIPALAMT();
					isAssetPrincipalFullyPaid = true;
					LOGGER.info("Principal Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID() + " is "
							+ isAssetPrincipalFullyPaid);
				}
				assetProfitAndFeesPaidAmount = (profitPaid.multiply(assetProfitPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				remPrincipalPaid = remPrincipalPaid.subtract(assetPrincipalPaidAmount);
				remProfitPaid = remProfitPaid.subtract(assetProfitAndFeesPaidAmount);
			}

			if (isAssetPrincipalFullyPaid) {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
			} else {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(assetPrincipalPaidAmount);
			}
			if (isAssetProfitAndFeesFullyPaid) {
				paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
			} else {
				if (collectionOrderProfile.indexOf('I') > collectionOrderProfile.indexOf('F')) {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) > 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBPROFITAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) == 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
					} else {
						paymentSchBreakup.setF_IBPROFITAMTPAID(assetProfitAndFeesPaidAmount);
					}
				} else {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) > 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						paymentSchBreakup.setF_IBPROFITAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) == 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					} else {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(assetProfitAndFeesPaidAmount);
					}
				}
			}
			++j;
		}
	}

	private void updateScheduleTable(List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult,
			IBOLoanRepayments loanRepaymentDtl) {
		BigDecimal hundred = new BigDecimal(100);
		if (loanRepaymentDtl.getF_REPAYMENTUNPAID().compareTo(BigDecimal.ZERO) == 0) {
			// repayment is fully paid
			LOGGER.info("Repayment is fully paid for loan reference: " + loanRepaymentDtl.getF_ACCOUNTID());
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
				paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
				paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
			}
		} else {
			// fetching total repayment principal, profit and fees for the billDate
			BigDecimal totalRepaymentPrincipal = BigDecimal.ZERO;
			BigDecimal totalRepaymentProfit = BigDecimal.ZERO;
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
				totalRepaymentPrincipal = totalRepaymentPrincipal.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
				totalRepaymentProfit = totalRepaymentProfit.add(paymentSchBreakup.getF_IBPROFITAMT())
						.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
			}

			// fetching the percentages for Principal, Profit at Asset level
			HashMap<String, BigDecimal> assetIdWithPrincipalPercentage = new HashMap<>();
			HashMap<String, BigDecimal> assetIdWithProfitPercentage = new HashMap<>();
			BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
			BigDecimal assetProfitPercentage = BigDecimal.ZERO;
			BigDecimal remAssetPrincipalPercentage = new BigDecimal(100);
			BigDecimal remAssetProfitPercentage = new BigDecimal(100);
			BigDecimal assetProfitAmount = BigDecimal.ZERO;
			int i = 1;
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
				assetProfitAmount = paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				if (i == ibPaymentSchResult.size()) {
					assetPrincipalPercentage = remAssetPrincipalPercentage;
					assetProfitPercentage = remAssetProfitPercentage;
				} else {
					if (totalRepaymentPrincipal.compareTo(BigDecimal.ZERO) > 0) {
						assetPrincipalPercentage = (paymentSchBreakup.getF_IBPRINCIPALAMT().multiply(hundred))
								.divide(totalRepaymentPrincipal, 0, RoundingMode.UP);
					}
					if (totalRepaymentProfit.compareTo(BigDecimal.ZERO) > 0) {
						assetProfitPercentage = (assetProfitAmount.multiply(hundred)).divide(totalRepaymentProfit, 0,
								RoundingMode.UP);
					}
				}
				assetIdWithPrincipalPercentage.put(paymentSchBreakup.getF_IBASSETID(), assetPrincipalPercentage);
				assetIdWithProfitPercentage.put(paymentSchBreakup.getF_IBASSETID(), assetProfitPercentage);
				remAssetPrincipalPercentage = remAssetPrincipalPercentage.subtract(assetPrincipalPercentage);
				remAssetProfitPercentage = remAssetProfitPercentage.subtract(assetProfitPercentage);
				++i;
			}

			// updating breakup table
			updatePaymentBreakupTable(loanRepaymentDtl.getF_PRINCIPALPAID(), loanRepaymentDtl.getF_INTERESTPAID(),
					loanRepaymentDtl.getF_ACCOUNTID(), ibPaymentSchResult, assetIdWithPrincipalPercentage,
					assetIdWithProfitPercentage);
		}
	}

}
