/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ConvertGregorianToHijriDate;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * @author Aklesh
 *
 */
public class ConvertGregorianToHijriDate extends AbstractCE_IB_ConvertGregorianToHijriDate {

	private static final long serialVersionUID = 7137308733675905581L;
private static final Log LOGGER = LogFactory.getLog(ConvertGregorianToHijriDate.class);

	public ConvertGregorianToHijriDate(BankFusionEnvironment env) {
		super(env);

	}

	public ConvertGregorianToHijriDate() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		Date inputDate1 = getF_IN_gregorianDate();
		Date inputDate = new Date();
		inputDate.setDate(inputDate1.getDate());
		inputDate.setMonth(inputDate1.getMonth());
		inputDate.setYear(inputDate1.getYear());
		LocalDate localDate = inputDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

		HijrahDate hdate = HijrahChronology.INSTANCE
				.date(LocalDate.of(localDate.getYear(), localDate.getMonth(), localDate.getDayOfMonth()));
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LOGGER.info(hdate.format(FOMATTER));
		setF_OUT_hijriDate(hdate.format(FOMATTER));
	}

}
