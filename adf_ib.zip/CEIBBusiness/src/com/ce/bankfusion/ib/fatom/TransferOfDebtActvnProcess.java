package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebt;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TransferOfDebtActvnProcess;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.calendar.functions.SubtractDateFromDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealPaymentSchedule;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_PFT_ProfitRateMatrixDetails;
import com.misys.bankfusion.ib.fatom.CalculateMinAndMaxRate;
import com.misys.bankfusion.ib.fatom.ReadSchedules;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.ib.msgs.v1r0.MaintainDisbursementDetails;
import bf.com.misys.ib.spi.types.ChargeDetails;
import bf.com.misys.ib.spi.types.ChargeDetailsList;
import bf.com.misys.ib.spi.types.CreateLoanDetails;
import bf.com.misys.ib.spi.types.DisbursementAccountDetail;
import bf.com.misys.ib.spi.types.DisbursementScheduleDetail;
import bf.com.misys.ib.spi.types.EarlySettlementDetails;
import bf.com.misys.ib.spi.types.InstallmentMethodDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.PaymentSchedule;
import bf.com.misys.ib.spi.types.PaymentScheduleInputDetails;
import bf.com.misys.ib.spi.types.PaymentScheduleList;
import bf.com.misys.ib.spi.types.ProfitRateDetails;
import bf.com.misys.ib.spi.types.ProfitRateDetailsList;
import bf.com.misys.ib.spi.types.messages.CreateLoanDetailsRq;
import bf.com.misys.ib.spi.types.messages.CreateLoanDetailsRs;
import bf.com.misys.ib.spi.types.messages.EarlySettlementDetailsRq;
import bf.com.misys.ib.spi.types.messages.EarlySettlementDetailsRs;
import bf.com.misys.ib.spi.types.messages.ReadDealPayOffDtlsRs;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.DealIDInput;
import bf.com.misys.ib.types.DownPaymentDetails;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.FinancialInfoDetail;
import bf.com.misys.ib.types.FreqDtls;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.Term;

public class TransferOfDebtActvnProcess extends AbstractCE_IB_TransferOfDebtActvnProcess {
	private static final long serialVersionUID = -5528789809603983872L;
	private transient static final Log LOGGER = LogFactory.getLog(TransferOfDebtActvnProcess.class.getName());

	private static final String findDealAdditionalDtls = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + "= ?";

	private CreateLoanDetails createLoanDetailsInput = new CreateLoanDetails();
	private CreateLoanDetailsRq createLoanObj = new CreateLoanDetailsRq();
	private IPersistenceObjectsFactory factory;
	private IslamicBankingObject ibObj;
	private IBOIB_DLI_DealDetails dealDetails;
	private ProductConfiguration productConfig;
	private String dealId;
	private String dealAccountId;
	private List<IBOIB_AST_AssetDetails> assetDtls;
	private ReadLoanDetailsRs res;
	private FinancialInfoDetail financialInfoDetail;
	private IBOIB_DLI_ScheduleProfile profileRec;

	private BigDecimal newProfitAmount = BigDecimal.ZERO;
	private BigDecimal newPrincipalAmount = BigDecimal.ZERO;
	private String newDealId;

	public TransferOfDebtActvnProcess(BankFusionEnvironment env) {
		super(env);
	}

	public TransferOfDebtActvnProcess() {
		super();

	}

	private static IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory
			.getInstance().getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		initProcess();
		prepareInitialCreateLoanObj();
		setChargeDtls();
		setDisbursementDtls();
		setManualSchedule();
		setProfitRateDtls();
		setPaymentScheduleInputDtls();
		createLoanObj.setCreateLoanDetailsInput(createLoanDetailsInput);
		ExtensionDetails extentionDetails = new ExtensionDetails();
		Object hostExtension = IBCommonUtils.getUDFDealDetails(dealId);
		extentionDetails.setUserExtension(hostExtension);
		createLoanObj.setExtentionDetails(extentionDetails);
		// Do Early Settlement for current loan closure
		EarlySettlementDetailsRs earlySettlement = doEarlySettlement(ibObj);
		LOGGER.info("Entering into callingCreateLoanPayoffSPI() for the deal " + ibObj.getDealID());

		if (earlySettlement != null && earlySettlement.getRsHeader().getStatus().getOverallStatus().equals("S")) {
			HashMap inputParams = new HashMap();
			inputParams.put("CreateLoanDetailsRq", createLoanObj);
			HashMap loanDtlsMap = MFExecuter.executeMF("IB_SPI_CreateLoan_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
			CreateLoanDetailsRs loanDtlsRs = (CreateLoanDetailsRs) loanDtlsMap.get("CreateLoanDetailsRs");
			if (loanDtlsRs != null && loanDtlsRs.getRsHeader().getStatus().getOverallStatus().equals("S")) {
				updateDealDetails(loanDtlsRs);
				createTranferOfDebtDtls(dealAccountId);
			} else {
				LOGGER.error("Loan creattion failed for Transfer of Debt Process having a deal id :" + dealId);
			}
		} else {
			LOGGER.error("Early Settlement is failed for Transfer of Debt Process having a deal id :" + dealId);
		}

	}

	private void updateDealDetails(CreateLoanDetailsRs loanDtlsRs) {
		dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealId, false);
		dealDetails.setF_DealAccountId(loanDtlsRs.getLoanAccountNo().getAccountID());
		ArrayList param = new ArrayList();
		param.add(dealId);
		param.add("PC");
		String whereClause = " WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + " = ? AND "
				+ IBOIB_IDI_DealCustomerDetail.ASSOCIATIONTYPE + " = ?";
		IBOIB_IDI_DealCustomerDetail dealCust = (IBOIB_IDI_DealCustomerDetail) factory
				.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, whereClause, param, null, false).get(0);
		String newPArtyId = (String) CeUtils.getUDFValueByName(dealId, "NEW_CUSTOMER");
		dealCust.setF_CUSTOMERID(newPArtyId);
	}

	private void setPaymentScheduleInputDtls() {
		PaymentScheduleInputDetails paymentScheduleInputDtls = new PaymentScheduleInputDetails();

		Term loanTerm = new Term();
		loanTerm.setPeriodCode(dealDetails.getF_DEALTERMCODE());
		loanTerm.setPeriodNumber(
				SubtractDateFromDate.run(profileRec.getF_LastPaymentDT(), IBCommonUtils.getBFBusinessDate()));
		paymentScheduleInputDtls.setLoanTerm(loanTerm);

		FreqDtls principalRepayFrequency = new FreqDtls();
		principalRepayFrequency.setFrequencyDay(ScheduleUtils.getRepaymentDay(
				createLoanDetailsInput.getManualPaymentSchedulesList().getPaymentSchedule(0).getRepaymentDate(),
				profileRec.getF_FreqCode()));
		principalRepayFrequency.setFrequencyCode(profileRec.getF_FreqCode());
		principalRepayFrequency.setFrequencyNum(profileRec.getF_FreqUnit());

		paymentScheduleInputDtls.setProfitAmt(newProfitAmount);
		paymentScheduleInputDtls.setPaymentStartDate(
				createLoanDetailsInput.getManualPaymentSchedulesList().getPaymentSchedule(0).getRepaymentDate());
		paymentScheduleInputDtls.setPaymentMaturityDate(dealDetails.getF_LastRepaymentDate());

		InstallmentMethodDetails vInstallmentMethodDetails = new InstallmentMethodDetails();
		vInstallmentMethodDetails.setEffectiveDate(IBCommonUtils.getBFBusinessDate());
		vInstallmentMethodDetails.setInstallmentMethod(profileRec.getF_ScheduleType().toUpperCase());
		vInstallmentMethodDetails.setLastInstallmentDate(profileRec.getF_LastPaymentDT());
		vInstallmentMethodDetails
				.setNoOfPayments(createLoanDetailsInput.getManualPaymentSchedulesList().getPaymentScheduleCount());
		vInstallmentMethodDetails.setPaymentOptions(profileRec.getF_PaymentOption().toUpperCase());
		vInstallmentMethodDetails.setFirstPrincipalInstallmentDate(
				createLoanDetailsInput.getManualPaymentSchedulesList().getPaymentSchedule(0).getRepaymentDate());
		vInstallmentMethodDetails.setPrincipalRepayFrequency(principalRepayFrequency);
		vInstallmentMethodDetails.setProfitRepayfrequency(principalRepayFrequency);
		vInstallmentMethodDetails.setFirstProfitInstallmentDate(
				createLoanDetailsInput.getManualPaymentSchedulesList().getPaymentSchedule(0).getRepaymentDate());
		vInstallmentMethodDetails.setTotalPrincipalAmount(newPrincipalAmount.setScale(2));
		vInstallmentMethodDetails.setTotalProfitAmount(newProfitAmount.setScale(2));
		vInstallmentMethodDetails.setFirstAmountCanDiffer(false);
		paymentScheduleInputDtls.addInstallmentMethodDetails(vInstallmentMethodDetails);
		createLoanDetailsInput.setPaymentScheduleInputDtls(paymentScheduleInputDtls);
	}

	private void setProfitRateDtls() {
		IBOIB_PFT_ProfitRateMatrixDetails profitData = getProfitDetails(profileRec.getF_ProfitMatrixID(),
				profileRec.getF_EvaluationMethod());

		ProfitRateDetailsList profitRateDetailsList = new ProfitRateDetailsList();
		ProfitRateDetails vProfitRateDetails = new ProfitRateDetails();
		vProfitRateDetails.setMarginRate(CommonConstants.BIGDECIMAL_ZERO);
		vProfitRateDetails.setProfitRateCode(CommonConstants.EMPTY_STRING);
		vProfitRateDetails.setProfitAmount(newProfitAmount.setScale(2));
		vProfitRateDetails.setProfitRate(CeUtils.getProfitRate(financialInfoDetail));
		if (profitData != null) {

			if (IBCommonUtils.isValidString(profitData.getF_Index())) {
				BigDecimal profitBaseRate = IBCommonUtils.getProfitBaseRate(profitData.getF_Index());
				BigDecimal actulaMarginRate = profileRec.getF_ProfitRate().subtract(profitBaseRate);
				vProfitRateDetails.setProfitRateCode(profitData.getF_Index());
				vProfitRateDetails.setMarginRate(actulaMarginRate);
			}
		}
		vProfitRateDetails.setProfitCalcMethod(CeUtils.getProfitMethod(financialInfoDetail));
		vProfitRateDetails.setEffectiveDate(IBCommonUtils.getBFBusinessDate());

		vProfitRateDetails.setProfitRateBasis(profileRec.getF_BaseFactor());
		profitRateDetailsList.addProfitRateDetails(vProfitRateDetails);
		createLoanDetailsInput.setProfitRateDetailsList(profitRateDetailsList);
	}

	public IBOIB_PFT_ProfitRateMatrixDetails getProfitDetails(String profitID, String evalMethod) {

		if (!IBCommonUtils.isValidString(profitID))
			return null;

		ArrayList<String> params = new ArrayList<String>();
		params.add(profitID);

		params.add(evalMethod);
		String whereClause = " WHERE " + IBOIB_PFT_ProfitRateMatrixDetails.ProfitMatrixId + " = ? AND "
				+ IBOIB_PFT_ProfitRateMatrixDetails.EvalMathod + " = ? ";
		List<IBOIB_PFT_ProfitRateMatrixDetails> list = new ArrayList<IBOIB_PFT_ProfitRateMatrixDetails>();
		list = factory.findByQuery(IBOIB_PFT_ProfitRateMatrixDetails.BONAME, whereClause, params, null, false);
		if (list == null || list.isEmpty()) {
			params.clear();
			params.add(profitID);
			String whereClause1 = " WHERE " + IBOIB_PFT_ProfitRateMatrixDetails.ProfitMatrixId + " = ? ";
			list = factory.findByQuery(IBOIB_PFT_ProfitRateMatrixDetails.BONAME, whereClause1, params, null, false);

		}

		return list.get(0);

	}

	private void initProcess() {
		factory = BankFusionThreadLocal.getPersistanceFactory();
		ibObj = getF_IN_islamicBankingObj();
		dealId = ibObj.getDealID();
		dealDetails = getDealDetails(ibObj.getDealID());
		dealAccountId= dealDetails.getF_DealAccountId();
		res = IBCommonUtils.getLoanDetails(dealId);
		loadProductConfigurations(ibObj);

		getProfileRec();
		getEligibleAssets();
		getAssetCost();
		getProfitAmt();
	}

	private void getProfileRec() {
		String scheduleProfile = " WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ? ";
		List<IBOIB_DLI_ScheduleProfile> scheduleProfileList = new ArrayList<IBOIB_DLI_ScheduleProfile>();
		ArrayList<String> params = new ArrayList<String>();
		params.clear();
		params.add(dealId);
		scheduleProfileList = (List<IBOIB_DLI_ScheduleProfile>) factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME,
				scheduleProfile, params, null, false);
		if (scheduleProfileList != null && !scheduleProfileList.isEmpty()) {
			profileRec = scheduleProfileList.get(0);
		}

	}

	private void getAssetCost() {
		newPrincipalAmount = BigDecimal.ZERO;
		for (IBOIB_AST_AssetDetails asstdtl : assetDtls) {
			newPrincipalAmount = newPrincipalAmount.add(asstdtl.getF_PRINCIPALAMOUNT());
		}

	}

	private void getProfitAmt() {
		if (dealDetails != null && res != null)
			newProfitAmount = dealDetails.getF_ProfitAmt()
					.subtract(res.getDealDetails().getLoanBasicDetails().getOustandingProfitAmt());

	}

	private void setChargeDtls() {
		String whereClause = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ? AND "
				+ IBOIB_DLI_DealAssetChargesdtls.ISUPFRONT + "='N' AND " + IBOIB_DLI_DealAssetChargesdtls.ISWAIVED
				+ " = 'N' AND " + IBOIB_DLI_DealAssetChargesdtls.CHARGEPAYMENTSTATUS + " = 'UNPAID'";
		ArrayList<String> params = new ArrayList<String>();
		params.add(dealId);
		List<IBOIB_DLI_DealAssetChargesdtls> list = new ArrayList<IBOIB_DLI_DealAssetChargesdtls>();
		list = factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, whereClause, params, null, false);
		ChargeDetailsList chargeDetailsList = new ChargeDetailsList();
		for (int i = 0; i < list.size(); i++) {
			IBOIB_DLI_DealAssetChargesdtls rec = list.get(i);
			ChargeDetails vChargeDetails = new ChargeDetails();
			vChargeDetails.setChargeCode(rec.getF_ChargeCode());
			vChargeDetails.setChargeBasis(rec.getF_ChargeBasis());
			vChargeDetails.setChargeAmount(rec.getF_ChargeAmount().setScale(2).add(rec.getF_TaxAmount().setScale(2)));
			vChargeDetails.setChargeCurrency(rec.getF_ChargeCurrency());
			vChargeDetails.setChargeReceivingAccount(rec.getF_ChargeReceivingAccount());
			vChargeDetails.setTaxCode(rec.getF_TaxCode());
			vChargeDetails.setTaxCurrency(rec.getF_TaxCurrency());
			vChargeDetails.setTaxReceivingAccount(rec.getF_TaxReceivingAccount());
			vChargeDetails.setChargeApplicationDate(IBCommonUtils.getBFBusinessDate());
			vChargeDetails.setAmortizationMethod(CommonConstants.EMPTY_STRING);
			vChargeDetails.setApplicationMethod(CommonConstants.EMPTY_STRING);
			vChargeDetails.setChargeBasisAmt(CommonConstants.BIGDECIMAL_ZERO);
			vChargeDetails.setChargeDetailId(CommonConstants.EMPTY_STRING);
			vChargeDetails.setChargeFundingAccount(CommonConstants.EMPTY_STRING);
			vChargeDetails.setChargeFundingAccountFormatType(CommonConstants.EMPTY_STRING);
			vChargeDetails.setChgFundingCurrency(CommonConstants.EMPTY_STRING);
			vChargeDetails.setChargePostTxnCode(CommonConstants.EMPTY_STRING);
			vChargeDetails.setEventCode(CommonConstants.EMPTY_STRING);
			vChargeDetails.setEventType(CommonConstants.EMPTY_STRING);
			vChargeDetails.setExchangeRate(CommonConstants.BIGDECIMAL_ZERO);
			vChargeDetails.setExchangeRateType(CommonConstants.EMPTY_STRING);
			vChargeDetails.setInstallmentNum(CommonConstants.INTEGER_ZERO);
			vChargeDetails.setIsChargeCapitalised(true);
			vChargeDetails.setIsChargewaived(false);
			vChargeDetails.setIsDuplicatedCharge(false);
			vChargeDetails.setIsTaxCapitalised(true);
			vChargeDetails.setOrigChargeAmount(rec.getF_ChargeAmount().setScale(2));
			vChargeDetails.setOrigTaxAmount(rec.getF_TaxAmount().setScale(2));
			vChargeDetails.setTaxPostTxnCode(CommonConstants.EMPTY_STRING);
			vChargeDetails.setTaxReceivingAccountFormatType(CommonConstants.EMPTY_STRING);
			vChargeDetails.setTransactionBranch(CommonConstants.EMPTY_STRING);
			vChargeDetails.setWaiverReason(CommonConstants.EMPTY_STRING);
			vChargeDetails.setWaiverReasonText(CommonConstants.EMPTY_STRING);
			chargeDetailsList.addChargeDetailList(vChargeDetails);
		}
		createLoanDetailsInput.setChargeDetailsList(chargeDetailsList);

	}

	private void generateSchedule(IslamicBankingObject islamicBankingObject, BankFusionEnvironment env) {

		HashMap<String, Object> param = new HashMap<>();
		param.clear();
		param.put("dealNo", dealId);
		HashMap<String, Object> outputParams = MFExecuter.executeMF("IB_IDI_GetFinInfo_SRV", env, param);
		financialInfoDetail = (FinancialInfoDetail) outputParams.get("financialInfoDetail");
		ExtensionDetails extensionDtls = new ExtensionDetails();
		extensionDtls.setUserExtension(CeUtils.getUserExtension(islamicBankingObject.getDealID()));
		extensionDtls.setHostExtension(CommonConstants.EMPTY_STRING);
		financialInfoDetail.setExtensionDtls(extensionDtls);
		GenerateScheduleWithMultipleContracts generateScheduleWithMultipleContracts = new GenerateScheduleWithMultipleContracts(
				env);
		generateScheduleWithMultipleContracts.setF_IN_islamicBankingObject(islamicBankingObject);
		generateScheduleWithMultipleContracts
				.setF_IN_paymentFrequency(CeUtils.getPaymentFrequency(financialInfoDetail));
		//generateScheduleWithMultipleContracts.setF_IN_scheduledProfit(newProfitAmount);
		generateScheduleWithMultipleContracts.setF_IN_pricingMethod(CeUtils.getPricingMethod(financialInfoDetail));
		generateScheduleWithMultipleContracts.setF_IN_profitMethod(CeUtils.getProfitMethod(financialInfoDetail));
		generateScheduleWithMultipleContracts.setF_IN_generateScheduleForDisbursedAssets(true);
		generateScheduleWithMultipleContracts.setF_IN_isGenScheduleForFutureAssets(true);
		generateScheduleWithMultipleContracts.process(env);
	}

	private void setManualSchedule() {
		generateSchedule(ibObj, IBCommonUtils.getBankFusionEnvironment());

		ArrayList<String> params = new ArrayList<String>();
		params.add(dealId);
		String scheduleClause = " WHERE " + IBOIB_DLI_DealPaymentSchedule.DEALNO + " = ? ";

		List<IBOIB_DLI_DealPaymentSchedule> paymentScheduleList = new ArrayList<IBOIB_DLI_DealPaymentSchedule>();

		paymentScheduleList = factory.findByQuery(IBOIB_DLI_DealPaymentSchedule.BONAME, scheduleClause, params, null,
				false);
		PaymentScheduleList manualPaymentSchedulesList = new PaymentScheduleList();
		for (int i = 0; i < paymentScheduleList.size(); i++) {

			IBOIB_DLI_DealPaymentSchedule singleRec = paymentScheduleList.get(i);
			PaymentSchedule vManualPaymentSchedules = new PaymentSchedule();

			vManualPaymentSchedules.setFeeAmt(singleRec.getF_CHARGEAMT().setScale(2));
			vManualPaymentSchedules.setRepaymentDate(singleRec.getF_PAYMENTDT());
			vManualPaymentSchedules.setPrincipleAmt(singleRec.getF_PRINCIPALAMT().setScale(2));
			vManualPaymentSchedules.setProfitAmt(singleRec.getF_PROFITAMT().setScale(2));
			vManualPaymentSchedules.setRepaymentAmt(singleRec.getF_REPAYMENTAMT().setScale(2));
			vManualPaymentSchedules.setRepaymentType(singleRec.getF_REPAYMENTTYPE().toUpperCase());
			vManualPaymentSchedules.setIsoCurrencyCode(dealDetails.getF_IsoCurrencyCode());
			if (singleRec.getF_PROFITRATE() != null
					&& (singleRec.getF_PROFITRATE().compareTo(CommonConstants.BIGDECIMAL_ZERO)) > 0)
				vManualPaymentSchedules.setProfitRate(singleRec.getF_PROFITRATE());
			vManualPaymentSchedules.setRepaymentNo(singleRec.getF_REPAYMENTNUMBER());
			manualPaymentSchedulesList.addPaymentSchedule(vManualPaymentSchedules);
		}
		createLoanDetailsInput.setManualPaymentSchedulesList(manualPaymentSchedulesList);
	}

	private void setDisbursementDtls() {

		for (int i = 0; i < assetDtls.size(); i++) {
			DisbursementScheduleDetail disbSchDtls = new DisbursementScheduleDetail();
			disbSchDtls.setActionMode("CREATE");
			DisbursementAccountDetail[] disbAccDtl = new DisbursementAccountDetail[assetDtls.size()];
			DisbursementAccountDetail disbAccDtls = new DisbursementAccountDetail();
			disbAccDtls.setDisbursementAccount(productConfig.getPrincipalReceivingAccount());
			disbAccDtls.setDisbursementAccountFormatType("PSU");
			disbAccDtls.setDisbursementAmount(assetDtls.get(i).getF_ASSETCOST());
			disbAccDtls.setPartID((String) CeUtils.getUDFValueByName(dealId, "NEW_CUSTOMER"));
			disbAccDtl[0] = disbAccDtls;
			disbSchDtls.setDisbursementAccountDetailList(disbAccDtl);
			disbSchDtls.setDisbursementAmount(assetDtls.get(i).getF_ASSETCOST());
			disbSchDtls.setDisbursementCurrency(ibObj.getCurrency());
			disbSchDtls.setDisbursementDate(IBCommonUtils.getCurrentBusinessDate());
			disbSchDtls.setDisbursementmentNo(i + 1);
			disbSchDtls.setDisbursementType("MANUAL");
			createLoanDetailsInput.addDisbursementScheduleDetail(disbSchDtls);
		}
	}

	private void getEligibleAssets() {
		String findByDealNumber = " WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);

		List<IBOIB_DLI_DealAssetDtls> dealAssetDetails = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
				findByDealNumber, params, null, true);

		StringBuilder whereClause1 = new StringBuilder(" Where " + IBOIB_AST_AssetDetails.ASSETDETAILSID);
		ArrayList params1 = new ArrayList();
		new StringBuilder(whereClause1.append(" IN ("));
		for (int i = 0; i < dealAssetDetails.size(); i++) {
			whereClause1.append("?,");
			params1.add(dealAssetDetails.get(i).getF_ASSETDETAILSID());
		}
		params1.add("Active");
		whereClause1 = new StringBuilder(whereClause1.substring(0, whereClause1.lastIndexOf(","))).append(")")
				.append(" and " + IBOIB_AST_AssetDetails.STATUS + "=?");
		assetDtls = factory.findByQuery(IBOIB_AST_AssetDetails.BONAME, whereClause1.toString(), params1, null, true);
	}

	private void updateLoanDtlsWithNewSch(CreateLoanDetailsRq createLoan, PaymentSchedule[] paymentSchedules) {
		CreateLoanDetails loanDetails = createLoan.getCreateLoanDetailsInput();
		PaymentScheduleList payScheList = loanDetails.getManualPaymentSchedulesList();
		payScheList.setPaymentSchedule(paymentSchedules);
		loanDetails.setManualPaymentSchedulesList(payScheList);
		createLoan.setCreateLoanDetailsInput(loanDetails);
	}

	private String getNewDealId() {
		newDealId = ibObj.getDealID();
		ArrayList<String> param = new ArrayList<>();
		String findByDealId = " WHERE " + IBOCE_IB_TransferOfDebt.IBORIGINALDEALID + " = ? ORDER BY "
				+ IBOCE_IB_TransferOfDebt.IBRECCREATEDON + " ASC";
		param.add(dealId);
		List result = null;
		result = factory.findByQuery(IBOCE_IB_TransferOfDebt.BONAME, findByDealId, param, null, true);
		if (null == result || result.isEmpty()) {
			newDealId = newDealId.concat("_1");

		} else {
			IBOCE_IB_TransferOfDebt obj = (IBOCE_IB_TransferOfDebt) result.get(result.size() - 1);
			newDealId = newDealId.concat("_").concat(String.valueOf(obj.getF_IBNUMOFTRANSFERS() + 1));
		}
		// create a new table and get the new dealId.
		return newDealId;
	}

	private void createTranferOfDebtDtls(String accouontId) {
		
		List<IBOIB_AST_AssetDetails> disbursedAssets=getDisbursedAssetsOfDeal();
		String disbursedAssetIds= new String();
		for(IBOIB_AST_AssetDetails assetDtl:disbursedAssets)
		{
			String assetId=assetDtl.getBoID();
			
			disbursedAssetIds=disbursedAssetIds.concat(assetId.concat("|"));
		}
		IBOCE_IB_TransferOfDebt transferOfDebtHist = (IBOCE_IB_TransferOfDebt) factory
				.getStatelessNewInstance(IBOCE_IB_TransferOfDebt.BONAME);
		transferOfDebtHist.setF_IBORIGINALDEALID(dealId);
		transferOfDebtHist.setF_IBTRANSFEREDDEALID(newDealId);
		transferOfDebtHist.setF_IBNUMOFTRANSFERS(Integer.valueOf(newDealId.substring(newDealId.length() - 1)));
		transferOfDebtHist.setF_IBRECCREATEDBY(IBCommonUtils.getUserId());
		transferOfDebtHist.setF_IBRECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
		transferOfDebtHist.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
		transferOfDebtHist.setF_IBLOANACCOUNTNUMBER(accouontId);
		transferOfDebtHist.setF_IBDISBURSEDASSETS(disbursedAssetIds);
		factory.create(IBOCE_IB_TransferOfDebt.BONAME, transferOfDebtHist);
	}

	private List<IBOIB_AST_AssetDetails> getDisbursedAssetsOfDeal() {


		List<IBOIB_AST_AssetDetails> disburedAssets = null;
		String findByDealNumber = " WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);

		List<IBOIB_DLI_DealAssetDtls> dealAssetDetails = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
				findByDealNumber, params, null, true);

		StringBuilder whereClause1 = new StringBuilder(" Where " + IBOIB_AST_AssetDetails.ASSETDETAILSID);
		ArrayList params1 = new ArrayList();
		new StringBuilder(whereClause1.append(" IN ("));
		for (int i = 0; i < dealAssetDetails.size(); i++) {
			whereClause1.append("?,");
			params1.add(dealAssetDetails.get(i).getF_ASSETDETAILSID());
		}
		params1.add(CeConstants.ASSET_STATUS_DISBURSED);
		whereClause1 = new StringBuilder(whereClause1.substring(0, whereClause1.lastIndexOf(","))).append(")")
				.append(" and " + IBOIB_AST_AssetDetails.STATUS + "=?");
	return	 disburedAssets = factory.findByQuery(IBOIB_AST_AssetDetails.BONAME, whereClause1.toString(), params1, null, true);
	
	}

	private List<IBOIB_DLI_DealAditionalDtls> getDealAddtnlDtlsByDealId(String dealId) {
		ArrayList param = new ArrayList();
		param.add(dealId);
		return factory.findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, findDealAdditionalDtls, param, null, false);
	}

	private void prepareInitialCreateLoanObj() {
		createLoanDetailsInput.setDealID(getNewDealId());
		createLoanDetailsInput.setDealBranch(dealDetails.getF_BranchSortCode());
		createLoanDetailsInput.setDealCurrency(dealDetails.getF_IsoCurrencyCode());
		createLoanDetailsInput.setDealProductID(dealDetails.getF_ProductCode());
		createLoanDetailsInput.setSubProductID(dealDetails.getF_ProductContextCode());
		CalculateMinAndMaxRate calculateMinAndMaxRate = new CalculateMinAndMaxRate();
		BigDecimal maxRate = calculateMinAndMaxRate.calculateMaxRate(dealId);
		BigDecimal minRate = calculateMinAndMaxRate.calculateMinRate(dealId);
		createLoanDetailsInput.setMaxRate(maxRate);
		createLoanDetailsInput.setMinRate(minRate);
		createLoanDetailsInput.setConstructionProfit(BigDecimal.ZERO);
		createLoanDetailsInput.setDisbursementType(IBConstants.MULTIPLE_DISBURSEMENT_TYPE.toString());
		ExtensionDetails extentionDetails = new ExtensionDetails();
		Object hostExtension = IBCommonUtils.getUDFDealDetails(dealId);
		extentionDetails.setUserExtension(hostExtension);
		createLoanDetailsInput.setExtentionDetails(extentionDetails);
		createLoanDetailsInput.setIndustrySectorCode(dealDetails.getF_INDUSTRYCODE());
		createLoanDetailsInput.setInterestFundingAcc(CommonConstants.EMPTY_STRING);
		createLoanDetailsInput.setInterestFundingAccFormatType(CommonConstants.EMPTY_STRING);
		createLoanDetailsInput.setIsAutomaticRateReview(false);

		createLoanDetailsInput.setIsHostScheduleGenerator(productConfig.getIsHostScheduleGenerator());
		createLoanDetailsInput.setPrincipalFundingAcc(CommonConstants.EMPTY_STRING);
		createLoanDetailsInput.setPrincipalFundingAccFormatType(CommonConstants.EMPTY_STRING);
		createLoanDetailsInput.setPrincipalReceivingAcc(productConfig.getPrincipalReceivingAccount());
		createLoanDetailsInput.setPrincipalReceivingAccFormatType("PSU");

		createLoanDetailsInput.setDealAmount(newPrincipalAmount.add(newProfitAmount));
		createLoanDetailsInput.addDealCustomerID((String) CeUtils.getUDFValueByName(dealId, "NEW_CUSTOMER"));
		createLoanDetailsInput.setDealDate(IBCommonUtils.getBFBusinessDate());
		createLoanDetailsInput.setDealEffectiveDate(IBCommonUtils.getBFBusinessDate());
		createLoanDetailsInput.setDealOriginator(IBCommonUtils.getUserId());
		createLoanDetailsInput.setTotalPrincipalAmount(newPrincipalAmount);
		createLoanDetailsInput.setTotalProfitAmount(newProfitAmount);

	}

	private MaintainDisbursementDetails getDisbursedSchedules(BankFusionEnvironment env, String dealId) {
		ReadSchedules disburseSchedules = new ReadSchedules(env);
		disburseSchedules.setF_IN_buildingBlaockId("CREATELOAN");
		disburseSchedules.setF_IN_dealId(dealId);
		DownPaymentDetails downPaymntDtls = new DownPaymentDetails();
		disburseSchedules.setF_IN_downPaymentDetailsInput(downPaymntDtls);
		disburseSchedules.setF_IN_isApplyDownpayments(false);
		disburseSchedules.process(env);
		return disburseSchedules.getF_OUT_maintainDisbursementDetails();
	}

	private PaymentSchedule[] paymentScheduleProcess(ReadLoanDetailsRs loanDtls) {
		LoanPayments[] currLoanDtls = loanDtls.getDealDetails().getPaymentSchedule();
		PaymentSchedule[] paymentSchedules;
		java.util.List<PaymentSchedule> paySch = new java.util.ArrayList<>();
		BigDecimal arrFee = BigDecimal.ZERO;
		BigDecimal arrPricAmt = BigDecimal.ZERO;
		BigDecimal arrRepAmt = BigDecimal.ZERO;
		BigDecimal arrProfitAmt = BigDecimal.ZERO;
		int arrearCounter = 0;
		int currCounter = 0;
		BigDecimal profitRate = loanDtls.getDealDetails().getLoanBasicDetails().getProfitRate();
		for (int i = 0; i < currLoanDtls.length; i++) {
			if (currLoanDtls[i].getRepaymentDate().before(IBCommonUtils.getCurrentBusinessDate())
					&& currLoanDtls[i].getRepaymentStatus().equalsIgnoreCase("ARREAR")) {
				arrFee = arrFee.add(currLoanDtls[i].getFeeAmt());
				arrPricAmt = arrPricAmt.add(currLoanDtls[i].getPrincipleAmt());
				arrRepAmt = arrRepAmt.add(currLoanDtls[i].getRepaymentAmt());
				arrProfitAmt = arrProfitAmt.add(currLoanDtls[i].getProfitAmt());
				arrearCounter = arrearCounter + 1;
			} else {
				if (i == (arrearCounter)) {
					++currCounter;
					paySch.add(preparePaymentSchedule(profitRate, currLoanDtls[i],
							currLoanDtls[i].getFeeAmt().add(arrFee), currLoanDtls[i].getPrincipleAmt().add(arrPricAmt),
							currLoanDtls[i].getRepaymentAmt().add(arrRepAmt),
							currLoanDtls[i].getProfitAmt().add(arrProfitAmt), currCounter));
				} else {
					++currCounter;
					paySch.add(preparePaymentSchedule(profitRate, currLoanDtls[i], currLoanDtls[i].getFeeAmt(),
							currLoanDtls[i].getPrincipleAmt(), currLoanDtls[i].getRepaymentAmt(),
							currLoanDtls[i].getProfitAmt(), currCounter));
				}
			}
		}
		paymentSchedules = paySch.toArray(new PaymentSchedule[0]);
		return paymentSchedules;

	}

	private PaymentSchedule preparePaymentSchedule(BigDecimal profitRate, LoanPayments currLoanDtls, BigDecimal arrFee,
			BigDecimal arrPricAmt, BigDecimal arrRepAmt, BigDecimal arrProfitAmt, int repayNo) {
		PaymentSchedule paymentSchedule = new PaymentSchedule();
		paymentSchedule.setFeeAmt(arrFee);
		paymentSchedule.setRepaymentDate(currLoanDtls.getRepaymentDate());
		paymentSchedule.setProfitAmt(arrProfitAmt);
		paymentSchedule.setRepaymentAmt(arrRepAmt);
		paymentSchedule.setProfitRate(profitRate);
		paymentSchedule.setRepaymentType(currLoanDtls.getRepaymentType());
		paymentSchedule.setHostRepaymentNo(repayNo);
		paymentSchedule.setOutstandingPrincipalAmt(currLoanDtls.getOutstandingPrincipalAmt());
		paymentSchedule.setExtentionDetails(currLoanDtls.getExtentionDetails());
		paymentSchedule.setPrincipleAmt(arrPricAmt);
		paymentSchedule.setRepaymentNo(repayNo);
		paymentSchedule.setIsoCurrencyCode(currLoanDtls.getIsoCurrencyCode());
		return paymentSchedule;
	}

	private EarlySettlementDetailsRs doEarlySettlement(IslamicBankingObject ibObj) {

		String collectionAccountFormatType = "PSU";
		HashMap<String, Object> inputParams = new HashMap<>();

		ReadDealPayOffDtlsRs readDealPayOffDtlsRs;
		String settlementCurrency;
		readDealPayOffDtlsRs = IBCommonUtils.callReadDealPayoffSPI(ibObj.getDealID());
		BigDecimal refundOfUnearnedProfitAmt = BigDecimal.ZERO;
		if (readDealPayOffDtlsRs != null && productConfig != null) {
			refundOfUnearnedProfitAmt = (readDealPayOffDtlsRs.getPayOffDetailsOutput().getUnEarnedProfit()
					.getAmountEdited().multiply(productConfig.getDealServices().getGiftAmountPercentage()))
							.divide(new BigDecimal(100));
		}
		settlementCurrency = ibObj.getCurrency();
		EarlySettlementDetailsRq req = new EarlySettlementDetailsRq();
		EarlySettlementDetails earlySettlementDetails = new EarlySettlementDetails();
		earlySettlementDetails.setDealID(getDealID(ibObj));
		earlySettlementDetails.setProduct(dealDetails.getF_ProductCode());
		earlySettlementDetails.setValueDate(IBCommonUtils.getCurrentBusinessDate());
		earlySettlementDetails.setSettlementCurrency(ibObj.getCurrency());
		earlySettlementDetails.setPercentageOfUnEarnedProfit(IBCommonUtils.scaleAmount(ibObj.getCurrency(),
				productConfig != null ? productConfig.getDealServices().getGiftAmountPercentage()
						: CommonConstants.BIGDECIMAL_ZERO));
		Amount refundProfitCollAmount = new Amount();
		refundProfitCollAmount
				.setAmountEdited(IBCommonUtils.scaleAmount(settlementCurrency, refundOfUnearnedProfitAmt));
		refundProfitCollAmount.setIsoCurrencyCode(settlementCurrency);
		earlySettlementDetails.setRefundOfUnearnedProfitAmount(refundProfitCollAmount);

		AccountInput collectionAccountInput = new AccountInput();
		collectionAccountInput.setAccountID((String) CeUtils.getUDFValueByName(dealId, "ACC_NUMBER"));
		collectionAccountInput.setAccountFormatType(collectionAccountFormatType);
		earlySettlementDetails.setRepaymentAccount(collectionAccountInput);
		req.setEarlySettlementDetails(earlySettlementDetails);
		bf.com.misys.ib.types.header.RqHeader rqHeader = new bf.com.misys.ib.types.header.RqHeader();
		rqHeader.setMode("UPDATE");
		req.setRqHeader(rqHeader);

		inputParams.put(IBSPIConstants.CREATE_LOAN_PAYOFF_MF_INPUT_PARAMNAME, req);
		HashMap<String, EarlySettlementDetailsRq> param = new HashMap<String, EarlySettlementDetailsRq>();
		param.put(IBSPIConstants.CREATE_LOAN_PAYOFF_MF_INPUT_PARAMNAME, req);
		HashMap<String, Object> outputParams = MFExecuter.executeMF(IBSPIConstants.CREATE_LOAN_PAYOFF_MFID,
				IBCommonUtils.getBankFusionEnvironment(), param);
		EarlySettlementDetailsRs earlySettlementDetailsRs = (EarlySettlementDetailsRs) outputParams
				.get(IBSPIConstants.CREATE_LOAN_PAYOFF_MF_OUTPUT_PARAMNAME);
		LOGGER.info("Existing Loan closed " + earlySettlementDetailsRs.getRsHeader().getStatus().toString());

		return earlySettlementDetailsRs;

	}

	private void loadProductConfigurations(IslamicBankingObject ibObj) {
		productConfig = IBCommonUtils.loadProductConfiguration(ibObj.getDealID());
	}

	private DealIDInput getDealID(IslamicBankingObject ibObj) {

		DealIDInput dealIdInput = new DealIDInput();
		dealIdInput.setDealID(ibObj.getDealID());
		dealIdInput.setDealBranch(dealDetails.getF_BranchSortCode());
		dealIdInput.setSubProductID(ibObj.getSubProductID());
		return dealIdInput;
	}

	private IBOIB_DLI_DealDetails getDealDetails(String dealId) {
		if (StringUtils.isNotEmpty(dealId)) {
			dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealId, false);
		}
		return dealDetails;

	}

}
