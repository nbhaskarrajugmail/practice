package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RequestEvaluationCalculations;
import com.ce.bankfusion.ib.util.CalculationRequestEvaluationUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;

public class RequestEvaluationCalculations extends AbstractCE_IB_RequestEvaluationCalculations{
	
	private static final long serialVersionUID = 1L;

    public RequestEvaluationCalculations() {
        super();
    }

    public RequestEvaluationCalculations(BankFusionEnvironment env) {

    }

    public void process(BankFusionEnvironment env) throws BankFusionException {
    	
    	String mode = getF_IN_MODE();
    	
    	
    	
        switch (mode) {
        case "TITLEDEEDAGRICULTURE_MODE":
        	setF_OUT_getTotalEvaluationValueOfAgriculture
        	(CalculationRequestEvaluationUtils.getTotalEvaluationValueOfAgriculture
        	(getF_IN_agricultureDetails(), getF_IN_titleDeedListAgriculture(), getF_IN_wellDetails(), getF_IN_wellDetailsList(), getF_IN_treeDetails(), getF_IN_treesDetailsList(), getF_IN_buildingDetails(), getF_IN_buildingsDetailsList()));
            
        	setF_OUT_getNetEvaluationValueOfAgriculture
        	(CalculationRequestEvaluationUtils.getNetEvaluationValueOfAgriculture(getF_IN_agricultureDetails(), getF_IN_titleDeedListAgriculture(), getF_IN_wellDetails(), getF_IN_wellDetailsList(), getF_IN_treeDetails(), getF_IN_treesDetailsList(), getF_IN_buildingDetails(), getF_IN_buildingsDetailsList(), getF_IN_titleDeedNum(), getF_IN_islamicBankingObject()));
            break;

        case "TITLEDEEDRESIDENTIAL_MODE":
        	setF_OUT_getTotalEvaluationValueResidential
        	(CalculationRequestEvaluationUtils.getTotalEvaluationValueResidential(getF_IN_residentialDetails(), getF_IN_titleDeedListResidential()));
        	
        	setF_OUT_getNetEvaluationValueResidential
        	(CalculationRequestEvaluationUtils.getNetEvaluationValueResidential
        	(getF_IN_collateralRequestDetails(),getF_IN_residentialDetails(), getF_IN_titleDeedListResidential(), getF_IN_titleDeedNum(), getF_IN_islamicBankingObject()));
            
            break;
        case "LAND_MODE":
        	setF_OUT_getCostOfLandAgriculture
        	(CalculationRequestEvaluationUtils.getCostOfLandAgriculture(getF_IN_agricultureDetails(), getF_IN_titleDeedListAgriculture()));
            
            break;
        case "TREES_MODE":
        	
        	setF_OUT_getCostPerTreesAgriculture(CalculationRequestEvaluationUtils.getCostPerTreesAgriculture(getF_IN_treeDetails()));
        	
        	
        	setF_OUT_getCostOfTreesAgriculture
        	(CalculationRequestEvaluationUtils.getCostOfTreesAgriculture(getF_IN_treeDetails(), getF_IN_treesDetailsList()));
        	
        	
            
            break;
            
        
        case "BUILDINGS_MODE":
        	setF_OUT_getCostPerBuildingAgriculture(CalculationRequestEvaluationUtils.getCostPerBuildingAgriculture(getF_IN_buildingDetails()));
        	
            
        	setF_OUT_getCostOfBuildingAgriculture
        	(CalculationRequestEvaluationUtils.getCostOfBuildingAgriculture(getF_IN_buildingDetails(), getF_IN_buildingsDetailsList()));
        	
            
            break;
            
        
		case "WELLS_MODE":
			setF_OUT_getCostOfWellsAgriculture
			(CalculationRequestEvaluationUtils.getCostOfWellsAgriculture(getF_IN_wellDetails(), getF_IN_wellDetailsList()));
		
			break;
			
			
		case "MORTGAGEAMOUNTAGRICULTURE_MODE":
			setF_OUT_getMortgageAmtForAgriculture
			(CalculationRequestEvaluationUtils.getMortgageAmtForAgriculture(getF_IN_titleDeedNum(), getF_IN_islamicBankingObject()));
        	
			break;
	
		case "MORTGAGEAMOUNTRESIDENTIAL_MODE":
			setF_OUT_getMortgageAmtForResidential
        	(CalculationRequestEvaluationUtils.getMortgageAmtForResidential(getF_IN_titleDeedNum(), getF_IN_islamicBankingObject()));
        	
			break;
	
		    default:
            break;

        }
 

    }




}
