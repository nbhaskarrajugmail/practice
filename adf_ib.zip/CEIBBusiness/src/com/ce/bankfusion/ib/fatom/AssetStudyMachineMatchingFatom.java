package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetStudyMachineMatching;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetRegistryDtl;
import bf.com.misys.ib.types.AssetRegistryList;
import bf.com.misys.ib.types.AssetThirdPartyDetails;

public class AssetStudyMachineMatchingFatom extends AbstractCE_IB_AssetStudyMachineMatching{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(AssetStudyMachineMatchingFatom.class.getName());
	private static Integer E_ASSET_REGISTRY_AMOUNT_LESS = 44000292;
	private static Integer E_ASSET_REGISTRY_RATE_LESS = 44000324;
	
	@SuppressWarnings("deprecation")
    public AssetStudyMachineMatchingFatom(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	if(getF_IN_mode().equalsIgnoreCase("MATCH")) {
    		AssetStudyAndInfoUtil.validateMaxRateChange(getF_IN_islamicBankingObject().getProcessConfigID(), getF_IN_assetThirdPartyDetails(), getF_IN_attribute7Calculated(), getF_IN_attribute8Calculated(), getF_IN_attribute9Calculated(),
    				getF_IN_attribute7Label(), getF_IN_attribute8Label(), getF_IN_attribute9Label());
    		matchRegistry();
    	}else {
    		calculateStudyCost();
    	}
    }

	private void calculateStudyCost() {
		//get the selected registries and set to calculated cost
		AssetRegistryList assetRegistryList = getF_IN_selectedRegistryList();
		AssetRegistryList allAssetRegistryList = getF_IN_assetRegistryList();
		BFCurrencyAmount calculatedCost = new BFCurrencyAmount();
		BigDecimal cost = BigDecimal.ZERO;
		BigDecimal att7Cost = BigDecimal.ZERO;
		BigDecimal att8Cost = BigDecimal.ZERO;
		BigDecimal att6Cost = BigDecimal.ZERO;
		String assetSerial = getF_IN_assetThirdPartyDetails().getAssetSerial();
		for(AssetRegistryDtl assetRegistryDtl : allAssetRegistryList.getAssetRegistryList()) {
			if(assetRegistryDtl.getAssetSerial().equals(assetSerial)) {
				allAssetRegistryList.removeAssetRegistryList(assetRegistryDtl);
			}
		}
		for(AssetRegistryDtl assetRegistryDtl : assetRegistryList.getAssetRegistryList()) {
			if(assetRegistryDtl.isSelect()) {
				allAssetRegistryList.addAssetRegistryList(assetRegistryDtl);
				cost = cost.add(assetRegistryDtl.getPrice().getCurrencyAmount());
				IBOCE_IB_RegistryAssetCfg registryAssetCfg = (IBOCE_IB_RegistryAssetCfg) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_RegistryAssetCfg.BONAME, assetRegistryDtl.getRegistrySerial(),true);
				att6Cost = att7Cost.add(registryAssetCfg.getF_IBATTRIBUTE1());
				att7Cost = att8Cost.add(registryAssetCfg.getF_IBATTRIBUTE2());
				att8Cost = att6Cost.add(registryAssetCfg.getF_IBATTRIBUTE3());
			}
		}
		validateSelectedRegistryAssets(cost, att7Cost, att8Cost, att6Cost);
		calculatedCost.setCurrencyAmount(cost);
		setF_OUT_machineCalculatedCost(calculatedCost);
		setF_OUT_selectedRegistryList(allAssetRegistryList);
	}

	

	private void matchRegistry() {
		List<IBOCE_IB_RegistryAssetCfg> registryMatchingList = getMatchedRegistryAssetCfgList(); 
		
		List<String> uniqueRegistryIds = getLatestRegistryIdsByDuplicateRef(registryMatchingList);
		AssetRegistryList assetRegistryList = new AssetRegistryList();
		List<String> alreadySelectedIds = new ArrayList();
		for(AssetRegistryDtl asstRegDtl : getF_IN_assetRegistryList().getAssetRegistryList()) {
			if(getF_IN_assetThirdPartyDetails().getAssetSerial().equals(asstRegDtl.getAssetSerial())) {
				alreadySelectedIds.add(asstRegDtl.getRegistrySerial());
			}
		}
		
		for(IBOCE_IB_RegistryAssetCfg dbRegistryAstCfg : registryMatchingList) {
			if(uniqueRegistryIds.contains(dbRegistryAstCfg.getF_IBREGISTRYID())) {
				AssetRegistryDtl assetRegistryDtl = AssetStudyAndInfoUtil.getRegAstCfg(dbRegistryAstCfg);
				assetRegistryDtl.setSelect(alreadySelectedIds.contains(assetRegistryDtl.getRegistrySerial()));
				assetRegistryDtl.setAssetSerial(getF_IN_assetThirdPartyDetails().getAssetSerial());
				assetRegistryList.addAssetRegistryList(assetRegistryDtl);
			}
		}
		setF_OUT_matchedRegistryList(assetRegistryList);
	}
	
	private List<IBOCE_IB_RegistryAssetCfg> getMatchedRegistryAssetCfgList() {
		String query = " WHERE "+IBOCE_IB_RegistryAssetCfg.IBASSETCATEGORY+" = ? ";
		AssetThirdPartyDetails assetThirdPartyDetail = getF_IN_assetThirdPartyDetails();
		ArrayList params = new ArrayList();
		IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, assetThirdPartyDetail.getAssetCategory().getCategory(),
						true);
		String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
		params.add(parentCategoryID);
		if(assetThirdPartyDetail.getMachineType()!=null && !assetThirdPartyDetail.getMachineType().isEmpty()) {
			query = query + " AND "+IBOCE_IB_RegistryAssetCfg.IBMACHINETYPE+" =? ";
			params.add(assetThirdPartyDetail.getMachineType());
			LOGGER.info("Machine Type : "+ assetThirdPartyDetail.getMachineType());
		}
		if(assetThirdPartyDetail.getAttribute6()!=null && assetThirdPartyDetail.getAttribute6().compareTo(BigDecimal.ZERO)!=0) {
			query = query + " AND "+IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE1+" <=? ";
			params.add(assetThirdPartyDetail.getAttribute6());
			LOGGER.info("Attribute6 : "+ assetThirdPartyDetail.getAttribute6());
		}
		if(assetThirdPartyDetail.getAttribute7()!=null && assetThirdPartyDetail.getAttribute7().compareTo(BigDecimal.ZERO)!=0) {
			query = query + " AND "+IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE2+" <=? ";
			params.add(assetThirdPartyDetail.getAttribute7());
			LOGGER.info("Attribute7 : "+ assetThirdPartyDetail.getAttribute7());
		}
		if(assetThirdPartyDetail.getAttribute8()!=null && assetThirdPartyDetail.getAttribute8().compareTo(BigDecimal.ZERO)!=0) {
			query = query + " AND "+IBOCE_IB_RegistryAssetCfg.IBATTRIBUTE3+" <=? ";
			params.add(assetThirdPartyDetail.getAttribute8());
			LOGGER.info("Attribute8 : "+ assetThirdPartyDetail.getAttribute8());
		}
		
		LOGGER.info("Query for matching the asset registries :"+query);
		return BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_RegistryAssetCfg.BONAME, query, params, null, false);
	}
	
	private void validateSelectedRegistryAssets(BigDecimal cost, BigDecimal att7Cost, BigDecimal att8Cost,
			BigDecimal att6Cost) {
		AssetThirdPartyDetails assetThirdPartyDtl = getF_IN_assetThirdPartyDetails();
		if(!getF_IN_editMode().equals(CeConstants.ASSET_REPLACEMENT_MODE) && assetThirdPartyDtl.getOriginalAssetCost().getCurrencyAmount().compareTo(cost)<0) {
			String[] parms = new String[2];
			parms[0] = "Original Cost";
			parms[1] = assetThirdPartyDtl.getOriginalAssetCost().getCurrencyAmount().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_REGISTRY_AMOUNT_LESS, parms);
		}
		if(assetThirdPartyDtl.getAttribute6().compareTo(BigDecimal.ZERO)!=0 && assetThirdPartyDtl.getAttribute6().compareTo(att6Cost)<0) {
			String[] parms = new String[2];
			parms[0] = getF_IN_attribute9Label();//This is modified to Attribute 6 for Machines not Attribute 9
			parms[1] = assetThirdPartyDtl.getAttribute6().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_REGISTRY_RATE_LESS, parms);
		}
		if(assetThirdPartyDtl.getAttribute7().compareTo(BigDecimal.ZERO)!=0 && assetThirdPartyDtl.getAttribute7().compareTo(att7Cost)<0) {
			String[] parms = new String[2];
			parms[0] = getF_IN_attribute7Label();
			parms[1] = assetThirdPartyDtl.getAttribute7().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_REGISTRY_RATE_LESS, parms);
		}
		if(assetThirdPartyDtl.getAttribute8().compareTo(BigDecimal.ZERO)!=0 && assetThirdPartyDtl.getAttribute8().compareTo(att8Cost)<0) {
			String[] parms = new String[2];
			parms[0] = getF_IN_attribute8Label();
			parms[1] = assetThirdPartyDtl.getAttribute8().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_REGISTRY_RATE_LESS, parms);
		}
		
	}
	
	private List<String> getLatestRegistryIdsByDuplicateRef(List<IBOCE_IB_RegistryAssetCfg> registryMatchingList) {
		//With the registry ids find the same reference numbers. and if reference numbers matched keep only latest one
				List<String> regIdList = new ArrayList<>();
				if(registryMatchingList.isEmpty()) {
					return regIdList;
				}
				StringBuilder registryQuery = new StringBuilder(" WHERE "+IBOCE_IB_RegistryListCfg.IBREGISTRYID+" in (");
				ArrayList params = new ArrayList();
				Map<String, List<String>> refRegistryMap = new HashMap<String, List<String>>();
				for(IBOCE_IB_RegistryAssetCfg dbRegistryAstCfg : registryMatchingList) {
					params.add(dbRegistryAstCfg.getF_IBREGISTRYID());
					registryQuery.append("?,");
				}
				registryQuery.replace(registryQuery.length()-1, registryQuery.length(), "");
				registryQuery.append(")");
				List<IBOCE_IB_RegistryListCfg> registryCfgList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_RegistryListCfg.BONAME, registryQuery.toString(), params, null, false);
				Map<String, List<IBOCE_IB_RegistryListCfg>> referenceWiseList = new HashMap<>();
				for(IBOCE_IB_RegistryListCfg registryCfg : registryCfgList) {
					if(referenceWiseList.containsKey(registryCfg.getF_IBREFERENCENUMBER())) {
						List<IBOCE_IB_RegistryListCfg> regList = referenceWiseList.get(registryCfg.getF_IBREFERENCENUMBER());
						regList.add(registryCfg);
						referenceWiseList.put(registryCfg.getF_IBREFERENCENUMBER(), regList);
					}else {
						List<IBOCE_IB_RegistryListCfg> regList = new ArrayList<>();
						regList.add(registryCfg);
						referenceWiseList.put(registryCfg.getF_IBREFERENCENUMBER(), regList);
					}
				}
				List<String> uniqueRegistryIds = new ArrayList<>();
				for(String refNumber : referenceWiseList.keySet()) {
					String registryId = null;
					Date regDate = null;
					for(IBOCE_IB_RegistryListCfg dupConfig : referenceWiseList.get(refNumber)) {
						if(registryId == null || dupConfig.getF_IBREGISTRYDATE().compareTo(regDate)>0) {
							registryId = dupConfig.getBoID();
							regDate = dupConfig.getF_IBREGISTRYDATE();
						}
					}
					uniqueRegistryIds.add(registryId);
				}
				LOGGER.info("Unique registry ids were :"+uniqueRegistryIds);
				return uniqueRegistryIds;
	}
}
