package com.ce.bankfusion.ib.fatom;

import bf.com.misys.followup.ib.types.FollowUpAssignmentCnf;
import bf.com.misys.followup.ib.types.FollowUpCnfList;
import bf.com.misys.ib.ilo.types.UserDetails;
import bf.com.misys.ib.ilo.types.UserList;

import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetFollowUpBranch;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.util.IBCommonUtils;

public class GetFollowUpBranch extends AbstractCE_IB_GetFollowUpBranch {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public GetFollowUpBranch() {
        super();
    }

    public GetFollowUpBranch(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        boolean isAdmin = CeUtils.isloggedInUserFromAdfFollowUpUserGroup();
        setF_OUT_setInspectorReadOnly(false);
        FollowUpCnfList followUpCnfList = getF_IN_followUpConfList();
        FollowUpAssignmentCnf[] followUpAssignmentData = followUpCnfList.getFollowUpAssignmentCnfDtls();
        for (FollowUpAssignmentCnf cfg : followUpAssignmentData) {
            if (null != cfg && cfg.isSelect()) {
                UserList user = new UserList();
                if (!isAdmin) { // locale user
                    if (!IBCommonUtils.isNullOrEmpty(cfg.getFollowUpBranch())) {
                        if (!cfg.getFollowUpBranch().equals(CeUtils.getUserBranchCode())) {
                            setF_OUT_setInspectorReadOnly(true);
                        }
                        user = CeUtils.getUserList(cfg.getFollowUpBranch());
                        setF_OUT_branch(cfg.getFollowUpBranch());
                        if (!IBCommonUtils.isNullOrEmpty(cfg.getInspectorName())) {
                            for (UserDetails userDetails : user.getUserDetailsList()) {
                                if (!IBCommonUtils.isNullOrEmpty(userDetails.getUserName())
                                    && userDetails.getUserName().equals(cfg.getInspectorName()))
                                    userDetails.setSelect(true);
                            }
                        } else {
                            user.addUserDetailsList(0, new UserDetails());
                            user.getUserDetailsList(0).setSelect(true);
                        }
                    } else {
                        user = CeUtils.getUserList(CeUtils.getUserBranchCode());
                        if (user != null && user.getUserDetailsListCount() > 0)
                            user.addUserDetailsList(0, new UserDetails());
                        setF_OUT_branch(CeUtils.getUserBranchCode());
                        user.getUserDetailsList(0).setSelect(true);
                    }
                    setF_OUT_userList(user);
                } else {
                    if (!IBCommonUtils.isNullOrEmpty(getF_IN_branchSelected()))
                        user = CeUtils.getUserList(getF_IN_branchSelected());
                    if (user != null && user.getUserDetailsListCount() > 0) {
                        if (!IBCommonUtils.isNullOrEmpty(cfg.getInspectorName())) {
                            for (UserDetails userDetails : user.getUserDetailsList()) {
                                if (!IBCommonUtils.isNullOrEmpty(userDetails.getUserName())
                                    && userDetails.getUserName().equals(cfg.getInspectorName()))
                                    userDetails.setSelect(true);
                            }
                        } else {
                            user.addUserDetailsList(0, new UserDetails());
                            user.getUserDetailsList(0).setSelect(true);
                        }
                    }
                    setF_OUT_branch(getF_IN_branchSelected());
                    setF_OUT_userList(user);
                }
            }
        }
        setF_OUT_isLocaleUser(!isAdmin);
        followUpCnfList.setFollowUpAssignmentCnfDtls(followUpAssignmentData);
        setF_OUT_followUpConfList(followUpCnfList);
    }

}
