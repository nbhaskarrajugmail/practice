package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ValidateCollateral;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCollateral;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.ib.types.IslamicBankingObject;

public class ValidateCollateral extends AbstractCE_IB_ValidateCollateral{
  
  /**
   * 
   */
  private static final long serialVersionUID = 4464960737488864750L;

  public ValidateCollateral()
  {
    super();
  }
  
  public ValidateCollateral(BankFusionEnvironment env)
  {
    super(env);
  }
  
  @Override
  public void process(BankFusionEnvironment env)
  {
    
    IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
    ErrorResponse errorResponse = new ErrorResponse();
    
    BigDecimal totalCollateralValue = BigDecimal.ZERO;
    
    IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    
    String whereClause = " WHERE " + IBOIB_IDI_DealCollateral.DEALNO + " = ?";
    
    ArrayList params = new ArrayList<>();
    params.add(ibObject.getDealID());
    List<IBOIB_IDI_DealCollateral> dealCollaterals=factory.findByQuery(IBOIB_IDI_DealCollateral.BONAME, whereClause, params, null, false);
        
    for(IBOIB_IDI_DealCollateral dealCollateral:dealCollaterals) {
      totalCollateralValue = totalCollateralValue.add(dealCollateral.getF_AMOUNT());
    }
    
    IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(ibObject.getDealID());
    
    String validateON = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.COLLATERAL_CUSTOM_CONF_FILE,
              CeConstants.VALIDATE_ON, "", CeConstants.ADFIBCONFIGLOCATION);
    
    if((validateON.equalsIgnoreCase("DA") && totalCollateralValue.compareTo(dealDtls.getF_DealAmt()) >= 0) || 
        (validateON.equalsIgnoreCase("PA") && totalCollateralValue.compareTo(dealDtls.getF_PrincipleAmt()) >= 0))
      errorResponse.setOVERALLSTATUS("VALIDATED");
    else
      errorResponse.setOVERALLSTATUS("NOTCOVERED");
    /*
     * If total collateral value(cover value) is less than deal/ principal amount and it is approved by approver in deal validation
     * exception bb then overall status is set as validated.
     */
    String query = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ?";
    List<IBOCE_IB_DealValidations> dealValidationsList =
        factory.findByQuery(IBOCE_IB_DealValidations.BONAME, query, params, null, false);
    if (null != dealValidationsList && !dealValidationsList.isEmpty()) {
        for (IBOCE_IB_DealValidations dealValidations : dealValidationsList) {
            if (ValidationExceptionConstants.STATUS_APPROVED.equals(dealValidations.getF_IBSTATUS())) {
                errorResponse.setOVERALLSTATUS("VALIDATED");
            }
        }
    } 
    setF_OUT_response(errorResponse);
    setF_OUT_islamicBankingObject(ibObject);
    
  }

}