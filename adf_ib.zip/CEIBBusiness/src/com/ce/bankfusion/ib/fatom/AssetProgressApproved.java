package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressingApproved;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class AssetProgressApproved extends AbstractCE_IB_AssetProgressingApproved{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(AssetProgressApproved.class.getName());
	private static final String APPROVAL_STEP = "APPROVAL";
	
	private static final String STATUS_APPROVED = "Approved";
	private static final String STATUS_NEW = "New";
	private static final String STATUS_PROCESSED = "Processed";
	private static final String OPERATIONAL_STEP = "OPERATIONAL";
	private static String GET_REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBDEALNO+" = ? AND "+IBOCE_IB_AssetProgressReport.IBSTATUS+" = ?";
	private static String GET_ISSUEPO_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_IssuePODetail.IBDEALID+" = ? AND "+IBOCE_IB_IssuePODetail.IBSTATUS+" = ?";
	
	@SuppressWarnings("deprecation")
    public AssetProgressApproved(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	IBOIB_CFG_StepDetails stepDetails= IBCommonUtils.getStepDetails(getF_IN_islamicBankingObject().getStepID(), getF_IN_islamicBankingObject().getProcessConfigID());
    	if(stepDetails!=null && stepDetails.getF_STEPTYPE().equalsIgnoreCase(APPROVAL_STEP) && !isF_IN_isIssuePO()) {
    		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add(STATUS_NEW);
			List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
			for(IBOCE_IB_AssetProgressReport report : assetProgressReportList) {
				report.setF_IBREVIEWER(env.getUserSession().getUserId());
				report.setF_IBSTATUS(STATUS_APPROVED);
			}
    	}
    	if(stepDetails!=null && stepDetails.getF_STEPTYPE().equalsIgnoreCase(OPERATIONAL_STEP) && !isF_IN_isIssuePO()) {
    		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add(STATUS_APPROVED);
			List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
			for(IBOCE_IB_AssetProgressReport report : assetProgressReportList) {
				report.setF_IBSTATUS(STATUS_PROCESSED);
			}
    	}
    	
    	if(stepDetails!=null && stepDetails.getF_STEPTYPE().equalsIgnoreCase(APPROVAL_STEP) && isF_IN_isIssuePO()) {
    		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add(STATUS_NEW);
			List<IBOCE_IB_IssuePODetail> issuePODetails = factory.findByQuery(IBOCE_IB_IssuePODetail.BONAME, GET_ISSUEPO_BY_DEAL_QUERY, params, null, true);
			for(IBOCE_IB_IssuePODetail  poDetail: issuePODetails) {
				poDetail.setF_IBSTATUS(STATUS_APPROVED);
			}
    	}
    	if(stepDetails!=null && stepDetails.getF_STEPTYPE().equalsIgnoreCase(OPERATIONAL_STEP) && isF_IN_isIssuePO()) {
    		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(getF_IN_islamicBankingObject().getDealID());
			params.add(STATUS_APPROVED);
			List<IBOCE_IB_IssuePODetail> issuePODetails = factory.findByQuery(IBOCE_IB_IssuePODetail.BONAME, GET_ISSUEPO_BY_DEAL_QUERY, params, null, true);
			for(IBOCE_IB_IssuePODetail  poDetail: issuePODetails) {
				poDetail.setF_IBSTATUS(STATUS_PROCESSED);
			}
    	}
    }
}
