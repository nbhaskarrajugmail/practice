package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistCreateCollateralDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_PersistCreateCollateralDetails;
import com.ce.bankfusion.ib.util.CollateralUtil;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealcustcollateral.dtls.ib.types.CreateCollateralRqDetails;

public class PersistCreateCollateralDetails extends AbstractCE_IB_PersistCreateCollateralDetails
        implements ICE_IB_PersistCreateCollateralDetails {

    private static final transient Log LOGGER = LogFactory.getLog(PersistCreateCollateralDetails.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public PersistCreateCollateralDetails() {
        // TODO Auto-generated constructor stub
    }

    public PersistCreateCollateralDetails(BankFusionEnvironment env) {
        super(env);

    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process -->" + getF_IN_ibObject().getDealID());
        if (getF_IN_createCollateralRqDetailsList().getCreateCollateralRqDetailsListCount() > 0 && !isF_IN_isViewOnly()) {
            removeTheDeletedCollaterals();
            for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralRqDetailsList()
                    .getCreateCollateralRqDetailsList()) {
                IBOCE_IB_DealCollateralDtls existingCollateralDetails = (IBOCE_IB_DealCollateralDtls) factory
                        .findByPrimaryKey(IBOCE_IB_DealCollateralDtls.BONAME, createCollateralRqDetails.getCollateralID(), true);
                if (null != existingCollateralDetails) {
                    updateExistingRecord(env, createCollateralRqDetails, existingCollateralDetails);
                }
                else {
                    createNewRecord(env, createCollateralRqDetails);
                }
                factory.commitTransaction();
            }
        }
        else if (getF_IN_createCollateralRqDetailsList().getCreateCollateralRqDetailsListCount() == 0)
            removeTheDeletedCollaterals();
        LOGGER.info("Exiting from process -->" + getF_IN_ibObject().getDealID());
    }

    private void removeTheDeletedCollaterals() {
        StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + "= ? ");
        ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_ibObject().getDealID());
        	for (CreateCollateralRqDetails createCollateralRqDetails : getF_IN_createCollateralRqDetailsList()
                .getCreateCollateralRqDetailsList()) {
        		if (IBCommonUtils.isNotEmpty(createCollateralRqDetails.getCollateralID())) {
                queryCondition.append(" AND " + IBOCE_IB_DealCollateralDtls.IBCOLLATERALID + " != ? ");
                params.add(createCollateralRqDetails.getCollateralID());
        		}
        	}
        	if(!getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
                params.add("");
                queryCondition.append(" AND (" + IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID + "= ? OR " + IBOCE_IB_DealCollateralDtls.IBTRANSACTIONID +" IS NULL )");
        		}
        factory.bulkDeleteall(IBOCE_IB_DealCollateralDtls.BONAME, queryCondition.toString(), params);
        factory.commitTransaction();
        factory.beginTransaction();
    }

    private void updateExistingRecord(BankFusionEnvironment env, CreateCollateralRqDetails createCollateralRqDetails,
            IBOCE_IB_DealCollateralDtls existingCollateralDetails) {
        existingCollateralDetails.setF_IBCOLLATERALTYPE(createCollateralRqDetails.getCollateralType());
        existingCollateralDetails.setF_IBCOVERVALUE(createCollateralRqDetails.getCoverValue().getCurrencyAmount());
        existingCollateralDetails.setF_IBDEALID(getF_IN_ibObject().getDealID());
        existingCollateralDetails.setF_IBDESCRIPTION(createCollateralRqDetails.getDescription());
        existingCollateralDetails.setF_IBDOCUMENTDATE(createCollateralRqDetails.getDocDate());
        existingCollateralDetails.setF_IBDOCUMENTNUMBER(createCollateralRqDetails.getDocnum());
        existingCollateralDetails.setF_IBDOCUMENTSOURCE(createCollateralRqDetails.getDocSourceId());
        existingCollateralDetails.setF_IBEXPIRYDATE(createCollateralRqDetails.getExpiryDate());
        existingCollateralDetails.setF_IBISDOCUPLOADED(createCollateralRqDetails.getIsDocUploaded());
        existingCollateralDetails.setF_IBMODIFIEDBY(env.getUserID());
        existingCollateralDetails.setF_IBMODIFIEDDTTM(IBCommonUtils.getBFBusinessDateTime());
        existingCollateralDetails.setF_IBREQUESTID(createCollateralRqDetails.getRequestID());
        existingCollateralDetails.setF_IBREQUESTTYPE(createCollateralRqDetails.getRequestType());
        existingCollateralDetails.setF_IBREVIEWDATE(AddDaysToDate.run(createCollateralRqDetails.getExpiryDate(), -1));
    }

    private void createNewRecord(BankFusionEnvironment env, CreateCollateralRqDetails createCollateralRqDetails) {
        IBOCE_IB_DealCollateralDtls newDealRelationshipDetailsToBeAdded = (IBOCE_IB_DealCollateralDtls) factory
                .getStatelessNewInstance(IBOCE_IB_DealCollateralDtls.BONAME);
        newDealRelationshipDetailsToBeAdded.setBoID(createCollateralRqDetails.getCollateralID());
        updateExistingRecord(env, createCollateralRqDetails, newDealRelationshipDetailsToBeAdded);
        newDealRelationshipDetailsToBeAdded.setF_IBSYSTEMSTATUS(CollateralUtil.COLLATERAL_SYSTEM_STATUS_NOTPOSTED);
        newDealRelationshipDetailsToBeAdded.setF_IBSTATUS(RescheduleConstants.STATUS_NEW);
        if(!getF_IN_ibObject().getTransactionID().equals(newDealRelationshipDetailsToBeAdded.getF_IBDEALID())) {
            newDealRelationshipDetailsToBeAdded.setF_IBTRANSACTIONID(getF_IN_ibObject().getTransactionID());
        }
        
        factory.create(IBOCE_IB_DealCollateralDtls.BONAME, newDealRelationshipDetailsToBeAdded);
    }

}
