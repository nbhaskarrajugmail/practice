package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_EmailAndSMS;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.fatom.PopulateEmailParams;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.ContextIDs;
import bf.com.misys.ib.types.IslamicBankingObject;

public class EmailAndSMSService extends AbstractCE_IB_EmailAndSMS{
	
	private static Log LOGGER = LogFactory.getLog(EmailAndSMSService.class);
    
    @SuppressWarnings("deprecation")
    public EmailAndSMSService(BankFusionEnvironment env) {
        super(env);
    }
    

    public void process(BankFusionEnvironment env) {
    	LOGGER.info("EmailAndSMSService started");
    	String processConfigID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.EMAIL_SMS_PROPERTY_FILE, CeConstants.EMAIL_SMS_PROCESS_CONFIG_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);
    	String stepID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
    			CeConstants.EMAIL_SMS_PROPERTY_FILE, CeConstants.EMAIL_SMS_STEP_ID, "",
    			CeConstants.ADFIBCONFIGLOCATION);
    	String dealID = getF_IN_dealID();
    	LOGGER.info("Preparing the IslamicBankingObject for DealID:"+dealID);
    	if(null != dealID) {
    		IslamicBankingObject islamicBankingObject = prepareIslamicBankingObject(dealID, processConfigID, stepID); 
    		PopulateEmailParams p = new PopulateEmailParams(env);
    		p.setF_IN_islamicBankingObj(islamicBankingObject);
    		LOGGER.info("Calling the IB Email and SMS service start with processConfigID:"+processConfigID+", stepID:"+stepID);
    		p.process(env);
    		LOGGER.info("Calling the IB Email and SMS service finished");
    	}
    	LOGGER.info("EmailAndSMSService finished");
    }
    
    private IslamicBankingObject prepareIslamicBankingObject(String dealID, String processConfigID, String stepID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        
        IslamicBankingObject islamicBankingObject = null;

        IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
        IBOIB_CFG_ProcessConfig processConfig =
                (IBOIB_CFG_ProcessConfig) factory.findByPrimaryKey(IBOIB_CFG_ProcessConfig.BONAME, dealDetails.getF_PROCESSCONFIGID(), true);
        islamicBankingObject = new IslamicBankingObject();
        islamicBankingObject.setAmount(CommonConstants.BIGDECIMAL_ZERO);
        islamicBankingObject.setApprovalDecision(CommonConstants.EMPTY_STRING);
        // islamicBankingObject.setChargeAmount(dealDetails.get);
        ContextIDs conetextIDs = new ContextIDs();
        islamicBankingObject.setConetextIDs(conetextIDs);
        islamicBankingObject.setControllerMFName(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setCurrency(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setCustomerName(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setDealID(dealID);
        islamicBankingObject.setInitiationDate(SystemInformationManager.getInstance().getBFBusinessDate());
        islamicBankingObject.setIsDealEnquiry(false);
        islamicBankingObject.setIsLastTask(false);
        islamicBankingObject.setMode(IBConstants.BB_MODE_NORMAL);
        islamicBankingObject.setPhaseID(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setParentDealID(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setProcessConfigID(processConfigID);
        islamicBankingObject.setStepID(stepID);
        islamicBankingObject.setApprovalDecision(IBConstants.DECISION_SUBMIT);
        islamicBankingObject.setProductID(dealDetails.getF_ProductCode());
        islamicBankingObject.setSubProductID(dealDetails.getF_ProductContextCode());
        islamicBankingObject.setTransactionID(dealID);
        islamicBankingObject.setTransactionName(processConfig.getF_PROCESSNAME());
        islamicBankingObject.setTerm(CommonConstants.INTEGER_ZERO);
        islamicBankingObject.setTermCode(CommonConstants.EMPTY_STRING);
        islamicBankingObject.setUserID(BankFusionThreadLocal.getUserId());
		islamicBankingObject.setProfitAmount(CommonConstants.BIGDECIMAL_ZERO);
        if (dealDetails != null) {
            islamicBankingObject.setAmount(dealDetails.getF_DealAmt());
            islamicBankingObject.setCurrency(dealDetails.getF_IsoCurrencyCode());
            islamicBankingObject.setInitiationDate(dealDetails.getF_DealInitDate());
            islamicBankingObject.setTerm(dealDetails.getF_DealTerm());
            islamicBankingObject.setTermCode(dealDetails.getF_DEALTERMCODE());
        }
		return islamicBankingObject;
	}
}
