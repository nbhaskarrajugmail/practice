package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_OnTransferOfDebtsRecordSelection;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_OnTransferOfDebtsRecordSelection;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.TransferDebtsHistory;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class OnTransferOfDebtsRecordSelection extends AbstractCE_IB_OnTransferOfDebtsRecordSelection
		implements ICE_IB_OnTransferOfDebtsRecordSelection {
	public OnTransferOfDebtsRecordSelection() {
		super();
	}

	public OnTransferOfDebtsRecordSelection(BankFusionEnvironment env) {
		super(env);
	}

	private static final transient Log LOGGER = LogFactory.getLog(OnTransferOfDebtsRecordSelection.class.getName());

	@Override
	public void process(BankFusionEnvironment env) {
		LOGGER.info("Entering into process method");
		IBOIB_DLI_DealDetails dealDetails = null;
		ReadLoanDetailsRs readLoanDetails = null;
		try {
			for (TransferDebtsHistory transferDebtsHistory : getF_IN_transferDebtsHistoryRq()
					.getTransferDebtsHistorylist()) {
				if (transferDebtsHistory.isSelect()) {
					dealDetails = IBCommonUtils.getDealDetails(transferDebtsHistory.getFromDealID());
					readLoanDetails = IBCommonUtils.getLoanDetails(transferDebtsHistory.getFromDealID());
				}
			}
		} catch (Exception e) {
			LOGGER.info("Dealdetails/ReadLoandetails doesnot exist for DealId " + getF_IN_ibObjext().getDealID());
			throw e;
		}
		getCurrentSchedule(readLoanDetails, dealDetails);
		if (isF_IN_isViewOnly())
			setF_OUT_isViewOnly(isF_IN_isViewOnly());
		else {
			for (TransferDebtsHistory transferDebtsHistory : getF_IN_transferDebtsHistoryRq()
					.getTransferDebtsHistorylist()) {
				if (transferDebtsHistory.isSelect()) {
					// TODO change the Status Reference
					String statusTransferredDesc = IBCommonUtils.getGCChildDesc(CeConstants.TD_STATUS_GC_PARENT_REF,
							CeConstants.TD_STATUS_TRANSFERRED);
					if (statusTransferredDesc.equals(transferDebtsHistory.getStatus())) {
						setF_OUT_isViewOnly(true);
					}
					break;

				}
			}
		}
		LOGGER.info("Exiting from process method");

	}

	private void getCurrentSchedule(ReadLoanDetailsRs readLoanDetails, IBOIB_DLI_DealDetails dealDetails) {
		LOGGER.info("Fetching current schedule from ReadLoan details");
		getF_OUT_transferDebtsHistoryRq().removeAllCePaymentSchedule();
		if (readLoanDetails != null && readLoanDetails.getDealDetails().getPaymentScheduleCount() > 0) {
			for (LoanPayments loanPayments : readLoanDetails.getDealDetails().getPaymentSchedule()) {
				CePaymentSchedule currentSchedule = new CePaymentSchedule();
				currentSchedule.setRepaymentDate(loanPayments.getRepaymentDate());
				currentSchedule.setRepaymentNo(loanPayments.getRepaymentNo());
				currentSchedule.setStatus(IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE,
						loanPayments.getRepaymentStatus()));
				currentSchedule.setPrincipalAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setProfitAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setFeesAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setSubsidyAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				currentSchedule.setTotalRepaymentAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				getF_OUT_transferDebtsHistoryRq().addCePaymentSchedule(currentSchedule);
			}
		}

		ArrayList<Object> params = new ArrayList<>();
		params.add(dealDetails.getBoID());
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";

		// ReadLoan gives fees amount also as profit amount, hence looping through
		// breakup table and fetching amounts
		List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);
		if (breakupDtls != null && !breakupDtls.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : breakupDtls) {
				for (CePaymentSchedule scheduleDetails : getF_OUT_transferDebtsHistoryRq().getCePaymentSchedule()) {
					if (CalendarUtil.IsDate1EqualsToDate2(scheduleDetails.getRepaymentDate(),
							paymentSchBreakup.getF_IBBILLDATE())) {
						scheduleDetails.getPrincipalAmount().setCurrencyAmount(scheduleDetails.getPrincipalAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBPRINCIPALAMT()));
						scheduleDetails.getProfitAmount().setCurrencyAmount(scheduleDetails.getProfitAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBPROFITAMT()));
						scheduleDetails.getFeesAmount().setCurrencyAmount(scheduleDetails.getFeesAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
						scheduleDetails.getSubsidyAmount().setCurrencyAmount(scheduleDetails.getSubsidyAmount()
								.getCurrencyAmount().add(paymentSchBreakup.getF_IBSUBSIDYAMNT()));
						scheduleDetails.getTotalRepaymentAmount()
								.setCurrencyAmount(scheduleDetails.getPrincipalAmount().getCurrencyAmount()
										.add(scheduleDetails.getProfitAmount().getCurrencyAmount())
										.add(scheduleDetails.getFeesAmount().getCurrencyAmount()));
					}
				}
			}
		}
	}
}
