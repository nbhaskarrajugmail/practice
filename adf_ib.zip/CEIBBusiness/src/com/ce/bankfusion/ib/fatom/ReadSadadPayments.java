package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadSadadPayments;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.util.IBConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.SadadPaymentDtlsList;
import bf.com.misys.ib.types.SadadPayments;

public class ReadSadadPayments extends AbstractCE_IB_ReadSadadPayments{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6688803107539240064L;
	private static final Log LOGGER = LogFactory.getLog(ReadSadadPayments.class);

	public ReadSadadPayments()
	{
		super();
	}

	public ReadSadadPayments(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObj = getF_IN_islamicBankingObject();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		SadadPaymentDtlsList sadadPymtList = new SadadPaymentDtlsList();
		String fee_collection_method = CommonConstants.EMPTY_STRING;
		try {
			fee_collection_method = SadadPaymentUtils.queryDealAditionalDtlsUDCheckSADAD(ibObj.getDealID());
		}
		catch(Exception e)
		{
			LOGGER.error("Error occurred during upfrontProfitCollection method value retrieval.");
		}
		if ("SADAD".equalsIgnoreCase(fee_collection_method))
		{
		ArrayList<Object> params = new ArrayList<Object>();
		String unpaidDealChrgListQuery = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ? " + " AND "
		        + IBOIB_DLI_DealAssetChargesdtls.ISUPFRONT + " = ? " + " AND " 
				+ IBOIB_DLI_DealAssetChargesdtls.CHARGEPAYMENTSTATUS + " != ? AND ("
				+ IBOIB_DLI_DealAssetChargesdtls.UNPAIDCHARGEAMOUNT + " > ? OR "
		        + IBOIB_DLI_DealAssetChargesdtls.UNPAIDTAXAMOUNT + " > ?)"; 
		params.add(ibObj.getDealID());
        params.add("Y");
        params.add(IBConstants.WAIVED);
        params.add(CommonConstants.BIGDECIMAL_ZERO);
        params.add(CommonConstants.BIGDECIMAL_ZERO);
        List<IBOIB_DLI_DealAssetChargesdtls> unpaidCharges = factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME,unpaidDealChrgListQuery,params,null,false);
        //preparing the chargeMap for the use in next loop
        HashMap<String, IBOIB_DLI_DealAssetChargesdtls> unpaidChargesMap = new HashMap<>();
        for(IBOIB_DLI_DealAssetChargesdtls unPaidCharge : unpaidCharges)
        {
        	unpaidChargesMap.put(unPaidCharge.getBoID(), unPaidCharge);
        }
        params.clear();
        String sadadPaymentsQuery = "WHERE " + IBOCE_IB_SadadPayments.IBDEALID + " = ? AND "
        		+IBOCE_IB_SadadPayments.IBSTATUS+" NOT IN ('"
        		+CeConstants.SADAD_PYMT_CANCELLED+"','"
        		+CeConstants.SADAD_PYMT_REVERSED+"')"; // may be entries with reversed and cancelled status can be excluded
        params.add(ibObj.getDealID());
        List<IBOCE_IB_SadadPayments> sadadPaymentsList = factory.findByQuery(IBOCE_IB_SadadPayments.BONAME,sadadPaymentsQuery,params,null,false);
        for(IBOCE_IB_SadadPayments sadadPayment : sadadPaymentsList)
        {
        	if(CeConstants.SADAD_PYMT_SCHEDULED.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()))
        	{
        		IBOIB_DLI_DealAssetChargesdtls chargeDtls = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, 
        				sadadPayment.getF_IBDEALCHARGEDTLID(), false);
        		if(IBConstants.WAIVED.equalsIgnoreCase(chargeDtls.getF_CHARGEPAYMENTSTATUS()))
        		{
        		continue;
        		}
        	}
        	SadadPayments sadadPaymentDtl = new SadadPayments();
        	if(unpaidChargesMap.containsKey(sadadPayment.getF_IBDEALCHARGEDTLID()) && !sadadPayment.isF_IBUSERDELETE())
        	{
        		IBOIB_DLI_DealAssetChargesdtls unPaidCharge = unpaidChargesMap.get(sadadPayment.getF_IBDEALCHARGEDTLID());
        		BigDecimal chargeAmount = unPaidCharge.getF_UNPAIDCHARGEAMOUNT().add(unPaidCharge.getF_UNPAIDTAXAMOUNT());
        		//prepares Schedules,On Sadad and Update entries
        		/*
        		1.InvoiceID empty - just schedule it with new amount.
        		2.InvoiceID nonEmpty
        			a. if the unpaidAmt matches - maintain On Sadad
        			b. if the unpaidAmt differs - change to Update Invoice
        		*/
        		if(StringUtils.isBlank(sadadPayment.getF_IBINVOICEID()))
        		{
        			BFCurrencyAmount amount = new BFCurrencyAmount();
        			amount.setCurrencyAmount(chargeAmount);
        			amount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setAmount(amount );
					sadadPaymentDtl.setFeeDesc(unPaidCharge.getF_DUPLICATECHARGENAME());
					sadadPaymentDtl.setFeeID(sadadPayment.getF_IBDEALCHARGEDTLID());
					sadadPaymentDtl.setDelete(false);
					BFCurrencyAmount paidAmount = new BFCurrencyAmount();
					paidAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
					paidAmount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setPaidAmount(paidAmount);
					sadadPaymentDtl.setPaymentID(sadadPayment.getBoID());
					BFCurrencyAmount remainingAmount = new BFCurrencyAmount();
					remainingAmount.setCurrencyAmount(chargeAmount);
					remainingAmount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setRemainingAmount(remainingAmount);
					sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_SCHEDULED);
					sadadPaymentDtl.setStepId(ibObj.getStepID());
					sadadPymtList.addSadadPaymentDtls(sadadPaymentDtl );
        			
        		}
        		else if(StringUtils.isNotBlank(sadadPayment.getF_IBINVOICEID()))
        		{
        			IBOCE_IB_FeesPaymentStatus feePayDtls = (IBOCE_IB_FeesPaymentStatus) factory.findByPrimaryKey(IBOCE_IB_FeesPaymentStatus.BONAME, 
        					sadadPayment.getF_IBINVOICEID(), true);
        			BFCurrencyAmount amount = new BFCurrencyAmount();
        			amount.setCurrencyAmount(chargeAmount);
        			amount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setAmount(amount );
					sadadPaymentDtl.setFeeDesc(unPaidCharge.getF_DUPLICATECHARGENAME());
					sadadPaymentDtl.setFeeID(sadadPayment.getF_IBDEALCHARGEDTLID());
					sadadPaymentDtl.setDelete(false);
					BFCurrencyAmount paidAmount = new BFCurrencyAmount();
					paidAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
					paidAmount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setPaidAmount(paidAmount);
					sadadPaymentDtl.setPaymentID(sadadPayment.getBoID());
					BFCurrencyAmount remainingAmount = new BFCurrencyAmount();
					remainingAmount.setCurrencyAmount(chargeAmount);
					remainingAmount.setCurrencyCode(unPaidCharge.getF_ChargeCurrency());
					sadadPaymentDtl.setRemainingAmount(remainingAmount);
        			if(null != feePayDtls && feePayDtls.getF_IBFEESPAYMENTFAMNT().compareTo(chargeAmount) == 0)
        			{
        				//the just below if condition can be removed
        				//as control will not come here is userDelete is true
        				if(sadadPayment.isF_IBUSERDELETE())
        				{
        					sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_CANCEL);
        					sadadPaymentDtl.setStepId(ibObj.getStepID());
        				}
        				else
        				{
        				sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_ON_SADAD);
        				sadadPaymentDtl.setStepId(sadadPayment.getF_IBSTEPID());
        				}
        			}
        			else
        			{
        				sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_UPDATE);
        				sadadPaymentDtl.setStepId(ibObj.getStepID());
        			}
        			sadadPaymentDtl.setInvoiceDate(sadadPayment.getF_IBINVOICEDATE());
					sadadPaymentDtl.setInvoiceNumber(sadadPayment.getF_IBINVOICEID());
					setUserActionApplicable(sadadPaymentDtl);
					sadadPymtList.addSadadPaymentDtls(sadadPaymentDtl );
        		}
        		
        	}
        	//all other will be ignored.
        	else /*if(CeConstants.SADAD_PYMT_ON_SADAD.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()) || 
        			CeConstants.SADAD_PYMT_PAID.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()))*/
        	{
        		//just add entries - prepares PAID and Cancel Invoice entries
        		/*
        		1. Paid - maintain Paid
        		2. On Sadad - check if unPaid is zero, then Update it to Cancel Invoice
        		*/
        		IBOIB_DLI_DealAssetChargesdtls chargeDtls = (IBOIB_DLI_DealAssetChargesdtls) factory.findByPrimaryKey(IBOIB_DLI_DealAssetChargesdtls.BONAME, 
        				sadadPayment.getF_IBDEALCHARGEDTLID(), false);
        		IBOCE_IB_FeesPaymentStatus feePayDtls = (IBOCE_IB_FeesPaymentStatus) factory.findByPrimaryKey(IBOCE_IB_FeesPaymentStatus.BONAME, 
    					sadadPayment.getF_IBINVOICEID(), true);
        		BigDecimal chargeAmount = chargeDtls.isF_ISWAIVED()?CommonConstants.BIGDECIMAL_ZERO:chargeDtls.getF_UNPAIDCHARGEAMOUNT().add(chargeDtls.getF_UNPAIDTAXAMOUNT());
        		BFCurrencyAmount amount = new BFCurrencyAmount();
        		BFCurrencyAmount paidAmount = new BFCurrencyAmount();
        		BFCurrencyAmount remainingAmount = new BFCurrencyAmount();
        		if(null != feePayDtls && (CeConstants.SADAD_PYMT_ON_SADAD.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()) &&
        				chargeAmount.compareTo(CommonConstants.BIGDECIMAL_ZERO) == 0) ||
        				CeConstants.SADAD_PYMT_CANCEL.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()))
        		{
        			if("STEP".equalsIgnoreCase(chargeDtls.getF_CHARGETYPE()) && !CeConstants.SADAD_PYMT_CANCEL.equalsIgnoreCase(sadadPayment.getF_IBSTATUS()))
        			{
        				sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_ON_SADAD);
        				sadadPaymentDtl.setStepId(sadadPayment.getF_IBSTEPID());
        			}
        			else
        			{
        				sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_CANCEL);
        				sadadPaymentDtl.setStepId(ibObj.getStepID());
        			}
        			sadadPaymentDtl.setDelete(sadadPayment.isF_IBUSERDELETE());
        			amount.setCurrencyAmount(feePayDtls.getF_IBFEESPAYMENTFAMNT());
        			paidAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
        			remainingAmount.setCurrencyAmount(feePayDtls.getF_IBFEESPAYMENTFAMNT());
        		}
        		else
        		{
        			sadadPaymentDtl.setStepId(sadadPayment.getF_IBSTEPID());
        			sadadPaymentDtl.setStatus(sadadPayment.getF_IBSTATUS());
        			sadadPaymentDtl.setDelete(false);
        			amount.setCurrencyAmount(null != feePayDtls?feePayDtls.getF_IBFEESPAYMENTFAMNT():CommonConstants.BIGDECIMAL_ZERO);
        			paidAmount.setCurrencyAmount(null != feePayDtls?feePayDtls.getF_IBFEESPAYMENTFAMNT():CommonConstants.BIGDECIMAL_ZERO);
        			remainingAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
        		}
        		
        		sadadPaymentDtl.setInvoiceDate(sadadPayment.getF_IBINVOICEDATE()); 
				sadadPaymentDtl.setInvoiceNumber(sadadPayment.getF_IBINVOICEID());
    			
    			amount.setCurrencyCode(chargeDtls.getF_ChargeCurrency());
				sadadPaymentDtl.setAmount(amount );
				sadadPaymentDtl.setFeeDesc(chargeDtls.getF_DUPLICATECHARGENAME());
				sadadPaymentDtl.setFeeID(sadadPayment.getF_IBDEALCHARGEDTLID());
				
				
				paidAmount.setCurrencyCode(chargeDtls.getF_ChargeCurrency());
				sadadPaymentDtl.setPaidAmount(paidAmount);
				sadadPaymentDtl.setPaymentID(sadadPayment.getBoID());
				
				
				remainingAmount.setCurrencyCode(chargeDtls.getF_ChargeCurrency());
				sadadPaymentDtl.setRemainingAmount(remainingAmount);
				if(null != feePayDtls)
				{
					sadadPymtList.addSadadPaymentDtls(sadadPaymentDtl );
					setUserActionApplicable(sadadPaymentDtl);
				}
        		
        	}
        	unpaidChargesMap.remove(sadadPayment.getF_IBDEALCHARGEDTLID());
        }
        
        //adding the fresh fees as scheduled from the map "unpaidChargesMap"
        if(!unpaidChargesMap.isEmpty())
        {
        	for(String key : unpaidChargesMap.keySet())
        	{
        		SadadPayments sadadPaymentDtl = new SadadPayments();
        		IBOIB_DLI_DealAssetChargesdtls unScheduledCharge = unpaidChargesMap.get(key);
        		String dealChargeDtlsID = unScheduledCharge.getBoID();
        		String whereClause = "WHERE "+IBOCE_IB_SadadPayments.IBDEALCHARGEDTLID + " = ? AND "
        				+ IBOCE_IB_SadadPayments.IBSTATUS + " = ? AND "
        				+ IBOCE_IB_SadadPayments.IBUSERDELETE + " = ?";
        		ArrayList<String> params1 = new ArrayList<>();
        		params1.add(dealChargeDtlsID);
        		params1.add(CeConstants.SADAD_PYMT_CANCELLED);
        		params1.add("Y");
        		List<IBOCE_IB_SadadPayments> userDeletedEntries = factory.findByQuery(IBOCE_IB_SadadPayments.BONAME, whereClause, params1, null, false);
        		if(null != userDeletedEntries && !userDeletedEntries.isEmpty())
        		{
        			continue;
        		}
        		BigDecimal chargeAmount = unScheduledCharge.getF_UNPAIDCHARGEAMOUNT().add(unScheduledCharge.getF_UNPAIDTAXAMOUNT());
        		BFCurrencyAmount amount = new BFCurrencyAmount();
        		amount.setCurrencyAmount(chargeAmount);
        		amount.setCurrencyCode(unScheduledCharge.getF_ChargeCurrency());
        		sadadPaymentDtl.setAmount(amount );
        		sadadPaymentDtl.setFeeDesc(unScheduledCharge.getF_DUPLICATECHARGENAME());
        		sadadPaymentDtl.setFeeID(unScheduledCharge.getBoID());
        		sadadPaymentDtl.setDelete(false);
        		BFCurrencyAmount paidAmount = new BFCurrencyAmount();
        		paidAmount.setCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO);
        		paidAmount.setCurrencyCode(unScheduledCharge.getF_ChargeCurrency());
        		sadadPaymentDtl.setPaidAmount(paidAmount);
        		//sadadPaymentDtl.setPaymentID(sadadPayment.getBoID());
        		BFCurrencyAmount remainingAmount = new BFCurrencyAmount();
        		remainingAmount.setCurrencyAmount(chargeAmount);
        		remainingAmount.setCurrencyCode(unScheduledCharge.getF_ChargeCurrency());
        		sadadPaymentDtl.setRemainingAmount(remainingAmount);
        		sadadPaymentDtl.setStatus(CeConstants.SADAD_PYMT_SCHEDULED);
        		sadadPaymentDtl.setStepId(ibObj.getStepID());
        		sadadPymtList.addSadadPaymentDtls(sadadPaymentDtl );
        	}
        }
		}
        setF_OUT_sadadPaymentList(sadadPymtList);
        setF_OUT_noOfRows(sadadPymtList.getSadadPaymentDtlsCount());
	}
	
	private void setUserActionApplicable(SadadPayments sadadPaymentDtl) {
		if(CeConstants.SADAD_PYMT_ON_SADAD.equalsIgnoreCase(sadadPaymentDtl.getStatus()) ||
				(CeConstants.SADAD_PYMT_CANCEL.equalsIgnoreCase(sadadPaymentDtl.getStatus()) && sadadPaymentDtl.isDelete()))
		{
			setF_OUT_isUserActionApplicable(true);
		}
	}
}