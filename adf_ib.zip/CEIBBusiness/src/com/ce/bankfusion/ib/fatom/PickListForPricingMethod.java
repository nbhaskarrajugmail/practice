package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PickListForPricingMethod;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.PickList;

public class PickListForPricingMethod extends AbstractCE_IB_PickListForPricingMethod {

	public PickListForPricingMethod(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		String subproductId = CeUtils.getSubproductIdForPickList(getF_IN_inputPayLoad());
		String productId = CeUtils.getProductIdForPickList(getF_IN_inputPayLoad());

		VectorTable result = getProfitMatrixAssociated(subproductId, productId);

		if (result != null && result.size() > 0) {
			for (int i = 0; i < result.size(); i++) {
				HashMap record = result.getRowTags(i);
				PickList pickListItem = CeUtils.getPisckListObject();
				pickListItem.setDescription(record.get(CeConstants.VECTOR_COL_PROFITMATRIXDETAILS_NAME).toString());
				pickListItem.setValues(record.get(CeConstants.VECTOR_COL_PROFITMATRIXDETAILS_PROFITMATRIXID).toString());
				getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
			}
		}

	}

	private VectorTable getProfitMatrixAssociated(String subproductId, String productId) {
		HashMap inputParams = new HashMap();
		inputParams.put(CeConstants.READ_PROFITMATRIX_SRV_INPUT_PRODID, productId);
		inputParams.put(CeConstants.READ_PROFITMATRIX_SRV_INPUT_SUBPRODID, subproductId);
		inputParams.put(CeConstants.READ_PROFITMATRIX_SRV_INPUT_DELFLAG, false);
		inputParams.put(CeConstants.READ_PROFITMATRIX_SRV_INPUT_STATUS, CeConstants.STATUS_ACTIVE);

		HashMap outputParams = MFExecuter.executeMF(CeConstants.READ_PROFITMATRIX_SRV,
				BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);

		VectorTable result = (VectorTable) outputParams.get(CeConstants.READ_PROFITMATRIX_SRV_OUTPUT_RES);
		return result;
	}

}
