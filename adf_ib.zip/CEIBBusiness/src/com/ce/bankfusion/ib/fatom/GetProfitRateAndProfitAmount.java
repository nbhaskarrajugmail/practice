package com.ce.bankfusion.ib.fatom;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.HashMap;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetProfitRateAndProfitAmount;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.ScheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.api.Util.ApiCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ib.types.AssetBasicDtls;
import bf.com.misys.ib.types.AssetBasicDtlsList;

public class GetProfitRateAndProfitAmount extends AbstractCE_IB_GetProfitRateAndProfitAmount {

	private String currencyCode = CommonConstants.EMPTY_STRING;
	private IBOIB_DLI_DealDetails dealDetails;
	private BigDecimal totalProfitAmount;
	private ReadAssetData readAssetData;
	private BigDecimal scheduledProfitAmount;
	private BigDecimal upfrontProfitAmount;
	private boolean isDealEffDateLessThanStartDate;
	private boolean isDealEffDateNWD;
	private boolean isPercentageNeg;
	
    
	public GetProfitRateAndProfitAmount(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		String bbMode = CommonConstants.EMPTY_STRING;
		init();
		if (getF_IN_islamicBankingObject() != null
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_islamicBankingObject().getChannel())
				&& !getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)) {
			bbMode = CeUtils.getBBMode(getF_IN_islamicBankingObject());
		}
		if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)
				|| (!IBCommonUtils.isNullOrEmpty(bbMode) && !bbMode.equals(IBConstants.VIEWMODE))) {
			validateDealEffectiveDate();
			validateUpfrontProfitPercentage();
		}
		if ((getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)
				|| (!IBCommonUtils.isNullOrEmpty(bbMode) && !bbMode.equals(IBConstants.VIEWMODE)))
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_paymentFrequency())
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_pricingMethod())
				&& !IBCommonUtils.isNullOrEmpty(getF_IN_profitMethod()) && !isDealEffDateLessThanStartDate
				&& !isDealEffDateNWD && !isPercentageNeg) {
			readAssetData = CeUtils.readAssetData(getF_IN_islamicBankingObject());
			calculateProfitForProfile();
			setF_OUT_profitAmount(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
			setF_OUT_scheduledProfitAmount(IBCommonUtils.getBFCurrencyAmount(scheduledProfitAmount, currencyCode));
			setF_OUT_upfrontProfitAmount(IBCommonUtils.getBFCurrencyAmount(upfrontProfitAmount, currencyCode));
			if (getF_IN_upfrontProfitPercentage() != null)
				setF_OUT_scheduledProfitPercentage(new BigDecimal(100).subtract(getF_IN_upfrontProfitPercentage()));
			else
				setF_OUT_scheduledProfitPercentage(BigDecimal.ZERO);
		} else {
			if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)
					|| (!IBCommonUtils.isNullOrEmpty(bbMode) && bbMode.equals(IBConstants.VIEWMODE)))
				setDataFromUDFForAPIAndViewMode();
		}
	}

	private void setDataFromUDFForAPIAndViewMode() {
		IBOIB_DLI_DealAditionalDtls dealAditionalDtls = IBCommonUtils.getDealAdditionalDetails(dealDetails.getBoID());
		if (dealAditionalDtls != null) {
			IBOUDFEXTIB_DLI_DealAditionalDtls iboudfextAddtionalDtl = (IBOUDFEXTIB_DLI_DealAditionalDtls) IBCommonUtils
					.getPersistanceFactory()
					.findByPrimaryKey(IBOUDFEXTIB_DLI_DealAditionalDtls.BONAME, dealAditionalDtls.getBoID(), true);
			UserDefinedFields userDefinedFields = iboudfextAddtionalDtl.getUserDefinedFields();
			if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
				for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
					if (userDefinedFld.getFieldName().equals(CeUtils.getUDFIDForProfitAmount()))
						totalProfitAmount = (BigDecimal) userDefinedFld.getFieldValue();
					if (userDefinedFld.getFieldName().equals(CeUtils.getUDFIDForScheduleProfitAmnt()))
						scheduledProfitAmount = (BigDecimal) userDefinedFld.getFieldValue();
					if (userDefinedFld.getFieldName().equals(CeUtils.getUDFIDForUpfrontProfitAmnt()))
						upfrontProfitAmount = (BigDecimal) userDefinedFld.getFieldValue();
					if (userDefinedFld.getFieldName().equals(CeUtils.getUDFIDForScheduleProfitPercentage()))
						setF_OUT_scheduledProfitPercentage((BigDecimal) userDefinedFld.getFieldValue());
				}
			}
		}
		setF_OUT_profitRate(dealDetails.getF_ProfitRate());
		setF_OUT_profitAmount(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		setF_OUT_scheduledProfitAmount(IBCommonUtils.getBFCurrencyAmount(scheduledProfitAmount, currencyCode));
		setF_OUT_upfrontProfitAmount(IBCommonUtils.getBFCurrencyAmount(upfrontProfitAmount, currencyCode));
	}

	private void validateDealEffectiveDate() {
		if (!CalendarUtil.isDateNullOrDefaultDate(getF_IN_dealEffectiveDate())) {
			isDealEffDateLessThanStartDate = ScheduleUtils.validateDealEffDateLessThanStartDate(
					getF_IN_dealEffectiveDate(), dealDetails.getF_DealStartDate());
			isDealEffDateNWD = ScheduleUtils.validateDealEffDateIfNWD(getF_IN_dealEffectiveDate(),
					dealDetails.getBoID());
			if (isDealEffDateLessThanStartDate) {
				setF_OUT_raiseDealStartDateLessThanEvent(true);
				setF_OUT_eventCodeDescription(CeUtils
						.getEventCodeMsg(String.valueOf(CeConstants.E_EFF_DATE_NOT_LESSTHAN_DEALSTARTDATE_CEIB)));
			} else if (isDealEffDateNWD) {
				setF_OUT_raiseNWDEvent(true);
				setF_OUT_eventCodeDescription(
						CeUtils.getEventCodeMsg(String.valueOf(CeConstants.E_DEAL_EFF_DATE_CANNOT_BE_NWD_CEIB)));
			}
		}
		if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)) {
			if (isDealEffDateLessThanStartDate)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_EFF_DATE_NOT_LESSTHAN_DEALSTARTDATE_CEIB);
			if (isDealEffDateNWD)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_EFF_DATE_CANNOT_BE_NWD_CEIB);
		}
	}

	private void init() {
		currencyCode = getF_IN_financialInfoDetail().getPrincipleAmtBFCurr().getCurrencyCode();
		dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
		totalProfitAmount = BigDecimal.ZERO;
		scheduledProfitAmount = BigDecimal.ZERO;
		upfrontProfitAmount = BigDecimal.ZERO;
		isDealEffDateLessThanStartDate = false;
		isDealEffDateNWD = false;
		setF_OUT_profitRate(dealDetails.getF_ProfitRate());
		setF_OUT_profitAmount(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		setF_OUT_scheduledProfitAmount(IBCommonUtils.getBFCurrencyAmount(scheduledProfitAmount, currencyCode));
		setF_OUT_upfrontProfitAmount(IBCommonUtils.getBFCurrencyAmount(upfrontProfitAmount, currencyCode));
	}

	private void calculateProfitForProfile() {

		BigDecimal profitRate = getProfitRateForDeal();
		BigDecimal scheduledProfitPercentage = BigDecimal.ZERO;
		if (getF_IN_upfrontProfitPercentage() != null
				&& getF_IN_upfrontProfitPercentage().compareTo(BigDecimal.ZERO) > 0) {
			scheduledProfitPercentage = new BigDecimal(100).subtract(getF_IN_upfrontProfitPercentage());
		}

		if (profitRate.compareTo(BigDecimal.ZERO) > 0) {
			totalProfitAmount = BigDecimal.ZERO;
			BigDecimal assetProfitAmount = BigDecimal.ZERO;
			AssetBasicDtlsList assetBasicDtlsList = readAssetData.getF_OUT_AssetBasicDtlsList();
			if (assetBasicDtlsList != null && assetBasicDtlsList.getAssetBasicDtlsCount() > 0) {
				for (AssetBasicDtls assetBasicDtls : assetBasicDtlsList.getAssetBasicDtls()) {
					HashMap<String, BigDecimal> profitAmountAndProfitRate = ScheduleUtils.getAssetProfitAmount(
							getF_IN_dealEffectiveDate(), assetBasicDtls.getAssetId(), getF_IN_paymentFrequency(),
							getF_IN_profitMethod(), getF_IN_pricingMethod(), getF_IN_islamicBankingObject(),
							assetBasicDtls.getAssetPrincipalAmount(), readAssetData);
					assetProfitAmount = IBCommonUtils.scaleAmount(currencyCode,profitAmountAndProfitRate.get("profitAmount"));
					if (scheduledProfitPercentage.compareTo(BigDecimal.ZERO) > 0) {
						BigDecimal assetScheduledProfitAmount = IBCommonUtils.scaleAmount(currencyCode,(assetProfitAmount.multiply(scheduledProfitPercentage)
								.divide(new BigDecimal(100))));
						scheduledProfitAmount = scheduledProfitAmount.add(
								assetScheduledProfitAmount);
					}
					totalProfitAmount = totalProfitAmount.add(assetProfitAmount);
				}
				if (scheduledProfitAmount.compareTo(BigDecimal.ZERO) == 0)
					scheduledProfitAmount = totalProfitAmount;
				else
					upfrontProfitAmount = totalProfitAmount.subtract(scheduledProfitAmount);
			}
		}
		setF_OUT_profitRate(profitRate);
	}

	private BigDecimal getProfitRateForDeal() {
		HashMap<String, BigDecimal> profitAmountAndProfitRate = new HashMap<>();
		Date scheduleStartDate = CeUtils.getScheduleStartDate(getF_IN_dealEffectiveDate(), "YEARLY",
				CeUtils.getMinDisbursementPeriod(readAssetData));
		Date scheduleLastPaymentDate = CeUtils.getLastPaymentDate(scheduleStartDate, getF_IN_paymentFrequency(),
				readAssetData, getF_IN_islamicBankingObject().getDealID(), CommonConstants.EMPTY_STRING);
		
		Properties confProperties = new Properties();
		String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
        String filePath = confPath.concat(CeConstants.EXLUCDE_DISBURSE_PERIOD_PRICINGMATRIXID);
        ScheduleUtils.loadConfigPricingMatrixProperties(filePath, confProperties);
        
        if(getF_IN_pricingMethod()!=null && getF_IN_pricingMethod().equals(confProperties.getProperty("ExcludeDisbursePeriod"))) {
        	profitAmountAndProfitRate = ScheduleUtils.getProfitAmountAndProfitRate(
				getF_IN_financialInfoDetail().getPrincipleAmtBFCurr(), getF_IN_dealEffectiveDate(), scheduleStartDate,
				scheduleLastPaymentDate, getF_IN_paymentFrequency(), getF_IN_profitMethod(), getF_IN_pricingMethod(),
				getF_IN_islamicBankingObject());
        }else {
        	profitAmountAndProfitRate = ScheduleUtils.getProfitAmountAndProfitRate(
    				getF_IN_financialInfoDetail().getPrincipleAmtBFCurr(), getF_IN_dealEffectiveDate(), getF_IN_dealEffectiveDate(),
    				scheduleLastPaymentDate, getF_IN_paymentFrequency(), getF_IN_profitMethod(), getF_IN_pricingMethod(),
    				getF_IN_islamicBankingObject());
        }

		if (profitAmountAndProfitRate != null && !profitAmountAndProfitRate.isEmpty()) {
			return profitAmountAndProfitRate.get("profitRate");
		}
		return BigDecimal.ZERO;
	}

	private void validateUpfrontProfitPercentage() {
		if (getF_IN_upfrontProfitPercentage() != null
				&& (BigDecimal.ZERO.compareTo(getF_IN_upfrontProfitPercentage()) > 0
						|| new BigDecimal(100).compareTo(getF_IN_upfrontProfitPercentage()) < 0)) {
			isPercentageNeg = true;
			setF_OUT_raisePercentageError(true);
			setF_OUT_eventCodeDescription(
					CeUtils.getEventCodeMsg(String.valueOf(CeConstants.E_PERCENTAGE_CANNOT_BE_NEG_CEIB)));
		}
		if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API) && isPercentageNeg)
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PERCENTAGE_CANNOT_BE_NEG_CEIB);

	}

}
