package com.ce.bankfusion.ib.fatom;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PartyFinancialDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_MaintainPartyFinancialDetails;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ub.nonfinancial.events.NonFinancialEventCodes;
import com.trapedza.bankfusion.bo.refimpl.IBOCountry;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.ib.types.PartyFinancialDetails;
import bf.com.misys.ib.types.PartyFinancialDetailsList;

public class MaintainPartyFinancialDetails extends AbstractCE_IB_MaintainPartyFinancialDetails  {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Log LOGGER = LogFactory.getLog(MaintainPartyFinancialDetails.class);	
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public MaintainPartyFinancialDetails() {
        super();
    }
	
	@SuppressWarnings("deprecation")
    public MaintainPartyFinancialDetails(BankFusionEnvironment env) {
        super(env);
    }
	
	@Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
		System.err.println();
		if (getF_IN_mode().equals("SAVE")) {
			for (PartyFinancialDetails partyFinancialDetails : getF_IN_partyFinancialDetailsList()
					.getPartyFinancialDetails()) {
				validateCheckSum(partyFinancialDetails.getIBANNumber(), partyFinancialDetails.getBankName(), env);
			}
			IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
					.getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000410);
			businessEventsService.handleEvent(raiseEvent);
			// EventsHelper.handleEvent(44000408, null, new HashMap(), env);
			String WHERE_CLAUSE = "WHERE " + IBOCE_IB_PartyFinancialDetails.IBPARTYID + " = ?";
			ArrayList params = new ArrayList<>();
			params.add(getF_IN_partyFinancialDetailsList().getPartyID());
			factory.bulkDelete(IBOCE_IB_PartyFinancialDetails.BONAME, WHERE_CLAUSE, params);
			for (PartyFinancialDetails partyFinancialDetails : getF_IN_partyFinancialDetailsList()
					.getPartyFinancialDetails()) {
				validateCheckSum(partyFinancialDetails.getIBANNumber(), partyFinancialDetails.getBankName(), env);
				IBOCE_IB_PartyFinancialDetails financialDetails = (IBOCE_IB_PartyFinancialDetails) factory
						.getStatelessNewInstance(IBOCE_IB_PartyFinancialDetails.BONAME);
				financialDetails.setF_IBADDRESS(partyFinancialDetails.getAddress());
				financialDetails.setF_IBBANKACCOUNTNUMBER(partyFinancialDetails.getBankAccountNumber());
				financialDetails.setF_IBBANKNAME(partyFinancialDetails.getBankName());
				//financialDetails.setF_IBBENIFICIARYNAME(partyFinancialDetails.getBenificiaryName());
				financialDetails.setF_IBCOUNTRY(partyFinancialDetails.getCountry());
				financialDetails.setF_IBFOREIGNBANKNAME(partyFinancialDetails.getForeignBankName());
				financialDetails.setF_IBIBANNUMBER(partyFinancialDetails.getIBANNumber());
				financialDetails.setF_IBPARTYID(getF_IN_partyFinancialDetailsList().getPartyID());
				financialDetails.setF_IBPOSTALCODE(partyFinancialDetails.getPostalCode());
				financialDetails.setF_IBSTATUS(partyFinancialDetails.getStatus());
				financialDetails.setF_IBSWIFTCODE(partyFinancialDetails.getSWIFTCode());
				financialDetails.setF_IBTELEPHONE(partyFinancialDetails.getTelephone());
				factory.create(IBOCE_IB_PartyFinancialDetails.BONAME, financialDetails);
			}
		}else {
			PartyFinancialDetailsList partyFinancialDetailsList= getF_OUT_partyFinancialDetailsList();
			partyFinancialDetailsList.setPartyID(getF_IN_partyFinancialDetailsList().getPartyID());
			partyFinancialDetailsList.setPartyName(getF_IN_partyFinancialDetailsList().getPartyName());
			partyFinancialDetailsList.removeAllPartyFinancialDetails();
			String WHERE_CLAUSE = "WHERE " + IBOCE_IB_PartyFinancialDetails.IBPARTYID + " = ?";
			ArrayList params = new ArrayList<>();
			params.add(getF_IN_partyFinancialDetailsList().getPartyID());

			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			List<IBOCE_IB_PartyFinancialDetails> financialDetails = factory.findByQuery(IBOCE_IB_PartyFinancialDetails.BONAME,
					WHERE_CLAUSE, params, null, true);
			for (IBOCE_IB_PartyFinancialDetails partyFinancialDetailsBO : financialDetails) {
				PartyFinancialDetails partyFinancialDetails = new PartyFinancialDetails();
				partyFinancialDetails.setAddress(partyFinancialDetailsBO.getF_IBADDRESS());
				partyFinancialDetails.setBankAccountNumber(partyFinancialDetailsBO.getF_IBBANKACCOUNTNUMBER());
				partyFinancialDetails.setBankName(partyFinancialDetailsBO.getF_IBBANKNAME());
				//partyFinancialDetails.setBenificiaryName(partyFinancialDetailsBO.getF_IBBENIFICIARYNAME());
				partyFinancialDetails.setCountry(partyFinancialDetailsBO.getF_IBCOUNTRY());
				partyFinancialDetails.setForeignBankName(partyFinancialDetailsBO.getF_IBFOREIGNBANKNAME());
				
				partyFinancialDetails.setIBANNumber(partyFinancialDetailsBO.getF_IBIBANNUMBER());
				partyFinancialDetails.setPartyID(partyFinancialDetailsBO.getF_IBPARTYID());
				partyFinancialDetails.setPostalCode(partyFinancialDetailsBO.getF_IBPOSTALCODE());
				partyFinancialDetails.setSelect(false);
				partyFinancialDetails.setStatus(partyFinancialDetailsBO.getF_IBSTATUS());
				partyFinancialDetails.setSWIFTCode(partyFinancialDetailsBO.getF_IBSWIFTCODE());
				partyFinancialDetails.setTelephone(partyFinancialDetailsBO.getF_IBTELEPHONE());
				partyFinancialDetailsList.addPartyFinancialDetails(partyFinancialDetails);
			}
		}
		
	}
	
	/**
     */

    private static final BigInteger INT_97 = new BigInteger("97");

    private static final String COUNTRYCODE_WHERE_CLAUSE = "WHERE " + IBOCountry.SHORTCOUNTRYCODE2CHR + " = ? ";
	private static final int E_INVALID_BANK_CODE = 44000409;

    

    /*
     * (non-Javadoc)
     * 
     * @see com.misys.bankfusion.idgeneration.providers.ICheckSum#validateCheckSum(java.lang.String,
     * com.misys.bankfusion.idgeneration.providers.AutoIDStructure,
     * com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment)
     */
    public boolean validateCheckSum(String iban, String bankCode,BankFusionEnvironment env) throws BankFusionException {
       if(bankCode!=null && bankCode.equals("999"))
    	   return true;
       
    	if (null == iban) {
            return false;
        }

        if (validateLength(iban, bankCode, env)) {
            BigInteger numericIBAN = getNumericIBAN(iban);
            int checkDigit = numericIBAN.mod(INT_97).intValue();
            return checkDigit == 1;
        }
        else {
            return false;
        }
    }

    /**
     * Method Description:
     * 
     * @param tempIBAN
     * @param env
     * @return
     * @throws BankFusionException
     */
    private boolean validateLength(String tempIBAN, String bankCode,BankFusionEnvironment env) throws BankFusionException {
        ArrayList<String> param = new ArrayList<String>();
        param.add(tempIBAN.substring(0, 2));
        IBOCountry countryIBANconfig = (IBOCountry) BankFusionThreadLocal.getPersistanceFactory().findFirstByQuery(
                IBOCountry.BONAME, COUNTRYCODE_WHERE_CLAUSE, param, false);
        if (countryIBANconfig == null) {
            Object[] field = new Object[] { tempIBAN.substring(0, 2) };
            EventsHelper.handleEvent(NonFinancialEventCodes.E_ALD_INVALID_COUNTRY, field, new HashMap(), env);
            return false;
        }
        if (countryIBANconfig.getF_IBANLENGTH() - tempIBAN.length() != 0) {
            Object[] field = new Object[] { tempIBAN, countryIBANconfig.getF_SHORTCOUNTRYCODE2CHR() };
            EventsHelper.handleEvent(NonFinancialEventCodes.E_COUNTRY_SPEC_IBAN_LEN_NOT_EQ_TO_NEW_GENERATED, field, new HashMap(),
                    env);
            return false;
        }
        if(!bankCode.equals(tempIBAN.substring(4, 6))) {
        	Object[] field = new Object[] {bankCode};
            EventsHelper.handleEvent(E_INVALID_BANK_CODE, field, new HashMap(),
                    env);
        }
        return true;
    }

    /**
     * Method Description:
     * 
     * @param iban
     * @return
     */
    private BigInteger getNumericIBAN(String iban) {
        iban = removeSpaces(iban);
        String endCheckDigitIBAN = iban.substring(4) + iban.substring(0, 4);
        StringBuffer numericIBAN = new StringBuffer();
        for (int i = 0; i < endCheckDigitIBAN.length(); i++) {
            if (Character.isDigit(endCheckDigitIBAN.charAt(i))) {
                numericIBAN.append(endCheckDigitIBAN.charAt(i));
            }
            else {
                numericIBAN.append(10 + getAlphabetPosition(endCheckDigitIBAN.charAt(i)));
            }
        }

        return new BigInteger(numericIBAN.toString());
    }

    /**
     * Method Description:
     * 
     * @param letter
     * @return
     */
    private int getAlphabetPosition(char letter) {
        // FOR JAVA 1.4 new
        // Character(Character.toUpperCase(letter)).compareTo(Character.valueOf('A'))
        return Character.valueOf(Character.toUpperCase(letter)).compareTo(Character.valueOf('A'));
    }

    /**
     * Method Description:
     * 
     * @param source
     * @return
     */
    private String removeSpaces(String source) {
        StringTokenizer stringTokenizer = new StringTokenizer(source, " ", false);
        StringBuffer finalString = new StringBuffer();
        while (stringTokenizer.hasMoreElements()) {
            finalString.append(stringTokenizer.nextElement());
        }
        return finalString.toString();
    }
}
