package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalArea;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveTechAreaDtls;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtlList;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtlList;

public class SaveTechAreaDtls extends AbstractCE_IB_SaveTechAreaDtls {

	private static final long serialVersionUID = 1L;

	public SaveTechAreaDtls(BankFusionEnvironment env) {
		super(env);
	}

	public SaveTechAreaDtls() {
		super();

	}

	private static final transient Log LOG = LogFactory.getLog(SaveTechAreaDtls.class.getName());

	public static final int AREA_AND_COORDINATES_MANDATORY = 44000216;
	public static final int AREA_SPL_PRJCT_TOTAL_ALL_DEED_COMP = 44000233;
	public static final int AREA_USED_AND_AREA_CANBE_USED_COMP = 44000235;
	public static final int E_MIN_FOUR_COORDINATE_ARE_MANDATORY_IB = 44000446;
	public static final int TITLE_ID_EXISTS = 44000217;

	@Override
	public void process(BankFusionEnvironment env) {
		// to calculate and save the total area's
		TechnicalAreaDtl eachArea = getF_IN_eachTechAreaDtl();
		TechnicalAreaDtlList technicalAreaListInput = getF_IN_technicalAreaDtlInput();
		BigDecimal areaAssignedForSplPrjct = getF_IN_totalAreaForAlldeeds();
		TechnicalAreaDtlList areaDtlList = new TechnicalAreaDtlList();
		BigDecimal totalAreaForAllDeed = BigDecimal.ZERO;
		BigDecimal areaCanBeUsedForAllDeed = BigDecimal.ZERO;
		BigDecimal areaUsedForAllDeed = BigDecimal.ZERO;
		int count = 0;
		BigDecimal areaUsed1 = new BigDecimal(eachArea.getAreaUsed());
		BigDecimal areaCanBeUsed1 = new BigDecimal(eachArea.getAreaCanBeUsed());
		if(areaUsed1.compareTo(areaCanBeUsed1)>CommonConstants.INTEGER_ZERO) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_USED_AND_AREA_CANBE_USED_COMP, new Object[] {},
					LOG, env);
		}
		if (technicalAreaListInput.getTechnicalAreaDtlList().length > 0) {
			for (int i = 0; i < technicalAreaListInput.getTechnicalAreaDtlListCount(); i++) {
				
				BigDecimal areaUsed = new BigDecimal(technicalAreaListInput.getTechnicalAreaDtlList(i).getAreaUsed());
				BigDecimal areaCanBeUsed = new BigDecimal(technicalAreaListInput.getTechnicalAreaDtlList(i).getAreaCanBeUsed());
				
				// get all the totals from grid data
				totalAreaForAllDeed = totalAreaForAllDeed.add(new BigDecimal(technicalAreaListInput.getTechnicalAreaDtlList(i).getTotalArea()));
				areaCanBeUsedForAllDeed = areaCanBeUsedForAllDeed.add(areaCanBeUsed);

				areaUsedForAllDeed = areaUsedForAllDeed.add(areaUsed);

				if (technicalAreaListInput.getTechnicalAreaDtlList(i).getTitleDeedId()
						.equals(eachArea.getTitleDeedId())) {
					count++; // grid already contains the title id
					totalAreaForAllDeed = totalAreaForAllDeed.add(new BigDecimal(eachArea.getTotalArea()).subtract(
							new BigDecimal(technicalAreaListInput.getTechnicalAreaDtlList(i).getTotalArea())));
					areaCanBeUsedForAllDeed = areaCanBeUsedForAllDeed
							.subtract(new BigDecimal(
									technicalAreaListInput.getTechnicalAreaDtlList(i).getAreaCanBeUsed()))
							.add(new BigDecimal(eachArea.getAreaCanBeUsed()));
					areaUsedForAllDeed = areaUsedForAllDeed
							.subtract(new BigDecimal(technicalAreaListInput.getTechnicalAreaDtlList(i).getAreaUsed()))
							.add(new BigDecimal(eachArea.getAreaUsed()));

					areaDtlList.addTechnicalAreaDtlList(eachArea);
				} else {

					areaDtlList.addTechnicalAreaDtlList(i, technicalAreaListInput.getTechnicalAreaDtlList(i));
				}

			}
		}

		String titleDeedId = eachArea.getTitleDeedId();
		if (count == 0) {
			// grid + new title area

			//checkSameTitleId(titleDeedId, eachArea.getReferenceNumber(), env);
			totalAreaForAllDeed = totalAreaForAllDeed.add(new BigDecimal(eachArea.getTotalArea()));

			areaCanBeUsedForAllDeed = areaCanBeUsedForAllDeed.add(new BigDecimal(eachArea.getAreaCanBeUsed()));

			areaUsedForAllDeed = areaUsedForAllDeed.add(new BigDecimal(eachArea.getAreaUsed()));

			areaDtlList.addTechnicalAreaDtlList(eachArea);
		}

		// setting the same totals to each row
		for (int i = 0; i < areaDtlList.getTechnicalAreaDtlListCount(); i++) {
			TechnicalAreaDtl vTechnicalAreaDtlList = new TechnicalAreaDtl();
			vTechnicalAreaDtlList = areaDtlList.getTechnicalAreaDtlList(i);
			vTechnicalAreaDtlList.setAreaCanBeUsedForAllDeeds(areaCanBeUsedForAllDeed.toString());
			vTechnicalAreaDtlList.setAreaUsedForAllDeeds(areaUsedForAllDeed.toString());
			vTechnicalAreaDtlList.setTotalAreaForAllDeeds(totalAreaForAllDeed.toString());
			areaDtlList.setTechnicalAreaDtlList(i, vTechnicalAreaDtlList);
		}
		if(areaAssignedForSplPrjct.compareTo(totalAreaForAllDeed)>CommonConstants.INTEGER_ZERO) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_SPL_PRJCT_TOTAL_ALL_DEED_COMP, new Object[] {},
					LOG, env);
		}
		TechnicalAreaCoordinateDtlList technicalAreaCoordinateDtlList = getF_IN_techCoordinateList();
		TechnicalAreaCoordinateDtlList hiddenGridOnlyCoordinate = getF_IN_hiddenTechAreaCoordinateList();
		
		for (TechnicalAreaCoordinateDtl areaCoordinateDtl : hiddenGridOnlyCoordinate.getTechnicalAreaCoordinateDtlList()) {
			if(areaCoordinateDtl.getReferenceNumber().equals(eachArea.getReferenceNumber())&& (areaCoordinateDtl.getTitleDeedId().equals(titleDeedId))) {
				hiddenGridOnlyCoordinate.removeTechnicalAreaCoordinateDtlList(areaCoordinateDtl);
			}
			
		}
		for (TechnicalAreaCoordinateDtl areaCoordinateDtl : technicalAreaCoordinateDtlList.getTechnicalAreaCoordinateDtlList()) {
			hiddenGridOnlyCoordinate.addTechnicalAreaCoordinateDtlList(areaCoordinateDtl);
		}
		if (technicalAreaCoordinateDtlList.getTechnicalAreaCoordinateDtlList().length < 4) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(E_MIN_FOUR_COORDINATE_ARE_MANDATORY_IB, new Object[] {},
					LOG, env);
		}
		
		if (technicalAreaCoordinateDtlList.getTechnicalAreaCoordinateDtlList().length == 0) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(AREA_AND_COORDINATES_MANDATORY, new Object[] {},
					LOG, env);
		}
		
		//setF_IN_hiddenTechAreaCoordinateList(technicalAreaCoordinateDtlList);
		setF_OUT_techCoordinateOutputList(hiddenGridOnlyCoordinate);
		setF_OUT_technicalAreaDtlList(areaDtlList);
	}

	private void checkSameTitleId(String titleDeedId, String referenceNumber, BankFusionEnvironment env) {

		ArrayList<String> params = new ArrayList<String>();
		String whereClause = "WHERE " + IBOCE_IB_TechincalArea.IBTITLEDEEDID + "=? AND "
				+ IBOCE_IB_TechincalArea.IBREFERENCENUMBER + "=?";
		params.add(titleDeedId);
		params.add(referenceNumber);
		List<IBOCE_IB_TechincalArea> areaDtl = (ArrayList<IBOCE_IB_TechincalArea>) IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_TechincalArea.BONAME, whereClause, params, null, true);
		if (areaDtl != null && areaDtl.size() > 0) {
			BusinessEventSupport.getInstance().raiseBusinessErrorEvent(TITLE_ID_EXISTS, new Object[] {}, LOG, env);
		}
	}
}
