package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOAssetDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressSaveToGrid;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;

public class AssetProgressSaveToGridFatom extends AbstractCE_IB_AssetProgressSaveToGrid {

    private static final long serialVersionUID = 1L;

    private transient final static Log LOGGER = LogFactory.getLog(AssetProgressSaveToGridFatom.class.getName());

	private static final String ISSUE_PO_WHERE = "WHERE "+IBOCE_IB_IssuePODetail.IBDEALID+"=?";

	private static final String ISSUE_PO_ASSET_WHERE = "WHERE "+IBOCE_IB_IssuePOAssetDetail.IBPURCHASEORDERID+"=? AND "+IBOCE_IB_IssuePOAssetDetail.IBASSETID+"=?";

    private  final int TOTAL_DISBURSEMENT_AMT_NOT_ZERO = 44000419;

    private  final int DISBURMNT_AMT_GREATER_THN_PREV_PENDG_AMT = 44000442;

    @SuppressWarnings("deprecation")
    public AssetProgressSaveToGridFatom(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) {
        String mode = getF_IN_mode();
        if (mode != null && mode.equalsIgnoreCase("ASSETGRID")) {
            BigDecimal totalDisbursement = BigDecimal.ZERO;
            BigDecimal originalFinalCost = BigDecimal.ZERO;
            BigDecimal originalFinalCostForSelectedAsset = BigDecimal.ZERO;
            BigDecimal netPrevDisbursedAmount = BigDecimal.ZERO;
            BigDecimal netFinalCost = BigDecimal.ZERO;
            BigDecimal totalAllowedCostForDisbursement;
            String selectedAssetID = CommonConstants.EMPTY_STRING;
            BFCurrencyAmount totalDisbursementAmount = new BFCurrencyAmount();
            totalDisbursementAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            for (AssetProgressDetails assetDetail : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
                totalAllowedCostForDisbursement = BigDecimal.ZERO;
                originalFinalCost = originalFinalCost.add(assetDetail.getOriginalFinalCost().getCurrencyAmount());
                if (!assetDetail.isSelect()) {
                    totalDisbursement = totalDisbursement.add(assetDetail.getFinalCostAfterDeduction().getCurrencyAmount());
                    netFinalCost = netFinalCost.add(assetDetail.getNetFinalCost().getCurrencyAmount());
                }else {
                	originalFinalCostForSelectedAsset = assetDetail.getOriginalFinalCost().getCurrencyAmount();
                	selectedAssetID = assetDetail.getAssetID();
                }
            }
            Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(getF_IN_hiddenAssetProgressRptDtls().getAssetProgressReportList(), selectedAssetID);
			BigDecimal previousReportsFinalCost = costMap.get("FINALCOST");
			BigDecimal previousReportsAllowedCost = costMap.get("ALLOWEDFINALCOST");
			if(previousReportsFinalCost.compareTo(previousReportsAllowedCost)>CommonConstants.INTEGER_ZERO) {
				netPrevDisbursedAmount = previousReportsFinalCost.subtract(previousReportsAllowedCost);
			}else {
				netPrevDisbursedAmount= previousReportsFinalCost;
			}
			BigDecimal newFinalAmount = netPrevDisbursedAmount.add(getF_IN_scalarNetFinalCost().getCurrencyAmount());
			if(newFinalAmount.compareTo(originalFinalCostForSelectedAsset)>CommonConstants.INTEGER_ZERO) {
				IBCommonUtils.raiseUnparameterizedEvent(DISBURMNT_AMT_GREATER_THN_PREV_PENDG_AMT);
			}
            totalDisbursement = totalDisbursement.add(getF_IN_scalarDisbursementAmount().getCurrencyAmount());
            totalDisbursementAmount.setCurrencyAmount(totalDisbursement);
            netFinalCost = netFinalCost.add(getF_IN_scalarNetFinalCost().getCurrencyAmount());
            // validation check for greater disbursementAmount
            if (null != getF_IN_scalarPreviouslyDisbursedAmount() && null != getF_IN_scalarNetFinalCost()
                && null != getF_IN_scalarAllowedFinalCost()) {
                totalAllowedCostForDisbursement = getF_IN_scalarPreviouslyDisbursedAmount().getCurrencyAmount().add(getF_IN_scalarNetFinalCost().getCurrencyAmount());
                if (getF_IN_scalarAllowedFinalCost().getCurrencyAmount().compareTo(totalAllowedCostForDisbursement) > 0)
                    IBCommonUtils.raiseUnparameterizedEvent(DISBURMNT_AMT_GREATER_THN_PREV_PENDG_AMT);
            }
            BigDecimal  prevDisbursedAmount = getPreviousDisbursedAmountForAsset(getF_IN_islamicBankingObject().getDealID(),selectedAssetID);
            if(prevDisbursedAmount.compareTo(originalFinalCost)>=CommonConstants.INTEGER_ZERO) {
            	IBCommonUtils.raiseUnparameterizedEvent(DISBURMNT_AMT_GREATER_THN_PREV_PENDG_AMT);
            }
            BigDecimal progressPercent = netFinalCost.multiply(new BigDecimal(100)).divide(originalFinalCost, 2, RoundingMode.HALF_UP);
            setF_OUT_totalDisbursementAmount(totalDisbursementAmount);
            setF_OUT_totalProgressPercentage(progressPercent);
            return;
		} else {
			//boolean ignoreSecReportExc = false;
			if (getF_IN_assetProgressReport().getTotalDisbursementAmount().getCurrencyAmount()
					.compareTo(BigDecimal.ZERO) <= 0) {
				IBCommonUtils.raiseUnparameterizedEvent(TOTAL_DISBURSEMENT_AMT_NOT_ZERO);
			}
			if (getF_IN_assetProgressReport().getReportID().equals(CommonConstants.EMPTY_STRING)) {
				IBCommonUtils.raiseUnparameterizedEvent(44000401);
			}
			if(isF_IN_isCoAssParty() && getF_IN_assetProgressReport().getDisbursementNumber()==2) {
			        for(AssetProgressReport progressReport:getF_IN_assetProgressReportDetails().getAssetProgressReportList()) {
			   if(progressReport.getDisbursementNumber()==1 && (progressReport.getCollectAdvancePayment().equals("NO") ||  progressReport.getCollectAdvancePayment().equals(""))) {
			        if(getF_IN_assetProgressReport().getCollectAdvancePayment().equals("NO") ||getF_IN_assetProgressReport().getCollectAdvancePayment().equals(""))
			            IBCommonUtils.raiseUnparameterizedEvent(44000458);
			        }
			    }
			    }
			/*if (isF_IN_isSpecialLoan()) {
				BigDecimal specialLoanMinCompletion = BigDecimal.ZERO;
				if (getF_IN_assetProgressReport().getDisbursementNumber() == 1) {
					 specialLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
							CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.SPECIAL_LOAN_MIN_PROG_PERC1, "",
							CeConstants.ADFIBCONFIGLOCATION));
				}else {
					BigDecimal netFinalCost = BigDecimal.ZERO;
					 specialLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
							CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.SPECIAL_LOAN_MIN_PROG_PERC2, "",
							CeConstants.ADFIBCONFIGLOCATION));
					 for (AssetProgressDetails assetDetail : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
							netFinalCost = netFinalCost.add(assetDetail.getNetFinalCost().getCurrencyAmount());
						}
						if(netFinalCost.compareTo(BigDecimal.ZERO)==CommonConstants.INTEGER_ZERO)
							ignoreSecReportExc = true;
				}
				if(getF_IN_assetProgressReport()
						.getTotalProgressPercentage().compareTo(specialLoanMinCompletion) < CommonConstants.INTEGER_ZERO) {
					String[] msgArg = new String[1];
					msgArg[0] = specialLoanMinCompletion.toString();
					IBCommonUtils.raiseParametrizedEvent(44000453, msgArg);
				}
			} else {
				BigDecimal normalLoanMinCompletion = BigDecimal.ZERO;
				if (getF_IN_assetProgressReport().getDisbursementNumber() == 1) {
					normalLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
							CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_LOAN_MIN_PROG_PERC1, "",
							CeConstants.ADFIBCONFIGLOCATION));
				}else {
					BigDecimal netFinalCost = BigDecimal.ZERO;
					
					normalLoanMinCompletion = new BigDecimal(BankFusionPropertySupport.getPropertyBasedOnConfLocation(
							CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_LOAN_MIN_PROG_PERC2, "",
							CeConstants.ADFIBCONFIGLOCATION));
					for (AssetProgressDetails assetDetail : getF_IN_assetProgressReportDetails().getAssetProgressDetailsList()) {
						netFinalCost = netFinalCost.add(assetDetail.getNetFinalCost().getCurrencyAmount());
					}
					if(netFinalCost.compareTo(BigDecimal.ZERO)==CommonConstants.INTEGER_ZERO)
						ignoreSecReportExc = true;
				}
				if(!ignoreSecReportExc && getF_IN_assetProgressReport()
						.getTotalProgressPercentage().compareTo(normalLoanMinCompletion) < CommonConstants.INTEGER_ZERO) {
					String[] msgArg = new String[1];
					msgArg[0] = normalLoanMinCompletion.toString();
					IBCommonUtils.raiseParametrizedEvent(44000453, msgArg);
				}
			}*/
		}
        AssetProgressReportDetails hiddenList = getF_IN_hiddenAssetProgressRptDtls();
        AssetProgressReportDetails gridList = getF_IN_assetProgressReportDetails();
        String reportId = getF_IN_reportID();

        AssetProgressReportDetails newHiddenList = new AssetProgressReportDetails();
        BigDecimal totalDisbursement = BigDecimal.ZERO;
        BFCurrencyAmount totalDisbursementAmount = new BFCurrencyAmount();
        totalDisbursementAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
        newHiddenList.addAssetProgressReportList(getF_IN_assetProgressReport());
        for (AssetProgressDetails assetDetail : gridList.getAssetProgressDetailsList()) {
            assetDetail.getAccumulatedCalculatedCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getAccumulatedFinalCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getInvoiceAmount().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getNetCalculatedCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getNetFinalCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getOriginalAssetStudyCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getOriginalFinalCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getPreviousCalculatedCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getPreviousFinalCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getPrevouslyDisbursedAmount().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getOriginalFinalCost().setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
            assetDetail.getFinalCostAfterDeduction().setCurrencyCode("SAR");
            totalDisbursement = totalDisbursement.add(assetDetail.getFinalCostAfterDeduction().getCurrencyAmount());
            newHiddenList.addAssetProgressDetailsList(assetDetail);
        }
        totalDisbursementAmount.setCurrencyAmount(totalDisbursement);
        for (AssetProgressDetails assetDetail : hiddenList.getAssetProgressDetailsList()) {
            if (!assetDetail.getReportID().equals(reportId)) {
                newHiddenList.addAssetProgressDetailsList(assetDetail);
            }
        }
        setF_OUT_hiddenAssetProgressRptDtls(newHiddenList);
    }

	public BigDecimal getPreviousDisbursedAmountForAsset(String dealID, String selectedAssetID) {
		BigDecimal disbursedAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList<>();
		params.add(dealID);
		List<IBOCE_IB_IssuePODetail> issuePOs = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_IssuePODetail.BONAME, ISSUE_PO_WHERE, params , null, true);
		for (IBOCE_IB_IssuePODetail iboce_IB_IssuePODetail : issuePOs) {
			params.clear();
			params.add(iboce_IB_IssuePODetail.getF_IBPURCHASEORDERID());
			params.add(selectedAssetID);
			List<IBOCE_IB_IssuePOAssetDetail> issuePOAssets = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_IssuePOAssetDetail.BONAME, ISSUE_PO_ASSET_WHERE, params , null, true);
			for (IBOCE_IB_IssuePOAssetDetail iboce_IB_IssuePOAssetDetail : issuePOAssets) {
				disbursedAmount = disbursedAmount.add(iboce_IB_IssuePOAssetDetail.getF_IBAMOUNT());
			}
		}
		return disbursedAmount;
	}

}
