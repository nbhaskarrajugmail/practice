package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FollowUpListConf;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SearchFollowUpAssignment;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.calendar.functions.AddMonthsToDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealFinDisbmntTxnInfo;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.followup.ib.types.FollowUpAssignmentCnf;
import bf.com.misys.followup.ib.types.FollowUpCnfList;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;

public class SearchFollowUpAssignment extends AbstractCE_IB_SearchFollowUpAssignment {
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public SearchFollowUpAssignment(BankFusionEnvironment env) {
        super(env);

    }

    public SearchFollowUpAssignment() {
        super();

    }

    private static boolean isAdmin=false;
    public static final String LIKE = "  like ?";

    private static final Log LOGGER = LogFactory.getLog(SearchFollowUpAssignment.class.getName());

    IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    private static final String FIND_ALL_DEALS_FOR_FOLLOWUP = " WHERE " + IBOIB_DLI_DealDetails.DealAccountId + " is not null ";
    
    private static final String FIND_DEALS_DETAIL_BY_ACC = " WHERE " + IBOIB_DLI_DealDetails.DealAccountId + " =?";

    private static final String FIND_All_DEALS_BY_BRANCHCODE =
        " WHERE " + IBOIB_DLI_DealDetails.BranchSortCode + " =? " + " AND " + IBOIB_DLI_DealDetails.DealAccountId + " is not null AND "+IBOIB_DLI_DealDetails.Status+" NOT IN('CANCELLED','CLOSED','CANCEL')";

    private static final String FIND_DEAL_DETAILS_BY_ALL_FILTERS = " WHERE " + IBOCE_IB_FollowUpListConf.IBDEALID + " =?" + " AND "
        + IBOCE_IB_FollowUpListConf.IBFOLLOWUPBRANCH + " =?" + " AND " + IBOCE_IB_FollowUpListConf.IBINSPECTORNAME + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_DEALID_AND_BRANCHCODE =
        " WHERE " + IBOCE_IB_FollowUpListConf.IBDEALID + " =? " + " AND " + IBOCE_IB_FollowUpListConf.IBFOLLOWUPBRANCH + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_BRANCH_AND_INSPECTOR =
        " WHERE " + IBOCE_IB_FollowUpListConf.IBFOLLOWUPBRANCH + " =? " + " AND " + IBOCE_IB_FollowUpListConf.IBINSPECTORNAME + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_DEALID_AND_INSPECTOR =
        " WHERE " + IBOCE_IB_FollowUpListConf.IBDEALID + " =? " + " AND " + IBOCE_IB_FollowUpListConf.IBINSPECTORNAME + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_INSPECTORID = " WHERE " + IBOCE_IB_FollowUpListConf.IBINSPECTORNAME + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_DEALID = " WHERE " + IBOCE_IB_FollowUpListConf.IBDEALID + " =? ";

    private static final String FIND_DEAL_DETAILS_BY_BRANCHCODE = " WHERE " + IBOIB_DLI_DealDetails.BranchSortCode + " =? ";

    @Override
    public void process(BankFusionEnvironment env) {
    	String dealId = CommonConstants.EMPTY_STRING;
		if (StringUtils.isNotEmpty(getF_IN_loanAccountID())) {
			ArrayList params = new ArrayList<>();
			params.add(getF_IN_loanAccountID());

			List<IBOIB_DLI_DealDetails> dealDetails = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME,
					FIND_DEALS_DETAIL_BY_ACC, params, null, true);
			if(dealDetails!=null && !dealDetails.isEmpty())
				dealId = dealDetails.get(0).getBoID();
		}
        String branch = getF_IN_branch();
        String inspectorName = getF_IN_inspectorName();
        FollowUpCnfList followUpAssignConfList = searchFollowUpList(dealId, branch, inspectorName);
        //using generic codes to show localized status and followup branch
        //ListGenericCodeRs branchGC = IBCommonUtils.getGCList("BRANCHNAME");
        ListGenericCodeRs statusGC = IBCommonUtils.getGCList("CEFOLLOWUPSTATUS");
        for(FollowUpAssignmentCnf followUpItem : followUpAssignConfList.getFollowUpAssignmentCnfDtls()) {
        /*    if(null != followUpItem.getFollowUpBranch() && followUpItem.getFollowUpBranch()!="" && !followUpItem.getFollowUpBranch().isEmpty()) {
            for(GcCodeDetail listItem :  branchGC.getGcCodeDetails()) {
                if(followUpItem.getFollowUpBranch().equals(listItem.getCodeReference())) {
                    followUpItem.setFollowUpBranch(listItem.getCodeDescription());
                    break;
                }
            }
        }*/
            if(null!=followUpItem.getCurrentFollowUpStatus() && followUpItem.getCurrentFollowUpStatus()!="" && !followUpItem.getCurrentFollowUpStatus().isEmpty()){
                String status = followUpItem.getCurrentFollowUpStatus();
                status = status.replaceAll("\\s", "");
                for(GcCodeDetail listItem :  statusGC.getGcCodeDetails()) {
                if(status.equalsIgnoreCase(listItem.getCodeReference())) {
                    followUpItem.setCurrentFollowUpStatus(listItem.getCodeDescription());
                    break;
                }
               }
            }
            
        }
        setF_OUT_followUpList(followUpAssignConfList);
        if (followUpAssignConfList.getFollowUpAssignmentCnfDtlsCount() > 0)
            setF_OUT_readOnly(false);
        else {
            setF_OUT_readOnly(true);
        }
    }

	public FollowUpCnfList searchFollowUpList(String dealId, String branch, String inspectorName) {

		FollowUpCnfList followUpList = new FollowUpCnfList();
		// no filter is given
		if (!StringUtils.isNotEmpty(inspectorName) && !StringUtils.isNotEmpty(dealId)) {
			isAdmin = CeUtils.isloggedInUserFromAdfFollowUpUserGroup();
			if (isAdmin)
				followUpList = fetchDealsBasedOnLocaleUserBranch(getF_IN_branch());
			else
				followUpList = fetchDealsBasedOnLocaleUserBranch(CeUtils.getUserBranchCode());
		} else {
			// only dealId as filter
			if (StringUtils.isNotEmpty(dealId) && !StringUtils.isNotEmpty(branch)&& !StringUtils.isNotEmpty(inspectorName)) {
				followUpList = fetchDealsBasedOnDealId(dealId);
			}
			// only branch as filter
			if (StringUtils.isNotEmpty(branch) && !StringUtils.isNotEmpty(inspectorName) && !StringUtils.isNotEmpty(dealId)) {
				followUpList = fetchDealsBasedOnLocaleUserBranch(getF_IN_branch());
			}
			// only inspector as filter
			if (StringUtils.isNotEmpty(inspectorName) && !StringUtils.isNotEmpty(dealId)&& !StringUtils.isNotEmpty(branch)) {
				followUpList = fetchDealsBasedOnInspector(inspectorName);
			}
			// deal Id and branch as filter
			if (StringUtils.isNotEmpty(dealId) && StringUtils.isNotEmpty(branch)&& !StringUtils.isNotEmpty(inspectorName)) {
				followUpList = fetchDealsBasedOnDealAndBranch(dealId, branch);
			}
			// branch and inspector as filter
			if (StringUtils.isNotEmpty(branch) && StringUtils.isNotEmpty(inspectorName)	&& !StringUtils.isNotEmpty(dealId)) {
				followUpList = fetchDealsBasedOnBranchAndInspectorName(branch, inspectorName);
			}
			// deal Id and inspector as filter
			if (StringUtils.isNotEmpty(dealId) && StringUtils.isNotEmpty(inspectorName)
					&& !StringUtils.isNotEmpty(branch)) {
				followUpList = fetchDealsBasedOnDealAndInspector(dealId, inspectorName);
			}
			// when all input as filter
			if (StringUtils.isNotEmpty(inspectorName) && StringUtils.isNotEmpty(dealId)
					&& StringUtils.isNotEmpty(branch)) {
				followUpList = fetchDealsBasedOnAllFilter(dealId, branch, inspectorName);
			}
		}
		return followUpList;
	}

    private FollowUpCnfList fetchDealsBasedOnBranchAndInspectorName(String branch, String inspectorName) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(branch);
        params.add(inspectorName);
        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_BRANCH_AND_INSPECTOR, params, null, true);
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            String dealId = eachFollowUp.getF_IBDEALID();
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }

        return followUpList;
    }

	private FollowUpCnfList fetchDealsBasedOnDealAndBranch(String dealId, String branch) {
		FollowUpCnfList followUpList = new FollowUpCnfList();
		ArrayList params = new ArrayList<>();
		params.add(dealId);
		params.add(branch);

		List<IBOCE_IB_FollowUpListConf> followUpListResult = factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME,
				FIND_DEAL_DETAILS_BY_DEALID_AND_BRANCHCODE, params, null, true);
		if (followUpListResult != null && !followUpListResult.isEmpty()) {
			for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
				IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
				if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),
						dealDtls.getF_ProductContextCode())) {
					FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
					followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
				}
			}
		} else {
			IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
			if (validateDeals(dealDtls.getF_DealStartDate(), null,
					dealDtls.getF_ProductContextCode())) {
            	ReadLoanDetailsRs readLoanRs = null;
                try {
                    readLoanRs = IBCommonUtils.getLoanDetails(dealDtls.getBoID());
                } catch (Exception e) {
                    e.getMessage();
                }
                if (null != readLoanRs
                        && (readLoanRs.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().compareTo(BigDecimal.ZERO) > 0)) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, null);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
          }
		}
		return followUpList;
	}

    private FollowUpCnfList fetchDealsBasedOnDealAndInspector(String dealId, String inspectorName) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(dealId);
        params.add(inspectorName);

        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_DEALID_AND_INSPECTOR, params, null, true);
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }

        return followUpList;
    }

    private FollowUpCnfList fetchDealsBasedOnAllFilter(String dealId, String branch, String inspectorName) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(dealId);
        params.add(branch);
        params.add(inspectorName);

        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_ALL_FILTERS, params, null, true);
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }

        return followUpList;
    }

    private FollowUpCnfList fetchDealsBasedOnInspector(String inspectorName) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(inspectorName);

        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_INSPECTORID, params, null, true);
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            String dealId = eachFollowUp.getF_IBDEALID();
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }

        return followUpList;
    }

    private FollowUpCnfList fetchDealsBasedOnBranch(String branch) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(branch);

        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_BRANCHCODE, params, null, true);
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            String dealId = eachFollowUp.getF_IBDEALID();
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }

        return followUpList;
    }

    private FollowUpCnfList fetchDealsBasedOnDealId(String dealId) {
        FollowUpCnfList followUpList = new FollowUpCnfList();
        List<IBOCE_IB_FollowUpListConf> followUpListResult = fetchDealsByDealId(dealId);
        if(followUpListResult!=null && !followUpListResult.isEmpty()) {
        for (IBOCE_IB_FollowUpListConf eachFollowUp : followUpListResult) {
            IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
            if (validateDeals(dealDtls.getF_DealStartDate(), eachFollowUp.getF_IBLASTFOLLOWUPDATE(),dealDtls.getF_ProductContextCode())) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, eachFollowUp);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
        }
        }else {
			IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealId);
			if (validateDeals(dealDtls.getF_DealStartDate(), null,
					dealDtls.getF_ProductContextCode())) {
            	ReadLoanDetailsRs readLoanRs = null;
                try {
                    readLoanRs = IBCommonUtils.getLoanDetails(dealDtls.getBoID());
                } catch (Exception e) {
                    e.getMessage();
                }
                if (null != readLoanRs
                        && (readLoanRs.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().compareTo(BigDecimal.ZERO) > 0)) {
                FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(dealDtls, null);
                followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
            }
          }
		
        }
        return followUpList;

    }

    private List<IBOCE_IB_FollowUpListConf> fetchDealsByDealId(String dealId) {
        ArrayList params = new ArrayList<>();
        params.add(dealId);
        List<IBOCE_IB_FollowUpListConf> followUpListResult =
            factory.findByQuery(IBOCE_IB_FollowUpListConf.BONAME, FIND_DEAL_DETAILS_BY_DEALID, params, null, true);
        return followUpListResult;
    }

    private FollowUpCnfList fetchDealsBasedOnLocaleUserBranch(String branchCode) {
    	System.err.println();
        FollowUpCnfList followUpList = new FollowUpCnfList();
        ArrayList params = new ArrayList<>();
        params.add(branchCode);
        List<IBOIB_DLI_DealDetails> dealDtlsList =
            factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, FIND_All_DEALS_BY_BRANCHCODE, params, null, true);

        for (IBOIB_DLI_DealDetails eachDealDtls : dealDtlsList) {
            String dealid = eachDealDtls.getBoID();
            
                List<IBOCE_IB_FollowUpListConf> followUpByDealIdList = fetchDealsByDealId(dealid);
                if (validateDeals(eachDealDtls.getF_DealStartDate(), (null != followUpByDealIdList && followUpByDealIdList.size() > 0)
                    ? followUpByDealIdList.get(0).getF_IBLASTFOLLOWUPDATE() : null,eachDealDtls.getF_ProductContextCode())) {
                	ReadLoanDetailsRs readLoanRs = null;
                    try {
                        readLoanRs = IBCommonUtils.getLoanDetails(dealid);
                    } catch (Exception e) {
                        e.getMessage();
                    }
                    if (null != readLoanRs
                            && (readLoanRs.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().compareTo(BigDecimal.ZERO) > 0)) {
                    FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(eachDealDtls,
                        (null != followUpByDealIdList && followUpByDealIdList.size() > 0) ? followUpByDealIdList.get(0) : null);
                    followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
                }
              }
        }
        return followUpList;
    }

    public FollowUpCnfList fetchAllDeals() {
        ArrayList params = new ArrayList();
        FollowUpCnfList followUpList = new FollowUpCnfList();
        List<IBOIB_DLI_DealDetails> dealDtlsList =
            factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, FIND_ALL_DEALS_FOR_FOLLOWUP.toString(), params, null, true);
        for (IBOIB_DLI_DealDetails eachDealDtls : dealDtlsList) {
            String dealid = eachDealDtls.getBoID();
            /*ReadLoanDetailsRs readLoanRs = null;
            try {
                readLoanRs = IBCommonUtils.getLoanDetails(dealid);
            } catch (Exception e) {
                e.getMessage();
            }*/
            if (getDealFinDisbursementTxnInfo(dealid)) {
                List<IBOCE_IB_FollowUpListConf> followUpByDealIdList = fetchDealsByDealId(dealid);
                if (validateDeals(eachDealDtls.getF_DealStartDate(), (null != followUpByDealIdList && followUpByDealIdList.size() > 0)
                    ? followUpByDealIdList.get(0).getF_IBLASTFOLLOWUPDATE() : null,eachDealDtls.getF_ProductContextCode())) {
                    FollowUpAssignmentCnf eachFollowUpListCfg = setFollowUpList(eachDealDtls,
                        (null != followUpByDealIdList && followUpByDealIdList.size() > 0) ? followUpByDealIdList.get(0) : null);
                    followUpList.addFollowUpAssignmentCnfDtls(eachFollowUpListCfg);
                }
            }

        }
        return followUpList;
    }

    private FollowUpAssignmentCnf setFollowUpList(IBOIB_DLI_DealDetails eachDealDtls, IBOCE_IB_FollowUpListConf eachFollowUpDtls) {
        FollowUpAssignmentCnf eachFollowUpListCfg = new FollowUpAssignmentCnf();

        eachFollowUpListCfg.setCurrentFollowUpStatus(null != eachFollowUpDtls ? eachFollowUpDtls.getF_IBCURRENTFOLLOWUPSTATUS() : null);
        eachFollowUpListCfg
            .setCustomerId((String) CeUtils.getCustomerDtls(eachDealDtls.getBoID(), eachDealDtls.getF_ParentDealNo()).get("CUSTOMERID"));
        eachFollowUpListCfg.setCustomerName(
            (String) CeUtils.getCustomerDtls(eachDealDtls.getBoID(), eachDealDtls.getF_ParentDealNo()).get("CUSTOMERNAME"));
        eachFollowUpListCfg.setDealId(eachDealDtls.getBoID());
        eachFollowUpListCfg.setDealBranch(IBCommonUtils.getBranchName(eachDealDtls.getF_BranchSortCode()));
        eachFollowUpListCfg.setInspectorName(null != eachFollowUpDtls ? eachFollowUpDtls.getF_IBINSPECTORNAME() : null);
        eachFollowUpListCfg.setFollowUpBranch(null != eachFollowUpDtls ? eachFollowUpDtls.getF_IBFOLLOWUPBRANCH() : null);
        eachFollowUpListCfg.setLastFollowUpDate(null != eachFollowUpDtls ? eachFollowUpDtls.getF_IBLASTFOLLOWUPDATE() : null);
        eachFollowUpListCfg.setProcessName(CeUtils.getProcessName(eachDealDtls.getF_PROCESSCONFIGID()));
        eachFollowUpListCfg.setSubProductName(CeUtils.getProductName(eachDealDtls.getF_ProductCode()));
        eachFollowUpListCfg.setSelect(false);
        eachFollowUpListCfg.setFollowUpDate(getFollowUpDate(eachDealDtls.getF_DealStartDate(),eachFollowUpListCfg.getLastFollowUpDate()));
        eachFollowUpListCfg.setLoanAccountID(eachDealDtls.getF_DealAccountId());
        return eachFollowUpListCfg;
    }

    private Date getFollowUpDate(Date dealStartDate,Date lastFollowupDate) {
        int monthsGreaterThan = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
            CeConstants.FIRST_FOLLOW_UP_START_PERIOD_IN_MONTHS, "", CeConstants.ADFIBCONFIGLOCATION));
		Date yearGreaterThan = AddMonthsToDate.run(dealStartDate, monthsGreaterThan, "Yes");
		if(lastFollowupDate!=null) {
			int monthsAfterLastFollowUp = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
		            CeConstants.MONTHS_AFTER_LAST_FOLLOW_UP, "", CeConstants.ADFIBCONFIGLOCATION));
				Date nextDateAfterLastfollowup = AddMonthsToDate.run(lastFollowupDate, monthsAfterLastFollowUp, "Yes");
				return nextDateAfterLastfollowup;
		}
		return yearGreaterThan;

    }

	private boolean validateDeals(Date dealStartDate, Date lastFollowUpDate, String subProductID) {
		CheckCurrentDealIsSpecialProject specialProject = new CheckCurrentDealIsSpecialProject();
		specialProject.setF_IN_subProductID(subProductID);
		specialProject.process(BankFusionThreadLocal.getBankFusionEnvironment());
		boolean isSpecial = specialProject.isF_OUT_isSpecialProject();
        boolean validateWithDealStartDate = false;
        boolean validateWithLastFollowUpDate = false;
        if (null != dealStartDate) {
            validateWithDealStartDate = validateWithDealStartDate(dealStartDate,isSpecial);
        }
        if (null != lastFollowUpDate) {
            validateWithLastFollowUpDate = validateWithLastFollowUpDate(lastFollowUpDate);
        } else {
            validateWithLastFollowUpDate = true;
        }
        if (validateWithDealStartDate && validateWithLastFollowUpDate) {
            return true;
        } else {
            return false;
        }

    }

    private boolean validateWithDealStartDate(Date dealStartDate, boolean isSpecailProject) {
    	int year = getF_IN_year();
        int monthsGreaterThan = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
            CeConstants.FIRST_FOLLOW_UP_START_PERIOD_IN_MONTHS, "", CeConstants.ADFIBCONFIGLOCATION));
        int monthsLessThan = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
            CeConstants.FIRST_FOLLOW_UP_END_PERIOD_IN_MONTHS, "", CeConstants.ADFIBCONFIGLOCATION));
        int monthsLessThanSpecailProj = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
                "First_Follow_Up_End_Period_Spcial_Loan_In_Months", "", CeConstants.ADFIBCONFIGLOCATION));
        int diff = calDateDiffWithStDate(IBCommonUtils.getBFBusinessDate(), dealStartDate);
        
		Date yearGreaterThan = AddMonthsToDate.run(dealStartDate, monthsGreaterThan, "Yes");
		Calendar cal = Calendar.getInstance();
		cal.setTime(yearGreaterThan);
		int yearForDeal = cal.get(Calendar.YEAR);
		if(isSpecailProject)
			monthsLessThan = monthsLessThanSpecailProj;
		
		if (yearForDeal == year && diff <= monthsLessThan)
			return true;
		
		return false;

    }

    private boolean validateWithLastFollowUpDate(Date lastFollowUpDate) {
    	int year = getF_IN_year();
        int monthsAfterLastFollowUp = Integer.parseInt(BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOW_UP_ASSIGN_CONF_FILE,
            CeConstants.MONTHS_AFTER_LAST_FOLLOW_UP, "", CeConstants.ADFIBCONFIGLOCATION));
		Date nextDateAfterLastfollowup = AddMonthsToDate.run(lastFollowUpDate, monthsAfterLastFollowUp, "Yes");
		Calendar cal = Calendar.getInstance();
		cal.setTime(nextDateAfterLastfollowup);
		int yearForDeal = cal.get(Calendar.YEAR);
		if (yearForDeal==year)
			return true;
		
		return false;

    }

    private int calDateDiffWithStDate(Date businessDate, Date dealStartDate) {
        int numberOfMonths = 0;
        int year = 0;
        int months = 0;

        if (dealStartDate != null) {
            year = businessDate.getYear() - dealStartDate.getYear();
            months = (businessDate.getMonth() + 1) - ((dealStartDate.getMonth() + 1));
            if (businessDate.getDate() <= (dealStartDate.getDate())) { // =check is added to not to include the same date but different
                                                                       // year.
                months--;
            }

        }

        numberOfMonths = months + (year * 12);
        return numberOfMonths;
    }

    private int calDateDiffWithLastFollowUp(Date businessDate, Date lastFollowUpDate) {
        int numberOfMonths = 0;
        int year = 0;
        int months = 0;
        if (null != lastFollowUpDate) {
            year = businessDate.getYear() - lastFollowUpDate.getYear();
            months = (businessDate.getMonth() + 1) - ((lastFollowUpDate.getMonth() + 1));
            if (businessDate.getDate() <= (lastFollowUpDate.getDate())) {
                months--;
            }
        }
        numberOfMonths = months + (year * 12);
        return numberOfMonths;
    }
    private boolean getDealFinDisbursementTxnInfo(String dealID) {
		String whereClause = "WHERE " + IBOIB_IDI_DealFinDisbmntTxnInfo.TRANSACTIONID + " IS NOT NULL " + "AND "
				+ IBOIB_IDI_DealFinDisbmntTxnInfo.DEALNO + " = ? AND "
				+ IBOIB_IDI_DealFinDisbmntTxnInfo.DISBURSEMENTSTATUS + "=?";
		ArrayList<String> params = new ArrayList<String>();
		params.add(dealID);
		params.add(IBConstants.DISBURSEMENT_STATUS_DISBURSED);

		List<IBOIB_IDI_DealFinDisbmntTxnInfo> list = factory.findByQuery(IBOIB_IDI_DealFinDisbmntTxnInfo.BONAME, whereClause, params, null, true);
		return list!=null && list.size()>CommonConstants.INTEGER_ZERO;
	}
}
