package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UnholdDealUserList;
import com.misys.bankfusion.ib.bo.refimpl.IBOIBVW_DealPartyDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.ib.services.ListDealCustomersRq;
import bf.com.misys.ib.services.ListDealCustomersRs;
import bf.com.misys.ib.types.InputListDealCustomersRq;
import bf.com.misys.ib.types.ListDealCustomer;
import bf.com.misys.ib.types.header.RqHeader;

public class UnholdDealUsers extends AbstractCE_IB_UnholdDealUserList{
        
    public UnholdDealUsers() {
        super();
    }
    
    @SuppressWarnings("deprecation")
    public UnholdDealUsers(BankFusionEnvironment env) {
        super(env);
    }
    
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
 
        String dealId = getF_IN_islamicBankingObject().getDealID();
        IBOIBVW_DealPartyDetails deal = (IBOIBVW_DealPartyDetails) env.getFactory().findByPrimaryKey(IBOIBVW_DealPartyDetails.BONAME, dealId);
        ListDealCustomersRq listDealCustomersRq = new ListDealCustomersRq();
        listDealCustomersRq.setRqHeader(new RqHeader());
        InputListDealCustomersRq inputListDealCustomersRq = new InputListDealCustomersRq();
        inputListDealCustomersRq.setDealId(dealId);
        listDealCustomersRq.setInputListDealCustomersRq(inputListDealCustomersRq);

        HashMap inputParams_0 = new HashMap();
        inputParams_0.put("ListDealCustomersRq", listDealCustomersRq);
        HashMap outputParams = MFExecuter.executeMF("IB_IDI_ListDealCustomers_SRV", IBCommonUtils.getBankFusionEnvironment(), inputParams_0);
        ListDealCustomersRs listDealCustomersRs = (ListDealCustomersRs) outputParams.get("ListDealCustomersRs");
        String customerName = "";
        for(ListDealCustomer customer: listDealCustomersRs.getDealCustomerDetails().getCustomerList().getListDealCustomer()) {
            if(customerName.equals("")) {
                customerName = customer.getCustomerName();
            }else {
                customerName = customerName + " , " + customer.getCustomerName();
            }
        }
        setF_OUT_customer(customerName);
    }
}
