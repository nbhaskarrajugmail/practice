package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDFEES;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHFEE;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistRefundRescheduleFee;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.dealreschedule.dtls.ib.types.CeReschRefundFeesDetails;
import bf.com.misys.dealreschedule.dtls.ib.types.CeRescheduleHistoryDetails;
import bf.com.misys.dealreschedule.dtls.ib.types.DealRescheduleDetails;
import bf.com.misys.ib.types.AccEntriesRegistrationDtls;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;

public class PersistRefundRescheduleFee extends AbstractCE_IB_PersistRefundRescheduleFee {


    public PersistRefundRescheduleFee() {
        super();
    }

    public PersistRefundRescheduleFee(BankFusionEnvironment env) {
        super(env);
    }

    private static final transient Log LOGGER = LogFactory.getLog(PersistRefundRescheduleFee.class.getName());
    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    private String scheduledDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
			CeConstants.REFUND_STATUS_SCHEDULED);
    private String refundDesc = IBCommonUtils.getGCChildDesc(CeConstants.REFUND_STATUS_GC_REF,
			CeConstants.REFUND_STATUS_REFUNDED);

    @Override
    public void process(BankFusionEnvironment env) {
        LOGGER.info("Entering into process method");
        IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
        CeReschRefundFeesDetails rescheduleRefundFeesDetails = getF_IN_rescheduleRefundFeesDtls();
        // Validation call
        persistValidation(rescheduleRefundFeesDetails);

        // Persist for RefundRescheduleFee
        if (!isF_IN_isViewOnly()) {
			if (rescheduleRefundFeesDetails.getPaymentMode().equalsIgnoreCase(CeConstants.PAYMENT_MODE_TOSURPLUS)) {
				IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(ibObject.getDealID());
				rescheduleRefundFeesDetails.setOtherBankAccount(dealDetails.getF_DealAccountId());
			} else if (IBCommonUtils.isEmpty(rescheduleRefundFeesDetails.getOtherBankAccount())) {
				rescheduleRefundFeesDetails.setOtherBankAccount(CeConstants.NOACCOUNT);
			}
            IBOCE_IB_REFUNDRESCHDTLS refundResDtls = persistRefundReschDtls(rescheduleRefundFeesDetails, ibObject, env);
			persistRefundReschedule(rescheduleRefundFeesDetails, ibObject, env);
			BigDecimal paidTotalRescheduleFee =persistRefundTransactionDetails(rescheduleRefundFeesDetails, ibObject, env);
			BigDecimal totalRescheduleAmtTobeRefunded = refundResDtls.getF_IBPIADSCHEDULEFEEAMT().add(paidTotalRescheduleFee);
			if(BigDecimal.ZERO.compareTo(totalRescheduleAmtTobeRefunded)!=0)
				persistPayrecRecordForPaidAmtRefund(ibObject, refundResDtls,totalRescheduleAmtTobeRefunded);
			else
			{
				IBOIB_TXN_PAYRECDETAIL payrecDtlRefundFees = (IBOIB_TXN_PAYRECDETAIL) factory
						.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, refundResDtls.getBoID(), true);
				if (null != payrecDtlRefundFees) {
					registerAccountingEntries(ibObject.getDealID(), payrecDtlRefundFees, CeConstants.ACTION_DELETE);
					factory.remove(IBOIB_TXN_PAYRECDETAIL.BONAME, refundResDtls.getBoID(), true);
				}
			}
			factory.commitTransaction();
            factory.beginTransaction();
			persistDealRescheduleDtls(env, rescheduleRefundFeesDetails);

            factory.commitTransaction();
            factory.beginTransaction();
        }

        LOGGER.info("Exiting from process method");

    }

    private BigDecimal persistRefundTransactionDetails(CeReschRefundFeesDetails rescheduleRefundFeesDetails, IslamicBankingObject ibObject,
			BankFusionEnvironment env) {
		BigDecimal paidTotalRescheduleFee = BigDecimal.ZERO;
		for (CeRescheduleHistoryDetails reschHistory : rescheduleRefundFeesDetails.getRescheduleHistoryDetails()) {
			String dealScheduledFeesClause = " WHERE " + IBOCE_IB_REFUNDFEES.IBDEALID + "=?" + " AND "
					+ IBOCE_IB_REFUNDFEES.IBDEALASSETCHARGEDTLID + "=?" + " AND " + IBOCE_IB_REFUNDFEES.IBREFUNDSTATUS
					+ "=?";
			String payrecRefundFeesClause = " WHERE " + IBOIB_TXN_PAYRECDETAIL.PAYRECDETAILID + "=?";
			String dealChargeDtls = " WHERE " + IBOIB_DLI_DealAssetChargesdtls.SRVCID + "=? AND "
					+ IBOIB_DLI_DealAssetChargesdtls.CHARGEPAYMENTSTATUS + "=? AND "
					+ IBOIB_DLI_DealAssetChargesdtls.DealNo + "=?";
			ArrayList params = new ArrayList<>();
			ArrayList paramsAssetChargeDtls = new ArrayList<>();
			paramsAssetChargeDtls.add(reschHistory.getRequestId());
			paramsAssetChargeDtls.add(IBConstants.PAID);
			paramsAssetChargeDtls.add(getF_IN_islamicBankingObject().getDealID());
			List<IBOIB_DLI_DealAssetChargesdtls> dealAssetChargesDtls = factory.findByQuery(
					IBOIB_DLI_DealAssetChargesdtls.BONAME, dealChargeDtls, paramsAssetChargeDtls, null, true);
			for (IBOIB_DLI_DealAssetChargesdtls dealAssetChargesDtl : dealAssetChargesDtls) {
				params.add(ibObject.getDealID());
				params.add(dealAssetChargesDtl.getBoID());
				params.add(CeConstants.STATUS_SCHEDULED);

				List<IBOCE_IB_REFUNDFEES> refundFeesList = factory.findByQuery(IBOCE_IB_REFUNDFEES.BONAME,
						dealScheduledFeesClause, params, null, false);

				// deleteExistingData(ibObject, reschHistory, refundFeesList);

				BigDecimal paidReschFees = updateExistingRefundFees(rescheduleRefundFeesDetails, ibObject, env,
						reschHistory, dealAssetChargesDtl, refundFeesList);
				paidTotalRescheduleFee = paidTotalRescheduleFee.add(paidReschFees);

				if (refundFeesList.isEmpty() && reschHistory.getRescheduleProfitStatus() != null
						&& !reschHistory.getRescheduleProfitStatus().isEmpty()
						&& reschHistory.getRescheduleProfitStatus().equalsIgnoreCase(scheduledDesc)
						&& 0 != BigDecimal.ZERO.compareTo(reschHistory.getFeesAmount().getCurrencyAmount())) {
					IBOCE_IB_REFUNDFEES refundFees = persistRefundFeeRecord(rescheduleRefundFeesDetails, ibObject, env,
							reschHistory, dealAssetChargesDtl);
					paidTotalRescheduleFee = paidTotalRescheduleFee.add(refundFees.getF_IBPAIDAMT());
					//persistAccountingEntriesData(ibObject, refundFees);

				}
			}

		}
		return paidTotalRescheduleFee;
	}

    private BigDecimal updateExistingRefundFees(CeReschRefundFeesDetails rescheduleRefundFeesDetails, IslamicBankingObject ibObject,
            BankFusionEnvironment env, CeRescheduleHistoryDetails reschHistory, IBOIB_DLI_DealAssetChargesdtls dealAssetChargesDtl,
			List<IBOCE_IB_REFUNDFEES> refundFeesList) {
    	boolean rescheduleHistoryUpdated=false;
    	BigDecimal rescheduleFeesPaid = BigDecimal.ZERO;
		if (!refundFeesList.isEmpty() && reschHistory.getRescheduleProfitStatus() != null
				&& !reschHistory.getRescheduleProfitStatus().isEmpty()
				&& reschHistory.getRescheduleProfitStatus().equalsIgnoreCase(scheduledDesc)
				&& 0 != BigDecimal.ZERO.compareTo(reschHistory.getFeesAmount().getCurrencyAmount())) {
			for (IBOCE_IB_REFUNDFEES scheduledRefundFee : refundFeesList) {
				if (scheduledRefundFee.getBoID().equals(reschHistory.getRequestId())) {
					scheduledRefundFee.setF_IBPARTYID(rescheduleRefundFeesDetails.getDealPartyId());
					scheduledRefundFee.setF_IBAMOUNT(reschHistory.getFeesAmount().getCurrencyAmount());
					scheduledRefundFee.setF_IBPAIDAMT(reschHistory.getFeesAmount().getCurrencyAmount()
							.subtract(dealAssetChargesDtl.getF_UNPAIDCHARGEAMOUNT()));
					scheduledRefundFee.setF_IBREMAMT(dealAssetChargesDtl.getF_UNPAIDCHARGEAMOUNT());
					scheduledRefundFee.setF_IBPARTYBANKACCOUNTID(rescheduleRefundFeesDetails.getOtherBankAccount());
					scheduledRefundFee.setF_IBTRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
					scheduledRefundFee.setF_IBUSER(env.getUserID());
					scheduledRefundFee.setF_IBREFUNDSTATUS(CeConstants.STATUS_SCHEDULED);
					if (scheduledRefundFee.getF_IBDESCRIPTION() != null)
						scheduledRefundFee.setF_IBDESCRIPTION(reschHistory.getRescheduleProfitStatus());
					rescheduleFeesPaid = scheduledRefundFee.getF_IBPAIDAMT();
					/*IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
							.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, scheduledRefundFee.getBoID(), true);

					payRecDetail.setF_ACCOUNTID(scheduledRefundFee.getF_IBPARTYBANKACCOUNTID());
					payRecDetail.setF_EQUIVALENTAMOUNT(scheduledRefundFee.getF_IBPAIDAMT());
					payRecDetail.setF_TRANSACTIONCURRENCY(getF_IN_islamicBankingObject().getCurrency());
					payRecDetail.setF_TRANSACTIONAMOUNT(scheduledRefundFee.getF_IBPAIDAMT());
					payRecDetail.setF_TRANSACTIONDTTM(scheduledRefundFee.getF_IBTRANSACTIONDTTM());
					payRecDetail.setF_VALUEDTTM(scheduledRefundFee.getF_IBTRANSACTIONDTTM());
					payRecDetail.setF_AMOUNTTYPE(CeConstants.TRANSACTION_TYPE_REFUNDRESCHEDULEFEES);
					payRecDetail.setF_STEPID(ibObject.getStepID());
					if (scheduledRefundFee.getF_IBDESCRIPTION() != null)
						payRecDetail.setF_NARRATIVE(scheduledRefundFee.getF_IBDESCRIPTION());

					registerAccountingEntries(ibObject.getDealID(), payRecDetail, CeConstants.ACTION_DELETE);
					registerAccountingEntries(ibObject.getDealID(), payRecDetail, IBConstants.EMPTY_STRING);*/
					rescheduleHistoryUpdated = true;
					break;
				}
			}

		} else if (!rescheduleHistoryUpdated) {
			factory.remove(IBOCE_IB_REFUNDFEES.BONAME, reschHistory.getRequestId(), true);
			/*IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) factory
					.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, reschHistory.getRequestId(), true);
			if(null != payRecDetail)
			{
			registerAccountingEntries(ibObject.getDealID(), payRecDetail, CeConstants.ACTION_DELETE);
			factory.remove(IBOIB_TXN_PAYRECDETAIL.BONAME, reschHistory.getRequestId(), true);*/
			factory.commitTransaction();
			factory.beginTransaction();
			/*}*/
		}
    	return rescheduleFeesPaid;
	}

	private void deleteExistingData(IslamicBankingObject ibObject, CeRescheduleHistoryDetails refundFee,
			List<IBOCE_IB_REFUNDFEES> refundFeesList) {
		if (!refundFeesList.isEmpty() && refundFee.getRescheduleProfitStatus() != null
				&& refundFee.getRescheduleProfitStatus().isEmpty()
				&& !refundFee.getRescheduleProfitStatus().equalsIgnoreCase(refundDesc)) {
			for (IBOCE_IB_REFUNDFEES scheduledFee : refundFeesList) {

				IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) factory
						.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, scheduledFee.getBoID(), true);

				registerAccountingEntries(ibObject.getDealID(), payRecDetail, CeConstants.ACTION_DELETE);
				IBCommonUtils.getPersistanceFactory().remove(IBOIB_TXN_PAYRECDETAIL.BONAME, scheduledFee.getBoID(),
						true);

			}

		}
	}

    private void persistAccountingEntriesData(IslamicBankingObject ibObject, IBOCE_IB_REFUNDFEES refundFees) {
        IBOIB_TXN_PAYRECDETAIL payrecDtlRefundFees = (IBOIB_TXN_PAYRECDETAIL) factory
                .getStatelessNewInstance(IBOIB_TXN_PAYRECDETAIL.BONAME);

        payrecDtlRefundFees.setBoID(refundFees.getBoID());
        payrecDtlRefundFees.setF_ACCOUNTID(refundFees.getF_IBPARTYBANKACCOUNTID());
        payrecDtlRefundFees.setF_DEALNO(refundFees.getF_IBDEALID());
        payrecDtlRefundFees.setF_EQUIVALENTAMOUNT(refundFees.getF_IBPAIDAMT());
        payrecDtlRefundFees.setF_TRANSACTIONCURRENCY(getF_IN_islamicBankingObject().getCurrency());
        payrecDtlRefundFees.setF_TRANSACTIONAMOUNT(refundFees.getF_IBPAIDAMT());
        payrecDtlRefundFees.setF_EXCHANGERATE(BigDecimal.ONE);
        payrecDtlRefundFees.setF_EXCHANGERATETYPE(CeConstants.EXCHANGE_RATE_TYPE_SPOT);
        payrecDtlRefundFees.setF_TRANSACTOINTYPE(CeConstants.TRANS_TYPE_PAY);
        payrecDtlRefundFees.setF_TRANSACTIONSTATUS(CeConstants.STATUS_SCHEDULED);
        payrecDtlRefundFees.setF_TRANSACTIONID(ibObject.getTransactionID());
        payrecDtlRefundFees.setF_TRANSACTIONDTTM(refundFees.getF_IBTRANSACTIONDTTM());
        payrecDtlRefundFees.setF_VALUEDTTM(refundFees.getF_IBTRANSACTIONDTTM());
        payrecDtlRefundFees.setF_PAYMENTMETHOD(CeConstants.PAYMENT_METHOD_TRF);
        payrecDtlRefundFees.setF_AMOUNTTYPE(CeConstants.TRANSACTION_TYPE_REFUNDRESCHEDULEFEES);
        payrecDtlRefundFees.setF_STEPID(ibObject.getStepID());
        if (refundFees.getF_IBDESCRIPTION() != null)
            payrecDtlRefundFees.setF_NARRATIVE(refundFees.getF_IBDESCRIPTION());

        factory.create(IBOIB_TXN_PAYRECDETAIL.BONAME, payrecDtlRefundFees);

        registerAccountingEntries(ibObject.getDealID(), payrecDtlRefundFees, IBConstants.EMPTY_STRING);
    }

    private IBOCE_IB_REFUNDFEES persistRefundFeeRecord(CeReschRefundFeesDetails rescheduleRefundFeesDetails,
            IslamicBankingObject ibObject, BankFusionEnvironment env, CeRescheduleHistoryDetails refundFee,
            IBOIB_DLI_DealAssetChargesdtls dealAssetChargesDtl) {
        IBOCE_IB_REFUNDFEES refundFees = (IBOCE_IB_REFUNDFEES) factory
                .getStatelessNewInstance(IBOCE_IB_REFUNDFEES.BONAME);

        refundFees.setBoID(refundFee.getRequestId());
        refundFees.setF_IBDEALID(ibObject.getDealID());
        refundFees.setF_IBDEALASSETCHARGEDTLID(dealAssetChargesDtl.getBoID());
        refundFees.setF_IBFEEID(dealAssetChargesDtl.getF_FEESCONFIGID());
        refundFees.setF_IBFEENAME(dealAssetChargesDtl.getF_SRVCNAME());
        refundFees.setF_IBPARTYID(rescheduleRefundFeesDetails.getDealPartyId());
        refundFees.setF_IBAMOUNT(refundFee.getFeesAmount().getCurrencyAmount());
        refundFees.setF_IBPAIDAMT(refundFee.getFeesAmount().getCurrencyAmount()
                .subtract(dealAssetChargesDtl.getF_UNPAIDCHARGEAMOUNT()));
        refundFees.setF_IBREMAMT(dealAssetChargesDtl.getF_UNPAIDCHARGEAMOUNT());
        refundFees.setF_IBPARTYBANKACCOUNTID(rescheduleRefundFeesDetails.getOtherBankAccount());
        refundFees.setF_IBTRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
        refundFees.setF_IBUSER(env.getUserID());
        refundFees.setF_IBREFUNDSTATUS(CeConstants.STATUS_SCHEDULED);
        if (refundFee.getRescheduleProfitStatus() != null)
            refundFees.setF_IBDESCRIPTION(refundFee.getRescheduleProfitStatus());

        factory.create(IBOCE_IB_REFUNDFEES.BONAME, refundFees);
        return refundFees;
    }

    private void persistDealRescheduleDtls(BankFusionEnvironment env, CeReschRefundFeesDetails rescheduleRefundFeesDetails) {
    	List<Date> paidDates =  new ArrayList<Date>();
        for (CePaymentSchedule newSchedule : rescheduleRefundFeesDetails.getNewSchedule()) {
            if (IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_FULLY_PAID).equals(newSchedule.getStatus())) {
                rescheduleRefundFeesDetails.removeNewSchedule(newSchedule);
                paidDates.add(newSchedule.getRepaymentDate());
            }
        }
        for (AssetBasedPaymentSchedule assetPaymentSchedule : getF_IN_rescheduleRefundFeesDtls().getAssetProfileDetails().getAssetBasedPaymentSchedule()) {
            if (paidDates.contains(assetPaymentSchedule.getRepaymentDate())) {
                rescheduleRefundFeesDetails.getAssetProfileDetails().removeAssetBasedPaymentSchedule(assetPaymentSchedule);
            }
        }
        DealRescheduleDetails dealrescheduleDtl = new DealRescheduleDetails();
        BigDecimal totalFeeAmt = BigDecimal.ZERO;
		for (CePaymentSchedule newSchedule : rescheduleRefundFeesDetails.getNewSchedule()) {
			dealrescheduleDtl.addNewSchedule(newSchedule);
			totalFeeAmt = totalFeeAmt.add(newSchedule.getFeesAmount().getCurrencyAmount());
		}
        getF_IN_rescheduleRefundFeesDtls().getRescheduleRequestDetails().getScheduleFeesAmount()
                .setCurrencyAmount(totalFeeAmt.subtract(
                        getF_IN_rescheduleRefundFeesDtls().getRescheduleRequestDetails().getOutstandingFees().getCurrencyAmount()));
        dealrescheduleDtl.setAssetProfileDetails(getF_IN_rescheduleRefundFeesDtls().getAssetProfileDetails());
        dealrescheduleDtl.setRescheduleRequestDetails(getF_IN_rescheduleRefundFeesDtls().getRescheduleRequestDetails());
        dealrescheduleDtl.setDealId(getF_IN_islamicBankingObject().getDealID());
        PersistDealRescheduleDetails rescheduleDtls = new PersistDealRescheduleDetails();
        rescheduleDtls.setF_IN_dealRescheduleDetails(dealrescheduleDtl);
        rescheduleDtls.setF_IN_isViewOnlyMode(isF_IN_isViewOnly());
        rescheduleDtls.process(env);

    }

    private void persistValidation(CeReschRefundFeesDetails rescheduleRefundFeesDetails) {
        boolean noRefundRescheduled = true;
        if (rescheduleRefundFeesDetails.getRescheduleHistoryDetailsCount() > 0) {
            for (CeRescheduleHistoryDetails refundFeeCheck : rescheduleRefundFeesDetails.getRescheduleHistoryDetails()) {
                if (refundFeeCheck.getRescheduleProfitStatus().equalsIgnoreCase(scheduledDesc))
                    noRefundRescheduled = false;
            }
        }
        if (noRefundRescheduled) {
        	IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_ATLEAST_ONE_FEE_TOBE_SCHEDULED);
        }
    }

    private void persistRefundReschedule(CeReschRefundFeesDetails rescheduleRefundFeesDetails, IslamicBankingObject ibObject, BankFusionEnvironment env) {
    	
		
    	if (rescheduleRefundFeesDetails.getRescheduleHistoryDetailsCount() > 0) { 	

            for (CeRescheduleHistoryDetails refundFee : rescheduleRefundFeesDetails.getRescheduleHistoryDetails()) {
                if (refundFee.getRescheduleProfitStatus().equalsIgnoreCase(scheduledDesc)) {
                    boolean isNew = false;
                    IBOCE_IB_REFUNDRESCHFEE refundResFees = (IBOCE_IB_REFUNDRESCHFEE) factory
                            .findByPrimaryKey(IBOCE_IB_REFUNDRESCHFEE.BONAME, refundFee.getRequestId(),true);
                    if (null == refundResFees) {
                        isNew = true;
                        refundResFees = (IBOCE_IB_REFUNDRESCHFEE) factory.getStatelessNewInstance(IBOCE_IB_REFUNDRESCHFEE.BONAME);
                        refundResFees.setBoID(refundFee.getRequestId());
                        refundResFees.setF_IBRECCREATEDBY(env.getUserID());
                        refundResFees.setF_IBRECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
                    }
                    refundResFees.setF_IBREFUNDRESCHDTLSID(ibObject.getTransactionID());
                    refundResFees.setF_IBDEALID(ibObject.getDealID());
                    refundResFees.setF_IBTRANSACTIONID(ibObject.getTransactionID());
                    refundResFees.setF_IBSYSTEMSTATUS(CeConstants.REFUND_STATUS_SCHEDULED);
                    refundResFees.setF_IBRESCHEDULEDFEEAMT(refundFee.getFeesAmount().getCurrencyAmount());
                    refundResFees.setF_IBSCHEDULEFEEAMT(refundFee.getScheduleFeesAmount().getCurrencyAmount());
                    refundResFees.setF_IBRECAPPROVEDBY(env.getUserID());
                    refundResFees.setF_IBRECAPPROVEDDATE(IBCommonUtils.getBFBusinessDateTime());
                    refundResFees.setF_IBRECLASTMODIFIEDBY(env.getUserID());
                    refundResFees.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
                    refundResFees.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
                    if (isNew)
                        factory.create(IBOCE_IB_REFUNDRESCHFEE.BONAME, refundResFees);
                }
                else if(!refundFee.getRescheduleProfitStatus().equalsIgnoreCase(refundDesc))
                {
                    factory.remove(IBOCE_IB_REFUNDRESCHFEE.BONAME, refundFee.getRequestId(),true);
                }
            }
        }

    }

    private IBOCE_IB_REFUNDRESCHDTLS persistRefundReschDtls(CeReschRefundFeesDetails rescheduleRefundFeesDetails, IslamicBankingObject ibObject, BankFusionEnvironment env) {
        
        boolean isNew = false;
        IBOCE_IB_REFUNDRESCHDTLS refundResDtls = (IBOCE_IB_REFUNDRESCHDTLS) factory
                .findByPrimaryKey(IBOCE_IB_REFUNDRESCHDTLS.BONAME, ibObject.getTransactionID(),true);
        if (null == refundResDtls) {
            refundResDtls = (IBOCE_IB_REFUNDRESCHDTLS) factory.getStatelessNewInstance(IBOCE_IB_REFUNDRESCHDTLS.BONAME);
            refundResDtls.setBoID(ibObject.getTransactionID());
            refundResDtls.setF_IBRECCREATEDBY(env.getUserID());
            refundResDtls.setF_IBRECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
            isNew = true;
        }

        refundResDtls.setF_IBDEALID(ibObject.getDealID());
        refundResDtls.setF_IBTRANSACTIONID(ibObject.getTransactionID());
        refundResDtls.setF_IBSYSTEMSTATUS(CeConstants.STATUS_SCHEDULED);
        refundResDtls.setF_IBPAYMENTMODE(rescheduleRefundFeesDetails.getPaymentMode());
        refundResDtls.setF_IBPIADSCHEDULEFEEAMT(rescheduleRefundFeesDetails.getRefundableFeeAmount().getCurrencyAmount());
        refundResDtls.setF_IBCUSTOMERACCOUNT(rescheduleRefundFeesDetails.getOtherBankAccount());
        refundResDtls.setF_IBRECAPPROVEDBY(env.getUserID());
        refundResDtls.setF_IBRECAPPROVEDDATE(IBCommonUtils.getBFBusinessDateTime());
        refundResDtls.setF_IBRECLASTMODIFIEDBY(env.getUserID());
        refundResDtls.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
        refundResDtls.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
        if (isNew)
            factory.create(IBOCE_IB_REFUNDRESCHDTLS.BONAME, refundResDtls);
        /*if(BigDecimal.ZERO.compareTo(rescheduleRefundFeesDetails.getRefundableFeeAmount().getCurrencyAmount())!=0)
        	persistPayrecRecordForPaidAmtRefund(ibObject, refundResDtls);*/
        return refundResDtls;

    }

    private void persistPayrecRecordForPaidAmtRefund(IslamicBankingObject ibObject, IBOCE_IB_REFUNDRESCHDTLS refundResDtls, BigDecimal totalRescheduleAmtTobeRefunded) {
        IBOIB_TXN_PAYRECDETAIL payrecDtlRefundFees = (IBOIB_TXN_PAYRECDETAIL) factory
                .findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME,refundResDtls.getBoID(),true);
        Boolean isNew = false;
        if(null == payrecDtlRefundFees)
        {
            payrecDtlRefundFees = (IBOIB_TXN_PAYRECDETAIL) factory
                .getStatelessNewInstance(IBOIB_TXN_PAYRECDETAIL.BONAME);
            payrecDtlRefundFees.setBoID(refundResDtls.getBoID());
            isNew = true;
        }

        payrecDtlRefundFees.setF_ACCOUNTID(refundResDtls.getF_IBCUSTOMERACCOUNT());
        payrecDtlRefundFees.setF_DEALNO(ibObject.getDealID());
        payrecDtlRefundFees.setF_EQUIVALENTAMOUNT(totalRescheduleAmtTobeRefunded);
        payrecDtlRefundFees.setF_TRANSACTIONCURRENCY(ibObject.getCurrency());
        payrecDtlRefundFees.setF_TRANSACTIONAMOUNT(totalRescheduleAmtTobeRefunded);
        payrecDtlRefundFees.setF_EXCHANGERATE(BigDecimal.ONE);
        payrecDtlRefundFees.setF_EXCHANGERATETYPE(CeConstants.EXCHANGE_RATE_TYPE_SPOT);
        payrecDtlRefundFees.setF_TRANSACTOINTYPE(CeConstants.TRANS_TYPE_PAY);
        payrecDtlRefundFees.setF_TRANSACTIONSTATUS(CeConstants.STATUS_SCHEDULED);
        payrecDtlRefundFees.setF_TRANSACTIONID(ibObject.getTransactionID());
        payrecDtlRefundFees.setF_TRANSACTIONDTTM(refundResDtls.getF_IBRECCREATEDON());
        payrecDtlRefundFees.setF_VALUEDTTM(refundResDtls.getF_IBRECAPPROVEDDATE());
        payrecDtlRefundFees.setF_PAYMENTMETHOD(CeConstants.PAYMENT_METHOD_TRF);
        payrecDtlRefundFees.setF_AMOUNTTYPE(CeConstants.RESCHREFUNDPROFIT);
        payrecDtlRefundFees.setF_STEPID(ibObject.getStepID());
        payrecDtlRefundFees.setF_NARRATIVE("");
        if(isNew)
            factory.create(IBOIB_TXN_PAYRECDETAIL.BONAME, payrecDtlRefundFees);
        if(!isNew)
            registerAccountingEntries(ibObject.getDealID(), payrecDtlRefundFees, CeConstants.ACTION_DELETE);
        registerAccountingEntries(ibObject.getDealID(), payrecDtlRefundFees, IBConstants.EMPTY_STRING);
    }

    private void registerAccountingEntries(String dealNo, IBOIB_TXN_PAYRECDETAIL payRecDetailObject, String mode) {
        AccEntriesRegistrationDtls accEntriesRegistrationDetails = new AccEntriesRegistrationDtls();
        accEntriesRegistrationDetails.setAccountID(payRecDetailObject.getF_ACCOUNTID());
        accEntriesRegistrationDetails.setEntityId(payRecDetailObject.getBoID());
        Amount amount2 = new Amount();
        BigDecimal temp = BigDecimal.ZERO;
        amount2.setAmountEdited(temp);
        amount2.setIsoCurrencyCode(" ");
        accEntriesRegistrationDetails.setAmountInAccCurr(amount2);
        Amount amount = new Amount();
        amount.setAmountEdited(payRecDetailObject.getF_EQUIVALENTAMOUNT());
        amount.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
        accEntriesRegistrationDetails.setBaseEquivalent(amount);
        accEntriesRegistrationDetails.setDealId(payRecDetailObject.getF_DEALNO());
        accEntriesRegistrationDetails.setEntityContext(payRecDetailObject.getF_AMOUNTTYPE());
        accEntriesRegistrationDetails.setExchangeRate(payRecDetailObject.getF_EXCHANGERATE());
        accEntriesRegistrationDetails.setExchangeRateType(payRecDetailObject.getF_EXCHANGERATETYPE());
        accEntriesRegistrationDetails.setNarrative(payRecDetailObject.getF_NARRATIVE());
        accEntriesRegistrationDetails.setProcessId(getF_IN_islamicBankingObject().getProcessConfigID());
        accEntriesRegistrationDetails.setStepId(getF_IN_islamicBankingObject().getStepID());
        accEntriesRegistrationDetails.setTransactionDt(new java.sql.Date(payRecDetailObject.getF_TRANSACTIONDTTM().getTime()));
        accEntriesRegistrationDetails.setTransactionId(getF_IN_islamicBankingObject().getTransactionID());
        Amount amount1 = new Amount();
        amount1.setAmountEdited(payRecDetailObject.getF_TRANSACTIONAMOUNT());
        amount1.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
        accEntriesRegistrationDetails.setTxnAmount(amount1);
        accEntriesRegistrationDetails.setTxnCurrency(amount1.getIsoCurrencyCode());
        accEntriesRegistrationDetails.setTxnType(payRecDetailObject.getF_TRANSACTOINTYPE());
        accEntriesRegistrationDetails.setValueDt(new java.sql.Date(payRecDetailObject.getF_VALUEDTTM().getTime()));
        HashMap input = new HashMap();
        input.put("accEntriesRegistrationDtls", accEntriesRegistrationDetails);
        if (!mode.isEmpty())
            input.put("mode", CeConstants.ACTION_DELETE);
        MFExecuter.executeMF("IB_CMN_RegisterAccountingEntries_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), input);
    }

}
