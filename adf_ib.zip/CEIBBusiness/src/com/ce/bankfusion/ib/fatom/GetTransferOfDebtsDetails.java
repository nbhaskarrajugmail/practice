package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetTransferOfDebtsDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_GetTransferOfDebtsDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.TransferDebtsHistory;

public class GetTransferOfDebtsDetails extends AbstractCE_IB_GetTransferOfDebtsDetails
		implements ICE_IB_GetTransferOfDebtsDetails {
	public GetTransferOfDebtsDetails() {
		super();
	}

	public GetTransferOfDebtsDetails(BankFusionEnvironment env) {
		super(env);
	}

	private static final transient Log LOGGER = LogFactory.getLog(GetTransferOfDebtsDetails.class.getName());
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	private String transferDebtsQuery = " WHERE " + IBOCE_IB_TransferOfDebtDtls.IBNEWDEALID + " = ?";
	private String statusTransferredDesc = IBCommonUtils.getGCChildDesc(CeConstants.TD_STATUS_GC_PARENT_REF,
			CeConstants.TD_STATUS_TRANSFERRED);
	private String statusScheduledDesc = IBCommonUtils.getGCChildDesc(CeConstants.TD_STATUS_GC_PARENT_REF,
			CeConstants.TD_STATUS_SCHEDULED);

	@Override
	public void process(BankFusionEnvironment env) {
		LOGGER.info("Entering into process method");
		getF_OUT_transerDebtsHistoryRq().removeAllTransferDebtsHistorylist();
		String newDealID = getF_IN_ibObject().getDealID();
		IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls = getTransferDebtsDetailsByNewDealID(newDealID);
		while (null != transferOfDebtDtls) {
			TransferDebtsHistory transferDebtsHistory = setTransferDebtsHistoryDtls(transferOfDebtDtls);
			if (newDealID.equals(getF_IN_ibObject().getDealID())) {
				setTransferOfDebtsDetails(transferDebtsHistory);
			}

			getF_OUT_transerDebtsHistoryRq().addTransferDebtsHistorylist(0, transferDebtsHistory);
			transferOfDebtDtls = getTransferDebtsDetailsByNewDealID(transferOfDebtDtls.getF_IBOLDDEALID());
		}
		LOGGER.info("Exiting from process method");
	}

	public TransferDebtsHistory setTransferDebtsHistoryDtls(IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls) {
		TransferDebtsHistory transferDebtsHistory = new TransferDebtsHistory();
		transferDebtsHistory.setTransferReqIDPk(transferOfDebtDtls.getBoID());
		transferDebtsHistory.setTransferReqDate(transferOfDebtDtls.getF_IBTDREQDATE());
		transferDebtsHistory.setFromDealID(transferOfDebtDtls.getF_IBOLDDEALID());
		transferDebtsHistory.setToDealID(transferOfDebtDtls.getF_IBNEWDEALID());
		transferDebtsHistory.setOldCustomerName(PanelUtils.readPartyDetails(transferOfDebtDtls.getF_IBOLDCUSTID()));
		transferDebtsHistory.setNewCustomerName(PanelUtils.readPartyDetails(transferOfDebtDtls.getF_IBNEWCUSTID()));
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(transferDebtsHistory.getFromDealID());
		transferDebtsHistory.setOriginalBranch(IBCommonUtils.getBranchName(dealDetails.getF_BranchSortCode()));
		transferDebtsHistory.setContinueSubsidy(transferOfDebtDtls.isF_IBSUBSDCONTINUE());
		transferDebtsHistory.setReschRequired(transferOfDebtDtls.isF_IBRESCHREQUIRED());
		transferDebtsHistory.setDocDate(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(transferOfDebtDtls.getF_IBDOCDATE())?null:transferOfDebtDtls.getF_IBDOCDATE());
		transferDebtsHistory.setDocNumber(transferOfDebtDtls.getF_IBDOCNUMBER());
		transferDebtsHistory.setNotes(transferOfDebtDtls.getF_IBTDREQNOTE());
		transferDebtsHistory.setOriginalDealAmt(
				IBCommonUtils.getBFCurrencyAmount(dealDetails.getF_DealAmt(), dealDetails.getF_IsoCurrencyCode()));
		transferDebtsHistory.setOsDealAmt(IBCommonUtils.getBFCurrencyAmount(transferOfDebtDtls.getF_IBOSDEALAMT(),
				dealDetails.getF_IsoCurrencyCode()));
		transferDebtsHistory.setOsPrincipalAmt(IBCommonUtils
				.getBFCurrencyAmount(transferOfDebtDtls.getF_IBOSPRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode()));
		transferDebtsHistory.setOsProfitAmt(IBCommonUtils.getBFCurrencyAmount(transferOfDebtDtls.getF_IBOSPROFITAMT(),
				dealDetails.getF_IsoCurrencyCode()));
		transferDebtsHistory.setProductID(dealDetails.getF_ProductCode());
		transferDebtsHistory.setSubproductID(dealDetails.getF_ProductContextCode());
		transferDebtsHistory.setReasonCode(transferOfDebtDtls.getF_IBTDREASON());
		transferDebtsHistory.setReasonDesc(IBCommonUtils.getGCChildDesc(CeConstants.TD_REASON_GC_PARENT_REF,
				transferOfDebtDtls.getF_IBTDREASON()));
		transferDebtsHistory.setStatus(
				CeConstants.TD_STATUS_SCHEDULED.equals(transferOfDebtDtls.getF_IBTDSTATUS()) ? statusScheduledDesc
						: statusTransferredDesc);
		transferDebtsHistory.setSelect(false);
		return transferDebtsHistory;
	}

	public IBOCE_IB_TransferOfDebtDtls getTransferDebtsDetailsByNewDealID(String newDealID) {
		ArrayList<Object> params = new ArrayList<>();
		params.add(newDealID);
		IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls = (IBOCE_IB_TransferOfDebtDtls) factory
				.findFirstByQuery(IBOCE_IB_TransferOfDebtDtls.BONAME, transferDebtsQuery, params, true);
		return transferOfDebtDtls;
	}

	public void setTransferOfDebtsDetails(TransferDebtsHistory transferDebtsHistory) {
		if (statusScheduledDesc.equals(transferDebtsHistory.getStatus())) {
			ReadLoanDetailsRs readLoanDetails = IBCommonUtils.getLoanDetails(transferDebtsHistory.getFromDealID());
			transferDebtsHistory.getOsDealAmt()
					.setCurrencyAmount(readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt());
			transferDebtsHistory.getOsPrincipalAmt().setCurrencyAmount(
					readLoanDetails.getDealDetails().getLoanBasicDetails().getOutstandingPrincipalAmt());
			transferDebtsHistory.getOsProfitAmt()
					.setCurrencyAmount(readLoanDetails.getDealDetails().getLoanBasicDetails().getOustandingProfitAmt());
		}

	}

}
