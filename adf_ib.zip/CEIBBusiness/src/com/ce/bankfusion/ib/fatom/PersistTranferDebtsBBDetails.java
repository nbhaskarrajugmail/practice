package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TransferOfDebtDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistTranferDebtsBBDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_PersistTranferDebtsBBDetails;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealPaymentSchedule;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealDisbursementInfo;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealDisbursementSchedules;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealFullDisbursementDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ThirdPartyPaymentScheduleDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.Get3rdPartyForAsset;
import com.misys.bankfusion.ib.fatom.PersistAssetData;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ib.schedule.types.ScheduleBasicInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfoList;
import bf.com.misys.ib.schedule.types.ScheduleGenInput;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AccEntriesRegistrationDtls;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.AssetBasicDtls;
import bf.com.misys.ib.types.AssetDtls;
import bf.com.misys.ib.types.AssetDtlsList;
import bf.com.misys.ib.types.AssetThirdPartyDtls;
import bf.com.misys.ib.types.AssetThirdPartyDtlsList;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.TransferDebtsHistory;

public class PersistTranferDebtsBBDetails extends AbstractCE_IB_PersistTranferDebtsBBDetails
		implements ICE_IB_PersistTranferDebtsBBDetails {
	public PersistTranferDebtsBBDetails() {
		super();
	}

	public PersistTranferDebtsBBDetails(BankFusionEnvironment env) {
		super(env);
	}

	private static final transient Log LOGGER = LogFactory.getLog(PersistTranferDebtsBBDetails.class.getName());
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	private String oldDealID = null;
	private String newDealID = null;
	private Map<String, String> oldNewAssetIdsMap = new HashMap<String, String>();
	private Map<String, ArrayList<IBOCE_IB_PaymentSchBreakup>> oldAssetIdPaymentSchedulesMap = new HashMap<String, ArrayList<IBOCE_IB_PaymentSchBreakup>>();
	private Map<String, AssetThirdPartyDtlsList> newAssetIdTPSMap = new HashMap<String, AssetThirdPartyDtlsList>();
	private Date dealStartDate = null;
	private Date dealEffectiveDate = null;
	BigDecimal newDealPrincipal = BigDecimal.ZERO;
	BigDecimal newDisbursedCost = BigDecimal.ZERO;
	BigDecimal newDealProfit = BigDecimal.ZERO;
	BigDecimal newScheduleFeeAmt = BigDecimal.ZERO;
	Boolean continueSubsidy = false;
	Integer noOfUnpaidInstallments = 0;
	public static final String TRANSFER_DEBTS_CONF_FILE = "conf/business/transferOfDebts.properties";
	Date minFirstPaymentDate = RescheduleUtils.getRescheduleMinPaymentDate();
	
	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info("Entering into process method");
		newDealID = getF_IN_ibObject().getDealID();
		if (!isF_IN_isViewOnly()) {
			boolean continuePersistence=persistTransferDebtsDetails(env);
			if(continuePersistence)
			{
				persistAssetDetails(env);
				persistDisbursementDtls(env);
				factory.commitTransaction();
				factory.beginTransaction();
				persistScheduleDetails(env);
				persistDealAdditionalUDDtls(env);
			}
		}
		LOGGER.info("Exiting from process method");
	}

	private void persistDealAdditionalUDDtls(BankFusionEnvironment env) {
		LOGGER.info("Entering into persistDealAdditionalUDDtls method");
		String whereClause = "WHERE "+IBOUDFEXTIB_DLI_DealDetails.DealNo +"= ?";
		ArrayList<String> queryParams = new ArrayList<String>();
		queryParams.add(newDealID);

		List<IBOUDFEXTIB_DLI_DealDetails> dealDetailsUD = factory
				.findByQuery(IBOUDFEXTIB_DLI_DealDetails.BONAME, whereClause, queryParams, null, true);
		String disbursmentPeriodInYears = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				"DisbursmentPeriodInYears", "", CeConstants.ADFIBCONFIGLOCATION);

		String noOfInstallments = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				"numberOfinstallment", "", CeConstants.ADFIBCONFIGLOCATION);
		for (IBOUDFEXTIB_DLI_DealDetails dealDetailUD : dealDetailsUD) {
			UserDefinedFields userDefinedFields = dealDetailUD.getUserDefinedFields();
			if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
				for (UserDefinedFld userDefinedFld : userDefinedFields.getUserDefinedField()) {
					if (disbursmentPeriodInYears.equals(userDefinedFld.getFieldName()) ) {
						userDefinedFld.setFieldValue(0);
					}
					else if(noOfInstallments.equals(userDefinedFld.getFieldName()))
					{
						userDefinedFld.setFieldValue(noOfUnpaidInstallments);
					}
					
				}
			}
		}
		List<IBOIB_DLI_DealAditionalDtls> dealAdditionalDetails = getDealAdditionalDtlsByDealId(oldDealID);
		IBOUDFEXTIB_DLI_DealAditionalDtls oldDealAdditionalUDFDetails = CeUtils
				.getDealAdditionalDetailsExtensionDtls(dealAdditionalDetails.get(0).getBoID());
		UserDefinedFields userDefinedFields = oldDealAdditionalUDFDetails.getUserDefinedFields();
		List<IBOIB_DLI_DealAditionalDtls> newDealAdditionalDetails = getDealAdditionalDtlsByDealId(newDealID);
		IBOUDFEXTIB_DLI_DealAditionalDtls newDealAdditionalUDFDetails = CeUtils
				.getDealAdditionalDetailsExtensionDtls(newDealAdditionalDetails.get(0).getBoID());
		 
		UserDefinedFields newUserDefinedFields = new UserDefinedFields();

		for (UserDefinedFld udf : userDefinedFields.getUserDefinedField()) {
			if (udf.getFieldValue() != null && !udf.getFieldValue().toString().isEmpty()) {
				UserDefinedFld udfNew = new UserDefinedFld();
				udfNew.setFieldName(udf.getFieldName());
				if (CeUtils.getUDFIDForDealEffectiveDate().equals(udf.getFieldName())) {
					udfNew.setFieldValue(dealEffectiveDate);
				} else if (CeUtils.getUDFIDForScheduleProfitAmnt().equals(udf.getFieldName())) {
					udfNew.setFieldValue(newDealProfit.add(newScheduleFeeAmt));
				} else if (CeUtils.getUDFIDForProfitAmount().equals(udf.getFieldName())) {
					udfNew.setFieldValue(newDealProfit.add(newScheduleFeeAmt));
				} else if (CeUtils.getUDFIDForUpfrontProfitAmnt().equals(udf.getFieldName())) {
					udfNew.setFieldValue(BigDecimal.ZERO);
				} else if (CeUtils.getUDFIDForScheduleProfitPercentage().equals(udf.getFieldName())) {
					udfNew.setFieldValue(new BigDecimal(100));
				} else if (CeUtils.getUDFIDForUpfrontProfitPercentage().equals(udf.getFieldName())) {
					udfNew.setFieldValue(BigDecimal.ZERO);
				} else {
					udfNew.setFieldValue(udf.getFieldValue());
				}
				newUserDefinedFields.addUserDefinedField(udfNew);
			}
		}
		newDealAdditionalUDFDetails.setUserDefinedFields(newUserDefinedFields);
		LOGGER.info("Exiting from persistDealAdditionalUDDtls method");
	}

	private List<IBOIB_DLI_DealAditionalDtls> getDealAdditionalDtlsByDealId(String dealID) {
		LOGGER.info("Entering into getDealAdditionalDtlsByDealId method");
		String whereClause = "WHERE " + IBOIB_DLI_DealAditionalDtls.DealNo + "= ? ";
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(dealID);
		List<IBOIB_DLI_DealAditionalDtls> dealAdditionalDetails = (List) IBCommonUtils.getBankFusionEnvironment()
				.getFactory().findByQuery(IBOIB_DLI_DealAditionalDtls.BONAME, whereClause, params, null, false);
		LOGGER.info("Exiting from getDealAdditionalDtlsByDealId method");
		return dealAdditionalDetails;
	}

	private void persistDisbursementDtls(BankFusionEnvironment env) {
		LOGGER.info("Entering into persistDisbursementDtls method");
		deleteExistingDisbursementDetails(newDealID);
		String disbAccount = BankFusionPropertySupport.getPropertyBasedOnConfLocation(TRANSFER_DEBTS_CONF_FILE,
						"TRANFER_DEBTS_FULL_DISB_ACCOUNT", "", CeConstants.ADFIBCONFIGLOCATION);
		IBOIB_IDI_DealDisbursementInfo disbursementInfo = (IBOIB_IDI_DealDisbursementInfo) factory
				.getStatelessNewInstance(IBOIB_IDI_DealDisbursementInfo.BONAME);
		disbursementInfo.setBoID(newDealID);
		disbursementInfo.setF_DISBURSEMENTMODE(IBConstants.DISBURSEMENT_MODE_ACTUAL);
		disbursementInfo.setF_RECCREATEDBY(IBCommonUtils.getUserId());
		disbursementInfo.setF_RECCREATEDON(IBCommonUtils.getBFBusinessDateTime());
		disbursementInfo.setF_RECLASTMODIFIEDBY(IBCommonUtils.getUserId());
		disbursementInfo.setF_RECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
		disbursementInfo.setF_RECSYSDATE(IBCommonUtils.getBFSystemDateTime());
		disbursementInfo.setF_DISBURSEMENTACCOUNT(disbAccount);
		disbursementInfo.setF_STARTDTTM(IBCommonUtils.getBFBusinessDate());
		factory.create(IBOIB_IDI_DealDisbursementInfo.BONAME, disbursementInfo);
		
		LOGGER.info("Exiting from persistDisbursementDtls method");
	}

	private void deleteExistingDisbursementDetails(String dealId) {
		LOGGER.info("Entering into deleteExistingDisbursementDetails method");
		String whereClause = "WHERE " + IBOIB_IDI_DealDisbursementInfo.DEALNO + "= ?";
		ArrayList params = new ArrayList();
		params.add(dealId);
		factory.bulkDelete(IBOIB_IDI_DealDisbursementInfo.BONAME, whereClause, params);
		whereClause = "WHERE " + IBOIB_IDI_DealFullDisbursementDTL.DEALNO + "= ?";
		factory.bulkDelete(IBOIB_IDI_DealFullDisbursementDTL.BONAME, whereClause, params);
		whereClause = "WHERE " + IBOIB_IDI_DealDisbursementSchedules.DEALNO + "= ?";
		factory.bulkDelete(IBOIB_IDI_DealDisbursementSchedules.BONAME, whereClause, params);
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Exiting from deleteExistingDisbursementDetails method");
	}

	private void persistScheduleDetails(BankFusionEnvironment env) {
		LOGGER.info("Entering into persistScheduleDetails method");
		ReadLoanDetailsRs oldLoanDetails = IBCommonUtils.getLoanDetails(oldDealID);
		Date newSchedulefirstPaymentDate = null;
		Date newScheduleLastPaymentDate = null;
		List<LoanPayments> newDealPayments = new ArrayList<LoanPayments>();
		LoanPayments newLoanPayment = new LoanPayments();
		BigDecimal osPrincipal = oldLoanDetails.getDealDetails().getLoanBasicDetails().getOriginalPrincipalAmt();
		int noOfPayments = 0;
		for (LoanPayments oldLoanPayment : oldLoanDetails.getDealDetails().getPaymentSchedule()) {
			osPrincipal = osPrincipal.subtract(oldLoanPayment.getPrincipleAmt());
			if (!CeConstants.PAYMENT_STATUS_FULLY_PAID.equals(oldLoanPayment.getRepaymentStatus()))

			{
				if (!CalendarUtil.IsDate1GreaterThanDate2(oldLoanPayment.getRepaymentDate(), minFirstPaymentDate)) {
					if (null == ThirdPartyPaymentScheduleUtil
							.clearDateDefaultValue(newLoanPayment.getRepaymentDate())) {
						setNewLoanPayment(newLoanPayment, noOfPayments, oldLoanPayment);
					} else {
						amendNewLoanPayment(newLoanPayment, oldLoanPayment);
					}
					newLoanPayment.setOutstandingPrincipalAmt(osPrincipal);
				} else {
					if (noOfPayments == 0) {
						newSchedulefirstPaymentDate = null != ThirdPartyPaymentScheduleUtil
								.clearDateDefaultValue(newLoanPayment.getRepaymentDate())
										? newLoanPayment.getRepaymentDate()
										: oldLoanPayment.getRepaymentDate();
					}
					if (null != ThirdPartyPaymentScheduleUtil
							.clearDateDefaultValue(newLoanPayment.getRepaymentDate())) {
						newDealPayments.add(newLoanPayment);
						newLoanPayment = new LoanPayments();
						noOfPayments++;
					}

					oldLoanPayment.setOutstandingPrincipalAmt(osPrincipal);
					oldLoanPayment.setRepaymentNo(noOfPayments + 1);
					newDealPayments.add(oldLoanPayment);
					newScheduleLastPaymentDate = oldLoanPayment.getRepaymentDate();
					noOfPayments++;
				}
			}

		}
		if (newDealPayments.isEmpty()
				&& null != ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(newLoanPayment.getRepaymentDate())) {
			newSchedulefirstPaymentDate = newLoanPayment.getRepaymentDate();
			newDealPayments.add(newLoanPayment);
			newScheduleLastPaymentDate = newLoanPayment.getRepaymentDate();
			noOfPayments++;
		}
		preparePersistScheduleProfiles(newSchedulefirstPaymentDate, newScheduleLastPaymentDate, noOfPayments,
				newDealPayments);
		LOGGER.info("Exiting from persistScheduleDetails method");
	}

	private void preparePersistScheduleProfiles(Date newSchedulefirstPaymentDate, Date newScheduleLastPaymentDate,
			int noOfPayments, List<LoanPayments> newDealPayments) {
		LOGGER.info("Entering into preparePersistScheduleProfiles method");
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(newDealID);
		ScheduleBasicInfo scheduleBasicInfo = prepareScheduleInfoObj(newScheduleLastPaymentDate, dealEffectiveDate,
				dealStartDate, dealDetails);
		ScheduleDetailedInfoList scheduleDetailedInfoList = prepareScheduleDetailedInfoObj(newSchedulefirstPaymentDate,
				newScheduleLastPaymentDate, dealDetails, noOfPayments);
		ScheduleGenInput scheduleGenInput = new ScheduleGenInput();
		scheduleGenInput.setScheduleDetailedInfoList(scheduleDetailedInfoList);
		scheduleGenInput.setScheduleBasicInfo(scheduleBasicInfo);
		ScheduleUtils.maintainScheduleProfile(scheduleGenInput, scheduleDetailedInfoList.getScheduleDetailedInfoList(),
				getF_IN_ibObject());
		ScheduleUtils.updateDealDetails(scheduleGenInput.getScheduleDetailedInfoList().getScheduleDetailedInfoList(),
				getF_IN_ibObject(), scheduleGenInput.getScheduleBasicInfo());
		com.ce.bankfusion.ib.util.ScheduleUtils.updateDealAdditionalDetails(
				scheduleGenInput.getScheduleDetailedInfoList().getScheduleDetailedInfoList(),
				getF_IN_ibObject().getDealID());
		for (LoanPayments paymentSchedule : newDealPayments) {
			paymentSchedule.setProfitRate(scheduleDetailedInfoList.getScheduleDetailedInfoList(0).getProfitRate());
		}
		persistIBScheduleTable(newDealPayments, newDealID);
		persistBreakupScheduleTable(newDealID);
		LOGGER.info("Exiting from preparePersistScheduleProfiles method");
	}

	public void persistIBScheduleTable(List<LoanPayments> newDealPayments, String dealId) {
		LOGGER.info("Entering into persistIBScheduleTable method");
		ArrayList<String> params = new ArrayList<String>();
		params.add(dealId);
		String whereClause = " WHERE " + IBOIB_DLI_DealPaymentSchedule.DEALNO + " = ?";

		factory.bulkDelete(IBOIB_DLI_DealPaymentSchedule.BONAME, whereClause, params);
		factory.commitTransaction();
		factory.beginTransaction();

		for (LoanPayments paymentSchedule : newDealPayments) {
			IBOIB_DLI_DealPaymentSchedule dealPaymentSchedule = (IBOIB_DLI_DealPaymentSchedule) (BankFusionThreadLocal
					.getPersistanceFactory().getStatelessNewInstance(IBOIB_DLI_DealPaymentSchedule.BONAME));
			dealPaymentSchedule.setF_CARRYOVERPROFITAMT(BigDecimal.ZERO);
			dealPaymentSchedule.setF_CHARGEAMT(BigDecimal.ZERO);
			dealPaymentSchedule.setF_DEALNO(dealId);
			dealPaymentSchedule.setF_OUTSTANDINGBALANCE(paymentSchedule.getOutstandingPrincipalAmt());
			dealPaymentSchedule.setF_OUTSTANDINGPROFITCOST(paymentSchedule.getOutstandingPrincipalAmt());
			dealPaymentSchedule.setF_PAYMENTDT(paymentSchedule.getRepaymentDate());
			dealPaymentSchedule.setF_PRINCIPALAMT(paymentSchedule.getPrincipleAmt());
			dealPaymentSchedule.setF_PROFITAMT(paymentSchedule.getProfitAmt());
			dealPaymentSchedule.setF_PROFITRATE(paymentSchedule.getProfitRate());
			dealPaymentSchedule.setF_REPAYMENTAMT(paymentSchedule.getRepaymentAmt());
			dealPaymentSchedule.setF_REPAYMENTNUMBER(paymentSchedule.getRepaymentNo());
			dealPaymentSchedule.setF_REPAYMENTTYPE(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
			factory.create(IBOIB_DLI_DealPaymentSchedule.BONAME, dealPaymentSchedule);
		}
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Exiting from persistIBScheduleTable method");
	}

	public void persistBreakupScheduleTable(String dealId) {
		LOGGER.info("Entering into persistBreakupScheduleTable method");
		bulkDeleteBreakupScheduleData(dealId);
		for (Map.Entry<String, ArrayList<IBOCE_IB_PaymentSchBreakup>> entry : oldAssetIdPaymentSchedulesMap
				.entrySet()) {
			String oldAssetId = entry.getKey();
			String newAssetId = oldNewAssetIdsMap.get(oldAssetId);
			for (IBOCE_IB_PaymentSchBreakup paymentSchedule : entry.getValue()) {
				if (!CalendarUtil.IsDate1GreaterThanDate2(paymentSchedule.getF_IBBILLDATE(), minFirstPaymentDate)) {
					IBOCE_IB_PaymentSchBreakup existingRec = getBreakUpRecordByBillDateandAssetId(dealId,
							minFirstPaymentDate, newAssetId);
					if (null != existingRec)
						updateExistingPaymentRec(paymentSchedule, existingRec);
					else
						createPaymentBreakUpRecord(dealId, newAssetId, paymentSchedule);
				} else
					createPaymentBreakUpRecord(dealId, newAssetId, paymentSchedule);

			}
		}
		LOGGER.info("Exiting from persistBreakupScheduleTable method");
	}

	private void updateExistingPaymentRec(IBOCE_IB_PaymentSchBreakup paymentSchedule,
			IBOCE_IB_PaymentSchBreakup existingRec) {
		LOGGER.info("Entering into updateExistingPaymentRec method");
		existingRec.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
		existingRec.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
		existingRec.setF_IBPRINCIPALAMT(existingRec.getF_IBPRINCIPALAMT().add(paymentSchedule
				.getF_IBPRINCIPALAMT().subtract(paymentSchedule.getF_IBPRINCIPALAMTPAID())));
		existingRec.setF_IBPROFITAMT(existingRec.getF_IBPROFITAMT().add(
				paymentSchedule.getF_IBPROFITAMT().subtract(paymentSchedule.getF_IBPROFITAMTPAID())));
		existingRec.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
		existingRec.setF_IBSCHEDULEFEEAMT(existingRec.getF_IBSCHEDULEFEEAMT().add(paymentSchedule
				.getF_IBSCHEDULEFEEAMT().subtract(paymentSchedule.getF_IBSCHEDULEFEESAMTPAID())));
		existingRec.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
		if (continueSubsidy) {
			existingRec.setF_IBSUBSIDYAMNT(existingRec.getF_IBSUBSIDYAMNT().add(paymentSchedule
					.getF_IBSUBSIDYAMNT().subtract(paymentSchedule.getF_IBSUBSIDYAMTPAID())));
		}
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Exiting from updateExistingPaymentRec method");
	}

	private void createPaymentBreakUpRecord(String dealId, String newAssetId,
			IBOCE_IB_PaymentSchBreakup paymentSchedule) {
		LOGGER.info("Entering into createPaymentBreakUpRecord method");
		//firstPaymentDate
		IBOCE_IB_PaymentSchBreakup paymentSchBreakup = (IBOCE_IB_PaymentSchBreakup) (BankFusionThreadLocal
				.getPersistanceFactory().getStatelessNewInstance(IBOCE_IB_PaymentSchBreakup.BONAME));
		paymentSchBreakup.setBoID(IBCommonUtils.getNewGUID());
		paymentSchBreakup.setF_IBASSETID(newAssetId);
		paymentSchBreakup.setF_IBBILLDATE(
				!CalendarUtil.IsDate1GreaterThanDate2(paymentSchedule.getF_IBBILLDATE(), minFirstPaymentDate)
						? minFirstPaymentDate
						: paymentSchedule.getF_IBBILLDATE());
		paymentSchBreakup.setF_IBDEALID(dealId);
		paymentSchBreakup.setF_IBSUBSIDYAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBPRINCIPALAMT(
				paymentSchedule.getF_IBPRINCIPALAMT().subtract(paymentSchedule.getF_IBPRINCIPALAMTPAID()));
		paymentSchBreakup.setF_IBPROFITAMT(
				paymentSchedule.getF_IBPROFITAMT().subtract(paymentSchedule.getF_IBPROFITAMTPAID()));
		paymentSchBreakup.setF_IBPROFITAMTPAID(BigDecimal.ZERO);
		paymentSchBreakup.setF_IBSCHEDULEFEEAMT(paymentSchedule.getF_IBSCHEDULEFEEAMT()
				.subtract(paymentSchedule.getF_IBSCHEDULEFEESAMTPAID()));
		paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(BigDecimal.ZERO);
		if (continueSubsidy) {
			paymentSchBreakup.setF_IBSUBSIDYAMNT(
					paymentSchedule.getF_IBSUBSIDYAMNT().subtract(paymentSchedule.getF_IBSUBSIDYAMTPAID()));
		}
		factory.create(IBOCE_IB_PaymentSchBreakup.BONAME, paymentSchBreakup);
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Exiting from createPaymentBreakUpRecord method");
	}

	public void bulkDeleteBreakupScheduleData(String dealId) {
		LOGGER.info("Entering into bulkDeleteBreakupScheduleData method");
		ArrayList<String> params = new ArrayList<>();
		params.add(dealId);
		String whereClause = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ?";
		factory.bulkDelete(IBOCE_IB_PaymentSchBreakup.BONAME, whereClause, params);
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Exiting from bulkDeleteBreakupScheduleData method");
	}

	public IBOCE_IB_PaymentSchBreakup getBreakUpRecordByBillDateandAssetId(String dealId, Date billDate, String assetId) {
		LOGGER.info("Entering into getBreakUpRecordByBillDateandAssetId method");
		ArrayList<Object> params = new ArrayList<>();
		params.add(dealId);
		params.add(billDate);
		params.add(assetId);
		String whereClause = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? and "
				+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? and " + IBOCE_IB_PaymentSchBreakup.IBASSETID + " = ?";
		List<IBOCE_IB_PaymentSchBreakup> paymentSchBreakups = factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClause, params,null,true);
		LOGGER.info("Exiting from getBreakUpRecordByBillDateandAssetId method");
		if(null != paymentSchBreakups && !paymentSchBreakups.isEmpty())
			return paymentSchBreakups.get(0);
		return null;
	}

	public ScheduleBasicInfo prepareScheduleInfoObj(Date lastPaymentDate, Date dealEffectiveDate, Date dealStartDate,
			IBOIB_DLI_DealDetails dealDetails) {
		LOGGER.info("Entering into prepareScheduleInfoObj method");
		ScheduleBasicInfo scheduleBasicInfo = new ScheduleBasicInfo();
		scheduleBasicInfo.setDealEffectiveDate(dealEffectiveDate);
		scheduleBasicInfo.setDealStartDate(dealStartDate);
		scheduleBasicInfo.setGraceDays(0);
		scheduleBasicInfo.setLastInstallmentDate(lastPaymentDate);
		scheduleBasicInfo.setDealAmt(IBCommonUtils.getBFCurrencyAmount(
				newDealPrincipal.add(newDealProfit).add(newScheduleFeeAmt), dealDetails.getF_IsoCurrencyCode()));
		BFCurrencyAmount newPrincipalAmt = IBCommonUtils.getBFCurrencyAmount(newDealPrincipal,
				dealDetails.getF_IsoCurrencyCode());
		scheduleBasicInfo.setDealPrincipleAmt(newPrincipalAmt);
		scheduleBasicInfo.setDealProfitAmt(IBCommonUtils.getBFCurrencyAmount(newDealProfit.add(newScheduleFeeAmt),
				dealDetails.getF_IsoCurrencyCode()));
		scheduleBasicInfo.setProfitChargesDealOverHeadCost(
				IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO, dealDetails.getF_IsoCurrencyCode()));
		scheduleBasicInfo.setProfitCost(newPrincipalAmt);
		scheduleBasicInfo.setRemainingPrinciple(
				IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO, dealDetails.getF_IsoCurrencyCode()));
		scheduleBasicInfo.setRemainingProfit(
				IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO, dealDetails.getF_IsoCurrencyCode()));
		scheduleBasicInfo.setScheduledPrinciple(newPrincipalAmt);
		scheduleBasicInfo.setScheduledProfit(
				IBCommonUtils.getBFCurrencyAmount(CommonConstants.BIGDECIMAL_ZERO, dealDetails.getF_IsoCurrencyCode()));
		LOGGER.info("Exiting from prepareScheduleInfoObj method");
		return scheduleBasicInfo;
	}

	private ScheduleDetailedInfoList prepareScheduleDetailedInfoObj(Date newSchedulefirstPaymentDate,
			Date newScheduleLastPaymentDate, IBOIB_DLI_DealDetails dealDetails, int noOfPayments) {
		LOGGER.info("Entering into prepareScheduleDetailedInfoObj method");
		String currencyCode = dealDetails.getF_IsoCurrencyCode();
		ScheduleDetailedInfoList scheduleDetailedInfoList = new ScheduleDetailedInfoList();
		long noOfMonths = CalendarUtil.getMonthsBetweenDate1AndDate2(newScheduleLastPaymentDate, dealEffectiveDate);
		IBOIB_DLI_ScheduleProfile oldDealScheduleProfile = getDealScheduleRepaymentProfie(oldDealID);
		ScheduleDetailedInfo scheduleDetailedInfoObj = new ScheduleDetailedInfo();
		scheduleDetailedInfoObj.setBaseFactor(oldDealScheduleProfile.getF_BaseFactor());
		BigDecimal totalProfitAmount = newDealProfit.add(newScheduleFeeAmt);
		scheduleDetailedInfoObj.setCalculatedProfit(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setDefaultProfitRate(oldDealScheduleProfile.getF_ProfitRate());
		scheduleDetailedInfoObj.setEquivalentRate(oldDealScheduleProfile.getF_EquivalentRate());
		scheduleDetailedInfoObj.setFactorRate(oldDealScheduleProfile.getF_FactorRate());
		scheduleDetailedInfoObj.setGraceProfitCollection(CommonConstants.EMPTY_STRING);
		scheduleDetailedInfoObj.setGraceProfitResidualAmt(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
		scheduleDetailedInfoObj.setInstallementAmt(CeUtils.getZeroAmount(currencyCode));
		scheduleDetailedInfoObj.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setProfitMatrixId(oldDealScheduleProfile.getF_ProfitMatrixID());
		scheduleDetailedInfoObj.setProfitMethod(oldDealScheduleProfile.getF_EvaluationMethod());
		scheduleDetailedInfoObj.setProfitPayment(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setProfitPaymentAll(true);
		scheduleDetailedInfoObj.setProfitRate(oldDealScheduleProfile.getF_ProfitRate());
		scheduleDetailedInfoObj.setRoundingOption(oldDealScheduleProfile.getF_RoundingOption());
		scheduleDetailedInfoObj.setScheduleDurationCode("Month");
		scheduleDetailedInfoObj.setScheduleDurationUnit((int) noOfMonths);
		scheduleDetailedInfoObj.setScheduleEndDate(newScheduleLastPaymentDate);
		scheduleDetailedInfoObj.setScheduleType(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
		scheduleDetailedInfoObj.setScheduleStartDate(dealEffectiveDate);
		scheduleDetailedInfoObj.setPaymentFrequencyCode(oldDealScheduleProfile.getF_FreqCode());
		scheduleDetailedInfoObj.setPaymentFrequencyUnit(oldDealScheduleProfile.getF_FreqUnit());
		scheduleDetailedInfoObj.setPaymentOption(oldDealScheduleProfile.getF_PaymentOption());
		scheduleDetailedInfoObj.setScheduleOption(oldDealScheduleProfile.getF_scheduleOption());
		scheduleDetailedInfoObj.setFirstPaymentDate(newSchedulefirstPaymentDate);
		scheduleDetailedInfoObj.setFirstPaymentDateWithNWDApplied(newSchedulefirstPaymentDate);
		scheduleDetailedInfoObj.setLastPaymentDate(newScheduleLastPaymentDate);
		scheduleDetailedInfoObj.setLastPaymentDateWithNWDApplied(newScheduleLastPaymentDate);
		scheduleDetailedInfoObj.setNoOfPayment(noOfPayments);
		scheduleDetailedInfoObj.setPrinciplePayment(IBCommonUtils.getBFCurrencyAmount(newDealPrincipal, currencyCode));
		scheduleDetailedInfoObj.setPrinciplePaymentAll(true);

		scheduleDetailedInfoList.addScheduleDetailedInfoList(scheduleDetailedInfoObj);
		LOGGER.info("Exiting from prepareScheduleDetailedInfoObj method");
		return scheduleDetailedInfoList;
	}

	private IBOIB_DLI_ScheduleProfile getDealScheduleRepaymentProfie(String dealId) {
		LOGGER.info("Entering into getDealScheduleRepaymentProfie method");
		String querydealschprofiledtls = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ? and "
				+ IBOIB_DLI_ScheduleProfile.ScheduleType + "=? ";
		ArrayList<Object> param = new ArrayList<Object>();
		param.add(dealId);
		param.add(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOIB_DLI_ScheduleProfile> scheduleProfiles = factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME,
				querydealschprofiledtls, param, null, true);
		if (null != scheduleProfiles && !scheduleProfiles.isEmpty()) {
			return scheduleProfiles.get(0);
		}
		LOGGER.info("Exiting from getDealScheduleRepaymentProfie method");
		return null;
	}

	private void amendNewLoanPayment(LoanPayments newLoanPayment, LoanPayments oldLoanPayment) {
		LOGGER.info("Entering into amendNewLoanPayment method");
		newLoanPayment.setFeeAmt(
				newLoanPayment.getFeeAmt().add(oldLoanPayment.getFeeAmt().subtract(oldLoanPayment.getFeeAmtPaid())));
		newLoanPayment.setOutstandingPrincipalAmt(oldLoanPayment.getOutstandingPrincipalAmt());
		newLoanPayment.setPrincipleAmt(newLoanPayment.getPrincipleAmt()
				.add(oldLoanPayment.getPrincipleAmt().subtract(oldLoanPayment.getPrincipalAmtPaid())));
		newLoanPayment.setProfitAmt(newLoanPayment.getProfitAmt()
				.add(oldLoanPayment.getProfitAmt().subtract(oldLoanPayment.getProfitAmtPaid())));
		newLoanPayment.setRepaymentAmt(
				newLoanPayment.getPrincipleAmt().add(newLoanPayment.getFeeAmt()).add(newLoanPayment.getProfitAmt()));
		LOGGER.info("Exiting from amendNewLoanPayment method");
	}	

	private void setNewLoanPayment(LoanPayments newLoanPayment, int noOfPayments, LoanPayments oldLoanPayment) {
		LOGGER.info("Entering into setNewLoanPayment method");
		newLoanPayment.setFeeAmt(oldLoanPayment.getFeeAmt().subtract(oldLoanPayment.getFeeAmtPaid()));
		newLoanPayment.setIsoCurrencyCode(oldLoanPayment.getIsoCurrencyCode());
		newLoanPayment.setOutstandingPrincipalAmt(oldLoanPayment.getOutstandingPrincipalAmt());
		newLoanPayment.setPrincipleAmt(oldLoanPayment.getPrincipleAmt().subtract(oldLoanPayment.getPrincipalAmtPaid()));
		newLoanPayment.setProfitAmt(oldLoanPayment.getProfitAmt().subtract(oldLoanPayment.getProfitAmtPaid()));
		newLoanPayment.setRepaymentAmt(
				newLoanPayment.getPrincipleAmt().add(newLoanPayment.getFeeAmt()).add(newLoanPayment.getProfitAmt()));
		newLoanPayment.setRepaymentNo(noOfPayments + 1);
		newLoanPayment.setRepaymentDate(minFirstPaymentDate);
		newLoanPayment.setRepaymentType(oldLoanPayment.getRepaymentType());
		LOGGER.info("Exiting from setNewLoanPayment method");
	}

	private void persistAssetDetails(BankFusionEnvironment env) {
		LOGGER.info("Entering into persistAssetDetails method");
		
		ArrayList params = new ArrayList();
		params.add(newDealID);		
		String thirdPartyPaymentClause = "WHERE " + IBOIB_IDI_ThirdPartyPaymentDetails.DEALNO + "= ?";
		
		List<IBOIB_IDI_ThirdPartyPaymentDetails> thirdPartyPayments = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, thirdPartyPaymentClause, params, null, true);
		
		for(IBOIB_IDI_ThirdPartyPaymentDetails paymentDtl: thirdPartyPayments) {
			
			ArrayList scheduleParams = new ArrayList();
			scheduleParams.add(paymentDtl.getBoID());
			
			String thirdPartyScheduleClause = "WHERE " + IBOIB_IDI_ThirdPartyPaymentScheduleDetails.THIRDPTYPAYMMENTDTLSID + "= ?";
			factory.bulkDelete(IBOIB_IDI_ThirdPartyPaymentScheduleDetails.BONAME, thirdPartyScheduleClause, scheduleParams);
			factory.commitTransaction();
			factory.beginTransaction();
			
		}
		
		
		factory.bulkDelete(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, thirdPartyPaymentClause, params);
		factory.commitTransaction();
		factory.beginTransaction();
		
		ArrayList newparams1 = new ArrayList();
		newparams1.add(newDealID);		
		String newassetProgressReportClause = "WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + "= ?";
		
		List<IBOCE_IB_AssetProgressReport> newassetProgressReports = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, newassetProgressReportClause, newparams1, null, true);
		
		for(IBOCE_IB_AssetProgressReport report: newassetProgressReports) {
			
			ArrayList newreportDtlParams = new ArrayList();
			newreportDtlParams.add(report.getF_IBREPORTID());
			
			String newassetProgressReportDtlClause = "WHERE " + IBOCE_IB_AssetProgressDtl.IBREPORTID + "= ?";
			
			factory.bulkDelete(IBOCE_IB_AssetProgressDtl.BONAME, newassetProgressReportDtlClause, newreportDtlParams);
			factory.commitTransaction();
			factory.beginTransaction();
			
		}
		
		factory.bulkDelete(IBOCE_IB_AssetProgressReport.BONAME, newassetProgressReportClause, newparams1);
		factory.commitTransaction();
		factory.beginTransaction();
			
		
		getF_IN_ibObject().setDealID(oldDealID);
		ReadAssetData readAssetData = CeUtils.readAssetData(getF_IN_ibObject());
		getF_IN_ibObject().setDealID(newDealID);
		PersistAssetData persistAssetData = new PersistAssetData();
		AssetDtlsList assetDtlsList = new AssetDtlsList();
		for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
			Get3rdPartyForAsset get3rdPartyForAsset = new Get3rdPartyForAsset();
			AssetDtls assetDtls = new AssetDtls();
			String oldAssetId = assetBasicDtls.getAssetId();
			assetDtls.setAssetBasicDtls(assetBasicDtls);
			get3rdPartyForAsset.setF_IN_AssetBasicDtls(assetBasicDtls);
			get3rdPartyForAsset.setF_IN_AssetThirdPartyList(readAssetData.getF_OUT_AssetThirdPartyDtlsList());
			get3rdPartyForAsset.process(env);
			String newAssetId = getNewAssetId(env);
			List<IBOCE_IB_PaymentSchBreakup> assetPaymentBreakUpSch = getPaymentSchBreakUpByDealAsset(oldDealID,
					oldAssetId);
			BigDecimal totalAssetCost = assetBasicDtls.getAssetPrincipalAmount().getCurrencyAmount()
					.subtract(getAssetPaidPrincipalAmount(oldDealID, assetBasicDtls.getAssetId(),assetPaymentBreakUpSch));
			newDealPrincipal = newDealPrincipal.add(totalAssetCost);
			BigDecimal totalOutstandingAssetCost = getAssetOutstandingPrincipalAmount(oldDealID, assetBasicDtls.getAssetId(),assetPaymentBreakUpSch);
			newDisbursedCost = newDisbursedCost.add(totalOutstandingAssetCost);
			BigDecimal totalProfit = getAssetOutstandingProfitAmount(oldDealID, assetBasicDtls.getAssetId(),
					assetPaymentBreakUpSch);
			BigDecimal totalFee = getAssetOutstandingFeeAmount(oldDealID, assetBasicDtls.getAssetId(),
					assetPaymentBreakUpSch);
			newDealProfit = newDealProfit.add(totalProfit);
			newScheduleFeeAmt = newScheduleFeeAmt.add(totalFee);
			BigDecimal assetPurchOrderAmt = BigDecimal.ZERO;
			for (AssetThirdPartyDtls assetThirdPartyDtls : get3rdPartyForAsset.getF_OUT_AssetThirdPartyDtlsList()
					.getAssetThirdPartyDtls()) {
				assetThirdPartyDtls.setAssetID(newAssetId);
				assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().setCurrencyAmount(totalAssetCost);
				if(assetThirdPartyDtls.getThirdPtyBasicDtls().isIncludeInPaymentOrder())
					assetPurchOrderAmt = assetPurchOrderAmt.add(assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().getCurrencyAmount());
			}
			
			ArrayList params1 = new ArrayList();
			params1.add(oldDealID);		
			String assetProgressReportClause = "WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + "= ?";
			
			List<IBOCE_IB_AssetProgressReport> assetProgressReports = IBCommonUtils.getPersistanceFactory()
					.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, assetProgressReportClause, params1, null, true);
			
			for(IBOCE_IB_AssetProgressReport report: assetProgressReports) {
				
				ArrayList reportDtlParams = new ArrayList();
				reportDtlParams.add(report.getF_IBREPORTID());
				reportDtlParams.add(oldAssetId);
				
				String assetProgressReportDtlClause = "WHERE " + IBOCE_IB_AssetProgressDtl.IBREPORTID + "= ? AND "+ IBOCE_IB_AssetProgressDtl.IBASSETID + "= ?";
				
				List<IBOCE_IB_AssetProgressDtl> assetProgressReportsDtl = IBCommonUtils.getPersistanceFactory()
						.findByQuery(IBOCE_IB_AssetProgressDtl.BONAME, assetProgressReportDtlClause, reportDtlParams, null, true);
				
				for(IBOCE_IB_AssetProgressDtl assetProgressDtl:assetProgressReportsDtl) {
					IBOCE_IB_AssetProgressDtl newAssetProgressDtl = (IBOCE_IB_AssetProgressDtl) factory
							.getStatelessNewInstance(IBOCE_IB_AssetProgressDtl.BONAME);
					
					newAssetProgressDtl.setBoID(GUIDGen.getNewGUID());
					newAssetProgressDtl.setF_IBREPORTID(assetProgressDtl.getF_IBREPORTID().concat("1"));
					newAssetProgressDtl.setF_IBASSETID(newAssetId);
					newAssetProgressDtl.setF_IBISINVOICE(assetProgressDtl.isF_IBISINVOICE());
					if(assetProgressDtl.getF_IBINVOICEAMT()!=null)
					newAssetProgressDtl.setF_IBINVOICEAMT(assetProgressDtl.getF_IBINVOICEAMT());
					if(assetProgressDtl.getF_IBCOMPLETIONPERCENT()!=null)
					newAssetProgressDtl.setF_IBCOMPLETIONPERCENT(assetProgressDtl.getF_IBCOMPLETIONPERCENT());
					if(assetProgressDtl.getF_IBPRICELISTNO()!=null)
					newAssetProgressDtl.setF_IBPRICELISTNO(assetProgressDtl.getF_IBPRICELISTNO());
					if(assetProgressDtl.getF_IBPRICELISTYEAR()!=null)
					newAssetProgressDtl.setF_IBPRICELISTYEAR(assetProgressDtl.getF_IBPRICELISTYEAR());
					if(assetProgressDtl.getF_IBMACHINENO()!=null)
					newAssetProgressDtl.setF_IBMACHINENO(assetProgressDtl.getF_IBMACHINENO());
					if(assetProgressDtl.getF_IBMACHINETYPE()!=null)
					newAssetProgressDtl.setF_IBMACHINETYPE(assetProgressDtl.getF_IBMACHINETYPE());
					if(assetProgressDtl.getF_IBATTR7()!=null)
					newAssetProgressDtl.setF_IBATTR7(assetProgressDtl.getF_IBATTR7());
					if(assetProgressDtl.getF_IBATTR8()!=null)
					newAssetProgressDtl.setF_IBATTR8(assetProgressDtl.getF_IBATTR8());
					if(assetProgressDtl.getF_IBATTR9()!=null)
					newAssetProgressDtl.setF_IBATTR9(assetProgressDtl.getF_IBATTR9());
					if(assetProgressDtl.getF_IBACCUMULATEDCALCCOST()!=null)
					newAssetProgressDtl.setF_IBACCUMULATEDCALCCOST(assetProgressDtl.getF_IBACCUMULATEDCALCCOST());
					if(assetProgressDtl.getF_IBACCUMULATEDFINALCOST()!=null)
					newAssetProgressDtl.setF_IBACCUMULATEDFINALCOST(assetProgressDtl.getF_IBACCUMULATEDFINALCOST());
					if(assetProgressDtl.getF_IBADDITIONALNOTES()!=null)
					newAssetProgressDtl.setF_IBADDITIONALNOTES(assetProgressDtl.getF_IBADDITIONALNOTES());
					if(assetProgressDtl.getF_IBADDNLNAME()!=null)
					newAssetProgressDtl.setF_IBADDNLNAME(assetProgressDtl.getF_IBADDNLNAME());
					if(assetProgressDtl.getF_IBADDNLNUMBER()!=null)
					newAssetProgressDtl.setF_IBADDNLNUMBER(assetProgressDtl.getF_IBADDNLNUMBER());
					if(assetProgressDtl.getF_IBADDNLSERIALNO()!=null)
					newAssetProgressDtl.setF_IBADDNLSERIALNO(assetProgressDtl.getF_IBADDNLSERIALNO());
					if(assetProgressDtl.getF_IBEASTCOORDINATEO()!=null)
					newAssetProgressDtl.setF_IBEASTCOORDINATEO(assetProgressDtl.getF_IBEASTCOORDINATEO());
					if(assetProgressDtl.getF_IBEASTCOORDINATE()!=null)
					newAssetProgressDtl.setF_IBEASTCOORDINATE(assetProgressDtl.getF_IBEASTCOORDINATE());
					if(assetProgressDtl.getF_IBNORTHCOORDINATEO()!=null)
					newAssetProgressDtl.setF_IBNORTHCOORDINATEO(assetProgressDtl.getF_IBNORTHCOORDINATEO());
					if(assetProgressDtl.getF_IBNORTHCOORDINATE()!=null)
					newAssetProgressDtl.setF_IBNORTHCOORDINATE(assetProgressDtl.getF_IBNORTHCOORDINATE());
					if(assetProgressDtl.getF_IBALLOWEDFINALCOST()!=null)
					newAssetProgressDtl.setF_IBALLOWEDFINALCOST(assetProgressDtl.getF_IBALLOWEDFINALCOST());
					if(assetProgressDtl.getF_IBADDNLSERIALNO()!=null)
					newAssetProgressDtl.setF_IBACTUALFINALCOST(totalOutstandingAssetCost);
					if(assetProgressDtl.getF_IBADDNLSERIALNO()!=null)
					newAssetProgressDtl.setF_IBFINALCOSTAFTERDEDUCTION(totalOutstandingAssetCost);
					
					newAssetProgressDtl.setF_IBDEDUCTIONAMOUNT(BigDecimal.ZERO);
					
					factory.create(IBOCE_IB_AssetProgressDtl.BONAME, newAssetProgressDtl);
				}
				
			}
			
			
			IBOIB_IDI_ThirdPartyPaymentDetails thirdPartyPayment = (IBOIB_IDI_ThirdPartyPaymentDetails) factory
					.getStatelessNewInstance(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME);
			
			String thirdPartyPaymentDtlsId = GUIDGen.getNewGUID();
			thirdPartyPayment.setBoID(thirdPartyPaymentDtlsId);
			thirdPartyPayment.setF_DEALNO(newDealID);
			thirdPartyPayment.setF_THIRDPARTYID("TP_1");
			thirdPartyPayment.setF_PAYMENTCURRENCYCODE("SAR");
			thirdPartyPayment.setF_THIRDPARTYOFFICEID("116e187e40ec01fE");
			thirdPartyPayment.setF_PAYMENTSCHEDULESTATUS("SCHEDULED");
			thirdPartyPayment.setF_ADVANCEPAYMENTPERCENTAGE(BigDecimal.ZERO);
			thirdPartyPayment.setF_ADVANCEPAYMENTAMT(BigDecimal.ZERO);
			thirdPartyPayment.setF_ADVANCEPAYMENTAMTDT(IBCommonUtils.getBFBusinessDate());
			thirdPartyPayment.setF_REGULARPAYMENTSTARTDT(IBCommonUtils.getBFBusinessDate());
			thirdPartyPayment.setF_REGULARNOOFPAYMENT(1);
			thirdPartyPayment.setF_REGULARPAYMENTFREQUNIT(1);
			thirdPartyPayment.setF_REGULARPAYMENTFREQMODE("YEAR");
			thirdPartyPayment.setF_REGULARTOTALPAYMENTAMT(totalOutstandingAssetCost);
			thirdPartyPayment.setF_DEDUCTIONPAYMENTPERCENTAGE(BigDecimal.ZERO);
			thirdPartyPayment.setF_DEDUCTIONPAYMENTAMT(BigDecimal.ZERO);
			thirdPartyPayment.setF_DEDUCTIONPAYMENTDT(IBCommonUtils.getBFBusinessDate());
			thirdPartyPayment.setF_DEDUCTIONDELIVERYDT(IBCommonUtils.getDealDetails(newDealID).getF_LastRepaymentDate());
			thirdPartyPayment.setF_PENALTYPAYMENTPERCENTAGE(BigDecimal.ZERO);
			thirdPartyPayment.setF_PENALTYPAYMENTAMT(BigDecimal.ZERO);
			thirdPartyPayment.setF_PENALTYPAYMENTDT(IBCommonUtils.getBFBusinessDate());
			thirdPartyPayment.setF_REGULARPAYMENTPERCENTAGE(new BigDecimal(100));
			thirdPartyPayment.setF_ASSETDETAILID(newAssetId);
			
			factory.create(IBOIB_IDI_ThirdPartyPaymentDetails.BONAME, thirdPartyPayment);
			
			IBOIB_IDI_ThirdPartyPaymentScheduleDetails thirdPartyPaymentSchedule = (IBOIB_IDI_ThirdPartyPaymentScheduleDetails) factory
					.getStatelessNewInstance(IBOIB_IDI_ThirdPartyPaymentScheduleDetails.BONAME);
			
			thirdPartyPaymentSchedule.setBoID(GUIDGen.getNewGUID());
			thirdPartyPaymentSchedule.setF_THIRDPTYPAYMMENTDTLSID(thirdPartyPaymentDtlsId);
			thirdPartyPaymentSchedule.setF_PAYMENTNUMBER(1);
			thirdPartyPaymentSchedule.setF_PAYMENTPERCENTAGE(new BigDecimal(100));
			thirdPartyPaymentSchedule.setF_PAYMENTTYPE("PAYMENT");
			thirdPartyPaymentSchedule.setF_PAYMENTAMT(totalOutstandingAssetCost);
			thirdPartyPaymentSchedule.setF_PAYMENTDT(IBCommonUtils.getBFBusinessDate());
			
			factory.create(IBOIB_IDI_ThirdPartyPaymentScheduleDetails.BONAME, thirdPartyPaymentSchedule);
			
			
			assetBasicDtls.setAssetId(newAssetId);
			assetBasicDtls.getCost().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetPrincipalAmount().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetProfitAmount().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetSellingPricePrincipalAmount().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetSellingPriceProfitAmount().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetPurchOrderAmt().setCurrencyAmount(assetPurchOrderAmt);
			assetBasicDtls.getAssetPrincipalAmountAfterResidual().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getAssetProfitAmountAfterResidual().setCurrencyAmount(totalAssetCost);
			assetBasicDtls.getResidualValue().setCurrencyAmount(BigDecimal.ZERO);
			assetBasicDtls.getAssetDownPaymentAmt().setCurrencyAmount(BigDecimal.ZERO);
			assetDtls.setAssetThirdPartyDtls(
					get3rdPartyForAsset.getF_OUT_AssetThirdPartyDtlsList().getAssetThirdPartyDtls());
			assetDtlsList.addAssetDtlsList(assetDtls);
			if (readAssetData.getF_OUT_assetUdfCollection().getAssetUDFsCount() > 0) {
				for (AssetUDF assetUDF : readAssetData.getF_OUT_assetUdfCollection().getAssetUDFs()) {
					if (oldAssetId.equals(assetUDF.getAssetid())) {
						if (assetUDF.getFieldValue() != null && !assetUDF.getFieldValue().isEmpty()
								&& assetUDF.getFieldId().equals(CeUtils.getUDFIDForDisbursementPeriodInYrs())) {
							assetUDF.setFieldValue("0");
						} else if (assetUDF.getFieldValue() != null
								&& assetUDF.getFieldId().equals(CeUtils.getUDFIDForAssetTenor())) {
							assetUDF.setFieldValue(String.valueOf(noOfUnpaidInstallments));
						} else if (assetUDF.getFieldValue() != null
								&& assetUDF.getFieldId().equals(CeUtils.getUDFIDForIsAssetDisbursed())) {
							assetUDF.setFieldValue("NO");
						} else if (assetUDF.getFieldValue() != null
								&& AssetStudyAndInfoUtil.ASSET_ORIGINAL_COST.equals(assetUDF.getFieldId())) {
							assetUDF.setFieldValue(totalAssetCost.toString());
						} else if (assetUDF.getFieldValue() != null
								&& assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_STUDY_COST)) {
							assetUDF.setFieldValue(totalAssetCost.toString());
						} else if (assetUDF.getFieldValue() != null
								&& assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_GRANT_APPROVAL_COST)) {
							assetUDF.setFieldValue(totalAssetCost.toString());
						} else if (assetUDF.getFieldValue() != null
								&& assetUDF.getFieldId().equals(AssetStudyAndInfoUtil.ASSET_FINAL_COST)) {
							assetUDF.setFieldValue(totalAssetCost.toString());
						}

						assetUDF.setAssetid(newAssetId);
					}
				}
			}
			newAssetIdTPSMap.put(newAssetId, get3rdPartyForAsset.getF_OUT_AssetThirdPartyDtlsList());
			oldNewAssetIdsMap.put(oldAssetId, newAssetId);

		}
		
		ArrayList params1 = new ArrayList();
		params1.add(oldDealID);		
		String assetProgressReportClause = "WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + "= ?";
		
		List<IBOCE_IB_AssetProgressReport> assetProgressReports = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, assetProgressReportClause, params1, null, true);
		
		for(IBOCE_IB_AssetProgressReport report: assetProgressReports) {
			IBOCE_IB_AssetProgressReport newReport = (IBOCE_IB_AssetProgressReport) factory
					.getStatelessNewInstance(IBOCE_IB_AssetProgressReport.BONAME);
			
			newReport.setBoID(GUIDGen.getNewGUID());
			newReport.setF_IBREPORTID(report.getF_IBREPORTID().concat("1"));
			newReport.setF_IBDEALNO(newDealID);
			newReport.setF_IBISCOORDINATESMATCH(report.isF_IBISCOORDINATESMATCH());
			if(report.getF_IBINSPECTOR()!=null)
			newReport.setF_IBINSPECTOR(report.getF_IBINSPECTOR());
			if(report.getF_IBREVIEWER()!=null)
			newReport.setF_IBREVIEWER(report.getF_IBREVIEWER());
			if(report.getF_IBVISITDATEG()!=null)
			newReport.setF_IBVISITDATEG(report.getF_IBVISITDATEG());
			if(report.getF_IBVISITDATEH()!=null)
			newReport.setF_IBVISITDATEH(report.getF_IBVISITDATEH());
			if(report.getF_IBNOTES()!=null)
			newReport.setF_IBNOTES(report.getF_IBNOTES());
			if(report.getF_IBDISBURSEMENTNO()!=null)
			newReport.setF_IBDISBURSEMENTNO(report.getF_IBDISBURSEMENTNO());
			newReport.setF_IBTOTALDISBURSEDAMT(newDisbursedCost);
			if(report.getF_IBTOTALPROGRESSPERCENT()!=null)
			newReport.setF_IBTOTALPROGRESSPERCENT(report.getF_IBTOTALPROGRESSPERCENT());
			newReport.setF_IBISLASTDISBURSED(report.isF_IBISLASTDISBURSED());
			newReport.setF_IBISVISITDONE(report.isF_IBISVISITDONE());
			newReport.setF_IBSTATUS("Disbursed");
			
			factory.create(IBOCE_IB_AssetProgressReport.BONAME, newReport);
			
		}
		
		persistAssetData.setF_IN_AssetDtlsList(assetDtlsList);
		persistAssetData.setF_IN_assetUdfCollection(readAssetData.getF_OUT_assetUdfCollection());
		persistAssetData.setF_IN_IslamicBankingObject(getF_IN_ibObject());
		persistAssetData.process(env);
		LOGGER.info("Exiting from persistAssetDetails method");
	}

	public String getNewAssetId(BankFusionEnvironment env) {
		LOGGER.info("Entering into getNewAssetId method");
		HashMap<String, Object> outputParams = MFExecuter.executeMF("IB_IDI_GenerateAssetID_SRV", env);
		String assetId = (String) outputParams.get("PrimKey");
		LOGGER.info("Exiting from getNewAssetId method");
		return assetId;
	}

	public BigDecimal getAssetPaidPrincipalAmount(String dealId, String assetId,
			List<IBOCE_IB_PaymentSchBreakup> assetPaymentBreakUpSch) {
		LOGGER.info("Entering into getAssetPaidPrincipalAmount method");
		BigDecimal principalAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		ArrayList<IBOCE_IB_PaymentSchBreakup> paymentSchedulesOfAsset = new ArrayList<IBOCE_IB_PaymentSchBreakup>();
		noOfUnpaidInstallments = 0;
		boolean arrearsPresent = false;
		boolean paymentOnBDExits = false;
		boolean partiallyPaidExists = false;
		if (assetPaymentBreakUpSch != null && !assetPaymentBreakUpSch.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : assetPaymentBreakUpSch) {
				totalAssetCost = totalAssetCost.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
				principalAmountPaid = principalAmountPaid.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID());
				if ((null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) == 0)) {
					if (CalendarUtil.IsDate1GreaterThanDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						arrearsPresent = true;
					} else if (CalendarUtil.IsDate1EqualsToDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						arrearsPresent = false;
						paymentOnBDExits = true;
					} else {
						noOfUnpaidInstallments++;
					}
					paymentSchedulesOfAsset.add(paymentSchBreakup);
				} else if ((null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) != 0
						&& paymentSchBreakup.getF_IBSCHEDULEFEEAMT()
								.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBPRINCIPALAMT()
										.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBPROFITAMT()
										.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBSUBSIDYAMNT()
										.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) != 0)) {
					if (CalendarUtil.IsDate1GreaterThanDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						partiallyPaidExists = true;
					} else if (CalendarUtil.IsDate1EqualsToDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						partiallyPaidExists = false;
						paymentOnBDExits = true;
					}
					paymentSchedulesOfAsset.add(paymentSchBreakup);
				}

			}
		}
		if (!paymentOnBDExits && (arrearsPresent || partiallyPaidExists))
			noOfUnpaidInstallments++;
		oldAssetIdPaymentSchedulesMap.put(assetId, paymentSchedulesOfAsset);
		LOGGER.info("Exiting from getAssetPaidPrincipalAmount method");
		return principalAmountPaid;
		
	}

	public BigDecimal getAssetOutstandingPrincipalAmount(String dealId, String assetId,
			List<IBOCE_IB_PaymentSchBreakup> assetPaymentBreakUpSch) {
		LOGGER.info("Entering into getAssetOutstandingPrincipalAmount method");
		BigDecimal principalAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		ArrayList<IBOCE_IB_PaymentSchBreakup> paymentSchedulesOfAsset = new ArrayList<IBOCE_IB_PaymentSchBreakup>();
		noOfUnpaidInstallments = 0;
		boolean arrearsPresent = false;
		boolean paymentOnBDExits = false;
		boolean partiallyPaidExists = false;
		if (assetPaymentBreakUpSch != null && !assetPaymentBreakUpSch.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : assetPaymentBreakUpSch) {
				totalAssetCost = totalAssetCost.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
				principalAmountPaid = principalAmountPaid.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID());
				if ((null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) == 0)
						&& (null == paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								|| BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) == 0)) {
					if (CalendarUtil.IsDate1GreaterThanDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						arrearsPresent = true;
					} else if (CalendarUtil.IsDate1EqualsToDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						arrearsPresent = false;
						paymentOnBDExits = true;
					} else {
						noOfUnpaidInstallments++;
					}
					paymentSchedulesOfAsset.add(paymentSchBreakup);
				} else if ((null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
						&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) != 0
						&& paymentSchBreakup.getF_IBSCHEDULEFEEAMT()
								.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBPRINCIPALAMT()
										.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBPROFITAMT()
										.compareTo(paymentSchBreakup.getF_IBPROFITAMTPAID()) != 0)
						|| (null != paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()
								&& BigDecimal.ZERO.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) != 0
								&& paymentSchBreakup.getF_IBSUBSIDYAMNT()
										.compareTo(paymentSchBreakup.getF_IBSUBSIDYAMTPAID()) != 0)) {
					if (CalendarUtil.IsDate1GreaterThanDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						partiallyPaidExists = true;
					} else if (CalendarUtil.IsDate1EqualsToDate2(minFirstPaymentDate,
							paymentSchBreakup.getF_IBBILLDATE())) {
						partiallyPaidExists = false;
						paymentOnBDExits = true;
					}
					paymentSchedulesOfAsset.add(paymentSchBreakup);
				}

			}
		}
		if (!paymentOnBDExits && (arrearsPresent || partiallyPaidExists))
			noOfUnpaidInstallments++;
		oldAssetIdPaymentSchedulesMap.put(assetId, paymentSchedulesOfAsset);
		LOGGER.info("Exiting from getAssetOutstandingPrincipalAmount method");
		return totalAssetCost.subtract(principalAmountPaid);
		
	}

	
	public BigDecimal getAssetOutstandingProfitAmount(String dealId, String assetId,
			List<IBOCE_IB_PaymentSchBreakup> assetPaymentBreakUpSch) {
		LOGGER.info("Entering into getAssetOutstandingProfitAmount method");
		BigDecimal profitAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetProfitAmount = BigDecimal.ZERO;

		if (assetPaymentBreakUpSch != null && !assetPaymentBreakUpSch.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : assetPaymentBreakUpSch) {
				totalAssetProfitAmount = totalAssetProfitAmount.add(paymentSchBreakup.getF_IBPROFITAMT());
				profitAmountPaid = profitAmountPaid.add(paymentSchBreakup.getF_IBPROFITAMTPAID());
			}
		}
		LOGGER.info("Exiting from getAssetOutstandingProfitAmount method");
		return totalAssetProfitAmount.subtract(profitAmountPaid);
		
	}

	public List<IBOCE_IB_PaymentSchBreakup> getPaymentSchBreakUpByDealAsset(String dealId, String assetId) {
		LOGGER.info("Entering into getPaymentSchBreakUpByDealAsset method");
		String whereClauseForbreakUp = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + "= ? AND "
				+ IBOCE_IB_PaymentSchBreakup.IBASSETID + "= ? ";
		ArrayList<String> queryParams = new ArrayList<>();
		queryParams.add(dealId);
		queryParams.add(assetId);
		List<IBOCE_IB_PaymentSchBreakup> resultSet = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereClauseForbreakUp, queryParams, null, true);
		LOGGER.info("Exiting from getPaymentSchBreakUpByDealAsset method");
		return resultSet;
	}

	public BigDecimal getAssetOutstandingFeeAmount(String dealId, String assetId,
			List<IBOCE_IB_PaymentSchBreakup> assetPaymentBreakUpSch) {
		LOGGER.info("Entering into getAssetOutstandingFeeAmount method");
		BigDecimal feeAmountPaid = BigDecimal.ZERO;
		BigDecimal totalAssetFeeAmount = BigDecimal.ZERO;

		if (assetPaymentBreakUpSch != null && !assetPaymentBreakUpSch.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : assetPaymentBreakUpSch) {
				totalAssetFeeAmount = totalAssetFeeAmount.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				feeAmountPaid = feeAmountPaid.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
			}
		}
		LOGGER.info("Exiting from getAssetOutstandingFeeAmount method");
		return totalAssetFeeAmount.subtract(feeAmountPaid);
		
	}

	private boolean persistTransferDebtsDetails(BankFusionEnvironment env) {
		LOGGER.info("Entering into persistTransferDebtsDetails method");
		String statusTransferredDesc = IBCommonUtils.getGCChildDesc(CeConstants.TD_STATUS_GC_PARENT_REF,
				CeConstants.TD_STATUS_TRANSFERRED);
		boolean continuePersist = false;
		for (TransferDebtsHistory transferDebtsHistory : getF_IN_transferDebtsHistoryRq()
				.getTransferDebtsHistorylist()) {
			if (!statusTransferredDesc.equals(transferDebtsHistory.getStatus())) {
				continuePersist = true;
				if(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(transferDebtsHistory.getTransferReqDate()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TRANSFER_DEBT_REQ_DT_MANDATORY_CEIB);
				if(IBCommonUtils.isEmpty(transferDebtsHistory.getDocNumber()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_DOCUMENT_NO_MANDATORY_CEIB);
				if(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(transferDebtsHistory.getDocDate()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_DOCUMENT_DT_MANDATORY_CEIB);
				if(IBCommonUtils.isEmpty(transferDebtsHistory.getReasonCode()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_REASON_MANDATORY_CEIB);
				
				IBOCE_IB_TransferOfDebtDtls transferOfDebtDtls = (IBOCE_IB_TransferOfDebtDtls) factory.findByPrimaryKey(
						IBOCE_IB_TransferOfDebtDtls.BONAME, transferDebtsHistory.getTransferReqIDPk());
				if (null != transferOfDebtDtls) {
					oldDealID = transferDebtsHistory.getFromDealID();
					transferOfDebtDtls.setF_IBDOCDATE(transferDebtsHistory.getDocDate());
					transferOfDebtDtls.setF_IBDOCNUMBER(transferDebtsHistory.getDocNumber());
					transferOfDebtDtls.setF_IBOSDEALAMT(transferDebtsHistory.getOsDealAmt().getCurrencyAmount());
					transferOfDebtDtls
							.setF_IBOSPRINCIPALAMT(transferDebtsHistory.getOsPrincipalAmt().getCurrencyAmount());
					transferOfDebtDtls.setF_IBOSPROFITAMT(transferDebtsHistory.getOsProfitAmt().getCurrencyAmount());
					transferOfDebtDtls.setF_IBRESCHREQUIRED(transferDebtsHistory.isReschRequired());
					transferOfDebtDtls.setF_IBSUBSDCONTINUE(transferDebtsHistory.isContinueSubsidy());
					transferOfDebtDtls.setF_IBTDREASON(transferDebtsHistory.getReasonCode());
					dealStartDate = transferDebtsHistory.getTransferReqDate();
					if (CalendarUtil.IsDate1GreaterThanDate2(dealStartDate, IBCommonUtils.getBFBusinessDate()))
						dealEffectiveDate = dealStartDate;
					else
						dealEffectiveDate = IBCommonUtils.getBFBusinessDate();
					continueSubsidy = transferDebtsHistory.isContinueSubsidy();
					transferOfDebtDtls.setF_IBTDREQDATE(transferDebtsHistory.getTransferReqDate());
					transferOfDebtDtls.setF_IBTDREQNOTE(transferDebtsHistory.getNotes());
					transferOfDebtDtls.setF_IBTDSTATUS(CeConstants.TD_STATUS_SCHEDULED);
					transferOfDebtDtls.setF_RECLASTMODIFIEDBY(env.getUserID());
					transferOfDebtDtls.setF_RECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
					transferOfDebtDtls.setF_RECSYSDATE(IBCommonUtils.getBFSystemDateTime());
				}
			}
		}
		LOGGER.info("Exiting from persistTransferDebtsDetails method");
		return continuePersist;
	}

}
