package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadDealValidationExceptions;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.ce.ib.validation.processor.ValidationProcessor;
import com.misys.bankfusion.subsystem.organisationgroup.mbean.impl.OrganizationGroupService;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.DealValidation;
import bf.com.misys.ib.types.DealValidationList;
import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationConfList;

public class ReadDealValidationExceptions extends AbstractCE_IB_ReadDealValidationExceptions{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2887243023011897748L;

	public ReadDealValidationExceptions()
	{
		super();
	}

	public ReadDealValidationExceptions(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();

		switch(context)
		{
		case "PREPARE" :
			processAndPrepareValidationsForDeal();
			break;
		case "APPROVAL" :
			readValidationsForApproval();
			break;
		default:
			break;
		}
		if(getF_OUT_dealValidationExceptions().getDealValidationsCount() == 0)
		{
			setF_OUT_isNoOfExcpsZero(true);
		}
	}

	private void readValidationsForApproval() {
		DealValidationList dealValidationList = new  DealValidationList();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String query = "SELECT a." + IBOCE_IB_DealValidations.IBDEALVALIDATIONID + " AS "
				+ IBOCE_IB_DealValidations.IBDEALVALIDATIONID + ", b." + IBOCE_IB_ValidationConfiguration.IBVALIDATIONID
				+ " AS " + IBOCE_IB_ValidationConfiguration.IBVALIDATIONID
				+ " from " + IBOCE_IB_DealValidations.BONAME
				+ " as a, "+ IBOCE_IB_ValidationConfiguration.BONAME + " as b "
				+ "WHERE b." + IBOCE_IB_ValidationConfiguration.IBVALIDATIONCONFID + " = a."
				+ IBOCE_IB_DealValidations.IBVALIDATIONCONFID + " AND a." + IBOCE_IB_DealValidations.IBDEALID
				+ " = ? AND b." + IBOCE_IB_ValidationConfiguration.IBAPPROVALUSERID + " IN ";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islmaicBankingObj().getDealID());
		//params.add(BankFusionThreadLocal.getUserId());
		List<SimplePersistentObject> resultSet = factory.executeGenericQuery(query+prepareInClauseForUser(), params, null, false);
		for (SimplePersistentObject eachEntry : resultSet)
		{
			String dealValidationID = (String) eachEntry.getDataMap().get(IBOCE_IB_DealValidations.IBDEALVALIDATIONID);
			IBOCE_IB_DealValidations eachDealValidations = (IBOCE_IB_DealValidations) factory.findByPrimaryKey(IBOCE_IB_DealValidations.BONAME,dealValidationID, true);
			DealValidation dealValidation = new DealValidation();
			//dealValidation.setActionType(eachDealValidations.getF_IBACTIONTYPE());
			dealValidation.setAdditionalDtls(eachDealValidations.getF_IBADDITIONALDTL());
			if(ValidationExceptionConstants.STATUS_APPROVED.equalsIgnoreCase(eachDealValidations.getF_IBSTATUS()) ||
					ValidationExceptionConstants.STATUS_REJECTED.equalsIgnoreCase(eachDealValidations.getF_IBSTATUS()))
			{
				dealValidation.setApprovalUserID(eachDealValidations.getF_RECAPPROVEDBY());
				dealValidation.setStatus(eachDealValidations.getF_IBSTATUS());
			}
			dealValidation.setApproverComment(eachDealValidations.getF_IBAPPROVERCOMMENT());
			dealValidation.setDealID(getF_IN_islmaicBankingObj().getDealID());
			dealValidation.setOriginatingUserID(eachDealValidations.getF_RECCREATEDBY());
			dealValidation.setProcessID(eachDealValidations.getF_IBPROCESSCONFIGID());
			dealValidation.setStepID(eachDealValidations.getF_IBSTEPID());
			dealValidation.setValidationID((String)eachEntry.getDataMap().get(IBOCE_IB_ValidationConfiguration.IBVALIDATIONID));
			dealValidation.setDealValidationID(eachDealValidations.getBoID());
			dealValidation.setIsReApproval(eachDealValidations.isF_IBREAPPROVAL());
			dealValidationList.addDealValidations(dealValidation);
		}
		setF_OUT_dealValidationExceptions(dealValidationList);
	}

	private void processAndPrepareValidationsForDeal() {
		DealValidationList dealValidationList = new  DealValidationList();
		HashMap<String, IBOCE_IB_DealValidations> validationsInDB = new HashMap<>();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ? AND "
				+IBOCE_IB_DealValidations.IBSTEPID + " = ? AND "
				+ IBOCE_IB_DealValidations.IBPROCESSCONFIGID + " = ?";
		String dealID = getF_IN_islmaicBankingObj().getDealID();
		ArrayList<String> params = new ArrayList<>();
		params.add(dealID);
		params.add(getF_IN_islmaicBankingObj().getStepID());
		params.add(getF_IN_islmaicBankingObj().getProcessConfigID());
		List<IBOCE_IB_DealValidations> dealValidationsList = factory.findByQuery(IBOCE_IB_DealValidations.BONAME, whereClause, params, null, false);
		for (IBOCE_IB_DealValidations eachDealValidations : dealValidationsList)
		{
			validationsInDB.put(eachDealValidations.getF_IBVALIDATIONCONFID(),eachDealValidations);
		}
		ValidationConfList configuredValidations = ValidationsUtil.
				getValidationListForProcessAndStep(getF_IN_islmaicBankingObj().getProcessConfigID(), getF_IN_islmaicBankingObj().getStepID());
		for(ValidationConf eachConfiguredValidations : configuredValidations.getValidationConf())
		{
			if(ValidationProcessor.processValidation(getF_IN_islmaicBankingObj(), eachConfiguredValidations.getValidationID()))
			{
				DealValidation dealValidation = new DealValidation();
				dealValidation.setActionType(eachConfiguredValidations.getActionType());
				dealValidation.setApprovalUserID(eachConfiguredValidations.getApprovalUserID());
				dealValidation.setStatus(ValidationExceptionConstants.STATUS_NEW);
				dealValidation.setDealID(getF_IN_islmaicBankingObj().getDealID());
				dealValidation.setOriginatingUserID(BankFusionThreadLocal.getUserId());
				dealValidation.setProcessID(getF_IN_islmaicBankingObj().getProcessConfigID());
				dealValidation.setStepID(getF_IN_islmaicBankingObj().getStepID());
				dealValidation.setValidationID(eachConfiguredValidations.getValidationID());
				dealValidation.setValidationConfID(eachConfiguredValidations.getValidationConfID());
				if(null != validationsInDB.get(eachConfiguredValidations.getValidationConfID()))
				{
					IBOCE_IB_DealValidations persistedValidation = validationsInDB.get(eachConfiguredValidations.getValidationConfID());
					dealValidation.setAdditionalDtls(persistedValidation.getF_IBADDITIONALDTL());
					dealValidation.setApproverComment(persistedValidation.getF_IBAPPROVERCOMMENT());
					dealValidation.setApprovalUserID(persistedValidation.getF_RECAPPROVEDBY());
					if(ValidationExceptionConstants.ACTION_APPROVAL.equals(eachConfiguredValidations.getActionType()))
					{
						dealValidation.setStatus(persistedValidation.getF_IBSTATUS());
					}
					dealValidation.setDealValidationID(persistedValidation.getBoID());
				}
				dealValidationList.addDealValidations(dealValidation);
			}
		}
		//the below code is to delete the any previously prepared validation exceptions in case there is no exceptions in currently.
		if(dealValidationList.getDealValidationsCount() == 0)
		{
			String deleteQuery = "WHERE " + IBOCE_IB_DealValidations.IBDEALID + " = ? AND "
					+ IBOCE_IB_DealValidations.IBPROCESSCONFIGID + " = ? AND "
					+ IBOCE_IB_DealValidations.IBSTEPID + " = ?";
			params.clear();
			params.add(getF_IN_islmaicBankingObj().getDealID());
			params.add(getF_IN_islmaicBankingObj().getProcessConfigID());
			params.add(getF_IN_islmaicBankingObj().getStepID());
			factory.bulkDelete(IBOCE_IB_DealValidations.BONAME, deleteQuery,params);
		}
		setF_OUT_dealValidationExceptions(dealValidationList);
	}
	
	private String prepareInClauseForUser() {
		String userID = BankFusionThreadLocal.getUserId();
		List<String> groupIDs = OrganizationGroupService.getInstance().getGroupIDsFromUserID(userID);
		groupIDs.add(userID);
		StringBuilder builder = new StringBuilder();
		builder.append("(");
		for(String item : groupIDs)
		{
			builder.append("'"+item+"',");
		}
		String finalInClause = builder.substring(0, builder.length()-1);
		finalInClause = finalInClause+")";
		return finalInClause;
	}

}
