package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SubsidyHandling;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealPostponeDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_ScheduleAmendmentDetails;
import com.misys.bankfusion.ib.util.PostponeInstallmentsUtils;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class SubsidyHandling extends AbstractCE_IB_SubsidyHandling {

	public static String whereClause = "WHERE " + IBOIB_IDI_ScheduleAmendmentDetails.POSTPONEREQUESTID + " =? ";
	public static String paymentSchBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " =?";

	public SubsidyHandling(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		subsidyHandlingForPostpone();
	}

	private void subsidyHandlingForPostpone() {
		IBOIB_IDI_DealPostponeDetails dealPostponeDetails = PostponeInstallmentsUtils
				.getDealPostponeDetailsByTransID(getF_IN_islamicBankingObject().getTransactionID());
		if (dealPostponeDetails != null
				&& getF_IN_islamicBankingObject().getStepID().equals(CeConstants.STEPID_PROCESSDEALPOSTPONE)) {
			ArrayList<String> param = new ArrayList<String>();
			param.add(getF_IN_islamicBankingObject().getTransactionID());

			List<IBOIB_IDI_ScheduleAmendmentDetails> scheduleAmendmentDetails = (List<IBOIB_IDI_ScheduleAmendmentDetails>) IBCommonUtils
					.getPersistanceFactory()
					.findByQuery(IBOIB_IDI_ScheduleAmendmentDetails.BONAME, whereClause, param, null, true);
			if (scheduleAmendmentDetails != null && !scheduleAmendmentDetails.isEmpty()) {
				for (IBOIB_IDI_ScheduleAmendmentDetails amendmentDetails : scheduleAmendmentDetails) {
					adjustPaymentScheduleBreakUp(amendmentDetails);
				}
			}
		}
	}

	private void adjustPaymentScheduleBreakUp(IBOIB_IDI_ScheduleAmendmentDetails amendmentDetails) {
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_PaymentSchBreakup> paymentScheduleBreakupDtls = (ArrayList<IBOCE_IB_PaymentSchBreakup>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, paymentSchBreakupQuery, param, null, true);

		if (paymentScheduleBreakupDtls != null && !paymentScheduleBreakupDtls.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : paymentScheduleBreakupDtls) {
				if (CalendarUtil.IsDate1EqualsToDate2(paymentSchBreakup.getF_IBBILLDATE(),
						amendmentDetails.getF_CURRENTDATE())) {
					paymentSchBreakup.setF_IBBILLDATE(amendmentDetails.getF_NEWDATE());
					if ((int) CalendarUtil.getMonthsBetweenDate1AndDate2(amendmentDetails.getF_NEWDATE(),
							amendmentDetails.getF_CURRENTDATE()) > CeUtils.getSubsidyHandlingPeriodConfigured())
						paymentSchBreakup.setF_IBSUBSIDYAMNT(BigDecimal.ZERO);
				}
			}
		}

	}

}
