package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TDNewCustValidation;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.spi.types.CustomerDetails;
import bf.com.misys.ib.types.TrnsfDbtsElgDeal;
import bf.com.misys.ib.types.TrnsfDbtsElgDealsList;

public class TDNewCustValidation extends AbstractCE_IB_TDNewCustValidation{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 56528254731446553L;

	public TDNewCustValidation()
	{
		super();
	}

	public TDNewCustValidation(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		String partyID = getF_IN_partyID();
		String enteredPartyID = null!= partyID?partyID:getF_IN_readCustomerRs().getCustomerDetails().getCustomerBasicDetails().getCustomerId();
		TrnsfDbtsElgDealsList selectedDealsForTD = getF_IN_selectedDealsForTD();
		if(null != selectedDealsForTD && selectedDealsForTD.getTrnsfDbtsElgDealsCount() > 0)
		{
			for(TrnsfDbtsElgDeal selectedDealForTD : selectedDealsForTD.getTrnsfDbtsElgDeals())
				//checking whether selected party is among the selectedForTDDeal holder
			if((selectedDealForTD.getPartyID()).equals(enteredPartyID))
			{
				IBCommonUtils.raiseUnparameterizedEvent(44000386);
			}
		}
		CustomerDetails partyDetails = null;
		if(null != partyID)
		{
			partyDetails = IBCommonUtils.getPartyDetailsFromPartyID(partyID, env);
		}
		else
		{
			partyDetails = getF_IN_readCustomerRs().getCustomerDetails();
		}
		
		//full and active check for the new party
		if(!"FULL".equals(partyDetails.getCustomerBasicDetails().getPartyCategory()) || 
				!"001".equals(partyDetails.getCustomerBasicDetails().getPartyStatus()))
		{
			IBCommonUtils.raiseUnparameterizedEvent(35100312);
		}
			
	}
}
