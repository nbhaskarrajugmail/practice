package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipAgents;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipPanel;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistRelationShipDetails;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_PersistRelationShipDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.fatom.AssociateThirdPartyToAsset;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.DealRelationshipDetails;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipAgents;
import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipDtls;
import bf.com.misys.ib.types.IslamicBankingObject;

public class PersistRelationShipDetails extends AbstractCE_IB_PersistRelationShipDetails
        implements ICE_IB_PersistRelationShipDetails {
    private static final transient Log LOGGER = LogFactory.getLog(AssociateThirdPartyToAsset.class.getName());

    private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();


    public PersistRelationShipDetails() {
        // TODO Auto-generated constructor stub
    }

    public PersistRelationShipDetails(BankFusionEnvironment env) {
        super(env);

    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        LOGGER.info("Entering into process -->"+getF_IN_dealRelationShipDetails().getDealId());
        if (getF_IN_dealRelationShipDetails().getRelationshipDtlsCount() == 0)
        {
            deleteAllExistingDetails();
            LOGGER.info("Exiting from process, Relationship details are empty -->"+getF_IN_dealRelationShipDetails().getDealId());
            return;
        }
        deleteExistingDetails();
        if(!getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
            persistsDealRelationDetails();
        }
        LOGGER.info("Exiting from process -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

    private void deleteAllExistingDetails() {    
        deleteExistingDetails(); 
        if(null!=getF_IN_ibObject() && getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
	    	 deleteAgentsDetailsByDealID();
	         deletePanelDetailsByDealID();
	    }
       
    }

    private void deletePanelDetailsByDealID() {
        List<String> params = new ArrayList<String>();
        String panelWhereClause = " where "+IBOCE_IB_DealRelationshipPanel.IBDEALID+"=?";
        params.add(getF_IN_dealRelationShipDetails().getDealId());
        factory.bulkDeleteall(IBOCE_IB_DealRelationshipPanel.BONAME, panelWhereClause , params);
        factory.commitTransaction();
        factory.beginTransaction();
    }

    private void deleteAgentsDetailsByDealID() {
        String agentsWhereClause = " where "+IBOCE_IB_DealRelationshipAgents.IBDEALID+"=?";
        List<String> params = new ArrayList<String>();
        params.add(getF_IN_dealRelationShipDetails().getDealId());
        factory.bulkDeleteall(IBOCE_IB_DealRelationshipAgents.BONAME, agentsWhereClause , params);
        factory.commitTransaction();
        factory.beginTransaction();
    }

    private void persistsDealRelationDetails() {
        LOGGER.info("Entering into persistsDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
        for (RelationshipDtls dealRelationshipDetails : getF_IN_dealRelationShipDetails().getRelationshipDtls()) {
            boolean isGauranteeToPayPanelVisible = false;
            boolean isPartnersPanelVisible = false;
            boolean isAgentsPanelVisible = false;
            IBOCE_IB_DealRelationshipDetails existingRelationshipDtls = (IBOCE_IB_DealRelationshipDetails) factory.findByPrimaryKey(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationshipDetails.getRelationshipDtlId(),true);
            if(existingRelationshipDtls==null) {
            createNewDealRelationDetails(dealRelationshipDetails, isGauranteeToPayPanelVisible, isPartnersPanelVisible,
                    isAgentsPanelVisible);
            }
            else {
            	updateExistingRelationDetails(dealRelationshipDetails, isGauranteeToPayPanelVisible, isPartnersPanelVisible, isAgentsPanelVisible);
            }
        }
        LOGGER.info("Exiting from persistsDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
    }
    private void persistsDealRelationDetails(DealRelationshipDetails uiList) {
		LOGGER.info("Entering into persistsDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
        for (RelationshipDtls dealRelationshipDetails : uiList.getRelationshipDtls()) {
            boolean isGauranteeToPayPanelVisible = false;
            boolean isPartnersPanelVisible = false;
            boolean isAgentsPanelVisible = false;
            createNewDealRelationDetails(dealRelationshipDetails, isGauranteeToPayPanelVisible, isPartnersPanelVisible,
                    isAgentsPanelVisible);
        }
        LOGGER.info("Exiting from persistsDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

    private void updateExistingRelationDetails(RelationshipDtls dealRelationshipDetails,
			boolean isGauranteeToPayPanelVisible, boolean isPartnersPanelVisible, boolean isAgentsPanelVisible) {
		// TODO Auto-generated method stub
        
    	IBOCE_IB_DealRelationshipDetails existingRelationshipDtls = (IBOCE_IB_DealRelationshipDetails) factory.findByPrimaryKey(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationshipDetails.getRelationshipDtlId(),true);

    	LOGGER.info("Entering into ExistingDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
        IslamicBankingObject ibo = getF_IN_ibObject();
        existingRelationshipDtls.setF_IBSTATUS(RescheduleConstants.STATUS_NEW);
        existingRelationshipDtls.setF_IBDEALSTATUS(null==dealRelationshipDetails.getDealStatus()||dealRelationshipDetails.getDealStatus().isEmpty()?RescheduleConstants.STATUS_NEW:dealRelationshipDetails.getDealStatus());
        if(!ibo.getTransactionID().equals(getF_IN_dealRelationShipDetails().getDealId())) {
        	existingRelationshipDtls.setF_IBTRANSACTIONID(ibo.getTransactionID().toString() != null?ibo.getTransactionID().toString():getF_IN_dealRelationShipDetails().getDealId());
        }
        
        existingRelationshipDtls.setF_IBDEALID(getF_IN_dealRelationShipDetails().getDealId());
        existingRelationshipDtls.setF_IBRELATIONSHIPTYPE(dealRelationshipDetails.getRelationshipType());
        existingRelationshipDtls.setF_IBPARTYID(dealRelationshipDetails.getPartyId());
        existingRelationshipDtls.setF_IBPARTYNAME(dealRelationshipDetails.getPartyName());
        existingRelationshipDtls.setF_IBPARTYNATIONALID(dealRelationshipDetails.getPartyNationalId());
        if (null!=dealRelationshipDetails.getDisplayPartners() && dealRelationshipDetails.getDisplayPartners()) {
            isPartnersPanelVisible = true;
            existingRelationshipDtls.setF_IBPARTNERSHIPPER(dealRelationshipDetails.getPartnershipPercentage());
            existingRelationshipDtls.setF_IBPARTNERSTATUS(dealRelationshipDetails.getPartnerStatus());
        }
        if (null!=dealRelationshipDetails.getDisplayGuranteeToPay() && dealRelationshipDetails.getDisplayGuranteeToPay()) {
            isGauranteeToPayPanelVisible = true;
            existingRelationshipDtls.setF_IBPLEDGEAMOUNT(dealRelationshipDetails.getPledgeAmount().getCurrencyAmount());
            existingRelationshipDtls.setF_IBPLEDGETYPE(dealRelationshipDetails.getPledgeType());
            existingRelationshipDtls.setF_IBSILOAREA(dealRelationshipDetails.getSiloArea());
            existingRelationshipDtls.setF_IBSILOYEAR(dealRelationshipDetails.getSiloYear());
            existingRelationshipDtls.setF_IBFROMDATE(dealRelationshipDetails.getFromDate());
            existingRelationshipDtls.setF_IBTODATE(dealRelationshipDetails.getToDate());
        }
        factory.commitTransaction();
        factory.beginTransaction();
        if (getF_IN_dealRelationShipDetails().getRelationshipAgentsCount() > 0) {
            if(getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
                deleteExistingAgents(dealRelationshipDetails,isAgentsPanelVisible);
            }else {
                deleteExistingAgents(dealRelationshipDetails);
                persistsRelationShipAgents(dealRelationshipDetails,isAgentsPanelVisible);
            }
            
        }
        persistRelationPanelData(dealRelationshipDetails, isGauranteeToPayPanelVisible, isPartnersPanelVisible,
                isAgentsPanelVisible);
        LOGGER.info("Exiting from createNewDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
    
	}

	private void deleteExistingDetails() {
        LOGGER.info("Entering into deleteExistingDetails-->"+getF_IN_dealRelationShipDetails().getDealId());
        String relationDtlsWhereClause = " where "+IBOCE_IB_DealRelationshipDetails.IBDEALID+" = ?";
        List<String> params = new ArrayList<String>();
        params.add(getF_IN_dealRelationShipDetails().getDealId());
        if (null!=getF_IN_ibObject() && getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
			List<IBOCE_IB_DealRelationshipDetails> resultSet = factory.findByQuery(
					IBOCE_IB_DealRelationshipDetails.BONAME, relationDtlsWhereClause, (ArrayList) params, null, true);

			DealRelationshipDetails uiList = getF_IN_dealRelationShipDetails();
			RelationshipDtls[] uiListCopy = uiList.getRelationshipDtls().clone();
			for (IBOCE_IB_DealRelationshipDetails result : resultSet) {
				boolean isremove = true;
				for (RelationshipDtls listItem : uiListCopy) {
					if (listItem.getRelationshipDtlId().equals(result.getBoID()) && null!= listItem.getDealStatus() && listItem.getDealStatus().equals(result.getF_IBDEALSTATUS())) {
						uiList.removeRelationshipDtls(listItem);
						isremove = false;
					}
				}
				if(isremove)
				{
					deleteRelationshipDtls(result);
				}
			}
			if (uiList.getRelationshipDtlsCount() > 0) {
				persistsDealRelationDetails(uiList);
			}
		} else {
			
			DealRelationshipDetails uiList = getF_IN_dealRelationShipDetails();
			RelationshipDtls[] uiListCopy = uiList.getRelationshipDtls().clone();
			String relationDtlWhereClause = " where "+ IBOCE_IB_DealRelationshipDetails.IBDEALID +" = ? AND "+IBOCE_IB_DealRelationshipDetails.IBTRANSACTIONID+ " = ?";
			List<String> param = new ArrayList<String>();
		    param.add(getF_IN_dealRelationShipDetails().getDealId());
		    param.add("");
		    List<IBOCE_IB_DealRelationshipDetails> resultSet = factory.findByQuery(
		        		IBOCE_IB_DealRelationshipDetails.BONAME, relationDtlWhereClause, (ArrayList) param, null, true);       
			    
		    // factory.bulkDeleteall(IBOCE_IB_DealRelationshipDetails.BONAME, relationDtlWhereClause, param);
				for (IBOCE_IB_DealRelationshipDetails result : resultSet) {
					boolean isremove = true;
					for (RelationshipDtls listItem : uiListCopy) {
						if (listItem.getRelationshipDtlId().equals(result.getBoID())) {
							//uiList.removeRelationshipDtls(listItem);
							isremove = false;
						}
					}
					if(isremove)
					{
						deleteRelationshipDtls(result);
					}
				}
			    factory.bulkDeleteall(IBOCE_IB_DealRelationshipDetails.BONAME, relationDtlWhereClause, param);
		      LOGGER.info("Deleting existing details of deal service");
		}
        factory.commitTransaction();
        factory.beginTransaction();
        LOGGER.info("Exiting from deleteExistingDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
    }
    
    private void deleteRelationshipDtls(IBOCE_IB_DealRelationshipDetails result) {
        List<String> params = new ArrayList<String>();
    	params.clear();
		String panelWhereClause = " where " + IBOCE_IB_DealRelationshipPanel.IBDEALID + "=? AND "
				+ IBOCE_IB_DealRelationshipPanel.IBDEALRELATIONSHIPDTLID + "=?";
		params.add(getF_IN_dealRelationShipDetails().getDealId());
		params.add(result.getBoID());
		factory.bulkDeleteall(IBOCE_IB_DealRelationshipPanel.BONAME, panelWhereClause, params);
		String agentsWhereClause = " where " + IBOCE_IB_DealRelationshipAgents.IBDEALID + "=? AND "
				+ IBOCE_IB_DealRelationshipAgents.IBDEALRELATIONSHIPDTLID + "=?";
		params.clear();
		params.add(getF_IN_dealRelationShipDetails().getDealId());
		params.add(result.getBoID());
		factory.bulkDeleteall(IBOCE_IB_DealRelationshipAgents.BONAME, agentsWhereClause, params);
		factory.remove(IBOCE_IB_DealRelationshipDetails.BONAME, result.getBoID(), true);

    }
    
    private void createNewDealRelationDetails(RelationshipDtls dealRelationshipDetails, boolean isGauranteeToPayPanelVisible,
            boolean isPartnersPanelVisible, boolean isAgentsPanelVisible) {
    	LOGGER.info("Entering into createNewDealRelationDetails-->"+getF_IN_dealRelationShipDetails().getDealId());
        IBOCE_IB_DealRelationshipDetails newDealRelationshipDetailsToBeAdded =
                (IBOCE_IB_DealRelationshipDetails) factory.getStatelessNewInstance(IBOCE_IB_DealRelationshipDetails.BONAME);
        IslamicBankingObject ibo = getF_IN_ibObject();
        newDealRelationshipDetailsToBeAdded.setF_IBSTATUS(RescheduleConstants.STATUS_NEW);
        if(!ibo.getTransactionID().equals(getF_IN_dealRelationShipDetails().getDealId())) {
            newDealRelationshipDetailsToBeAdded.setF_IBTRANSACTIONID(ibo.getTransactionID().toString() != null?ibo.getTransactionID().toString():getF_IN_dealRelationShipDetails().getDealId());
        }
        newDealRelationshipDetailsToBeAdded.setBoID(dealRelationshipDetails.getRelationshipDtlId());
        newDealRelationshipDetailsToBeAdded.setF_IBDEALID(getF_IN_dealRelationShipDetails().getDealId());
        newDealRelationshipDetailsToBeAdded.setF_IBRELATIONSHIPTYPE(dealRelationshipDetails.getRelationshipType());
        newDealRelationshipDetailsToBeAdded.setF_IBPARTYID(dealRelationshipDetails.getPartyId());
        newDealRelationshipDetailsToBeAdded.setF_IBPARTYNAME(dealRelationshipDetails.getPartyName());
        newDealRelationshipDetailsToBeAdded.setF_IBPARTYNATIONALID(dealRelationshipDetails.getPartyNationalId());
        if (null!=dealRelationshipDetails.getDisplayPartners() && dealRelationshipDetails.getDisplayPartners()) {
            isPartnersPanelVisible = true;
            newDealRelationshipDetailsToBeAdded.setF_IBPARTNERSHIPPER(dealRelationshipDetails.getPartnershipPercentage());
            newDealRelationshipDetailsToBeAdded.setF_IBPARTNERSTATUS(dealRelationshipDetails.getPartnerStatus());
        }
        if (null!=dealRelationshipDetails.getDisplayGuranteeToPay() && dealRelationshipDetails.getDisplayGuranteeToPay()) {
            isGauranteeToPayPanelVisible = true;
            newDealRelationshipDetailsToBeAdded.setF_IBPLEDGEAMOUNT(dealRelationshipDetails.getPledgeAmount().getCurrencyAmount());
            newDealRelationshipDetailsToBeAdded.setF_IBPLEDGETYPE(dealRelationshipDetails.getPledgeType());
            newDealRelationshipDetailsToBeAdded.setF_IBSILOAREA(dealRelationshipDetails.getSiloArea());
            newDealRelationshipDetailsToBeAdded.setF_IBSILOYEAR(dealRelationshipDetails.getSiloYear());
            newDealRelationshipDetailsToBeAdded.setF_IBFROMDATE(dealRelationshipDetails.getFromDate());
            newDealRelationshipDetailsToBeAdded.setF_IBTODATE(dealRelationshipDetails.getToDate());
            
        }
        newDealRelationshipDetailsToBeAdded.setF_IBDEALSTATUS((null==dealRelationshipDetails.getDealStatus()||dealRelationshipDetails.getDealStatus().isEmpty())?RescheduleConstants.STATUS_NEW:dealRelationshipDetails.getDealStatus().equalsIgnoreCase(RescheduleConstants.STATUS_NEW)?RescheduleConstants.STATUS_NEW:dealRelationshipDetails.getDealStatus());
        factory.create(IBOCE_IB_DealRelationshipDetails.BONAME, newDealRelationshipDetailsToBeAdded);
        factory.commitTransaction();
        factory.beginTransaction();
        if (getF_IN_dealRelationShipDetails().getRelationshipAgentsCount() > 0) {
            if(getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
                deleteExistingAgents(dealRelationshipDetails,isAgentsPanelVisible);
            }else {
                deleteExistingAgents(dealRelationshipDetails);
                persistsRelationShipAgents(dealRelationshipDetails,isAgentsPanelVisible);
            }
            
        }
        persistRelationPanelData(dealRelationshipDetails, isGauranteeToPayPanelVisible, isPartnersPanelVisible,
                isAgentsPanelVisible);
        LOGGER.info("Exiting from createNewDealRelationDetails -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

    private void deleteExistingAgents(RelationshipDtls dealRelationshipDetails) {
        String agentsWhereClause = " where "+IBOCE_IB_DealRelationshipAgents.IBDEALRELATIONSHIPDTLID+"=? and "+IBOCE_IB_DealRelationshipAgents.IBDEALID+"=?";
        List<String> params = new ArrayList<String>();
        params.add(dealRelationshipDetails.getRelationshipDtlId());
        params.add(getF_IN_dealRelationShipDetails().getDealId());
        factory.bulkDeleteall(IBOCE_IB_DealRelationshipAgents.BONAME, agentsWhereClause , params);
        factory.commitTransaction();
        factory.beginTransaction();
        
    }

    private void persistRelationPanelData(RelationshipDtls dealRelationshipDetails, boolean isGauranteeToPayPanelVisible,
            boolean isPartnersPanelVisible, boolean isAgentsPanelVisible) {
        LOGGER.info("Entering into persistRelationPanelData -->"+getF_IN_dealRelationShipDetails().getDealId());
        String panelWhereClause = " where "+IBOCE_IB_DealRelationshipPanel.IBDEALRELATIONSHIPDTLID+"=? and "+IBOCE_IB_DealRelationshipPanel.IBDEALID+"=?";
        List<String> params = new ArrayList<String>();
        params.add(dealRelationshipDetails.getRelationshipDtlId());
        params.add(getF_IN_dealRelationShipDetails().getDealId());
        factory.bulkDeleteall(IBOCE_IB_DealRelationshipPanel.BONAME, panelWhereClause , params);
        factory.commitTransaction();
        factory.beginTransaction();
        IBOCE_IB_DealRelationshipPanel newDealRelationshipPanelObj =
                (IBOCE_IB_DealRelationshipPanel) factory.getStatelessNewInstance(IBOCE_IB_DealRelationshipPanel.BONAME);
        newDealRelationshipPanelObj.setF_IBDEALID(getF_IN_dealRelationShipDetails().getDealId());
        newDealRelationshipPanelObj.setF_IBDEALRELATIONSHIPDTLID(dealRelationshipDetails.getRelationshipDtlId());
        newDealRelationshipPanelObj.setF_IBGURANTEETOPAYPANEL(dealRelationshipDetails.getDisplayGuranteeToPay());
        newDealRelationshipPanelObj.setF_IBPARTNERSPANEL(dealRelationshipDetails.getDisplayPartners());
        newDealRelationshipPanelObj.setF_IBAGENTSPANEL(dealRelationshipDetails.getDisplayAgents());
        newDealRelationshipPanelObj.setF_IBRELATIONSHIPTYPE(dealRelationshipDetails.getRelationshipType());
        factory.create(IBOCE_IB_DealRelationshipPanel.BONAME, newDealRelationshipPanelObj);
        LOGGER.info("Exiting from persistRelationPanelData -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

    private void deleteExistingAgents(RelationshipDtls dealRelationshipDetails, boolean isAgentsPanelVisible) {
        LOGGER.info("Entering into deleteExistingAgents -->"+getF_IN_dealRelationShipDetails().getDealId());
        String relationDtlsWhereClause = " where "+IBOCE_IB_DealRelationshipAgents.IBDEALID+" = ?";
        List<String> paramsList = new ArrayList<String>();
        paramsList.add(getF_IN_dealRelationShipDetails().getDealId());
        if(getF_IN_ibObject().getTransactionName().equals(IBConstants.STANDALONE)) {
        List<IBOCE_IB_DealRelationshipAgents> resultSet = factory.findByQuery(
        		IBOCE_IB_DealRelationshipAgents.BONAME, relationDtlsWhereClause, (ArrayList) paramsList, null, true);
        
        DealRelationshipDetails uiList = getF_IN_dealRelationShipDetails();
        RelationshipAgents[] uiCopy =  uiList.getRelationshipAgents().clone();
        
            for (IBOCE_IB_DealRelationshipAgents result : resultSet) {
                for(RelationshipAgents listItem : uiCopy) {
                   if( listItem.getRelationshipDtlId().equals(result.getF_IBDEALRELATIONSHIPDTLID())){
                       uiList.removeRelationshipAgents(listItem);
                   }
            }
        }
            if(null!=uiList && null != uiList.getRelationshipAgents()) {
            for(RelationshipDtls relation : uiList.getRelationshipDtls()) {
                persistsRelationShipAgents(relation,isAgentsPanelVisible);
            }
            }
        }
        factory.commitTransaction();
        factory.beginTransaction();
        LOGGER.info("Exiting from deleteExistingAgents -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

    private void persistsRelationShipAgents(RelationshipDtls dealRelationshipDetails, boolean isAgentsPanelVisible) {
        LOGGER.info("Entering into persistsRelationShipAgents deal ID-->"+getF_IN_dealRelationShipDetails().getDealId());
        for (RelationshipAgents relationshipAgent : getF_IN_dealRelationShipDetails().getRelationshipAgents()) {
            if (dealRelationshipDetails.getRelationshipDtlId()
                    .equalsIgnoreCase(relationshipAgent.getRelationshipDtlId())) {
                isAgentsPanelVisible = true;
                IBOCE_IB_DealRelationshipAgents newDealRelationshipAgentsObj =
                        (IBOCE_IB_DealRelationshipAgents) factory.getStatelessNewInstance(IBOCE_IB_DealRelationshipAgents.BONAME);
                newDealRelationshipAgentsObj.setF_IBAGENCYDATE(relationshipAgent.getAgencyDate());
                newDealRelationshipAgentsObj.setF_IBAGENCYNUMBER(relationshipAgent.getAgencyNumber());
                newDealRelationshipAgentsObj.setF_IBAGENCYSOURCE(relationshipAgent.getAgencySource());
                newDealRelationshipAgentsObj.setF_IBAGENCYSTATUS(relationshipAgent.getAgencyStatus());
                newDealRelationshipAgentsObj.setF_IBAGENTNATIONALID(relationshipAgent.getPartyNationalId());
                newDealRelationshipAgentsObj.setF_IBAGENTPARTYID(relationshipAgent.getPartyId());
                newDealRelationshipAgentsObj.setF_IBAGENTPARTYNAME(relationshipAgent.getPartyName());
                newDealRelationshipAgentsObj.setF_IBDEALID(getF_IN_dealRelationShipDetails().getDealId());
                newDealRelationshipAgentsObj.setF_IBDEALRELATIONSHIPDTLID(relationshipAgent.getRelationshipDtlId());
                newDealRelationshipAgentsObj.setF_IBNOTES(relationshipAgent.getNotes());
                factory.create(IBOCE_IB_DealRelationshipAgents.BONAME, newDealRelationshipAgentsObj);
            }
        }
        LOGGER.info("Exiting from persistsRelationShipAgents -->"+getF_IN_dealRelationShipDetails().getDealId());
    }

}
