package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import bf.com.misys.ib.types.IslamicBankingObject;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_FeesConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProductConfiguration;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_IDI_ReschedulePostponeFees;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class CEReschedulePostponeFees extends AbstractIB_IDI_ReschedulePostponeFees {

    private static final long serialVersionUID = 1L;

    @SuppressWarnings("deprecation")
    public CEReschedulePostponeFees(BankFusionEnvironment env) {
        super(env);
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        boolean suppressBuildingBlock = false;
        IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
        ;
        /*// reschedule fees checked in product configuration
        String whereClauseReschedule = " WHERE " + IBOIB_CFG_ProcessConfig.PROCESSTYPE + " = ?";
        ArrayList<String> params = new ArrayList<String>();
        params.clear();
        params.add("RESCHEDULE");
        List<IBOIB_CFG_ProcessConfig> rescheduleProcess = factory.findByQuery(IBOIB_CFG_ProcessConfig.BONAME, whereClauseReschedule,
                params, null, true);
        for (IBOIB_CFG_ProcessConfig processConfig : rescheduleProcess) {

            if (islamicBankingObject.getProcessConfigID().equals(processConfig.getBoID())) {
                String whereClause1 = " WHERE " + IBOIB_CFG_ProductConfiguration.PRODUCTID + " = ?" + " AND "
                        + IBOIB_CFG_ProductConfiguration.SUBPRODUCTID + " = ? AND "
                        + IBOIB_CFG_ProductConfiguration.ISRESCFEESAPPLICABLE + "  = ? ";
                params.clear();
                ;
                params.add(islamicBankingObject.getProductID());
                params.add(islamicBankingObject.getSubProductID());
                params.add("Y");
                List<IBOIB_CFG_FeesConfig> listRescheduleFeesAttached = factory.findByQuery(IBOIB_CFG_ProductConfiguration.BONAME,
                        whereClause1, params, null, true);
                if (listRescheduleFeesAttached != null && listRescheduleFeesAttached.size() > 0) {
                    suppressBuildingBlock = false;
                }
                else {
                    suppressBuildingBlock = true;
                }

            }
        }*/

        // posptpone fees checked in product configuration
        String whereClausePostPone = " WHERE " + IBOIB_CFG_ProcessConfig.PROCESSTYPE + " = ?";
        ArrayList<String> params1 = new ArrayList<String>();
        params1.clear();
        params1.add("POSTPONEINSTALMENT");
        List<IBOIB_CFG_ProcessConfig> postponeProcess =
            factory.findByQuery(IBOIB_CFG_ProcessConfig.BONAME, whereClausePostPone, params1, null, true);
        for (IBOIB_CFG_ProcessConfig processConfig : postponeProcess) {
            if (islamicBankingObject.getProcessConfigID().equals(processConfig.getBoID())) {
                String whereClause2 = " WHERE " + IBOIB_CFG_ProductConfiguration.PRODUCTID + " = ?" + " AND "
                    + IBOIB_CFG_ProductConfiguration.SUBPRODUCTID + " = ? AND " + IBOIB_CFG_ProductConfiguration.ISPOSTPONFEES + "  = ? ";
                params1.clear();
                params1.add(islamicBankingObject.getProductID());
                params1.add(islamicBankingObject.getSubProductID());
                params1.add("Y");
                List<IBOIB_CFG_FeesConfig> listPostponeFeesAttached =
                    factory.findByQuery(IBOIB_CFG_ProductConfiguration.BONAME, whereClause2, params1, null, true);
                if (listPostponeFeesAttached != null && listPostponeFeesAttached.size() > 0) {
                    suppressBuildingBlock = false;
                } else {
                    suppressBuildingBlock = true;
                }

            }
        }

        setF_OUT_isBuildingBlockSuppress(suppressBuildingBlock);
    }
}
