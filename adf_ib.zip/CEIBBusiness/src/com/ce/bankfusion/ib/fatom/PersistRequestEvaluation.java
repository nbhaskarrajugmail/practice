package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AgricultureRequestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_BuildingDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PersonalRequestDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ResidentialRquestDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TitleDeedDtlsForEvaluation;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TreeDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_WellDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistRequestEvaluation;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.eventcode.BusinessEventSupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CMN_DealStepDetails;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.AgricultureDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.BuildingsDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.ResidentialDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TitleDeedDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreeDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.TreesDetailsList;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.WellDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class PersistRequestEvaluation extends AbstractCE_IB_PersistRequestEvaluation {

  private static final long serialVersionUID = 1L;
  private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
  Log LOG = LogFactory.getLog(PersistRequestEvaluation.class.getName());
  public static final int SAVE_CHANGES_TO_PROCCED = 40312083;

  @SuppressWarnings("deprecation")
  public PersistRequestEvaluation(BankFusionEnvironment env) {
    super(env);
  }

  
  public void process(BankFusionEnvironment env) {

    CollateralRequestDetailsList collateralList = getF_IN_collateralRequestDetailsList();
    TitleDeedDetailsList hiddenTitleDeedDtls = getF_IN_hidden_titledeedDetailsList();
    WellDetailsList hiddenWellDtlsList = getF_IN_hidden_wellDetailsList();
    TreesDetailsList hiddenTreeDetails = getF_IN_hidden_treesDetailsList();
    BuildingsDetailsList hiddenBuildingDtls = getF_IN_hidden_buildingDetailsList();

    for(CollateralRequestDetails s : collateralList.getCollateralRequestDetailsList()) {
        if(s.getRequestType()==null || s.getRequestType().isEmpty()) {
            //collateralList.removeCollateralRequestDetailsList(s);
            IBCommonUtils.raiseUnparameterizedEvent(20020822);
        }
    }
    if((collateralList.getCollateralRequestDetailsList().length > 0) && (!IBCommonUtils.isEmpty(collateralList.getCollateralRequestDetailsList(0).getRequestType()))) {
        
        persistCollateralReqDtls(collateralList.getCollateralRequestDetailsList());
        
    }
    else
    {
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      List<IBOCE_IB_CollateralRevaluationDetails> collateralReqDtls = factory.findByQuery(
          IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);

      for (IBOCE_IB_CollateralRevaluationDetails result : collateralReqDtls) {
        if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.DEAL)) {
              if(!result.getF_IBTRANSACTIONID().isEmpty() && !result.getF_IBSTEPSTATUS().isEmpty()) {
                  continue;
              }
          }
      deletePersonalDtls(result.getBoID());
        deleteTitleDeedDtls(result.getBoID());
        deleteAgriculture(result.getBoID());
        deleteResidential(result.getBoID());
        deleteWellDtls(result.getBoID());
        deleteTreeDtls(result.getBoID());
        deleteBuildingDtls(result.getBoID());
      }
      deleteCollateralRqDtls(getF_IN_islamicBankingObject().getDealID());
    }
  }

  private void persistCollateralReqDtls(CollateralRequestDetails[] collateralRequestDetailsList) {

    IslamicBankingObject ibo = getF_IN_islamicBankingObject();
    String dealId = ibo.getDealID();

    ArrayList<String> params = new ArrayList<>();
    params.add(dealId);
    String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
    List<IBOCE_IB_CollateralRevaluationDetails> resultSet = factory
        .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);

    if(ibo.getTransactionName().equals(IBConstants.STANDALONE)) {
        deleteCollateralRqDtls(dealId, ibo);
    }else {
      for (IBOCE_IB_CollateralRevaluationDetails collateral : resultSet) {
        if(collateral.getF_IBTRANSACTIONID().isEmpty() && collateral.getF_IBSTEPSTATUS().isEmpty()) {
              deleteRelatedOtherDetailsForReqId(collateral.getBoID());
          }
      }
        deleteCollateralRqDtls(dealId);
        
        //persisting the title deed Agriculture to DB - START
        TitleDeedDetailsList hiddenTitleDeedDtls = getF_IN_hidden_titledeedDetailsList();
        WellDetailsList hiddenWellDtlsList = getF_IN_hidden_wellDetailsList();
        TreesDetailsList hiddenTreeDetails = getF_IN_hidden_treesDetailsList();
        BuildingsDetailsList hiddenBuildingDtls = getF_IN_hidden_buildingDetailsList();
        
        persistTitleDeedDtls(hiddenTitleDeedDtls);
        persistBuildingsDtls(hiddenBuildingDtls);
        persistTreeDtls(hiddenTreeDetails);
        persistWellDtls(hiddenWellDtlsList);
        
      //persisting the title deed Agriculture to DB - END
        for (CollateralRequestDetails collateral : collateralRequestDetailsList) {
            if(collateral.getStatus().equals("POSTED")) {
                continue;
            }
            IBOCE_IB_CollateralRevaluationDetails collateralReqDtls = (IBOCE_IB_CollateralRevaluationDetails) factory
                .getStatelessNewInstance(IBOCE_IB_CollateralRevaluationDetails.BONAME);
            collateralReqDtls.setBoID(collateral.getRequestID());
            collateralReqDtls.setF_IBCATEGORYTYPE(collateral.getCategoryType());
            collateralReqDtls.setF_IBCOLLATERALID(collateral.getCollateralID());
            collateralReqDtls.setF_IBCOVERVALUE(collateral.getCoverValue().getCurrencyAmount());
            collateralReqDtls.setF_IBDEALID(ibo.getDealID());
            collateralReqDtls.setF_IBDESCRIPTION(collateral.getDescription());
            collateralReqDtls.setF_IBREQUESTTYPE(collateral.getRequestType());
            collateralReqDtls.setF_IBSTATUS(collateral.getStatus());
            collateralReqDtls.setF_IBTITLEDEEDIDPK(collateral.getTitleDeedIDPK());
            collateralReqDtls.setF_IBTITLEDEEDNUM(collateral.getTitleDeedNum());
            collateralReqDtls.setF_IBTOTALCOVERVALUE(collateral.getCoverValue().getCurrencyAmount());
            
            
            
            if(collateral.getRequestType().equals("Personal")) {
                collateralReqDtls.setF_IBCUSTOMERID(collateral.getPersonalRequest().getCustomerId());
            }
            
            factory.create(IBOCE_IB_CollateralRevaluationDetails.BONAME, collateralReqDtls);

            if (collateral.getRequestType().equals("Personal"))

            {
              
              personalRequestTypeDetails(collateral.getRequestID(), collateral.getPersonalRequest());
              
            }

          }
    }

        factory.commitTransaction();
        factory.beginTransaction();

    

  }

  private int deleteCollateralRqDtls(String dealId) {
      int res = 0;
      ArrayList<String> params = new ArrayList<>();
      params.add(dealId);
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      if(!getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
          params.add("");
          params.add("");
          REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? AND ( " + IBOCE_IB_CollateralRevaluationDetails.IBSTEPSTATUS + " = ? OR "+IBOCE_IB_CollateralRevaluationDetails.IBSTEPSTATUS+" IS NULL ) AND ( "+ IBOCE_IB_CollateralRevaluationDetails.IBTRANSACTIONID+ " = ? OR " + IBOCE_IB_CollateralRevaluationDetails.IBTRANSACTIONID +" IS NULL )";
      }
      res = factory.bulkDelete(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params);
      factory.commitTransaction();
      factory.beginTransaction();
      return res;
        
    }


    private void createRequestDetails(CollateralRequestDetails[] collateralRequestDetailsList, IslamicBankingObject ibo) {
      for (CollateralRequestDetails collateral : collateralRequestDetailsList) {

          IBOCE_IB_CollateralRevaluationDetails collateralReqDtls = (IBOCE_IB_CollateralRevaluationDetails) factory
              .getStatelessNewInstance(IBOCE_IB_CollateralRevaluationDetails.BONAME);
          collateralReqDtls.setBoID(collateral.getRequestID());
          collateralReqDtls.setF_IBCATEGORYTYPE(collateral.getCategoryType());
          collateralReqDtls.setF_IBCOLLATERALID(collateral.getCollateralID());
          collateralReqDtls.setF_IBCOVERVALUE(collateral.getCoverValue().getCurrencyAmount());
          collateralReqDtls.setF_IBDEALID(ibo.getDealID());
          collateralReqDtls.setF_IBDESCRIPTION(collateral.getDescription());
          collateralReqDtls.setF_IBREQUESTTYPE(collateral.getRequestType());
          collateralReqDtls.setF_IBSTATUS(collateral.getStatus());
          collateralReqDtls.setF_IBSTEPSTATUS(RescheduleConstants.STATUS_NEW);
          if(!ibo.getTransactionID().equals(ibo.getDealID())) {
              collateralReqDtls.setF_IBTRANSACTIONID(ibo.getTransactionID().toString());
          }
          collateralReqDtls.setF_IBTITLEDEEDIDPK(collateral.getTitleDeedIDPK());
          collateralReqDtls.setF_IBTITLEDEEDNUM(collateral.getTitleDeedNum());
          collateralReqDtls.setF_IBTOTALCOVERVALUE(collateral.getCoverValue().getCurrencyAmount());
          
          
          if(collateral.getRequestType().equals("Personal")) {
              collateralReqDtls.setF_IBCUSTOMERID(collateral.getPersonalRequest().getCustomerId());
          }
          
          factory.create(IBOCE_IB_CollateralRevaluationDetails.BONAME, collateralReqDtls);

          if (collateral.getRequestType().equals("Personal"))

          {
            
            personalRequestTypeDetails(collateral.getRequestID(), collateral.getPersonalRequest());
            
          }

        }
        
    }


    private void personalRequestTypeDetails(String requestID, PersonalRequestdtls personalRequestDtls) {

    IBOCE_IB_PersonalRequestDtls personalReqDtls = (IBOCE_IB_PersonalRequestDtls) factory
        .getStatelessNewInstance(IBOCE_IB_PersonalRequestDtls.BONAME);
    personalReqDtls.setBoID(GUIDGen.getNewGUID());
    personalReqDtls.setF_IBAVAILABLEBALANCE(personalRequestDtls.getAvailableBalance().getCurrencyAmount());
    personalReqDtls.setF_IBCOLLATERALDESCRIPTION(personalRequestDtls.getDescription());
    personalReqDtls.setF_IBCOVERVALUE(personalRequestDtls.getCoverValue().getCurrencyAmount());
    personalReqDtls.setF_IBRELATIONSHIPTYPE(personalRequestDtls.getRelationshipType());
    personalReqDtls.setF_IBRELATIONSIPDTLSID(personalRequestDtls.getRelationShipDtlsID());
    personalReqDtls.setF_IBREQUESTID(requestID);

    factory.create(IBOCE_IB_PersonalRequestDtls.BONAME, personalReqDtls);
    factory.commitTransaction();
    factory.beginTransaction();
  }

  private void persistTitleDeedDtls(TitleDeedDetailsList hiddenTitleDeedDtlsList) {
    // if(hiddenTitleDeedDtlsList!=null) {

      for(TitleDeedDetails titleDeedList : hiddenTitleDeedDtlsList.getTitleDeedDetailsList()) {
          Boolean flag = true;
          for(CollateralRequestDetails colReq : getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsList()) {
              if(titleDeedList.getRequestID().equals(colReq.getRequestID())) {
                  flag = false;
              }
          }
          
          if(flag) {
              hiddenTitleDeedDtlsList.removeTitleDeedDetailsList(titleDeedList);
              //IBCommonUtils.raiseUnparameterizedEvent(20020822);
          }
      }
      if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
      TitleDeedDetails[] TDcopy = hiddenTitleDeedDtlsList.getTitleDeedDetailsList().clone();
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      List<IBOCE_IB_CollateralRevaluationDetails> resultSet = factory
          .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
      if(resultSet!=null) {
          for(IBOCE_IB_CollateralRevaluationDetails result : resultSet) {
    
              deleteTitleDeedDtls(result.getBoID());
              deleteAgriculture(result.getBoID());
              deleteResidential(result.getBoID());
    
          }
         }
      
      }
      
    for (TitleDeedDetails eachTitleDeedDtl : hiddenTitleDeedDtlsList.getTitleDeedDetailsList()) {
               
        if(!IBCommonUtils.isEmpty(eachTitleDeedDtl.getRequestID())) {
            String category = new String();
           
            for(CollateralRequestDetails colReq : getF_IN_collateralRequestDetailsList().getCollateralRequestDetailsList()) {
                if(eachTitleDeedDtl.getRequestID().equals(colReq.getRequestID())){
                    category = colReq.getCategoryType();
                    break;
                }
              }
            
      IBOCE_IB_TitleDeedDtlsForEvaluation newTitleDeedDtlObj = (IBOCE_IB_TitleDeedDtlsForEvaluation) factory
          .getStatelessNewInstance(IBOCE_IB_TitleDeedDtlsForEvaluation.BONAME);
      newTitleDeedDtlObj.setBoID(GUIDGen.getNewGUID());
      newTitleDeedDtlObj.setF_IBTITLEDEEDID(eachTitleDeedDtl.getTitleDeedIDPK());
      newTitleDeedDtlObj.setF_IBEVALUATIONID(eachTitleDeedDtl.getEvaluationId());
      newTitleDeedDtlObj.setF_IBPLAN(eachTitleDeedDtl.getPlan());
      newTitleDeedDtlObj.setF_IBPLOTNUM(eachTitleDeedDtl.getLandPlotNum());
      newTitleDeedDtlObj.setF_IBREQUESTID(eachTitleDeedDtl.getRequestID());
      String sourceLabel = "";
      ListGenericCodeRs sourceList = IBCommonUtils.getGCList("TITLEDEEDSOURCE");
      for(GcCodeDetail source : sourceList.getGcCodeDetails()) {
          if(source.getCodeDescription().equals(eachTitleDeedDtl.getSource())){
              sourceLabel = source.getCodeValue();
              break;
          }
      }
      if(sourceLabel !="") {
          newTitleDeedDtlObj.setF_IBSOURCE(sourceLabel);
      }else {
          newTitleDeedDtlObj.setF_IBSOURCE(eachTitleDeedDtl.getSource());
      }
      
      newTitleDeedDtlObj.setF_IBTITLEDEEDNUM(eachTitleDeedDtl.getTitleDeedNum());
      newTitleDeedDtlObj.setF_IBTITLEDEEDVERSIONNUM(eachTitleDeedDtl.getTitleDeedVersionNum());
      String typeLabel = "";
      ListGenericCodeRs typeList = IBCommonUtils.getGCList("TITLEDEEDTYPE");
      for(GcCodeDetail type : typeList.getGcCodeDetails()) {
          if(type.getCodeDescription().equals(eachTitleDeedDtl.getType())){
              typeLabel = type.getCodeValue();
              break;
          }
      }
      if(typeLabel != "") {
          newTitleDeedDtlObj.setF_IBTYPE(typeLabel);
      }else {
          newTitleDeedDtlObj.setF_IBTYPE(eachTitleDeedDtl.getType());
      }
      
      newTitleDeedDtlObj.setF_IBYEAR(eachTitleDeedDtl.getYear());
      newTitleDeedDtlObj.setF_IBREQUESTID(eachTitleDeedDtl.getRequestID());

      factory.create(IBOCE_IB_TitleDeedDtlsForEvaluation.BONAME, newTitleDeedDtlObj);
      if (category.equals("Agricultural")) {

          persistAgriculture(eachTitleDeedDtl);
      }else if(category.equals("Residential") || category.equals("Commercial")){
          persistResidential(eachTitleDeedDtl);
      }
      factory.commitTransaction();
      factory.beginTransaction();
            

    }
        }
  }

  private void persistTreeDtls(TreesDetailsList hiddenTreeDetails) {
       if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
      TreeDetails[] treecopy = hiddenTreeDetails.getTreesDetailsList().clone();
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      List<IBOCE_IB_CollateralRevaluationDetails> resultSet = factory
          .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
      for(IBOCE_IB_CollateralRevaluationDetails result : resultSet) {
          deleteTreeDtls(result.getBoID());
      }
   }
    for (TreeDetails treeDtl : hiddenTreeDetails.getTreesDetailsList()) {
        //IBCommonUtils.intializeDefaultvalues(treeDtl);
      if (!treeDtl.getRequestID().equals(CommonConstants.EMPTY_STRING)) {
        IBOCE_IB_TreeDetails newTreeDtlObj = (IBOCE_IB_TreeDetails) factory
            .getStatelessNewInstance(IBOCE_IB_TreeDetails.BONAME);
        newTreeDtlObj.setF_IBAGREECULTUREDTLSID(treeDtl.getAgricultureDetailsID());
        newTreeDtlObj.setF_IBCOST(treeDtl.getCost().getCurrencyAmount());
        newTreeDtlObj.setF_IBEVALUATIONID(treeDtl.getEvaluationId());
        newTreeDtlObj.setF_IBNOOFTREES(treeDtl.getNoOfTrees());
        newTreeDtlObj.setF_IBNOTES(treeDtl.getNotes());
        newTreeDtlObj.setF_IBPRICEPERTREE(treeDtl.getPricePerTree().getCurrencyAmount());
        newTreeDtlObj.setF_IBREQUESTID(treeDtl.getRequestID());
        newTreeDtlObj.setF_IBSNO(treeDtl.getSno());
        newTreeDtlObj.setF_IBTITLEDEEDID(treeDtl.getTitleDeedIDPK());
        newTreeDtlObj.setF_IBTITLEDEEDNUM(treeDtl.getTitleDeedNum());
        newTreeDtlObj.setF_IBTREEAGE(treeDtl.getTreeAge());
        newTreeDtlObj.setF_IBTREETYPE(treeDtl.getTreeType());
        newTreeDtlObj.setBoID(GUIDGen.getNewGUID());
        factory.create(IBOCE_IB_TreeDetails.BONAME, newTreeDtlObj);
        factory.commitTransaction();
        factory.beginTransaction();
      }
    }
  }

  private void persistBuildingsDtls(BuildingsDetailsList hiddenBuildingDtls) {
    if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
      BuildingDetails[] buildingcopy = hiddenBuildingDtls.getBuildingsDetailsList().clone();
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      List<IBOCE_IB_CollateralRevaluationDetails> resultSet = factory
          .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
      for(IBOCE_IB_CollateralRevaluationDetails result : resultSet) {
        deleteBuildingDtls(result.getBoID());
      }
    }   
    for (BuildingDetails eachBuildingDtl : hiddenBuildingDtls.getBuildingsDetailsList()) {
        //IBCommonUtils.intializeDefaultvalues(eachBuildingDtl);
      if (!eachBuildingDtl.getRequestID().equals(CommonConstants.EMPTY_STRING) ) {
        IBOCE_IB_BuildingDetails newBuildingtDtlObj = (IBOCE_IB_BuildingDetails) factory
            .getStatelessNewInstance(IBOCE_IB_BuildingDetails.BONAME);
        newBuildingtDtlObj.setBoID(GUIDGen.getNewGUID());
        newBuildingtDtlObj.setF_IBAGREECULTUREDTLSID(eachBuildingDtl.getAgricultureDetailsID());
        newBuildingtDtlObj.setF_IBBUILDINGAGE(eachBuildingDtl.getBuildingAge());
        newBuildingtDtlObj.setF_IBBUILDINGSIZE(eachBuildingDtl.getBuildingsize());
        newBuildingtDtlObj.setF_IBBUILDINGTYPE(eachBuildingDtl.getBuildingType());
        newBuildingtDtlObj.setF_IBCOST(eachBuildingDtl.getCost().getCurrencyAmount());
        newBuildingtDtlObj.setF_IBEVALUATIONID(eachBuildingDtl.getEvaluationId());
        newBuildingtDtlObj.setF_IBNOTES(eachBuildingDtl.getNotes());
        newBuildingtDtlObj.setF_IBPRICEPERSQM(eachBuildingDtl.getPricePerSqM().getCurrencyAmount());
        newBuildingtDtlObj.setF_IBREQUESTID(eachBuildingDtl.getRequestID());
        newBuildingtDtlObj.setF_IBSNO(eachBuildingDtl.getSno());
        newBuildingtDtlObj.setF_IBTITLEDEEDID(eachBuildingDtl.getTitleDeedIDPK());
        newBuildingtDtlObj.setF_IBTITLEDEEDNUM(eachBuildingDtl.getTitleDeedNum());

        factory.create(IBOCE_IB_BuildingDetails.BONAME, newBuildingtDtlObj);
        factory.commitTransaction();
        factory.beginTransaction();
      }
    }

  }

  private void persistWellDtls(WellDetailsList hiddenWellDtlsList) {
    if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
      WellDetails[] wellcopy = hiddenWellDtlsList.getWellDetailsList().clone();
      ArrayList<String> params = new ArrayList<>();
      params.add(getF_IN_islamicBankingObject().getDealID());
      String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
      List<IBOCE_IB_CollateralRevaluationDetails> resultSet = factory
          .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
      for(IBOCE_IB_CollateralRevaluationDetails result : resultSet) {
        deleteWellDtls(result.getBoID());
      }
    }
    for (WellDetails wellDtl : hiddenWellDtlsList.getWellDetailsList()) {
        //IBCommonUtils.intializeDefaultvalues(wellDtl);
      if (!wellDtl.getRequestID().equals(CommonConstants.EMPTY_STRING)) {
        IBOCE_IB_WellDetails newWellDtlObj = (IBOCE_IB_WellDetails) factory
            .getStatelessNewInstance(IBOCE_IB_WellDetails.BONAME);

        newWellDtlObj.setBoID(GUIDGen.getNewGUID());
        newWellDtlObj.setF_IBAGRICULTUREDTLSID(wellDtl.getAgricultureDetailsID());
        newWellDtlObj.setF_IBAIRDEPTH(wellDtl.getAirDepth());
        newWellDtlObj.setF_IBEVALUATIONID(wellDtl.getEvaluationId());
        newWellDtlObj.setF_IBDEPTH(wellDtl.getDepth());
        newWellDtlObj.setF_IBNOTES(wellDtl.getNotes());
        newWellDtlObj.setF_IBPRICE(wellDtl.getPrice().getCurrencyAmount());
        newWellDtlObj.setF_IBREQUESTID(wellDtl.getRequestID());
        newWellDtlObj.setF_IBSNO(wellDtl.getSno());
        newWellDtlObj.setF_IBTITLEDEEDID(wellDtl.getTitleDeedIDPK());
        newWellDtlObj.setF_IBTITLEDEEDNUM(wellDtl.getTitleDeedNum());
        newWellDtlObj.setF_IBWELLDIAMETER(wellDtl.getWellDiameter());
        newWellDtlObj.setF_IBWELLTYPE(wellDtl.getWellType());

        factory.create(IBOCE_IB_WellDetails.BONAME, newWellDtlObj);
        factory.commitTransaction();
        factory.beginTransaction();
      }
    }
  }

  private void persistAgriculture(TitleDeedDetails eachTitleDeedDtl) {

      //deleteAgriculture(eachTitleDeedDtl.getRequestID());
      factory.commitTransaction();
    factory.beginTransaction();
    AgricultureDetails agricultureDtls = eachTitleDeedDtl.getAgricultureDetails();
    IBOCE_IB_AgricultureRequestDetails newAgricultureDtlObj = (IBOCE_IB_AgricultureRequestDetails) factory
        .getStatelessNewInstance(IBOCE_IB_AgricultureRequestDetails.BONAME);
    newAgricultureDtlObj.setBoID(agricultureDtls.getAgricultureDetailsID());
    newAgricultureDtlObj.setF_IBDESCRIPTION(agricultureDtls.getDescription());
    newAgricultureDtlObj.setF_IBDISTANCETOMAINROAD(agricultureDtls.getDistanceToMainRoad());
    newAgricultureDtlObj.setF_IBDUNUMPRICE(agricultureDtls.getDunumPrice().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBELECTIRCITYAVAILABLE(agricultureDtls.isElectricityAvailable());
    newAgricultureDtlObj.setF_IBELIGIBLETOFARM(agricultureDtls.getEligibleToFarm());
    newAgricultureDtlObj.setF_IBEVALUATIONDATE(agricultureDtls.getEvaluationDate());
    newAgricultureDtlObj.setF_IBEVALUATIONID(eachTitleDeedDtl.getEvaluationId());
    newAgricultureDtlObj.setF_IBEVALUATOR(agricultureDtls.getEvaluator());
    newAgricultureDtlObj.setF_IBFARMSIZEINDUNUM(agricultureDtls.getFarmSizeInDunum());
    newAgricultureDtlObj.setF_IBINSIDEFARMROADTYPE(agricultureDtls.getInsideFarmRoadType());
    newAgricultureDtlObj.setF_IBISLOCATIONMATCHING(agricultureDtls.getIsLocationMatching());
    newAgricultureDtlObj.setF_IBISPLANMATCHING(agricultureDtls.getIsPlanMatching());
    newAgricultureDtlObj.setF_IBISPREVMORTGAGEAMT(agricultureDtls.getIsPrevMortgageAmt());
    newAgricultureDtlObj.setF_IBLANDNETVALUE(agricultureDtls.getLandNetValue().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBLANDTOTALVALUE(agricultureDtls.getLandTotalValue().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBMORTGAGEAMT(agricultureDtls.getMortgageAmt().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBNEARESTCITYDISTANCE(agricultureDtls.getNearestCityDistance());
    newAgricultureDtlObj.setF_IBNEARESTCITYNAME(agricultureDtls.getNearestCityName());
    newAgricultureDtlObj.setF_IBNETCOVERVALUE(agricultureDtls.getNetCoverValue().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBOTHERS(agricultureDtls.getOthers());
    newAgricultureDtlObj.setF_IBPHONEAVAILABLE(agricultureDtls.getPhoneAvailable());
    newAgricultureDtlObj.setF_IBREQUESTID(eachTitleDeedDtl.getRequestID());
    newAgricultureDtlObj.setF_IBSTATUS(agricultureDtls.getStatus());
    newAgricultureDtlObj.setF_IBTITLEDEEDID(eachTitleDeedDtl.getTitleDeedIDPK());
    newAgricultureDtlObj.setF_IBTITLEDEEDNUM(eachTitleDeedDtl.getTitleDeedNum());
    newAgricultureDtlObj.setF_IBTOTALCOVERVALUE(agricultureDtls.getTotalCoverValue().getCurrencyAmount());
    newAgricultureDtlObj.setF_IBTYPEOFROAD(agricultureDtls.getTypeOfRoad());
    newAgricultureDtlObj.setF_IBWATERAVAILABILITY(agricultureDtls.getWaterAvailability());
    newAgricultureDtlObj.setF_IBWATERINGMETHOD(agricultureDtls.getWateringMethod());
    newAgricultureDtlObj.setF_IBWATREINNEIGHBOURSAREA(agricultureDtls.getWaterInNeighbourArea());
    newAgricultureDtlObj.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
    newAgricultureDtlObj.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
    newAgricultureDtlObj.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
    
    factory.create(IBOCE_IB_AgricultureRequestDetails.BONAME, newAgricultureDtlObj);
    factory.commitTransaction();
    factory.beginTransaction();

  }

  private void persistResidential(TitleDeedDetails eachTitleDeedDtl) {
    //deleteResidential(eachTitleDeedDtl.getRequestID());
    factory.commitTransaction();
    factory.beginTransaction();
    ResidentialDetails residentialDtls = eachTitleDeedDtl.getResidentialDetails();
    IBOCE_IB_ResidentialRquestDetails newResidentailDtlObj = (IBOCE_IB_ResidentialRquestDetails) factory
        .getStatelessNewInstance(IBOCE_IB_ResidentialRquestDetails.BONAME);

    newResidentailDtlObj.setBoID(residentialDtls.getResidentialDetailsID());
    newResidentailDtlObj.setF_IBBUILDINGAGE(residentialDtls.getBuildingAge());
    newResidentailDtlObj.setF_IBBUILTAREA(residentialDtls.getBuiltArea());
    newResidentailDtlObj.setF_IBCOMPUNDWALLHEIGHT(residentialDtls.getCompoundWallHeight());
    newResidentailDtlObj.setF_IBCONSTRUCTIONLEVEL(residentialDtls.getConstructionLevel());
    newResidentailDtlObj.setF_IBDESCRIPTION(residentialDtls.getDescription());
    newResidentailDtlObj.setF_IBEVALUATIONDATE(residentialDtls.getEvaluationDate());
    newResidentailDtlObj.setF_IBEVALUATIONID(eachTitleDeedDtl.getEvaluationId());
    newResidentailDtlObj.setF_IBEVALUATOR(residentialDtls.getEvaluator());
    newResidentailDtlObj.setF_IBHOUSENUMBER(residentialDtls.getHouseNo());
    newResidentailDtlObj.setF_IBISBUILDING(residentialDtls.getIsBuilding());
    newResidentailDtlObj.setF_IBISLOCATIONMATCHING(residentialDtls.getIsLocationMatching());
    newResidentailDtlObj.setF_IBISPLANMATCHING(residentialDtls.getIsPlanMatching());
    newResidentailDtlObj.setF_IBISPREVMORTGAGEAMT(residentialDtls.getIsPrevMortgageAmt());
    newResidentailDtlObj.setF_IBLANDAREA(residentialDtls.getLandArea());
    newResidentailDtlObj.setF_IBMORTGAGEAMT(residentialDtls.getMortgageAmt().getCurrencyAmount());
    newResidentailDtlObj.setF_IBNETEVALUATIONVALUE(residentialDtls.getNetEvaluationValue().getCurrencyAmount());
    newResidentailDtlObj.setF_IBNUMBEROFFLOORS(residentialDtls.getNoOfFloors());
    newResidentailDtlObj.setF_IBPRICEPERBUILDINGSQM(residentialDtls.getPricePerBuildSqM().getCurrencyAmount());
    newResidentailDtlObj.setF_IBPRICEPERSQM(residentialDtls.getPricePerSqM().getCurrencyAmount());
    newResidentailDtlObj.setF_IBPROPERTYSIZE(residentialDtls.getPropertySize());
    newResidentailDtlObj.setF_IBQUALITY(residentialDtls.getQuality());
    newResidentailDtlObj.setF_IBREQUESTID(eachTitleDeedDtl.getRequestID());
    newResidentailDtlObj.setF_IBSHADOWPRICE(residentialDtls.getShadowPrice().getCurrencyAmount());
    newResidentailDtlObj.setF_IBSHADOWSIZE(residentialDtls.getShadowSize());
    newResidentailDtlObj.setF_IBSTATUS(residentialDtls.getStatus());
    newResidentailDtlObj.setF_IBSTREETNAME1(residentialDtls.getStreetName1());
    newResidentailDtlObj.setF_IBSTREETNAME2(residentialDtls.getStreetName2());
    newResidentailDtlObj.setF_IBSTREETNAME3(residentialDtls.getStreetName3());
    newResidentailDtlObj.setF_IBSTREETNAME4(residentialDtls.getStreetName4());
    newResidentailDtlObj.setF_IBSTREETTYPES(residentialDtls.getStreetsTypes());
    newResidentailDtlObj.setF_IBTITLEDEEDID(eachTitleDeedDtl.getTitleDeedIDPK());
    newResidentailDtlObj.setF_IBTITLEDEEDNUM(eachTitleDeedDtl.getTitleDeedNum());
    newResidentailDtlObj.setF_IBTOTALEVALUATIONVALUE(residentialDtls.getTotalEvaluationValue().getCurrencyAmount());
    newResidentailDtlObj.setF_IBUTILITYAREASIZE(residentialDtls.getUtilityAreaSize());
    newResidentailDtlObj.setF_IBUTILITYPRICE(residentialDtls.getUtilityPrice().getCurrencyAmount());
    newResidentailDtlObj.setF_IBWALLPRICE(residentialDtls.getWallPrice().getCurrencyAmount());
    newResidentailDtlObj.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
    newResidentailDtlObj.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
    newResidentailDtlObj.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());

    factory.create(IBOCE_IB_ResidentialRquestDetails.BONAME, newResidentailDtlObj);
    factory.commitTransaction();
    factory.beginTransaction();

  }

  private void deleteRelatedOtherDetailsForReqId(String requestId) {
    deletePersonalDtls(requestId);
    deleteTitleDeedDtls(requestId);
    deleteAgriculture(requestId);
    deleteResidential(requestId);
    if(!getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
    deleteWellDtls(requestId);
    deleteTreeDtls(requestId);
    deleteBuildingDtls(requestId);
    }
    factory.commitTransaction();
    factory.beginTransaction();
  }

  private int deleteCollateralRqDtls(String dealId , IslamicBankingObject ibo) {
    int res = 0;
    ArrayList<String> params = new ArrayList<>();
    params.add(dealId);
    String REQUESTDTLS_WHERECLAUSE = "where " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? ";
    
    if(getF_IN_islamicBankingObject().getTransactionName().equals(IBConstants.STANDALONE)) {
    List<IBOCE_IB_CollateralRevaluationDetails> collateralReqDtls = factory
        .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params, null, true);
    CollateralRequestDetailsList uiList = getF_IN_collateralRequestDetailsList();
    deleteCollateralRqDtls(dealId);
    createRequestDetails(uiList.getCollateralRequestDetailsList(), ibo);
    TitleDeedDetailsList hiddenTitleDeedDtls = getF_IN_hidden_titledeedDetailsList();
    WellDetailsList hiddenWellDtlsList = getF_IN_hidden_wellDetailsList();
    TreesDetailsList hiddenTreeDetails = getF_IN_hidden_treesDetailsList();
    BuildingsDetailsList hiddenBuildingDtls = getF_IN_hidden_buildingDetailsList();
    
    persistTitleDeedDtls(hiddenTitleDeedDtls);
    persistBuildingsDtls(hiddenBuildingDtls);
    persistTreeDtls(hiddenTreeDetails);
    persistWellDtls(hiddenWellDtlsList);
    }else {
        res = factory.bulkDelete(IBOCE_IB_CollateralRevaluationDetails.BONAME, REQUESTDTLS_WHERECLAUSE, params);
        factory.commitTransaction();
        factory.beginTransaction();
    }
    return res;
  }

  private int deletePersonalDtls(String requestId) {
    int res = 0;
    ArrayList<String> params = new ArrayList<>();
    params.add(requestId);
    String PERSONAL_WHERECLAUSE = "where " + IBOCE_IB_PersonalRequestDtls.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_PersonalRequestDtls.BONAME, PERSONAL_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  public int deleteTitleDeedDtls(String requestId) {
    int res = 0;
    ArrayList<String> params = new ArrayList<>();
    params.add(requestId);
    String TITLEDEED_WHERECLAUSE = "where " + IBOCE_IB_TitleDeedDtlsForEvaluation.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_TitleDeedDtlsForEvaluation.BONAME, TITLEDEED_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  private int deleteAgriculture(String requestId) {
    int res = 0;
    ArrayList<String> params = new ArrayList<>();
    params.add(requestId);
    String AGRICULTURE_WHERECLAUSE = "where " + IBOCE_IB_AgricultureRequestDetails.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_AgricultureRequestDetails.BONAME, AGRICULTURE_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  private int deleteResidential(String requestId) {
    int res = 0;
    ArrayList<String> params = new ArrayList<>();
    params.add(requestId);
    String RESIDENTIAL_WHERECLAUSE = "where " + IBOCE_IB_ResidentialRquestDetails.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_ResidentialRquestDetails.BONAME, RESIDENTIAL_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  public int deleteWellDtls(String requestId) {
    int res = 0;
    ArrayList params = new ArrayList<>();
    params.add(requestId);
    String WELLDTLS_WHERECLAUSE = "where " + IBOCE_IB_WellDetails.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_WellDetails.BONAME, WELLDTLS_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  public int deleteTreeDtls(String requestId) {
    int res = 0;
    ArrayList params = new ArrayList<>();
    params.add(requestId);
    String TREEDTLS_WHERECLAUSE = "where " + IBOCE_IB_TreeDetails.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_TreeDetails.BONAME, TREEDTLS_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

  public int deleteBuildingDtls(String requestId) {
    int res = 0;
    ArrayList params = new ArrayList<>();
    params.add(requestId);
    String BUILDINGDTLS_WHERECLAUSE = "where " + IBOCE_IB_BuildingDetails.IBREQUESTID + " = ? ";
    res = factory.bulkDelete(IBOCE_IB_BuildingDetails.BONAME, BUILDINGDTLS_WHERECLAUSE, params);
    // factory.commitTransaction();
    return res;
  }

}