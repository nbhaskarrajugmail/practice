package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RequestEvaluationPersonalFilterSelected;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_COL_DebitObligationFeature;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.dealcustcollateral.dtls.ib.types.CollateralRequestDetails;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtls;
import bf.com.misys.dealcustcollateral.dtls.ib.types.PersonalRequestdtlsList;

public class RequestEvaluationPersonalFilterSelected extends AbstractCE_IB_RequestEvaluationPersonalFilterSelected{
    public RequestEvaluationPersonalFilterSelected() {
        super();
    }
    @SuppressWarnings("deprecation")
    public RequestEvaluationPersonalFilterSelected(BankFusionEnvironment env) {
        super(env);
    }
  
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        PersonalRequestdtls[] personList = getF_IN_personalRequestDtlsList().getPersonalRequestdtlsList();
        String pledgeDesc = IBConstants.EMPTY_STRING;
        for(PersonalRequestdtls personDtls : personList) {
            if(personDtls.getSelect()) {
            	
                PersonalRequestdtls vPersonalRequestdtlsList = new PersonalRequestdtls();
                vPersonalRequestdtlsList.setCustomerId(personDtls.getCustomerId());
                
                ListGenericCodeRs lsGeneric = IBCommonUtils.getGCList("IBRELATIONSHIPTYPE");
                String relationDesc = "";

                vPersonalRequestdtlsList.setRelationshipType(personDtls.getRelationshipType());
                vPersonalRequestdtlsList.setRelationShipDtlsID(personDtls.getRelationShipDtlsID());
                vPersonalRequestdtlsList.setName(personDtls.getName());
                vPersonalRequestdtlsList.setNationalID(personDtls.getNationalID());
            	vPersonalRequestdtlsList.setFromDate(personDtls.getFromDate());
                vPersonalRequestdtlsList.setToDate(personDtls.getToDate());
                if(CalendarUtil.isDateNullOrDefaultDate(vPersonalRequestdtlsList.getFromDate())) {
                	vPersonalRequestdtlsList.setFromDate(null);
                }
                if(CalendarUtil.isDateNullOrDefaultDate(vPersonalRequestdtlsList.getToDate())) {
                    vPersonalRequestdtlsList.setToDate(null);
                }
                vPersonalRequestdtlsList.setSiloYear(personDtls.getSiloYear());
                
                ListGenericCodeRs lsGenericCodesSileArea = IBCommonUtils.getGCList("IBSILOAREACODE");
                String siloArea = "";
                for (GcCodeDetail gcCode : lsGenericCodesSileArea.getGcCodeDetails()) {
                    if (personDtls.getPledgeType().equals(gcCode.getCodeReference())) {
                        siloArea = gcCode.getCodeDescription();
                        break;
                    }
                }
                vPersonalRequestdtlsList.setSiloArea(siloArea);
                vPersonalRequestdtlsList.setPledgeAmount(personDtls.getPledgeAmount());
                ListGenericCodeRs lsGenericCodes = IBCommonUtils.getGCList("IBPLEDGETYPE");

                for (GcCodeDetail gcCode : lsGenericCodes.getGcCodeDetails()) {
                    if (personDtls.getPledgeType().equals(gcCode.getCodeReference())) {
                        pledgeDesc = gcCode.getCodeDescription();
                        break;
                    }
                }
                vPersonalRequestdtlsList.setPledgeType(pledgeDesc);
                BFCurrencyAmount availableBalance = new BFCurrencyAmount();
                availableBalance.setCurrencyAmount(getAvailableBalancePersonal(personDtls.getCustomerId()));
                availableBalance.setCurrencyCode(personDtls.getAvailableBalance().getCurrencyCode());
                vPersonalRequestdtlsList.setAvailableBalance(availableBalance);
                setF_OUT_personalRequestDtls(vPersonalRequestdtlsList);
            }
        }
        
    }
    
    public static BigDecimal getAvailableBalancePersonal( String customerID)
    {
    	 
        BigDecimal totalCoverValue = new BigDecimal(0);
        BigDecimal balance = new BigDecimal(0);

        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

        String whereDealClause = "WHERE "+ IBOUB_COL_DebitObligationFeature.UBDONUMBER +" = ?  AND " + IBOUB_COL_DebitObligationFeature.UBDOISACTIVE + " = ? ";
        String whereClause = "WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBCUSTOMERID + " = ? AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTTYPE + " = ? ";
       
        ArrayList<String> queryParams = new ArrayList<String>();
        queryParams.add(customerID);
        queryParams.add("Personal");
 
        List<IBOCE_IB_CollateralRevaluationDetails> collateralDealDtls = factory.findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause, queryParams, null, true);
        if(!collateralDealDtls.isEmpty() && collateralDealDtls!=null){            
            for (IBOCE_IB_CollateralRevaluationDetails eachCollDtlsFromDB : collateralDealDtls) {            
                String collaterId = eachCollDtlsFromDB.getF_IBCOLLATERALID();
                if(!IBCommonUtils.isEmpty(collaterId) && collaterId!=null)
                {
            	String dealID=eachCollDtlsFromDB.getF_IBDEALID();
                IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealID);
                String dealAccNo = dealDtls.getF_DealAccountId();
                ArrayList<String> params = new ArrayList<String>();
                params.add(dealAccNo);
                params.add("Y");
                List<IBOUB_COL_DebitObligationFeature> debitObligation = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOUB_COL_DebitObligationFeature.BONAME, whereDealClause, params, null, true);            
                if(debitObligation!=null){                	                                            
                     totalCoverValue= totalCoverValue.add(eachCollDtlsFromDB.getF_IBCOVERVALUE());                               	                                
                  }
               }
            }
        }
        BigDecimal availableBalance = CollateralRequestDtlsUtils.readPersonalRequestAvailableBalance();
        balance = availableBalance.subtract(totalCoverValue);
        if(balance.compareTo(BigDecimal.ZERO)<0)
         {
            	balance = new BigDecimal(0);
         }
        
         
        return balance;
    }
}
