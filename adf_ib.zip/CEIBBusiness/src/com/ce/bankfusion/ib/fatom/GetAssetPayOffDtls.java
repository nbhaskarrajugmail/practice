package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetAssetPayOffDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.calendar.IBusinessDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.util.AssetCategoryUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.types.Currency;
import bf.com.misys.ib.schedule.payments.ProfitRateDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.EarlyAssetPayoffCollDtls;
import bf.com.misys.ib.types.EarlyAssetPayoffCollection;
import bf.com.misys.ib.types.EarlyAssetPayoffDtls;
import bf.com.misys.ib.types.ProductConfiguration;

public class GetAssetPayOffDtls extends AbstractCE_IB_GetAssetPayOffDtls {

	private static final Log LOGGER = LogFactory.getLog(GetAssetPayOffDtls.class);
	private IBOIB_DLI_DealDetails dealDetails;
	private ReadLoanDetailsRs readLoanDetailsRs;
	private boolean isAssetPayOffProcess;
	private String paymentSchBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " =?";

	public GetAssetPayOffDtls(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
		readLoanDetailsRs = IBCommonUtils.getLoanDetails(getF_IN_islamicBankingObject().getDealID());
		LOGGER.info("Getting Asset Payoff Dtls for Deal " + getF_IN_islamicBankingObject().getDealID());
		EarlyAssetPayoffDtls earlyAssetPayoffDtls = null;
		LOGGER.info("Input mode " + getF_IN_mode());
		LOGGER.info("Input Building block mode " + getF_IN_BBMode());
		isAssetPayOffProcess = EarlyAssetPayoffUtils
				.isAssetPayOffProcess(getF_IN_islamicBankingObject().getSearchPageID());

		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			earlyAssetPayoffDtls = new EarlyAssetPayoffDtls();
			getAssetDtls(earlyAssetPayoffDtls);
		}
		if (getF_IN_mode().equals(CeConstants.INPUT_MODE_SELECT)) {
			earlyAssetPayoffDtls = getF_IN_earlyAssetPayoffDtls();
			EarlyAssetPayoffUtils.validateAssetSelectCount(earlyAssetPayoffDtls,
					getF_IN_islamicBankingObject().getDealID(), isAssetPayOffProcess, getF_IN_BBMode());
			getEarlyAssetPayoffPaymentDtls(earlyAssetPayoffDtls);
		}
		setF_OUT_earlyAssetPayoffDtls(earlyAssetPayoffDtls);
		setF_OUT_isAssetPayoffProcess(isAssetPayOffProcess);
	}

	private void getEarlyAssetPayoffPaymentDtls(EarlyAssetPayoffDtls earlyAssetPayoffDtls) {
		if (earlyAssetPayoffDtls != null && earlyAssetPayoffDtls.getEarlyAssetPayoffCollectionCount() > 0) {
			EarlyAssetPayoffCollDtls payoffCollDtls = new EarlyAssetPayoffCollDtls();
			payoffCollDtls.setPaymentAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setTotalRemainingAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setTotalSubsidyPaid(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setTotalRemainingPrincipalAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setTotalRemainingProfitAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setTotalRemainingFeesAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setSurplusAccountBalance(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
			payoffCollDtls.setDealId(dealDetails.getBoID());
			payoffCollDtls.setReverseSubsidyPaid(true);

			if(getF_IN_mode().equals(CeConstants.INPUT_MODE_LOAD)) {
			IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtls = (IBOCE_IB_EarlyAssetPayoffDtls) IBCommonUtils
					.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_EarlyAssetPayoffDtls.BONAME,
							getF_IN_islamicBankingObject().getTransactionID(), true);

			if (assetPayoffDtls != null) {
				String[] assetIds = assetPayoffDtls.getF_IBASSETIDS().split("\\|");
				List assetIdList = Arrays.asList(assetIds);
				for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
						.getEarlyAssetPayoffCollection()) {
					if (assetIdList.contains(earlyAssetPayoffCollection.getAssetId()))
						earlyAssetPayoffCollection.setSelect(true);
					else
						earlyAssetPayoffCollection.setSelect(false);
				}
				payoffCollDtls.setInternalAccountNum(assetPayoffDtls.getF_IBACCOUNTNUMBER());
				payoffCollDtls.setNarrative(assetPayoffDtls.getF_IBNARRATIVE());
				payoffCollDtls.setPaymentMethod(assetPayoffDtls.getF_IBPAYMENTMETHOD());
				payoffCollDtls.setReverseSubsidyPaid(assetPayoffDtls.isF_IBREVSUBSIDYPAID());
			}
			}
			BigDecimal paymentAmount = BigDecimal.ZERO;
			BigDecimal subsidyPaidAmount = BigDecimal.ZERO;
			BigDecimal totalRemainingPrincipalAmount = BigDecimal.ZERO;
			BigDecimal totalRemainingProfitAmount = BigDecimal.ZERO;
			BigDecimal totalRemainingFeesAmount = BigDecimal.ZERO;
			for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
					.getEarlyAssetPayoffCollection()) {
				if (earlyAssetPayoffCollection.isSelect()) {
					paymentAmount = paymentAmount
							.add(earlyAssetPayoffCollection.getTotalRemainingAmntToBeCollected().getCurrencyAmount());
					subsidyPaidAmount = subsidyPaidAmount
							.add(earlyAssetPayoffCollection.getSubsidyPaidAmount().getCurrencyAmount());
					totalRemainingPrincipalAmount = totalRemainingPrincipalAmount
							.add(earlyAssetPayoffCollection.getRemainingAssetCostToBeCollected().getCurrencyAmount());
					totalRemainingProfitAmount = totalRemainingProfitAmount
							.add(earlyAssetPayoffCollection.getRemainingProfitAmntToBeCollected().getCurrencyAmount());
					totalRemainingFeesAmount = totalRemainingFeesAmount
							.add(earlyAssetPayoffCollection.getRemainingFeesAmntToBeCollected().getCurrencyAmount());
				}
			}
			payoffCollDtls.getTotalRemainingAmount().setCurrencyAmount(paymentAmount);
			payoffCollDtls.getTotalSubsidyPaid().setCurrencyAmount(subsidyPaidAmount);
			payoffCollDtls.getTotalRemainingPrincipalAmount().setCurrencyAmount(totalRemainingPrincipalAmount);
			payoffCollDtls.getTotalRemainingProfitAmount().setCurrencyAmount(totalRemainingProfitAmount);
			payoffCollDtls.getTotalRemainingFeesAmount().setCurrencyAmount(totalRemainingFeesAmount);
			if (payoffCollDtls.getReverseSubsidyPaid()) {
				payoffCollDtls.getPaymentAmount().setCurrencyAmount(paymentAmount.add(subsidyPaidAmount));
			} else {
				payoffCollDtls.getPaymentAmount().setCurrencyAmount(paymentAmount);
			}
			IBOIB_DLI_DealDetails dealDetails = IBCommonUtils
					.getDealDetails(getF_IN_islamicBankingObject().getDealID());
			if (dealDetails != null)
				payoffCollDtls.setInternalAccountNum(CeUtils.getSurplusAccount(dealDetails.getF_DealAccountId()));
			if(!IBCommonUtils.isNullOrEmpty(payoffCollDtls.getInternalAccountNum())) {
				Currency surplusAmount = RescheduleUtils.getSurplusAmount(dealDetails.getF_DealAccountId());
				BFCurrencyAmount surplusAmountBFCurr = new BFCurrencyAmount();
				surplusAmountBFCurr.setCurrencyAmount(surplusAmount.getAmount());
				surplusAmountBFCurr.setCurrencyCode(surplusAmount.getIsoCurrencyCode());
				payoffCollDtls.setSurplusAccountBalance(surplusAmountBFCurr);
			}
			earlyAssetPayoffDtls.setEarlyAssetPayoffCollDtls(payoffCollDtls);
		}
	}

	private void getAssetDtls(EarlyAssetPayoffDtls earlyAssetPayoffDtls) {
		Map<String, ArrayList<EarlyAssetPayoffCollection>> assetIdAndDtlsMap = new HashMap<>();
		getPrincipalAndSubsidyAmounts(assetIdAndDtlsMap);
		addSameAssetIdObjects(assetIdAndDtlsMap, earlyAssetPayoffDtls);
		if (isAssetPayOffProcess)
			addProfitAmountTillDate(earlyAssetPayoffDtls);
		getEarlyAssetPayoffPaymentDtls(earlyAssetPayoffDtls);
	}

	private void addProfitAmountTillDate(EarlyAssetPayoffDtls earlyAssetPayoffDtls) {
		BigDecimal arrearAndPaidProfit = BigDecimal.ZERO;
		BigDecimal earnedProfitTillDate = BigDecimal.ZERO;
		Date lastArrearOrPaidOrFirstInstallmentDate = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getLoanStartDate();
		Date futureInstallmentDate = null;
		BigDecimal futureInstallmenProfitAmt = BigDecimal.ZERO;;
		if (readLoanDetailsRs != null && readLoanDetailsRs.getDealDetails().getPaymentScheduleCount() > 0) {
			for (LoanPayments loanPayments : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
				if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
						loanPayments.getRepaymentDate())) {
					arrearAndPaidProfit = arrearAndPaidProfit
							.add(loanPayments.getProfitAmt().add(loanPayments.getFeeAmt()));
					lastArrearOrPaidOrFirstInstallmentDate = loanPayments.getRepaymentDate();
				}
				if (null == futureInstallmentDate && CalendarUtil.IsDate1GreaterThanDate2(
						loanPayments.getRepaymentDate(), lastArrearOrPaidOrFirstInstallmentDate)) {
					futureInstallmentDate = loanPayments.getRepaymentDate();
					futureInstallmenProfitAmt = loanPayments.getProfitAmt().add(loanPayments.getFeeAmt());
					break;
				}
				if(CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
						loanPayments.getRepaymentDate()))
				{
					earnedProfitTillDate = loanPayments.getProfitAmt().add(loanPayments.getFeeAmt());
				}
			}
			
			earnedProfitTillDate = earnedProfitTillDate.add(arrearAndPaidProfit);
						
			//ProductConfiguration prodConfig = IBCommonUtils.loadProductConfiguration(getF_IN_islamicBankingObject().getDealID());
			/*if(RescheduleUtils.isNonFrontLoadedManual(getF_IN_islamicBankingObject().getSubProductID(),dealDetails.getF_DealAccountId(), prodConfig.getIsHostScheduleGenerator()))
			{
				if(CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
						lastArrearOrPaidOrFirstInstallmentDate))
				{
					long noOfDaysOfFutureProfit =0;
					IBusinessDate date1BusinessDate = IBCommonUtils.getCalendarServiceDate(futureInstallmentDate).withoutTimeParts();
			        IBusinessDate date2BusinessDate = IBCommonUtils.getCalendarServiceDate(lastArrearOrPaidOrFirstInstallmentDate).withoutTimeParts();

			        if (date1BusinessDate.isAfterDate(date2BusinessDate)) {
			        	noOfDaysOfFutureProfit = date2BusinessDate.getDaysBetween(date1BusinessDate);
			        }
					BigDecimal perDayProfit =  futureInstallmenProfitAmt.divide(new BigDecimal(noOfDaysOfFutureProfit), 0,
							RoundingMode.HALF_EVEN);
					date1BusinessDate = IBCommonUtils.getCalendarServiceDate(IBCommonUtils.getBFBusinessDate()).withoutTimeParts();
					date2BusinessDate = IBCommonUtils.getCalendarServiceDate(lastArrearOrPaidOrFirstInstallmentDate).withoutTimeParts();
					long noOfDaysForProfit = 0;
					if (date1BusinessDate.isAfterDate(date2BusinessDate)) {
						noOfDaysForProfit = date2BusinessDate.getDaysBetween(date1BusinessDate);
			        }
					earnedProfitTillDate = perDayProfit.multiply(new BigDecimal(noOfDaysForProfit));
				}
				else {
					earnedProfitTillDate = BigDecimal.ZERO;
				}
				arrearAndPaidProfit = arrearAndPaidProfit
						.subtract(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getArrearProfitAmt());
				earnedProfitTillDate = earnedProfitTillDate.add(arrearAndPaidProfit);
			}*/
			if (earnedProfitTillDate.subtract(arrearAndPaidProfit).compareTo(BigDecimal.ZERO) > 0) {
				BigDecimal totalProfitAmount = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getProfitAmt();
				HashMap<String, BigDecimal> assetIdAndProfitPercentage = new HashMap<>();
				HashMap<String, BigDecimal> assetIdAndFeesPercentage = new HashMap<>();
				BigDecimal remainingPercentage = new BigDecimal(100);

				BigDecimal assetProfitPercentage = BigDecimal.ZERO;
				BigDecimal assetFeesPercentage = BigDecimal.ZERO;
				int i = 1;
				for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
						.getEarlyAssetPayoffCollection()) {
					if (i == earlyAssetPayoffDtls.getEarlyAssetPayoffCollectionCount()) {
						assetProfitPercentage = (earlyAssetPayoffCollection.getTotalProfitAmount().getCurrencyAmount()
								.multiply(com.ce.bankfusion.ib.util.ScheduleUtils.hundred)).divide(totalProfitAmount, 0,
										RoundingMode.HALF_EVEN);
						assetIdAndProfitPercentage.put(earlyAssetPayoffCollection.getAssetId(), assetProfitPercentage);
						assetIdAndFeesPercentage.put(earlyAssetPayoffCollection.getAssetId(), remainingPercentage);
					} else {
						assetProfitPercentage = (earlyAssetPayoffCollection.getTotalProfitAmount().getCurrencyAmount()
								.multiply(com.ce.bankfusion.ib.util.ScheduleUtils.hundred)).divide(totalProfitAmount, 0,
										RoundingMode.HALF_EVEN);
						assetIdAndProfitPercentage.put(earlyAssetPayoffCollection.getAssetId(), assetProfitPercentage);

						assetFeesPercentage = (earlyAssetPayoffCollection.getTotalScheduleFeesAmount()
								.getCurrencyAmount().multiply(com.ce.bankfusion.ib.util.ScheduleUtils.hundred))
										.divide(totalProfitAmount, 0, RoundingMode.HALF_EVEN);
						assetIdAndFeesPercentage.put(earlyAssetPayoffCollection.getAssetId(), assetFeesPercentage);

						remainingPercentage = remainingPercentage.subtract(assetProfitPercentage)
								.subtract(assetFeesPercentage);
					}
					++i;
				}
				if (assetIdAndProfitPercentage != null && !assetIdAndProfitPercentage.isEmpty()) {
					int j = 1;
					BigDecimal deltaProfitAmountToBeDistributed = earnedProfitTillDate.subtract(arrearAndPaidProfit);
					BigDecimal remainingProfitAmount = earnedProfitTillDate.subtract(arrearAndPaidProfit);
					for (Map.Entry<String, BigDecimal> entry : assetIdAndProfitPercentage.entrySet()) {
						BFCurrencyAmount assetProfitAmountToBePaid = new BFCurrencyAmount();
						assetProfitAmountToBePaid.setCurrencyAmount(BigDecimal.ZERO);
						assetProfitAmountToBePaid.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						if (j == assetIdAndProfitPercentage.size() && assetIdAndFeesPercentage.isEmpty()) {
							assetProfitAmountToBePaid.setCurrencyAmount(remainingProfitAmount);
						} else {
							assetProfitAmountToBePaid
									.setCurrencyAmount((deltaProfitAmountToBeDistributed.multiply(entry.getValue()))
											.divide(com.ce.bankfusion.ib.util.ScheduleUtils.hundred, 0,
													RoundingMode.HALF_EVEN));
						}
						for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
								.getEarlyAssetPayoffCollection()) {
							if (earlyAssetPayoffCollection.getAssetId().equals(entry.getKey())) {
								earlyAssetPayoffCollection
										.setRemainingProfitAmntToBeCollected(assetProfitAmountToBePaid);
								earlyAssetPayoffCollection.getTotalRemainingAmntToBeCollected()
										.setCurrencyAmount(earlyAssetPayoffCollection
												.getRemainingAssetCostToBeCollected().getCurrencyAmount()
												.add(earlyAssetPayoffCollection.getRemainingProfitAmntToBeCollected()
														.getCurrencyAmount())
												.add(earlyAssetPayoffCollection.getRemainingFeesAmntToBeCollected()
														.getCurrencyAmount()));
							}
						}
						remainingProfitAmount = remainingProfitAmount
								.subtract(assetProfitAmountToBePaid.getCurrencyAmount());
						++j;
					}
					int k = 1;
					for (Map.Entry<String, BigDecimal> entry : assetIdAndFeesPercentage.entrySet()) {
						BFCurrencyAmount scheduleFeesAmountToBePaid = new BFCurrencyAmount();
						scheduleFeesAmountToBePaid.setCurrencyAmount(BigDecimal.ZERO);
						scheduleFeesAmountToBePaid.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
						if (k == assetIdAndFeesPercentage.size()) {
							scheduleFeesAmountToBePaid.setCurrencyAmount(remainingProfitAmount);
						} else {
							scheduleFeesAmountToBePaid
									.setCurrencyAmount((deltaProfitAmountToBeDistributed.multiply(entry.getValue()))
											.divide(com.ce.bankfusion.ib.util.ScheduleUtils.hundred, 0,
													RoundingMode.HALF_EVEN));
						}
						for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
								.getEarlyAssetPayoffCollection()) {
							if (earlyAssetPayoffCollection.getAssetId().equals(entry.getKey())) {
								earlyAssetPayoffCollection
										.setRemainingFeesAmntToBeCollected(scheduleFeesAmountToBePaid);
								earlyAssetPayoffCollection.getTotalRemainingAmntToBeCollected()
										.setCurrencyAmount(earlyAssetPayoffCollection
												.getRemainingAssetCostToBeCollected().getCurrencyAmount()
												.add(earlyAssetPayoffCollection.getRemainingProfitAmntToBeCollected()
														.getCurrencyAmount())
												.add(earlyAssetPayoffCollection.getRemainingFeesAmntToBeCollected()
														.getCurrencyAmount()));
							}
						}
						remainingProfitAmount = remainingProfitAmount
								.subtract(scheduleFeesAmountToBePaid.getCurrencyAmount());
						++k;
					}
				}
			} else {
				for (EarlyAssetPayoffCollection earlyAssetPayoffCollection : earlyAssetPayoffDtls
						.getEarlyAssetPayoffCollection()) {
						earlyAssetPayoffCollection
								.setRemainingProfitAmntToBeCollected(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
						earlyAssetPayoffCollection
						.setRemainingFeesAmntToBeCollected(CeUtils.getZeroAmount(getF_IN_islamicBankingObject().getCurrency()));
						earlyAssetPayoffCollection.getTotalRemainingAmntToBeCollected()
								.setCurrencyAmount(earlyAssetPayoffCollection
										.getRemainingAssetCostToBeCollected().getCurrencyAmount()
										.add(earlyAssetPayoffCollection.getRemainingProfitAmntToBeCollected()
												.getCurrencyAmount())
										.add(earlyAssetPayoffCollection.getRemainingFeesAmntToBeCollected()
												.getCurrencyAmount()));
				}
			}
		}
	}

	private void getPrincipalAndSubsidyAmounts(Map<String, ArrayList<EarlyAssetPayoffCollection>> assetIdAndDtlsMap) {
		ArrayList<String> param = new ArrayList<>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_PaymentSchBreakup> paymentScheduleBreakupDtls = (ArrayList<IBOCE_IB_PaymentSchBreakup>) IBCommonUtils
				.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, paymentSchBreakupQuery, param, null, true);

		if (paymentScheduleBreakupDtls != null && !paymentScheduleBreakupDtls.isEmpty()) {
			for (int i = 0; i < paymentScheduleBreakupDtls.size(); i++) {
				EarlyAssetPayoffCollection assetPayoffCollection = new EarlyAssetPayoffCollection();
				assetPayoffCollection.setAssetId(paymentScheduleBreakupDtls.get(i).getF_IBASSETID());
				assetPayoffCollection.setPrincipalPaidAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setProfitPaidAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setSubsidyPaidAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection
						.setScheduleFeesPaidAmount(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setRemainingAssetCostToBeCollected(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setRemainingFeesAmntToBeCollected(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setRemainingProfitAmntToBeCollected(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setWaivedOffScheduleFeesAmnt(CeUtils.getZeroAmount(dealDetails.getF_IsoCurrencyCode()));

				if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
						paymentScheduleBreakupDtls.get(i).getF_IBBILLDATE())
						|| CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
								paymentScheduleBreakupDtls.get(i).getF_IBBILLDATE())) {
					assetPayoffCollection.setPrincipalPaidAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBPRINCIPALAMT(),
									dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setProfitPaidAmount(IBCommonUtils.getBFCurrencyAmount(
							paymentScheduleBreakupDtls.get(i).getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setSubsidyPaidAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBSUBSIDYAMNT(),
									dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setScheduleFeesPaidAmount(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBSCHEDULEFEEAMT(),
									dealDetails.getF_IsoCurrencyCode()));
				} else {
					assetPayoffCollection.setRemainingAssetCostToBeCollected(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBPRINCIPALAMT(),
									dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setRemainingFeesAmntToBeCollected(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBSCHEDULEFEEAMT(),
									dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setRemainingProfitAmntToBeCollected(IBCommonUtils.getBFCurrencyAmount(
							paymentScheduleBreakupDtls.get(i).getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
					assetPayoffCollection.setWaivedOffScheduleFeesAmnt(
							IBCommonUtils.getBFCurrencyAmount(paymentScheduleBreakupDtls.get(i).getF_IBSCHEDULEFEEAMT(),
									dealDetails.getF_IsoCurrencyCode()));
				}
				assetPayoffCollection.setTotalAssetCost(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleBreakupDtls.get(i).getF_IBPRINCIPALAMT(), dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setTotalProfitAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleBreakupDtls.get(i).getF_IBPROFITAMT(), dealDetails.getF_IsoCurrencyCode()));
				assetPayoffCollection.setTotalScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(
						paymentScheduleBreakupDtls.get(i).getF_IBSCHEDULEFEEAMT(), dealDetails.getF_IsoCurrencyCode()));

				if (assetIdAndDtlsMap.containsKey(paymentScheduleBreakupDtls.get(i).getF_IBASSETID())) {
					assetIdAndDtlsMap.get(paymentScheduleBreakupDtls.get(i).getF_IBASSETID())
							.add(assetPayoffCollection);
				} else {
					ArrayList<EarlyAssetPayoffCollection> paymentSchedules = new ArrayList<>();
					paymentSchedules.add(assetPayoffCollection);
					assetIdAndDtlsMap.put(paymentScheduleBreakupDtls.get(i).getF_IBASSETID(), paymentSchedules);
				}
			}
		}
	}

	private void addSameAssetIdObjects(Map<String, ArrayList<EarlyAssetPayoffCollection>> assetIdAndDtlsMap,
			EarlyAssetPayoffDtls earlyAssetPayoffDtls) {
		Iterator<Entry<String, ArrayList<EarlyAssetPayoffCollection>>> iterator = assetIdAndDtlsMap.entrySet()
				.iterator();
		while (iterator.hasNext()) {
			Entry<String, ArrayList<EarlyAssetPayoffCollection>> entry = iterator.next();
			if ((isAssetPayOffProcess && CeUtils.isAssetDisbursed(entry.getKey())
					&& !CeConstants.ASSETSTATUS_EARLYPAIDOFF
							.equals(EarlyAssetPayoffUtils.getAssetStatus(entry.getKey()))
							&& !DealFollowUpUtils
							.isAssetToBeRecalled(getF_IN_islamicBankingObject().getDealID(), entry.getKey()))
					|| (!isAssetPayOffProcess && DealFollowUpUtils
							.isAssetToBeRecalled(getF_IN_islamicBankingObject().getDealID(), entry.getKey()))) {
				BigDecimal totalAssetCost = BigDecimal.ZERO;
				BigDecimal totalProfitAmount = BigDecimal.ZERO;
				BigDecimal totalScheduleFeesAmount = BigDecimal.ZERO;

				BigDecimal principalPaidAmount = BigDecimal.ZERO;
				BigDecimal profitPaidAmount = BigDecimal.ZERO;
				BigDecimal scheduleFeesPaidAmount = BigDecimal.ZERO;
				BigDecimal subsidyPaidAmount = BigDecimal.ZERO;

				BigDecimal remainingAssetCostToBeCollected = BigDecimal.ZERO;
				BigDecimal remainingFeesAmntToBeCollected = BigDecimal.ZERO;
				BigDecimal remainingProfitAmntToBeCollected = BigDecimal.ZERO;
				BigDecimal totalRemainingAmntToBeCollected = BigDecimal.ZERO;
				BigDecimal totalWaiveOffScheduleFees = BigDecimal.ZERO;

				for (EarlyAssetPayoffCollection assetPayoffDtl : entry.getValue()) {
					totalAssetCost = totalAssetCost.add(assetPayoffDtl.getTotalAssetCost().getCurrencyAmount());
					totalProfitAmount = totalProfitAmount
							.add(assetPayoffDtl.getTotalProfitAmount().getCurrencyAmount());
					totalScheduleFeesAmount = totalScheduleFeesAmount
							.add(assetPayoffDtl.getTotalScheduleFeesAmount().getCurrencyAmount());
					principalPaidAmount = principalPaidAmount
							.add(assetPayoffDtl.getPrincipalPaidAmount().getCurrencyAmount());
					profitPaidAmount = profitPaidAmount.add(assetPayoffDtl.getProfitPaidAmount().getCurrencyAmount());
					scheduleFeesPaidAmount = scheduleFeesPaidAmount
							.add(assetPayoffDtl.getScheduleFeesPaidAmount().getCurrencyAmount());
					subsidyPaidAmount = subsidyPaidAmount
							.add(assetPayoffDtl.getSubsidyPaidAmount().getCurrencyAmount());
					remainingAssetCostToBeCollected = remainingAssetCostToBeCollected
							.add(assetPayoffDtl.getRemainingAssetCostToBeCollected().getCurrencyAmount());
					remainingFeesAmntToBeCollected = remainingFeesAmntToBeCollected
							.add(assetPayoffDtl.getRemainingFeesAmntToBeCollected().getCurrencyAmount());
					remainingProfitAmntToBeCollected = remainingProfitAmntToBeCollected
							.add(assetPayoffDtl.getRemainingProfitAmntToBeCollected().getCurrencyAmount());
					totalWaiveOffScheduleFees = totalWaiveOffScheduleFees.add(assetPayoffDtl.getWaivedOffScheduleFeesAmnt().getCurrencyAmount());
				}
				totalRemainingAmntToBeCollected = remainingAssetCostToBeCollected.add(remainingProfitAmntToBeCollected)
						.add(remainingFeesAmntToBeCollected);

				EarlyAssetPayoffCollection assetPayoffDtl = new EarlyAssetPayoffCollection();
				assetPayoffDtl.setAssetCategoryId(getAssetCategoryId(entry.getKey()));
				assetPayoffDtl.setAssetCategory(getAssetCategoryDesc(assetPayoffDtl.getAssetCategoryId()));
				assetPayoffDtl.setAssetId(entry.getKey());
				assetPayoffDtl.setAssetStatus(CeConstants.GCCODE_EARLYASSETPAYOFFSTATUS_INPROGRESS);
				assetPayoffDtl
						.setAssetStatusDesc(IBCommonUtils.getGCChildDesc(CeConstants.GCCODE_EARLYASSETPAYOFFSTATUS,
								CeConstants.GCCODE_EARLYASSETPAYOFFSTATUS_INPROGRESS));
				assetPayoffDtl.setPrincipalPaidAmount(
						IBCommonUtils.getBFCurrencyAmount(principalPaidAmount, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setProfitPaidAmount(
						IBCommonUtils.getBFCurrencyAmount(profitPaidAmount, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setScheduleFeesPaidAmount(
						IBCommonUtils.getBFCurrencyAmount(scheduleFeesPaidAmount, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setSubsidyPaidAmount(
						IBCommonUtils.getBFCurrencyAmount(subsidyPaidAmount, dealDetails.getF_IsoCurrencyCode()));

				assetPayoffDtl.setRemainingAssetCostToBeCollected(IBCommonUtils
						.getBFCurrencyAmount(remainingAssetCostToBeCollected, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setRemainingProfitAmntToBeCollected(IBCommonUtils
						.getBFCurrencyAmount(remainingProfitAmntToBeCollected, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setRemainingFeesAmntToBeCollected(IBCommonUtils
						.getBFCurrencyAmount(remainingFeesAmntToBeCollected, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setTotalAssetCost(
						IBCommonUtils.getBFCurrencyAmount(totalAssetCost, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setTotalProfitAmount(
						IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setTotalScheduleFeesAmount(
						IBCommonUtils.getBFCurrencyAmount(totalScheduleFeesAmount, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setTotalRemainingAmntToBeCollected(IBCommonUtils
						.getBFCurrencyAmount(totalRemainingAmntToBeCollected, dealDetails.getF_IsoCurrencyCode()));
				assetPayoffDtl.setWaivedOffScheduleFeesAmnt(IBCommonUtils
						.getBFCurrencyAmount(totalWaiveOffScheduleFees, dealDetails.getF_IsoCurrencyCode()));

				if (!isAssetPayOffProcess) {
					assetPayoffDtl.setSelect(true);
				}
				earlyAssetPayoffDtls.addEarlyAssetPayoffCollection(assetPayoffDtl);
			}
		}
	}

	private String getAssetCategoryId(String assetId) {
		IBOIB_AST_AssetDetails assetDetails = (IBOIB_AST_AssetDetails) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetDetails.BONAME, assetId, true);
		return assetDetails.getF_CATEGORY();
	}

	private String getAssetCategoryDesc(String assetCategoryId) {
		String categoryHirachyName = AssetCategoryUtil.getCategoryQualifiedName(assetCategoryId,
				BankFusionThreadLocal.getPersistanceFactory(), null);
		categoryHirachyName = categoryHirachyName.replace(">", ">>");
		categoryHirachyName = (String) categoryHirachyName.subSequence(0, categoryHirachyName.lastIndexOf(">>"));
		return categoryHirachyName;
	}

	private List<ProfitRateDetails> getProfitRateDetails() {
		ArrayList<Object> param = new ArrayList<Object>();
		param.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOIB_DLI_ScheduleProfile> scheduleProfile = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOIB_DLI_ScheduleProfile.BONAME, ScheduleUtils.QUERY_DEAL_SCH_PROFILE_DTLS, param, null, true);

		List<ProfitRateDetails> rateList = new ArrayList<ProfitRateDetails>();
		if (scheduleProfile != null && !scheduleProfile.isEmpty()) {

			ProfitRateDetails profitdetails = new ProfitRateDetails();
			profitdetails.setEndDate(scheduleProfile.get(0).getF_scheduleEndDT());
			profitdetails.setProfitAmount(scheduleProfile.get(0).getF_ProfitPaymentAMT()
					.subtract(scheduleProfile.get(0).getF_GraceProfitUnpaidAmt()));

			String profitCalcMethod = CommonConstants.EMPTY_STRING;

			if (DealInitiationConstants.DEALINIT_CONST_FLATRATE.equals(scheduleProfile.get(0).getF_EvaluationMethod())
					|| DealInitiationConstants.DEALINIT_CONST_FIXEDAMOUNT
							.equals(scheduleProfile.get(0).getF_EvaluationMethod())) {
				profitCalcMethod = "10";
			} else if (DealInitiationConstants.DEALINIT_CONST_FIXEDRATE
					.equals(scheduleProfile.get(0).getF_EvaluationMethod())) {
				profitCalcMethod = "13";

			} else
				profitCalcMethod = "0";
			profitdetails.setProfitCalcMethod(profitCalcMethod);

			profitdetails.setProfitRate(scheduleProfile.get(0).getF_ProfitRate());
			profitdetails.setProfitRateBasis(scheduleProfile.get(0).getF_BaseFactor());
			profitdetails.setStartDate(scheduleProfile.get(0).getF_scheduleStartDT());
			profitdetails.setProfitRateCode(CommonConstants.EMPTY_STRING);
			rateList.add(profitdetails);
		}
		return rateList;
	}

}
