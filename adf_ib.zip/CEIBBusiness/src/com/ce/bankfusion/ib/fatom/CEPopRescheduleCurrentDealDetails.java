package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_DealRescheduleDetails;
import com.misys.bankfusion.ib.constants.CoreBankingTemplateConstants;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.fatom.NewSchedulePaymentAmounts;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_CMN_PopRescheduleCurrentDealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.InputOutputConstants;
import com.misys.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.misys.ub.lending.persistence.LoanPlanFinderMethods;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.spi.types.DealPayOffDetailsOutput;
import bf.com.misys.ib.spi.types.LoanBasicDetails;
import bf.com.misys.ib.spi.types.LoanDetails;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadDealPayOffDtlsRq;
import bf.com.misys.ib.spi.types.messages.ReadDealPayOffDtlsRs;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsInput;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRq;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.DealIDInput;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.PastDuePaymentSchedules;
import bf.com.misys.ib.types.PastDueReschedulePaymentsList;
import bf.com.misys.ib.types.PaymentRescheduleResponse;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.RescheduleCurrentDealDetails;
import bf.com.misys.ib.types.RescheduleRequestDetails;
import bf.com.misys.ib.types.RescheduleTotalAmountDetails;
import bf.com.misys.ib.types.header.RqHeader;

/**
 * @author Anusha
 */
public class CEPopRescheduleCurrentDealDetails extends AbstractIB_CMN_PopRescheduleCurrentDealDetails {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private IPersistenceObjectsFactory factory;

    private Boolean overRideProfitCalculation = false;

    private Boolean visibleOverRideProfitCalc = true;

    private boolean isRescheduleProfitChange;

    private IslamicBankingObject islamicBankingObj;

    private LoanDetails loanDet;

    private RescheduleRequestDetails resReqDetails;

    private Boolean isHostScheduleGenerator;

    private ProductConfiguration prodConfig;

    private IBOIB_IBF_DealRescheduleDetails reschDet;

    private String hostConfigured;

    public CEPopRescheduleCurrentDealDetails(BankFusionEnvironment env) {
        super(env);
    }

    private BigDecimal profitAmount = CommonConstants.BIGDECIMAL_ZERO;

    public void process(BankFusionEnvironment env) throws BankFusionException {

        factory = BankFusionThreadLocal.getPersistanceFactory();
        profitAmount = CommonConstants.BIGDECIMAL_ZERO;
        isHostScheduleGenerator = false;

        islamicBankingObj = getF_IN_islamicBankingObject();
        resReqDetails = new RescheduleRequestDetails();
        prodConfig = IBCommonUtils.loadProductConfiguration(islamicBankingObj.getDealID());
        isRescheduleProfitChange = prodConfig.getDealServices().getIsRescheduleProfitChange() != null
            ? prodConfig.getDealServices().getIsRescheduleProfitChange() : false;
        overRideProfitCalculation = prodConfig.getDealServices().isIsRescOverideProfitCalc();
        isHostScheduleGenerator = prodConfig.getIsHostScheduleGenerator();

        hostConfigured = BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, IBConstants.IB_HOST,
            Boolean.FALSE.toString());
        IBOIB_DLI_DealDetails dealDet = IBCommonUtils.getDealDetails(islamicBankingObj.getDealID());
        ReadLoanDetailsRq readLoanDetailsRq = new ReadLoanDetailsRq();
        ReadLoanDetailsInput readLoanDetailsInput = new ReadLoanDetailsInput();

        DealIDInput dealID = new DealIDInput();
        dealID.setDealBranch(dealDet.getF_BranchSortCode());
        dealID.setDealID(islamicBankingObj.getDealID());
        dealID.setSubProductID(dealDet.getF_ProductContextCode());
        readLoanDetailsInput.setDealID(dealID);

        AccountInput dealAccountNo = new AccountInput();
        dealAccountNo.setAccountFormatType(RescheduleConstants.ACCOUNT_FORMAT_TYPE);
        dealAccountNo.setAccountID(dealDet.getF_DealAccountId());

        readLoanDetailsInput.setDealAccountNo(dealAccountNo);
        readLoanDetailsRq.setReadLoanDetailsInput(readLoanDetailsInput);
        RqHeader rqHeader = new RqHeader();
        rqHeader.setMode(RescheduleConstants.VALIDATE);
        readLoanDetailsRq.setRqHeader(rqHeader);

        HashMap param = new HashMap();
        param.put(InputOutputConstants.READLOANDTLSRQ, readLoanDetailsRq);
        HashMap<String, Object> outputParams = MFExecuter.executeMF(RescheduleConstants.IB_SPI_ReadLoanDetails_SRV, env, param);
        ReadLoanDetailsRs readLoanDetailsRs = (ReadLoanDetailsRs) outputParams.get(InputOutputConstants.READLOANDTLSRS);
        String curr = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getLoanCurrency();

        ReadDealPayOffDtlsRq readDealPayOffDtlsRq = new ReadDealPayOffDtlsRq();
        readDealPayOffDtlsRq.setLoanAccountNumber(dealAccountNo);
        readDealPayOffDtlsRq.setDealID(dealID);
        readDealPayOffDtlsRq.setSettlementCurrency(curr);

        param.clear();
        ReadDealPayOffDtlsRs readDealPayOffDtlsRs = new ReadDealPayOffDtlsRs();
        if ("CLOSED".equals(dealDet.getF_SYSTEMSTATUS()) && islamicBankingObj.isIsDealEnquiry()) {
            // Added if for [IBF-7486] to skip payoff call for settled accounts during inquiry
            LogFactory.getLog(CEPopRescheduleCurrentDealDetails.class.getName()).info("Closed Deal in Enquiry");
        } else {
            param.put(InputOutputConstants.READDEALPAYOFFDTLSRQ, readDealPayOffDtlsRq);
            HashMap<String, Object> outputParam = null;
            try {
                outputParam = MFExecuter.executeMF(RescheduleConstants.IB_SPI_ReadLoanPayOffDetails_SRV, env, param);
                readDealPayOffDtlsRs = (ReadDealPayOffDtlsRs) outputParam.get(InputOutputConstants.READDEALPAYOFFDTLSRS);
            } catch (Exception e) {
                LogFactory.getLog(CEPopRescheduleCurrentDealDetails.class.getName()).info("PayOff Details Error");
            }
        }
        profitAmount = readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getProfitAmt();
        populatePastDueAndAllSchedules(readLoanDetailsRs.getDealDetails().getPaymentSchedule(), curr);

        BFCurrencyAmount outstandingFeeAmnt = new BFCurrencyAmount();
        outstandingFeeAmnt.setCurrencyAmount(readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getOustandingFeeAmount());
        outstandingFeeAmnt.setCurrencyCode(curr);

        BFCurrencyAmount resProfitAmount = new BFCurrencyAmount();
        resProfitAmount.setCurrencyAmount(profitAmount);
        resProfitAmount.setCurrencyCode(curr);

        loanDet = readLoanDetailsRs.getDealDetails();

        populateRescheduleRequestDetails(dealDet, resProfitAmount);

        setF_OUT_rescheduleCurrentDealDet(populateCurrentDealDet(readDealPayOffDtlsRs.getPayOffDetailsOutput(), readLoanDetailsRs));
        setF_OUT_outstandingFeeAmount(outstandingFeeAmnt);
        setF_OUT_profitAmount(resProfitAmount);
        setF_OUT_rescheduleRequestDetails(resReqDetails);
        setF_OUT_checkSum(readLoanDetailsRs.getRsHeader().getChecksum());
        setF_OUT_loanDet(loanDet);

        editModes(dealDet);

        setF_OUT_isReschAllowed(
            prodConfig.getDealServices().getIsReschedule() != null ? prodConfig.getDealServices().getIsReschedule() : false);

        if (!islamicBankingObj.isIsDealEnquiry()
            && (islamicBankingObj.getPhaseID().equals("NEWSCHEDULEH") || islamicBankingObj.getPhaseID().equals("NEWSCHEDULES"))) {
            populateNewSchedule(env);
        }
    }

    private RescheduleCurrentDealDetails populateCurrentDealDet(DealPayOffDetailsOutput payOffDetailsOutput,
        ReadLoanDetailsRs readLoanDetailRs) {

        LoanBasicDetails loanBasicDetails = readLoanDetailRs.getDealDetails().getLoanBasicDetails();
        LoanPayments loanPayment = null;
        int paidInstallments = 0;
        RescheduleCurrentDealDetails resCurrDealDet = new RescheduleCurrentDealDetails();
        String curr = loanBasicDetails.getLoanCurrency();
        Date nextInstallmentDate = loanBasicDetails.getNextPaymentDate();

        BFCurrencyAmount dealAmount = new BFCurrencyAmount();
        dealAmount.setCurrencyAmount(loanBasicDetails.getOriginalDealAmount());
        dealAmount.setCurrencyCode(curr);

        BFCurrencyAmount nextInstallmentAmount = new BFCurrencyAmount();
        nextInstallmentAmount.setCurrencyAmount(loanBasicDetails.getNextRepaymentAmount());
        nextInstallmentAmount.setCurrencyCode(curr);

        BFCurrencyAmount outstandingBalance = new BFCurrencyAmount();
        outstandingBalance.setCurrencyAmount(loanBasicDetails.getOutstandingDealAmt());
        outstandingBalance.setCurrencyCode(curr);

        BFCurrencyAmount paidPrinciple = new BFCurrencyAmount();

        // original principal amount minus oustanding principal amount
        if (!IBCommonUtils.isNullOrEmpty(hostConfigured) && hostConfigured.equals(CoreBankingTemplateConstants.ESSENCE_HOST)) {
        	if(BigDecimal.ZERO.compareTo(loanBasicDetails.getTotalDisbursementAmount())==0)
				paidPrinciple.setCurrencyAmount(BigDecimal.ZERO);
        	else
        		paidPrinciple
                .setCurrencyAmount(loanBasicDetails.getTotalDisbursementAmount().subtract(loanBasicDetails.getOutstandingPrincipalAmt()));
        } else {
            paidPrinciple.setCurrencyAmount((loanBasicDetails.getTotalDisbursementAmount().add(loanBasicDetails.getFeeAmount()))
                .subtract(loanBasicDetails.getOutstandingPrincipalAmt()));
        }
        paidPrinciple.setCurrencyCode(curr);

        BFCurrencyAmount paidProfit = new BFCurrencyAmount();// profit amount minus outstanding profit amount
        paidProfit.setCurrencyAmount(loanBasicDetails.getProfitAmt().subtract(loanBasicDetails.getOustandingProfitAmt()));
        paidProfit.setCurrencyCode(curr);

        BFCurrencyAmount pastDueAmount = new BFCurrencyAmount();// overdue loan amount
        pastDueAmount.setCurrencyAmount(loanBasicDetails.getArrearDealAmount());
        pastDueAmount.setCurrencyCode(curr);

        BFCurrencyAmount payOffAmount = new BFCurrencyAmount();
        Boolean isFrontLoadedManual = false;
		IBOIB_DLI_DealDetails dealDet = IBCommonUtils.getDealDetails(islamicBankingObj.getDealID());
		if (!isHostScheduleGenerator)
			isFrontLoadedManual = LoanPlanFinderMethods.isInterestUpfrontLoaded(dealDet.getF_DealAccountId(),
					IBCommonUtils.getBankFusionEnvironment());
		else
			isFrontLoadedManual = !isHostScheduleGenerator;
        BFCurrencyAmount unrealizedProfit = new BFCurrencyAmount();
        BFCurrencyAmount realizedProfit = new BFCurrencyAmount();// earned profit
        if(!isFrontLoadedManual && !isHostScheduleGenerator)
        	realizedProfit.setCurrencyAmount(paidProfit.getCurrencyAmount());
        else
        	realizedProfit.setCurrencyAmount(loanBasicDetails.getEarnedProfit().getAmountEdited());
        realizedProfit.setCurrencyCode(curr);

        if ((readLoanDetailRs.getDealDetails().getLoanBasicDetails().getOutstandingDealAmt().intValue() == 0)) {

            payOffAmount.setCurrencyAmount(BigDecimal.ZERO);

            payOffAmount.setCurrencyCode(curr);
            
            if(!isFrontLoadedManual && !isHostScheduleGenerator)
            	unrealizedProfit.setCurrencyAmount(BigDecimal.ZERO);
            else
            	unrealizedProfit.setCurrencyAmount(loanBasicDetails.getOustandingProfitAmt());

            unrealizedProfit.setCurrencyCode(curr);

            realizedProfit.setCurrencyAmount(paidProfit.getCurrencyAmount());

        }

        else {
            payOffAmount.setCurrencyAmount(
                null != payOffDetailsOutput ? payOffDetailsOutput.getTotalPayOffAmount().getAmountEdited() : BigDecimal.ZERO);

            payOffAmount.setCurrencyCode(curr);
            isHostScheduleGenerator = IBCommonUtils.loadProductConfiguration(islamicBankingObj.getDealID()).getIsHostScheduleGenerator();
            if (!isHostScheduleGenerator && (!(null != BankFusionPropertySupport
                .getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, IBConstants.IB_HOST, "false")
                && BankFusionPropertySupport
                    .getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, IBConstants.IB_HOST, "false")
                    .equals(CoreBankingTemplateConstants.EQ_HOST)) ? true : false)) {
            	if(!isFrontLoadedManual && !isHostScheduleGenerator)
					unrealizedProfit.setCurrencyAmount(BigDecimal.ZERO);
				else
					unrealizedProfit.setCurrencyAmount(
							null != payOffDetailsOutput
									? payOffDetailsOutput.getUnEarnedProfit().getAmountEdited()
											.subtract(realizedProfit.getCurrencyAmount())
									: BigDecimal.ZERO);
            } else {
                unrealizedProfit.setCurrencyAmount(
                    loanBasicDetails.getOustandingProfitAmt().subtract(loanBasicDetails.getEarnedProfit().getAmountEdited()));
            }

            unrealizedProfit.setCurrencyCode(curr);

        }

        BFCurrencyAmount unpaidPrinciple = new BFCurrencyAmount();
        unpaidPrinciple.setCurrencyAmount(loanBasicDetails.getOutstandingPrincipalAmt());
        unpaidPrinciple.setCurrencyCode(curr);

        if (loanBasicDetails.getOutstandingPrincipalAmt().equals(BigDecimal.ZERO)) {
            unpaidPrinciple.setCurrencyAmount(loanBasicDetails.getOriginalPrincipalAmt().subtract(paidPrinciple.getCurrencyAmount()));
        }
        BFCurrencyAmount unPaidProfit = new BFCurrencyAmount();// outstanding profit amount
        unPaidProfit.setCurrencyAmount(loanBasicDetails.getOustandingProfitAmt());
        unPaidProfit.setCurrencyCode(curr);

        BFCurrencyAmount totalProfit = new BFCurrencyAmount();
        totalProfit.setCurrencyAmount(loanBasicDetails.getProfitAmt());
        totalProfit.setCurrencyCode(curr);

        BFCurrencyAmount totalPrinciple = new BFCurrencyAmount();
        totalPrinciple.setCurrencyAmount(loanBasicDetails.getOriginalPrincipalAmt());
        totalPrinciple.setCurrencyCode(curr);

        BFCurrencyAmount totalFeeAmount = new BFCurrencyAmount();
        totalFeeAmount.setCurrencyAmount(loanBasicDetails.getFeeAmount());
        totalFeeAmount.setCurrencyCode(curr);

        // IBF-7126 Starts

        BFCurrencyAmount paidFees = new BFCurrencyAmount();
        paidFees.setCurrencyAmount(loanBasicDetails.getFeeAmount().subtract(loanBasicDetails.getOustandingFeeAmount()));
        paidFees.setCurrencyCode(curr);

        BFCurrencyAmount paidAmount = new BFCurrencyAmount();// loan amount minus oustanding loan amount
        paidAmount.setCurrencyAmount(paidPrinciple.getCurrencyAmount().add(paidProfit.getCurrencyAmount()));
        if (paidAmount.getCurrencyAmount().compareTo(BigDecimal.ZERO) < 0) {
            paidAmount.setCurrencyAmount(BigDecimal.ZERO);
        }
        paidAmount.setCurrencyCode(curr);

        // IBF-7126 End

        if (readLoanDetailRs.getDealDetails().getPaymentSchedule() != null) {
            for (int i = 0; i < readLoanDetailRs.getDealDetails().getPaymentScheduleCount(); i++) {

                loanPayment = readLoanDetailRs.getDealDetails().getPaymentSchedule(i);

                if (RescheduleConstants.UNPAID.equalsIgnoreCase(loanPayment.getRepaymentStatus())) {
                    nextInstallmentDate = loanPayment.getRepaymentDate();
                    nextInstallmentAmount.setCurrencyAmount(loanPayment.getRepaymentAmt());
                    nextInstallmentAmount.setCurrencyCode(curr);
                    break;
                }
                if (RescheduleConstants.FULLY_PAID.equalsIgnoreCase(loanPayment.getRepaymentStatus())
                    || RescheduleConstants.PARTIALLY_PAID.equalsIgnoreCase(loanPayment.getRepaymentStatus())) {
                    ++paidInstallments;

                    // if Essence, schedule charges can be applicable at subproduct level
                    // this will not be part of deal principal amount
                    if (!StringUtils.isBlank(hostConfigured) && hostConfigured.equals(CoreBankingTemplateConstants.ESSENCE_HOST)) {
                        paidAmount.setCurrencyAmount(paidAmount.getCurrencyAmount().add(loanPayment.getFeeAmtPaid()));
                    }
                }
            }
        }
        BFCurrencyAmount disbursedAmount = new BFCurrencyAmount();
        disbursedAmount.setCurrencyAmount(loanBasicDetails.getTotalDisbursementAmount());
        disbursedAmount.setCurrencyCode(curr);

        BFCurrencyAmount unDisbursedAmount = new BFCurrencyAmount();
        if (!IBCommonUtils.isNullOrEmpty(hostConfigured) && hostConfigured.equals(CoreBankingTemplateConstants.ESSENCE_HOST))
            unDisbursedAmount.setCurrencyAmount(totalPrinciple.getCurrencyAmount().subtract(disbursedAmount.getCurrencyAmount()));
        else
            unDisbursedAmount.setCurrencyAmount(
                totalPrinciple.getCurrencyAmount().subtract(loanBasicDetails.getFeeAmount()).subtract(disbursedAmount.getCurrencyAmount()));
        unDisbursedAmount.setCurrencyCode(curr);

        resCurrDealDet.setCurrency(curr);
        resCurrDealDet.setDealAmount(dealAmount);
        resCurrDealDet.setDealId(getF_IN_islamicBankingObject().getDealID());
        resCurrDealDet.setDisbursedAmount(disbursedAmount);
        resCurrDealDet.setEffectiveRate(RescheduleUtils.getCurrentRate(islamicBankingObj.getDealID(),
            prodConfig.getIsHostScheduleGenerator(), loanBasicDetails.getEffectiveRate()));
        resCurrDealDet.setNextInstallmentAmount(nextInstallmentAmount);
        resCurrDealDet.setNextInstallmentDate(nextInstallmentDate);
        resCurrDealDet.setNoOfInstallments(loanBasicDetails.getTotalNoOfPayments());
        resCurrDealDet.setNoOfPaidInstallments(paidInstallments);
        resCurrDealDet.setNoOfPastDueDays(loanBasicDetails.getNoOfPastDueDays());
        resCurrDealDet.setOutstandingBalance(outstandingBalance);
        resCurrDealDet.setPaidAmount(paidAmount);
        resCurrDealDet.setPaidPrinciple(paidPrinciple);
        resCurrDealDet.setPaidProfit(paidProfit);
        resCurrDealDet.setPastDueAmount(pastDueAmount);
        resCurrDealDet.setPayOffAmount(payOffAmount);
        resCurrDealDet.setRealizedProfit(realizedProfit);
        resCurrDealDet.setUnDisbursedAmount(unDisbursedAmount);
        resCurrDealDet.setUnpaidPrinciple(unpaidPrinciple);
        resCurrDealDet.setUnPaidProfit(unPaidProfit);
        resCurrDealDet.setUnrealizedProfit(unrealizedProfit);
        resCurrDealDet.setTotalProfit(totalProfit);
        resCurrDealDet.setTotalPrinciple(totalPrinciple);
        resCurrDealDet.setTotalFeeAmount(totalFeeAmount);

        return resCurrDealDet;

    }

    private void populatePastDueAndAllSchedules(LoanPayments[] loanPayments, String currency) {
        BFCurrencyAmount totalPastDueAmnt = new BFCurrencyAmount();
        BigDecimal pastDueAmnt = CommonConstants.BIGDECIMAL_ZERO;
        PastDueReschedulePaymentsList pastAllPaymentsList = new PastDueReschedulePaymentsList();
        PastDueReschedulePaymentsList pastDueReschedulePaymentsList = new PastDueReschedulePaymentsList();
        int repayemntNo = 1;
        Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
        for (int i = 0; i < loanPayments.length; i++) {

            BFCurrencyAmount schFeeAmnt = new BFCurrencyAmount();
            schFeeAmnt.setCurrencyAmount(loanPayments[i].getFeeAmt());
            schFeeAmnt.setCurrencyCode(currency);

            BFCurrencyAmount schPrincipleAmt = new BFCurrencyAmount();
            schPrincipleAmt.setCurrencyAmount(loanPayments[i].getPrincipleAmt());
            schPrincipleAmt.setCurrencyCode(currency);

            BFCurrencyAmount schProfitAmt = new BFCurrencyAmount();
            schProfitAmt.setCurrencyAmount(loanPayments[i].getProfitAmt());
            schProfitAmt.setCurrencyCode(currency);

            BFCurrencyAmount schRepaymentAmt = new BFCurrencyAmount();
            schRepaymentAmt.setCurrencyAmount(loanPayments[i].getRepaymentAmt());
            schRepaymentAmt.setCurrencyCode(currency);

            PastDuePaymentSchedules pastDuePaymentSchedules = new PastDuePaymentSchedules();
            pastDuePaymentSchedules.setFeeAmt(schFeeAmnt);
            pastDuePaymentSchedules.setIsoCurrencyCode(currency);
            pastDuePaymentSchedules.setPrincipleAmt(schPrincipleAmt);
            pastDuePaymentSchedules.setProfitAmt(schProfitAmt);
            pastDuePaymentSchedules.setProfitRate(loanPayments[i].getProfitRate());
            pastDuePaymentSchedules.setRepaymentAmt(schRepaymentAmt);
            pastDuePaymentSchedules.setRepaymentDate(loanPayments[i].getRepaymentDate());
            pastDuePaymentSchedules.setRepaymentNo(loanPayments[i].getRepaymentNo());
            pastDuePaymentSchedules.setRepaymentType(loanPayments[i].getRepaymentType());
            pastDuePaymentSchedules.setRepaymentNo(repayemntNo);
            pastDuePaymentSchedules.setRepaymentStatus(loanPayments[i].getRepaymentStatus());
            pastAllPaymentsList.addPastDuePaymentsList(pastDuePaymentSchedules);

            if (loanPayments[i].getRepaymentDate().toString().compareTo(businessDate.toString()) < 0) {
                if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                    || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.UNPAID)
                    || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                    pastDueReschedulePaymentsList.addPastDuePaymentsList(pastDuePaymentSchedules);
                    pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                    repayemntNo++;
                }
                profitAmount = profitAmount.subtract(loanPayments[i].getProfitAmt());
            } else if (loanPayments[i].getRepaymentDate().toString().compareTo(businessDate.toString()) == 0) {
                if ((null != BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                    IBConstants.IB_HOST, "false")
                    && BankFusionPropertySupport
                        .getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, IBConstants.IB_HOST, "false").equals("ES"))) {
                    if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                        || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)
                        || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.FULLY_PAID)) {
                        pastDueReschedulePaymentsList.addPastDuePaymentsList(pastDuePaymentSchedules);
                        pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                        repayemntNo++;
                    }
                    profitAmount = profitAmount.subtract(loanPayments[i].getProfitAmt());
                } else {
                    if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                        || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.UNPAID)
                        || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                        pastDueReschedulePaymentsList.addPastDuePaymentsList(pastDuePaymentSchedules);
                        pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                        repayemntNo++;
                    }
                    profitAmount = profitAmount.subtract(loanPayments[i].getProfitAmt());
                }
            } else {
                if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.FULLY_PAID)
                    || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                    profitAmount = profitAmount.subtract(loanPayments[i].getProfitAmt());
                    if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                        pastDueReschedulePaymentsList.addPastDuePaymentsList(pastDuePaymentSchedules);
                        pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                        repayemntNo++;
                    }
                }
            }

        }
        totalPastDueAmnt.setCurrencyAmount(pastDueAmnt);
        totalPastDueAmnt.setCurrencyCode(currency);

        setF_OUT_pastReschedulePaymentList(pastAllPaymentsList);
        setF_OUT_PastDueReschedulePaymentsList(pastDueReschedulePaymentsList);
        setF_OUT_totalPastdueAmount(totalPastDueAmnt);
    }

    private void populateRescheduleRequestDetails(IBOIB_DLI_DealDetails dealDet, BFCurrencyAmount profitAmount) {

        reschDet = RescheduleUtils.getReschReqExistingObjStatusNotCompleted(getF_IN_islamicBankingObject().getDealID());

        if (reschDet != null) {
            BFCurrencyAmount profitAmnt = new BFCurrencyAmount();
            profitAmnt.setCurrencyAmount(reschDet.getF_PROFITAMT());
            profitAmnt.setCurrencyCode(reschDet.getF_DEALCURRENCY());

            BFCurrencyAmount graceExcessProfitAmnt = new BFCurrencyAmount();
            graceExcessProfitAmnt.setCurrencyAmount(reschDet.getF_GRACEEXCESSPROFITAMNT());
            graceExcessProfitAmnt.setCurrencyCode(reschDet.getF_DEALCURRENCY());

            resReqDetails.setDealId(reschDet.getF_DEALNO());
            resReqDetails.setFrequency(reschDet.getF_FREQUNIT());
            resReqDetails.setFrequencyType(reschDet.getF_FREQCODE());
            resReqDetails.setProfitAmount(profitAmnt);
            resReqDetails.setGraceExcessProfitAmount(graceExcessProfitAmnt);
            resReqDetails.setProfitRate(reschDet.getF_PROFITRATE());
            resReqDetails.setTerm(reschDet.getF_TERM());
            resReqDetails.setTermType(reschDet.getF_TERMTYPE());
            resReqDetails.setRescheduleStartDate(reschDet.getF_RSCHDLSTARTDT());
            resReqDetails.setRescheduleReason(reschDet.getF_RSCHDLREASON());
            resReqDetails.setRescheduleDescription(reschDet.getF_RSCHDLDESC());
            resReqDetails.setNoOfPayments(reschDet.getF_NOOFPAYMENTS());
            isRescheduleProfitChange = reschDet.isF_ISRECALCPROFIT();
            if (isHostScheduleGenerator) {
                visibleOverRideProfitCalc = false;
            }
            if (!IBCommonUtils.isHostTemplateParamActive(IBConstants.CATEGORY_PRODUCT, IBConstants.OVER_RIDE_PROFIT_CALCULATION)) {
                visibleOverRideProfitCalc = false;
            }

        } else {
            BFCurrencyAmount graceProfitAmnt = new BFCurrencyAmount();
            graceProfitAmnt.setCurrencyAmount(BigDecimal.ZERO);
            graceProfitAmnt.setCurrencyCode(dealDet.getF_IsoCurrencyCode());

            resReqDetails.setDealId(dealDet.getBoID());
            resReqDetails.setProfitAmount(profitAmount);
            resReqDetails.setProfitRate(RescheduleUtils.getCurrentRate(dealDet.getBoID(), prodConfig.getIsHostScheduleGenerator(),
                loanDet.getLoanBasicDetails().getEffectiveRate()));
            resReqDetails.setGraceExcessProfitAmount(graceProfitAmnt);
            resReqDetails.setRescheduleId(getF_IN_islamicBankingObject().getTransactionID());
            resReqDetails.setFrequency(dealDet.getF_RepayFreqUnit());
            resReqDetails.setFrequencyType(dealDet.getF_RepayFreqcode());
            resReqDetails.setNoOfPayments(0);
            int term = 0;
            String termCode = "";
            if (dealDet.getF_GraceDays() > 0) {
                Date graceEndDate = ScheduleUtils.calculateScheduleEndDate(dealDet.getF_FirstRepaymentDate(), dealDet.getF_DEALTERMCODE(),
                    dealDet.getF_GraceDays());
                Date currentBusinessDate = IBCommonUtils.getCurrentBusinessDate();
                if (/* !currentBusinessDate.before(dealDet.getF_FirstRepaymentDate()) && */!currentBusinessDate.after(graceEndDate)) {
                    String query = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ?";
                    ArrayList<Object> param = new ArrayList<Object>();
                    param.add(dealDet.getBoID());
                    List<IBOIB_DLI_ScheduleProfile> scheduleProfiles =
                        factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME, query, param, null, true);
                    List<IBOIB_IBF_DealRescheduleDetails> reschDtls =
                        RescheduleUtils.getReschReqExistingObjStatusCompleted(dealDet.getBoID());
                    if (null != reschDtls && !reschDtls.isEmpty()) {
                        IBOIB_IBF_DealRescheduleDetails reschDtlLatest = null;
                        for (IBOIB_IBF_DealRescheduleDetails reschDtl : reschDtls) {
                            reschDtlLatest = reschDtl;
                        }
                        if (reschDtlLatest != null) {
                            term = reschDtlLatest.getF_TERM();
                            termCode = reschDtlLatest.getF_TERMTYPE();
                            resReqDetails.setFrequency(reschDtlLatest.getF_FREQUNIT());
                            resReqDetails.setFrequencyType(reschDtlLatest.getF_FREQCODE());
                        }
                    } else {
                        for (IBOIB_DLI_ScheduleProfile scheduleProfile : scheduleProfiles) {
                            term = term + scheduleProfile.getF_DurationUnit();
                            termCode = scheduleProfile.getF_DurationCode();
                            resReqDetails.setFrequency(scheduleProfile.getF_FreqUnit());
                            resReqDetails.setFrequencyType(scheduleProfile.getF_FreqCode());

                            if (isHostScheduleGenerator) {
                                visibleOverRideProfitCalc = false;
                                isRescheduleProfitChange = true;
                            } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                                && scheduleProfile.getF_EvaluationMethod() != null
                                && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_REDUCINGRATE)
                                && scheduleProfile.getF_scheduleOption() != null
                                && scheduleProfile.getF_scheduleOption().equals(DealInitiationConstants.DEALINIT_CONST_CUSTOMIZE)) {
                                visibleOverRideProfitCalc = false;
                                overRideProfitCalculation = false;
                                isRescheduleProfitChange = true;
                            } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                                && scheduleProfile.getF_EvaluationMethod() != null
                                && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_FIXEDRATE)) {
                                visibleOverRideProfitCalc = true;
                                overRideProfitCalculation = false;
                                isRescheduleProfitChange = true;
                            } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                                && scheduleProfile.getF_EvaluationMethod() != null
                                && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_FIXEDAMOUNT)) {
                                visibleOverRideProfitCalc = true;
                                overRideProfitCalculation = false;
                                isRescheduleProfitChange = false;
                            } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                                && scheduleProfile.getF_EvaluationMethod() != null
                                && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_REDUCINGRATE)
                                && scheduleProfile.getF_scheduleOption() != null
                                && scheduleProfile.getF_scheduleOption().equals(DealInitiationConstants.DEALINIT_CONST_GENERATE)) {
                                visibleOverRideProfitCalc = true;
                                overRideProfitCalculation = false;
                                isRescheduleProfitChange = true;
                            } else {
                                visibleOverRideProfitCalc = true;
                            }

                            if (!IBCommonUtils.isHostTemplateParamActive(IBConstants.CATEGORY_PRODUCT,
                                IBConstants.OVER_RIDE_PROFIT_CALCULATION)) {
                                visibleOverRideProfitCalc = false;
                            }

                        }

                    }

                }
            } else {

                String query = "WHERE " + IBOIB_DLI_ScheduleProfile.DealNo + " = ?";
                ArrayList<Object> param = new ArrayList<Object>();
                param.add(dealDet.getBoID());
                List<IBOIB_DLI_ScheduleProfile> scheduleProfiles =
                    factory.findByQuery(IBOIB_DLI_ScheduleProfile.BONAME, query, param, null, true);

                for (IBOIB_DLI_ScheduleProfile scheduleProfile : scheduleProfiles) {
                    if (isHostScheduleGenerator) {
                        visibleOverRideProfitCalc = false;
                        isRescheduleProfitChange = true;
                    } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                        && scheduleProfile.getF_EvaluationMethod() != null
                        && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_REDUCINGRATE)
                        && scheduleProfile.getF_scheduleOption() != null
                        && scheduleProfile.getF_scheduleOption().equals(DealInitiationConstants.DEALINIT_CONST_CUSTOMIZE)) {
                        visibleOverRideProfitCalc = false;
                        overRideProfitCalculation = false;
                        isRescheduleProfitChange = true;
                    } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                        && scheduleProfile.getF_EvaluationMethod() != null
                        && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_FIXEDRATE)) {
                        visibleOverRideProfitCalc = true;
                        overRideProfitCalculation = false;
                        isRescheduleProfitChange = true;
                    } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                        && scheduleProfile.getF_EvaluationMethod() != null
                        && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_FIXEDAMOUNT)) {
                        visibleOverRideProfitCalc = true;
                        overRideProfitCalculation = false;
                        isRescheduleProfitChange = false;
                    } else if (!isHostScheduleGenerator && scheduleProfile.getF_ScheduleType().equals(IBConstants.REPAYMENT)
                        && scheduleProfile.getF_EvaluationMethod() != null
                        && scheduleProfile.getF_EvaluationMethod().equals(DealInitiationConstants.DEALINIT_CONST_REDUCINGRATE)
                        && scheduleProfile.getF_scheduleOption() != null
                        && scheduleProfile.getF_scheduleOption().equals(DealInitiationConstants.DEALINIT_CONST_GENERATE)) {
                        visibleOverRideProfitCalc = true;
                        overRideProfitCalculation = false;
                        isRescheduleProfitChange = true;
                    } else {
                        visibleOverRideProfitCalc = true;
                    }

                    if (!IBCommonUtils.isHostTemplateParamActive(IBConstants.CATEGORY_PRODUCT, IBConstants.OVER_RIDE_PROFIT_CALCULATION)) {
                        visibleOverRideProfitCalc = false;
                    }

                }

            }
            Date nextRepaymentDate = null;
            int totalNoOfPayments = loanDet.getLoanBasicDetails().getTotalNoOfPayments();
            for (LoanPayments loanPayments : loanDet.getPaymentSchedule()) {
                if (loanPayments.getRepaymentStatus().equals(RescheduleConstants.UNPAID)) {
                    nextRepaymentDate = loanPayments.getRepaymentDate();
                    break;
                } else {
                    term--;
                    totalNoOfPayments--;
                }
            }
            if (dealDet.getF_GraceDays() > 0 && IBCommonUtils.isHostTemplateParamActive(RescheduleConstants.DEALRESCHEDULE_CATEGORY,
                RescheduleConstants.DISABLE_TERM_DURING_GRACE_PARAM)) {
                resReqDetails.setTerm(term);
                resReqDetails.setTermType(termCode);
                resReqDetails.setNoOfPayments(totalNoOfPayments);
            }
          //  resReqDetails.setRescheduleStartDate(nextRepaymentDate);
        }

    }

    private void editModes(IBOIB_DLI_DealDetails dealDet) {

        Boolean reschReqEditableTag = false;
        Boolean profitAmntEditableTag = false;
        Boolean isProfitRateEditable = true, isReducingRateSchedule = false;

        isReducingRateSchedule = RescheduleUtils.isReducingRateSchedule(islamicBankingObj.getDealID());

        String buildingBlockID = BuildingBlockConstants.BuildingBlock.NEWSCHEDULEH.toString();
        String productCode = dealDet.getF_ProductCode();
        String productType = dealDet.getF_ProductContextCode();
        String stepID = getF_IN_islamicBankingObject().getStepID();

        IBOIB_CFG_BuildingBlockConfig buildingBlockConfig = IBCommonUtils.getConfiguredBuildingBlock(buildingBlockID, productCode,
            productType, stepID, getF_IN_islamicBankingObject().getProcessConfigID());

        if (buildingBlockConfig != null) {
            String mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
            if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
                reschReqEditableTag = true;
                profitAmntEditableTag = true;
                isProfitRateEditable = true;
                overRideProfitCalculation = false;
            } else {
                reschReqEditableTag = false;

                if (isRescheduleProfitChange) {
                    if (isReducingRateSchedule) {
                        isProfitRateEditable = false;
                        profitAmntEditableTag = true;// disable profit amount
                    } else {
                        profitAmntEditableTag = false;
                        isProfitRateEditable = true;
                    }
                } else {
                    profitAmntEditableTag = true;
                    isProfitRateEditable = true;
                }
            }

            setF_OUT_profitAmntEditableTag(profitAmntEditableTag);
            setF_OUT_reschReqEditableTag(reschReqEditableTag);
            setF_OUT_isRescheduleProfitChange(isRescheduleProfitChange);
            setF_OUT_isHostSchGenerator(isHostScheduleGenerator);
            setF_OUT_profitRateEditableTag(isProfitRateEditable);
            setF_OUT_isReducingRateSchedule(isReducingRateSchedule);
            setF_OUT_disableOverRideProfitCalculation(!overRideProfitCalculation);
            setF_OUT_visibleOverRideProfitCalc(visibleOverRideProfitCalc);
        }
    }

    private void populateNewSchedule(BankFusionEnvironment env) {

        PaymentRescheduleResponse paymentReschResponse = new PaymentRescheduleResponse();
        if (reschDet != null && !reschDet.getF_RSCHDLSTATUS().equals(IBConstants.DECISION_RETURNED)
            && !reschDet.getF_RSCHDLSTATUS().equals(IBConstants.DECISION_REJECTED)
            && !reschDet.getF_RSCHDLSTATUS().equals(IBConstants.DECISION_CANCELLED)) {
            HashMap inputParams = new HashMap();
            inputParams.put(InputOutputConstants.DEALID, islamicBankingObj.getDealID());
            inputParams.put(InputOutputConstants.LOANDETAILS, loanDet);
            inputParams.put(InputOutputConstants.RESREQDETAILS, resReqDetails);
            inputParams.put(InputOutputConstants.GENERATESCHEDULE, true);
            inputParams.put(InputOutputConstants.CALCULATEPROFIT, true);

            if (loanDet.getLoanBasicDetails().getOustandingProfitAmt()
                .compareTo(resReqDetails.getProfitAmount().getCurrencyAmount()) == 0) {
                inputParams.put(InputOutputConstants.CALCULATEPROFIT, false);
            } else {
                inputParams.put(InputOutputConstants.CALCULATEPROFIT, true);
            }

            HashMap outputParams = MFExecuter.executeMF("IB_CMN_PreapreRqForRescheduleLoan_SRV",
                BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
            paymentReschResponse = (PaymentRescheduleResponse) outputParams.get(InputOutputConstants.PAYMENTRESCHRESPONE);

            BigDecimal totalPricipal = paymentReschResponse.getTotalAmountDetails().getTotalPrincipal().getCurrencyAmount();
            BigDecimal totalProfit = paymentReschResponse.getTotalAmountDetails().getTotalProfit().getCurrencyAmount();

            paymentReschResponse.getTotalAmountDetails().getTotalRepaymentAmount().setCurrencyAmount(totalPricipal.add(totalProfit));

            NewSchedulePaymentAmounts newschedulePaymentAmounts = new NewSchedulePaymentAmounts(env);

            newschedulePaymentAmounts.setF_IN_NewScheduleResponse(paymentReschResponse);

            newschedulePaymentAmounts.setF_OUT_NewScheduleResponse(paymentReschResponse);

            newschedulePaymentAmounts.process(env);

            paymentReschResponse.setTotalAmountDetails(newschedulePaymentAmounts.getF_OUT_NewScheduleResponse().getTotalAmountDetails());

            setF_OUT_displayNewSchedulePanel(true);
        } else {

            BFCurrencyAmount emptyObj = new BFCurrencyAmount();
            emptyObj.setCurrencyAmount(BigDecimal.ZERO);
            emptyObj.setCurrencyCode(islamicBankingObj.getCurrency());

            RescheduleTotalAmountDetails totalAmountDet = new RescheduleTotalAmountDetails();
            totalAmountDet.setTotalFees(emptyObj);
            totalAmountDet.setTotalPastDueAmount(emptyObj);
            totalAmountDet.setTotalPrincipal(emptyObj);
            totalAmountDet.setTotalProfit(emptyObj);
            totalAmountDet.setTotalRepaymentAmount(emptyObj);

            paymentReschResponse.setTotalAmountDetails(totalAmountDet);

        }
        resReqDetails.setNoOfPayments(paymentReschResponse.getNewSchedulePaymentsListCount());
        setF_OUT_paymentRescheduleResponse(paymentReschResponse);

    }

}
