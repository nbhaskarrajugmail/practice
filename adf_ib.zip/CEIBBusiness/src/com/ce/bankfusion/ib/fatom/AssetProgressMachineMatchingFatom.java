package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_AssetProgressMachineMatching;
import com.ce.bankfusion.ib.util.AssetProgressUtil;
import com.misys.bankfusion.calendar.functions.AddYearsToDate;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressPricingDtl;
import bf.com.misys.ib.types.AssetProgressPricingList;

public class AssetProgressMachineMatchingFatom extends AbstractCE_IB_AssetProgressMachineMatching{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(AssetProgressMachineMatchingFatom.class.getName());
	private final String pricingListQuery = " WHERE "+IBOCE_IB_PricingListCfg.IBPRICELISTYEAR+" = ? AND "+IBOCE_IB_PricingListCfg.IBREFERENCENUMBER+" = ?";
	private static Integer E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE = 44000352;
			
	
	@SuppressWarnings("deprecation")
    public AssetProgressMachineMatchingFatom(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	if(getF_IN_mode().equalsIgnoreCase("MATCH")) {
    		matchPricingList();
    	}else {
    		calculateCost();
    	}
    }

	private void calculateCost() {
		//remove all the selected pricing from all list 
		//add to the all list
		//sum all the price
		//set all to out and price to calculated
		System.err.println();
		AssetProgressDetails assetDetail = getF_IN_assetProgressDtl();
		AssetProgressPricingList allAssetPricingList = getF_IN_allAssetProgressPricingList();
		for(AssetProgressPricingDtl assetPricingDtl : allAssetPricingList.getAssetRegistryList()) {
			if(assetPricingDtl.getAssetSerial().equals(assetDetail.getAssetID())) {
				allAssetPricingList.removeAssetRegistryList(assetPricingDtl);
			}
		}
		
		AssetProgressPricingList matchedAssetPricingList = getF_IN_selectedAssetProgressPricingList();
		BFCurrencyAmount calculatedCost = new BFCurrencyAmount();
		calculatedCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		BigDecimal cost = BigDecimal.ZERO;
		for(AssetProgressPricingDtl assetPricingDtl : matchedAssetPricingList.getAssetRegistryList()) {
			if(assetPricingDtl.isSelect()) {
				allAssetPricingList.addAssetRegistryList(assetPricingDtl);
				cost = cost.add(assetPricingDtl.getPrice().getCurrencyAmount());
			}
		}
		if(cost.compareTo(getF_IN_assetStudyCost())>0) {
			String[] parms = new String[2];
			parms[0] = cost.toString();
			parms[1] = getF_IN_assetFinalCost().toString();
			IBCommonUtils.raiseParametrizedEvent(E_ASSET_PROGRESS_MACHINE_AMOUNT_MORE, parms);
		}
		//get the previous reports and calculate the final cost
		
		
		calculatedCost.setCurrencyAmount(cost);
		setF_OUT_allAssetProgressPricingList(allAssetPricingList);
		setF_OUT_calculatedCost(calculatedCost);
		BigDecimal percentage = CalculateStudyGrantApproval.calculateParticipationPercentage(getF_IN_assetStudyCost(), getF_IN_assetFinalCost());
		BFCurrencyAmount finalCost = new BFCurrencyAmount();
		finalCost.setCurrencyAmount(calculatedCost.getCurrencyAmount().multiply(percentage).divide(new BigDecimal(100), 2, RoundingMode.HALF_UP));
		finalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		setF_OUT_calculatedFinalCost(finalCost);
		BigDecimal progressPercent = getF_OUT_calculatedFinalCost().getCurrencyAmount().multiply(new BigDecimal(100)).divide(getF_IN_assetFinalCost(),2, RoundingMode.HALF_UP);
		setF_OUT_progressPercent(progressPercent);
		Map<String, BigDecimal> costMap = AssetProgressUtil.getPreviousReportsCosts(getF_IN_assetProgressReportDetails().getAssetProgressReportList(), assetDetail.getAssetID());;
		BigDecimal previousReportsCost = costMap.get("CALCULATEDCOST");
		BigDecimal previousReportsFinalCost = costMap.get("FINALCOST");
		BFCurrencyAmount netCost = new BFCurrencyAmount();
		netCost.setCurrencyAmount(cost.subtract(previousReportsCost));
		netCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		BFCurrencyAmount netFinalCost = new BFCurrencyAmount();
		netFinalCost.setCurrencyAmount(finalCost.getCurrencyAmount().subtract(previousReportsFinalCost));
		netFinalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		BFCurrencyAmount previousCalculatedCost = new BFCurrencyAmount();
		previousCalculatedCost.setCurrencyAmount(previousReportsCost);
		previousCalculatedCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		BFCurrencyAmount previousFinalCost = new BFCurrencyAmount();
		previousFinalCost.setCurrencyAmount(previousReportsFinalCost);
		previousFinalCost.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
		setF_OUT_netCost(netCost);
		setF_OUT_netFinalCost(netFinalCost);
		setF_OUT_previousCost(previousCalculatedCost);
		setF_OUT_previousFinalCost(previousFinalCost);
	}

	private void matchPricingList() {
		String pricingAssetListQuery = " WHERE "+IBOCE_IB_PricingListAssetCfg.IBASSETCATEGORY+" = ? AND "+IBOCE_IB_PricingListAssetCfg.IBMACHINETYPE+" = ? AND "+ IBOCE_IB_PricingListAssetCfg.IBMACHINENUMBER +" = ?";
		//get the selected registries and set to calculated cost
		AssetProgressDetails assetDetail = getF_IN_assetProgressDtl();
		AssetProgressPricingList allAssetPricingList = getF_IN_allAssetProgressPricingList();
		
		//get the previous selected items against this asset and put assetids in list
		//get the matched from db and put selected true if already selected
		//set the matched to out
		List<String> previousSelectedIds = new ArrayList<>();
		for(AssetProgressPricingDtl assetPricingDtl :allAssetPricingList.getAssetRegistryList()) {
			if(assetPricingDtl.isSelect() && assetPricingDtl.getReportID().equals(getF_IN_reportId())) {
				previousSelectedIds.add(String.valueOf(assetPricingDtl.getPricingAssetID()));
			}
		}
		ArrayList params = new ArrayList<>();
		params.add(assetDetail.getPriceListYear());
		params.add(assetDetail.getPriceListNumber());
		List<IBOCE_IB_PricingListCfg> priceCfgList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_PricingListCfg.BONAME, pricingListQuery, params, null, false);
		ArrayList<String> priceListIds = new ArrayList<>();
		int priceListValidity= Integer.parseInt(IBCommonUtils.getModuleConfigurationValue("IB", "PriceListValidityInYears").getValue());
		for(IBOCE_IB_PricingListCfg pricingCfg : priceCfgList) {
			priceListIds.add(pricingCfg.getBoID());
		}
		params.clear();
		IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, assetDetail.getAssetCategory().getCategory(),
						true);
		String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
		params.add(parentCategoryID);
		params.add(assetDetail.getMachineType());
		params.add(assetDetail.getMachineNumber());
		List<IBOCE_IB_PricingListAssetCfg> priceAssetCfgList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_PricingListAssetCfg.BONAME, pricingAssetListQuery, params, null, false);
		
		AssetProgressPricingList matchedAssetPricingList = new AssetProgressPricingList();
		
		for(IBOCE_IB_PricingListAssetCfg dbPricingAsset : priceAssetCfgList) {
			if(priceListIds.contains(dbPricingAsset.getF_IBPRICINGLISTID())) {
				IBOCE_IB_PricingListCfg ib_PricingListCfg= (IBOCE_IB_PricingListCfg) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_IB_PricingListCfg.BONAME, dbPricingAsset.getF_IBPRICINGLISTID(), true);
				Date expiryDate= AddYearsToDate.run(ib_PricingListCfg.getF_IBPRICINGLISTDATE(), priceListValidity, "yes");
				if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),	new java.sql.Date(expiryDate.getTime()))) {
					if (dbPricingAsset.isF_IBEXTENSIONINDICATOR()) {
						expiryDate = AddYearsToDate.run(dbPricingAsset.getF_NEWPLDATE1(), priceListValidity, "yes");
						if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),	new java.sql.Date(expiryDate.getTime()))) {
							expiryDate = AddYearsToDate.run(dbPricingAsset.getF_NEWPLDATE2(), priceListValidity, "yes");
							if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),	new java.sql.Date(expiryDate.getTime()))) {
								continue;
							}
						}
					}else {
						continue;
					}
				}
				AssetProgressPricingDtl assetProgressDtl = new AssetProgressPricingDtl();
				assetProgressDtl.setSelect(previousSelectedIds.contains(dbPricingAsset.getBoID()));
				assetProgressDtl.setAssetSerial(assetDetail.getAssetID());
				assetProgressDtl.setExtensionIndicator(dbPricingAsset.isF_IBEXTENSIONINDICATOR());
				assetProgressDtl.setHorsePower(dbPricingAsset.getF_IBHORSEPOWER());
				assetProgressDtl.setModel(dbPricingAsset.getF_IBMODEL());
				assetProgressDtl.setPricingListID(dbPricingAsset.getF_IBPRICINGLISTID());
				assetProgressDtl.setPricingAssetID(Integer.parseInt(dbPricingAsset.getBoID()));
				assetProgressDtl.setReportID(getF_IN_reportId());
				BFCurrencyAmount price = new BFCurrencyAmount();
				price.setCurrencyAmount(dbPricingAsset.getF_IBPRICE());
				price.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				assetProgressDtl.setPrice(price);
				matchedAssetPricingList.addAssetRegistryList(assetProgressDtl);
			}
		}
		setF_OUT_foundAssetProgressPricingList(matchedAssetPricingList);
	}

	

	
}
