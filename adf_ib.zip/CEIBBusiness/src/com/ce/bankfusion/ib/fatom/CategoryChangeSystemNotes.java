package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_CategoryChangeSystemNotes;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOUDFEXTIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.BuildingBlockConstants.BuildingBlock;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ib.types.StepNotes;
import bf.com.misys.ib.types.StepNotesCreate;
import bf.com.misys.ib.types.StepNotesCreateRq;
import bf.com.misys.ib.types.StepNotesListRq;
import bf.com.misys.ib.types.StepNotesListRs;

public class CategoryChangeSystemNotes extends AbstractCE_IB_CategoryChangeSystemNotes  {
	
	private static final Log LOGGER = LogFactory.getLog(CategoryChangeSystemNotes.class);	
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public CategoryChangeSystemNotes() {
        super();
    }
	
	@SuppressWarnings("deprecation")
    public CategoryChangeSystemNotes(BankFusionEnvironment env) {
        super(env);
    }
	
	@Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
		
		String whereClauseIboibAstAssetDetails;
        String whereClauseIboibAstAssetCategory;
        String whereClauseIboibAstAssetCategoryParentCategory;
        
        String whereClauseIboibDliDealAssetDtls = " WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ?";  
        ArrayList<String> paramsIboibDliDealAssetDtls = new ArrayList<String>();
        paramsIboibDliDealAssetDtls.add(getF_IN_islamicBankingObject().getDealID());
        List<IBOIB_DLI_DealAssetDtls> dealAssetDtls = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME, whereClauseIboibDliDealAssetDtls, paramsIboibDliDealAssetDtls, null, true);
        
        boolean flag = true;
        //from this dealassetdtls find out the ASSETDETAILSID
        for(IBOIB_DLI_DealAssetDtls forDealAssetDtls : dealAssetDtls)
        {
        if(flag)
        	{
        	whereClauseIboibAstAssetDetails = " WHERE " + IBOIB_AST_AssetDetails.ASSETDETAILSID + " =?";
        	ArrayList<String> paramsIboibAstAssetDetails = new ArrayList<String>();
        	paramsIboibAstAssetDetails.add(forDealAssetDtls.getF_ASSETDETAILSID());
        	List<IBOIB_AST_AssetDetails> assetDtls = factory.findByQuery(IBOIB_AST_AssetDetails.BONAME, whereClauseIboibAstAssetDetails, paramsIboibAstAssetDetails, null, true);
        //from this assetdtls find out CATEGORY;
        		for(IBOIB_AST_AssetDetails forAssetDtls : assetDtls)
        		{	
        		whereClauseIboibAstAssetCategory = " WHERE " + IBOIB_AST_AssetCategory.CATEGORYID + " =?";
        		ArrayList<String> paramsIboibAstAssetCategory = new ArrayList<String>();
        		paramsIboibAstAssetCategory.add(forAssetDtls.getF_CATEGORY());
        		List<IBOIB_AST_AssetCategory> assetCategory = factory.findByQuery(IBOIB_AST_AssetCategory.BONAME, whereClauseIboibAstAssetCategory, paramsIboibAstAssetCategory, null, true);
        //from this assetcategory find out IBPARENTCATEGORYID
        		   for(IBOIB_AST_AssetCategory forAssetCategory : assetCategory)
        			{	
        			whereClauseIboibAstAssetCategoryParentCategory = " WHERE " + IBOIB_AST_AssetCategory.PARENTCATEGORY + " =?"+ "ORDER BY " + IBOIB_AST_AssetCategory.SEQUENCE + " DESC ";
        			ArrayList<String> paramsIboibAstAssetCategoryParentCategory = new ArrayList<String>();
        			paramsIboibAstAssetCategoryParentCategory.add(forAssetCategory.getF_PARENTCATEGORY());
        			List<IBOIB_AST_AssetCategory> parentCategory = factory.findByQuery(IBOIB_AST_AssetCategory.BONAME, whereClauseIboibAstAssetCategoryParentCategory, paramsIboibAstAssetCategoryParentCategory, null, true);
        				for(IBOIB_AST_AssetCategory forParentCategory : parentCategory)
        				{
        				try {	
        				int selectedCategory = Integer.parseInt(forAssetCategory.getF_CATEGORYNAME());
        				int remainingCategory =Integer.parseInt(forParentCategory.getF_CATEGORYNAME());
        	        	if(parentCategory!=null && remainingCategory>selectedCategory)
        	        	{	flag = false;
        	        		raiseSystemNotes(env,remainingCategory);
        	        	    break;
        	        	}
        				}catch (NumberFormatException e) {
        					LOGGER.warn("System notes generation failed due to category" +forAssetCategory.getF_CATEGORYNAME()+"is of type string");
        				 }
        				}
        		    }
        		  }
        		}
          }
      listSystemNotes(env);
	}
	
	private void listSystemNotes(BankFusionEnvironment env) {
        Map input = new HashMap();
        StepNotesListRq stepNotesListRq = new StepNotesListRq();
        StepNotes stepNoteRq = new StepNotes();
        stepNoteRq.setBuildingBlockID(getF_IN_islamicBankingObject().getPhaseID());
        stepNoteRq.setCreateDateTime(IBCommonUtils.getBFBusinessDateTime());
        stepNoteRq.setProcessConfigID(getF_IN_islamicBankingObject().getProcessConfigID());
        stepNoteRq.setStepId(getF_IN_islamicBankingObject().getStepID());
        stepNoteRq.setTransactionID(getF_IN_islamicBankingObject().getTransactionID());
        stepNoteRq.setUserId(getF_IN_islamicBankingObject().getUserID());
        stepNotesListRq.setStepNotes(stepNoteRq);
        input.put("StepNotesListRq", stepNotesListRq);
        HashMap<String, Object> output = MFExecuter.executeMF("IB_IDI_ListNotes_SRV", env, input);
        StepNotesListRs stepNotes = (StepNotesListRs) output.get("StepNotesListRs");
       
        Set<String> notesIdDBSet = new HashSet<>();
        if(stepNotes != null && stepNotes.getStepNotesCount() > 0) {
            for(StepNotes notes : stepNotes.getStepNotes()) {
                notesIdDBSet.add(notes.getNotesID());
            }
        }
       
        Set<String> notesIdUISet = new HashSet<>();
        if(getF_IN_StepNotesListRs() != null && getF_IN_StepNotesListRs().getStepNotesCount() > 0) {
            for(StepNotes notes : getF_IN_StepNotesListRs().getStepNotes()) {
                notesIdUISet.add(notes.getNotesID());
            }
        }
       
        notesIdDBSet.removeAll(notesIdUISet);
        StepNotesListRs outputRs = new StepNotesListRs();
        if(!notesIdDBSet.isEmpty()
                && stepNotes != null && stepNotes.getStepNotesCount() > 0) {
            for(String notesID : notesIdDBSet) {
                for(StepNotes stepNotes2 : stepNotes.getStepNotes()) {
                    if(notesID.equals(stepNotes2.getNotesID())) {
                        outputRs.addStepNotes(stepNotes2);
                    }
                }
            }
        }
        
        setF_OUT_StepNotesListRs(outputRs);
    }
	
	private void raiseSystemNotes(BankFusionEnvironment env,int remainingCategoryNumber) {
		BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
		StepNotesCreate stepnotesCreate = new StepNotesCreate();
		stepnotesCreate.setContext("");
		stepnotesCreate.setBuildingBlockID(BuildingBlock.SUBMIT.toString());
		stepnotesCreate.setCreateDateTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		stepnotesCreate.setNotesStatus(IBConstants.SYSTEM_NOTE_PROCESSED);
		stepnotesCreate.setNoteType(IBConstants.SYSTEM_NOTE_TYPE);
		String value = Integer.toString(remainingCategoryNumber);
		stepnotesCreate.setOldValue(value);
		stepnotesCreate.setNotesText("44000247");
		//stepnotesCreate.setNewVlaue(oldCategory);
		stepnotesCreate.setNewVlaue("");
		stepnotesCreate.setProcessConfigID(getF_IN_islamicBankingObject().getProcessConfigID());
		stepnotesCreate.setStepId(getF_IN_islamicBankingObject().getStepID());
		stepnotesCreate.setTransactionID(getF_IN_islamicBankingObject().getTransactionID());
		stepnotesCreate.setCurrency("");
		stepnotesCreate.setUserId(env.getUserID());
		StepNotesCreateRq stepnotesCreateRq = new StepNotesCreateRq();
		bf.com.misys.ib.types.header.RqHeader rqHeader = new bf.com.misys.ib.types.header.RqHeader();
		stepnotesCreateRq.setStepNotesCreate(stepnotesCreate);
		stepnotesCreateRq.setRqHeader(rqHeader);
		Map request = new HashMap();
		request.put(IBConstants.CREATE_NOTE_INPUT_RQ, stepnotesCreateRq);
		MFExecuter.executeMF(IBConstants.CREATENOTE, env, request);
		
		//Update Asset List Change Value
		IBOUDFEXTIB_DLI_DealDetails ibDealDetailsUD =  (IBOUDFEXTIB_DLI_DealDetails) IBCommonUtils.getPersistanceFactory().
				findByPrimaryKey(IBOUDFEXTIB_DLI_DealDetails.BONAME,getF_IN_islamicBankingObject().getDealID(), true);
		
		String assetListChange_udf = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.UDFPROPERTY, CeConstants.ASSET_LIST_CHANGE_UDF, "", CeConstants.ADFIBCONFIGLOCATION);
		LOGGER.info("ASSET_LIST_CHANGE_UDF Value:"+assetListChange_udf);
		// process the results
			if(ibDealDetailsUD!=null) {
				UserDefinedFields userDefinedFields = ibDealDetailsUD.getUserDefinedFields();
			if (userDefinedFields != null && userDefinedFields.getUserDefinedFieldCount() > 0) {
				
					for(int i=0; i<userDefinedFields.getUserDefinedFieldCount(); i++) {
					
					if (userDefinedFields.getUserDefinedField(i).getFieldName().equals(assetListChange_udf)) {
						LOGGER.info("ASSET_LIST_CHANGE_UDF Value Set to Y:"+userDefinedFields.getUserDefinedField(i).getFieldName());
						userDefinedFields.getUserDefinedField(i).setFieldValue("Y");
						}
					}
				}
			ibDealDetailsUD.setUserDefinedFields(userDefinedFields);
			}
		
		BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
	}


	
}
