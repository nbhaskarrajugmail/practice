package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.CE_IB_GrandApprovalCalculatedID;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_GrandApproval;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_GrandApprovalCalculated;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PricingListAssetCfg;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryAssetCfg;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ADFTechGrantAssetStep;
import com.ce.bankfusion.ib.util.ADFTechGrantAssetUtils;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAditionalDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetThirdPartyDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_AssetCatAttrbts;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
// import com.misys.bankfusion.subsystem.audit.runtime.impl.BankFusionThreadLocal;
// import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.webservice.common.util.WebServiceInvocationHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.msgs.v1r0.CustCustomerExposureInput;
import bf.com.misys.cbs.msgs.v1r0.ReadCustomerPortfolioRq;
import bf.com.misys.cbs.msgs.v1r0.ReadCustomerPortfolioRs;
import bf.com.misys.ib.types.AssetUDF;
import bf.com.misys.ib.types.Output;

public class CE_IB_ADFTechGrantAsset extends AbstractCE_IB_ADFTechGrantAssetStep {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String machineAttributeID;
	private String assetCost = CommonConstants.EMPTY_STRING;

	public CE_IB_ADFTechGrantAsset(BankFusionEnvironment env) {
		super(env);
	}

	public CE_IB_ADFTechGrantAsset() {
		super();
	}

	public void process(BankFusionEnvironment env) {/*
		
		Output outputValue = new Output();
		try {
			String[] arr = getF_IN_InputValue().split("\\|");
			String method = arr[0];
			String dealNo = arr[1];
			String assetSelected = CommonConstants.EMPTY_STRING;
			if(arr.length>2)
				assetSelected = arr[2];
			String assetAttributes = CommonConstants.EMPTY_STRING;
			if(arr.length>3)
				assetAttributes = getAttributes(arr[3]);
			String stepId =  CommonConstants.EMPTY_STRING;
			if(arr.length>4)
				stepId = arr[4];
			String isMachine = getIsMachine(assetSelected);
			outputValue.setIsMachine(isMachine);
			if (isMachine.equals("YES")) {
				switch (stepId) {
				case "TECHNICALANALYSIS":
				case "STUDYANDGRANTAPPROVAL":
					outputValue.setOutputValue(getAssetRegistration(arr[3]));
					setF_OUT_OutputValue(outputValue);
					ADFTechGrantAssetUtils.removeGrantApprovalCalculated(dealNo, assetSelected);
					break;
				case "PROGRESSREPORT":
					outputValue.setOutputValue(getAssetPricing(arr[3]));
					setF_OUT_OutputValue(outputValue);
					ADFTechGrantAssetUtils.removeGrantApprovalCalculated(dealNo, assetSelected);
					break;
				default:
					return;
				}

			} else if(isMachine.equals("NO")){
				String[] arrSPParams = prepareSPInfo(assetSelected, assetAttributes).split("\\@");
				String v_toolno = "";
				String v_grp_cd = "";
				String v_var1 = "";
				String v_var2 = "";
				String v_var3 = "";
				String v_var4 = "";
				String v_var5 = "";
				String v_cur_listser = "";
				String v_app = "";
				String v_crop_list = "";
				// String[] arrSPParams = arr[3].split("\\@");
				for (int i = 0; i < arrSPParams.length; i++) {
					String[] arrSPParamsValue = arrSPParams[i].split("\\:");
					switch (arrSPParamsValue[0]) {
					case "v_toolno":
						v_toolno = arrSPParamsValue[1];
						break;
					case "v_grp_cd":
						v_grp_cd = arrSPParamsValue[1];
						break;
					case "v_var1":
						v_var1 = arrSPParamsValue[1];
						break;
					case "v_var2":
						v_var2 = arrSPParamsValue[1];
						break;
					case "v_var3":
						v_var3 = arrSPParamsValue[1];
						break;
					case "v_var4":
						v_var4 = arrSPParamsValue[1];
						break;
					case "v_var5":
						v_var5 = arrSPParamsValue[1];
						break;
					case "v_cur_listser":
						v_cur_listser = arrSPParamsValue[1];
						break;
					}
				}
				
				switch (v_grp_cd) {
				case "1":
					// return v_res1 out number , v_res2 out number , v_res3 out number ,
					// v_res4 out number, okval out boolean , msg out varchar2
					String spResponse1 = ADFTechGrantAssetUtils.prepareSP1(v_toolno, v_grp_cd, v_var1, v_var2, v_var3, v_var4, v_var5,
							v_cur_listser, v_app, v_crop_list);
					outputValue.setAssetUDFs(updateUDFData(assetSelected, assetAttributes,spResponse1));
					outputValue.setOutputValue(assetCost);
					setF_OUT_OutputValue(outputValue);
					break;
				// 2, 18, 46,47,48,49,50,51,52,53,55,56
				case "0":
				case "2":
				case "18":
				case "46":
				case "47":
				case "48":
				case "49":
				case "50":
				case "51":
				case "52":
				case "53":
				case "55":
				case "56":
					// return v_res1 out number , v_res2 out number , v_res3 out number ,
					// v_res4 out number, okval out boolean , msg out varchar2
					String spResponse2 = ADFTechGrantAssetUtils.prepareSP2(v_toolno, v_grp_cd, v_var1, v_var2, v_var3, v_var4, v_var5,
							v_cur_listser, v_app);
					outputValue.setAssetUDFs(updateUDFData(assetSelected, assetAttributes,spResponse2));
					outputValue.setOutputValue(assetCost);
					setF_OUT_OutputValue(outputValue);
					break;
				// 3,4,5,6,7,8,9,10,12,13,17,19,20,28,31,32,33,34,37,38,39,41,42,43,44,45
				case "3":
				case "4":
				case "5":
				case "6":
				case "7":
				case "8":
				case "9":
				case "10":
				case "12":
				case "13":
				case "17":
				case "19":
				case "20":
				case "28":
				case "31":
				case "32":
				case "33":
				case "34":
				case "37":
				case "38":
				case "39":
				case "41":
				case "42":
				case "43":
				case "44":
				case "45":
					// return v_res1 out number , v_res2 out number ,v_res3 out number,
					// v_res4 out number, okval out boolean , msg out varchar2
					String spResponse3 = ADFTechGrantAssetUtils.prepareSP3(v_toolno, v_grp_cd, v_var1, v_var2, v_var3, v_var4, v_var5, v_cur_listser);
					outputValue.setAssetUDFs(updateUDFData(assetSelected, assetAttributes,spResponse3));
					outputValue.setOutputValue(assetCost);
					setF_OUT_OutputValue(outputValue);
					break;
				// 21,25,26,35,40
				case "21":
				case "25":
				case "26":
				case "35":
				case "40":
					// return v_res1 out number , v_res2 out number , v_res3 out number ,
					// v_res4 out number, v_txt_res out varchar2, okval out boolean, msg out
					// varchar2
					String spResponse4 = ADFTechGrantAssetUtils.prepareSP4(v_toolno, v_grp_cd, v_var1, v_var2, v_var3, v_var4, v_var5, v_cur_listser);
					outputValue.setAssetUDFs(updateUDFData(assetSelected, assetAttributes,spResponse4));
					outputValue.setOutputValue(assetCost);
					setF_OUT_OutputValue(outputValue);
					break;
				}
				ADFTechGrantAssetUtils.removeGrantApprovalCalculated(dealNo, assetSelected);

			}
			switch (method) {

			case "CalculateNormalLoan":
				String returnValue = arr[3];
				String outPut = "";
				BigDecimal totalCost = new BigDecimal(0);
				Thread.sleep(5000);
				for (int i = 3; i < arr.length; i++) {
					// check if the deal/asset is already calculated
					if (ADFTechGrantAssetUtils.hasGrantApprovalCalculated(arr[1], arr[i].split("\\,")[0]))
					{
						totalCost = totalCost.add(new BigDecimal((arr[i].split("\\,")[1])));
						continue;
					}
					outPut = calculateNormalLoan(arr[1], new BigDecimal(arr[i].split("\\,")[1]));
					returnValue += "|" + arr[i].split("\\,")[0] + "," + outPut;
					ADFTechGrantAssetUtils.updateDealAssetDtls(arr[1], arr[i].split("\\,")[0], new BigDecimal(outPut));
					ADFTechGrantAssetUtils.updateDealAssetThirdPartyDtls(arr[1], arr[i].split("\\,")[0], new BigDecimal(outPut));
					totalCost = totalCost.add(new BigDecimal(outPut));
					// flag this deal/asset that grant has been calculated
					ADFTechGrantAssetUtils.addGrantApprovalCalculated(arr[1], arr[i].split("\\,")[0]);
				}
				ADFTechGrantAssetUtils.updateDealAdditionalDtls(arr[1], totalCost);
				ADFTechGrantAssetUtils.updateDealDetails(arr[1], totalCost);
				// deal and loan requested amount
				outputValue.setOutputValue(returnValue);
				setF_OUT_OutputValue(outputValue);
				break;
			case "CalculateSpecialLoan":
				String returnValue1 = arr[3];
				String aks1=null;
				String outPut1 = "";
				BigDecimal totalCost1 = new BigDecimal(0);
				Thread.sleep(5000);
				for (int i = 3; i < arr.length; i++) {
					// check if the deal/asset is already calculated
					if (ADFTechGrantAssetUtils.hasGrantApprovalCalculated(arr[1], arr[i].split("\\,")[0]))
					{
						totalCost1 = totalCost1.add(new BigDecimal((arr[i].split("\\,")[1])));
						continue;
					}
					outPut1 = calculateSpecialLoan(arr[1], new BigDecimal(arr[i].split("\\,")[1]));
					returnValue1 += "|" + arr[i].split("\\,")[0] + "," + outPut1;
					ADFTechGrantAssetUtils.updateDealAssetDtls(arr[1], arr[i].split("\\,")[0], new BigDecimal(outPut1));
					ADFTechGrantAssetUtils.updateDealAssetThirdPartyDtls(arr[1], arr[i].split("\\,")[0], new BigDecimal(outPut1));
					totalCost1 = totalCost1.add(new BigDecimal(outPut1));
					// flag this deal/asset that grant has been calculated
					ADFTechGrantAssetUtils.addGrantApprovalCalculated(arr[1], arr[i].split("\\,")[0]);
				}
				ADFTechGrantAssetUtils.updateDealAdditionalDtls(arr[1], totalCost1);
				ADFTechGrantAssetUtils.updateDealDetails(arr[1], totalCost1);
				// deal and loan requested amount
				outputValue.setOutputValue(returnValue1);
				setF_OUT_OutputValue(outputValue);
				break;
			case "ProcessInfo":
				// deal and loan requested amount
				outputValue.setOutputValue(getProcessInfo(arr[3]));
				setF_OUT_OutputValue(outputValue);
				break;
			}
		} catch (Exception e) {
			// return error message
			outputValue.setOutputValue("ERROR: " + e.toString());
			setF_OUT_OutputValue(outputValue);
		}
	*/}

	private AssetUDF[] updateUDFData(String assetSelected, String assetAttributes, String spResponse) {
		String attributes[] = assetAttributes.split("\\,");
		String spResponseValues[] = spResponse.split("\\|");
		AssetUDF assetUDFs[] = getF_IN_assetUDFsCollection().getAssetUDFs();
		String Attribute6 = spResponseValues[0];
		String Attribute7 = spResponseValues[1];
		String Attribute8 = spResponseValues[2];
		String Attribute9 = spResponseValues[3];
		for (String attribute : attributes) {
			String attrValueMap[] = attribute.split("\\|");
			for (AssetUDF assetUDF : assetUDFs) {
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-6")) {
						if(Attribute6.equals("")||Attribute6.equals("null"))
							Attribute6 = "0";
						assetUDF.setFieldValue(Attribute6);
						assetCost  = Attribute6;
					}
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-7")) {
						if(Attribute7.equals("")||Attribute7.equals("null"))
							Attribute7 = "0";
						assetUDF.setFieldValue(Attribute7);
						}
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-8")) {
						if(Attribute8.equals("")||Attribute8.equals("null"))
							Attribute8 = "0";
						assetUDF.setFieldValue(Attribute8);
						}
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-9")) {
						if(Attribute9.equals("")||Attribute9.equals("null"))
							Attribute9 = "0";
						assetUDF.setFieldValue(Attribute9);
						}
				}
			}
		}
		return assetUDFs;
	}

	private String prepareSPInfo(String assetSelected, String assetAttributes) {
		String spParams = CommonConstants.EMPTY_STRING;
		String attributes[] = assetAttributes.split("\\,");
		AssetUDF assetUDFs[] = getF_IN_assetUDFsCollection().getAssetUDFs();
		for (String attribute : attributes) {
			String attrValueMap[] = attribute.split("\\|");
			for (AssetUDF assetUDF : assetUDFs) {
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("TOOLNO"))
						spParams += "v_toolno" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("GRP_CD"))
						spParams += "v_grp_cd" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-1"))
						spParams += "v_var1" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-2"))
						spParams += "v_var2" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-3"))
						spParams += "v_var3" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-4"))
						spParams += "v_var4" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("Attribute-5"))
						spParams += "v_var5" + ":" + assetUDF.getFieldValue() + "@";
				}
				if (assetUDF.getAssetid().equals(assetSelected) && assetUDF.getFieldId().equals(attrValueMap[0])) {
					if (attrValueMap[1].equals("ECL"))
						spParams += "v_cur_listser" + ":" + assetUDF.getFieldValue() + "@";
				}
			}
		}
		return spParams.substring(0, spParams.length() - 1);
	}

	private String getIsMachine(String assetSelected) {

		AssetUDF[] assetUDFs = getF_IN_assetUDFsCollection().getAssetUDFs();
		for (AssetUDF assetUDF : assetUDFs) {
			if (assetSelected.equals(assetUDF.getAssetid()) && (machineAttributeID.equals(assetUDF.getFieldId()))) {
				return assetUDF.getFieldValue();
			}
		}
		return CommonConstants.EMPTY_STRING;
	}

	private Connection getConnection() throws Exception {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		return factory.getJDBCConnection();

	}

	private String getProcessInfo(String ProcessId) throws Exception {
		try {
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			String whereClause = " WHERE IBPROCESSCONFIGIDPK = ?";

			// Add Parameters
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(ProcessId);

			// Execute and retrieve result
			List<IBOIB_CFG_ProcessConfig> processConfig = factory.findByQuery(IBOIB_CFG_ProcessConfig.BONAME,
					whereClause, queryParams, null, true);

			// process the results
			for (IBOIB_CFG_ProcessConfig process : processConfig) {
				return process.getF_TEMPLATEID();
			}

			return "";
		} catch (Exception e) {
			throw e;
		}
	}

	private String getAttributes(String AssetCategoryId) throws Exception {
		try {
			String assets = getAssets(AssetCategoryId);

			if (assets.equals(""))
				return "";
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			String whereClause = " WHERE IBCATEGORYID IN (";
			String[] assetsArray = assets.split("\\,");
			ArrayList<String> queryParams = new ArrayList<String>();
			for (int i = 0; i < assetsArray.length; i++) {
				whereClause += "?,";
				queryParams.add(assetsArray[i]);
			}
			whereClause = whereClause.substring(0, whereClause.length() - 1) + ")";

			String attributes = "";
			// Execute and retrieve result
			List<IBOIB_IDI_AssetCatAttrbts> assetCatAttrbts = factory.findByQuery(IBOIB_IDI_AssetCatAttrbts.BONAME,
					whereClause, queryParams, null, true);

			// process the results
			for (IBOIB_IDI_AssetCatAttrbts assetCat : assetCatAttrbts) {
				attributes += assetCat.getBoID() + "|" + assetCat.getF_ATTRID() + ",";
				if (assetCat.getF_ATTRID().equals("ISM")) {
					machineAttributeID = assetCat.getBoID();
				}
			}

			attributes = attributes.substring(0, attributes.length() - 1);

			return attributes;
		} catch (Exception e) {
			throw e;
		}
	}

	private String getAssets(String Id) throws Exception {
		String assetIds = "'" + Id + "'";
		String assetId = Id;
		while (true) {
			assetId = getAsset(assetId);
			// Asset not found
			if (assetId.equals(""))
				return "";
			// check if last Asset
			if (assetId.equals("-1")) {
				break;
			}
			assetIds += "," + assetId;
		}
		return assetIds;
	}

	private String getAsset(String Id) throws Exception {
		try {
			// set the factory connection
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			// Filter Query
			String whereClause = " WHERE IBASSETCATEGORYIDPK = ?";
			// Add Parameters
			ArrayList<String> queryParams = new ArrayList<String>();
			queryParams.add(Id);

			// Execute and retrieve result
			List<IBOIB_AST_AssetCategory> categoryList = factory.findByQuery(IBOIB_AST_AssetCategory.BONAME,
					whereClause, queryParams, null, true);

			// process the results
			for (IBOIB_AST_AssetCategory category : categoryList) {
				return category.getF_PARENTCATEGORY();
			}

			return "";
		} catch (Exception e) {
			throw e;
		}
	}

	/* Changes of CX to be made (2) */
	private String getAssetRegistration(String AssetCategoryId) throws Exception {
		BigDecimal result = CommonConstants.BIGDECIMAL_ZERO;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(AssetCategoryId);
		String whereClause = "WHERE "+IBOCE_IB_RegistryAssetCfg.IBASSETCATEGORY +"=?";
		List<IBOCE_IB_RegistryAssetCfg> assetCfgs= factory.findByQuery(IBOCE_IB_RegistryAssetCfg.BONAME, whereClause, params, null);
		if(!assetCfgs.isEmpty()) {
			for (IBOCE_IB_RegistryAssetCfg iboce_IB_RegistryAssetCfg : assetCfgs) {
				result = iboce_IB_RegistryAssetCfg.getF_IBPRICE();
			}
		}
		return result.toString();
	}

	private String getAssetPricing(String AssetCategoryId) throws Exception {

		BigDecimal result = CommonConstants.BIGDECIMAL_ZERO;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(AssetCategoryId);
		String whereClause = "WHERE " + IBOCE_IB_PricingListAssetCfg.IBASSETCATEGORY + "=?";
		List<IBOCE_IB_PricingListAssetCfg> assetCfgs = factory.findByQuery(IBOCE_IB_PricingListAssetCfg.BONAME,
				whereClause, params, null, true);
		if (!assetCfgs.isEmpty()) {
			for (IBOCE_IB_PricingListAssetCfg assetCfg : assetCfgs) {
				result = assetCfg.getF_IBPRICE();
			}
		}
		return result.toString();
	}

	

	private String calculateNormalLoan(String DealNumber, BigDecimal LoanRequestedAmount) throws Exception {
		BigDecimal approvalAmount = new BigDecimal(0);
		BigDecimal liabilityAmount = ADFTechGrantAssetUtils.getCustomerLiabilty(DealNumber);

		BigDecimal x = new BigDecimal(0);
		BigDecimal z = new BigDecimal(0);
		BigDecimal h = new BigDecimal(0);
		BigDecimal s = new BigDecimal(0);
		BigDecimal w = new BigDecimal(0);
		BigDecimal remain = new BigDecimal(0);
		BigDecimal cePercentage2 = new BigDecimal(0);
		BigDecimal cePercentage3 = new BigDecimal(0);
		String SELECT_GRANT_APPROVAL = "WHERE " + IBOCE_IB_GrandApproval.IBTYPE + " = ?  ORDER BY "
				+ IBOCE_IB_GrandApproval.IBORDER + " DESC";
		ArrayList params = new ArrayList<>();
		params.add("N");

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOCE_IB_GrandApproval> grandApprovals = factory.findByQuery(IBOCE_IB_GrandApproval.BONAME,
				SELECT_GRANT_APPROVAL, params, null, true);

		for (IBOCE_IB_GrandApproval grandApproval : grandApprovals) {
			if (grandApproval.getF_IBORDER() == 3) {
				cePercentage3 = grandApproval.getF_IBPERCENTAGE();
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					approvalAmount = LoanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
							.divide(new BigDecimal(100));
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == 2) {
				remain = grandApproval.getF_IBRANGETO().subtract(grandApproval.getF_IBRANGEFROM());
				cePercentage2 = grandApproval.getF_IBPERCENTAGE();
				if ((liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0)
						&& liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);

					if (LoanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = LoanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						// get next row to fetch the next percentage
						// _Result.next();
						approvalAmount = ((LoanRequestedAmount.subtract(x)).multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100))).add(z);
					}
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == CommonConstants.INTEGER_ONE) {
				// check if Liability Amount <= first record
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);
					if (LoanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = LoanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						h = LoanRequestedAmount.subtract(x);
						if (h.compareTo(remain) <= 0) {
							s = h.multiply(cePercentage2).divide(new BigDecimal(100));
						} else {
							s = remain.multiply(cePercentage2).divide(new BigDecimal(100));
							w = (LoanRequestedAmount.subtract((x.add(remain)))).multiply(cePercentage3)
									.divide(new BigDecimal(100));
						}
						approvalAmount = z.add(s).add(w);
					}
					break;
				}
			}
		}
		return String.valueOf(approvalAmount);
	}
	private String calculateSpecialLoan(String DealNumber, BigDecimal LoanRequestedAmount) throws Exception {
		BigDecimal approvalAmount = new BigDecimal(0);
		BigDecimal liabilityAmount = ADFTechGrantAssetUtils.getCustomerLiabilty(DealNumber);

		BigDecimal x = new BigDecimal(0);
		BigDecimal z = new BigDecimal(0);
		BigDecimal h = new BigDecimal(0);
		BigDecimal s = new BigDecimal(0);
		BigDecimal cePercentage2 = new BigDecimal(0);
		String SELECT_GRANT_APPROVAL = "WHERE " + IBOCE_IB_GrandApproval.IBTYPE + " = ?";
		ArrayList params = new ArrayList<>();
		params.add("S");

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOCE_IB_GrandApproval> grandApprovals = factory.findByQuery(IBOCE_IB_GrandApproval.BONAME,
				SELECT_GRANT_APPROVAL, params, null, true);
		for (IBOCE_IB_GrandApproval grandApproval : grandApprovals) {
			if (grandApproval.getF_IBORDER() == 2) {
				cePercentage2 = grandApproval.getF_IBPERCENTAGE();

				// check if Liability amount > last range
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGEFROM()) > 0) {
					approvalAmount = LoanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
							.divide(new BigDecimal(100));
					break;
				}
			}
			if (grandApproval.getF_IBORDER() == CommonConstants.INTEGER_ONE) {
				// check if Liability Amount <= first record
				if (liabilityAmount.compareTo(grandApproval.getF_IBRANGETO()) <= 0) {
					x = grandApproval.getF_IBRANGETO().subtract(liabilityAmount);
					if (LoanRequestedAmount.compareTo(x) <= 0) {
						approvalAmount = LoanRequestedAmount.multiply(grandApproval.getF_IBPERCENTAGE())
								.divide(new BigDecimal(100));
					} else {
						z = x.multiply(grandApproval.getF_IBPERCENTAGE()).divide(new BigDecimal(100));
						h = LoanRequestedAmount.subtract(x);
						s = h.multiply(cePercentage2).divide(new BigDecimal(100));
						approvalAmount = z.add(s);
					}
					break;
				}
			}
		}
		return String.valueOf(approvalAmount);
	}
	
}