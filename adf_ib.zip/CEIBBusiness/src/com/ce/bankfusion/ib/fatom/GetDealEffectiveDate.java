package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetDealEffectiveDate;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class GetDealEffectiveDate extends AbstractCE_IB_GetDealEffectiveDate {

	public GetDealEffectiveDate() {
	}
	public GetDealEffectiveDate(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		String bbMode = CeUtils.getBBMode(getF_IN_islamicBankingObject());
		if (!IBCommonUtils.isNullOrEmpty(bbMode) && !bbMode.equals(IBConstants.VIEWMODE)) {
			if (!CalendarUtil.isDateNullOrDefaultDate(getF_IN_dealEffectiveDate()) && CalendarUtil
					.IsDate1GreaterThanDate2(getF_IN_dealEffectiveDate(), IBCommonUtils.getCurrentBusinessDate())) {
				setF_OUT_dealEffectiveDate(getF_IN_dealEffectiveDate());
			} else {
				setF_OUT_dealEffectiveDate(CalendarUtil.getWorkingDateBasedOnNWDAndStartDate(
						IBCommonUtils.getCurrentBusinessDate(), getF_IN_islamicBankingObject().getDealID(),
						IBCommonUtils.getCurrentBusinessDate(), true));
			}
		} else
			setF_OUT_dealEffectiveDate(getF_IN_dealEffectiveDate());
	}
}
