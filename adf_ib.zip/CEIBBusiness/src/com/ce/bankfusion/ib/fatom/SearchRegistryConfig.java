package com.ce.bankfusion.ib.fatom;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
//import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SearchRegistryConfig;
import com.ce.ib.cfg.dto.RegistryDto;
import com.trapedza.bankfusion.core.BankFusionException;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.PagingData;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;

import org.apache.commons.lang3.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RegistryListCfg;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.RegistryCfgSearchRs;
import bf.com.misys.ib.types.RegistryList;
import bf.com.misys.ib.types.RegistryListCfg;

@SuppressWarnings("serial")
public class SearchRegistryConfig extends AbstractCE_IB_SearchRegistryConfig {
	private static final long serialVersionUID = -1583488685796725466L;
	private static final Integer PAGE_SIZE = 10;
  private static final Integer PAGE_NO = 1;
  private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
  private static final String LIKE = "  like ?";
  

	RegistryList regList = new RegistryList();
	RegistryListCfg regCfg = new RegistryListCfg();

		public SearchRegistryConfig() {
	    super();

	  }
	
	@SuppressWarnings("deprecation")
	public SearchRegistryConfig(BankFusionEnvironment env) {
		super(env);

	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException{
	
		int pageSize = PAGE_SIZE;
    int pageNo = getF_IN_registrySearchRq().getPagedQuery().getPagingRequest().getRequestedPage();
    IPagingData pagingData = null;
    
		if (pageSize == 0)
        pageSize = PAGE_SIZE;
      if (pageNo == 0)
        pageNo = PAGE_NO;

        pagingData = new PagingData(pageNo, pageSize);
        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
        this.getRegistryDtls(pagingData, env);
}
	
	 @SuppressWarnings({ "rawtypes", "unchecked" })
    public VectorTable getRegistryDtls(IPagingData pagingData, BankFusionEnvironment env) {
	     
	     IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	     String referenceNo = getF_IN_registrySearchRq().getRegCfgSearch().getReferenceNo();
	     Date docDate = getF_IN_registrySearchRq().getRegCfgSearch().getDocDate();
	     String docNo = getF_IN_registrySearchRq().getRegCfgSearch().getDocNo();
	     Date regDate = getF_IN_registrySearchRq().getRegCfgSearch().getRegDate();
	     
	     RegistryDto dto = new RegistryDto();
	     StringBuilder registyDtlsWhereClause1 = new StringBuilder("WHERE ");
	     ArrayList params = new ArrayList();
	     String and = " AND ";
	     if (StringUtils.isNotEmpty(referenceNo)) {
	       params.add(referenceNo);
	       registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBREFERENCENUMBER + LIKE);
	     }
	     if (StringUtils.isNotEmpty(docNo)) {
	       if (registyDtlsWhereClause1.length() > 6) {
	         registyDtlsWhereClause1.append(and);
	       }
	       params.add(docNo);
	       registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBDOCUMENTNUMBER + LIKE);
	     }
	     if (null != docDate && !docDate.toString().equals("1970-01-01")) {
	       if (registyDtlsWhereClause1.length() > 6) {
	         registyDtlsWhereClause1.append(and);
	       }
	       registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBDOCUMENTDATE + " =?");
	       params.add(docDate);
	     }
	     if (null != regDate && !regDate.toString().equals("1970-01-01")) {
	       if (registyDtlsWhereClause1.length() > 6) {
	         registyDtlsWhereClause1.append(and);
	       }
	       registyDtlsWhereClause1.append(IBOCE_IB_RegistryListCfg.IBREGISTRYDATE + " =?");

	       params.add(regDate);
	     }

	     List<IBOCE_IB_RegistryListCfg> registryList = new ArrayList<>();
	     if (registyDtlsWhereClause1.toString().equals("WHERE ")) {
	       registryList = factory.findAll(IBOCE_IB_RegistryListCfg.BONAME, pagingData, true);
	     } else {
	       registryList = factory.findByQuery(IBOCE_IB_RegistryListCfg.BONAME, registyDtlsWhereClause1.toString(),
	           params, pagingData, true);
	     }
	     RegistryList registryListDtls = new RegistryList();
	     RegistryListCfg[] regListCfg = new RegistryListCfg[registryList.size()];
	     String[] regID = new String[registryList.size()];
	     for (int i = 0; i < registryList.size(); i++) {

	       RegistryListCfg registryListCfg = new RegistryListCfg();
	       registryListCfg.setDocumentDate(registryList.get(i).getF_IBDOCUMENTDATE());
	       registryListCfg.setDocumentNumber(registryList.get(i).getF_IBDOCUMENTNUMBER());
	       registryListCfg.setReferenceNumber(registryList.get(i).getF_IBREFERENCENUMBER());
	       registryListCfg.setRegistryDate(registryList.get(i).getF_IBREGISTRYDATE());
	       registryListCfg.setRegistryId(registryList.get(i).getBoID());
	       regID[i] = registryList.get(i).getBoID();
	       registryListCfg.setRegistryStatus(
	           (Boolean.compare(registryList.get(i).isF_IBREGISTRYSTATUS(), Boolean.TRUE) == 0) ? "ACTIVE"
	               : "INACTIVE");
	       regListCfg[i] = registryListCfg;
	     }
	     registryListDtls.setRegistryListDtls(regListCfg);
	     dto.setRegistryList(registryListDtls);
	     return this.createResponse(registryList, pagingData, null);
	     //return dto;
	   }
	
	private VectorTable createResponse(List<IBOCE_IB_RegistryListCfg> registryList, IPagingData pagingData, Object object) {
	    VectorTable vectorTable = new VectorTable();
	    RegistryCfgSearchRs registrySearchRs = new RegistryCfgSearchRs();
	    RegistryList registryItem = new RegistryList();
	    boolean select = false;
	    
	    if (registryList != null) {
          for (IBOCE_IB_RegistryListCfg registryType : registryList) {
              this.prepareListRegistryType(registryItem, registryType, select);
              select = false;
              Map<String, Object> map = this.prepareMap(registryType);
              VectorTable newRow = new VectorTable(map);
              vectorTable.addAll(newRow); 
          }
      }

	    PagedQuery pagedQuery = new PagedQuery();
      PagingRequest pagingRequest = new PagingRequest();
      pagingRequest.setNumberOfRows(pagingData.getPageSize());
      pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
      pagingRequest.setTotalPages(pagingData.getTotalPages());
      pagedQuery.setPagingRequest(pagingRequest);
      pagedQuery.setQueryData(registryItem);

      Object pageData[] = new Object[4];
      pageData[0] = pagingRequest.getRequestedPage();
      pageData[1] = pagingRequest.getNumberOfRows();
      pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
      vectorTable.setPagingData(pageData);

      registrySearchRs.setRegCfgSearchList(registryItem);
      registrySearchRs.setPagedQuery(pagedQuery);
      setF_OUT_registrySearchRs(registrySearchRs);
      setF_OUT_PaginatedData(vectorTable);
      return vectorTable;
    }

    private Map<String, Object> prepareMap(IBOCE_IB_RegistryListCfg registryType) {
        Map<String, Object> map = new HashMap<>();
        map.put("versionNumber", registryType.getVersionNum());
        map.put("SELECT", Boolean.FALSE);
        map.put("IBREGISTRYIDPK", registryType.getBoID());
        map.put("IBREFERENCENUMBER", registryType.getF_IBREFERENCENUMBER());
        map.put("IBREGISTRYDATE", registryType.getF_IBREGISTRYDATE());
        map.put("IBDOCUMENTNUMBER", registryType.getF_IBDOCUMENTNUMBER());
        map.put("IBDOCUMENTDATE", registryType.getF_IBDOCUMENTDATE());
        map.put("IBREGISTRYSTATUS", Boolean.compare(registryType.isF_IBREGISTRYSTATUS(), Boolean.TRUE) == 0 ? "ACTIVE"
            : "INACTIVE");
        
        return map;
    }

    private void prepareListRegistryType(RegistryList registryItem, IBOCE_IB_RegistryListCfg registryType, boolean select) {
        RegistryListCfg vRegistryListDtls = new RegistryListCfg();
        vRegistryListDtls.setDocumentDate(registryType.getF_IBDOCUMENTDATE());
        vRegistryListDtls.setDocumentNumber(registryType.getF_IBDOCUMENTNUMBER());
        vRegistryListDtls.setReferenceNumber(registryType.getF_IBREFERENCENUMBER());
        vRegistryListDtls.setRegistryDate(registryType.getF_IBREGISTRYDATE());
        vRegistryListDtls.setRegistryId(registryType.getBoID());
        vRegistryListDtls.setRegistryStatus(Boolean.compare(registryType.isF_IBREGISTRYSTATUS(), Boolean.TRUE) == 0 ? "ACTIVE"
            : "INACTIVE");
        vRegistryListDtls.setSelect(select);
        registryItem.addRegistryListDtls(vRegistryListDtls );  
    }
    
    public ActivityStepPagingState createActivityStepPagingState() {
      ActivityStepPagingState pagingState = super.createActivityStepPagingState();
      return pagingState;
    }
    public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
        @SuppressWarnings("rawtypes") Map map) {

      VectorTable resultVector = new VectorTable();


      int pageSize = PAGE_SIZE;
      int pageNo = PAGE_NO;

      if (map.containsKey("PAGENO")) {
        pageNo = (Integer) map.get("PAGENO");
      }
      if (map.containsKey("NUMBEROFROWS")) {
        pageSize = (Integer) map.get("NUMBEROFROWS");
      }

      IPagingData pagingData = new PagingData(pageNo, pageSize);

      if (pagingData != null) {
        pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
        if (pagingData.getCurrentPageNumber() == 0)
          pagingData.setCurrentPageNumber(pageNo);
        if (pagingData.getPageSize() == 0)
          pagingData.setPageSize(pageSize);

        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);

        resultVector = this.getRegistryDtls(pagingData, env);
      }
      return resultVector;
    }
    
    public RegistryList convertToComplexType(List<RegistryDto> dto) {
		for (RegistryDto registryDto : dto) {

			regCfg.setRegistryId(registryDto.getRegistryId());
			regCfg.setReferenceNumber(registryDto.getReferenceNumber());
			regCfg.setDocumentDate(registryDto.getDocumentDate());
			regCfg.setRegistryDate(registryDto.getRegistryDate());
			regCfg.setRegistryStatus(registryDto.getRegistryStatus());
			regCfg.setDocumentNumber(registryDto.getDocumentNumber());
			regList.addRegistryListDtls(regCfg);
		}
		return regList;

	}
}
