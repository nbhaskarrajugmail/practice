package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentScheduleHistory;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GenerateScheduleWithMultipleContracts;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_ScheduleProfile;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.bankfusion.util.ScheduleUtils;
import com.misys.ib.api.Util.ApiCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.expression.builder.functions.SubtractDaysFromDate;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.cbs.lending.types.LoanScheduleDtls;
import bf.com.misys.dealreschedule.dtls.ib.types.CeDistributePaymentSchedule;
import bf.com.misys.dealreschedule.dtls.ib.types.CePostPonePaymentSchedule;
import bf.com.misys.ib.schedule.payments.DrawdownDetails;
import bf.com.misys.ib.schedule.payments.PaymentSchedule;
import bf.com.misys.ib.schedule.types.DrawDownAndDownPaymentDetails;
import bf.com.misys.ib.schedule.types.ScheduleBasicInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfo;
import bf.com.misys.ib.schedule.types.ScheduleDetailedInfoList;
import bf.com.misys.ib.schedule.types.ScheduleGenInput;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AssetBasicDtls;
import bf.com.misys.ib.types.AssetThirdPartyDtls;
import bf.com.misys.ib.types.AssetThirdPartyDtlsList;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.schedule.dtls.ib.types.AssetBasedPaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.AssetProfileDetails;
import bf.com.misys.schedule.dtls.ib.types.CeAssetProfile;
import bf.com.misys.schedule.dtls.ib.types.CePaymentSchedule;
import bf.com.misys.schedule.dtls.ib.types.PaymentScheduleDetails;

public class GenerateScheduleWithMultipleContracts extends AbstractCE_IB_GenerateScheduleWithMultipleContracts {

	private static final String PO_PROCESSED_STATUS = "Processed";
	private static final Object PO_COMPLETED_STATUS = "Completed";
	private String currencyCode = CommonConstants.EMPTY_STRING;
	private IBOIB_DLI_DealDetails dealDetails;
	private DrawDownAndDownPaymentDetails drawDownAndDownPaymentDetails;
	private ProductConfiguration productConfiguration;
	private Date scheduleStartDate;
	private Date lastPaymentDate;
	private Date firstPaymentDate;
	private ReadAssetData readAssetData;
	private int noOfPayments;
	private int noOfAssetsForSchGen;
	private boolean isDealEffDateLessThanStartDate;
	private boolean isDealEffDateNWD;
	private boolean isPercentageNeg;
	private BFCurrencyAmount dealPrincipalAmnt;
	private BigDecimal profitRate;
	private BigDecimal totalProfitAmount;
	private AssetProfileDetails assetProfileDetails;
	private ReadLoanDetailsRs readLoanDetailsRs;
	private Map<String, PaymentSchedule> assetIdAndpaymentScheduleMap;
	private BigDecimal totalScheduleFeesAmount;
	private PoAssetDisbursementDetails[] poAssetDisbursementDtls;
	private IBOCE_IB_DealReschedule dealReschedule;
	private ArrayList<Date> futureAssetPaymentDates;
	private boolean isgenerateforAllassets = false;
	private static final Log LOGGER = LogFactory.getLog(GenerateScheduleWithMultipleContracts.class);
	public static final int E_FULLY_PAID_AMENDED = 44000810;
	public static final int E_LAST_REPAYMENT_LATER = 44000811;
	public static final int E_NEW_REPAYMENT_BEFORE_BD = 44000812;
	public static final int E_ARREAR_SHOULD_BE_MOVED = 44000813;
	

	public GenerateScheduleWithMultipleContracts(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		LOGGER.info(
				"Generating the customized schedule: Begin for DealId " + getF_IN_islamicBankingObject().getDealID());
		String bbMode = CommonConstants.EMPTY_STRING;
		try {
			dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
		} catch (Exception e) {
			LOGGER.info("Dealdetails doesnot exist for DealId " + getF_IN_islamicBankingObject().getDealID());
			throw e;
		}
		if (dealDetails != null) {
			if (getF_IN_islamicBankingObject() != null
					&& !IBCommonUtils.isNullOrEmpty(getF_IN_islamicBankingObject().getChannel())
					&& !getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)) {
				bbMode = CeUtils.getBBMode(getF_IN_islamicBankingObject());
				LOGGER.info("BB Mode is:" + bbMode);
			}
			if (isF_IN_isReschedule()) {
				if(isF_IN_isGenerate()) {
					RescheduleUtils.validateReschedulePaymentDate(getF_IN_firstPaymentDate());
					RescheduleUtils.validateNewNoOfInstallments(getF_IN_noOfInstallments());
					RescheduleUtils.validateFrequency(getF_IN_paymentFrequency());
				}
			} else {
				// validating the deal effective date and upfront profit percentage for Edit
				// mode and API
				if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)
						|| (!IBCommonUtils.isNullOrEmpty(bbMode) && !bbMode.equals(IBConstants.VIEWMODE))) {
					validateDealEffectiveDate();
					validateUpfrontProfitPercentage();
				}
			}
			init();
			if(!isF_IN_isPostpone() && !isF_IN_isDistribute()) {
			if ((getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)
					|| (!IBCommonUtils.isNullOrEmpty(bbMode) && !bbMode.equals(IBConstants.VIEWMODE))
							&& !isDealEffDateLessThanStartDate && !isDealEffDateNWD && !isPercentageNeg)) {
				generateScheduleAndPersist();
				updateIBRelatedTables();
				updateThirdPartyPaymentSchedules(env);
				updatePercentagesInAssetProfile();
				setF_OUT_assetprofileDetails(assetProfileDetails);
			}
			}else if(isF_IN_isPostpone()) {
				//should not select the fully paid
				//last repayment date should bot be later to the current last repay date
				//new repayment date should not be current or lesser
				generatePostponeSchedule();
				setAssetBasedPaymentSchedule();
				updateIBRelatedTables();
				updateThirdPartyPaymentSchedules(env);
				updatePercentagesInAssetProfile();
				setF_OUT_assetprofileDetails(assetProfileDetails);
			}else if(isF_IN_isDistribute()) {
				generateDistributeSchedule();
				setAssetBasedPaymentSchedule();
				updateIBRelatedTables();
				updateThirdPartyPaymentSchedules(env);
				updatePercentagesInAssetProfile();
				setF_OUT_assetprofileDetails(assetProfileDetails);
			}
			
		}
	}
	private void validatePostponeAndDistribute(){
		
		IBCommonUtils.raiseUnparameterizedEvent(E_FULLY_PAID_AMENDED);
		IBCommonUtils.raiseUnparameterizedEvent(E_LAST_REPAYMENT_LATER);
		IBCommonUtils.raiseUnparameterizedEvent(E_NEW_REPAYMENT_BEFORE_BD);
	}

	private void updatePercentagesInAssetProfile() {
		if (getF_OUT_paymentScheduleList() != null && getF_OUT_paymentScheduleList().getCePaymentScheduleCount() > 0
				&& assetProfileDetails != null && assetProfileDetails.getAssetProfileListCount() > 0) {
			CePaymentSchedule lastRepayment = getF_OUT_paymentScheduleList()
					.getCePaymentSchedule(getF_OUT_paymentScheduleList().getCePaymentScheduleCount() - 1);
			BigDecimal principalRepaymentAmnt = lastRepayment.getPrincipalAmount().getCurrencyAmount();
			BigDecimal profitRepaymentAmnt = lastRepayment.getPrincipalAmount().getCurrencyAmount();
			BigDecimal principalPercentage = com.ce.bankfusion.ib.util.ScheduleUtils.hundred;
			BigDecimal profitPercentage = com.ce.bankfusion.ib.util.ScheduleUtils.hundred;

			int i = 1;
			for (CeAssetProfile ceAssetProfile : assetProfileDetails.getAssetProfileList()) {
				PaymentSchedule paymentSchedule = assetIdAndpaymentScheduleMap.get(ceAssetProfile.getAssetId());
				if (i != assetProfileDetails.getAssetProfileListCount()) {
					ceAssetProfile.setPrincipalPercentageOfTotalPrincipal((paymentSchedule.getPrincipleAmt()
							.getCurrencyAmount().multiply(com.ce.bankfusion.ib.util.ScheduleUtils.hundred))
									.divide(principalRepaymentAmnt, 0, RoundingMode.HALF_EVEN));
					ceAssetProfile.setProfitPercentageOfTotalProfit((paymentSchedule.getProfitAmt().getCurrencyAmount()
							.multiply(com.ce.bankfusion.ib.util.ScheduleUtils.hundred)).divide(profitRepaymentAmnt, 0,
									RoundingMode.HALF_EVEN));
				} else {
					ceAssetProfile.setPrincipalPercentageOfTotalPrincipal(principalPercentage);
					ceAssetProfile.setProfitPercentageOfTotalProfit(profitPercentage);
				}
				ceAssetProfile.setFeesPercentageOfTotalScheduleFees(BigDecimal.ZERO);
				principalPercentage = principalPercentage
						.subtract(ceAssetProfile.getPrincipalPercentageOfTotalPrincipal());
				profitPercentage = profitPercentage.subtract(ceAssetProfile.getProfitPercentageOfTotalProfit());
				++i;
			}
		}
	}

	private void updateIBRelatedTables() {
		if (!isF_IN_generateScheduleForDisbursedAssets()) {
			LOGGER.info("Updating IB related tables after schedule generation");
			ScheduleGenInput scheduleGenInput = new ScheduleGenInput();
			ScheduleDetailedInfoList scheduleDetailedInfoList = new ScheduleDetailedInfoList();
			scheduleGenInput.setDrawDownAndDownPaymentDetails(drawDownAndDownPaymentDetails);
			prepareScheduleInfoObj(scheduleGenInput);
			prepareScheduleDetailedInfoObj(scheduleDetailedInfoList);
			scheduleGenInput.setScheduleDetailedInfoList(scheduleDetailedInfoList);
			
			if (!IBCommonUtils.isNullOrEmpty(getF_IN_islamicBankingObject().getDealID())) {
				IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
				if(dealDetails != null && !IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId())) {
					IBOIB_DLI_ScheduleProfile scheduleProfile = IBCommonUtils.getScheduleProfileOfRepaymentType(getF_IN_islamicBankingObject().getDealID());
					if(scheduleProfile != null && scheduleDetailedInfoList != null 
							&& scheduleDetailedInfoList.getScheduleDetailedInfoListCount() > 0) {
						scheduleDetailedInfoList.getScheduleDetailedInfoList(0).setProfitRate(scheduleProfile.getF_ProfitRate());
						scheduleDetailedInfoList.getScheduleDetailedInfoList(0).setBaseFactor(scheduleProfile.getF_BaseFactor());
					}
				}
			}

			ScheduleUtils.maintainScheduleProfile(scheduleGenInput,
					scheduleDetailedInfoList.getScheduleDetailedInfoList(), getF_IN_islamicBankingObject());
			ScheduleUtils.updateDealDetails(
					scheduleGenInput.getScheduleDetailedInfoList().getScheduleDetailedInfoList(),
					getF_IN_islamicBankingObject(), scheduleGenInput.getScheduleBasicInfo());
			com.ce.bankfusion.ib.util.ScheduleUtils.updateDealAdditionalDetails(
					scheduleGenInput.getScheduleDetailedInfoList().getScheduleDetailedInfoList(),
					getF_IN_islamicBankingObject().getDealID());
		}
	}

	private void updateThirdPartyPaymentSchedules(BankFusionEnvironment env) {
		if (!isF_IN_generateScheduleForDisbursedAssets() && dealDetails != null && !CalendarUtil
				.IsDate1EqualsToDate2(getF_IN_dealEffectiveDate(), dealDetails.getF_DEALEFFECTIVEDT())) {
			LOGGER.info("Updating Third Party Payment schedules incase of Deal effective date change");
			// regenerate third party payment schedules
			PopulateTPPaymentScheduleData populateTPPaymentScheduleData = new PopulateTPPaymentScheduleData(env);
			populateTPPaymentScheduleData.setF_IN_regenerateTPPaymentSchedule(true);
			populateTPPaymentScheduleData.setF_IN_dealEffectiveDate(getF_IN_dealEffectiveDate());
			populateTPPaymentScheduleData.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
			populateTPPaymentScheduleData.process(env);
		}
	}

	private void init() {
		currencyCode = dealDetails.getF_IsoCurrencyCode();

		dealPrincipalAmnt = new BFCurrencyAmount();
		dealPrincipalAmnt.setCurrencyAmount(dealDetails.getF_PrincipleAmt());
		dealPrincipalAmnt.setCurrencyCode(currencyCode);

		if (CalendarUtil.isDateNullOrDefaultDate(getF_IN_dealEffectiveDate())) {
			setF_IN_dealEffectiveDate(dealDetails.getF_DEALEFFECTIVEDT());
		}

		productConfiguration = IBCommonUtils.loadProductConfiguration(getF_IN_islamicBankingObject().getProductID(),
				getF_IN_islamicBankingObject().getSubProductID());
		drawDownAndDownPaymentDetails = new DrawDownAndDownPaymentDetails();
		readAssetData = CeUtils.readAssetData(getF_IN_islamicBankingObject());

		scheduleStartDate = CeUtils.getScheduleStartDate(getF_IN_dealEffectiveDate(), "YEARLY",
				CeUtils.getMinDisbursementPeriod(readAssetData));

		profitRate = BigDecimal.ZERO;
		totalProfitAmount = BigDecimal.ZERO;
		noOfAssetsForSchGen = 0;
		assetProfileDetails = new AssetProfileDetails();

		if (isF_IN_isReschedule()) {
			IBOIB_DLI_ScheduleProfile scheduleProfile = IBCommonUtils
					.getScheduleProfileOfRepaymentType(getF_IN_islamicBankingObject().getDealID());
			if (scheduleProfile != null) {
				setF_IN_pricingMethod(scheduleProfile.getF_ProfitMatrixID());
				setF_IN_profitMethod(scheduleProfile.getF_EvaluationMethod());
			}
		}

		if (!IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId())) {
			readLoanDetailsRs = IBCommonUtils.getLoanDetails(getF_IN_islamicBankingObject().getDealID());
			dealReschedule = RescheduleUtils
					.getRescheduleLatestRecord(getF_IN_islamicBankingObject().getDealID());
		}
		assetIdAndpaymentScheduleMap = new HashMap<>();
		totalScheduleFeesAmount = getF_IN_scheduleFees().getCurrencyAmount().setScale(0, RoundingMode.UP)
				.add(getF_IN_outstandingFees().getCurrencyAmount());
	}

	private void prepareAssetFuturePaymentsDates(String assetId) {
		if (null != poAssetDisbursementDtls) {
			for (PoAssetDisbursementDetails poDetails : poAssetDisbursementDtls) {
				if (assetId.equals(poDetails.getAssetID())) {
					List<IBOCE_IB_IssuePODetail> issuePODetailListDB = getIssuePODetails(poDetails);
					if (null != issuePODetailListDB && !issuePODetailListDB.isEmpty()
							&& !(PO_COMPLETED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS())||PO_PROCESSED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS()))
							&& BigDecimal.ZERO
									.compareTo(poDetails.getCurrentDisbursedAmount().getCurrencyAmount()) != 0) {
						List<IBOCE_IB_PaymentScheduleHistory> paymentsForDealAsset = RescheduleUtils
								.getExistingPaymentScheduleHistoryBreakupRecord(assetId,
										getF_IN_islamicBankingObject().getDealID());
						if (null != paymentsForDealAsset && !paymentsForDealAsset.isEmpty()) {
							for (IBOCE_IB_PaymentScheduleHistory history : paymentsForDealAsset) {
								if (!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
										history.getF_IBREPAYMENTDATE())) {
									futureAssetPaymentDates.add(history.getF_IBREPAYMENTDATE());
								}
							}
						} else {
							LOGGER.error("PaymentScheduleHistory data is empty for deal -->"
									+ getF_IN_islamicBankingObject().getDealID());
						}
					}
				}
			}
		}
	}

	private void prepareScheduleInfoObj(ScheduleGenInput scheduleGenInput) {
		ScheduleBasicInfo scheduleBasicInfo = com.ce.bankfusion.ib.util.ScheduleUtils.prepareScheduleInfoObj(
				lastPaymentDate, getF_IN_dealEffectiveDate(), dealDetails.getF_DealStartDate(), dealPrincipalAmnt);
		scheduleBasicInfo.getDealProfitAmt().setCurrencyAmount(totalProfitAmount);
		scheduleGenInput.setScheduleBasicInfo(scheduleBasicInfo);
	}

	private void prepareScheduleDetailedInfoObj(ScheduleDetailedInfoList scheduleDetailedInfoList) {
		long noOfMonths = CalendarUtil.getMonthsBetweenDate1AndDate2(lastPaymentDate, scheduleStartDate);
		ScheduleDetailedInfo scheduleDetailedInfoObj = new ScheduleDetailedInfo();
		scheduleDetailedInfoObj.setBaseFactor(productConfiguration.getGeneralParameters().getBaseFactor());
		scheduleDetailedInfoObj.setCalculatedProfit(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setDefaultProfitRate(profitRate);
		scheduleDetailedInfoObj.setEquivalentRate(profitRate);
		scheduleDetailedInfoObj.setFactorRate(profitRate);
		scheduleDetailedInfoObj.setGraceProfitCollection(CommonConstants.EMPTY_STRING);
		scheduleDetailedInfoObj.setGraceProfitResidualAmt(CeUtils.getZeroAmount(currencyCode));
		scheduleDetailedInfoObj.setInstallementAmt(CeUtils.getZeroAmount(currencyCode));
		scheduleDetailedInfoObj.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setProfitMatrixId(getF_IN_pricingMethod());
		scheduleDetailedInfoObj.setProfitMethod(getF_IN_profitMethod());
		scheduleDetailedInfoObj.setProfitPayment(IBCommonUtils.getBFCurrencyAmount(totalProfitAmount, currencyCode));
		scheduleDetailedInfoObj.setProfitPaymentAll(true);
		scheduleDetailedInfoObj.setProfitRate(profitRate);
		scheduleDetailedInfoObj.setRoundingOption("1");
		scheduleDetailedInfoObj.setScheduleDurationCode("Month");
		scheduleDetailedInfoObj.setScheduleDurationUnit((int) noOfMonths);
		scheduleDetailedInfoObj.setScheduleEndDate(lastPaymentDate);
		scheduleDetailedInfoObj.setScheduleType(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
		scheduleDetailedInfoObj.setScheduleStartDate(scheduleStartDate);
		scheduleDetailedInfoObj.setPaymentFrequencyCode(getF_IN_paymentFrequency());
		scheduleDetailedInfoObj.setPaymentFrequencyUnit(1);
		scheduleDetailedInfoObj.setPaymentOption(DealInitiationConstants.DEALINIT_CONST_BOTH);
		scheduleDetailedInfoObj.setScheduleOption(DealInitiationConstants.DEALINIT_CONST_GENERATE);
		scheduleDetailedInfoObj.setFirstPaymentDate(firstPaymentDate);
		scheduleDetailedInfoObj.setFirstPaymentDateWithNWDApplied(firstPaymentDate);
		scheduleDetailedInfoObj.setLastPaymentDate(lastPaymentDate);
		scheduleDetailedInfoObj.setLastPaymentDateWithNWDApplied(lastPaymentDate);
		scheduleDetailedInfoObj.setNoOfPayment(noOfPayments);
		scheduleDetailedInfoObj.setPrinciplePayment(dealPrincipalAmnt);
		scheduleDetailedInfoObj.setPrinciplePaymentAll(true);

		scheduleDetailedInfoList.addScheduleDetailedInfoList(scheduleDetailedInfoObj);
	}

	private void generateScheduleAndPersist() {
		AssetThirdPartyDtlsList assetThirdPartyDtlsList = readAssetData.getF_OUT_AssetThirdPartyDtlsList();
		Map<Date, ArrayList<PaymentSchedule>> dateAndpaymentScheduleMap = new HashMap<>();
		Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap = new HashMap();
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		ArrayList<PaymentSchedule> paymentScheduleList = new ArrayList<>();
		if (!isF_IN_isReschedule() || null != poAssetDisbursementDtls) {
			int noOfRecordsDeleted = getNoOfScheduleHistoryRecords();
			if (null != poAssetDisbursementDtls && 0 == noOfRecordsDeleted) {
				// This is to support legacy deals
				// If the history data is not available,Preparing that for all assets
				generateHistoryScheduleForAllAssets(assetThirdPartyDtlsList, dateAndpaymentScheduleMap,
							dateAndCePaymentScheduleMap);
			}
			if (null == readLoanDetailsRs || BigDecimal.ZERO.compareTo(
					readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()) == 0) {
				com.ce.bankfusion.ib.util.ScheduleUtils
						.bulkDeleteBreakupData(getF_IN_islamicBankingObject().getDealID());
			}
		}
		if (IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId())) {
			RescheduleUtils
			.deleteExistingRecordsInBreakupHistoryTable(getF_IN_islamicBankingObject().getDealID());
		}
		if (isF_IN_generateScheduleForDisbursedAssets()) {
			String assetDisbursedStatusDesc = IBCommonUtils.getGCChildDesc(IBConstants.ASSETSTATUS, CeConstants.ASSET_STATUS_DISBURSED);
			String assetPartiallyDisbursedStatusDesc = IBCommonUtils.getGCChildDesc(IBConstants.ASSETSTATUS, "PARTIALLYDIBURSED");
			List<String> transferOfDebtAssets = com.ce.bankfusion.ib.util.ScheduleUtils
					.getAssetIdFromTransferOfDebt(getF_IN_islamicBankingObject().getDealID());
			String udfValueAssetToBeDisbursed = com.misys.bankfusion.common.constant.CommonConstants.EMPTY_STRING;
			for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
				if (!isF_IN_isGenScheduleForFutureAssets()) {
					if (!(transferOfDebtAssets != null &&
							transferOfDebtAssets.contains(assetBasicDtls.getAssetId()))) {
						udfValueAssetToBeDisbursed = CeUtils.getUDFValueAssetToBeDisbursed(readAssetData,
								assetBasicDtls.getAssetId());
						if (udfValueAssetToBeDisbursed.equals("YES")
								|| assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
								|| assetBasicDtls.getAssetStatus().equals(assetDisbursedStatusDesc)
								|| assetBasicDtls.getAssetStatus().equals("PARTIALLYDIBURSED")
								|| assetBasicDtls.getAssetStatus().equals(assetPartiallyDisbursedStatusDesc)) {
							++noOfAssetsForSchGen;
						}
					}
				} else {
					if (!(assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
							|| assetBasicDtls.getAssetStatus().equals(assetDisbursedStatusDesc))) {
						++noOfAssetsForSchGen;
					}
				}
			}

			for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
				// disbursed assets from transfer of debt contains asset, if it doesn't contain
				// then only execute the logic, it will handle both the cases of with/without
				// transfer of debt.

				if (!isF_IN_isGenScheduleForFutureAssets()) {
					LOGGER.info("Generating the schedule for Disbursed Assets");
					if (!(transferOfDebtAssets.contains(assetBasicDtls.getAssetId()))) {
						udfValueAssetToBeDisbursed = CeUtils.getUDFValueAssetToBeDisbursed(readAssetData,
								assetBasicDtls.getAssetId());
						if (udfValueAssetToBeDisbursed.equals("YES")
								|| assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
								|| assetBasicDtls.getAssetStatus().equals(assetDisbursedStatusDesc)
								|| assetBasicDtls.getAssetStatus().equals("PARTIALLYDIBURSED")
								|| assetBasicDtls.getAssetStatus().equals(assetPartiallyDisbursedStatusDesc)) {
							BigDecimal assetCost = com.ce.bankfusion.ib.util.ScheduleUtils
									.getAssetOutstandingPrincipalAmount(readLoanDetailsRs,
											getF_IN_islamicBankingObject().getDealID(), assetBasicDtls.getAssetId());
							generatePrincipalProfitComponents(assetBasicDtls.getAssetId(), assetCost,
									dateAndpaymentScheduleMap, dateAndCePaymentScheduleMap);
							totalAssetCost = totalAssetCost.add(assetCost);
						}
					}
				} else {
					LOGGER.info("Generating the schedule for Future Assets");
					if (!(assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
							|| assetBasicDtls.getAssetStatus().equals(assetDisbursedStatusDesc))) {
						BigDecimal assetCost = new BigDecimal(0);
						for (AssetThirdPartyDtls assetThirdPartyDtls : assetThirdPartyDtlsList
								.getAssetThirdPartyDtls()) {
							if (assetThirdPartyDtls.getAssetID().equals(assetBasicDtls.getAssetId())) {
								assetCost = assetCost.add(
										assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().getCurrencyAmount());
								totalAssetCost = totalAssetCost.add(assetCost);
							}
						}
						generatePrincipalProfitComponents(assetBasicDtls.getAssetId(), assetCost,
								dateAndpaymentScheduleMap, dateAndCePaymentScheduleMap);
					}
				}
			}
		} else {
			LOGGER.info("Generating the schedule for All Assets");
			for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
				String assetId = assetBasicDtls.getAssetId();
				BigDecimal assetCost = new BigDecimal(0);
				if (null != poAssetDisbursementDtls && null != readLoanDetailsRs && BigDecimal.ZERO.compareTo(
						readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()) != 0) {
					BigDecimal totalAssetProfitAmount = BigDecimal.ZERO;
					totalAssetProfitAmount = com.ce.bankfusion.ib.util.ScheduleUtils
							.getAssetExistingProfitAmount(getF_IN_islamicBankingObject().getDealID(), assetId);
					totalProfitAmount = totalProfitAmount.add(totalAssetProfitAmount);
				}
				if (null != poAssetDisbursementDtls) {
					for (PoAssetDisbursementDetails poDetails : poAssetDisbursementDtls) {
						if (assetBasicDtls.getAssetId().equals(poDetails.getAssetID())) {
							List<IBOCE_IB_IssuePODetail> issuePODetailListDB = getIssuePODetails(poDetails);
							if (null != issuePODetailListDB && !issuePODetailListDB.isEmpty()
									&& !(PO_COMPLETED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS())||PO_PROCESSED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS()))
									&& BigDecimal.ZERO.compareTo(
											poDetails.getCurrentDisbursedAmount().getCurrencyAmount()) != 0) {
								assetCost = assetCost.add(poDetails.getCurrentDisbursedAmount().getCurrencyAmount());
								totalAssetCost = totalAssetCost
										.add(poDetails.getCurrentDisbursedAmount().getCurrencyAmount());
								generateAndPersistScheduleForIssuePOAmt(dateAndpaymentScheduleMap,
										dateAndCePaymentScheduleMap, assetId, assetCost);
							}
							else if (null != issuePODetailListDB && !issuePODetailListDB.isEmpty()
									&& (PO_COMPLETED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS())||PO_PROCESSED_STATUS.equals(issuePODetailListDB.get(0).getF_IBSTATUS())))
							{
								totalAssetCost = totalAssetCost
										.add(poDetails.getCurrentDisbursedAmount().getCurrencyAmount());
							}
						}
					}
				} else {
					for (AssetThirdPartyDtls assetThirdPartyDtls : assetThirdPartyDtlsList.getAssetThirdPartyDtls()) {
						if (assetThirdPartyDtls.getAssetID().equals(assetId)) {
							assetCost = assetCost
									.add(assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().getCurrencyAmount());
							totalAssetCost = totalAssetCost.add(assetCost);
						}
					}
					generatePrincipalProfitComponents(assetId, assetCost, dateAndpaymentScheduleMap,
							dateAndCePaymentScheduleMap);
				}
			}
		}

		addSameDateRepayments(dateAndpaymentScheduleMap, paymentScheduleList);
		setOutstandingComponents(paymentScheduleList, totalAssetCost);
		convertIBPaymentSchToCEPaymentSch(dateAndCePaymentScheduleMap);
		if (!isF_IN_isReschedule() && null == poAssetDisbursementDtls) {
			CeUtils.persistSchedule(paymentScheduleList, dealDetails.getBoID());
		}
		if (paymentScheduleList != null && !paymentScheduleList.isEmpty()) {
			if (isF_IN_isReschedule()) {
				firstPaymentDate = dealDetails.getF_FirstRepaymentDate();
			} else {
				firstPaymentDate = paymentScheduleList.get(0).getRepaymentDate();
			}
			lastPaymentDate = paymentScheduleList.get(paymentScheduleList.size() - 1).getRepaymentDate();
			noOfPayments = paymentScheduleList.size();
		}
	}

	private int getNoOfScheduleHistoryRecords() {
		StringBuffer queryCondition = new StringBuffer(" WHERE " + IBOCE_IB_PaymentScheduleHistory.IBRESCHEDULEID
				+ "= ? AND " + IBOCE_IB_PaymentScheduleHistory.IBDEALID + "= ? ");
		ArrayList<String> params = new ArrayList<String>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_PaymentScheduleHistory> existingHistoryData = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentScheduleHistory.BONAME, queryCondition.toString(), params, null, true);
		int noOfRecordsDeleted = null != existingHistoryData ? existingHistoryData.size() : 0;
		return noOfRecordsDeleted;
	}

	private void generateHistoryScheduleForAllAssets(AssetThirdPartyDtlsList assetThirdPartyDtlsList,
			Map<Date, ArrayList<PaymentSchedule>> dateAndpaymentScheduleMap,
			Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap) {
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		isgenerateforAllassets = true;
		for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
			String assetId = assetBasicDtls.getAssetId();
			BigDecimal assetCost = new BigDecimal(0);
			for (AssetThirdPartyDtls assetThirdPartyDtls : assetThirdPartyDtlsList.getAssetThirdPartyDtls()) {
				if (assetThirdPartyDtls.getAssetID().equals(assetId)) {
					assetCost = assetCost
							.add(assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().getCurrencyAmount());
					totalAssetCost = totalAssetCost.add(assetCost);
				}
			}
			generatePrincipalProfitComponents(assetId, assetCost, dateAndpaymentScheduleMap,
					dateAndCePaymentScheduleMap);
			assetIdAndpaymentScheduleMap = new HashMap<>();
			dateAndpaymentScheduleMap = new HashMap<>();
			dateAndCePaymentScheduleMap = new HashMap();
		}
		assetProfileDetails = new AssetProfileDetails();
		totalProfitAmount = BigDecimal.ZERO;
		isgenerateforAllassets = false;
	}

	private List<IBOCE_IB_IssuePODetail> getIssuePODetails(PoAssetDisbursementDetails poDetails) {
		String getIssuePoDetailsByPoId = " WHERE "+IBOCE_IB_IssuePODetail.IBDEALID+" = ? and "+IBOCE_IB_IssuePODetail.IBPURCHASEORDERID +"=?";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		params.add(poDetails.getPurchaseOrderID());
		List<IBOCE_IB_IssuePODetail> issuePODetailListDB = BankFusionThreadLocal
				.getPersistanceFactory().findByQuery(IBOCE_IB_IssuePODetail.BONAME, getIssuePoDetailsByPoId, params, null, true);
		return issuePODetailListDB;
	}

	private void generateAndPersistScheduleForIssuePOAmt(
			Map<Date, ArrayList<PaymentSchedule>> dateAndpaymentScheduleMap,
			Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap, String assetId, BigDecimal assetCost) {
		futureAssetPaymentDates = new ArrayList<Date>();
		if(dealReschedule!=null) {
			prepareAssetFuturePaymentsDatesAfterReschedule();
		}else {
			prepareAssetFuturePaymentsDates(assetId);
		}
		
		setF_IN_noOfInstallments(futureAssetPaymentDates.size());
		generatePrincipalProfitComponents(assetId, assetCost, dateAndpaymentScheduleMap, dateAndCePaymentScheduleMap);
		ArrayList<PaymentSchedule> assetPaymentScheduleList = new ArrayList<>();
		addSameDateRepayments(dateAndpaymentScheduleMap, assetPaymentScheduleList);
	}
	
	private void prepareAssetFuturePaymentsDatesAfterReschedule() {
		for(LoanPayments loanPayment: readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
			if(!CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
					loanPayment.getRepaymentDate())) {
				futureAssetPaymentDates.add(loanPayment.getRepaymentDate());
			}
		}
		
	}

	private void convertIBPaymentSchToCEPaymentSch(
			Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap) {
		PaymentScheduleDetails paymentScheduleDetails = new PaymentScheduleDetails();
		CePaymentSchedule[] vCePaymentScheduleArray = new CePaymentSchedule[dateAndCePaymentScheduleMap.size()];
		RescheduleUtils.addSameDateRepayments(dateAndCePaymentScheduleMap, vCePaymentScheduleArray, currencyCode);
		paymentScheduleDetails.setCePaymentSchedule(vCePaymentScheduleArray);
		setF_OUT_paymentScheduleList(paymentScheduleDetails);
	}

	private void setOutstandingComponents(ArrayList<PaymentSchedule> paymentScheduleList, BigDecimal totalAssetCost) {
		LOGGER.info("Setting the outstanding components in the schedule");
		boolean isMultipleDisbursement = false;
		int repaymentNum = 1;
		if (drawDownAndDownPaymentDetails.getDrawdownDetailsCount() > 1)
			isMultipleDisbursement = true;
		if (paymentScheduleList != null && !paymentScheduleList.isEmpty()) {
			BigDecimal outstandingPrincipleAmnt = BigDecimal.ZERO;
			if (isF_IN_generateScheduleForDisbursedAssets() || null != poAssetDisbursementDtls) {
				outstandingPrincipleAmnt = totalAssetCost;
			} else {
				outstandingPrincipleAmnt = dealPrincipalAmnt.getCurrencyAmount();
			}
			BigDecimal outstandingProfitCost = dealPrincipalAmnt.getCurrencyAmount();
			Date fromDate = getF_IN_dealEffectiveDate();
			Date toDate = null;
			BigDecimal originalOustandingPrincipal = BigDecimal.ZERO;
			BigDecimal totalRepaymentAmount;
			for (int i = 0; i < paymentScheduleList.size(); i++) {
				totalRepaymentAmount = BigDecimal.ZERO;
				if (i == paymentScheduleList.size() - 1) {
					paymentScheduleList.get(i).setOutstandingPrincipalAmt(CeUtils.getZeroAmount(currencyCode));
					paymentScheduleList.get(i).setOutstandingProfitCost(CeUtils.getZeroAmount(currencyCode));
					paymentScheduleList.get(i)
							.setPrincipleAmt(IBCommonUtils.getBFCurrencyAmount(outstandingPrincipleAmnt, currencyCode));
				} else {

					if (isMultipleDisbursement) {
						fromDate = IBCommonUtils.getCalendarServiceDate(fromDate).withoutTimeParts().toSQLDate();
						toDate = IBCommonUtils.getCalendarServiceDate(paymentScheduleList.get(i).getRepaymentDate())
								.withoutTimeParts().toSQLDate();
						List<LoanScheduleDtls> oustandingBalanceList = ScheduleUtils.getPeriodOustandingPrincipalList(
								fromDate, toDate, Arrays.asList(drawDownAndDownPaymentDetails.getDrawdownDetails()),
								originalOustandingPrincipal, i == 0 ? true : false);
						BigDecimal profitCost = BigDecimal.ZERO;
						if (null != oustandingBalanceList && !oustandingBalanceList.isEmpty()
								&& oustandingBalanceList.size() > 0) {
							profitCost = profitCost.add(oustandingBalanceList.get(oustandingBalanceList.size() - 1)
									.getOutstandingPrincipal().getAmount());
						}
						outstandingPrincipleAmnt = profitCost;
						fromDate = paymentScheduleList.get(i).getRepaymentDate();
					}
					paymentScheduleList.get(i)
							.setOutstandingPrincipalAmt(IBCommonUtils.getBFCurrencyAmount(
									outstandingPrincipleAmnt
											.subtract(paymentScheduleList.get(i).getPrincipleAmt().getCurrencyAmount()),
									currencyCode));
					paymentScheduleList.get(i)
							.setOutstandingProfitCost(IBCommonUtils.getBFCurrencyAmount(
									outstandingProfitCost
											.subtract(paymentScheduleList.get(i).getPrincipleAmt().getCurrencyAmount()),
									currencyCode));
				}
				outstandingPrincipleAmnt = outstandingPrincipleAmnt
						.subtract(paymentScheduleList.get(i).getPrincipleAmt().getCurrencyAmount());
				outstandingProfitCost = outstandingProfitCost
						.subtract(paymentScheduleList.get(i).getPrincipleAmt().getCurrencyAmount());
				originalOustandingPrincipal = outstandingPrincipleAmnt;
				paymentScheduleList.get(i).setInstallmentProfitAmt(paymentScheduleList.get(i).getProfitAmt());
				totalRepaymentAmount = paymentScheduleList.get(i).getPrincipleAmt().getCurrencyAmount()
						.add(paymentScheduleList.get(i).getProfitAmt().getCurrencyAmount())
						.add(paymentScheduleList.get(i).getFeeAmt().getCurrencyAmount());

				paymentScheduleList.get(i)
						.setRepaymentAmt(IBCommonUtils.getBFCurrencyAmount(totalRepaymentAmount, currencyCode));
				paymentScheduleList.get(i).setRepaymentNo(repaymentNum);
				++repaymentNum;
			}
		}

	}

	private void addSameDateRepayments(Map<Date, ArrayList<PaymentSchedule>> dateAndpaymentScheduleMap,
			ArrayList<PaymentSchedule> paymentScheduleList) {
		LOGGER.info("Adding amounts of same date repayments");
		Iterator<Entry<Date, ArrayList<PaymentSchedule>>> iterator = dateAndpaymentScheduleMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<Date, ArrayList<PaymentSchedule>> entry = iterator.next();
			BigDecimal totalPrincipalRepaymentAmount = BigDecimal.ZERO;
			BigDecimal totalProfitRepaymentAmount = BigDecimal.ZERO;
			BigDecimal totalFeesRepaymentAmount = BigDecimal.ZERO;
			for (PaymentSchedule paymentSchedule : entry.getValue()) {
				totalPrincipalRepaymentAmount = totalPrincipalRepaymentAmount
						.add(paymentSchedule.getPrincipleAmt().getCurrencyAmount());
				totalProfitRepaymentAmount = totalProfitRepaymentAmount
						.add(paymentSchedule.getProfitAmt().getCurrencyAmount());
				totalFeesRepaymentAmount = totalFeesRepaymentAmount
						.add(paymentSchedule.getFeeAmt().getCurrencyAmount());
			}
			PaymentSchedule paymentSchedule = new PaymentSchedule();
			paymentSchedule.setRepaymentDate(entry.getKey());
			paymentSchedule.setCarryoverProfitAmt(CeUtils.getZeroAmount(currencyCode));
			paymentSchedule.setFeeAmt(CeUtils.getZeroAmount(currencyCode));
			paymentSchedule.setIsInstructionApplied(false);
			paymentSchedule.setProfitRate(profitRate);
			paymentSchedule.setRepaymentType(DealInitiationConstants.DEALINIT_CONST_REPAYMENT);
			paymentSchedule.setStatus(IBConstants.REPAYMENT_STATUS_UNPAID);
			paymentSchedule.setStatusDesc(
					IBCommonUtils.getGCChildDesc("IBINSTALLMENTSTATUS", IBConstants.REPAYMENT_STATUS_UNPAID));
			paymentSchedule
					.setPrincipleAmt(IBCommonUtils.getBFCurrencyAmount(totalPrincipalRepaymentAmount, currencyCode));
			paymentSchedule.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(totalProfitRepaymentAmount, currencyCode));
			paymentSchedule.setFeeAmt(IBCommonUtils.getBFCurrencyAmount(totalFeesRepaymentAmount, currencyCode));
			paymentSchedule.setInstallmentProfitAmt(paymentSchedule.getProfitAmt());
			paymentScheduleList.add(paymentSchedule);
		}
		com.ce.bankfusion.ib.util.ScheduleUtils.sortPaymentSchedule(paymentScheduleList);
	}

	private void generatePrincipalProfitComponents(String assetId, BigDecimal assetCost,
			Map<Date, ArrayList<PaymentSchedule>> dateAndpaymentScheduleMap,
			Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap) {
		LOGGER.info("Generating principal, profit, fees amounts for the schedule");
		BigDecimal assetTotalSubsidyAmount = BigDecimal.ZERO;
		String assetSubsidyPercentage = CeUtils.getAssetSubsidyPercentage(readAssetData, assetId);
		if (assetSubsidyPercentage.equals(CommonConstants.EMPTY_STRING)
				||(null != dealReschedule && !dealReschedule.isF_IBINCLUDESUBSIDY())) {
			assetSubsidyPercentage = "0.00";
		}

		BigDecimal assetTenor = BigDecimal.ZERO;
		if (getF_IN_noOfInstallments() > 0) {
			assetTenor = new BigDecimal(getF_IN_noOfInstallments());
		} else {
			assetTenor = new BigDecimal(CeUtils.getAssetTenor(readAssetData, assetId));
		}

		BigDecimal totalAssetProfitAmount = getTotalAssetProfitAmount(assetId, assetCost);
		BigDecimal assetScheudleFeesAmount = getAssetScheduleFeesAmount();
		BigDecimal assetRepaymentProfitAmount = totalAssetProfitAmount.divide(assetTenor, 0, RoundingMode.FLOOR);
		BigDecimal assetRepaymentPrincipalAmount = assetCost.divide(assetTenor, 0, RoundingMode.FLOOR);
		BigDecimal assetRepaymentFeesAmount = assetScheudleFeesAmount.divide(assetTenor, 0, RoundingMode.FLOOR);

		BigDecimal firstRepaymentPrincipalAmount = assetCost
				.subtract(assetRepaymentPrincipalAmount.multiply(assetTenor.subtract(BigDecimal.ONE)));
		BigDecimal firstRepaymentProfitAmount = totalAssetProfitAmount
				.subtract(assetRepaymentProfitAmount.multiply(assetTenor.subtract(BigDecimal.ONE)));
		BigDecimal firstRepaymentFeesAmount = assetScheudleFeesAmount
				.subtract(assetRepaymentFeesAmount.multiply(assetTenor.subtract(BigDecimal.ONE)));

		Date paymentDateNWDApplied = null;
		Date assetScheduleStartDate = null;
		if (isF_IN_isReschedule()) {  // if already fully paid --> repayment date , payment frequency
			assetScheduleStartDate = new Date(IBCommonUtils
					.getNextPaymentDate(getF_IN_firstPaymentDate(), getF_IN_paymentFrequency(), -1, 1, 0, false, 0)
					.getTime());
		}
		else {
			assetScheduleStartDate = CeUtils.getScheduleStartDate(getF_IN_dealEffectiveDate(), "YEARLY",
					CeUtils.getDisbursementPeriodForAsset(readAssetData, assetId));
		}
		DrawdownDetails vDrawdownDetails = new DrawdownDetails();
		vDrawdownDetails.setDrawdownAmount(assetCost);
		vDrawdownDetails.setDrawdownDate(SubtractDaysFromDate.run(assetScheduleStartDate, 1));
		drawDownAndDownPaymentDetails.addDrawdownDetails(vDrawdownDetails);
		Date paymentDate = null;

		for (int i = 0; i < assetTenor.intValue(); i++) {
			if(null != poAssetDisbursementDtls && !isgenerateforAllassets && !futureAssetPaymentDates.isEmpty())
			{
				//issuePoAssetStartDate is the first future date to start the disbursement Distribution
				paymentDate = futureAssetPaymentDates.get(i);
			}
			else
			{
				paymentDate = new Date(IBCommonUtils
						.getNextPaymentDate(assetScheduleStartDate, getF_IN_paymentFrequency(), 1, i + 1, 0, false, 0)
						.getTime());
			}
			paymentDateNWDApplied = CalendarUtil.getWorkingDateBasedOnNWDAndStartDate(paymentDate,
					getF_IN_islamicBankingObject().getDealID(), paymentDate, true);

			PaymentSchedule paymentSchedule = new PaymentSchedule();
			paymentSchedule.setRepaymentDate(paymentDateNWDApplied);
			if (i != 0) {
				paymentSchedule.setPrincipleAmt(
						IBCommonUtils.getBFCurrencyAmount(assetRepaymentPrincipalAmount, currencyCode));
				paymentSchedule
						.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(assetRepaymentProfitAmount, currencyCode));
				paymentSchedule.setFeeAmt(IBCommonUtils.getBFCurrencyAmount(assetRepaymentFeesAmount, currencyCode));
			} else {
				paymentSchedule.setPrincipleAmt(
						IBCommonUtils.getBFCurrencyAmount(firstRepaymentPrincipalAmount, currencyCode));
				paymentSchedule
						.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(firstRepaymentProfitAmount, currencyCode));
				paymentSchedule.setFeeAmt(IBCommonUtils.getBFCurrencyAmount(firstRepaymentFeesAmount, currencyCode));
			}
			paymentSchedule.setInstallmentProfitAmt(paymentSchedule.getProfitAmt());
			if (dateAndpaymentScheduleMap.containsKey(paymentDateNWDApplied)) {
				dateAndpaymentScheduleMap.get(paymentDateNWDApplied).add(paymentSchedule);
			} else {
				ArrayList<PaymentSchedule> paymentSchedules = new ArrayList<>();
				paymentSchedules.add(paymentSchedule);
				dateAndpaymentScheduleMap.put(paymentDateNWDApplied, paymentSchedules);
			}

			if ((null == readLoanDetailsRs || BigDecimal.ZERO.compareTo(
					readLoanDetailsRs.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount()) == 0)
					&& !isgenerateforAllassets) {
				com.ce.bankfusion.ib.util.ScheduleUtils.persistPaymentScheduleBreakup(
						getF_IN_islamicBankingObject().getDealID(), assetId, readAssetData, paymentSchedule,
						isF_IN_isIncludeSubsidy());
			} else if (null != poAssetDisbursementDtls && !isgenerateforAllassets) {
				IBOCE_IB_PaymentSchBreakup paymentSchBreakup = RescheduleUtils
						.persistFutureInstallmentsInBreakUpByAssetId(paymentSchedule, assetId,
								getF_IN_islamicBankingObject().getDealID(), isF_IN_isIncludeSubsidy(), readAssetData);
				paymentSchedule.getPrincipleAmt().setCurrencyAmount(paymentSchBreakup.getF_IBPRINCIPALAMT());
				paymentSchedule.getProfitAmt().setCurrencyAmount(paymentSchBreakup.getF_IBPRINCIPALAMT());
				paymentSchedule.getFeeAmt().setCurrencyAmount(paymentSchBreakup.getF_IBPRINCIPALAMT());
			}
			if (IBCommonUtils.isNullOrEmpty(dealDetails.getF_DealAccountId()) || isgenerateforAllassets) {
				com.ce.bankfusion.ib.util.ScheduleUtils.persistPaymentScheduleBreakupHistoryTable(
						getF_IN_islamicBankingObject().getDealID(), assetId, readAssetData, paymentSchedule,
						isF_IN_isIncludeSubsidy());
			}

			assetTotalSubsidyAmount = addAssetBasedPaymentScheduleObj(paymentSchedule, assetId, assetSubsidyPercentage,
					assetTotalSubsidyAmount, dateAndCePaymentScheduleMap);

			if (i == assetTenor.intValue()-1) {
				assetIdAndpaymentScheduleMap.put(assetId, paymentSchedule);
			}
		}

		scheduleStartDate = scheduleStartDate.compareTo(assetScheduleStartDate) > 0 ? assetScheduleStartDate
				: scheduleStartDate;

		BigDecimal totalAssetRepaymentAmount = assetRepaymentProfitAmount.add(assetRepaymentPrincipalAmount)
				.add(assetRepaymentFeesAmount);

		// adding asset profile
		CeAssetProfile assetProfile = new CeAssetProfile();
		assetProfile.setAssetId(assetId);
		assetProfile.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(assetScheudleFeesAmount, currencyCode));
		assetProfile.setScheduleFeesAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetProfile.setTotalPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(assetCost, currencyCode));
		assetProfile.setTotalPrincipalAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetProfile.setTotalProfitAmount(IBCommonUtils.getBFCurrencyAmount(totalAssetProfitAmount, currencyCode));
		assetProfile.setTotalProfitAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetProfile.setTotalSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(assetTotalSubsidyAmount, currencyCode));
		assetProfile.setTotalSubsidyAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetProfile
				.setAssetRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(totalAssetRepaymentAmount, currencyCode));
		assetProfileDetails.addAssetProfileList(assetProfile);

	}

	private BigDecimal addAssetBasedPaymentScheduleObj(PaymentSchedule paymentSchedule, String assetId,
			String assetSubsidyPercentage, BigDecimal assetTotalSubsidyAmount,
			Map<Date, ArrayList<CePaymentSchedule>> dateAndCePaymentScheduleMap) {
		AssetBasedPaymentSchedule assetBasedPaymentSchedule = new AssetBasedPaymentSchedule();
		assetBasedPaymentSchedule.setAssetId(assetId);
		assetBasedPaymentSchedule.setPrincipalAmount(paymentSchedule.getPrincipleAmt());
		assetBasedPaymentSchedule.setPrincipalAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetBasedPaymentSchedule.setProfitAmount(paymentSchedule.getProfitAmt());
		assetBasedPaymentSchedule.setProfitAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetBasedPaymentSchedule.setRepaymentDate(paymentSchedule.getRepaymentDate());
		assetBasedPaymentSchedule.setScheduleFeesAmount(paymentSchedule.getFeeAmt());
		assetBasedPaymentSchedule.setScheduleFeesAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetBasedPaymentSchedule.setSubsidyAmount(CeUtils.getZeroAmount(currencyCode));
		if (isF_IN_isIncludeSubsidy()) {
			BigDecimal subsidyAmount = (paymentSchedule.getPrincipleAmt().getCurrencyAmount()
					.multiply(new BigDecimal(assetSubsidyPercentage)))
							.divide(com.ce.bankfusion.ib.util.ScheduleUtils.hundred, 0, RoundingMode.FLOOR);
			assetBasedPaymentSchedule.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(subsidyAmount, currencyCode));
		}
		assetBasedPaymentSchedule.setSubsidyAmountPaid(CeUtils.getZeroAmount(currencyCode));
		assetBasedPaymentSchedule.setTotalRepaymentAmount(paymentSchedule.getRepaymentAmt());
		assetProfileDetails.addAssetBasedPaymentSchedule(assetBasedPaymentSchedule);
		assetTotalSubsidyAmount = assetTotalSubsidyAmount
				.add(assetBasedPaymentSchedule.getSubsidyAmount().getCurrencyAmount());

		CePaymentSchedule vCurrentSchedule = new CePaymentSchedule();
		vCurrentSchedule.setFeesAmount(paymentSchedule.getFeeAmt());
		vCurrentSchedule.setPrincipalAmount(paymentSchedule.getPrincipleAmt());
		vCurrentSchedule.setProfitAmount(paymentSchedule.getProfitAmt());
		vCurrentSchedule.setRepaymentDate(paymentSchedule.getRepaymentDate());
		vCurrentSchedule.setSubsidyAmount(assetBasedPaymentSchedule.getSubsidyAmount());
		if (dateAndCePaymentScheduleMap.containsKey(vCurrentSchedule.getRepaymentDate())) {
			dateAndCePaymentScheduleMap.get(vCurrentSchedule.getRepaymentDate()).add(vCurrentSchedule);
		} else {
			ArrayList<CePaymentSchedule> paymentSchedules = new ArrayList<>();
			paymentSchedules.add(vCurrentSchedule);
			dateAndCePaymentScheduleMap.put(vCurrentSchedule.getRepaymentDate(), paymentSchedules);
		}
		return assetTotalSubsidyAmount;
	}

	private BigDecimal getAssetScheduleFeesAmount() {
		// Total schedule fees is divided equally among each asset
		BigDecimal assetScheduleFeesAmount = BigDecimal.ZERO;
		if (noOfAssetsForSchGen > 0 && totalScheduleFeesAmount != null
				&& totalScheduleFeesAmount.compareTo(BigDecimal.ZERO) > 0) {
			if (noOfAssetsForSchGen == 1)
				return totalScheduleFeesAmount;
			assetScheduleFeesAmount = totalScheduleFeesAmount
					.divide(new BigDecimal(noOfAssetsForSchGen), 0, RoundingMode.UP);
			--noOfAssetsForSchGen;
			totalScheduleFeesAmount = totalScheduleFeesAmount.subtract(assetScheduleFeesAmount);
		}
		return assetScheduleFeesAmount;
	}

	private BigDecimal getTotalAssetProfitAmount(String assetId, BigDecimal assetCost) {
		// In case of reschedule, there is no profit recalculation, schedule generation
		// happens on outstanding profit
		BigDecimal totalAssetProfitAmount;
		if (isF_IN_isReschedule()) {
			totalAssetProfitAmount = com.ce.bankfusion.ib.util.ScheduleUtils.getAssetOutstandingProfitAmount(
					readLoanDetailsRs, getF_IN_islamicBankingObject().getDealID(), assetId);
		} else {
			BFCurrencyAmount assetCostBFCurr = new BFCurrencyAmount();
			assetCostBFCurr.setCurrencyAmount(assetCost);
			assetCostBFCurr.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());

			HashMap<String, BigDecimal> profitAmountAndProfitRate = com.ce.bankfusion.ib.util.ScheduleUtils
					.getAssetProfitAmount(getF_IN_dealEffectiveDate(), assetId, getF_IN_paymentFrequency(),
							getF_IN_profitMethod(), getF_IN_pricingMethod(), getF_IN_islamicBankingObject(),
							assetCostBFCurr, readAssetData);
			BigDecimal scheduledProfitPercentage = BigDecimal.ZERO;

			totalAssetProfitAmount = IBCommonUtils.scaleAmount(currencyCode,profitAmountAndProfitRate.get("profitAmount"));
			profitRate = profitAmountAndProfitRate.get("profitRate");

			if (getF_IN_upfrontProfitPercentage() != null
					&& getF_IN_upfrontProfitPercentage().compareTo(BigDecimal.ZERO) > 0) {
				scheduledProfitPercentage = new BigDecimal(100).subtract(getF_IN_upfrontProfitPercentage());
			}
			if (scheduledProfitPercentage.compareTo(BigDecimal.ZERO) > 0) {
				totalAssetProfitAmount = IBCommonUtils.scaleAmount(currencyCode,(totalAssetProfitAmount.multiply(scheduledProfitPercentage))
						.divide(new BigDecimal(100)));
			}
		}
		totalProfitAmount = totalProfitAmount.add(totalAssetProfitAmount);
		return totalAssetProfitAmount;
	}

	private void validateDealEffectiveDate() {
		if (!CalendarUtil.isDateNullOrDefaultDate(getF_IN_dealEffectiveDate())) {
			isDealEffDateLessThanStartDate = com.ce.bankfusion.ib.util.ScheduleUtils
					.validateDealEffDateLessThanStartDate(getF_IN_dealEffectiveDate(),
							dealDetails.getF_DealStartDate());
			isDealEffDateNWD = com.ce.bankfusion.ib.util.ScheduleUtils
					.validateDealEffDateIfNWD(getF_IN_dealEffectiveDate(), dealDetails.getBoID());
			if (isDealEffDateLessThanStartDate) {
				LOGGER.info("ERROR: Deal effective date is less than deal start date");
				setF_OUT_raiseDealStartDateLessThanEvent(true);
				setF_OUT_eventCodeMsg(CeUtils
						.getEventCodeMsg(String.valueOf(CeConstants.E_EFF_DATE_NOT_LESSTHAN_DEALSTARTDATE_CEIB)));
			} else if (isDealEffDateNWD) {
				LOGGER.info("ERROR: Deal Effective date is a nonworking day");
				setF_OUT_raiseNWDEvent(true);
				setF_OUT_eventCodeMsg(
						CeUtils.getEventCodeMsg(String.valueOf(CeConstants.E_DEAL_EFF_DATE_CANNOT_BE_NWD_CEIB)));
			}
		}
		if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API)) {
			if (isDealEffDateLessThanStartDate)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_EFF_DATE_NOT_LESSTHAN_DEALSTARTDATE_CEIB);
			if (isDealEffDateNWD)
				IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_EFF_DATE_CANNOT_BE_NWD_CEIB);
		}
	}

	private void validateUpfrontProfitPercentage() {
		if (getF_IN_upfrontProfitPercentage() != null
				&& (BigDecimal.ZERO.compareTo(getF_IN_upfrontProfitPercentage()) > 0
						|| new BigDecimal(100).compareTo(getF_IN_upfrontProfitPercentage()) < 0)) {
			LOGGER.info("ERROR: Upfront profit percentage is either lessthan zero or greather than hundred");
			isPercentageNeg = true;
			setF_OUT_raisePercentageError(true);
			setF_OUT_eventCodeMsg(CeUtils.getEventCodeMsg(String.valueOf(CeConstants.E_PERCENTAGE_CANNOT_BE_NEG_CEIB)));
		}
		if (getF_IN_islamicBankingObject().getChannel().equals(ApiCommonUtils.CHANNEL_API) && isPercentageNeg)
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_PERCENTAGE_CANNOT_BE_NEG_CEIB);

	}
	private void generatePostponeSchedule() {
		String fullyPaidStatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_FULLY_PAID);
		String arrearStatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_ARREAR);
		String partiallyPaidSatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_PARTIAL_PAID);
		Date currentLastPaidDate = getF_IN_dealRescheduleDetails().getCurrentSchedule(getF_IN_dealRescheduleDetails().getCurrentScheduleCount()-1).getRepaymentDate();
		List<CePaymentSchedule> newScheduleList = new ArrayList<>();
		Map<Date, CePaymentSchedule> datesMap = new HashMap<>();
		for(CePostPonePaymentSchedule postponeSchedule : getF_IN_dealRescheduleDetails().getPostPonePaymentSchedule()) {
			if(postponeSchedule.getStatus().equals(fullyPaidStatusDesc) && postponeSchedule.getRepaymentNewDate()!=null) {
				IBCommonUtils.raiseUnparameterizedEvent(44000810);
			}
			if(postponeSchedule.getStatus().equals(fullyPaidStatusDesc)) {
				continue;
			}
			if(postponeSchedule.getRepaymentNewDate()!=null && CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), postponeSchedule.getRepaymentNewDate())) {
				IBCommonUtils.raiseUnparameterizedEvent(44000812);
			}
			if(postponeSchedule.getRepaymentNewDate()!=null && CalendarUtil.IsDate1GreaterThanDate2(postponeSchedule.getRepaymentNewDate(), currentLastPaidDate)) {
				IBCommonUtils.raiseUnparameterizedEvent(44000811);
			}
			if((postponeSchedule.getStatus().equals(arrearStatusDesc) || postponeSchedule.getStatus().equals(partiallyPaidSatusDesc)) && postponeSchedule.getRepaymentNewDate()==null) {
				IBCommonUtils.raiseUnparameterizedEvent(E_ARREAR_SHOULD_BE_MOVED);
			}
			boolean isArrear = false;
			if((postponeSchedule.getStatus().equals(arrearStatusDesc) || postponeSchedule.getStatus().equals(partiallyPaidSatusDesc)) && postponeSchedule.getRepaymentNewDate()!=null) {
				for(LoanPayments loanPayment : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
					if(loanPayment.getRepaymentDate().equals(postponeSchedule.getRepaymentOldDate()) &&(
							loanPayment.getFeeAmtPaid().compareTo(BigDecimal.ZERO)>0 ||
							loanPayment.getProfitAmtPaid().compareTo(BigDecimal.ZERO)>0 || 
							loanPayment.getPrincipalAmtPaid().compareTo(BigDecimal.ZERO)>0)) {
						addAdjustedArrearPaymentPostPone(postponeSchedule, loanPayment, newScheduleList);
						isArrear = true;
					}
				}
			}
			if(isArrear) {
				continue;
			}
			CePaymentSchedule cps = new CePaymentSchedule();
			cps.setFeesAmount(postponeSchedule.getFeesAmount());
			cps.setPrincipalAmount(postponeSchedule.getPrincipalAmount());
			cps.setProfitAmount(postponeSchedule.getProfitAmount());
			cps.setRepaymentDate(postponeSchedule.getRepaymentNewDate()==null?postponeSchedule.getRepaymentOldDate() : postponeSchedule.getRepaymentNewDate());
			cps.setStatus(postponeSchedule.getStatus());
			BFCurrencyAmount amount = new BFCurrencyAmount();
			amount.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
			amount.setCurrencyAmount(postponeSchedule.getIsIncludeSubsidy()? postponeSchedule.getSubsidyAmount().getCurrencyAmount():BigDecimal.ZERO);
			cps.setSubsidyAmount(amount);
			cps.setTotalRepaymentAmount(postponeSchedule.getTotalRepaymentAmount());
			newScheduleList.add(cps);
		}
		for(CePaymentSchedule ps : newScheduleList) {
			if(datesMap.containsKey(ps.getRepaymentDate())) {
				CePaymentSchedule ps1 = datesMap.get(ps.getRepaymentDate());
				BFCurrencyAmount totalAmount = ps1.getTotalRepaymentAmount();
				BFCurrencyAmount profitAmount = ps1.getProfitAmount();
				BFCurrencyAmount subsidyAmount = ps1.getSubsidyAmount();
				BFCurrencyAmount feeAmount = ps1.getFeesAmount();
				BFCurrencyAmount principalAmount = ps1.getPrincipalAmount();
				BigDecimal princ = ps1.getPrincipalAmount().getCurrencyAmount().add(ps.getPrincipalAmount().getCurrencyAmount());
				BigDecimal fe = ps1.getFeesAmount().getCurrencyAmount().add(ps.getFeesAmount().getCurrencyAmount());
				BigDecimal prft = ps1.getProfitAmount().getCurrencyAmount().add(ps.getProfitAmount().getCurrencyAmount());
				BigDecimal sbsid = ps1.getSubsidyAmount().getCurrencyAmount().add(ps.getSubsidyAmount().getCurrencyAmount());
				BigDecimal total = ps1.getTotalRepaymentAmount().getCurrencyAmount().add(ps.getTotalRepaymentAmount().getCurrencyAmount());
				totalAmount.setCurrencyAmount(total);
				profitAmount.setCurrencyAmount(prft);
				subsidyAmount.setCurrencyAmount(sbsid);
				feeAmount.setCurrencyAmount(fe);
				principalAmount.setCurrencyAmount(princ);
				ps1.setFeesAmount(feeAmount);
				ps1.setPrincipalAmount(principalAmount);
				ps1.setProfitAmount(profitAmount);
				ps1.setSubsidyAmount(subsidyAmount);
				ps1.setTotalRepaymentAmount(totalAmount);
			}else {
				datesMap.put(ps.getRepaymentDate(), ps);
			}
		}
		newScheduleList.clear();
		for(Entry<Date, CePaymentSchedule> entry : datesMap.entrySet()) {
			newScheduleList.add(entry.getValue());
		}
		newScheduleList.sort(new Comparator<CePaymentSchedule>() {
				@Override
				public int compare(CePaymentSchedule o1, CePaymentSchedule o2) {
					return o1.getRepaymentDate().compareTo(o2.getRepaymentDate());
				}
			});
		BigDecimal schFee = getF_IN_scheduleFees().getCurrencyAmount();
		if(schFee == null) {
			schFee = BigDecimal.ZERO;
		}
		BigDecimal newScheduleFee = schFee.setScale(0, RoundingMode.UP);
		BigDecimal repayFee = newScheduleFee.divide(new BigDecimal(newScheduleList.size()), BigDecimal.ROUND_DOWN);
		repayFee = repayFee.setScale(0, RoundingMode.UP);
		int i = 1;
		PaymentScheduleDetails psl = new PaymentScheduleDetails();
		for(CePaymentSchedule cps : newScheduleList) {
			cps.setRepaymentNo(i++);
			BFCurrencyAmount feeCAmt = cps.getFeesAmount();
			feeCAmt.setCurrencyAmount(feeCAmt.getCurrencyAmount().add(repayFee));
			cps.setFeesAmount(feeCAmt);
			BFCurrencyAmount totalAmt = cps.getTotalRepaymentAmount();
			totalAmt.setCurrencyAmount(totalAmt.getCurrencyAmount().add(repayFee));
			cps.setTotalRepaymentAmount(totalAmt);
			psl.addCePaymentSchedule(cps);
		}
		
		setF_OUT_paymentScheduleList(psl);
		
	}
	
	private void addAdjustedArrearPaymentPostPone(CePostPonePaymentSchedule postponeSchedule, LoanPayments loanPayment,
			List<CePaymentSchedule> newScheduleList) {
		String unPaidSatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_UNPAID);
		BigDecimal feePaid = loanPayment.getFeeAmtPaid();
		BigDecimal profitPaid = loanPayment.getProfitAmtPaid();
		BigDecimal principalPaid = loanPayment.getPrincipalAmtPaid();
		
		//moving the remaining paid to future
		CePaymentSchedule cps = new CePaymentSchedule();
		BFCurrencyAmount fee = postponeSchedule.getFeesAmount();
		fee.setCurrencyAmount(fee.getCurrencyAmount().subtract(feePaid));
		BFCurrencyAmount profit = postponeSchedule.getProfitAmount();
		profit.setCurrencyAmount(profit.getCurrencyAmount().subtract(profitPaid));
		BFCurrencyAmount principal = postponeSchedule.getPrincipalAmount();
		principal.setCurrencyAmount(principal.getCurrencyAmount().subtract(principalPaid));
		cps.setFeesAmount(fee);
		cps.setPrincipalAmount(principal);
		cps.setProfitAmount(profit);
		cps.setRepaymentDate(postponeSchedule.getRepaymentNewDate());
		cps.setStatus(unPaidSatusDesc);
		BFCurrencyAmount amount = new BFCurrencyAmount();
		amount.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
		amount.setCurrencyAmount(postponeSchedule.getIsIncludeSubsidy()? postponeSchedule.getSubsidyAmount().getCurrencyAmount():BigDecimal.ZERO);
		cps.setSubsidyAmount(amount);
		cps.setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(principal.getCurrencyAmount().add(profit.getCurrencyAmount()).add(fee.getCurrencyAmount()), dealDetails.getF_IsoCurrencyCode()));
		newScheduleList.add(cps);
		
		/*//making the arrear repayment with only paid
		CePaymentSchedule cps1 = new CePaymentSchedule();
		cps1.setFeesAmount(IBCommonUtils.getBFCurrencyAmount( feePaid , dealDetails.getF_IsoCurrencyCode()));
		cps1.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount( principalPaid , dealDetails.getF_IsoCurrencyCode()));
		cps1.setProfitAmount(IBCommonUtils.getBFCurrencyAmount( profitPaid , dealDetails.getF_IsoCurrencyCode()));
		cps1.setRepaymentDate(postponeSchedule.getRepaymentOldDate());
		cps1.setStatus(postponeSchedule.getStatus());
		cps1.setSubsidyAmount(amount);
		cps1.setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(cps1.getPrincipalAmount().getCurrencyAmount().add(cps1.getProfitAmount().getCurrencyAmount()).add(cps1.getFeesAmount().getCurrencyAmount()), dealDetails.getF_IsoCurrencyCode()));
		newScheduleList.add(cps);*/
		
	}

	private void generateDistributeSchedule() {
		String fullyPaidStatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_FULLY_PAID);
		String arrearStatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_ARREAR);
		String partiallyPaidSatusDesc = IBCommonUtils.getGCChildDesc(CeConstants.IBINSTALLMENTSTATUS_REFERENCE, CeConstants.PAYMENT_STATUS_PARTIAL_PAID);
		int noOfDist = 0;
		BigDecimal skipTotalAmount = BigDecimal.ZERO;
		BigDecimal skipPrincipalAmount = BigDecimal.ZERO;
		BigDecimal skipFeeAmount = BigDecimal.ZERO;
		BigDecimal skipSubsidyAmount = BigDecimal.ZERO;
		BigDecimal skipProfitAmount = BigDecimal.ZERO;
		//Finding the skip repayments
		for(CeDistributePaymentSchedule dps : getF_IN_dealRescheduleDetails().getDistributePaymentSchedule()) {
			if((dps.getStatus().equals(arrearStatusDesc) || dps.getStatus().equals(partiallyPaidSatusDesc))  && !dps.isIsSkipRepayment()) {
				IBCommonUtils.raiseUnparameterizedEvent(E_ARREAR_SHOULD_BE_MOVED);
			}
			if(dps.isIsSkipRepayment()) {
				if(dps.getStatus().equals(fullyPaidStatusDesc)) {
					IBCommonUtils.raiseUnparameterizedEvent(44000810);
				}
				BigDecimal totalAmount = dps.getTotalRepaymentAmount().getCurrencyAmount();
				BigDecimal principleAmount = dps.getPrincipalAmount().getCurrencyAmount();
				BigDecimal feeAmount = dps.getFeesAmount().getCurrencyAmount();
				BigDecimal profitAmount = dps.getProfitAmount().getCurrencyAmount();
				if(dps.getStatus().equals(arrearStatusDesc)) {
					for(LoanPayments loanPayment : readLoanDetailsRs.getDealDetails().getPaymentSchedule()) {
						if(loanPayment.getRepaymentDate().equals(dps.getRepaymentDate()) &&(
								loanPayment.getFeeAmtPaid().compareTo(BigDecimal.ZERO)>0 ||
								loanPayment.getProfitAmtPaid().compareTo(BigDecimal.ZERO)>0 || 
								loanPayment.getPrincipalAmtPaid().compareTo(BigDecimal.ZERO)>0)) {
							principleAmount = principleAmount.subtract(loanPayment.getPrincipalAmtPaid());
							feeAmount = feeAmount.subtract(loanPayment.getFeeAmtPaid());
							profitAmount = profitAmount.subtract(loanPayment.getProfitAmtPaid());
							totalAmount = principleAmount.add(profitAmount).add(feeAmount);
						}
					}
				}
				skipTotalAmount = skipTotalAmount.add(totalAmount);
				skipPrincipalAmount = skipPrincipalAmount.add(principleAmount);
				skipFeeAmount = skipFeeAmount.add(feeAmount);
				skipProfitAmount = skipProfitAmount.add(profitAmount);
				if(isF_IN_distributeIsSubsidy()) {
					skipSubsidyAmount = skipSubsidyAmount.add(dps.getSubsidyAmount().getCurrencyAmount());
				}
			}
			if(dps.isIsDistribute())
				noOfDist++;
		}
		BigDecimal originalSkipPrincipleAmount = skipPrincipalAmount;
		BigDecimal originalSkipProfitAmount = skipProfitAmount;
		BigDecimal originalSkipFeeAmount = skipFeeAmount;
		BigDecimal originalSkipSubsidyAmount = skipSubsidyAmount;
		skipTotalAmount = skipTotalAmount.divide(new BigDecimal(noOfDist), BigDecimal.ROUND_DOWN).setScale(0, BigDecimal.ROUND_DOWN);
		skipPrincipalAmount = skipPrincipalAmount.divide(new BigDecimal(noOfDist), BigDecimal.ROUND_DOWN).setScale(0, BigDecimal.ROUND_DOWN);
		skipFeeAmount = skipFeeAmount.divide(new BigDecimal(noOfDist), BigDecimal.ROUND_DOWN).setScale(0, BigDecimal.ROUND_DOWN);
		skipSubsidyAmount = skipSubsidyAmount.divide(new BigDecimal(noOfDist), BigDecimal.ROUND_DOWN).setScale(0, BigDecimal.ROUND_DOWN);
		skipProfitAmount = skipProfitAmount.divide(new BigDecimal(noOfDist), BigDecimal.ROUND_DOWN).setScale(0, BigDecimal.ROUND_DOWN);
		List<CePaymentSchedule> newScheduleList = new ArrayList<>();
		//adding the skip amounts to distribute selected payments
		for(CeDistributePaymentSchedule dps : getF_IN_dealRescheduleDetails().getDistributePaymentSchedule()) {
			if(dps.getStatus().equals(fullyPaidStatusDesc)) {
				continue;
			}
			if(!dps.isIsSkipRepayment()) {
				CePaymentSchedule cps = new CePaymentSchedule();
				cps.setStatus(dps.getStatus());
				cps.setRepaymentDate(dps.getRepaymentDate());
				if(dps.isIsDistribute()) {
					BFCurrencyAmount feeA = new BFCurrencyAmount();
					feeA.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					BigDecimal fee = dps.getFeesAmount().getCurrencyAmount().add(skipFeeAmount);
					feeA.setCurrencyAmount(fee);
					cps.setFeesAmount(feeA);
					BFCurrencyAmount principalA = new BFCurrencyAmount();
					principalA.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					BigDecimal principal = dps.getPrincipalAmount().getCurrencyAmount().add(skipPrincipalAmount);
					principalA.setCurrencyAmount(principal);
					cps.setPrincipalAmount(principalA);
					BFCurrencyAmount subsidyA = new BFCurrencyAmount();
					subsidyA.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					BigDecimal subsidy = CommonConstants.BIGDECIMAL_ZERO;
					if(isF_IN_distributeIsSubsidy()) 
					  subsidy = dps.getSubsidyAmount().getCurrencyAmount().add(skipSubsidyAmount);
					
					subsidyA.setCurrencyAmount(subsidy);
					cps.setSubsidyAmount(subsidyA);
					BFCurrencyAmount profitA = new BFCurrencyAmount();
					profitA.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					BigDecimal profit = dps.getProfitAmount().getCurrencyAmount().add(skipProfitAmount);
					profitA.setCurrencyAmount(profit);
					cps.setProfitAmount(profitA);
					BFCurrencyAmount totalA = new BFCurrencyAmount();
					totalA.setCurrencyCode(dealDetails.getF_IsoCurrencyCode());
					BigDecimal total = dps.getTotalRepaymentAmount().getCurrencyAmount().add(skipTotalAmount);
					totalA.setCurrencyAmount(total);
					cps.setTotalRepaymentAmount(totalA);
				}else {
					cps.setFeesAmount(dps.getFeesAmount());
					cps.setPrincipalAmount(dps.getPrincipalAmount());
					cps.setProfitAmount(dps.getProfitAmount());
					cps.setSubsidyAmount(dps.getSubsidyAmount());
					cps.setTotalRepaymentAmount(dps.getTotalRepaymentAmount());
				}
				newScheduleList.add(cps);
			}
		}
		newScheduleList.sort(new Comparator<CePaymentSchedule>() {
			@Override
			public int compare(CePaymentSchedule o1, CePaymentSchedule o2) {
				return o1.getRepaymentDate().compareTo(o2.getRepaymentDate());
			}
		});

		BigDecimal diffPrinciple = originalSkipPrincipleAmount.subtract(skipPrincipalAmount.multiply(new BigDecimal(noOfDist)));
		BigDecimal diffFee = originalSkipFeeAmount.subtract(skipFeeAmount.multiply(new BigDecimal(noOfDist)));
		BigDecimal diffProfit = originalSkipProfitAmount.subtract(skipProfitAmount.multiply(new BigDecimal(noOfDist)));
		BigDecimal diffSubsidy = originalSkipSubsidyAmount.subtract(skipSubsidyAmount.multiply(new BigDecimal(noOfDist)));
		BigDecimal diffTotalAmount = diffPrinciple.add(diffFee).add(diffProfit);
		
		//adding the rounding diff amount to first repayment
		if(diffTotalAmount.compareTo(BigDecimal.ZERO)>0) {
			CePaymentSchedule firstRepayment = newScheduleList.get(0);
			newScheduleList.get(0).setFeesAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getFeesAmount().getCurrencyAmount().add(diffFee), currencyCode));
			newScheduleList.get(0).setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getPrincipalAmount().getCurrencyAmount().add(diffPrinciple), currencyCode));
			newScheduleList.get(0).setProfitAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getProfitAmount().getCurrencyAmount().add(diffProfit), currencyCode));
			newScheduleList.get(0).setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getSubsidyAmount().getCurrencyAmount().add(diffSubsidy), currencyCode));
			newScheduleList.get(0).setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getTotalRepaymentAmount().getCurrencyAmount().add(diffTotalAmount), currencyCode));
		}
		BigDecimal schFee = getF_IN_scheduleFees().getCurrencyAmount();
		if(schFee == null) {
			schFee = BigDecimal.ZERO;
		}
		BigDecimal newScheduleFee = schFee.setScale(0, RoundingMode.UP);
		BigDecimal repayFee = newScheduleFee.divide(new BigDecimal(newScheduleList.size()), BigDecimal.ROUND_DOWN);
		repayFee = repayFee.setScale(0, RoundingMode.UP);
		BigDecimal allocatedFee = BigDecimal.ZERO;
		//Setting the repayment number
		int i = 1;
		PaymentScheduleDetails psl = new PaymentScheduleDetails();
		for(CePaymentSchedule cps : newScheduleList) {
			cps.setRepaymentNo(i++);
			BFCurrencyAmount feeCAmt = cps.getFeesAmount();
			feeCAmt.setCurrencyAmount(feeCAmt.getCurrencyAmount().add(repayFee));
			cps.setFeesAmount(feeCAmt);
			BFCurrencyAmount totalAmt = cps.getTotalRepaymentAmount();
			totalAmt.setCurrencyAmount(totalAmt.getCurrencyAmount().add(repayFee));
			cps.setTotalRepaymentAmount(totalAmt);
			psl.addCePaymentSchedule(cps);
			allocatedFee = allocatedFee.add(repayFee);
		}	
		if(newScheduleFee.compareTo(allocatedFee)>0) {
			CePaymentSchedule firstRepayment = newScheduleList.get(0);
			BigDecimal roundingFee = newScheduleFee.subtract(allocatedFee);
			newScheduleList.get(0).setFeesAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getFeesAmount().getCurrencyAmount().add(roundingFee), currencyCode));
			newScheduleList.get(0).setTotalRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(firstRepayment.getTotalRepaymentAmount().getCurrencyAmount().add(roundingFee), currencyCode));
		}
		setF_OUT_paymentScheduleList(psl);
	}
	
	private void setAssetBasedPaymentSchedule() {
		//from readloans get the last payment schedule
		//from breakup table get the last payment schedule of assets
		//create a new payment schedule against assets
		LoanPayments lastLoanPayment = readLoanDetailsRs.getDealDetails().getPaymentSchedule()[readLoanDetailsRs.getDealDetails().getPaymentScheduleCount()-1];
		String assetDisbursedStatusDesc = IBCommonUtils.getGCChildDesc(IBConstants.ASSETSTATUS, CeConstants.ASSET_STATUS_DISBURSED);
		String assetPartiallyDisbursedStatusDesc = IBCommonUtils.getGCChildDesc(IBConstants.ASSETSTATUS, "PARTIALLYDISBURSED");
		List<String> transferOfDebtAssets = com.ce.bankfusion.ib.util.ScheduleUtils
				.getAssetIdFromTransferOfDebt(getF_IN_islamicBankingObject().getDealID());
		String udfValueAssetToBeDisbursed = com.misys.bankfusion.common.constant.CommonConstants.EMPTY_STRING;
		List<String> assetIds = new ArrayList<>();
		for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
				if (!(transferOfDebtAssets != null &&
						transferOfDebtAssets.contains(assetBasicDtls.getAssetId()))) {
					udfValueAssetToBeDisbursed = CeUtils.getUDFValueAssetToBeDisbursed(readAssetData,
							assetBasicDtls.getAssetId());
					if ((!assetBasicDtls.getAssetStatus().equals(CommonConstants.EMPTY_STRING))&&(udfValueAssetToBeDisbursed.equals("YES")
							|| assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
							|| assetBasicDtls.getAssetStatus().equals(assetDisbursedStatusDesc)
							|| assetBasicDtls.getAssetStatus().equals("PARTIALLYDISBURSED")
							|| assetBasicDtls.getAssetStatus().equals(assetPartiallyDisbursedStatusDesc))) {
						assetIds.add(assetBasicDtls.getAssetId());
					}
				}
			
			}
		//getF_OUT_assetprofileDetails()
		getF_OUT_assetprofileDetails().removeAllAssetBasedPaymentSchedule();
		String scheduleBreakupQuery = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? and "+IBOCE_IB_PaymentSchBreakup.IBASSETID + " = ? order by "+IBOCE_IB_PaymentSchBreakup.IBBILLDATE+" desc";
		int i = 0;
		Map<Date, BigDecimal> principleAllocated = new HashMap<>();
		Map<Date, BigDecimal> profitAllocated = new HashMap<>();
		Map<Date, BigDecimal> feeAllocated = new HashMap<>();
		Map<Date, BigDecimal> subsidyAllocated = new HashMap<>();
		for(String assetId : assetIds) {
			i++;
			ArrayList params = new ArrayList<>();
			params.add(dealDetails.getBoID());
			params.add(assetId);
			List<IBOCE_IB_PaymentSchBreakup> breakupDtls = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, scheduleBreakupQuery, params, null, false);
			IBOCE_IB_PaymentSchBreakup breakupDtl = breakupDtls.get(0);
			BigDecimal assetPercentage = breakupDtl.getF_IBPRINCIPALAMT().divide(lastLoanPayment.getPrincipleAmt(), 4, BigDecimal.ROUND_FLOOR);
			BigDecimal assetScheudleFeesAmount = BigDecimal.ZERO;
			BigDecimal assetTotalSubsidyAmount = BigDecimal.ZERO;
			BigDecimal lastPaymentPrincipalAmount = BigDecimal.ZERO;
			BigDecimal lastPaymentProfitAmount = BigDecimal.ZERO;
			for(CePaymentSchedule paymentSchedule : getF_OUT_paymentScheduleList().getCePaymentSchedule()) {
				AssetBasedPaymentSchedule assetPaymentSchedule = new AssetBasedPaymentSchedule();
				assetPaymentSchedule.setAssetId(assetId);
				Date repaymentDate = paymentSchedule.getRepaymentDate();
				assetPaymentSchedule.setRepaymentDate(repaymentDate);
				BigDecimal principalAmount = BigDecimal.ZERO;
				BigDecimal profitAmount = BigDecimal.ZERO;
				BigDecimal feeAmount = BigDecimal.ZERO;
				BigDecimal subsidyAmount = BigDecimal.ZERO;
				if(i != assetIds.size()) {
					principalAmount = paymentSchedule.getPrincipalAmount().getCurrencyAmount().multiply(assetPercentage).setScale(0, BigDecimal.ROUND_DOWN);
					profitAmount = paymentSchedule.getProfitAmount().getCurrencyAmount().multiply(assetPercentage).setScale(0, BigDecimal.ROUND_DOWN);
					feeAmount = paymentSchedule.getFeesAmount().getCurrencyAmount().multiply(assetPercentage).setScale(0, BigDecimal.ROUND_DOWN);
					subsidyAmount = paymentSchedule.getSubsidyAmount().getCurrencyAmount().multiply(assetPercentage).setScale(0, BigDecimal.ROUND_DOWN);
					principleAllocated.put(repaymentDate, principleAllocated.containsKey(repaymentDate)?principleAllocated.get(repaymentDate).add(principalAmount):principalAmount);
					profitAllocated.put(repaymentDate, profitAllocated.containsKey(repaymentDate)?profitAllocated.get(repaymentDate).add(profitAmount):profitAmount);
					feeAllocated.put(repaymentDate, feeAllocated.containsKey(repaymentDate)?feeAllocated.get(repaymentDate).add(feeAmount):feeAmount);
					subsidyAllocated.put(repaymentDate, subsidyAllocated.containsKey(repaymentDate)?subsidyAllocated.get(repaymentDate).add(subsidyAmount):subsidyAmount);
				}else {
					principalAmount = principleAllocated.containsKey(repaymentDate)?paymentSchedule.getPrincipalAmount().getCurrencyAmount().subtract(principleAllocated.get(repaymentDate)):paymentSchedule.getPrincipalAmount().getCurrencyAmount();
					profitAmount = profitAllocated.containsKey(repaymentDate)?paymentSchedule.getProfitAmount().getCurrencyAmount().subtract(profitAllocated.get(repaymentDate)):paymentSchedule.getProfitAmount().getCurrencyAmount();
					feeAmount = feeAllocated.containsKey(repaymentDate)?paymentSchedule.getFeesAmount().getCurrencyAmount().subtract(feeAllocated.get(repaymentDate)):paymentSchedule.getFeesAmount().getCurrencyAmount();
					subsidyAmount = subsidyAllocated.containsKey(repaymentDate)?paymentSchedule.getSubsidyAmount().getCurrencyAmount().subtract(subsidyAllocated.get(repaymentDate)):paymentSchedule.getSubsidyAmount().getCurrencyAmount();
				}
				assetPaymentSchedule.setPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(principalAmount, currencyCode));
				assetPaymentSchedule.setProfitAmount(IBCommonUtils.getBFCurrencyAmount(profitAmount, currencyCode));
				assetPaymentSchedule.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(feeAmount, currencyCode));
				assetPaymentSchedule.setSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(subsidyAmount, currencyCode));
				assetProfileDetails.addAssetBasedPaymentSchedule(assetPaymentSchedule);
				assetScheudleFeesAmount = assetScheudleFeesAmount.add(feeAmount);
				assetTotalSubsidyAmount = assetTotalSubsidyAmount.add(subsidyAmount);
				lastPaymentPrincipalAmount = principalAmount;
				lastPaymentProfitAmount = profitAmount;
			}
			BigDecimal assetRepaymentProfitAmount = getTotalAssetProfitAmount(assetId, BigDecimal.ZERO);
			BigDecimal assetRepaymentPrincipalAmount = com.ce.bankfusion.ib.util.ScheduleUtils
					.getAssetOutstandingPrincipalAmount(readLoanDetailsRs,
							getF_IN_islamicBankingObject().getDealID(), assetId);
			BigDecimal totalAssetRepaymentAmount = assetRepaymentProfitAmount.add(assetRepaymentPrincipalAmount)
					.add(assetScheudleFeesAmount);
			// adding asset profile
			CeAssetProfile assetProfile = new CeAssetProfile();
			assetProfile.setAssetId(assetId);
			assetProfile.setScheduleFeesAmount(IBCommonUtils.getBFCurrencyAmount(assetScheudleFeesAmount, currencyCode));
			assetProfile.setScheduleFeesAmountPaid(CeUtils.getZeroAmount(currencyCode));
			assetProfile.setTotalPrincipalAmount(IBCommonUtils.getBFCurrencyAmount(assetRepaymentPrincipalAmount, currencyCode));
			assetProfile.setTotalPrincipalAmountPaid(CeUtils.getZeroAmount(currencyCode));
			assetProfile.setTotalProfitAmount(IBCommonUtils.getBFCurrencyAmount(assetRepaymentProfitAmount, currencyCode));
			assetProfile.setTotalProfitAmountPaid(CeUtils.getZeroAmount(currencyCode));
			assetProfile.setTotalSubsidyAmount(IBCommonUtils.getBFCurrencyAmount(assetTotalSubsidyAmount, currencyCode));
			assetProfile.setTotalSubsidyAmountPaid(CeUtils.getZeroAmount(currencyCode));
			assetProfile.setAssetRepaymentAmount(IBCommonUtils.getBFCurrencyAmount(totalAssetRepaymentAmount, currencyCode));
			assetProfileDetails.addAssetProfileList(assetProfile);
			PaymentSchedule paymentSchedule = new PaymentSchedule();
			paymentSchedule.setPrincipleAmt(IBCommonUtils.getBFCurrencyAmount(lastPaymentPrincipalAmount, currencyCode));
			paymentSchedule.setProfitAmt(IBCommonUtils.getBFCurrencyAmount(lastPaymentProfitAmount, currencyCode));
			assetIdAndpaymentScheduleMap.put(assetId, paymentSchedule);
		}
	}

	public PoAssetDisbursementDetails[] getPoAssetDisbursementDtls() {
		return poAssetDisbursementDtls;
	}

	public void setPoAssetDisbursementDtls(PoAssetDisbursementDetails[] poAssetDisbursementDtls) {
		this.poAssetDisbursementDtls = poAssetDisbursementDtls;
	}
	

}
