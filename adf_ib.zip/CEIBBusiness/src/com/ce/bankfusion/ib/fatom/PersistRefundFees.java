package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDFEES;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PersistRefundFees;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealFinancialDisbursementDTL;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AccEntriesRegistrationDtls;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.RefundFeesDtls;
import bf.com.misys.ib.types.RefundFeesDtlsList;

public class PersistRefundFees extends AbstractCE_IB_PersistRefundFees{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4464960737488864750L;

	public PersistRefundFees()
	{
		super();
	}
	
	public PersistRefundFees(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IslamicBankingObject ibObject = getF_IN_islamicBankingObject();
		RefundFeesDtlsList refundFeesList = getF_IN_refundFeesDtlsList();
		boolean noRefundScheduled = true;
		
		
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		
		for(RefundFeesDtls refundFeeCheck : refundFeesList.getRefundFeesDtls()) {
			if(refundFeeCheck.getRefundStatus()!=null && !refundFeeCheck.getRefundStatus().isEmpty() && !refundFeeCheck.getRefundStatus().equalsIgnoreCase("REFUNDED"))
				noRefundScheduled = false;
		}
		
		if(noRefundScheduled) {
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_ATLEAST_ONE_FEE_TOBE_SCHEDULED);
		}
		
		for(RefundFeesDtls refundFee : refundFeesList.getRefundFeesDtls()) {
					
			String dealScheduledFeesClause = "WHERE "+ IBOCE_IB_REFUNDFEES.IBDEALID+"=?" +" AND "+ IBOCE_IB_REFUNDFEES.IBDEALASSETCHARGEDTLID+"=?" +" AND "+ IBOCE_IB_REFUNDFEES.IBREFUNDSTATUS+"=?";
			String payrecRefundFeesClause = "WHERE "+ IBOIB_TXN_PAYRECDETAIL.PAYRECDETAILID+"=?";
			ArrayList params = new ArrayList<>();
			params.add(ibObject.getDealID());
			params.add(refundFee.getDealAssetChargeDetailId());
			params.add("SCHEDULED");
		
			List<IBOCE_IB_REFUNDFEES> dealScheduledFeesList = factory.findByQuery(IBOCE_IB_REFUNDFEES.BONAME, dealScheduledFeesClause, params, null, false);
		
			if(!dealScheduledFeesList.isEmpty() && refundFee.getRefundStatus()!=null && refundFee.getRefundStatus().isEmpty() && !refundFee.getRefundStatus().equalsIgnoreCase("REFUNDED")) {
				for(IBOCE_IB_REFUNDFEES scheduledFee : dealScheduledFeesList) {
					
					IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
							.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, scheduledFee.getBoID(), true);
					
					registerAccountingEntries(ibObject.getDealID(),payRecDetail,"delete");
					
					params.clear();
					params.add(scheduledFee.getBoID());
					factory.bulkDelete(IBOCE_IB_REFUNDFEES.BONAME, payrecRefundFeesClause, params);
					
					params.clear();
					params.add(ibObject.getDealID());
					params.add(scheduledFee.getF_IBDEALASSETCHARGEDTLID());
					params.add("SCHEDULED");
					factory.bulkDelete(IBOCE_IB_REFUNDFEES.BONAME, dealScheduledFeesClause, params);
					 
				}
			
			}
			
			if(!dealScheduledFeesList.isEmpty() && refundFee.getRefundStatus()!=null && !refundFee.getRefundStatus().isEmpty() && !refundFee.getRefundStatus().equalsIgnoreCase("REFUNDED")) {
				for(IBOCE_IB_REFUNDFEES scheduledFee : dealScheduledFeesList) {					
					scheduledFee.setF_IBPARTYID(refundFee.getCustomerId());
					scheduledFee.setF_IBAMOUNT(refundFee.getAmount().getCurrencyAmount());
					scheduledFee.setF_IBPAIDAMT(refundFee.getPaidAmount().getCurrencyAmount());
					scheduledFee.setF_IBREMAMT(refundFee.getRemainingAmount().getCurrencyAmount());
					scheduledFee.setF_IBPARTYBANKACCOUNTID(refundFee.getBankAccountId());
					scheduledFee.setF_IBTRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
					scheduledFee.setF_IBUSER(refundFee.getUser());
					scheduledFee.setF_IBREFUNDSTATUS(refundFee.getRefundStatus());
					if(scheduledFee.getF_IBDESCRIPTION()!=null)
						scheduledFee.setF_IBDESCRIPTION(refundFee.getDescription());
					
					IBOIB_TXN_PAYRECDETAIL payRecDetail = (IBOIB_TXN_PAYRECDETAIL) IBCommonUtils.getPersistanceFactory()
							.findByPrimaryKey(IBOIB_TXN_PAYRECDETAIL.BONAME, scheduledFee.getBoID(), true);
					
					if(scheduledFee.getF_IBPARTYBANKACCOUNTID()!=null && !scheduledFee.getF_IBPARTYBANKACCOUNTID().isEmpty())
						payRecDetail.setF_ACCOUNTID(scheduledFee.getF_IBPARTYBANKACCOUNTID());
					else
						payRecDetail.setF_ACCOUNTID("NOACCOUNT");
					
					payRecDetail.setF_EQUIVALENTAMOUNT(scheduledFee.getF_IBPAIDAMT());
					payRecDetail.setF_TRANSACTIONCURRENCY(getF_IN_islamicBankingObject().getCurrency());
					payRecDetail.setF_TRANSACTIONAMOUNT(scheduledFee.getF_IBPAIDAMT());
					payRecDetail.setF_TRANSACTIONDTTM(scheduledFee.getF_IBTRANSACTIONDTTM());
					payRecDetail.setF_VALUEDTTM(scheduledFee.getF_IBTRANSACTIONDTTM());
					payRecDetail.setF_AMOUNTTYPE("REFUNDFEES");
					payRecDetail.setF_STEPID(ibObject.getStepID());
					if(scheduledFee.getF_IBDESCRIPTION()!=null)
						payRecDetail.setF_NARRATIVE(scheduledFee.getF_IBDESCRIPTION());
					
					registerAccountingEntries(ibObject.getDealID(),payRecDetail,"delete");
					registerAccountingEntries(ibObject.getDealID(),payRecDetail,IBConstants.EMPTY_STRING);
					
				}
			
			}
			
			
			if(dealScheduledFeesList.isEmpty() && refundFee.getRefundStatus()!=null && !refundFee.getRefundStatus().isEmpty() && !refundFee.getRefundStatus().equalsIgnoreCase("REFUNDED")) {
			
				IBOCE_IB_REFUNDFEES refundFees = (IBOCE_IB_REFUNDFEES) factory
						.getStatelessNewInstance(IBOCE_IB_REFUNDFEES.BONAME);
				
			refundFees.setBoID(GUIDGen.getNewGUID());
			refundFees.setF_IBDEALID(ibObject.getDealID());
			refundFees.setF_IBDEALASSETCHARGEDTLID(refundFee.getDealAssetChargeDetailId());
			refundFees.setF_IBFEEID(refundFee.getFeeID());
			refundFees.setF_IBFEENAME(refundFee.getFeeName());
			refundFees.setF_IBPARTYID(refundFee.getCustomerId());
			refundFees.setF_IBAMOUNT(refundFee.getAmount().getCurrencyAmount());
			refundFees.setF_IBPAIDAMT(refundFee.getPaidAmount().getCurrencyAmount());
			refundFees.setF_IBREMAMT(refundFee.getRemainingAmount().getCurrencyAmount());
			refundFees.setF_IBPARTYBANKACCOUNTID(refundFee.getBankAccountId());
			refundFees.setF_IBTRANSACTIONDTTM(IBCommonUtils.getBFBusinessDateTime());
			refundFees.setF_IBUSER(refundFee.getUser());
			refundFees.setF_IBREFUNDSTATUS(refundFee.getRefundStatus());
			if(refundFee.getDescription()!=null)
			refundFees.setF_IBDESCRIPTION(refundFee.getDescription());
			
			
			
			IBOIB_TXN_PAYRECDETAIL payrecDtlRefundFees = (IBOIB_TXN_PAYRECDETAIL) factory
					.getStatelessNewInstance(IBOIB_TXN_PAYRECDETAIL.BONAME);
			
			payrecDtlRefundFees.setBoID(refundFees.getBoID());
			if(refundFees.getF_IBPARTYBANKACCOUNTID()!=null && !refundFees.getF_IBPARTYBANKACCOUNTID().isEmpty())
				payrecDtlRefundFees.setF_ACCOUNTID(refundFees.getF_IBPARTYBANKACCOUNTID());
			else
				payrecDtlRefundFees.setF_ACCOUNTID("NOACCOUNT");
			
			payrecDtlRefundFees.setF_DEALNO(refundFees.getF_IBDEALID());
			payrecDtlRefundFees.setF_EQUIVALENTAMOUNT(refundFees.getF_IBPAIDAMT());
			payrecDtlRefundFees.setF_TRANSACTIONCURRENCY(getF_IN_islamicBankingObject().getCurrency());
			payrecDtlRefundFees.setF_TRANSACTIONAMOUNT(refundFees.getF_IBPAIDAMT());
			payrecDtlRefundFees.setF_EXCHANGERATE(BigDecimal.ONE);
			payrecDtlRefundFees.setF_EXCHANGERATETYPE("SPOT");
			payrecDtlRefundFees.setF_TRANSACTOINTYPE("PAY");
			payrecDtlRefundFees.setF_TRANSACTIONSTATUS("SCHEDULED");
			payrecDtlRefundFees.setF_TRANSACTIONID(ibObject.getTransactionID());
			payrecDtlRefundFees.setF_TRANSACTIONDTTM(refundFees.getF_IBTRANSACTIONDTTM());
			payrecDtlRefundFees.setF_VALUEDTTM(refundFees.getF_IBTRANSACTIONDTTM());
			payrecDtlRefundFees.setF_PAYMENTMETHOD("TRF");
			payrecDtlRefundFees.setF_AMOUNTTYPE("REFUNDFEES");
			payrecDtlRefundFees.setF_STEPID(ibObject.getStepID());
			if(refundFees.getF_IBDESCRIPTION()!=null)
			payrecDtlRefundFees.setF_NARRATIVE(refundFees.getF_IBDESCRIPTION());
			
			
			factory.create(IBOCE_IB_REFUNDFEES.BONAME, refundFees);
			factory.create(IBOIB_TXN_PAYRECDETAIL.BONAME, payrecDtlRefundFees);
			
			registerAccountingEntries(ibObject.getDealID(),payrecDtlRefundFees,IBConstants.EMPTY_STRING);
			
			}
		}
	}
	
	private void registerAccountingEntries(String dealNo, IBOIB_TXN_PAYRECDETAIL payRecDetailObject, String mode){
    	AccEntriesRegistrationDtls accEntriesRegistrationDetails = new AccEntriesRegistrationDtls();
    	accEntriesRegistrationDetails.setAccountID(payRecDetailObject.getF_ACCOUNTID());
    	accEntriesRegistrationDetails.setEntityId(payRecDetailObject.getBoID());
    	Amount amount2 = new Amount();
    	BigDecimal temp = BigDecimal.ZERO;
    	amount2.setAmountEdited(temp);
    	amount2.setIsoCurrencyCode(" ");
    	accEntriesRegistrationDetails.setAmountInAccCurr(amount2);
    	Amount amount = new Amount();
    	amount.setAmountEdited(payRecDetailObject.getF_EQUIVALENTAMOUNT());
    	amount.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
    	accEntriesRegistrationDetails.setBaseEquivalent(amount);
    	accEntriesRegistrationDetails.setDealId(payRecDetailObject.getF_DEALNO());
    	accEntriesRegistrationDetails.setEntityContext(payRecDetailObject.getF_AMOUNTTYPE());
    	accEntriesRegistrationDetails.setExchangeRate(payRecDetailObject.getF_EXCHANGERATE());
    	accEntriesRegistrationDetails.setExchangeRateType(payRecDetailObject.getF_EXCHANGERATETYPE());
    	accEntriesRegistrationDetails.setNarrative(payRecDetailObject.getF_NARRATIVE());
    	accEntriesRegistrationDetails.setProcessId(getF_IN_islamicBankingObject().getProcessConfigID());
    	accEntriesRegistrationDetails.setStepId(getF_IN_islamicBankingObject().getStepID());
    	accEntriesRegistrationDetails.setTransactionDt(new java.sql.Date(payRecDetailObject.getF_TRANSACTIONDTTM().getTime()));
    	accEntriesRegistrationDetails.setTransactionId(dealNo);
    	Amount amount1 = new Amount();
    	amount1.setAmountEdited(payRecDetailObject.getF_TRANSACTIONAMOUNT());
    	amount1.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
    	accEntriesRegistrationDetails.setTxnAmount(amount1);
    	accEntriesRegistrationDetails.setTxnCurrency(amount1.getIsoCurrencyCode());
    	accEntriesRegistrationDetails.setTxnType(payRecDetailObject.getF_TRANSACTOINTYPE());
    	accEntriesRegistrationDetails.setValueDt(new java.sql.Date(payRecDetailObject.getF_VALUEDTTM().getTime()));
    	HashMap input = new HashMap();
    	input.put("accEntriesRegistrationDtls", accEntriesRegistrationDetails);
    	if(!mode.isEmpty())
    		input.put("mode", "delete");
    	MFExecuter.executeMF("IB_CMN_RegisterAccountingEntries_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), input);
    }

}
