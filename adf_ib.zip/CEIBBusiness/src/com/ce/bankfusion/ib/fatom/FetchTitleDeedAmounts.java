/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BuyerDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerDocumentDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerTitleDeedDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalArea;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_FetchTitleDeedAmounts;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_GetPartyFinancialDetails;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.utils.ADFUtils;
import com.ce.bankfusion.ib.utils.DealAmounts;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.BuyerDetails;
import bf.com.misys.ib.types.SellerDocumentDetails;
import bf.com.misys.ib.types.SellerTitleDeedDetails;

/**
 * @author Aklesh
 *
 */
public class FetchTitleDeedAmounts extends AbstractCE_ADF_FetchTitleDeedAmounts {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String TITLE_DEED_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + "=? AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDSOURCE + "=? AND " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE + "=? AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDYEAR + "=? AND " + IBOCE_TITLEDEEDDETAILS.LANDPLANNUMBER + "=? AND "
			+ IBOCE_TITLEDEEDDETAILS.LANDPLOTNUMBER + "=?";

	public FetchTitleDeedAmounts(BankFusionEnvironment env) {
		super(env);

	}

	public FetchTitleDeedAmounts() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		BigDecimal dueAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal remainingAmount = CommonConstants.BIGDECIMAL_ZERO;
		BFCurrencyAmount bfDueAmount = new BFCurrencyAmount();
		bfDueAmount.setCurrencyCode("SAR");
		bfDueAmount.setCurrencyAmount(dueAmount);
		BFCurrencyAmount bfRemainingAmount = new BFCurrencyAmount();
		bfRemainingAmount.setCurrencyAmount(remainingAmount);
		bfRemainingAmount.setCurrencyCode("SAR");
		String TITLE_DEED_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + "=? AND "
				+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDSOURCE + "=? AND " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE + "=? AND "
				+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDYEAR + "=? ";
		String TECH_ANALYSIS_WHERE_CLAUSE = "WHERE " + IBOCE_IB_TechincalArea.IBTITLEDEEDID + "=?";
		String TECH_ANALYSIS_FARM_WHERE_CLAUSE = "WHERE " + IBOCE_IB_TechnicalFarm.IBREFERENCENUMBER + "=?";
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList();
		params.add(getF_IN_sellerTitleDeedDetails().getTitleDeedNumber());
		params.add(getF_IN_sellerTitleDeedDetails().getTitleDeedSource());
		params.add(getF_IN_sellerTitleDeedDetails().getTitleDeedType());
		params.add(getF_IN_sellerTitleDeedDetails().getTitleDeedYear());
		if (!getF_IN_sellerTitleDeedDetails().getLandPlanNumber().isEmpty()) {
			TITLE_DEED_WHERE_CLAUSE = TITLE_DEED_WHERE_CLAUSE + " AND " + IBOCE_TITLEDEEDDETAILS.LANDPLANNUMBER
					+ " =? ";
			params.add(getF_IN_sellerTitleDeedDetails().getLandPlanNumber());
		}
		if (!getF_IN_sellerTitleDeedDetails().getLandPlotNumber().isEmpty()) {
			TITLE_DEED_WHERE_CLAUSE = TITLE_DEED_WHERE_CLAUSE + " AND " + IBOCE_TITLEDEEDDETAILS.LANDPLOTNUMBER
					+ " =? ";
			params.add(getF_IN_sellerTitleDeedDetails().getLandPlotNumber());
		}

		List<IBOCE_TITLEDEEDDETAILS> titleDeedDetails = factory.findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
				TITLE_DEED_WHERE_CLAUSE, params, null);
		for (IBOCE_TITLEDEEDDETAILS iboce_TITLEDEEDDETAILS : titleDeedDetails) {
			CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) iboce_TITLEDEEDDETAILS
					.getCompositeBOID();
			ArrayList techParams = new ArrayList();
			techParams.add(titledeeddetailsid.getF_TITLEDEEDID());
			List<IBOCE_IB_TechincalArea> ib_TechincalAreas = factory.findByQuery(IBOCE_IB_TechincalArea.BONAME,
					TECH_ANALYSIS_WHERE_CLAUSE, techParams, null);
			for (IBOCE_IB_TechincalArea iboce_IB_TechincalArea : ib_TechincalAreas) {
				ArrayList techfarmParams = new ArrayList();
				techfarmParams.add(iboce_IB_TechincalArea.getF_IBREFERENCENUMBER());
				List<IBOCE_IB_TechnicalFarm> ib_TechnicalFarms = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
						TECH_ANALYSIS_FARM_WHERE_CLAUSE, techfarmParams, null);
				for (IBOCE_IB_TechnicalFarm iboce_IB_TechnicalFarm : ib_TechnicalFarms) {
					IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
							.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, iboce_IB_TechnicalFarm.getF_IBDEALID(), true);
					if (dealDetails!=null && null != dealDetails.getF_DealAccountId()
							&& !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {

						DealAmounts dealAmounts = ADFUtils.getDealAmounts(iboce_IB_TechnicalFarm.getF_IBDEALID());
						dueAmount = dueAmount.add(dealAmounts.getDueAmount().getCurrencyAmount());
						remainingAmount = remainingAmount.add(dealAmounts.getRemainingAmount().getCurrencyAmount());
						if(dueAmount.compareTo(CommonConstants.BIGDECIMAL_ZERO)>CommonConstants.INTEGER_ZERO)
							getF_OUT_sellerTitleDeedDetails().setIsUsedinTechAnalysis("This is used in tech analysis");
					}
				}
			}
		}
		bfDueAmount.setCurrencyAmount(dueAmount);
		bfRemainingAmount.setCurrencyAmount(remainingAmount);
		getF_OUT_sellerTitleDeedDetails().setPastDueAmount(bfDueAmount);
		getF_OUT_sellerTitleDeedDetails().setRemainingAmount(bfRemainingAmount);
	}
}