/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: DealInitiationPanelInfoProvider.java,v.1.0,Oct 27, 2014 2:21:41 PM Aklesh S
 *
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import bf.com.misys.bankfusion.attributes.MultiPanelResponse;
import bf.com.misys.bankfusion.attributes.ProcessNavigationLinks;
import bf.com.misys.bankfusion.attributes.RequestDataEntries;
import bf.com.misys.bankfusion.attributes.RequestDataEntry;
import bf.com.misys.ib.types.ListDealCustomer;

import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.expression.builder.functions.ConvertToString;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.app.api.IPanelInfoProvider;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.toolkit.expression.function.ConvertToDate;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_DealRescheduleDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.constants.DealInitiationConstants;
import com.misys.bankfusion.ib.constants.IBHeaderConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.PanelUtils;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.document.DocumentProcessor;

public class CEDealInitiationPanelInfoProvider implements IPanelInfoProvider {

    private static final String FINAL_DEAL_PARTY =
        "WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + " = ? AND " + IBOIB_IDI_DealCustomerDetail.ASSOCIATIONTYPE + " =?";

    private PanelUtils panelUtil = new PanelUtils();

    private final IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
    /*
     * (non-Javadoc)
     * @see com.misys.bankfusion.app.api.IPanelInfoProvider#getPanelServiceData(java.lang.String)
     */

    public MultiPanelResponse getPanelServiceData(String correlationId, Map data) {
        MultiPanelResponse multiPanel = new MultiPanelResponse();

        multiPanel.setStructureChanged(true);
        String[] splitted = PanelUtils.splitGUID(correlationId);
        String dealID = splitted[2];
        IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);

        RequestDataEntries requestMapping = createMapEntries(dealID);
        createReturnDetailsLink(requestMapping, correlationId, dealDetails, multiPanel, data);
        requestMapping = createMapEntriesHeader(dealID, dealDetails);
        multiPanel.setServiceData(requestMapping);
        return multiPanel;
    }

    /**
     * @param correlationId
     * @return
     */

    private RequestDataEntries createMapEntries(String correlationId) {
        RequestDataEntries requestMapping = new RequestDataEntries();
        RequestDataEntry[] mapEntries = panelUtil.createMapEntriesArray(correlationId);
        requestMapping.setRequestData(mapEntries);
        return requestMapping;
    }

    /**
     * @param correlationId
     * @param applicationDetails
     * @param quotationDetails
     * @param factory
     * @param env
     * @return
     */
    private RequestDataEntries createMapEntriesHeader(String correlationId, IBOIB_DLI_DealDetails applicationDetails) {
        RequestDataEntries requestMapping = new RequestDataEntries();
        RequestDataEntry[] mapEntries = createMapEntriesArrayForHeader(correlationId, applicationDetails);
        requestMapping.setRequestData(mapEntries);
        return requestMapping;
    }

    /**
     * @param correlationId
     * @param env
     * @param factory
     * @param applicationDetails
     * @param quotationDetails
     * @return
     */
    private RequestDataEntry[] createMapEntriesArrayForHeader(String correlationId, IBOIB_DLI_DealDetails applicationDetails) {
        ArrayList<RequestDataEntry> mapEntryList = new ArrayList<RequestDataEntry>();
        RequestDataEntry mapEntry = new RequestDataEntry();
        BankFusionThreadLocal.setUserZone("BF");
        
        createMapEntriesForCommonAttributes(applicationDetails, mapEntryList);
        
        if (applicationDetails != null) {
        	IBOCE_IB_DealReschedule dealReschObj =
                RescheduleUtils.getReschReqExistingObjStatusNotCompleted(applicationDetails.getBoID());
        	if(dealReschObj != null) {
        		createMapEntriesArrayFromDealReschedule(applicationDetails, mapEntryList);
        	} else {
        		createMapEntriesArrayFromDealDetails(applicationDetails, mapEntryList);
        	}
        }
        if (mapEntryList.size() > 0) {
            return mapEntryList.toArray(new RequestDataEntry[mapEntryList.size()]);
        } else {
            RequestDataEntry[] mapEntries = new RequestDataEntry[1];
            mapEntry = new RequestDataEntry();
            mapEntry.setKey(IBHeaderConstants.PANEL_CORR_ID);
            mapEntry.setValue(correlationId);
            mapEntries[0] = mapEntry;
            return mapEntries;
        }

    }

    private void createMapEntriesForCommonAttributes(IBOIB_DLI_DealDetails applicationDetails,
			ArrayList<RequestDataEntry> mapEntryList) {

        if (applicationDetails != null) {
            DocumentProcessor docPrc = new DocumentProcessor();
            RequestDataEntry mapEntry = null;
            IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
            
            if ((applicationDetails.getF_PrincipleAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.PRINCIPAL_AMOUNT);
                mapEntry.setValue(panelUtil.convertCurrencyForLocale(applicationDetails.getF_PrincipleAmt(),
                    applicationDetails.getF_IsoCurrencyCode(), BankFusionThreadLocal.getUserLocale()));
                mapEntryList.add(mapEntry);

                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.PRINCIPAL_AMOUNT + "_CurrCode");
                mapEntry.setValue(applicationDetails.getF_IsoCurrencyCode());
                mapEntryList.add(mapEntry);
            }
            if (!(applicationDetails.getF_Status()).equals(CommonConstants.EMPTY_STRING)) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.DEAL_STATUS);
                mapEntry.setValue(PanelUtils.getCodeDescr(applicationDetails.getF_Status(), DealInitiationConstants.DEALSTATUS));
                mapEntryList.add(mapEntry);
            }
            if ((applicationDetails.getF_DealStartDate()) != null) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.NEW_START_DATE);
                mapEntry.setValue(ConvertToDate.run(ConvertToString.run(applicationDetails.getF_DealStartDate(), -1)));
                mapEntryList.add(mapEntry);
            }
            if (!(applicationDetails.getF_ProductCode()).equals(CommonConstants.EMPTY_STRING)) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.PRODUCT_ID);
                mapEntry.setValue(PanelUtils.getCodeDescr(applicationDetails.getF_ProductCode(), DealInitiationConstants.PRODUCTNAME));
                mapEntryList.add(mapEntry);
            }
            if (!(applicationDetails.getF_ProductContextCode()).equals(CommonConstants.EMPTY_STRING)) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.SUB_PRODUCT_ID);
                String multiLangSubProductName = PanelUtils.getSubProductDescription(applicationDetails.getF_ProductCode(),
                    applicationDetails.getF_ProductContextCode());
                mapEntry.setValue(multiLangSubProductName);
                mapEntryList.add(mapEntry);
            }
            if (!(applicationDetails.getF_BranchSortCode()).equals(CommonConstants.EMPTY_STRING)) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.DEAL_BRANCH);
                String branchDesc = PanelUtils.readBranchDetails(applicationDetails.getF_BranchSortCode());
                mapEntry.setValue(branchDesc);
                mapEntryList.add(mapEntry);
            }
            ArrayList<String> params = new ArrayList<String>();
            params.add(applicationDetails.getBoID());
            params.add(IBConstants.PRIMARYCUSTOMER);
            List<IBOIB_IDI_DealCustomerDetail> customerDetail =
                factory.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, FINAL_DEAL_PARTY, params, null, true);
            for (IBOIB_IDI_DealCustomerDetail dealCustomerDetail : customerDetail) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.CUSTOMER_NAME);
                if (dealCustomerDetail.isF_ISPROSPECT()) {
                    ListDealCustomer deserializedObj =
                        (ListDealCustomer) IBCommonUtils.convertFromBytes(dealCustomerDetail.getF_CUSTOMERDATA());
                    if (null != deserializedObj.getPartyDetails().getFirstName()
                        && deserializedObj.getPartyDetails().getPartyType().equals("1062"))
                        mapEntry.setValue(deserializedObj.getPartyDetails().getFirstName() + " "
                            + deserializedObj.getPartyDetails().getMiddleName() + " " + deserializedObj.getPartyDetails().getLastName());
                    else if (null != deserializedObj.getCustomerName() && deserializedObj.getPartyDetails().getPartyType().equals("1063"))
                        mapEntry.setValue(deserializedObj.getCustomerName());
                } else {
                    mapEntry.setValue(PanelUtils.readPartyDetails(dealCustomerDetail.getF_CUSTOMERID()));
                }
                mapEntryList.add(mapEntry);
                mapEntry = new RequestDataEntry();
                mapEntry.setKey("customerImage:ImageContent");
                mapEntry.setValue(
                    new String(Base64.encodeBase64(docPrc.uploadCustomerImage(dealCustomerDetail.getF_CUSTOMERID()).getImageContent())));
                mapEntryList.add(mapEntry);
            }
        }		
	}

	/**
     * @param requestMapping
     * @param correlationId
     * @param applicationDetails
     * @param multiPanel
     */
    private void createReturnDetailsLink(RequestDataEntries requestMapping, String correlationId, IBOIB_DLI_DealDetails dealDetails,
        MultiPanelResponse multiPanel, Map data) {

        ProcessNavigationLinks navigationLinks = new ProcessNavigationLinks();
        multiPanel.setNavigationLinks(navigationLinks);
        if (dealDetails != null) {
            data.put("productID", dealDetails.getF_ProductCode());
            data.put("subProductID", dealDetails.getF_ProductContextCode());
        }
        int currSeq = 1;
        panelUtil.populateLinks(requestMapping, correlationId, dealDetails, multiPanel, currSeq, data);
    }

    private void createMapEntriesArrayFromDealReschedule(IBOIB_DLI_DealDetails applicationDetails,
        ArrayList<RequestDataEntry> mapEntryList) {
        if (applicationDetails != null) {
        	IBOCE_IB_DealReschedule dealReschObj =
                RescheduleUtils.getReschReqExistingObjStatusNotCompleted(applicationDetails.getBoID());
            if (dealReschObj != null) {

                IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealReschObj.getF_IBDEALID());
                RequestDataEntry mapEntry = null;
                BigDecimal deltaProfitAmnt = CommonConstants.BIGDECIMAL_ZERO, newProfitAmnt = CommonConstants.BIGDECIMAL_ZERO,
                    dealAmnt = CommonConstants.BIGDECIMAL_ZERO;

                deltaProfitAmnt = dealReschObj.getF_IBSCHEDULEFEES();
                newProfitAmnt = dealDetails.getF_ProfitAmt().add(deltaProfitAmnt);
                dealAmnt = dealDetails.getF_PrincipleAmt().add(newProfitAmnt);
              
                if ((dealReschObj.getF_IBMATURITYDATE()).compareTo(dealDetails.getF_DealStartDate()) > CommonConstants.INTEGER_ZERO) {
                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.NEW_END_DATE);
                    mapEntry.setValue(ConvertToDate.run(ConvertToString.run(dealReschObj.getF_IBMATURITYDATE(), -1)));
                    mapEntryList.add(mapEntry);
                }

                if ((dealReschObj.getF_IBRESCHINSTALLMENTS()) > CommonConstants.INTEGER_ZERO) {
                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.DEAL_TENOR);
                    mapEntry.setValue(
                        CalendarUtil.getPeriodDurationInString(dealDetails.getF_DEALEFFECTIVEDT(), dealReschObj.getF_IBMATURITYDATE()));
                    mapEntryList.add(mapEntry);

                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.DEAL_TENOR_TERM_CODE);
                    mapEntry.setValue(
                        CalendarUtil.getPeriodDurationInString(dealDetails.getF_DEALEFFECTIVEDT(), dealReschObj.getF_IBMATURITYDATE()));
                    mapEntryList.add(mapEntry);
                }

                if ((dealReschObj.getF_IBRESCHINSTALLMENTS()) > CommonConstants.INTEGER_ZERO
                    || (dealReschObj.getF_IBSCHEDULEFEES()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.PROFIT_AMOUNT);
                    mapEntry.setValue(panelUtil.convertCurrencyForLocale(newProfitAmnt, dealDetails.getF_IsoCurrencyCode(),
                        BankFusionThreadLocal.getUserLocale()));
                    mapEntryList.add(mapEntry);

                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.PROFIT_AMOUNT + "_CurrCode");
                    mapEntry.setValue(dealDetails.getF_IsoCurrencyCode());
                    mapEntryList.add(mapEntry);
                }

                if ((dealDetails.getF_DealAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.DEAL_AMOUNT);
                    mapEntry.setValue(panelUtil.convertCurrencyForLocale(dealAmnt, dealDetails.getF_IsoCurrencyCode(),
                        BankFusionThreadLocal.getUserLocale()));
                    mapEntryList.add(mapEntry);

                    mapEntry = new RequestDataEntry();
                    mapEntry.setKey(IBHeaderConstants.DEAL_AMOUNT + "_CurrCode");
                    mapEntry.setValue(dealDetails.getF_IsoCurrencyCode());
                    mapEntryList.add(mapEntry);
                }
            }
        }
    }

    private void createMapEntriesArrayFromDealDetails(IBOIB_DLI_DealDetails applicationDetails, ArrayList<RequestDataEntry> mapEntryList) {
        if (applicationDetails != null) {
            RequestDataEntry mapEntry = null;
            if ((applicationDetails.getF_DealAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.DEAL_AMOUNT);
                mapEntry.setValue(panelUtil.convertCurrencyForLocale(applicationDetails.getF_DealAmt(),
                    applicationDetails.getF_IsoCurrencyCode(), BankFusionThreadLocal.getUserLocale()));
                mapEntryList.add(mapEntry);
            }
            mapEntry = new RequestDataEntry();
            mapEntry.setKey(IBHeaderConstants.DEAL_AMOUNT + "_CurrCode");
            mapEntry.setValue(applicationDetails.getF_IsoCurrencyCode());
            mapEntryList.add(mapEntry);
            
            if ((applicationDetails.getF_DealTerm()) > CommonConstants.INTEGER_ZERO
                || (applicationDetails.getF_ProfitAmt()).compareTo(CommonConstants.BIGDECIMAL_ZERO) != CommonConstants.INTEGER_ZERO) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.PROFIT_AMOUNT);
                mapEntry.setValue(panelUtil.convertCurrencyForLocale(applicationDetails.getF_ProfitAmt(),
                    applicationDetails.getF_IsoCurrencyCode(), BankFusionThreadLocal.getUserLocale()));
                mapEntryList.add(mapEntry);

                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.PROFIT_AMOUNT + "_CurrCode");
                mapEntry.setValue(applicationDetails.getF_IsoCurrencyCode());
                mapEntryList.add(mapEntry);
            }
            if ((applicationDetails.getF_DealTerm()) > CommonConstants.INTEGER_ZERO) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.DEAL_TENOR);
                mapEntry.setValue(CalendarUtil.getPeriodDurationInString(applicationDetails.getF_DEALEFFECTIVEDT(),
                    applicationDetails.getF_LastRepaymentDate()));
                mapEntryList.add(mapEntry);

                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.DEAL_TENOR_TERM_CODE);
                mapEntry.setValue(CalendarUtil.getPeriodDurationInString(applicationDetails.getF_DEALEFFECTIVEDT(),
                    applicationDetails.getF_LastRepaymentDate()));
                mapEntryList.add(mapEntry);
            }
            if ((applicationDetails.getF_LastRepaymentDate())
                .compareTo(applicationDetails.getF_DealStartDate()) > CommonConstants.INTEGER_ZERO) {
                mapEntry = new RequestDataEntry();
                mapEntry.setKey(IBHeaderConstants.NEW_END_DATE);
                mapEntry.setValue(ConvertToDate.run(ConvertToString.run(applicationDetails.getF_LastRepaymentDate(), -1)));
                mapEntryList.add(mapEntry);
            }
        }

    }
}
