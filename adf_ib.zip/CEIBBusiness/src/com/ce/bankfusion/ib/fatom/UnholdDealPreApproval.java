package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealHoldDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_UnholdDealPreApproval;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class UnholdDealPreApproval extends AbstractCE_IB_UnholdDealPreApproval{
    private static String isDealHoldQuery = " WHERE " + IBOCE_IB_DealHoldDtls.IBDEALID + " = ? ";
    
    public UnholdDealPreApproval() {
        super();
    }
    @SuppressWarnings("deprecation")
    public UnholdDealPreApproval(BankFusionEnvironment env) {
        super(env);
    }
    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
        
        String dealId = getF_IN_islamicBankingObject().getDealID();
        
        ArrayList<String> params = new ArrayList<>();
        params.add(dealId);
        
        List<IBOCE_IB_DealHoldDtls> holdDtlsList = IBCommonUtils.getPersistanceFactory().findByQuery(
            IBOCE_IB_DealHoldDtls.BONAME, isDealHoldQuery.toString(), params, null, false);
        
        if (holdDtlsList != null && !holdDtlsList.isEmpty()) {
            IBOCE_IB_DealHoldDtls dealHoldDetails = holdDtlsList.get(CommonConstants.INTEGER_ZERO);
            String reason = dealHoldDetails.getF_IBUNHOLDREASON();
            String reason1 = dealHoldDetails.getF_IBUNHOLDREASON();
            
            setF_OUT_reason(dealHoldDetails.getF_IBUNHOLDREASON());
          }
        
    }
}
