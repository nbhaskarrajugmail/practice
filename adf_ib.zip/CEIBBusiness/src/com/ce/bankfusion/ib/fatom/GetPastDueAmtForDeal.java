package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.HashMap;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetPastDueAmtForDeal;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.InputOutputConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadDealPayOffDtlsRq;
import bf.com.misys.ib.spi.types.messages.ReadDealPayOffDtlsRs;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AccountInput;
import bf.com.misys.ib.types.DealIDInput;

public class GetPastDueAmtForDeal extends AbstractCE_IB_GetPastDueAmtForDeal {

    private static final long serialVersionUID = -2637816799576358202L;

    public GetPastDueAmtForDeal(BankFusionEnvironment env) {
        super(env);
    }

    public GetPastDueAmtForDeal() {
        super();

    }

    @Override
    public void process(BankFusionEnvironment env) {
        String dealId = getF_IN_DealID();
        ReadLoanDetailsRs readLonaRes = IBCommonUtils.getLoanDetails(dealId);
        BigDecimal disbAmt = readLonaRes.getDealDetails().getLoanBasicDetails().getTotalDisbursementAmount();
        BigDecimal amount = BigDecimal.ZERO;
        BigDecimal pastDueAmnt = BigDecimal.ZERO;
        Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
        if (disbAmt.compareTo(BigDecimal.ZERO) > 0) {
            IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
            ReadDealPayOffDtlsRq readDealPayOffDtlsRq = new ReadDealPayOffDtlsRq();
            AccountInput dealAccountNo = new AccountInput();
            dealAccountNo.setAccountFormatType(RescheduleConstants.ACCOUNT_FORMAT_TYPE);
            dealAccountNo.setAccountID(dealDetails.getF_DealAccountId());
            readDealPayOffDtlsRq.setLoanAccountNumber(dealAccountNo);
            DealIDInput dealID = new DealIDInput();
            dealID.setDealBranch(dealDetails.getF_BranchSortCode());
            dealID.setDealID(dealId);
            dealID.setSubProductID(dealDetails.getF_ProductContextCode());
            readDealPayOffDtlsRq.setDealID(dealID);
            readDealPayOffDtlsRq.setSettlementCurrency(dealDetails.getF_IsoCurrencyCode());
            HashMap param = new HashMap();
            param.put(InputOutputConstants.READDEALPAYOFFDTLSRQ, readDealPayOffDtlsRq);
            HashMap<String, Object> outputParam = null;
            outputParam = MFExecuter.executeMF(RescheduleConstants.IB_SPI_ReadLoanPayOffDetails_SRV, env, param);

            ReadDealPayOffDtlsRs readDealPayOffDtlsRs;
            if (null != outputParam) {
                readDealPayOffDtlsRs = (ReadDealPayOffDtlsRs) outputParam.get(InputOutputConstants.READDEALPAYOFFDTLSRS);

                LoanPayments[] loanPayments = readLonaRes.getDealDetails().getPaymentSchedule();
                for (int i = 0; i < loanPayments.length; i++) {
                    if (loanPayments[i].getRepaymentDate().toString().compareTo(businessDate.toString()) < 0) {
                        if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                            || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.UNPAID)
                            || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                            pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                        }
                   } else if (loanPayments[i].getRepaymentDate().toString().compareTo(businessDate.toString()) == 0) {
                        if ((null != BankFusionPropertySupport.getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME,
                            IBConstants.IB_HOST, "false")
                            && BankFusionPropertySupport
                                .getProperty(BankFusionPropertySupport.BANKFUSION_PROPERTY_FILE_NAME, IBConstants.IB_HOST, "false").equals("ES"))) {
                            if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                                || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)
                                || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.FULLY_PAID)) {
                                 pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                           }
                         } else {
                            if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.ARREAR)
                                || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.UNPAID)
                                || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                                pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                           }
                         }
                    } else {
                        if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.FULLY_PAID)
                            || loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {

                            if (loanPayments[i].getRepaymentStatus().equals(RescheduleConstants.PARTIALLY_PAID)) {
                                pastDueAmnt = pastDueAmnt.add(loanPayments[i].getRepaymentAmtUnPaid());
                            }
                        }
                    }
                    
                }       
                amount = pastDueAmnt;
            }
        }
        setF_OUT_pastDueAmount(amount);
    }
}
