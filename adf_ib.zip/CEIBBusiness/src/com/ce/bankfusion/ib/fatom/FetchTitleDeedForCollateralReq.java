package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_FetchTitleDeedForCollateralReq;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class FetchTitleDeedForCollateralReq extends AbstractCE_IB_FetchTitleDeedForCollateralReq{

	public FetchTitleDeedForCollateralReq() {
        super();
	}
	@SuppressWarnings("deprecation")
    public FetchTitleDeedForCollateralReq(BankFusionEnvironment env) {
		
    }
	
	@Override
    public void process(BankFusionEnvironment env) throws BankFusionException  {
		
	ListTitleDeedIdDtlsType listTitleDeedDDetails = new ListTitleDeedIdDtlsType();
	TitleDeedDetailsType titleDeedDtls= new TitleDeedDetailsType();
	ListTitleDeedIdDtlsType searchTitleDeedRs = getF_IN_searchTitleDeedDtlsRs().getListTitleDeedIdDtls();
	for(TitleDeedDetailsType listTitleDeedDtls: searchTitleDeedRs.getTitleDeedDetails()) {
		if(listTitleDeedDtls.getTitleDeedIdpk().equals(getF_IN_idpk())) {
			titleDeedDtls.setAreaSize(listTitleDeedDtls.getAreaSize());
			titleDeedDtls.setTitleDeedIdpk(listTitleDeedDtls.getTitleDeedIdpk());
			titleDeedDtls.setDicissionStatus(listTitleDeedDtls.getDicissionStatus());
			titleDeedDtls.setFarmLocation(listTitleDeedDtls.getFarmLocation());
			titleDeedDtls.setLandPlanNumber(listTitleDeedDtls.getLandPlanNumber());
			titleDeedDtls.setLandPlotNumber(listTitleDeedDtls.getLandPlotNumber());
			titleDeedDtls.setLinkedToCollateral(listTitleDeedDtls.getLinkedToCollateral());
			titleDeedDtls.setNotes(listTitleDeedDtls.getNotes());
			titleDeedDtls.setReasonForChange(listTitleDeedDtls.getReasonForChange());
			titleDeedDtls.setRetailIndex(listTitleDeedDtls.getRetailIndex());
			titleDeedDtls.setSplitIndicator(listTitleDeedDtls.getSplitIndicator());
			titleDeedDtls.setStatus(listTitleDeedDtls.getStatus());
			titleDeedDtls.setTitleDeedNumber(listTitleDeedDtls.getTitleDeedNumber());
			titleDeedDtls.setTitleDeedSource(listTitleDeedDtls.getTitleDeedSource());
			titleDeedDtls.setTitleDeedStatus(listTitleDeedDtls.getTitleDeedStatus());
			titleDeedDtls.setTitleDeedType(listTitleDeedDtls.getTitleDeedType());
			titleDeedDtls.setTitleDeedYear(listTitleDeedDtls.getTitleDeedYear());
			titleDeedDtls.setTransactionDate(listTitleDeedDtls.getTransactionDate());
			titleDeedDtls.setTransactionNotes(listTitleDeedDtls.getTransactionNotes());
			titleDeedDtls.setTransactionType(listTitleDeedDtls.getTransactionType());
			titleDeedDtls.setValidFrom(listTitleDeedDtls.getValidFrom());
			titleDeedDtls.setValidFromHijri(listTitleDeedDtls.getValidFromHijri());
			titleDeedDtls.setValidTo(listTitleDeedDtls.getValidTo());
			titleDeedDtls.setValidToHijri(listTitleDeedDtls.getValidToHijri());	
			titleDeedDtls.setVersionNumber(listTitleDeedDtls.getVersionNumber());
		}
	}
	setF_OUT_titleDeedDtlsType(titleDeedDtls);

}
}
