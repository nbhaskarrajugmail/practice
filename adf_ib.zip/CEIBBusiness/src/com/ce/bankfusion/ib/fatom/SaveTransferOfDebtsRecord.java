package com.ce.bankfusion.ib.fatom;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveTransferOfDebtsRecord;
import com.ce.bankfusion.ib.steps.refimpl.ICE_IB_SaveTransferOfDebtsRecord;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.util.ThirdPartyPaymentScheduleUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.TransferDebtsHistory;

public class SaveTransferOfDebtsRecord extends AbstractCE_IB_SaveTransferOfDebtsRecord
		implements ICE_IB_SaveTransferOfDebtsRecord {

	public SaveTransferOfDebtsRecord() {
		super();
	}

	public SaveTransferOfDebtsRecord(BankFusionEnvironment env) {
		super(env);
	}

	private static final transient Log LOGGER = LogFactory.getLog(SaveTransferOfDebtsRecord.class.getName());

	@Override
	public void process(BankFusionEnvironment env) {
		LOGGER.info("Entering into process method");
		for (TransferDebtsHistory transferDebtsHistory : getF_IN_transferDebtsHistoryRq()
				.getTransferDebtsHistorylist()) {
			if (transferDebtsHistory.isSelect()) {
				if(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(getF_IN_transferDebtsScheduledRq().getTransferReqDate()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TRANSFER_DEBT_REQ_DT_MANDATORY_CEIB);
				if(IBCommonUtils.isEmpty(getF_IN_transferDebtsScheduledRq().getDocNumber()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_DOCUMENT_NO_MANDATORY_CEIB);
				if(null == ThirdPartyPaymentScheduleUtil.clearDateDefaultValue(getF_IN_transferDebtsScheduledRq().getDocDate()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_DOCUMENT_DT_MANDATORY_CEIB);
				if(IBCommonUtils.isEmpty(getF_IN_transferDebtsScheduledRq().getReasonCode()))
					IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_TD_REASON_MANDATORY_CEIB);
				transferDebtsHistory.setContinueSubsidy(getF_IN_transferDebtsScheduledRq().getContinueSubsidy());
				transferDebtsHistory.setReschRequired(getF_IN_transferDebtsScheduledRq().getReschRequired());
				transferDebtsHistory.setTransferReqDate(getF_IN_transferDebtsScheduledRq().getTransferReqDate());
				transferDebtsHistory.setDocDate(getF_IN_transferDebtsScheduledRq().getDocDate());
				transferDebtsHistory.setDocNumber(getF_IN_transferDebtsScheduledRq().getDocNumber());
				transferDebtsHistory.setReasonCode(getF_IN_transferDebtsScheduledRq().getReasonCode());
				String reasonDesc = IBCommonUtils.getGCChildDesc(CeConstants.TD_REASON_GC_PARENT_REF,
						getF_IN_transferDebtsScheduledRq().getReasonCode());
				transferDebtsHistory.setReasonDesc(reasonDesc);
				transferDebtsHistory.setNotes(getF_IN_transferDebtsScheduledRq().getNotes());
				break;
			}
		}
		getF_OUT_transferDebtsHistoryRq()
				.setTransferDebtsHistorylist(getF_IN_transferDebtsHistoryRq().getTransferDebtsHistorylist());
		LOGGER.info("Exiting from process method");

	}

}
