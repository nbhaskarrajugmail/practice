package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOAssetDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePODetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOLiabilityDetail;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePOPayDetail;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_IssuePOFatom;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_TXN_PAYRECDETAIL;
import com.misys.bankfusion.ib.fatom.CollectFeeProcessing;
import com.misys.bankfusion.ib.fatom.LoadFeesToCollect;
import com.misys.bankfusion.ib.fatom.RegisterCollectFeesForAE;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.AccEntriesRegistrationDtls;
import bf.com.misys.ib.types.Amount;
import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.FeeToBeCollected;
import bf.com.misys.ib.types.FeeToBeCollectedList;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PaymentDetails;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.PurchaseOrderDetails;

public class IssuePOFatom extends AbstractCE_IB_IssuePOFatom{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(IssuePOFatom.class.getName());
	
	public static final String SAVE = "SAVE";
	public static final String RETRIEVE = "RETRIEVE";
	private static final String BB_ID = "ISSUEPAYMNTORDERH";
	
	private static String GET_ISSUEPO_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_IssuePODetail.IBDEALID+" = ?";
	private static String ISSUEPOASSETS_BY_ISSUEPO = " WHERE "+IBOCE_IB_IssuePOAssetDetail.IBPURCHASEORDERID+" = ?";
	private static String LIABILITIES_BY_ISSUEPO = " WHERE "+IBOCE_IB_IssuePOLiabilityDetail.IBPURCHASEORDERID+" = ?";
	private static String PAYMENTS_BY_ISSUEPO = " WHERE "+IBOCE_IB_IssuePOPayDetail.IBPURCHASEORDERID+" = ?";
	
	private static String DELETE_ISSUEPO_BY_ISSUEPO = " WHERE "+IBOCE_IB_IssuePODetail.IBPURCHASEORDERID+" = ?";
	
	public static String PAYMENTORDER_CONTEXT = "PAYMENTORDER";
	public static String COMMISSION_CONTEXT = "COMMISSION";
	public static String UPFRONTPROFIT_CONTEXT = "UPFRONTPROFIT";
	private static final String SELECT_PAYRECDETAIL = " WHERE " + IBOIB_TXN_PAYRECDETAIL.DEALNO + " =? AND "
			+ IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + " = ? OR " + IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + " = ? OR "
			+ IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + " = ? OR " + IBOIB_TXN_PAYRECDETAIL.AMOUNTTYPE + "=? AND "
			+ IBOIB_TXN_PAYRECDETAIL.TRANSACTIONSTATUS + " =? OR " + IBOIB_TXN_PAYRECDETAIL.TRANSACTIONSTATUS + " =?";

	
	@SuppressWarnings("deprecation")
    public IssuePOFatom(BankFusionEnvironment env) {
        super(env);
    }
        
    public void process(BankFusionEnvironment env) {
    	System.err.println();
    	if(getF_IN_mode().equalsIgnoreCase(SAVE)) {
    		IBOIB_CFG_BuildingBlockConfig bbConfig = IBCommonUtils.getConfiguredBuildingBlock(BB_ID, getF_IN_islamicBankingObject().getProductID(), getF_IN_islamicBankingObject().getSubProductID(), getF_IN_islamicBankingObject().getStepID(), getF_IN_islamicBankingObject().getProcessConfigID());
    		if (bbConfig.getF_BUILDINGBLOCKMODE().contains("EDIT")) {
    			save();
    		}
    		if (getF_IN_islamicBankingObject().getStepID().equals("PROCESS")||getF_IN_islamicBankingObject().getStepID().equals("STEPTWELVE")||getF_IN_islamicBankingObject().getStepID().equals("STEPNINE")) {
                IssuePayOrderDtls issuePayOrderDtls = getF_IN_issuePayOrderDtls();
                String selectedPurchaseOrderId = "";
                for (PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
                    if (!((poDetail.getPoStatus().equalsIgnoreCase("Processed"))||(poDetail.getPoStatus().equalsIgnoreCase("Completed")))) {
    					selectedPurchaseOrderId = poDetail.getPurchaseOrderID();
    					List<PaymentDetails> paymentDetails = new ArrayList<>();
    					for(PaymentDetails paymentDetail : issuePayOrderDtls.getPaymentDetails()) {
    						if(selectedPurchaseOrderId.equals(paymentDetail.getPurchaseOrderID())) {
    							paymentDetails.add(paymentDetail);
    						}
    					}
    					postAccountingEntries(poDetail, paymentDetails);
    					collectFeesAPI(poDetail.getFeesToBePaid(), poDetail.getAdjustmentFeesToBePaid());
    				}
    			}
    		}
    	}else if(getF_IN_mode().equalsIgnoreCase(RETRIEVE)){
    		retrieve(env);
    	}
    }

	private void save() {
		IssuePayOrderDtls issuePayOrderDtls = getF_IN_issuePayOrderDtls();
		String selectedPurchaseOrderId = "";
		if(issuePayOrderDtls.getPurchaseOrderDetailsCount()==0) {
			IBCommonUtils.raiseUnparameterizedEvent(44000417);
		}
		boolean isPOAvailable = false;
		for(PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
            if(poDetail.getPoStatus().equalsIgnoreCase("New")){
			   isPOAvailable = true; 
               break;
			 }
         }
       if(!isPOAvailable) {
        IBCommonUtils.raiseUnparameterizedEvent(44000417);
       }
		for(PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
			if(!(poDetail.getPoStatus().equalsIgnoreCase("Disbursed")||poDetail.getPoStatus().equalsIgnoreCase("Completed"))) {
				selectedPurchaseOrderId = poDetail.getPurchaseOrderID();
				deleteIssuePO(poDetail.getPurchaseOrderID());
				deleteIssuePOAssetDetails(poDetail.getPurchaseOrderID());
				deleteIssuePOLiabilityDetails(poDetail.getPurchaseOrderID());
				deleteIssuePOPaymentDetails(poDetail.getPurchaseOrderID());
				insertIssuePODetail(poDetail);
				for(PoAssetDisbursementDetails assetDetail : issuePayOrderDtls.getPoAssetDisbursementDetails()) {
					if(selectedPurchaseOrderId.equals(assetDetail.getPurchaseOrderID())) {
						insertPOAssetDetail(assetDetail);
					}
				}
				for(CustomerLiabilities liability : issuePayOrderDtls.getCustomerLiabilitiesDtls()) {
					if(selectedPurchaseOrderId.equals(liability.getPurchaseOrderID())) {
						insertCustomerLiability(liability);
					}
				}
				int count =1;
				List<PaymentDetails> paymentDetails = new ArrayList<>();
				for(PaymentDetails paymentDetail : issuePayOrderDtls.getPaymentDetails()) {
					if(selectedPurchaseOrderId.equals(paymentDetail.getPurchaseOrderID())) {
						insertPaymentDetail(paymentDetail, count++);
						paymentDetails.add(paymentDetail);
					}
				}
				/*postAccountingEntries(poDetail, paymentDetails);
				collectFeesAPI(poDetail.getFeesToBePaid(), poDetail.getAdjustmentFeesToBePaid());*/
			}
		}
	}

	private void insertPaymentDetail(PaymentDetails paymentDetail, int count) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_IssuePOPayDetail issuePOPayDetailBOD = (IBOCE_IB_IssuePOPayDetail) factory.getStatelessNewInstance(IBOCE_IB_IssuePOPayDetail.BONAME);
		issuePOPayDetailBOD.setBoID(GUIDGen.getNewGUID());
		issuePOPayDetailBOD.setF_IBPURCHASEORDERID(paymentDetail.getPurchaseOrderID());
		issuePOPayDetailBOD.setF_IBSERIAL(count);
		issuePOPayDetailBOD.setF_IBPAYMENTOPTION(paymentDetail.getPaymentOption());
		issuePOPayDetailBOD.setF_IBCUSTOMERNAME(paymentDetail.getBeneficiaryName());
		issuePOPayDetailBOD.setF_IBTHIRDPARTYID(paymentDetail.getThirdPartyID());
		issuePOPayDetailBOD.setF_IBRELATIONSHIPID(paymentDetail.getRelationshipPartyID());
		issuePOPayDetailBOD.setF_IBBENIFICIARYBANK(paymentDetail.getBeneficiaryBank());
		issuePOPayDetailBOD.setF_IBIBAN(paymentDetail.getBeneficiaryIBAN());
		issuePOPayDetailBOD.setF_IBDEBITBANK(paymentDetail.getDebitBank());
		issuePOPayDetailBOD.setF_IBDEBITACCOUNTID(paymentDetail.getDebitAccount());
		issuePOPayDetailBOD.setF_IBDEBITBANKIBAN(paymentDetail.getDebitIBANAccount());
		issuePOPayDetailBOD.setF_IBPAYMENTAMOUNT(paymentDetail.getPaymentAmount().getCurrencyAmount());
		issuePOPayDetailBOD.setF_IBPENDINGAMOUNT(paymentDetail.getRemainingPaymentAmount().getCurrencyAmount());
		issuePOPayDetailBOD.setF_IBINVOICENUMBER(paymentDetail.getInvoiceNumber());
		issuePOPayDetailBOD.setF_IBINVOICEDATE(paymentDetail.getInvoiceDate());
		issuePOPayDetailBOD.setF_IBCURRENCYCODE(paymentDetail.getPaymentCurrency());
		issuePOPayDetailBOD.setF_IBEXCHANGERATE(paymentDetail.getPaymentExchangeRate());
		issuePOPayDetailBOD.setF_IBAMOUNTINFX(paymentDetail.getPaymentAmountInOtherCurrency().getCurrencyAmount());
		issuePOPayDetailBOD.setF_IBTRANSFERID(paymentDetail.getTransferID());
		issuePOPayDetailBOD.setF_IBTRANSFERDATE(paymentDetail.getTransferDate());
		issuePOPayDetailBOD.setF_IBNOTES(paymentDetail.getPaymentNotes());
		factory.create(IBOCE_IB_IssuePOPayDetail.BONAME, issuePOPayDetailBOD);
	}

	private void insertCustomerLiability(CustomerLiabilities liability) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_IssuePOLiabilityDetail issuePOLiabilityDetailBOD = (IBOCE_IB_IssuePOLiabilityDetail) factory.getStatelessNewInstance(IBOCE_IB_IssuePOLiabilityDetail.BONAME);
		issuePOLiabilityDetailBOD.setBoID(GUIDGen.getNewGUID());
		issuePOLiabilityDetailBOD.setF_IBPURCHASEORDERID(liability.getPurchaseOrderID());
		issuePOLiabilityDetailBOD.setF_IBDEALID(liability.getDealId());
		issuePOLiabilityDetailBOD.setF_IBCUSTOMERROLE(liability.getUserRole());
		issuePOLiabilityDetailBOD.setF_IBLIABILITYPAID(liability.getLiabilityToBePaid().getCurrencyAmount());
		issuePOLiabilityDetailBOD.setF_IBOUTSTANDINGAMOUNT(liability.getLiabilityAmount().getCurrencyAmount());
		factory.create(IBOCE_IB_IssuePOLiabilityDetail.BONAME, issuePOLiabilityDetailBOD);
	}

	private void insertPOAssetDetail(PoAssetDisbursementDetails assetDetail) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_IssuePOAssetDetail issueAssetPODetailBOD = (IBOCE_IB_IssuePOAssetDetail) factory.getStatelessNewInstance(IBOCE_IB_IssuePOAssetDetail.BONAME);
		issueAssetPODetailBOD.setBoID(GUIDGen.getNewGUID());
		issueAssetPODetailBOD.setF_IBPURCHASEORDERID(assetDetail.getPurchaseOrderID());
		issueAssetPODetailBOD.setF_IBASSETID(assetDetail.getAssetID());
		issueAssetPODetailBOD.setF_IBAMOUNT(assetDetail.getCurrentDisbursedAmount().getCurrencyAmount());
		issueAssetPODetailBOD.setF_IBDISBURSEDAMOUNT(assetDetail.getPrevouslyDisbursedAmount().getCurrencyAmount());
		issueAssetPODetailBOD.setF_IBPENDINGDISBURSED(assetDetail.getPendingDisbursedAmount().getCurrencyAmount());
		factory.create(IBOCE_IB_IssuePOAssetDetail.BONAME, issueAssetPODetailBOD);
	}

	private void insertIssuePODetail(PurchaseOrderDetails poDetail) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_IssuePODetail issuePODetailBOD = (IBOCE_IB_IssuePODetail) factory.getStatelessNewInstance(IBOCE_IB_IssuePODetail.BONAME);
		issuePODetailBOD.setBoID(GUIDGen.getNewGUID());
		issuePODetailBOD.setF_IBPURCHASEORDERID(poDetail.getPurchaseOrderID());
		issuePODetailBOD.setF_IBDEALID(getF_IN_islamicBankingObject().getDealID());
		issuePODetailBOD.setF_IBREPORTID(poDetail.getProgressReportID());
		issuePODetailBOD.setF_IBPODATEG(poDetail.getPoDateG());
		issuePODetailBOD.setF_IBPODATEH(poDetail.getPoDateH());
		issuePODetailBOD.setF_IBNOTES(poDetail.getNotes());
		issuePODetailBOD.setF_IBSTATUS(poDetail.getPoStatus());
		issuePODetailBOD.setF_IBPOAMOUNT(poDetail.getPoAmount().getCurrencyAmount());
		issuePODetailBOD.setF_IBREPORTAMOUNT(poDetail.getProgressReportAmount().getCurrencyAmount());
		issuePODetailBOD.setF_IBOUTSTANDINGLIABILITY(poDetail.getOutstandingLiability().getCurrencyAmount());
		issuePODetailBOD.setF_IBLIABILITYPAID(poDetail.getLiabilityToBePaid().getCurrencyAmount());
		issuePODetailBOD.setF_IBTAWAROOQCOMMISION(poDetail.getTawarooqCommision()!=null?poDetail.getTawarooqCommision():CommonConstants.BIGDECIMAL_ZERO);
		issuePODetailBOD.setF_IBFEEPAID(poDetail.getFeesToBePaid()!=null?poDetail.getFeesToBePaid():CommonConstants.BIGDECIMAL_ZERO);
		issuePODetailBOD.setF_IBNEWOUTSTANDINGFEE(poDetail.getNewOutstandingFees());
		issuePODetailBOD.setF_IBUPFRONTFEE(poDetail.getUpfrontProfitToBePaid());
		issuePODetailBOD.setF_IBNEWUPFRONTFEE(poDetail.getNewOutstandingUpfrontProfit());
		issuePODetailBOD.setF_IBADJUSTMENTFEE(poDetail.getAdjustmentFeesToBePaid());
		issuePODetailBOD.setF_IBNEWADJUSTMENTFEE(poDetail.getNewOutstandingAdjustFees());
		issuePODetailBOD.setF_IBFINALDISBURSEMENTAMT(poDetail.getFinalDisbursementAmount().getCurrencyAmount());
		factory.create(IBOCE_IB_IssuePODetail.BONAME, issuePODetailBOD);
	}

	public static void deleteIssuePOPaymentDetails(String purchaseOrderID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(purchaseOrderID);
		factory.bulkDelete(IBOCE_IB_IssuePOPayDetail.BONAME, PAYMENTS_BY_ISSUEPO, params);
	}

	public static  void deleteIssuePOLiabilityDetails(String purchaseOrderID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(purchaseOrderID);
		factory.bulkDelete(IBOCE_IB_IssuePOLiabilityDetail.BONAME, LIABILITIES_BY_ISSUEPO, params);
	}

	public static  void deleteIssuePOAssetDetails(String purchaseOrderID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(purchaseOrderID);
		factory.bulkDelete(IBOCE_IB_IssuePOAssetDetail.BONAME, ISSUEPOASSETS_BY_ISSUEPO, params);
	}

	public static  void deleteIssuePO(String purchaseOrderID) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(purchaseOrderID);
		factory.bulkDelete(IBOCE_IB_IssuePODetail.BONAME, DELETE_ISSUEPO_BY_ISSUEPO, params);
	}

	private void retrieve(BankFusionEnvironment env) {
		IssuePayOrderDtls issuePayOrderDtls = new IssuePayOrderDtls();
		populateIssuePODetails(issuePayOrderDtls);
		populateAssetDisbursementDetails(issuePayOrderDtls);
		populateIssuePOLiabilityDetails(issuePayOrderDtls);
		populatePaymentDetails(issuePayOrderDtls);
		setF_OUT_issuePayOrderDtls(issuePayOrderDtls);
	}
	
	private void populatePaymentDetails(IssuePayOrderDtls issuePayOrderDtls) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		for(PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
			ArrayList<String> params = new ArrayList<>();
			params.add(poDetail.getPurchaseOrderID());
			List<IBOCE_IB_IssuePOPayDetail> payDetailListDB = factory.findByQuery(IBOCE_IB_IssuePOPayDetail.BONAME, PAYMENTS_BY_ISSUEPO, params, null, true);
			for(IBOCE_IB_IssuePOPayDetail payDetailDB : payDetailListDB) {
				PaymentDetails paymentDetail = new PaymentDetails();
				paymentDetail.setPaymentSerial(payDetailDB.getF_IBSERIAL());
				paymentDetail.setPurchaseOrderID(payDetailDB.getF_IBPURCHASEORDERID());
				paymentDetail.setPaymentOption(payDetailDB.getF_IBPAYMENTOPTION());
				paymentDetail.setBeneficiaryName(payDetailDB.getF_IBCUSTOMERNAME());
				paymentDetail.setThirdPartyID(payDetailDB.getF_IBTHIRDPARTYID());
				paymentDetail.setRelationshipPartyID(payDetailDB.getF_IBRELATIONSHIPID());
				paymentDetail.setBeneficiaryBank(payDetailDB.getF_IBBENIFICIARYBANK());
				paymentDetail.setBeneficiaryIBAN(payDetailDB.getF_IBIBAN());
				paymentDetail.setDebitBank(payDetailDB.getF_IBDEBITBANK());
				paymentDetail.setDebitAccount(payDetailDB.getF_IBDEBITACCOUNTID());
				paymentDetail.setDebitIBANAccount(payDetailDB.getF_IBDEBITBANKIBAN());
				
				BFCurrencyAmount paymentAmount = new BFCurrencyAmount();
				paymentAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				paymentAmount.setCurrencyAmount(payDetailDB.getF_IBPAYMENTAMOUNT());
				paymentDetail.setPaymentAmount(paymentAmount);
				
				BFCurrencyAmount rpAmount = new BFCurrencyAmount();
				rpAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				rpAmount.setCurrencyAmount(payDetailDB.getF_IBPENDINGAMOUNT());
				paymentDetail.setRemainingPaymentAmount(rpAmount);
				
				paymentDetail.setInvoiceNumber(payDetailDB.getF_IBINVOICENUMBER());
				paymentDetail.setInvoiceDate(payDetailDB.getF_IBINVOICEDATE());
				paymentDetail.setPaymentCurrency(payDetailDB.getF_IBCURRENCYCODE());
				paymentDetail.setPaymentExchangeRate(payDetailDB.getF_IBEXCHANGERATE());
				
				BFCurrencyAmount piocAmount = new BFCurrencyAmount();
				piocAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				piocAmount.setCurrencyAmount(payDetailDB.getF_IBAMOUNTINFX());
				paymentDetail.setPaymentAmountInOtherCurrency(piocAmount);
				
				paymentDetail.setTransferID(payDetailDB.getF_IBTRANSFERID());
				paymentDetail.setTransferDate(payDetailDB.getF_IBTRANSFERDATE());
				paymentDetail.setPaymentNotes(payDetailDB.getF_IBNOTES());
				issuePayOrderDtls.addPaymentDetails(paymentDetail);
			}
		}
	}

	private void populateIssuePOLiabilityDetails(IssuePayOrderDtls issuePayOrderDtls) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		for(PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
			ArrayList<String> params = new ArrayList<>();
			params.add(poDetail.getPurchaseOrderID());
			List<IBOCE_IB_IssuePOLiabilityDetail> poLiabilityListDB = factory.findByQuery(IBOCE_IB_IssuePOLiabilityDetail.BONAME, LIABILITIES_BY_ISSUEPO, params, null, true);
			for(IBOCE_IB_IssuePOLiabilityDetail liabilityDB : poLiabilityListDB) {
				CustomerLiabilities liability = new CustomerLiabilities();
				liability.setPurchaseOrderID(liabilityDB.getF_IBPURCHASEORDERID());
				liability.setUserRole(liabilityDB.getF_IBCUSTOMERROLE());
				
				BFCurrencyAmount liabilityAmount = new BFCurrencyAmount();
				liabilityAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				liabilityAmount.setCurrencyAmount(liabilityDB.getF_IBOUTSTANDINGAMOUNT());
				liability.setLiabilityAmount(liabilityAmount);
				
				BFCurrencyAmount tobePaidAmount = new BFCurrencyAmount();
				tobePaidAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				tobePaidAmount.setCurrencyAmount(liabilityDB.getF_IBLIABILITYPAID());
				liability.setLiabilityToBePaid(tobePaidAmount);
				liability.setDealId(liabilityDB.getF_IBDEALID());
				liability.setDealAccountID(IBCommonUtils.getDealDetails(liabilityDB.getF_IBDEALID()).getF_DealAccountId());
				issuePayOrderDtls.addCustomerLiabilitiesDtls(liability);
			}
		}
	}

	private void populateAssetDisbursementDetails(IssuePayOrderDtls issuePayOrderDtls) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		
		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		assetProgressingFatom.setF_IN_mode("RETRIEVE");
		assetProgressingFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		
		for(PurchaseOrderDetails poDetail : issuePayOrderDtls.getPurchaseOrderDetails()) {
			ArrayList<String> params = new ArrayList<>();
			params.add(poDetail.getPurchaseOrderID());
			List<IBOCE_IB_IssuePOAssetDetail> poAssetListDB = factory.findByQuery(IBOCE_IB_IssuePOAssetDetail.BONAME, ISSUEPOASSETS_BY_ISSUEPO, params, null, true);
			for(IBOCE_IB_IssuePOAssetDetail assetPODetailDB : poAssetListDB) {
				PoAssetDisbursementDetails asset = new PoAssetDisbursementDetails();
				asset.setPurchaseOrderID(assetPODetailDB.getF_IBPURCHASEORDERID());
				//get progress report amount of asset by assetid and reportid
				String reportId = poDetail.getProgressReportID();
				
				asset.setAssetID(assetPODetailDB.getF_IBASSETID());
				
				BFCurrencyAmount pdAmount = new BFCurrencyAmount();
				pdAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				pdAmount.setCurrencyAmount(assetPODetailDB.getF_IBDISBURSEDAMOUNT());
				asset.setPrevouslyDisbursedAmount(pdAmount);
				if (reportId.equals("AdvancePayment")) {
					asset.setOriginalAssetStudyCost(pdAmount);
					asset.setOriginalFinalCost(pdAmount);
				} else {
					for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
							.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
						if (assetProgressDetails.getReportID().equals(reportId)
								&& assetProgressDetails.getAssetID().equals(assetPODetailDB.getF_IBASSETID())) {
							asset.setAssetCategory(assetProgressDetails.getAssetCategory());
							asset.setOriginalAssetStudyCost(assetProgressDetails.getNetCalculatedCost());
							asset.setOriginalFinalCost(assetProgressDetails.getNetFinalCost());
						}
					}
				}
				BFCurrencyAmount pdiAmount = new BFCurrencyAmount();
				pdiAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				pdiAmount.setCurrencyAmount(assetPODetailDB.getF_IBPENDINGDISBURSED());
				asset.setPendingDisbursedAmount(pdiAmount);
				
				BFCurrencyAmount cdiAmount = new BFCurrencyAmount();
				cdiAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
				cdiAmount.setCurrencyAmount(assetPODetailDB.getF_IBAMOUNT());
				asset.setCurrentDisbursedAmount(cdiAmount);
				
				issuePayOrderDtls.addPoAssetDisbursementDetails(asset);
			}
		}
	}
	

	private void populateIssuePODetails(IssuePayOrderDtls issuePayOrderDtls) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_islamicBankingObject().getDealID());
		List<IBOCE_IB_IssuePODetail> assetProgressPricingListDB = factory.findByQuery(IBOCE_IB_IssuePODetail.BONAME, GET_ISSUEPO_BY_DEAL_QUERY, params, null, true);
		for(IBOCE_IB_IssuePODetail issuePODetailDB : assetProgressPricingListDB) {
			PurchaseOrderDetails poDetail = new PurchaseOrderDetails();
			poDetail.setDealId(issuePODetailDB.getF_IBDEALID());
			poDetail.setProgressReportID(issuePODetailDB.getF_IBREPORTID());
			poDetail.setPurchaseOrderID(issuePODetailDB.getF_IBPURCHASEORDERID());
			poDetail.setPoDateG(issuePODetailDB.getF_IBPODATEG());
			poDetail.setPoDateH(issuePODetailDB.getF_IBPODATEH());
			poDetail.setNotes(issuePODetailDB.getF_IBNOTES());
			poDetail.setPoStatus(issuePODetailDB.getF_IBSTATUS());
			
			BFCurrencyAmount reportAmount = new BFCurrencyAmount();
			reportAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			reportAmount.setCurrencyAmount(issuePODetailDB.getF_IBREPORTAMOUNT());
			poDetail.setProgressReportAmount(reportAmount);
			
			BFCurrencyAmount poAmount = new BFCurrencyAmount();
			poAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			poAmount.setCurrencyAmount(issuePODetailDB.getF_IBPOAMOUNT());
			poDetail.setPoAmount(poAmount);
			
			BFCurrencyAmount olAmount = new BFCurrencyAmount();
			olAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			olAmount.setCurrencyAmount(issuePODetailDB.getF_IBOUTSTANDINGLIABILITY());
			poDetail.setOutstandingLiability(olAmount);
			
			BFCurrencyAmount lpAmount = new BFCurrencyAmount();
			lpAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			lpAmount.setCurrencyAmount(issuePODetailDB.getF_IBLIABILITYPAID());
			poDetail.setLiabilityToBePaid(lpAmount);
			
			poDetail.setTawarooqCommision(issuePODetailDB.getF_IBTAWAROOQCOMMISION());
			poDetail.setFeesToBePaid(issuePODetailDB.getF_IBFEEPAID());
			poDetail.setNewOutstandingFees(issuePODetailDB.getF_IBNEWOUTSTANDINGFEE());
			poDetail.setUpfrontProfitToBePaid(issuePODetailDB.getF_IBUPFRONTFEE());
			poDetail.setNewOutstandingUpfrontProfit(issuePODetailDB.getF_IBNEWUPFRONTFEE());
			poDetail.setAdjustmentFeesToBePaid(issuePODetailDB.getF_IBADJUSTMENTFEE());
			poDetail.setNewOutstandingAdjustFees(issuePODetailDB.getF_IBNEWADJUSTMENTFEE());
			
			BFCurrencyAmount fdaAmount = new BFCurrencyAmount();
			fdaAmount.setCurrencyCode(getF_IN_islamicBankingObject().getCurrency());
			fdaAmount.setCurrencyAmount(issuePODetailDB.getF_IBFINALDISBURSEMENTAMT());
			poDetail.setFinalDisbursementAmount(fdaAmount);
			issuePayOrderDtls.addPurchaseOrderDetails(poDetail);
		}
	}
	private void postAccountingEntries(PurchaseOrderDetails purchaseOrderDetails, List<PaymentDetails> paymentDetails) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_DLI_DealDetails dealDetail = null;
		
          dealDetail = IBCommonUtils.getDealDetails(getF_IN_islamicBankingObject().getDealID());
          ArrayList params = new ArrayList();
          params.add(getF_IN_islamicBankingObject().getDealID());
          params.add(PAYMENTORDER_CONTEXT);
          params.add(COMMISSION_CONTEXT);
          params.add(UPFRONTPROFIT_CONTEXT);
          params.add("COLLECTFEES");
          params.add("SCHEDULED");
          params.add("Scheduled");
          
          factory.bulkDelete(IBOIB_TXN_PAYRECDETAIL.BONAME, SELECT_PAYRECDETAIL, params);
          //iterate the fee amounts and 
          String narrative = "Tawarooq comission for Deal:"+getF_IN_islamicBankingObject().getDealID()+" and Report Id : "+purchaseOrderDetails.getProgressReportID();
          
          defineAccountingEntries(dealDetail, purchaseOrderDetails.getTawarooqCommision(), IBCommonUtils.getModuleConfigurationValue("IB", "TawarooqComissionCreditAccount").getValue(), narrative, COMMISSION_CONTEXT);
          //defineAccountingEntries(dealDetail, issuePaymentOrders.getPurchaseOrderDetails(0).getFeesToBePaid(), accountid, narrative);
          //defineAccountingEntries(dealDetail, issuePaymentOrders.getPurchaseOrderDetails(0).getAdjustmentFeesToBePaid(), accountid, narrative);
          narrative = "Upfront Profit amount for Deal:"+getF_IN_islamicBankingObject().getDealID()+" and Report Id : "+purchaseOrderDetails.getProgressReportID();
          defineAccountingEntries(dealDetail, purchaseOrderDetails.getUpfrontProfitToBePaid(), IBCommonUtils.getModuleConfigurationValue("IB", "UpfrontProfitAmountCreditAccount").getValue(), narrative, UPFRONTPROFIT_CONTEXT);
          for(PaymentDetails payDetail : paymentDetails) {
        	  narrative = "Issue PO PayDetail for Deal:"+getF_IN_islamicBankingObject().getDealID()+", Report Id : "+purchaseOrderDetails.getProgressReportID();
        	  defineAccountingEntries(dealDetail, payDetail.getPaymentAmount().getCurrencyAmount(), IBCommonUtils.getModuleConfigurationValue("IB", "PayOrderCreditAccount").getValue(), narrative, PAYMENTORDER_CONTEXT);
          }
          factory.commitTransaction();
          factory.beginTransaction();
	}
	
	private void defineAccountingEntries(IBOIB_DLI_DealDetails dealDetail, BigDecimal amount, String accountId, String narrative, String context) {
		if(amount!=null && amount.compareTo(BigDecimal.ZERO)>0) {
			IBOIB_TXN_PAYRECDETAIL payRecDetailObject = createPayRecDetail(dealDetail, amount, accountId, narrative, context);
			registerAccountingEntries(getF_IN_islamicBankingObject().getDealID(), payRecDetailObject, narrative, context);
		}
		
	}

	private IBOIB_TXN_PAYRECDETAIL createPayRecDetail(IBOIB_DLI_DealDetails dealDetail, BigDecimal amount, String accountId, String narrative, String context){
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_TXN_PAYRECDETAIL payRecDetailObject = (IBOIB_TXN_PAYRECDETAIL) factory.getStatelessNewInstance(IBOIB_TXN_PAYRECDETAIL.BONAME);
		payRecDetailObject.setBoID(GUIDGen.getNewGUID());
        payRecDetailObject.setF_ACCOUNTID(accountId);
        payRecDetailObject.setF_AMOUNTTYPE(context);
        payRecDetailObject.setF_DEALNO(dealDetail.getBoID());
        payRecDetailObject.setF_EQUIVALENTAMOUNT(amount);
        payRecDetailObject.setF_EXCHANGERATE(BigDecimal.ONE);
        payRecDetailObject.setF_OUTSTANDINGAMOUNT(amount);
        payRecDetailObject.setF_PAYMENTMETHOD("TRF");
        payRecDetailObject.setF_STEPID(getF_IN_islamicBankingObject().getStepID());
        payRecDetailObject.setF_TRANSACTIONAMOUNT(amount);
        payRecDetailObject.setF_TRANSACTIONCURRENCY(dealDetail.getF_IsoCurrencyCode());
        payRecDetailObject.setF_TRANSACTIONID(dealDetail.getBoID());
        payRecDetailObject.setF_TRANSACTIONSTATUS("SCHEDULED");
        payRecDetailObject.setF_TRANSACTOINTYPE("PAY");
        payRecDetailObject.setF_NARRATIVE(narrative);
        factory.create(IBOIB_TXN_PAYRECDETAIL.BONAME, payRecDetailObject);
        return payRecDetailObject;
    }
    
    private void registerAccountingEntries(String dealNo, IBOIB_TXN_PAYRECDETAIL payRecDetailObject, String narrative, String context){
    	AccEntriesRegistrationDtls accEntriesRegistrationDetails = new AccEntriesRegistrationDtls();
    	accEntriesRegistrationDetails.setAccountID(payRecDetailObject.getF_ACCOUNTID());
    	accEntriesRegistrationDetails.setEntityId(payRecDetailObject.getBoID());
    	Amount amount2 = new Amount();
    	BigDecimal temp = BigDecimal.ZERO;
    	amount2.setAmountEdited(temp);
    	amount2.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
    	accEntriesRegistrationDetails.setAmountInAccCurr(amount2);
    	Amount amount = new Amount();
    	amount.setAmountEdited(payRecDetailObject.getF_EQUIVALENTAMOUNT());
    	amount.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
    	accEntriesRegistrationDetails.setBaseEquivalent(amount);
    	accEntriesRegistrationDetails.setDealId(payRecDetailObject.getF_DEALNO());
    	accEntriesRegistrationDetails.setEntityContext(context);
    	accEntriesRegistrationDetails.setExchangeRate(payRecDetailObject.getF_EXCHANGERATE());
    	accEntriesRegistrationDetails.setExchangeRateType(payRecDetailObject.getF_EXCHANGERATETYPE());
    	accEntriesRegistrationDetails.setNarrative(narrative);
    	accEntriesRegistrationDetails.setProcessId(getF_IN_islamicBankingObject().getProcessConfigID());
    	accEntriesRegistrationDetails.setStepId(getF_IN_islamicBankingObject().getStepID());
    	accEntriesRegistrationDetails.setTransactionDt(new java.sql.Date(payRecDetailObject.getF_TRANSACTIONDTTM().getTime()));
    	accEntriesRegistrationDetails.setTransactionId(dealNo);
    	Amount amount1 = new Amount();
    	amount1.setAmountEdited(payRecDetailObject.getF_TRANSACTIONAMOUNT());
    	amount1.setIsoCurrencyCode(payRecDetailObject.getF_TRANSACTIONCURRENCY());
    	accEntriesRegistrationDetails.setTxnAmount(amount1);
    	accEntriesRegistrationDetails.setTxnCurrency(amount1.getIsoCurrencyCode());
    	accEntriesRegistrationDetails.setTxnType(payRecDetailObject.getF_TRANSACTOINTYPE());
    	accEntriesRegistrationDetails.setValueDt(new java.sql.Date(payRecDetailObject.getF_VALUEDTTM().getTime()));
    	HashMap input = new HashMap();
    	input.put("accEntriesRegistrationDtls", accEntriesRegistrationDetails);
    	MFExecuter.executeMF("IB_CMN_RegisterAccountingEntries_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), input);
    }
    
    private void collectFeesAPI(BigDecimal paidFees, BigDecimal adjustmentFees) {
    	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
    	String transactionID = getF_IN_islamicBankingObject().getTransactionID();
		LoadFeesToCollect loadFeesToCollect = new LoadFeesToCollect(env);
		getF_IN_islamicBankingObject().setTransactionID(getF_IN_islamicBankingObject().getDealID());
		loadFeesToCollect.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		loadFeesToCollect.process(env);
		FeeToBeCollectedList feesToBeCollected = loadFeesToCollect.getF_OUT_FeeToBeCollectedList();
		FeeToBeCollectedList feesToBeCollectedList = new FeeToBeCollectedList();
		
		CollectFeeProcessing collectFeeProcessing = new CollectFeeProcessing();
		for (FeeToBeCollected feeToBeCollected : feesToBeCollected.getFeesToBeCollected()) {
			if (feeToBeCollected.getFeeName().contains("Adjustment") && adjustmentFees.compareTo(BigDecimal.ZERO)>0) {
				feeToBeCollected.getChargeAmount().setCurrencyAmount(adjustmentFees);
				feeToBeCollected.getBalanceAmount().setCurrencyAmount(adjustmentFees);
				feeToBeCollected.getAdjustedAmount().setCurrencyAmount(adjustmentFees);
				feesToBeCollectedList.addFeesToBeCollected(feeToBeCollected);
			} else if (feeToBeCollected.getFeeName().contains("Initial") && paidFees.compareTo(BigDecimal.ZERO)>0) {
				feeToBeCollected.getChargeAmount().setCurrencyAmount(paidFees);
				feeToBeCollected.getBalanceAmount().setCurrencyAmount(paidFees);
				feeToBeCollected.getAdjustedAmount().setCurrencyAmount(paidFees);
				feesToBeCollectedList.addFeesToBeCollected(feeToBeCollected);
			}
		}
		collectFeeProcessing.setF_IN_feeToBeCollectedList(feesToBeCollectedList);
		collectFeeProcessing.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		collectFeeProcessing.setF_IN_isStandAlone(true);
		collectFeeProcessing.process(env);
		RegisterCollectFeesForAE registerCollectFees = new RegisterCollectFeesForAE();
		registerCollectFees.setF_IN_islamicBankingObject(getF_IN_islamicBankingObject());
		registerCollectFees.process(env);
		getF_IN_islamicBankingObject().setTransactionID(transactionID);
	}
}
