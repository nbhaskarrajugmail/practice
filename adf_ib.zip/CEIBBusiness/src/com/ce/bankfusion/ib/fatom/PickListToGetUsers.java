package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_PickListToGetUsers;
import com.ce.bankfusion.ib.util.CeUtils;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.bankfusion.attributes.PickList;
import bf.com.misys.ib.types.ManageAssignUserGroup;
import bf.com.misys.ib.types.ManageAssignUserGroupList;

public class PickListToGetUsers extends AbstractCE_IB_PickListToGetUsers {
	
	public PickListToGetUsers(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		HashMap inputParams = new HashMap();
		HashMap outputParams = MFExecuter.executeMF("IB_CFG_SearchUserAssignments_SRV", env, inputParams);
		ManageAssignUserGroupList manageAssignUserGroupList = (ManageAssignUserGroupList) outputParams
				.get("manageAssignUserGroupList");
		if (manageAssignUserGroupList != null && manageAssignUserGroupList.getManageAssignUserGroupCount() > 0) {
			for (ManageAssignUserGroup userGroup : manageAssignUserGroupList.getManageAssignUserGroup()) {
				if (userGroup.getUserOrGroupType().equals("User")) {
					PickList pickListItem = CeUtils.getPisckListObject();
					pickListItem.setDescription(userGroup.getUserOrGroupName());
					pickListItem.setValues(userGroup.getUserOrGroupID());
					getF_OUT_pickListCollection().addPickListCollValues(pickListItem);
				}
			}

		}
	}
}
