package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveIssuePOData;
import com.misys.bankfusion.events.IBusinessEventsService;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.IssuePayOrderDtls;
import bf.com.misys.ib.types.PaymentDetails;
import bf.com.misys.ib.types.PoAssetDisbursementDetails;
import bf.com.misys.ib.types.PurchaseOrderDetails;

public class SaveIssuePOData extends AbstractCE_IB_SaveIssuePOData{
    
	private static final long serialVersionUID = 1L;
	private transient final static Log LOGGER = LogFactory.getLog(SaveIssuePOData.class.getName());
	
	@SuppressWarnings("deprecation")
    public SaveIssuePOData(BankFusionEnvironment env) {
        super(env);
    }
    public void process(BankFusionEnvironment env) {
    	IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
		        .getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
    	
    	System.err.println();
    	IssuePayOrderDtls hiddenList = getF_IN_hiddenIssuePayOrderDtls();
    	IssuePayOrderDtls gridList = getF_IN_issuePayOrderDtls();
    	IssuePayOrderDtls newHiddenList = new IssuePayOrderDtls();
    	PurchaseOrderDetails purchaseOrderDetail = getF_IN_purchaseOrderDetail();
    	if(gridList.getOutstandingFees().compareTo(purchaseOrderDetail.getFeesToBePaid())<CommonConstants.INTEGER_ZERO) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000395);
			businessEventsService.handleEvent(raiseEvent);
		}
    	if(gridList.getOutstandingAdjustmentFees().compareTo(purchaseOrderDetail.getAdjustmentFeesToBePaid())<CommonConstants.INTEGER_ZERO) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000396);
			businessEventsService.handleEvent(raiseEvent);
		}
    	if(gridList.getOutstandingUpfrontProfit().compareTo(purchaseOrderDetail.getUpfrontProfitToBePaid())<CommonConstants.INTEGER_ZERO) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000397);
			businessEventsService.handleEvent(raiseEvent);
		}
    	if(purchaseOrderDetail.getPoAmount().getCurrencyAmount().compareTo(CommonConstants.BIGDECIMAL_ZERO)<=CommonConstants.INTEGER_ZERO) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000404);
			businessEventsService.handleEvent(raiseEvent);
		}
    	if(purchaseOrderDetail.getPurchaseOrderID().equals(CommonConstants.EMPTY_STRING)) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000405);
			businessEventsService.handleEvent(raiseEvent);
		}
    	String purchaseOrderID = purchaseOrderDetail.getPurchaseOrderID();
    	for(CustomerLiabilities customerLiability : hiddenList.getCustomerLiabilitiesDtls()) {
    		if(!customerLiability.getPurchaseOrderID().equals(purchaseOrderID)) {
    			newHiddenList.addCustomerLiabilitiesDtls(customerLiability);
    		}
    	}
    	
    	for(PoAssetDisbursementDetails poAssetDetail : hiddenList.getPoAssetDisbursementDetails()) {
    		if(!poAssetDetail.getPurchaseOrderID().equals(purchaseOrderID)) {
    			newHiddenList.addPoAssetDisbursementDetails(poAssetDetail);
    		}
    	}
    	
    	for(PaymentDetails paymentDetail : hiddenList.getPaymentDetails()) {
    		if(!paymentDetail.getPurchaseOrderID().equals(purchaseOrderID)) {
    			newHiddenList.addPaymentDetails(paymentDetail);
    		}
    	}
    	
    	for(CustomerLiabilities customerLiability : gridList.getCustomerLiabilitiesDtls()) {
    		customerLiability.setPurchaseOrderID(purchaseOrderID);
    		newHiddenList.addCustomerLiabilitiesDtls(customerLiability);
    	}
    	
    	for(PoAssetDisbursementDetails poAssetDetail : gridList.getPoAssetDisbursementDetails()) {
    		poAssetDetail.getCurrentDisbursedAmount().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
    		poAssetDetail.getOriginalAssetStudyCost().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
    		poAssetDetail.getOriginalFinalCost().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
    		poAssetDetail.getPendingDisbursedAmount().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
    		poAssetDetail.getPrevouslyDisbursedAmount().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
    		poAssetDetail.setPurchaseOrderID(purchaseOrderID);
    		newHiddenList.addPoAssetDisbursementDetails(poAssetDetail);
    	}
    	BigDecimal totalPOAmount = BigDecimal.ZERO;
    	for(PaymentDetails paymentDetail : gridList.getPaymentDetails()) {
    		paymentDetail.getPaymentAmount().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
			paymentDetail.getPaymentAmountInOtherCurrency().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
			paymentDetail.getRemainingPaymentAmount().setCurrencyCode(getF_IN_islamicBankingObjec().getCurrency());
			paymentDetail.setPurchaseOrderID(purchaseOrderID);
    		newHiddenList.addPaymentDetails(paymentDetail);
    		totalPOAmount = totalPOAmount.add(paymentDetail.getPaymentAmount().getCurrencyAmount());
    	}
    	if(purchaseOrderDetail.getFinalDisbursementAmount().getCurrencyAmount().compareTo(totalPOAmount)!=CommonConstants.INTEGER_ZERO) {
			Event raiseEvent = new Event();
			raiseEvent.setEventNumber(44000406);
			businessEventsService.handleEvent(raiseEvent);
		}
    	setF_OUT_hiddenIssuePayOrderDtls(newHiddenList);
    	
    }

}
