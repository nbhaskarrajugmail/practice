package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipAgents;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_GetAllDealRelationshipAgents;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.dealrelationship.dtls.ib.types.RelationshipAgents;

public class GetAllDealRelationshipAgents extends AbstractCE_IB_GetAllDealRelationshipAgents {

	private static final Log LOGGER = LogFactory.getLog(GetAllDealRelationshipAgents.class);
	private String GET_ALL_AGENTS = " WHERE " + IBOCE_IB_DealRelationshipAgents.IBDEALID + " =?";

	public GetAllDealRelationshipAgents(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		ArrayList<String> params = new ArrayList<String>();
		params.add(getF_IN_dealId());
		getF_OUT_dealRelationshipDetails_agents().removeAllRelationshipAgents();
		List<IBOCE_IB_DealRelationshipAgents> results = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOCE_IB_DealRelationshipAgents.BONAME, GET_ALL_AGENTS, params, null, true);
		if (!results.isEmpty()) {
			for (IBOCE_IB_DealRelationshipAgents dealRelationshipAgent : results) {
				RelationshipAgents vRelationshipAgents = new RelationshipAgents();
				vRelationshipAgents.setAgencyDate(dealRelationshipAgent.getF_IBAGENCYDATE());
				vRelationshipAgents.setAgencyNumber(dealRelationshipAgent.getF_IBAGENCYNUMBER());
				vRelationshipAgents.setAgencySource(dealRelationshipAgent.getF_IBAGENCYSOURCE());
				vRelationshipAgents.setAgencyStatus(dealRelationshipAgent.getF_IBAGENCYSTATUS());
				vRelationshipAgents.setNotes(dealRelationshipAgent.getF_IBNOTES());
				vRelationshipAgents.setPartyId(dealRelationshipAgent.getF_IBAGENTPARTYID());
				vRelationshipAgents.setPartyName(dealRelationshipAgent.getF_IBAGENTPARTYNAME());
				vRelationshipAgents.setPartyNationalId(dealRelationshipAgent.getF_IBAGENTNATIONALID());
				vRelationshipAgents.setRelationshipDtlId(dealRelationshipAgent.getF_IBDEALRELATIONSHIPDTLID());
				getF_OUT_dealRelationshipDetails_agents().addRelationshipAgents(vRelationshipAgents);
			}
		}
	}
}
