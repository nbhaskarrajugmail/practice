package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedPreData;
import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class TitleDeedPreData extends AbstractCE_IB_TitleDeedPreData {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("deprecation")
	private transient static final Log LOGGER = LogFactory.getLog(TitleDeedPreData.class.getName());

	public TitleDeedPreData(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ? ";
		System.err.println();
		ArrayList<String> params = new ArrayList<>();

		if (getF_IN_bbMode().equalsIgnoreCase("VIEW")) {
			setF_OUT_MODE(false);
		}

		String dealID = getF_IN_islamicBankingObject().getDealID();
		params.add(dealID);
		if (dealID != null) {

			List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetailsList = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params, null, false);

			SearchTitleDeedDtlsRsType output = new SearchTitleDeedDtlsRsType();
			output.setListTitleDeedIdDtls(new ListTitleDeedIdDtlsType());
			if (titleDeedDetailsList != null && !titleDeedDetailsList.isEmpty()) {

				ListTitleDeedIdDtlsType listTitleDeedIdDtls = new ListTitleDeedIdDtlsType();
				for (IBOCE_IB_DealTitleDeedDtls dealTitleDeed : titleDeedDetailsList) {
					Map inputParams = new HashMap<>();
					inputParams.put("titleDeedId", dealTitleDeed.getF_IBTITLEDEEDID());
					inputParams.put("versionNumber", Integer.valueOf(dealTitleDeed.getF_IBTITLEDEEDVERSIONNUM()));
					HashMap outputParams = MFExecuter.executeMF("CE_PTY_ViewTitleDeedDetails_SRV",
							BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
					ListTitleDeedIdDtlsType rs = (ListTitleDeedIdDtlsType) outputParams.get("listTitleDeedDetailsType");
					if (rs != null && rs.getTitleDeedDetails() != null && rs.getTitleDeedDetails().length > 0) {
						TitleDeedDetailsType vtitleDeedDetail = rs.getTitleDeedDetails()[0];
						vtitleDeedDetail.setFarmLocationDescription(vtitleDeedDetail.getFarmLocation());
						
						vtitleDeedDetail.setVersionNumber(Integer.parseInt(dealTitleDeed.getF_IBTITLEDEEDVERSIONNUM()));
						vtitleDeedDetail.setSelect(false);
						listTitleDeedIdDtls.addTitleDeedDetails(vtitleDeedDetail);
					} else {
						LOGGER.error(
								"Title deed details not found in essence for :" + dealTitleDeed.getF_IBTITLEDEEDID()
										+ " and version " + dealTitleDeed.getF_IBTITLEDEEDVERSIONNUM());
					}
					output.setListTitleDeedIdDtls(listTitleDeedIdDtls);

				}

			}
			PagedQuery pagingInfo = new PagedQuery();
			PagingRequest pagingRequest = new PagingRequest();
			pagingRequest.setNumberOfRows(titleDeedDetailsList.size());
			pagingInfo.setPagingRequest(pagingRequest);
			output.setPagingInfo(pagingInfo);
			setF_OUT_searchTitleDeedDtlsRs(output);
		}
	}
}

