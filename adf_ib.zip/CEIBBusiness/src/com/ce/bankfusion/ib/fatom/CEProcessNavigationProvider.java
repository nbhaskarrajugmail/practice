package com.ce.bankfusion.ib.fatom;

import java.util.HashMap;

import com.misys.bankfusion.app.api.IPanelInfoProvider;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_CMN_ProcessNavigationProvider;
import com.misys.bankfusion.ib.util.PanelInfoProvider;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.workflow.attributes.WorkflowTaskAttributes;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CEProcessNavigationProvider extends AbstractIB_CMN_ProcessNavigationProvider {

    private static final long serialVersionUID = 1L;

    public CEProcessNavigationProvider() {
    }

    public CEProcessNavigationProvider(BankFusionEnvironment env) {
        super(env);
    }

    IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    @SuppressWarnings("unchecked")
    public void process(BankFusionEnvironment env) throws BankFusionException {
        BankFusionThreadLocal.setFromLeftPanel(false);
        String accSrviceName = getF_IN_AccountingSerName();
        IPanelInfoProvider panelInfoProvider = null;
        String dealID = getF_IN_dealID();
        IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
        HashMap data = new HashMap();
        if (accSrviceName.equals(RescheduleConstants.DEALRESCHWRKFLW)) {
            panelInfoProvider = new PanelInfoProvider();
        } else {
            panelInfoProvider = new CEDealInitiationPanelInfoProvider();
            data.put("productID", islamicBankingObject.getProductID());
            data.put("subProductID", islamicBankingObject.getSubProductID());
            data.put("processName", islamicBankingObject.getTransactionName());
            if ((getF_IN_taskID() != null) && (!getF_IN_taskID().equals(CommonConstants.EMPTY_STRING))) {
                WorkflowTaskAttributes workflowTaskAttributes =
                    IBCommonUtils.getWorkflowTaskAttributesForTaskID(getF_IN_taskID(), getF_IN_GUID());
                IslamicBankingObject payload = (IslamicBankingObject) workflowTaskAttributes.getAdditionalTaskAttributes().getTaskInputPayload();
                String dealStatus = CommonConstants.EMPTY_STRING;
                if(null != payload.getDealID() && !payload.getDealID().isEmpty()){
                	IBOIB_DLI_DealDetails dealDeatils =  (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME,
                			payload.getDealID(), true);
                	dealStatus = dealDeatils!=null ? dealDeatils.getF_Status():CommonConstants.EMPTY_STRING;
                }
                IBCommonUtils.updateStatus(CommonConstants.EMPTY_STRING, dealStatus, CommonConstants.EMPTY_STRING, CommonConstants.EMPTY_STRING, payload);
                data.put("stepID",
                    ((IslamicBankingObject) workflowTaskAttributes.getAdditionalTaskAttributes().getTaskInputPayload()).getStepID());
            }
        }
        data.put("dealID", dealID);
        setF_OUT_multiPanelResponse(panelInfoProvider.getPanelServiceData(getF_IN_GUID(), data));

    }

}
