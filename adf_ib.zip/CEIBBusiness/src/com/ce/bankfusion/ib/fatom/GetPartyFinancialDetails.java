/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BuyerDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerDocumentDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_SellerTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_ADF_GetPartyFinancialDetails;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.utils.ADFUtils;
import com.ce.bankfusion.ib.utils.DealAmounts;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.BFCurrencyAmount;
import bf.com.misys.ib.types.BuyerDetails;
import bf.com.misys.ib.types.SellerDocumentDetails;
import bf.com.misys.ib.types.SellerTitleDeedDetails;

/**
 * @author Aklesh
 *
 */
public class GetPartyFinancialDetails extends AbstractCE_ADF_GetPartyFinancialDetails {

	private static final long serialVersionUID = 7137308733675905581L;
	private static final String WHERE_CLAUSE = "WHERE " + IBOCE_ADF_SellerDocumentDtls.PARTYID + "=?";

	public GetPartyFinancialDetails(BankFusionEnvironment env) {
		super(env);

	}

	public GetPartyFinancialDetails() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
		String partyID = getF_IN_partyID();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<HashMap> dealInfos = CeUtils.getDealIdsByCustomerId(partyID);
		BigDecimal dueAmount = CommonConstants.BIGDECIMAL_ZERO;
		BigDecimal remainingAmount = CommonConstants.BIGDECIMAL_ZERO;
		BFCurrencyAmount bfDueAmount = new BFCurrencyAmount();
		bfDueAmount.setCurrencyCode("SAR");
		bfDueAmount.setCurrencyAmount(dueAmount);
		BFCurrencyAmount bfRemainingAmount = new BFCurrencyAmount();
		bfRemainingAmount.setCurrencyAmount(remainingAmount);
		bfRemainingAmount.setCurrencyCode("SAR");
		if (null != dealInfos && dealInfos.size() > 0) {
			for (int i = 0; i < dealInfos.size(); i++) {
				IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
						.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, (String) dealInfos.get(i).get("dealId"), true);
				if (null != dealDetails.getF_DealAccountId()
						&& !StringUtils.isEmpty(dealDetails.getF_DealAccountId())) {

					DealAmounts dealAmounts = ADFUtils.getDealAmounts((String) dealInfos.get(i).get("dealId"));
					dueAmount = dueAmount.add(dealAmounts.getDueAmount().getCurrencyAmount());
					remainingAmount = remainingAmount.add(dealAmounts.getRemainingAmount().getCurrencyAmount());
				}
			}
			bfDueAmount.setCurrencyAmount(IBCommonUtils.scaleAmount("SAR", dueAmount));
			bfRemainingAmount.setCurrencyAmount(IBCommonUtils.scaleAmount("SAR", remainingAmount));
			getF_OUT_buyerSellerAgreement().getSellerDetails().setPastDueAmount(bfDueAmount);
			getF_OUT_buyerSellerAgreement().getSellerDetails().setRemainingAmount(bfRemainingAmount);
		}
		if (!isF_IN_readPartyOnly()) {
			getF_OUT_buyerSellerAgreement().removeAllSellerDocumentDetailsList();
			ArrayList params = new ArrayList<String>();
			params.add(partyID);
			List<IBOCE_ADF_SellerDocumentDtls> sellerDocuments = factory
					.findByQuery(IBOCE_ADF_SellerDocumentDtls.BONAME, WHERE_CLAUSE, params, null);
			for (IBOCE_ADF_SellerDocumentDtls iboce_ADF_SellerDocumentDtls : sellerDocuments) {
				SellerDocumentDetails documentDetails = new SellerDocumentDetails();
				documentDetails.setApprovalLetterNumber(iboce_ADF_SellerDocumentDtls.getF_APPROVALLETTERNUMBER());
				documentDetails.setDocumentDate(iboce_ADF_SellerDocumentDtls.getF_DOCUMENTDATE());
				documentDetails.setDocumentDateHijri(iboce_ADF_SellerDocumentDtls.getF_DOCUMENTDATEHIJRI());
				documentDetails.setDocumentNumber(iboce_ADF_SellerDocumentDtls.getF_DOCUMENTNUMBER());
				documentDetails.setDocumentReciever(iboce_ADF_SellerDocumentDtls.getF_DOCUMENTRECIEVER());
				documentDetails.setEmployeeName(iboce_ADF_SellerDocumentDtls.getF_EMPLOYEENAME());
				documentDetails.setEmployeeNationalID(iboce_ADF_SellerDocumentDtls.getF_EMPLOYEENATIONALID());
				documentDetails.setEmployeeNumber(iboce_ADF_SellerDocumentDtls.getF_EMPLOYEENUMBER());
				documentDetails.setIssuingAuthority(iboce_ADF_SellerDocumentDtls.getF_ISSUINGAUTHORITY());
				documentDetails.setIssuingDate(iboce_ADF_SellerDocumentDtls.getF_ISSUINGDATE());
				documentDetails.setIssuingSource(iboce_ADF_SellerDocumentDtls.getF_ISSUINGSOURCE());
				documentDetails.setLetterType(iboce_ADF_SellerDocumentDtls.getF_LETTERTYPE());
				documentDetails.setMortgageType(iboce_ADF_SellerDocumentDtls.getF_MORTGAGETYPE());
				documentDetails.setSequenceNumber(iboce_ADF_SellerDocumentDtls.getF_SEQUENCENUMBER());
				documentDetails.setShareholder(iboce_ADF_SellerDocumentDtls.isF_SHAREHOLDER());
				documentDetails.setShowEmployeeInRep(iboce_ADF_SellerDocumentDtls.isF_SHOWEMPLOYEEINREP());
				documentDetails.setIsExisting(true);
				getF_OUT_buyerSellerAgreement().addSellerDocumentDetailsList(documentDetails);
			}
			getF_OUT_buyerSellerAgreement().removeAllBuyerDetailsList();
			List<IBOCE_ADF_BuyerDetails> buyerDetails = factory.findByQuery(IBOCE_ADF_BuyerDetails.BONAME, WHERE_CLAUSE,
					params, null);
			for (IBOCE_ADF_BuyerDetails iboce_ADF_BuyerDetails : buyerDetails) {
				BuyerDetails details = new BuyerDetails();
				BFCurrencyAmount tdDueAmount = new BFCurrencyAmount();
				tdDueAmount.setCurrencyCode("SAR");
				tdDueAmount.setCurrencyAmount(iboce_ADF_BuyerDetails.getF_DUEAMOUNT());
				BFCurrencyAmount tdRemainingAmount = new BFCurrencyAmount();
				tdRemainingAmount.setCurrencyAmount(iboce_ADF_BuyerDetails.getF_REMAININGAMOUNT());
				tdRemainingAmount.setCurrencyCode("SAR");
				details.setPastDueAmount(tdDueAmount);
				details.setRemainingAmount(tdRemainingAmount);
				details.setSellerNationalID(iboce_ADF_BuyerDetails.getF_NATIONALID());
				details.setSellerPartyID(iboce_ADF_BuyerDetails.getF_BUYERPARTYID());
				details.setSellerPartyName(iboce_ADF_BuyerDetails.getF_BUYERPARTYNAME());
				details.setSellerPartyType(iboce_ADF_BuyerDetails.getF_PARTYTYPE());
				details.setIsExisting(true);

				getF_OUT_buyerSellerAgreement().addBuyerDetailsList(details);
			}

			getF_OUT_buyerSellerAgreement().removeAllSellerTitleDeedDetailsList();
			List<IBOCE_ADF_SellerTitleDeedDtls> sellerTitleDeedDtls = factory
					.findByQuery(IBOCE_ADF_SellerTitleDeedDtls.BONAME, WHERE_CLAUSE, params, null);
			for (IBOCE_ADF_SellerTitleDeedDtls iboce_ADF_SellerTitleDeedDtls : sellerTitleDeedDtls) {
				SellerTitleDeedDetails deedDetails = new SellerTitleDeedDetails();
				deedDetails.setBranch(iboce_ADF_SellerTitleDeedDtls.getF_BRANCH());
				deedDetails.setFarmLocation(iboce_ADF_SellerTitleDeedDtls.getF_FARMLOCATION());
				deedDetails.setIsUsedinCollateral(iboce_ADF_SellerTitleDeedDtls.getF_ISUSEDINCOLLATERAL());
				deedDetails.setIsUsedinTechAnalysis(iboce_ADF_SellerTitleDeedDtls.getF_ISUSEDINTECHANALYSIS());
				deedDetails.setLandPlanNumber(iboce_ADF_SellerTitleDeedDtls.getF_LANDPLANNUMBER());
				deedDetails.setLandPlotNumber(iboce_ADF_SellerTitleDeedDtls.getF_LANDPLOTNUMBER());
				BFCurrencyAmount tdDueAmount = new BFCurrencyAmount();
				tdDueAmount.setCurrencyCode("SAR");
				tdDueAmount.setCurrencyAmount(iboce_ADF_SellerTitleDeedDtls.getF_PASTDUEAMOUNT());
				BFCurrencyAmount tdRemainingAmount = new BFCurrencyAmount();
				tdRemainingAmount.setCurrencyAmount(iboce_ADF_SellerTitleDeedDtls.getF_REMAININGAMOUNT());
				tdRemainingAmount.setCurrencyCode("SAR");
				deedDetails.setPastDueAmount(tdDueAmount);
				deedDetails.setRemainingAmount(tdRemainingAmount);
				deedDetails.setTitleDeedNumber(iboce_ADF_SellerTitleDeedDtls.getF_TITLEDEEDNUMBER());
				deedDetails.setTitleDeedSource(iboce_ADF_SellerTitleDeedDtls.getF_TITLEDEEDSOURCE());
				deedDetails.setTitleDeedType(iboce_ADF_SellerTitleDeedDtls.getF_TITLEDEEDTYPE());
				deedDetails.setTitleDeedYear(String.valueOf(iboce_ADF_SellerTitleDeedDtls.getF_TITLEDEEDYEAR()));
				deedDetails.setIsExisting(true);
				getF_OUT_buyerSellerAgreement().addSellerTitleDeedDetailsList(deedDetails);
			}
		}

	}
}