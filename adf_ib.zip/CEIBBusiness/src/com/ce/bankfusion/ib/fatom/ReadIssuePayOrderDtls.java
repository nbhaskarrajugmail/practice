package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CustomerLiabilitiesOfIssuePO;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_IssuePaymentOrder;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ReadIssuePayOrderDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.fatom.ReadAssetData;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.services.ReadCodeValueRs;
import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.PaymentSchedule;
import bf.com.misys.ib.spi.types.PaymentScheduleList;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.AssetBasicDtls;
import bf.com.misys.ib.types.AssetThirdPartyDtls;
import bf.com.misys.ib.types.CustomerLiabilities;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.IssuePayOrderDtls;

public class ReadIssuePayOrderDtls extends AbstractCE_IB_ReadIssuePayOrderDtls {
	private static final long serialVersionUID = 1L;

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	private transient final static Log LOGGER = LogFactory.getLog(ReadIssuePayOrderDtls.class.getName());
	private static final String SELECT_CUST_LIABILITIES_DTLS_BY_DEALID = " WHERE "
			+ IBOCE_IB_CustomerLiabilitiesOfIssuePO.DEALIDOFPO + "  =?";
	private static final String SELECT_ISSUE_PO_BY_DEALID = " WHERE " + IBOCE_IB_IssuePaymentOrder.DEALID + "  =?";
	private static final String GET_DEAL_PRIMARY_CUST_DETAIL = " WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + " = ?";
	private static final String GET_DEALID_BY_CUST = " WHERE " + IBOIB_IDI_DealCustomerDetail.CUSTOMERID + " = ?";

	public ReadIssuePayOrderDtls() {
		super();
	}

	@SuppressWarnings("deprecation")
	public ReadIssuePayOrderDtls(BankFusionEnvironment env) {
		super(env);
	}

	@SuppressWarnings({ "deprecation" })
	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		/*ReadAssetData readAssetData = CeUtils.readAssetData(getF_IN_islamicBankingObject());
		IslamicBankingObject islamicBankingObject = getF_IN_islamicBankingObject();
		BigDecimal totalAssetCost = calculateTotalAssetCost(readAssetData);
		BigDecimal feesToBeDeducted = calculateTotalFees(getF_IN_islamicBankingObject().getDealID());
		BigDecimal upfrontProfitTobeDeducted = calculateTotalUpfrontProfit(getF_IN_islamicBankingObject().getDealID());
		CustomerLiabilities[] vCustomerLiabilitiesDtlsArray = getCustomerLIabilities(islamicBankingObject);

		IssuePayOrderDtls issuePayOrderDtls = new IssuePayOrderDtls();
		//IBCommonUtils.intializeDefaultvalues(issuePayOrderDtls);
		IBOCE_IB_IssuePaymentOrder issuePODtl = fetchIssuePODtls(islamicBankingObject.getDealID());
		issuePayOrderDtls
				.setPaymentOrderAmt(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), totalAssetCost));
		issuePayOrderDtls.setCustomerLiabilitiesDtls(vCustomerLiabilitiesDtlsArray);
		issuePayOrderDtls.setDealId(islamicBankingObject.getDealID());

		issuePayOrderDtls
				.setFeesToBeDeducted(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), feesToBeDeducted));
		issuePayOrderDtls.setUpfrontProfitToBeDeducted(
				IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), upfrontProfitTobeDeducted));
		if (null != issuePODtl) {
			if (issuePODtl.getF_PAYMENTORDERAMOUNT().compareTo(totalAssetCost) != 0) {
				issuePayOrderDtls.setDisbursementAmt(
						IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), totalAssetCost));

			} else {
				issuePayOrderDtls.setDisbursementAmt(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(),
						issuePODtl.getF_DISBURSEMENTAMOUNT()));
			}
			issuePayOrderDtls
					.setFeesToBePaid(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), BigDecimal.ZERO));
			issuePayOrderDtls.setUpfrontProfitToBePaid(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), BigDecimal.ZERO));
			issuePayOrderDtls.setOutstandingCustomerLiabilities(IBCommonUtils
					.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_OUTSTANDINGCUSTLIAB()));
			issuePayOrderDtls.setOutstandingFees(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_OUTSTANDINGFEES()));
			issuePayOrderDtls.setOutstandingFeesInDisb(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(),
					issuePODtl.getF_OUTSTANDINGFEESINDISB()));
			issuePayOrderDtls.setOutstandingUpfrontProfit(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_OUTSTANDINGUPAMT()));
			issuePayOrderDtls.setOutstandingUpfrontProfitInDisb(IBCommonUtils
					.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_OUTSTANDINGUPAMTINDISB()));
			issuePayOrderDtls.setPaidFees(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_PAIDFEES()));
			issuePayOrderDtls.setPaidUpfrontProfit(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_PAIDUPAMT()));
			issuePayOrderDtls.setCustomerLiabilitiesToBeDeducted(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), issuePODtl.getF_CUSTLIABDEDUCTED()));
		} else {
			issuePayOrderDtls.setOutstandingFees(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), feesToBeDeducted));
			issuePayOrderDtls.setOutstandingUpfrontProfit(
					IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), upfrontProfitTobeDeducted));
			issuePayOrderDtls
					.setDisbursementAmt(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(), totalAssetCost));
		}

		setF_OUT_issuePayOrderDtlRs(issuePayOrderDtls);*/
	}

	/*private CustomerLiabilities[] getCustomerLIabilities(IslamicBankingObject islamicBankingObject) {

		List<CustomerLiabilities> custLiab = new ArrayList();
		List<IBOCE_IB_CustomerLiabilitiesOfIssuePO> custLiabDtls = fetchCustLiabilities(
				islamicBankingObject.getDealID());
		if (null != custLiabDtls && custLiabDtls.size() > 0) {
			for (int i = 0; i < custLiabDtls.size(); i++) {
				CustomerLiabilities eachCustLiab = new CustomerLiabilities();
				eachCustLiab.setDealId(custLiabDtls.get(i).getF_DEALIDOFCUSTOMER());
				eachCustLiab.setOutstandingAmt(IBCommonUtils.scaleAmount(islamicBankingObject.getCurrency(),
						custLiabDtls.get(i).getF_OUTSTANDINGAMOUNT()));
				eachCustLiab.setSelect(custLiabDtls.get(i).isF_SELECT());
				eachCustLiab.setTransactionType(custLiabDtls.get(i).getF_TRANSACTIONTYPE());
				ReadCodeValueRs userRoleRs = IBCommonUtils.getGCFromCode("ASSCTYPE",
						custLiabDtls.get(i).getF_UESRROLE());
				String userRoledesc = userRoleRs.getReadCodeValueDetails().getGcCodeDetails().getCodeDescription();
				eachCustLiab.setUserRole(userRoledesc);
				eachCustLiab.setTransactionType(custLiabDtls.get(i).getF_UESRROLE());
				custLiab.add(eachCustLiab);
			}
			CustomerLiabilities[] vCustomerLiabilitiesDtlsArray = custLiab
					.toArray(new CustomerLiabilities[custLiab.size()]);
			return vCustomerLiabilitiesDtlsArray;
		} else {
			ArrayList<HashMap> dealInfos = getDealIdsByCustomerId(islamicBankingObject);
			if (null != dealInfos && dealInfos.size() > 0) {
				for (int i = 0; i < dealInfos.size(); i++) {
					CustomerLiabilities eachCustLiab = new CustomerLiabilities();
					eachCustLiab.setDealId((String) dealInfos.get(i).get("dealId"));
					BigDecimal outstandingAmt = getOutstandingAmt(eachCustLiab.getDealId());
					eachCustLiab.setOutstandingAmt(outstandingAmt);
					eachCustLiab.setSelect(false);
					String userRoleRef = (String) dealInfos.get(i).get("userRole");
					ReadCodeValueRs userRoleRs = IBCommonUtils.getGCFromCode("ASSCTYPE", userRoleRef);
					String userRoledesc = userRoleRs.getReadCodeValueDetails().getGcCodeDetails().getCodeDescription();
					eachCustLiab.setUserRole(userRoledesc);
					eachCustLiab.setTransactionType(userRoleRef);
					if (outstandingAmt.compareTo(BigDecimal.ZERO) > 0)
						custLiab.add(eachCustLiab);

				}

				CustomerLiabilities[] vCustomerLiabilitiesDtlsArray = custLiab
						.toArray(new CustomerLiabilities[custLiab.size()]);
				return vCustomerLiabilitiesDtlsArray;
			}
		}
		return custLiab.toArray(new CustomerLiabilities[custLiab.size()]);
	}

	private BigDecimal getOutstandingAmt(String dealId) {

		BigDecimal outstandingAmt = BigDecimal.ZERO;
		ReadLoanDetailsRs readLoanRs = null;
		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(dealId);
		try {
			readLoanRs = IBCommonUtils.getLoanDetails(dealId);
		} catch (Exception e) {
			e.getMessage();
		}
		if (null != readLoanRs) {
			PaymentScheduleList paymentScheduleList = new PaymentScheduleList();
			if (readLoanRs != null && readLoanRs.getDealDetails().getPaymentSchedule().length > 0) {
				for (LoanPayments row : readLoanRs.getDealDetails().getPaymentSchedule()) {
					if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(), row.getRepaymentDate())
							|| IBCommonUtils.getBFBusinessDate().equals(row.getRepaymentDate())) {
						PaymentSchedule paymentSchedule = new PaymentSchedule();
						paymentSchedule.setRepaymentAmt(row.getRepaymentAmtUnPaid().setScale(2));
						outstandingAmt = outstandingAmt.add(paymentSchedule.getRepaymentAmt());

					}
				}
			}

			// outstandingAmt =
			// readLoanRs.getDealDetails().getLoanBasicDetails().getArrearDealAmount();

			for (LoanPayments paymentSch : readLoanRs.getDealDetails().getPaymentSchedule()) {
				if (paymentSch.getRepaymentDate().equals(IBCommonUtils.getBFBusinessDate())
						&& paymentSch.getRepaymentAmtUnPaid().compareTo(BigDecimal.ZERO) > 0) {
					EarlyAssetPayoffUtils assetPayoffUtils = new EarlyAssetPayoffUtils();
					List<IBOCE_IB_EarlyAssetPayoffDtls> earlyAssetDtls = assetPayoffUtils
							.getReschReqExistingObjStatusCompleted(dealId);
					if (null != earlyAssetDtls && earlyAssetDtls.size() > 0) {
						Timestamp earlyAssetDate = earlyAssetDtls.get(0).getF_IBRECLASTMODIFIEDDATE();
						if (earlyAssetDate.equals(IBCommonUtils.getBFBusinessDateTime())) {
							outstandingAmt = outstandingAmt.add(paymentSch.getRepaymentAmtUnPaid());
						}
					}
				}
				{

				}
			}
		}
		return IBCommonUtils.scaleAmount(getF_IN_islamicBankingObject().getCurrency(), outstandingAmt);
	}

	private ArrayList getDealIdsByCustomerId(IslamicBankingObject islamicBankingObject) {

		ArrayList dealInfos = new ArrayList<>();

		String dealId = islamicBankingObject.getDealID();
		IBOIB_IDI_DealCustomerDetail customerDtls = IBCommonUtils.getDealPrimaryPartyDetails(dealId);
		String partyId = customerDtls.getF_CUSTOMERID();
		ArrayList params = new ArrayList();
		params.add(partyId);
		List<IBOIB_IDI_DealCustomerDetail> customerDeals = (List<IBOIB_IDI_DealCustomerDetail>) factory
				.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, GET_DEALID_BY_CUST, params, null, true);
		if (null != customerDeals && customerDeals.size() > 0) {
			for (int i = 0; i < customerDeals.size(); i++) {
				HashMap dealDtls = new HashMap<>();
				String userRole = customerDeals.get(i).getF_ASSOCIATIONTYPE();
				String eachDealIdByCustomer = customerDeals.get(i).getF_DEALID();
				params.clear();
				params.add(eachDealIdByCustomer);
				String where = " WHERE " + IBOIB_DLI_DealDetails.DealNo + "=? AND "
						+ IBOIB_DLI_DealDetails.DealAccountId + " is not null ";
				List<IBOIB_DLI_DealDetails> dealDtlsList = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, where,
						params, null, true);
				if (null != dealDtlsList && dealDtlsList.size() > 0 && !eachDealIdByCustomer.equals(dealId)) {
					dealDtls.put("userRole", userRole);
					dealDtls.put("dealId", eachDealIdByCustomer);
					dealInfos.add(dealDtls);
				}
			}
		}
		return dealInfos;
	}

	private BigDecimal calculateTotalFees(String dealId) {
		BigDecimal feesAmount = CeUtils.getFeesAmount(dealId);
		return feesAmount;
	}

	private BigDecimal calculateTotalUpfrontProfit(String dealId) {
		BigDecimal upfrontProfitAmount = CeUtils.getUpfrontProfitAmount(dealId);
		return upfrontProfitAmount;
	}

	private BigDecimal calculateTotalAssetCost(ReadAssetData readAssetData) {
		BigDecimal totalAssetCost = BigDecimal.ZERO;
		for (AssetBasicDtls assetBasicDtls : readAssetData.getF_OUT_AssetBasicDtlsList().getAssetBasicDtls()) {
			String assetId = assetBasicDtls.getAssetId();
			String isAssetDisbursed = CeUtils.getUDFValueAssetToBeDisbursed(readAssetData, assetId);
			// isAssetDisbursed = true;// to do changes
			if (isAssetDisbursed.equals("YES")
					&& !(assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED)
							|| assetBasicDtls.getAssetStatus().equals(CeConstants.ASSET_STATUS_DISBURSED_DESC))) {
				// if (isAssetDisbursed.equals("YES")){
				BigDecimal assetCost = new BigDecimal(0);
				for (AssetThirdPartyDtls assetThirdPartyDtls : readAssetData.getF_OUT_AssetThirdPartyDtlsList()
						.getAssetThirdPartyDtls()) {
					if (assetThirdPartyDtls.getAssetID().equals(assetId)) {
						assetCost = assetCost
								.add(assetThirdPartyDtls.getThirdPtyBasicDtls().getAmount().getCurrencyAmount());
						totalAssetCost = totalAssetCost.add(assetCost);
					}
				}
			}
		}
		return totalAssetCost;
	}

	public List<IBOCE_IB_CustomerLiabilitiesOfIssuePO> fetchCustLiabilities(String dealId) {

		ArrayList<String> params = new ArrayList<String>();

		params.clear();
		params.add(dealId);

		@SuppressWarnings("unchecked")
		List<IBOCE_IB_CustomerLiabilitiesOfIssuePO> custLiabIssuePODtls = (List<IBOCE_IB_CustomerLiabilitiesOfIssuePO>) factory
				.findByQuery(IBOCE_IB_CustomerLiabilitiesOfIssuePO.BONAME, SELECT_CUST_LIABILITIES_DTLS_BY_DEALID,
						params, null, true);

		return custLiabIssuePODtls;

	}

	public IBOCE_IB_IssuePaymentOrder fetchIssuePODtls(String dealId) {

		ArrayList<String> params = new ArrayList<String>();

		params.clear();
		params.add(dealId);

		@SuppressWarnings("unchecked")
		List<IBOCE_IB_IssuePaymentOrder> issuePODtls = (List<IBOCE_IB_IssuePaymentOrder>) factory
				.findByQuery(IBOCE_IB_IssuePaymentOrder.BONAME, SELECT_ISSUE_PO_BY_DEALID, params, null, true);
		if (issuePODtls != null && issuePODtls.size() > 0) {
			return issuePODtls.get(0);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public List<IBOIB_IDI_DealCustomerDetail> getDealPartyDetails(String dealNo) {
		List<IBOIB_IDI_DealCustomerDetail> dealCustomerDtlsList = new ArrayList<>();
		ArrayList<String> paramsArrayList = new ArrayList<String>();
		paramsArrayList.add(dealNo);
		dealCustomerDtlsList = ((ArrayList<IBOIB_IDI_DealCustomerDetail>) factory.findByQuery(
				IBOIB_IDI_DealCustomerDetail.BONAME, GET_DEAL_PRIMARY_CUST_DETAIL, paramsArrayList, null, true));
		return dealCustomerDtlsList;
	}*/
}
