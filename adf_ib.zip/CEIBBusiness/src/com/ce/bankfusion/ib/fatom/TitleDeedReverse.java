package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedReverse;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class TitleDeedReverse extends AbstractCE_IB_TitleDeedReverse{

    @SuppressWarnings("deprecation")
    public TitleDeedReverse(BankFusionEnvironment env) {
        super(env);
    }

    public void process(BankFusionEnvironment env) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ? ";
        ArrayList<String> params = new ArrayList<String>();
        params.add("");
        
        List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetails = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params, null, false);
        
        for(IBOCE_IB_DealTitleDeedDtls e : titleDeedDetails) {
            e.setF_IBSTATUS("REQUESTED");
        }
    }
}
