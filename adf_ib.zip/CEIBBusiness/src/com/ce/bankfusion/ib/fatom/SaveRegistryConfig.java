/**
 * 
 */
package com.ce.bankfusion.ib.fatom;

import java.math.BigDecimal;
import java.sql.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_SaveRegistryConfig;
import com.ce.ib.cfg.bo.Registry;
import com.ce.ib.cfg.bo.RegistryAsset;
import com.misys.bankfusion.ib.fatom.CustomAutoNumFatom;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.events.BusinessEventSupport;

import bf.com.misys.ib.types.RegistryAssetListCfg;
import bf.com.misys.ib.types.RegistryCfgSearchRq;
import bf.com.misys.ib.types.RegistryCfgSearchRs;
import bf.com.misys.ib.types.RegistryList;
import bf.com.misys.ib.types.RegistryListCfg;

/**
 * @author chethabn
 *
 */
public class SaveRegistryConfig extends AbstractCE_IB_SaveRegistryConfig {
	private static final long serialVersionUID = -9159341008780369992L;
	private static final transient Log LOGGER = LogFactory.getLog(SaveRegistryConfig.class.getName());

	public SaveRegistryConfig(BankFusionEnvironment env) {
		super(env);

	}

	public SaveRegistryConfig() {
		super();

	}

	@Override
	public void process(BankFusionEnvironment env) {
	   String mode = getF_IN_mode();
if(mode.equals("NEW")) {
    RegistryCfgSearchRs registrySearchRqIN = getF_IN_registrySearchRsIN();
    RegistryListCfg[] registry = registrySearchRqIN.getRegCfgSearchList().getRegistryListDtls();
    Boolean newRow = false;
    for(RegistryListCfg item : registry) {
        if(item.getSelect()==true) {
            item.setSelect(Boolean.FALSE);
        }
        if(IBCommonUtils.isNullOrEmpty(item.getDocumentNumber()) || item.getDocumentNumber().equalsIgnoreCase("") ) {
            newRow = true;
        }
    }
        if(!newRow) {
        int entries = registrySearchRqIN.getPagedQuery().getPagingRequest().getNumberOfRows();
       Date dt = new Date(IBCommonUtils.getBFBusinessDateTime().getYear(),IBCommonUtils.getBFBusinessDateTime().getMonth(),IBCommonUtils.getBFBusinessDateTime().getDate());
       CustomAutoNumFatom customAutoNumFatom = new CustomAutoNumFatom(env);
       customAutoNumFatom.setF_IN_BONAME("CE_IB_RegistryListCfg");
       customAutoNumFatom.setF_IN_isRightPad(false);
       customAutoNumFatom.setF_IN_Prefix("Reg_");
       customAutoNumFatom.setF_IN_Suffix("");
       customAutoNumFatom.setF_IN_TotalLength(0);
       customAutoNumFatom.process(env);

       String reqId = customAutoNumFatom.getF_OUT_PrimKey(); 
       
       RegistryListCfg vRegistryListDtls = new RegistryListCfg();
        vRegistryListDtls.setDocumentDate(dt);
        vRegistryListDtls.setDocumentNumber("");
        vRegistryListDtls.setReferenceNumber("");
        vRegistryListDtls.setRegistryDate(dt);
        vRegistryListDtls.setRegistryId(reqId);
        vRegistryListDtls.setRegistryStatus("");
        vRegistryListDtls.setSelect(Boolean.TRUE);
        
        registrySearchRqIN.getRegCfgSearchList().addRegistryListDtls(vRegistryListDtls );
        
        registrySearchRqIN.getPagedQuery().getPagingRequest().setNumberOfRows(entries+1);
        }
        setF_OUT_registrySearchRs(registrySearchRqIN);
        

}else {
    RegistryList registryList = getF_IN_registrySearchRsIN().getRegCfgSearchList();

    Registry registry = new Registry();
    RegistryAsset regasset = new RegistryAsset();
    RegistryListCfg registryListCfg = getF_IN_regListCfg();
    
    RegistryAssetListCfg[] assetListCfgs = registryList.getRegistryAssetListDtls();
    for(RegistryAssetListCfg asset : assetListCfgs) {
            asset.setAttribute1(null==asset.getAttribute1()?BigDecimal.ZERO:asset.getAttribute1());
            asset.setAttribute2(null==asset.getAttribute2()?BigDecimal.ZERO:asset.getAttribute2());
            asset.setAttribute3(null==asset.getAttribute3()?BigDecimal.ZERO:asset.getAttribute3());
    }
    if (assetListCfgs.length > 0) {
      try {
        registry.saveRegistryList(registryListCfg);
        regasset.createRegistryAssetDtls(assetListCfgs, registryListCfg.getRegistryId());
        BusinessEventSupport.getInstance().raiseBusinessInfoEvent(44000208, new Object[] {}, LOGGER,
            IBCommonUtils.getBankFusionEnvironment());
        RegistryCfgSearchRs registrySearchIN = getF_IN_registrySearchRsIN();
        for(RegistryListCfg reg : registrySearchIN.getRegCfgSearchList().getRegistryListDtls()) {
            if(reg.isSelect()) {
                reg.setDocumentDate(registryListCfg.getDocumentDate());
                reg.setDocumentNumber(registryListCfg.getDocumentNumber());
                reg.setReferenceNumber(registryListCfg.getDocumentNumber());
                reg.setRegistryDate(registryListCfg.getRegistryDate());
                reg.setRegistryId(registryListCfg.getRegistryId());
                reg.setRegistryStatus(registryListCfg.getRegistryStatus());

            }
        }
        setF_OUT_registrySearchRs(registrySearchIN);
        
      } catch (Exception e) {
        LOGGER.error(e);
        BusinessEventSupport.getInstance().raiseBusinessErrorEvent(44000203, new Object[] {}, LOGGER,
            IBCommonUtils.getBankFusionEnvironment());
      }
    } else {
      BusinessEventSupport.getInstance().raiseBusinessErrorEvent(11400229, new Object[] { "Asset Details" },
          LOGGER, IBCommonUtils.getBankFusionEnvironment());
    }
    
    
}
	    
	    
		

	}

}
