package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealValidations;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_DealValidationScreenHandler;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.DealValidation;

public class DealValidationScreenHandler extends AbstractCE_IB_DealValidationScreenHandler{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5829524355687437098L;

	public DealValidationScreenHandler()
	{
		super();
	}
	
	public DealValidationScreenHandler(BankFusionEnvironment env)
	{
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env)
	{
		String context = getF_IN_context();

		switch(context)
		{
		case "INFO_BB_ROW_SELECT" :
			isDisableScalarForInfoBB();
			break;
		case "APPROVAL_BB_ROW_SELECT" :
			isDisableScalarForApprovalBB();
			break;
		default:
			break;
		}
	}

	private void isDisableScalarForApprovalBB() {
		boolean disableScalars = false;
		DealValidation dealValidation = getF_IN_dealValidation();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_IB_DealValidations iboce_IB_DealValidations = (IBOCE_IB_DealValidations) factory.findByPrimaryKey(IBOCE_IB_DealValidations.BONAME, 
				dealValidation.getDealValidationID(), true);
		if(ValidationExceptionConstants.STATUS_APPROVED.equalsIgnoreCase(iboce_IB_DealValidations.getF_IBSTATUS()) ||
				ValidationExceptionConstants.STATUS_REJECTED.equalsIgnoreCase(iboce_IB_DealValidations.getF_IBSTATUS()))
		{
			disableScalars = true;
		}
		setF_OUT_disableScalars(disableScalars);
	}

	private void isDisableScalarForInfoBB() {
		boolean disableScalars = true;
		DealValidation dealValidation = getF_IN_dealValidation();
		if(!IBConstants.VIEWMODE.equalsIgnoreCase(getF_IN_bbMode()) && null != dealValidation && 
				ValidationExceptionConstants.ACTION_APPROVAL.equalsIgnoreCase(dealValidation.getActionType()))
		{
			disableScalars = false;
		}
		setF_OUT_disableScalars(disableScalars);
	}
}
