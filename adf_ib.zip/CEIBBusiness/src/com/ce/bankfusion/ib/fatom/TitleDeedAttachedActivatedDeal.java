package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_TitleDeedAttachedActivatedDeal;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.ib.types.TitleDeedAttachedDealResponse;

public class TitleDeedAttachedActivatedDeal extends AbstractCE_IB_TitleDeedAttachedActivatedDeal {

	private static final long serialVersionUID = 1L;

	@SuppressWarnings("deprecation")
	public TitleDeedAttachedActivatedDeal(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID + " = ? AND "+IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDVERSIONNUM + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(getF_IN_titleDeedID());
		params.add(String.valueOf(getF_IN_versionNumber()));
		List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetails = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME,
				whereClause, params, null, false);
		boolean attachedToActiveDeal = false;
		List<String> inActiveStatus = new ArrayList<>();
		inActiveStatus.add(IBConstants.CLOSED);
		inActiveStatus.add(IBConstants.CANCELLED);
		inActiveStatus.add(CeConstants.DEAL_STATUS_EXPIRED);
		inActiveStatus.add(IBConstants.REJECTED);
		if (titleDeedDetails != null && titleDeedDetails.size() > 0) {
			for(IBOCE_IB_DealTitleDeedDtls titleDeedDtl : titleDeedDetails) {
				IBOIB_DLI_DealDetails dealDetail = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, titleDeedDtl.getF_IBDEALNUMBER());
				if(!inActiveStatus.contains(dealDetail.getF_Status())){
					attachedToActiveDeal = true;
					break;
				}
			}
		}
	    setF_OUT_attached(attachedToActiveDeal);
	}
}
