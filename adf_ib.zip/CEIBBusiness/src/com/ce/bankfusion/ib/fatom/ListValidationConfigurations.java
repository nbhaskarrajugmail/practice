package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ValidationConfiguration;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_ListValidationConfs;
import com.misys.bankfusion.subsystem.organisationgroup.mbean.impl.OrganizationGroupService;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;
import bf.com.misys.ib.types.ListValidationConfsRq;
import bf.com.misys.ib.types.ListValidationConfsRs;
import bf.com.misys.ib.types.ValidationConf;
import bf.com.misys.ib.types.ValidationConfSearch;

public class ListValidationConfigurations extends AbstractCE_IB_ListValidationConfs{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2765196491355517586L;

	public ListValidationConfigurations()
	{
		super();
	}

	public ListValidationConfigurations(BankFusionEnvironment env)
	{
		super(env);
	}
	
	@Override
	public void process(BankFusionEnvironment env)
	{
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = "WHERE " + IBOCE_IB_ValidationConfiguration.IBVALIDATIONID + " LIKE ? AND "
				+ IBOCE_IB_ValidationConfiguration.IBPROCESSCONFIGID + " LIKE ? AND "
				+ IBOCE_IB_ValidationConfiguration.IBSTEPID + " LIKE ?";
		ListValidationConfsRs response = new ListValidationConfsRs();
		
		ListValidationConfsRq request = getF_IN_listValidationConfsRq();
		ValidationConfSearch searchFilter = request.getValidation();
		PagingRequest pageInfo = request.getPagedQuery().getPagingRequest();
		ArrayList<String> params = prepareParamsList(searchFilter);
		
		IPagingData pagingData = new PagingData(pageInfo.getRequestedPage()==0?1:pageInfo.getRequestedPage(), 
				pageInfo.getNumberOfRows()==0?10:pageInfo.getNumberOfRows());
        pagingData.setRequiresTotalPages(true);
        List<IBOCE_IB_ValidationConfiguration> validationConfs = factory.findByQuery(IBOCE_IB_ValidationConfiguration.BONAME, whereClause, params, pagingData, false);
        if(null != validationConfs && !validationConfs.isEmpty())
        {
        	for(IBOCE_IB_ValidationConfiguration validationConfFromDB : validationConfs)
        	{
        		ValidationConf conf = new ValidationConf();
				conf.setActionType(validationConfFromDB.getF_IBACTIONTYPE());
				conf.setApprovalUserID(validationConfFromDB.getF_IBAPPROVALUSERID());
				if(validationConfFromDB.isF_IBGROUP())
				{
					conf.setApprovalUserName(OrganizationGroupService.getInstance().getGroupName(validationConfFromDB.getF_IBAPPROVALUSERID()));
				}
				else
				{
					conf.setApprovalUserName(validationConfFromDB.getF_IBAPPROVALUSERID());
				}
				conf.setProcessID(validationConfFromDB.getF_IBPROCESSCONFIGID());
				conf.setStepID(validationConfFromDB.getF_IBSTEPID());
				conf.setValidationConfID(validationConfFromDB.getBoID());
				conf.setValidationID(validationConfFromDB.getF_IBVALIDATIONID());
				conf.setIsFilterBasedOnBranch(validationConfFromDB.isF_IBFILTERBYBRANCH());
				conf.setIsGroup(validationConfFromDB.isF_IBGROUP());
				conf.setSelect(false);
				response.addValidations(conf);
        	}
        }
        if(response.getValidationsCount() > 0)
        {
        	response.getValidations(0).setSelect(true);
        }
        PagingRequest pageInfoRes = new PagingRequest();
        pageInfoRes.setNumberOfRows(pagingData.getPageSize());
        pageInfoRes.setRequestedPage(pagingData.getCurrentPageNumber());
        pageInfoRes.setTotalPages(pagingData.getTotalPages());	
        PagedQuery pagedQuery = new PagedQuery();
        pagedQuery.setPagingRequest(pageInfoRes);
        response.setPagedQuery(pagedQuery);
        
        setF_OUT_listValidationConfsRs(response);
	}

	private ArrayList<String> prepareParamsList(ValidationConfSearch searchFilter) {
		ArrayList<String> params = new ArrayList<>();
		if(StringUtils.isNotBlank(searchFilter.getValidationID()))
		{
			params.add("%"+searchFilter.getValidationID()+"%");
		}
		else
		{
			params.add("%");
		}
		if(StringUtils.isNotBlank(searchFilter.getProcessID()))
		{
			params.add("%"+searchFilter.getProcessID()+"%");
		}
		else
		{
			params.add("%");
		}
		if(StringUtils.isNotBlank(searchFilter.getStepID()))
		{
			params.add("%"+searchFilter.getStepID()+"%");
		}
		else
		{
			params.add("%");
		}
		return params;
	}
}
