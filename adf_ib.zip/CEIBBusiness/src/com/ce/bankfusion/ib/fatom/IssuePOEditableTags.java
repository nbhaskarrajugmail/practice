package com.ce.bankfusion.ib.fatom;

import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_IssuePOEditableTags;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class IssuePOEditableTags extends AbstractCE_IB_IssuePOEditableTags {

    private static final long serialVersionUID = 7137308733675905581L;

    public IssuePOEditableTags(BankFusionEnvironment env) {
        super(env);

    }

    public IssuePOEditableTags() {
        super();

    }

    @Override
    public void process(BankFusionEnvironment env) {
        String poStatus = getF_IN_poStatus();
        if (isF_IN_viewMode()) {
            setF_OUT_payNewRowViewMode(true);
            setF_OUT_paySaveRemViewMode(true);
            setF_OUT_payScallersViewMode(true);
        } else {
            if ((!"New".equalsIgnoreCase(poStatus) && !"".equalsIgnoreCase(poStatus))) {
                if (isF_IN_poScallersViewMode() && isF_IN_poSaveRemViewMode()) {
                    setF_OUT_paySaveRemViewMode(true);
                    setF_OUT_payScallersViewMode(true);
                    setF_OUT_payNewRowViewMode(true);
                }
            } else {
                setF_OUT_payNewRowViewMode(false);
                setF_OUT_paySaveRemViewMode(true);
                setF_OUT_payScallersViewMode(true);
            }
        }
    }

}
