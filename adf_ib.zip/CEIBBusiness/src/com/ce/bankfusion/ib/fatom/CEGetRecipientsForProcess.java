package com.ce.bankfusion.ib.fatom;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessUserGroupMap;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealStepUserAssignMap;
import com.misys.bankfusion.ib.steps.refimpl.AbstractIB_CMN_GetRecipientsForProcess;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.ib.util.StepSetupUtils;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.bo.refimpl.IBOBranch;
import com.trapedza.bankfusion.bo.refimpl.IBOOrganisationGroupUser;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.types.RuleExecRsData;
import bf.com.misys.ib.ilo.types.RecipientResponsePayload;
import bf.com.misys.ib.ilo.types.UserDetails;
import bf.com.misys.ib.ilo.types.UserList;

/**
 * @author Aklesh
 */
public class CEGetRecipientsForProcess extends AbstractIB_CMN_GetRecipientsForProcess {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    IPersistenceObjectsFactory factory;

    private static final String usersAndGroupsWhereClause =
        "WHERE " + IBOIB_CFG_ProcessUserGroupMap.PROCESSCONFIGID + " =? AND " + IBOIB_CFG_ProcessUserGroupMap.STEPID + "=?";

    // private static final String usersWhereClause = "WHERE " + IBOOrganisationGroupUser.GROUPID +
    // " =?";
    private transient final static Log logger = LogFactory.getLog(CEGetRecipientsForProcess.class.getName());
    
    public CEGetRecipientsForProcess(BankFusionEnvironment env) {
        super(env);
    }

    public CEGetRecipientsForProcess() {
        super();
    }

    @Override
    public void process(BankFusionEnvironment env) throws BankFusionException {
        factory = BankFusionThreadLocal.getPersistanceFactory();
        UserList userList = new UserList();

        IBOIB_CFG_StepDetails currentStepDetails = IBCommonUtils.getStepDetails(getF_IN_stepID(),
				getF_IN_processConfigID());
		if (currentStepDetails == null) {
			currentStepDetails = IBCommonUtils.getStepDetails(getF_IN_stepID());
		}
		if (!getF_IN_payLoadObj().isIsDealEnquiry()) {
			// Reading deal level assigned users
			if (!IBConstants.STEP_TYPE_VOTING.equals(currentStepDetails.getF_STEPTYPE()))
				getDealLevelReassignedUsers(userList);
			// If Deal level Re-assignments are not there reading from process step level
			// assigned users
			if (userList.getUserDetailsListCount() == 0)
				getProcessLevelAssignedUserd(userList);
		}

        /*
         * for (IBOIB_CFG_ProcessUserGroupMap userOrGroup : usersAndGroups) { // TODO Placeholder to execute and filter users from Rule if
         * (executeRule(userOrGroup.getF_RULEID(), getF_IN_dealID(), userOrGroup.getF_USERORGROUPID())) { if
         * (userOrGroup.getF_USERORGROUPTYPE().equals("Group")) { params.clear(); params.add(userOrGroup.getF_USERORGROUPID());
         * List<IBOOrganisationGroupUser> users = factory.findByQuery(IBOOrganisationGroupUser.BONAME, usersWhereClause, params, null,
         * true); for (IBOOrganisationGroupUser user : users) { UserDetails userDetails = new UserDetails();
         * userDetails.setGroupId(user.getF_GROUPID()); userDetails.setUserName(user.getF_USERNAME()); userDetails.setSelect(false);
         * userList.addUserDetailsList(userDetails); } } else { UserDetails userDetails = new UserDetails();
         * userDetails.setGroupId(CommonConstants.EMPTY_STRING); userDetails.setUserName(userOrGroup.getF_USERORGROUPID());
         * userDetails.setSelect(false); userList.addUserDetailsList(userDetails); } } }
         */
		if(userList.getUserDetailsListCount() ==0)
		{
			HashMap<String, Object> inputParams = new HashMap<String, Object>();
			inputParams.put("islamicBankingObject", getF_IN_payLoadObj());
			HashMap outputParams = MFExecuter.executeMF(IBConstants.GET_RECIPIENTS_FOR_UNASSIGNED_STEP_MF,
					BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
			RecipientResponsePayload recipientResponsePayload = (RecipientResponsePayload) outputParams.get("recipientResponsePayload");
			if(null != recipientResponsePayload && recipientResponsePayload.getOwnersListCount() > 0 )
			{
				userList.setUserDetailsList(recipientResponsePayload.getOwnersList());
			}
		}
		if(CEGetRelaunchDealDtls.loadRelaunchingDeals().contains(getF_IN_payLoadObj().getDealID()))
		{
			logger.info("CEGetRecipient :: Deal ID ::" + getF_IN_payLoadObj().getDealID());
			userList.removeAllUserDetailsList();
			String userID = CEGetRelaunchDealDtls.loadDealStepUserIDMapping().get(getF_IN_payLoadObj().getDealID()+getF_IN_stepID());
			logger.info("CEGetRecipient :: User ID ::" + userID);
			if(null == userID)
			{
				userID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.FOLLOWUP_PROPERTY_FILE,
			            "USER_ID_FOR_DEAL_RELAUNCH", "", CeConstants.ADFIBCONFIGLOCATION);
				logger.info("CEGetRecipient :: User ID :: " + userID);
			}
			getUserListForUsers(userID, userList);
		}
        setF_OUT_UserList(userList);
    }

    private void getProcessLevelAssignedUserd(UserList userList) {
		IBOBranch parentBranch=null;
		boolean flag=false;
        ArrayList<String> branchData = new ArrayList<String>();
    	ArrayList<String> params = new ArrayList<String>();
        params.add(getF_IN_processConfigID());
        params.add(getF_IN_stepID());
        List<IBOIB_CFG_ProcessUserGroupMap> usersAndGroups =
            factory.findByQuery(IBOIB_CFG_ProcessUserGroupMap.BONAME, usersAndGroupsWhereClause, params, null, true);
        StringBuilder parameterString = new StringBuilder();
        params.clear();
        
        IBOIB_CFG_StepDetails stepDetails = StepSetupUtils.findStepDetailsProcessConfIdAndUniqueStepId(getF_IN_stepID(), getF_IN_processConfigID());
		boolean usersToBeFilteredByDealBranch = (null != stepDetails && stepDetails.isF_FILTERBYDEALBRANCHUSRS())?true:false;
        String dealID = getF_IN_payLoadObj().getDealID();
        IBOIB_DLI_DealDetails dealdetails = null;
        String dealBranch = null;
        if(usersToBeFilteredByDealBranch && StringUtils.isNotBlank(dealID))
        {
        	dealdetails = (IBOIB_DLI_DealDetails) factory.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
        	if(null != dealdetails)
        	{
        		dealBranch = dealdetails.getF_BranchSortCode();
        	}
        }
        if(null!=dealBranch) {
    		String branchCode= dealBranch;
    		do {
    			parentBranch = (IBOBranch) factory.findByPrimaryKey(IBOBranch.BONAME, branchCode, true);
    			branchCode= parentBranch.getF_BMBRANCH();
    			if(!parentBranch.getBoID().equals(branchCode)) {
    			branchData.add(branchCode);
    			}
    			else {
    				parentBranch=null;
    			}
    			
    		} while(null!=parentBranch);
        }
        for (IBOIB_CFG_ProcessUserGroupMap userOrGroup : usersAndGroups) {
        	if (executeRule(userOrGroup.getF_RULEID(), getF_IN_dealID(), userOrGroup.getF_USERORGROUPID())) {
        		if (userOrGroup.getF_USERORGROUPTYPE().equals("Group")) {
        			parameterString.append(",?");
        			params.add(userOrGroup.getF_USERORGROUPID());
        		} else {
        			if(!usersToBeFilteredByDealBranch || null == dealBranch || IBCommonUtils.userBelongsToDealBranch(dealBranch, userOrGroup.getF_USERORGROUPID()))
        			{
    					userList = getUserListForUsers(userOrGroup.getF_USERORGROUPID(), userList);
        			}
        		}
        	}
        }
        if (!params.isEmpty()) {
            parameterString = parameterString.deleteCharAt(0);
            String query = "WHERE " + IBOOrganisationGroupUser.GROUPID + " IN (" + parameterString + ")";
            List<IBOOrganisationGroupUser> users = factory.findByQuery(IBOOrganisationGroupUser.BONAME, query, params, null, true);
            if (null != users && !users.isEmpty()) {
            	for (IBOOrganisationGroupUser user : users) {
            		if(!usersToBeFilteredByDealBranch || null == dealBranch || IBCommonUtils.userBelongsToDealBranch(dealBranch, user.getF_USERNAME()))
            		{
    	        		userList = getUserListForGroupUsers(user, userList);
            		}
            	}
            }
        }
        if(userList.getUserDetailsListCount()==0) {
        	if(null!=dealBranch &&  usersToBeFilteredByDealBranch) {
                for(String branch: branchData) {
                	for (IBOIB_CFG_ProcessUserGroupMap userOrGroup : usersAndGroups) {
                		if (executeRule(userOrGroup.getF_RULEID(), getF_IN_dealID(), userOrGroup.getF_USERORGROUPID())) {
                			if (!userOrGroup.getF_USERORGROUPTYPE().equals("Group")) {
                    			if(branch != dealBranch && IBCommonUtils.userBelongsToDealBranch(branch, userOrGroup.getF_USERORGROUPID())) {
                	        		userList = getUserListForUsers(userOrGroup.getF_USERORGROUPID(), userList);
                	        		flag = true;  
                    			 }
                			}
                		}
                	}
                	if (!params.isEmpty()) {
                        String query = "WHERE " + IBOOrganisationGroupUser.GROUPID + " IN (" + parameterString + ")";
                        List<IBOOrganisationGroupUser> users = factory.findByQuery(IBOOrganisationGroupUser.BONAME, query, params, null, true);
                        if (null != users && !users.isEmpty()) {
                        	for (IBOOrganisationGroupUser user : users) {
                        		if(branch != dealBranch && IBCommonUtils.userBelongsToDealBranch(branch, user.getF_USERNAME()))
                        		{
                	        		userList = getUserListForGroupUsers(user, userList);
                	        		flag=true;
                        		}
                        	}
                        }
                    }
                	if(flag==true || userList.getUserDetailsListCount()!=0) {
                		break;
                	}
                }
        	}
        }
    }
    
    private UserList getUserListForUsers(String userId, UserList userList) {
    	
    	UserDetails userDetails = new UserDetails();
		userDetails.setGroupId(CommonConstants.EMPTY_STRING);
		userDetails.setUserName(userId);
		userDetails.setSelect(false);
		userList.addUserDetailsList(userDetails);		
		return userList;	
    }
   
    private UserList getUserListForGroupUsers(IBOOrganisationGroupUser user, UserList userList) {
    	
    	UserDetails userDetails = new UserDetails();
    	userDetails.setGroupId(user.getF_GROUPID());
    	userDetails.setUserName(user.getF_USERNAME());
    	userDetails.setSelect(false);
    	userList.addUserDetailsList(userDetails);
    	return userList;
    }
    
    private void getDealLevelReassignedUsers(UserList userList) {
        String existingValuesQuery = " where " + IBOIB_IDI_DealStepUserAssignMap.DEALID + " = ? and "
                + IBOIB_IDI_DealStepUserAssignMap.PROCESSCONFIGID + " = ? and " + IBOIB_IDI_DealStepUserAssignMap.TRANSACTIONID
                + " = ? and "+ IBOIB_IDI_DealStepUserAssignMap.STEPID + " = ?";
        ArrayList ipParamsOfMap = new ArrayList();
        ipParamsOfMap.add(getF_IN_payLoadObj().getDealID());
        ipParamsOfMap.add(getF_IN_processConfigID());
        ipParamsOfMap.add(getF_IN_payLoadObj().getTransactionID());
        ipParamsOfMap.add(getF_IN_stepID());
        List<IBOIB_IDI_DealStepUserAssignMap> dealStepUserAssignMap = factory.findByQuery(IBOIB_IDI_DealStepUserAssignMap.BONAME,
                existingValuesQuery, ipParamsOfMap, null);
        if(null != dealStepUserAssignMap && !dealStepUserAssignMap.isEmpty())
        {
            for (IBOIB_IDI_DealStepUserAssignMap dealStepUserAssignMapDB : dealStepUserAssignMap) {

                UserDetails userDetails = new UserDetails();
                userDetails.setGroupId(CommonConstants.EMPTY_STRING);
                userDetails.setUserName(dealStepUserAssignMapDB.getF_USERID());
                userDetails.setSelect(false);
                userList.addUserDetailsList(userDetails);
            }
        }
    }

    public boolean executeRule(String ruleID, String dealID, String userGroupId) {
        boolean isUserEligible = true;
        String ruleOutput = "";
        if (null != ruleID && IBCommonUtils.isNotEmpty(ruleID)) {
            String productId = getF_IN_productId();
            String subProductId = getF_IN_subProductId();
            RuleExecRsData ruleResponse = IBCommonUtils.getRuleAndExecuteForProcess(ruleID, dealID, productId, subProductId);
            if (null != ruleResponse && null != ruleResponse.getRuleData()) {
                List<String> responseList = (List<String>) ruleResponse.getRuleData();
                if (ruleResponse.getRuleType().equals(IBConstants.RULE_TYPE_CONDITION_CONSTANT) && ruleResponse.getRuleData() != null
                    && responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
                    /*
                     * if (responseList.size() > CommonConstants.INTEGER_ZERO && responseList.get(CommonConstants.INTEGER_ZERO) != null) {
                     */
                    ruleOutput = String.valueOf(responseList.get(CommonConstants.INTEGER_ZERO));
                    if (ruleOutput.equalsIgnoreCase("false")) {
                        logger.info("Condition is false so skiping user/group " + userGroupId + " for task assignment of deal " + dealID);
                        isUserEligible = false;
                    }
                    // }
                }

            }
        }
        return isUserEligible;
    }
}
