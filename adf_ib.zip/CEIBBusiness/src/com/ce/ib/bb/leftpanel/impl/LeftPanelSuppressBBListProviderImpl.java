package com.ce.ib.bb.leftpanel.impl;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.CeConstants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.finastra.ib.bb.leftpanel.ILeftPanelSuppressBBListProvider;
import com.finastra.ib.bb.leftpanel.dto.LeftPanelSuppressBB;

public class LeftPanelSuppressBBListProviderImpl implements ILeftPanelSuppressBBListProvider {

	private transient final static Log logger = LogFactory.getLog(LeftPanelSuppressBBListProviderImpl.class.getName());

	@Override
	public Set<String> getLeftPanelSuppressBBList() {
		ObjectMapper mapper =  new ObjectMapper();
		HashSet<String> leftPanelSuppressBBFinalList = new HashSet<>();
		HashSet<LeftPanelSuppressBB> leftPanelSuppressBBList =null;
		String jsonFile = System.getProperty(CeConstants.ADFIBCONFIGLOCATION)+"conf/business/leftPanelSuppressBBList.json";
		try {
			leftPanelSuppressBBList = mapper.readValue(new File(jsonFile),
					new TypeReference<HashSet<LeftPanelSuppressBB>>() {});
		} catch (Exception e) {
			logger.error("Error while reading the " +jsonFile );
		} 
		if(null != leftPanelSuppressBBList && !leftPanelSuppressBBList.isEmpty())
		{
			for(LeftPanelSuppressBB eachEntry : leftPanelSuppressBBList)
			{
				leftPanelSuppressBBFinalList.add(eachEntry.getBuildingBlockID());
			}
		}
		return leftPanelSuppressBBFinalList;
	}

}
