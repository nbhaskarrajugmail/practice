/**
 * 
 */
package com.ce.ib.cfg.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


/**
 * @author bnandima
 *
 */
@XmlRootElement(name = "holdrules")
public class HoldRule {
	private List<RuleDTO> rule;
	public HoldRule() {}
	public HoldRule(List<RuleDTO> rule) {
		super();
		this.rule = rule;
	}
	@XmlElement
	public List<RuleDTO> getRule() {
		return rule;
	}
	public void setRule(List<RuleDTO> rule) {
		this.rule = rule;
	}

	
	
	

}
