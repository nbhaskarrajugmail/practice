package com.ce.ib.cfg.dto;

import java.sql.Date;

import bf.com.misys.ib.types.RegistryList;

public class RegistryDto {

	private String registryId;
	private String referenceNumber;
	private Date registryDate;
	private String documentNumber;
	private Date documentDate;
	private String registryStatus;
	private RegistryList registryList;

	public String getRegistryId() {
		return registryId;
	}

	public void setRegistryId(String registryId) {
		this.registryId = registryId;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public Date getRegistryDate() {
		return registryDate;
	}

	public void setRegistryDate(Date registryDate) {
		this.registryDate = registryDate;
	}

	public String getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getRegistryStatus() {
		return registryStatus;
	}

	public void setRegistryStatus(String registryStatus) {
		this.registryStatus = registryStatus;
	}

	/**
	 * @return the registryList
	 */
	public RegistryList getRegistryList() {
		return registryList;
	}

	/**
	 * @param registryList the registryList to set
	 */
	public void setRegistryList(RegistryList registryList) {
		this.registryList = registryList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RegistryDto [registryId=" + registryId + ", referenceNumber=" + referenceNumber + ", registryDate="
				+ registryDate + ", documentNumber=" + documentNumber + ", documentDate=" + documentDate
				+ ", registryStatus=" + registryStatus + ", registryList=" + registryList + "]";
	}
}
