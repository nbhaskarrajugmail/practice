/**
 * 
 */
package com.ce.ib.cfg.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "subproductFrequency")
public class SubproductFrequency {
	private List<SubproductFrequencyDtl> subproductFrequencyDtl;
	public SubproductFrequency() {}
	public SubproductFrequency(List<SubproductFrequencyDtl> subproductFrequencyDtl) {
		super();
		this.subproductFrequencyDtl = subproductFrequencyDtl;
	}
	@XmlElement
	public List<SubproductFrequencyDtl> getSubproductFrequencyDtl() {
		return subproductFrequencyDtl;
	}
	public void setSubproductFrequencyDtl(List<SubproductFrequencyDtl> subproductFrequencyDtl) {
		this.subproductFrequencyDtl = subproductFrequencyDtl;
	}

}
