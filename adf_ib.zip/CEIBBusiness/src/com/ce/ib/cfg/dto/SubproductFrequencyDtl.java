package com.ce.ib.cfg.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "relationshipDtl")
public class SubproductFrequencyDtl {
	
	String subproductId;
	String monthlyFrequency;
	String quarterlyFrequency;
	String halfyearlyFrequency;
	String yearlyFrequency;
	
	public SubproductFrequencyDtl() {
	}

	public SubproductFrequencyDtl(String subproductId, String monthlyFrequency, String quarterlyFrequency,
			String halfyearlyFrequency, String yearlyFrequency) {
		super();
		this.subproductId = subproductId;
		this.monthlyFrequency = monthlyFrequency;
		this.quarterlyFrequency = quarterlyFrequency;
		this.halfyearlyFrequency = halfyearlyFrequency;
		this.yearlyFrequency = yearlyFrequency;
	}
	
	public String getSubproductId() {
		return subproductId;
	}
	
	@XmlElement(name = "subproductId")
	public void setSubproductId(String subproductId) {
		this.subproductId = subproductId;
	}
	
	public String getMonthlyFrequency() {
		return monthlyFrequency;
	}
	
	@XmlElement(name = "monthlyFrequency")
	public void setMonthlyFrequency(String monthlyFrequency) {
		this.monthlyFrequency = monthlyFrequency;
	}
	
	public String getQuarterlyFrequency() {
		return quarterlyFrequency;
	}
	
	@XmlElement(name = "quarterlyFrequency")
	public void setQuarterlyFrequency(String quarterlyFrequency) {
		this.quarterlyFrequency = quarterlyFrequency;
	}
	
	public String getHalfyearlyFrequency() {
		return halfyearlyFrequency;
	}
	
	@XmlElement(name = "halfyearlyFrequency")
	public void setHalfyearlyFrequency(String halfyearlyFrequency) {
		this.halfyearlyFrequency = halfyearlyFrequency;
	}
	
	public String getYearlyFrequency() {
		return yearlyFrequency;
	}
	
	@XmlElement(name = "yearlyFrequency")
	public void setYearlyFrequency(String yearlyFrequency) {
		this.yearlyFrequency = yearlyFrequency;
	}

	@Override
	public String toString() {
		return "SubproductFrequencyDtl [subproductId=" + subproductId + ", monthlyFrequency=" + monthlyFrequency
				+ ", quarterlyFrequency=" + quarterlyFrequency + ", halfyearlyFrequency=" + halfyearlyFrequency
				+ ", yearlyFrequency=" + yearlyFrequency + "]";
	}


}