package com.ce.ib.cfg.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "relationshipDtl")
public class RelationshipDtl {
	String relationshipType;
	String displayGuranteeToPay;
	String displayPartners;
	String displayAgents;

	public RelationshipDtl() {
	}

	public RelationshipDtl(String relationshipType, String displayGuranteeToPay, String displayPartners,
			String displayAgents) {
		super();
		this.relationshipType = relationshipType;
		this.displayGuranteeToPay = displayGuranteeToPay;
		this.displayPartners = displayPartners;
		this.displayAgents = displayAgents;
	}

	public String getRelationshipType() {
		return relationshipType;
	}

	@XmlElement(name = "relationshipType")
	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public String getDisplayGuranteeToPay() {
		return displayGuranteeToPay;
	}

	@XmlElement(name = "displayGuranteeToPay")
	public void setDisplayGuranteeToPay(String displayGuranteeToPay) {
		this.displayGuranteeToPay = displayGuranteeToPay;
	}

	public String getDisplayPartners() {
		return displayPartners;
	}

	@XmlElement(name = "displayPartners")
	public void setDisplayPartners(String displayPartners) {
		this.displayPartners = displayPartners;
	}

	public String getDisplayAgents() {
		return displayAgents;
	}

	@XmlElement(name = "displayAgents")
	public void setDisplayAgents(String displayAgents) {
		this.displayAgents = displayAgents;
	}

	@Override
	public String toString() {
		return "RelationshipDtl [relationshipType=" + relationshipType + ", displayGuranteeToPay="
				+ displayGuranteeToPay + ", displayPartners=" + displayPartners + ", displayAgents=" + displayAgents
				+ "]";
	}

}