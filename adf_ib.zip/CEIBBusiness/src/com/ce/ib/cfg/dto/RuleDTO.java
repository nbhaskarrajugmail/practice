package com.ce.ib.cfg.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "rule")
public class RuleDTO{
	String id;
	String status;
	String reason;
	public RuleDTO() {}

	public RuleDTO(String id, String status, String reason) {
		super();
		this.id = id;
		this.status = status;
		this.reason = reason;
	}
	@XmlElement(name = "id" )
	public void setId(String id) {
		this.id = id;
	}
	@XmlElement(name = "status" )
	public void setStatus(String status) {
		this.status = status;
	}
	@XmlElement(name = "reason" )
	public void setReason(String reason) {
		this.reason = reason;
	}
	


	public String getId() {
		return id;
	}
	public String getStatus() {
		return status;
	}
	public String getReason() {
		return reason;
	}
	@Override
	public String toString() {
		return "Rule [id=" + id + ", status=" + status + ", reason=" + reason + "]";
	}
	
}