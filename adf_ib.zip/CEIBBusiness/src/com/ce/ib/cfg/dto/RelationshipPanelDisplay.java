/**
 * 
 */
package com.ce.ib.cfg.dto;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "relationshipPanelDisplay")
public class RelationshipPanelDisplay {
	private List<RelationshipDtl> relationshipDtl;
	public RelationshipPanelDisplay() {}
	public RelationshipPanelDisplay(List<RelationshipDtl> relationshipDtl) {
		super();
		this.relationshipDtl = relationshipDtl;
	}
	@XmlElement
	public List<RelationshipDtl> getRelationshipDtl() {
		return relationshipDtl;
	}
	public void setRelationshipDtl(List<RelationshipDtl> relationshipDtl) {
		this.relationshipDtl = relationshipDtl;
	}

}
