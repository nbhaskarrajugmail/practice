/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: AccountingEntryBuildingBlock.java,v.1.0,Aug 13, 2013 7:05:12 AM Aklesh
 *
 */
package com.ce.ib.buildingblock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import bf.com.misys.bankfusion.attributes.UserDefinedFld;
import bf.com.misys.ce.api.dto.ADFCustomerPersonalInfo;
import bf.com.misys.ce.api.dto.ADFDealCustomerInfo;
import bf.com.misys.ce.api.dto.ADFEnterpriseCustomerInfo;
import bf.com.misys.ce.api.dto.ADFSetCustomerInfo;
import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.api.bb.dto.CustomerContactDetails;
import bf.com.misys.ib.api.bb.dto.CustomerCreditDetails;
import bf.com.misys.ib.api.bb.dto.CustomerEmploymentDetails;
import bf.com.misys.ib.api.bb.dto.CustomerPermanentAddress;
import bf.com.misys.ib.api.bb.dto.CustomerPersonalDetails;
import bf.com.misys.ib.api.bb.dto.CustomerPersonalInfo;
import bf.com.misys.ib.api.bb.dto.DealCustomerInfo;
import bf.com.misys.ib.api.bb.dto.EnterpriseContactDetails;
import bf.com.misys.ib.api.bb.dto.EnterpriseCustomerBasicDetails;
import bf.com.misys.ib.api.bb.dto.EnterpriseCustomerInfo;
import bf.com.misys.ib.api.bb.dto.EnterprisePermanentAddress;
import bf.com.misys.ib.api.bb.dto.SetCustomerInfo;
import bf.com.misys.ib.services.ListDealCustomersRq;
import bf.com.misys.ib.services.ListDealCustomersRs;
import bf.com.misys.ib.spi.types.messages.ReadCustomerRq;
import bf.com.misys.ib.spi.types.messages.ReadCustomerRs;
import bf.com.misys.ib.spi.types.messages.RescheduleLoanRs;
import bf.com.misys.ib.types.CeDealCustomerInfo;
import bf.com.misys.ib.types.CustomerInfoEditableTags;
import bf.com.misys.ib.types.ExtensionDetails;
import bf.com.misys.ib.types.InputListDealCustomersRq;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.ListDealCustomer;
import bf.com.misys.ib.types.ListDealCustomers;
import bf.com.misys.ib.types.PartyDetails;
import bf.com.misys.ib.types.ProductConfiguration;
import bf.com.misys.ib.types.header.RqHeader;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.misys.ib.spi.IBSPIConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

public class DealCustomerInfoBuildingBlock extends AbstractIslamicBuildingBlock {

    private static final String PROSPECT = "PROSPECT";
	private static final String TITLE_GCCODE = "002";

	@Override
    public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
        String mode = CommonConstants.EMPTY_STRING;
        if (buildingBlockConfig != null) {
            mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
            buildingBlockConfig.getF_EDITMODES();
        }
        if (isDealEnquiry) {
            mode = BuildingBlockConstants.MODE_VIEW;
        }
        CustomerInfoEditableTags readOnlyTags = new CustomerInfoEditableTags();
        if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
            readOnlyTags.setPartyId(true);
        } else {
            readOnlyTags.setPartyId(false);
        }
        return readOnlyTags;
    }

    /*
     * (non-Javadoc)
     * @see com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock#isBuildingBlockSuppresed(bf.com.misys .ib.types.IslamicBankingObject)
     */
    @Override
    public boolean isBuildingBlockSuppresed(IslamicBankingObject islamicBankingObject) {
        String whereClause =
            "WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + "=? AND " + IBOIB_IDI_DealCustomerDetail.ASSOCIATIONTYPE + "!=?";
        ArrayList<String> params = new ArrayList<String>();
        params.add(islamicBankingObject.getDealID());
        params.add("GC");
        List<IBOIB_IDI_DealCustomerDetail> dealCustomers = (List<IBOIB_IDI_DealCustomerDetail>) BankFusionThreadLocal
            .getPersistanceFactory().findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, whereClause, params, null, true);
        return (dealCustomers.size() > CommonConstants.INTEGER_ZERO ? false : true);
    }

    @Override
    public AbstractBuildingBlock getBuildingBlockDetails(IslamicBankingObject islamicBankingObject) {
        // IBCommonUtils.refreshPersistenceFactory();
        ADFDealCustomerInfo dealCustomerInfo = null;
        dealCustomerInfo = listDealCustomers(islamicBankingObject);
        return dealCustomerInfo;
    }

    private ADFDealCustomerInfo listDealCustomers(IslamicBankingObject islamicBankingObject) {

        ListDealCustomersRq listDealCustomersRq = new ListDealCustomersRq();
        listDealCustomersRq.setRqHeader(new RqHeader());
        new ArrayList();

        InputListDealCustomersRq inputListDealCustomersRq = new InputListDealCustomersRq();
        inputListDealCustomersRq.setDealId(islamicBankingObject.getDealID());
        listDealCustomersRq.setInputListDealCustomersRq(inputListDealCustomersRq);

        HashMap inputParams_0 = new HashMap();
        inputParams_0.put("ListDealCustomersRq", listDealCustomersRq);
        HashMap outputParams_0 =
            MFExecuter.executeMF("IB_IDI_ListDealCustomers_SRV", IBCommonUtils.getBankFusionEnvironment(), inputParams_0);

        ListDealCustomersRs listDealCustomersRs = (ListDealCustomersRs) outputParams_0.get("ListDealCustomersRs");

        ListDealCustomer listDealCustomer[] = listDealCustomersRs.getDealCustomerDetails().getCustomerList().getListDealCustomer();
        ADFDealCustomerInfo dealCustomerInfo = new ADFDealCustomerInfo();

        List<ADFCustomerPersonalInfo> customerPersonalInfo = new ArrayList<ADFCustomerPersonalInfo>();
        List<ADFEnterpriseCustomerInfo> enterpriseCustomerInfo = new ArrayList<ADFEnterpriseCustomerInfo>();

        String partyType = "";

        for (int i = 0; i < listDealCustomer.length; i++) {
            ListDealCustomer listDealCustomer1 = (ListDealCustomer) listDealCustomer[i];
            String customer_Id = listDealCustomer1.getCustomerId();
            if(customer_Id!=null && !customer_Id.isEmpty()){
	            boolean isPrimaryCustomer = listDealCustomer1.getIsPrimaryCustomer();
	
	            ReadCustomerRq readCustomerRq = new ReadCustomerRq();
	            readCustomerRq.setCustomerID(customer_Id);
	            readCustomerRq.setRqHeader(new RqHeader());
	
	            HashMap inputParams_1 = new HashMap();
	            inputParams_1.put("ReadCustomerRq", readCustomerRq);
	
	            HashMap outputParam_1 =
	                MFExecuter.executeMF("IB_SPI_ReadCustomer_SRV", IBCommonUtils.getBankFusionEnvironment(), inputParams_1);
	
	            ReadCustomerRs readCustomerRs = (ReadCustomerRs) outputParam_1.get("ReadCustomerRs");
	            partyType = readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getPartyType();
	
	            if (partyType.equals("1062")) {
	                customerPersonalInfo.add(set_CustomerPersonalInfo(readCustomerRs, isPrimaryCustomer, listDealCustomer1));
	            } else if (partyType.equals("1063")) {
	                enterpriseCustomerInfo.add(set_EnterpriseCustomerInfo(readCustomerRs, isPrimaryCustomer, listDealCustomer1));
	            }
            }else{
            	//populating the prospect party data if party is not created yet IBF-17769
            	customerPersonalInfo.add(set_CustomerPersonalInfo(listDealCustomer1));
            }

        }

        dealCustomerInfo.setCustomerPersonalInfo(customerPersonalInfo);
        dealCustomerInfo.setEnterpriseCustomerInfo(enterpriseCustomerInfo);

        return dealCustomerInfo;

    }

    /* **********Setting Personal Details ********* */

    private ADFCustomerPersonalInfo set_CustomerPersonalInfo(ReadCustomerRs readCustomerRs, boolean isPrimaryCustomer, ListDealCustomer listDealCustomer1)

    {
        ADFCustomerPersonalInfo customerPersonalInfo = new ADFCustomerPersonalInfo();
        customerPersonalInfo.setPartyId(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getCustomerId());
        customerPersonalInfo.setExistingOrProspect(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getPartyCategory());
        customerPersonalInfo.setPrimaryCustomer(isPrimaryCustomer);

        CustomerPersonalDetails customerPersonalDetails = set_PersonalInfo(readCustomerRs);
        customerPersonalInfo.setCustomerPersonalDetails(customerPersonalDetails);

        CustomerPermanentAddress customerPermanentAddress = set_CustomerPermanentAddres(readCustomerRs);
        customerPersonalInfo.setCustomerPermanentAddress(customerPermanentAddress);

        CustomerContactDetails customerContactDetails = set_CustomerContactDetails(readCustomerRs);
        customerPersonalInfo.setCustomerContactDetails(customerContactDetails);

        CustomerEmploymentDetails customerEmploymentDetails = set_CustomerEmploymentDetails(readCustomerRs);
        customerPersonalInfo.setCustomerEmploymentDetails(customerEmploymentDetails);

        CustomerCreditDetails customerCreditDetails = set_CustomerCreditDetails(readCustomerRs);
        customerPersonalInfo.setCustomerCreditDetails(customerCreditDetails);
        
        UserDefinedFields customerUdfs = set_CustomerUdfs(listDealCustomer1);
        customerPersonalInfo.setUserDefinedFields(customerUdfs);

        return customerPersonalInfo;

    }

    private UserDefinedFields set_CustomerUdfs(ListDealCustomer listDealCustomer1) {
    	UserDefinedFields udfs = (UserDefinedFields)listDealCustomer1.getPartyDetails().getExtensionDetails().getUserExtension();
    	
		return udfs;
	}

	private CustomerPersonalDetails set_PersonalInfo(ReadCustomerRs readCustomerRs) {
        CustomerPersonalDetails customerPersonalDetails = new CustomerPersonalDetails();

        customerPersonalDetails.setTitle(readCustomerRs.getCustomerDetails().getPersonalDetails().getTitle());
        customerPersonalDetails.setDateOfBirth(readCustomerRs.getCustomerDetails().getPersonalDetails().getDateOfBirth());
        customerPersonalDetails.setFirstName(readCustomerRs.getCustomerDetails().getPersonalDetails().getFirstName());
        customerPersonalDetails.setMiddleName(readCustomerRs.getCustomerDetails().getPersonalDetails().getMiddleName());
        customerPersonalDetails.setLastName(readCustomerRs.getCustomerDetails().getPersonalDetails().getLastName());
        customerPersonalDetails.setNationality(readCustomerRs.getCustomerDetails().getPersonalDetails().getNationality());
        customerPersonalDetails.setNoOfDependents(readCustomerRs.getCustomerDetails().getPersonalDetails().getNumberOfDependents());
        customerPersonalDetails.setPlaceOfBirth(readCustomerRs.getCustomerDetails().getPersonalDetails().getPlaceOfBirth());
        customerPersonalDetails.setGender(readCustomerRs.getCustomerDetails().getPersonalDetails().getGender());
        customerPersonalDetails.setCivilStatus(readCustomerRs.getCustomerDetails().getPersonalDetails().getResidencyStatus());

        return customerPersonalDetails;

    }

    private CustomerPermanentAddress set_CustomerPermanentAddres(ReadCustomerRs readCustomerRs) {
        CustomerPermanentAddress customerPermanentAddres = new CustomerPermanentAddress();
        customerPermanentAddres.setAddress1(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine1());
        customerPermanentAddres.setAddress2(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine2());
        customerPermanentAddres.setAddress3(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine3());
        customerPermanentAddres.setAddress4(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine4());
        customerPermanentAddres.setCountry(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getCountry());
        customerPermanentAddres.setHomePhone(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getDunsNumber());
        customerPermanentAddres.setPostCode(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getPostCode());
        customerPermanentAddres
            .setResidentialStatus(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrStatus());
        return customerPermanentAddres;

    }

    private CustomerContactDetails set_CustomerContactDetails(ReadCustomerRs readCustomerRs) {
        CustomerContactDetails customerContactDetails = new CustomerContactDetails();
        customerContactDetails.setHomePhone(readCustomerRs.getCustomerDetails().getContactDetails().getContactTelNum());
        customerContactDetails.setPersonalEmail(readCustomerRs.getCustomerDetails().getContactDetails().getContactEmailId());
        customerContactDetails.setPhoneOrMobile(readCustomerRs.getCustomerDetails().getContactDetails().getContactMobileNum());

        return customerContactDetails;

    }

    private CustomerEmploymentDetails set_CustomerEmploymentDetails(ReadCustomerRs readCustomerRs) {
        CustomerEmploymentDetails customerEmploymentDetails = new CustomerEmploymentDetails();
        if (readCustomerRs.getCustomerDetails().getPersonalDetails() != null
            && readCustomerRs.getCustomerDetails().getPersonalDetails().getEmployeeBasicDetailsCount() != 0) {
            customerEmploymentDetails
                .setEmployerName(readCustomerRs.getCustomerDetails().getPersonalDetails().getEmployeeBasicDetails(0).getEmployerName());
            customerEmploymentDetails.setEmploymentStatus(
                readCustomerRs.getCustomerDetails().getPersonalDetails().getEmployeeBasicDetails(0).getTypeOfEmployment());
            customerEmploymentDetails
                .setJobTitle(readCustomerRs.getCustomerDetails().getPersonalDetails().getEmployeeBasicDetails(0).getEmployeeTitle());
            customerEmploymentDetails
                .setStartDate(readCustomerRs.getCustomerDetails().getPersonalDetails().getEmployeeBasicDetails(0).getStartDate());
        }
        return customerEmploymentDetails;
    }

    private CustomerCreditDetails set_CustomerCreditDetails(ReadCustomerRs readCustomerRs) {
        CustomerCreditDetails customerCreditDetails = new CustomerCreditDetails();
        if (readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getCreditRatingDetailCount() != 0) {
            customerCreditDetails
                .setCreditRating(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getCreditRatingDetail(0).getCreditRating());
            customerCreditDetails.setCreditRatingAgency(
                readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getCreditRatingDetail(0).getRatingAgency());
        }
        return customerCreditDetails;
    }
    
    //populating the personal details if prospect and not created in party host yet IBF-17769
    private ADFCustomerPersonalInfo set_CustomerPersonalInfo(ListDealCustomer dealCustomer)
    
    {
    	ADFCustomerPersonalInfo customerPersonalInfo = new ADFCustomerPersonalInfo();
    	customerPersonalInfo.setPartyId(dealCustomer.getCustomerId());
    	customerPersonalInfo.setExistingOrProspect(PROSPECT);
    	customerPersonalInfo.setPrimaryCustomer(dealCustomer.isIsPrimaryCustomer());//true
    	
    	CustomerPersonalDetails customerPersonalDetails = set_PersonalInfo(dealCustomer);
    	customerPersonalInfo.setCustomerPersonalDetails(customerPersonalDetails);
    	
    	CustomerPermanentAddress customerPermanentAddress = set_CustomerPermanentAddres(dealCustomer);
    	customerPersonalInfo.setCustomerPermanentAddress(customerPermanentAddress);
    	
    	CustomerContactDetails customerContactDetails = set_CustomerContactDetails(dealCustomer);
    	customerPersonalInfo.setCustomerContactDetails(customerContactDetails);
    	
    	return customerPersonalInfo;
    	
    }
    
    private CustomerPersonalDetails set_PersonalInfo(ListDealCustomer dealCustomer) {
    	CustomerPersonalDetails customerPersonalDetails = new CustomerPersonalDetails();
    	
    	customerPersonalDetails.setTitle(IBCommonUtils.getGCChildDesc(TITLE_GCCODE, dealCustomer.getPartyDetails().getTitle()));
    	customerPersonalDetails.setDateOfBirth(dealCustomer.getDateOfBirth());
    	customerPersonalDetails.setFirstName(dealCustomer.getPartyDetails().getFirstName());
    	customerPersonalDetails.setMiddleName(dealCustomer.getPartyDetails().getMiddleName());
    	customerPersonalDetails.setLastName(dealCustomer.getPartyDetails().getLastName());
    	customerPersonalDetails.setGender(IBCommonUtils.getGCChildDesc("017",dealCustomer.getPartyDetails().getGender()));
    	return customerPersonalDetails;
    	
    }
    
    private CustomerPermanentAddress set_CustomerPermanentAddres(ListDealCustomer dealCustomer) {
    	CustomerPermanentAddress customerPermanentAddres = new CustomerPermanentAddress();
    	customerPermanentAddres.setAddress1(dealCustomer.getPartyDetails().getAddrLine1());
    	customerPermanentAddres.setAddress2(dealCustomer.getPartyDetails().getAddrLine2());
    	customerPermanentAddres.setAddress3(dealCustomer.getPartyDetails().getAddrLine3());
    	customerPermanentAddres.setAddress4(dealCustomer.getPartyDetails().getAddrLine4());
    	customerPermanentAddres.setCountry(dealCustomer.getPartyDetails().getCountryOfAddress());
    	customerPermanentAddres.setHomePhone(dealCustomer.getPartyDetails().getTelephoneNumber());
    	customerPermanentAddres.setPostCode(dealCustomer.getPartyDetails().getPostCode());
    	return customerPermanentAddres;
    	
    }
    
    private CustomerContactDetails set_CustomerContactDetails(ListDealCustomer dealCustomer) {
    	CustomerContactDetails customerContactDetails = new CustomerContactDetails();
    	customerContactDetails.setHomePhone(dealCustomer.getPartyDetails().getTelephoneNumber());
    	customerContactDetails.setPersonalEmail(dealCustomer.getPartyDetails().getEmailID());
    	return customerContactDetails;
    	
    }
    

    /* **********Setting Enterprise Details ********* */

    private ADFEnterpriseCustomerInfo set_EnterpriseCustomerInfo(ReadCustomerRs readCustomerRs, boolean isPrimaryCustomer, ListDealCustomer listDealCustomer1) {
        ADFEnterpriseCustomerInfo enterpriseCustomerInfo = new ADFEnterpriseCustomerInfo();

        enterpriseCustomerInfo.setPartyId(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getCustomerId());
        enterpriseCustomerInfo.setExistingOrProspect(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getPartyCategory());
        enterpriseCustomerInfo.setIsPrimaryCustomer(isPrimaryCustomer);

        EnterpriseCustomerBasicDetails enterpriseCustomerBasicDetails = set_EnterpriseCustomerBasicDetails(readCustomerRs);
        enterpriseCustomerInfo.setEnterpriseCustomerBasicDetails(enterpriseCustomerBasicDetails);

        EnterpriseContactDetails enterpriseContactDetails = set_EnterpriseContactDetails(readCustomerRs);
        enterpriseCustomerInfo.setEnterpriseContactDetails(enterpriseContactDetails);

        EnterprisePermanentAddress enterprisePermanentAddress = set_EnterprisePermanentAddress(readCustomerRs);
        enterpriseCustomerInfo.setEnterprisePermanentAddress(enterprisePermanentAddress);

        CustomerCreditDetails customerCreditDetails = set_CustomerCreditDetails(readCustomerRs);
        enterpriseCustomerInfo.setCustomerCreditDetails(customerCreditDetails);
        
        UserDefinedFields customerUdfs = set_CustomerUdfs(listDealCustomer1);
        enterpriseCustomerInfo.setUserDefinedFields(customerUdfs);

        return enterpriseCustomerInfo;
    }

    private EnterpriseContactDetails set_EnterpriseContactDetails(ReadCustomerRs readCustomerRs) {
        EnterpriseContactDetails enterpriseContactDetails = new EnterpriseContactDetails();
        enterpriseContactDetails.setEmail(readCustomerRs.getCustomerDetails().getContactDetails().getContactEmailId());
        enterpriseContactDetails.setPhoneOrMobile(readCustomerRs.getCustomerDetails().getContactDetails().getContactMobileNum());
        enterpriseContactDetails.setPrincipalContact(readCustomerRs.getCustomerDetails().getContactDetails().getContactTelNum());

        return enterpriseContactDetails;

    }

    private EnterpriseCustomerBasicDetails set_EnterpriseCustomerBasicDetails(ReadCustomerRs readCustomerRs) {
        EnterpriseCustomerBasicDetails enterpriseCustomerBasicDetails = new EnterpriseCustomerBasicDetails();
        enterpriseCustomerBasicDetails.setCountryOfRegistration(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getRegCountry());
        enterpriseCustomerBasicDetails.setDateFormed(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getFormationDt());
        enterpriseCustomerBasicDetails.setDateOfCommencedTrading(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getTradeStDt());
        enterpriseCustomerBasicDetails
            .setDateOfIncorporation(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getDateIncorporated());
        enterpriseCustomerBasicDetails.setEnterpriseName(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getEnterpriseName());
        enterpriseCustomerBasicDetails.setEnterpriseStatus(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getBusStatus());
        enterpriseCustomerBasicDetails.setLicenseOrPermit(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getLicenseNum());
        enterpriseCustomerBasicDetails.setMainBuisnessActivity(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getBusActivity());
        // enterpriseCustomerBasicDetails.setNoOfBenificialOwners(readCustomerRs.getCustomerDetails().getEnterpriseDetails().get);
        enterpriseCustomerBasicDetails.setRegisteredNumber(readCustomerRs.getCustomerDetails().getEnterpriseDetails().getRegNumber());

        return enterpriseCustomerBasicDetails;
    }

    private EnterprisePermanentAddress set_EnterprisePermanentAddress(ReadCustomerRs readCustomerRs) {
        EnterprisePermanentAddress enterprisePermanentAddress = new EnterprisePermanentAddress();
        enterprisePermanentAddress.setAddress1(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine1());
        enterprisePermanentAddress.setAddress2(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine2());
        enterprisePermanentAddress.setAddress3(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine3());
        enterprisePermanentAddress.setAddress4(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine4());
        enterprisePermanentAddress.setAddress5(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine5());
        enterprisePermanentAddress.setAddress6(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine6());
        enterprisePermanentAddress.setAddress7(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine7());
        enterprisePermanentAddress.setAddress8(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine8());
        enterprisePermanentAddress.setAddress9(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine9());
        enterprisePermanentAddress.setAddress10(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getAddrLine10());

        enterprisePermanentAddress.setCountry(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getCountry());
        enterprisePermanentAddress.setLocation(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getRegion());
        enterprisePermanentAddress.setPostalCode(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getPostCode());
        enterprisePermanentAddress.setTownOrCity(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getTownCity());
        enterprisePermanentAddress.setVailidFrom(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getFromDate());
        enterprisePermanentAddress.setValidTo(readCustomerRs.getCustomerDetails().getCustomerBasicDetails().getAddress().getToDate());

        return enterprisePermanentAddress;
    }

    @Override
    public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject, AbstractBuildingBlock abstractBuildingBlock) {
        callDealCusomerInfoBBProcess(islamicBankingObject, abstractBuildingBlock);
        return IBCommonUtils.getNextBuildingBlockDtls(islamicBankingObject.getProcessConfigID(), islamicBankingObject.getStepID(),
            islamicBankingObject.getPhaseID());

    }

    private void callDealCusomerInfoBBProcess(IslamicBankingObject islamicBankingObject, AbstractBuildingBlock abstractBuildingBlock) {

        ListDealCustomers listDealCustomers = new ListDealCustomers();
        ADFSetCustomerInfo setCustomerInfo = (ADFSetCustomerInfo) abstractBuildingBlock;

        if (setCustomerInfo.getPersonalCustomerIdList() != null) {
            int s0 = setCustomerInfo.getPersonalCustomerIdList().size();
            for (int i = 0; i < s0; i++) {
                ListDealCustomer listDealCustomer = new ListDealCustomer();
                if (setCustomerInfo.getPersonalCustomerIdList().get(i).isPrimaryCustomer()) {
                    listDealCustomer.setAssociationType("PC");
                } else {
                    listDealCustomer.setAssociationType("SC");
                }
                listDealCustomer.setCustomerId(setCustomerInfo.getPersonalCustomerIdList().get(i).getPartyId());
                listDealCustomer.setIsPrimaryCustomer(setCustomerInfo.getPersonalCustomerIdList().get(i).isPrimaryCustomer());
              
                HashMap inputParams_1 = new HashMap();
            	inputParams_1.put("partyId", listDealCustomer.getCustomerId());

            	HashMap outputParams = MFExecuter.executeMF("CE_IB_getDealCustomerAdditionalInfo", inputParams_1,
                    BankFusionThreadLocal.getUserLocator().getStringRepresentation());
                
               	CeDealCustomerInfo dealCustomerAddInfo = (CeDealCustomerInfo) outputParams.get("ceDealCustomerInfo");
               	dealCustomerAddInfo.getAdfEmployee();
               	dealCustomerAddInfo.getCustomerAge();
               	
               	setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields();
               	boolean noAdfEmployeeTag = true;
               	boolean noCustomerAgeTag= true;
               	boolean noRelativeTag=true;
               	if (setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields() != null && 
               			setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedFieldCount() > 0) {
    				for (int j=0;j<setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedFieldCount();j++) {
    					
    					if (setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedField(j)
    							.getFieldName().equals("UDF_ADFEMPLOYEE")) {
    						setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedField(j)
    						.setFieldValue(dealCustomerAddInfo.getAdfEmployee());
    						noAdfEmployeeTag = false;
    					}
    					if (setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedField(j)
    							.getFieldName().equals("UDF_CUSTOMERAGE")) {
    						setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedField(j)
    						.setFieldValue(dealCustomerAddInfo.getCustomerAge());
    						noCustomerAgeTag = false;
    					}
    					if (setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().getUserDefinedField(j)
    							.getFieldName().equals("UDF_RELATIVE")) {
    						noRelativeTag = false;
    					}
    				}
    			}
               	if(noAdfEmployeeTag) {
               		UserDefinedFld udf = new UserDefinedFld();
               		udf.setFieldName("UDF_ADFEMPLOYEE");
               		udf.setFieldValue(dealCustomerAddInfo.getAdfEmployee());
               		setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().addUserDefinedField(udf);
               	}
				if(noCustomerAgeTag) {
					UserDefinedFld udf = new UserDefinedFld();
               		udf.setFieldName("UDF_CUSTOMERAGE");
               		if(!dealCustomerAddInfo.getCustomerAge().equals(IBConstants.EMPTY_STRING))
               			udf.setFieldValue(Integer.parseInt(dealCustomerAddInfo.getCustomerAge()));
               		else
               			udf.setFieldValue(Integer.parseInt("0"));
               		setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().addUserDefinedField(udf);
				}
				if(noRelativeTag) {
					UserDefinedFld udf = new UserDefinedFld();
               		udf.setFieldName("UDF_RELATIVE");
               		udf.setFieldValue(false);
               		setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields().addUserDefinedField(udf);	
				}
                
                PartyDetails partyDetails= new PartyDetails();
                ExtensionDetails extensionDetails=new ExtensionDetails();
                UserDefinedFields userDefinedFields = setCustomerInfo.getPersonalCustomerIdList().get(i).getUserDefinedFields();
                userDefinedFields.setAssociatedBoName("IB_IDI_DealCustomerDetail");
                extensionDetails.setUserExtension(userDefinedFields);
                extensionDetails.setHostExtension(CommonConstants.EMPTY_STRING);
				partyDetails.setExtensionDetails(extensionDetails);
				listDealCustomer.setPartyDetails(partyDetails); 
                
                listDealCustomers.addListDealCustomer(listDealCustomer);
            }
        }

        if (setCustomerInfo.getEnterpriseCustomerIdList() != null) {
            int s1 = setCustomerInfo.getEnterpriseCustomerIdList().size();
            for (int i = 0; i < s1; i++) {
                ListDealCustomer listDealCustomer = new ListDealCustomer();
                if (setCustomerInfo.getEnterpriseCustomerIdList().get(i).isPrimaryCustomer()) {
                    listDealCustomer.setAssociationType("PC");
                } else {
                    listDealCustomer.setAssociationType("SC");
                }
                listDealCustomer.setCustomerId(setCustomerInfo.getEnterpriseCustomerIdList().get(i).getPartyId());
                listDealCustomer.setIsPrimaryCustomer(setCustomerInfo.getEnterpriseCustomerIdList().get(i).isPrimaryCustomer());
                
                PartyDetails partyDetails= new PartyDetails();
                ExtensionDetails extensionDetails=new ExtensionDetails();
                UserDefinedFields userDefinedFields = setCustomerInfo.getEnterpriseCustomerIdList().get(i).getUserDefinedFields();
                userDefinedFields.setAssociatedBoName("IB_IDI_DealCustomerDetail");
                extensionDetails.setUserExtension(userDefinedFields);
                extensionDetails.setHostExtension(CommonConstants.EMPTY_STRING);
				partyDetails.setExtensionDetails(extensionDetails);
				listDealCustomer.setPartyDetails(partyDetails); 
                
                listDealCustomers.addListDealCustomer(listDealCustomer);
            }
        }

        if (setCustomerInfo.getProspectPersonalCustomerList() != null) {
            int s2 = setCustomerInfo.getProspectPersonalCustomerList().size();
            for (int i = 0; i < s2; i++) {
                ListDealCustomer listDealCustomer = new ListDealCustomer();
                listDealCustomer.setIsPrimaryCustomer(setCustomerInfo.getProspectPersonalCustomerList().get(i).isPrimaryCustomer());
                if (setCustomerInfo.getProspectPersonalCustomerList().get(i).isPrimaryCustomer()) {
                    listDealCustomer.setAssociationType("PC");
                } else {
                    listDealCustomer.setAssociationType("SC");
                }
                PartyDetails partyDetails = new PartyDetails();
                partyDetails
                    .setFirstName(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getFirstName());
                partyDetails
                    .setLastName(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getLastName());
                partyDetails
                    .setMiddleName(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getMiddleName());
                partyDetails.setTitle(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getTitle());
                // Timestamp is used here
                // partyDetails.setDateOfBirth(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getDateOfBirth());
                partyDetails.setGender(setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getGender());
                partyDetails.setAddrLine1(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress1());
                partyDetails.setAddrLine2(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress2());
                partyDetails.setAddrLine3(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress3());
                partyDetails.setAddrLine4(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress4());
                partyDetails.setPostCode(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getPostCode());
                partyDetails.setCountryOfAddress(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getCountry());
                partyDetails.setEmailID(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getEmail());
                partyDetails.setContactTel(setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getHomePhone());
                partyDetails.setPartyType("1062");
                
            
                ExtensionDetails extensionDetails=new ExtensionDetails();
                extensionDetails.setUserExtension(new UserDefinedFields());
                extensionDetails.setHostExtension(CommonConstants.EMPTY_STRING);
				partyDetails.setExtensionDetails(extensionDetails);
				listDealCustomer.setPartyDetails(partyDetails); 

             
                listDealCustomers.addListDealCustomer(listDealCustomer);
            }
        }

        if (setCustomerInfo.getProspectEnterpriseCustomerList() != null) {
            int s3 = setCustomerInfo.getProspectEnterpriseCustomerList().size();
            for (int i = 0; i < s3; i++) {

                ListDealCustomer listDealCustomer = new ListDealCustomer();
                listDealCustomer.setIsPrimaryCustomer(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).isPrimaryCustomer());
                if (setCustomerInfo.getProspectEnterpriseCustomerList().get(i).isPrimaryCustomer()) {
                    listDealCustomer.setAssociationType("PC");
                } else {
                    listDealCustomer.setAssociationType("SC");
                }
                PartyDetails partyDetails = new PartyDetails();

                partyDetails.setEnterpriseName(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getEnterpriseName());
                partyDetails.setEnterpriseStatus(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getEnterpriseStatus());
                // partyDetails.setDateOfFormation(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getDateFormed());
                partyDetails.setRegNumber(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getRegisteredNumber());
                // partyDetails.setDateOfCommencedTrading(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getDateOfCommencedTrading());
                // partyDetails.setDateoOfIncorporation(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getDateOfIncorporation());
                partyDetails.setCountryOfRegistration(setCustomerInfo.getProspectEnterpriseCustomerList().get(i)
                    .getEnterpriseCustomerBasicDetails().getCountryOfRegistration());
                partyDetails.setNumberOfBeneficialOwner(setCustomerInfo.getProspectEnterpriseCustomerList().get(i)
                    .getEnterpriseCustomerBasicDetails().getNoOfBenificialOwners());

                partyDetails
                    .setAddrLine1(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress1());
                partyDetails
                    .setAddrLine2(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress2());
                partyDetails
                    .setAddrLine3(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress3());
                partyDetails
                    .setAddrLine4(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress4());
                partyDetails
                    .setAddrLine5(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress5());
                partyDetails
                    .setAddrLine6(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress6());
                partyDetails
                    .setAddrLine7(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress7());
                partyDetails
                    .setAddrLine8(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress8());
                partyDetails
                    .setAddrLine9(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress9());
                partyDetails.setAddrLine10(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getAddress10());
                partyDetails.setCountryOfAddress(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getCountry());
                partyDetails.setPostCode(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterprisePermanentAddress().getPostalCode());
                partyDetails
                    .setEmailID(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getCustomerContactDetails().getPersonalEmail());
                partyDetails.setTelephoneNumber(
                    setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getCustomerContactDetails().getPhoneOrMobile());
                partyDetails
                    .setContactTel(setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getCustomerContactDetails().getHomePhone());
                partyDetails.setPartyType("1063");
                
              
                ExtensionDetails extensionDetails=new ExtensionDetails();
                extensionDetails.setUserExtension(new UserDefinedFields());
                extensionDetails.setHostExtension(CommonConstants.EMPTY_STRING);
				partyDetails.setExtensionDetails(extensionDetails);
				listDealCustomer.setPartyDetails(partyDetails); 
                listDealCustomers.addListDealCustomer(listDealCustomer);

            }
        }

        IBOIB_CFG_ProcessConfig processConfigDtls = IBCommonUtils.getProcessConfigByPrimaryKey(islamicBankingObject.getProcessConfigID());
        String transactionName = processConfigDtls.getF_PROCESSTYPE();
        islamicBankingObject.setTransactionName(transactionName);

        IPersistenceObjectsFactory persistanceFactory = BankFusionThreadLocal.getPersistanceFactory();
        try {
            persistanceFactory.beginTransaction();
            HashMap inputParams_0 = new HashMap();
            inputParams_0.put("taskInputPayload", islamicBankingObject);
            inputParams_0.put("RqFromAPI", listDealCustomers);

            MFExecuter.executeMF("CE_IB_CaptureCustomers_PRC", inputParams_0,
                BankFusionThreadLocal.getUserLocator().getStringRepresentation());
            persistanceFactory.commitTransaction();            
        } catch (BankFusionException bfe) {
            BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
            BankFusionThreadLocal.cleanUp();
            BankFusionThreadLocal.cleanUpAllFactories();
        } catch (Exception e) {
            BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
            BankFusionThreadLocal.cleanUp();
            BankFusionThreadLocal.cleanUpAllFactories();
        }
    }

    @Override
    public boolean validateBuildingBlockDetails(IslamicBankingObject islamicBankingObject, AbstractBuildingBlock abstractBuildingBlock) {
        ADFSetCustomerInfo setCustomerInfo = (ADFSetCustomerInfo) abstractBuildingBlock;
        validatePrimaryKey(setCustomerInfo);
        validateMandatoryInputs(setCustomerInfo);
        validateCustomerType(setCustomerInfo, islamicBankingObject);
        return true;
    }

    private void validatePrimaryKey(ADFSetCustomerInfo setCustomerInfo) {

        int isPrimaryCount = 0;

        if (setCustomerInfo.getPersonalCustomerIdList() != null) {
            int s0 = setCustomerInfo.getPersonalCustomerIdList().size();
            for (int i = 0; i < s0; i++) {
                if (setCustomerInfo.getPersonalCustomerIdList().get(i).isPrimaryCustomer()) {
                    isPrimaryCount++;
                }
            }
        }

        if (setCustomerInfo.getEnterpriseCustomerIdList() != null) {
            int s1 = setCustomerInfo.getEnterpriseCustomerIdList().size();
            for (int i = 0; i < s1; i++) {
                if (setCustomerInfo.getEnterpriseCustomerIdList().get(i).isPrimaryCustomer()) {
                    isPrimaryCount++;

                }
            }
        }

        if (setCustomerInfo.getProspectPersonalCustomerList() != null) {
            int s2 = setCustomerInfo.getProspectPersonalCustomerList().size();
            for (int i = 0; i < s2; i++) {
                if (setCustomerInfo.getProspectPersonalCustomerList().get(i).isPrimaryCustomer()) {
                    isPrimaryCount++;

                }
            }
        }

        if (setCustomerInfo.getProspectEnterpriseCustomerList() != null) {
            int s3 = setCustomerInfo.getProspectEnterpriseCustomerList().size();
            for (int i = 0; i < s3; i++) {
                if (setCustomerInfo.getProspectEnterpriseCustomerList().get(i).isPrimaryCustomer()) {
                    isPrimaryCount++;

                }
            }
        }

        if (isPrimaryCount != 1) {
            String[] msgArgs = { IBConstants.SINGLE_QUOTE + IBConstants.MANDATORYFIELDS + IBConstants.SINGLE_QUOTE };
            IBCommonUtils.raiseParametrizedEvent(IBConstants.E_NO_PRIMARY_CUST_SELECTED_IB, msgArgs);
        }
    }

    private void validateMandatoryInputs(ADFSetCustomerInfo setCustomerInfo) {

        if (setCustomerInfo.getProspectPersonalCustomerList() != null) {
            int s0 = setCustomerInfo.getProspectPersonalCustomerList().size();
            for (int i = 0; i < s0; i++) {
                if (setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getFirstName().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getMiddleName().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getLastName().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getGender().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getCustomerPersonalDetails().getTitle().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress1().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress2().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress3().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getAddress4().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getCountry().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getEmail().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getHomePhone().isEmpty()
                    || setCustomerInfo.getProspectPersonalCustomerList().get(i).getContactDetails().getPostCode().isEmpty()) {
                    String[] msgArgs = { IBConstants.SINGLE_QUOTE + IBConstants.MANDATORYFIELDS + IBConstants.SINGLE_QUOTE };
                    IBCommonUtils.raiseParametrizedEvent(IBConstants.E_MANDATORY_FIELD_EMPTY_WITH_FILEDNAME_IB, msgArgs);
                }
            }
        }
        if (setCustomerInfo.getProspectEnterpriseCustomerList() != null) {
            int s1 = setCustomerInfo.getProspectEnterpriseCustomerList().size();
            for (int i = 0; i < s1; i++) {

                if (setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getEnterpriseName()
                    .isEmpty()
                    || setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails().getRegisteredNumber()
                        .isEmpty()
                    || setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getEnterpriseCustomerBasicDetails()
                        .getCountryOfRegistration().isEmpty()
                    || setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getCustomerContactDetails().getPersonalEmail().isEmpty()
                    || setCustomerInfo.getProspectEnterpriseCustomerList().get(i).getCustomerContactDetails().getPhoneOrMobile().isEmpty())

                {
                    String[] msgArgs = { IBConstants.SINGLE_QUOTE + IBConstants.MANDATORYFIELDS + IBConstants.SINGLE_QUOTE };
                    IBCommonUtils.raiseParametrizedEvent(IBConstants.E_MANDATORY_FIELD_EMPTY_WITH_FILEDNAME_IB, msgArgs);

                }

            }
        }

    }

    private void validateCustomerType(ADFSetCustomerInfo setCustomerInfo, IslamicBankingObject islamicBankingObject) {
        ProductConfiguration productConfig = null;
        productConfig = IBCommonUtils.loadProductConfiguration(islamicBankingObject.getProductID(), islamicBankingObject.getSubProductID());
        if (productConfig.getCustomerType().equals(IBConstants.CUSTOMER_TYPE_PERSONAL)
            && (((setCustomerInfo.getEnterpriseCustomerIdList() != null) && (setCustomerInfo.getEnterpriseCustomerIdList().size() > 0))
                || ((setCustomerInfo.getProspectEnterpriseCustomerList() != null)
                    && (setCustomerInfo.getProspectEnterpriseCustomerList().size() > 0)))) {
            String[] msgArgs = { IBConstants.SINGLE_QUOTE + productConfig.getCustomerType() + IBConstants.SINGLE_QUOTE };
            IBCommonUtils.raiseParametrizedEvent(IBConstants.E_PRODUCT_DOES_NOT_SUPPORT_ENTERPRISE_CUSTOMER_IB, msgArgs);
        }

        if (productConfig.getCustomerType().equals(IBConstants.CUSTOMER_TYPE_ENTERPRISE)
            && (((setCustomerInfo.getPersonalCustomerIdList() != null) && (setCustomerInfo.getPersonalCustomerIdList().size() > 0))
                || ((setCustomerInfo.getProspectPersonalCustomerList() != null)
                    && (setCustomerInfo.getProspectPersonalCustomerList().size() > 0)))) {
            String[] msgArgs = { IBConstants.SINGLE_QUOTE + productConfig.getCustomerType() + IBConstants.SINGLE_QUOTE };
            IBCommonUtils.raiseParametrizedEvent(IBConstants.E_PRODUCT_DOES_NOT_SUPPORT_PERSONAL_CUSTOMER_IB, msgArgs);
        }

    }

}
