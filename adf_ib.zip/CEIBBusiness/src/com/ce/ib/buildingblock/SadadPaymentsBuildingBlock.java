package com.ce.ib.buildingblock;

import com.ce.bankfusion.ib.fatom.ReadSadadPayments;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.SadadPaymentDtlsList;

public class SadadPaymentsBuildingBlock extends AbstractIslamicBuildingBlock{
	
	public static final String buildingBlockId = "SADADPAYMENT";
	
	@Override
	public boolean isBuildingBlockSuppresed(IslamicBankingObject ibObj)
	{
		boolean isBBSuppressed = true;
		ReadSadadPayments sadadPayments = new ReadSadadPayments();
		sadadPayments.setF_IN_islamicBankingObject(ibObj);
		sadadPayments.process(BankFusionThreadLocal.getBankFusionEnvironment());
		SadadPaymentDtlsList paymentsList = sadadPayments.getF_OUT_sadadPaymentList();
		IBOIB_CFG_BuildingBlockConfig buildingBlockConfig = IBCommonUtils.getConfiguredBuildingBlock(buildingBlockId,
				ibObj.getProductID(), ibObj.getSubProductID(), ibObj.getStepID(), ibObj.getProcessConfigID());
		if(buildingBlockConfig.getF_BUILDINGBLOCKMODE().equals(BuildingBlockConstants.MODE_EDIT) && sadadPayments.isF_OUT_isUserActionApplicable())
		{
			isBBSuppressed = false;
		}
		else if(buildingBlockConfig.getF_BUILDINGBLOCKMODE().equals(BuildingBlockConstants.MODE_VIEW) 
				&& null != paymentsList && paymentsList.getSadadPaymentDtlsCount() > 0)
		{
			isBBSuppressed = false;
		}
		
		return isBBSuppressed;
	}

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig arg0, boolean arg1) {
		return null;
	}

}
