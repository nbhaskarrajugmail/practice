package com.ce.ib.buildingblock;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.ce.api.dto.ADFDealCustomerInfo;
import bf.com.misys.ce.api.dto.LinkTitleDeedInfo;
import bf.com.misys.ce.api.dto.TitleDeedAreaAndCoordinateDtls;
import bf.com.misys.ce.api.dto.TitleDeedInfo;
import bf.com.misys.ib.api.bb.dto.AbstractBuildingBlock;
import bf.com.misys.ib.types.AdditionalFieldsEditableTags;
import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaCoordinateDtl;
import bf.com.misys.technical.dtls.ib.types.TechnicalAreaDtl;
import bf.com.misys.technical.dtls.ib.types.TitleDeedSource;

public class TitleDeedDealBuildingBlock extends AbstractIslamicBuildingBlock {
	private transient final static Log LOGGER = LogFactory
			.getLog(TitleDeedDealBuildingBlock.class.getName());
	
	private static final String TITLE_DEED_LOCATION_WHERE_CLAUSE = "WHERE " + IBOCE_TITLEDEEDLOCATION.TITLEDEEDID
			+ "=?";
	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {

		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry)
			mode = BuildingBlockConstants.MODE_VIEW;
		AdditionalFieldsEditableTags readOnlyTags = new AdditionalFieldsEditableTags();
		if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			readOnlyTags.setAllTags(true);

		} else if (editMode.equals(BuildingBlockConstants.FULL_EDIT_MODE)) {
			readOnlyTags.setAllTags(false);
		} else {
			readOnlyTags.setAllTags(false);
		}

		return readOnlyTags;
	
	}
	@Override
	public boolean executeSubmitAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_ACTION);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF("CE_IB_TitleDeed_PRC", BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}

	@Override
	public String setBuildingBlockDetails(IslamicBankingObject islamicBankingObject,
			AbstractBuildingBlock abstractBuildingBlock) {
		LinkTitleDeedInfo linkTitleDeedInfo = (LinkTitleDeedInfo) abstractBuildingBlock;
		//get the title deeds by customer and validate is correct or not
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause =
	            "WHERE " + IBOIB_IDI_DealCustomerDetail.DEALID + "=? AND " + IBOIB_IDI_DealCustomerDetail.ASSOCIATIONTYPE + "=?";
        ArrayList<String> params = new ArrayList<String>();
        params.add(islamicBankingObject.getDealID());
        params.add("PC");
        List<IBOIB_IDI_DealCustomerDetail> dealCustomers = (List<IBOIB_IDI_DealCustomerDetail>) factory.findByQuery(IBOIB_IDI_DealCustomerDetail.BONAME, whereClause, params, null, true);
	    if(dealCustomers != null && dealCustomers.size()>0) {
	    	IBOIB_IDI_DealCustomerDetail dealCustomer = dealCustomers.get(0);
	    	if(validateTitleDeedsToDealPrimaryCustomer(dealCustomer, linkTitleDeedInfo.getTitleDeedInfoList())) {
	    		if(linkTitleDeedInfo.getTitleDeedInfoList()!=null && linkTitleDeedInfo.getTitleDeedInfoList().size()>0)
	    		{
	    			String deleteClause = "WHERE "+IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER+" =?";
	    			params.clear();
	    			params.add(islamicBankingObject.getDealID());
	    			factory.bulkDelete(IBOCE_IB_DealTitleDeedDtls.BONAME, deleteClause, params);
		    		for (TitleDeedInfo titleDeedIdPk : linkTitleDeedInfo.getTitleDeedInfoList()) {
		    			Map inputParams = new HashMap<>();
		    			SearchTitleDeedDtlsRqType rq = new SearchTitleDeedDtlsRqType();
		    			rq.setTitleDeedId(titleDeedIdPk.getTitleDeedID());
		    			rq.setPartyId("");
		    			inputParams.put("searchTitleDeedDtlsRqType", rq);
		    			HashMap outputParams = MFExecuter.executeMF("CE_FilterTitleDeedDtl_SRV",
		    					BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
		    			SearchTitleDeedDtlsRsType rs = (SearchTitleDeedDtlsRsType) outputParams.get("searchTitleDeedDtlsRs");
		    			if (rs != null && rs.getListTitleDeedIdDtls() != null) {
		    				TitleDeedDetailsType vtitleDeedDetail = rs.getListTitleDeedIdDtls().getTitleDeedDetails(0);
		    				if(validateTitleDeed(islamicBankingObject.getDealID(), vtitleDeedDetail.getFarmLocation())) {
			    				IBOCE_IB_DealTitleDeedDtls dealTitleDeedDtls = (IBOCE_IB_DealTitleDeedDtls) factory
			    						.getStatelessNewInstance(IBOCE_IB_DealTitleDeedDtls.BONAME);
			    				dealTitleDeedDtls.setF_IBDEALNUMBER(islamicBankingObject.getDealID());
			    				dealTitleDeedDtls.setF_IBTITLEDEEDID(titleDeedIdPk.getTitleDeedID());
			    				dealTitleDeedDtls.setF_IBTITLEDEEDVERSIONNUM(String.valueOf(vtitleDeedDetail.getVersionNumber()));
			    				dealTitleDeedDtls.setF_IBSTATUS("APPROVED");
			    				dealTitleDeedDtls.setBoID(GUIDGen.getNewGUID());
			    				factory.create(IBOCE_IB_DealTitleDeedDtls.BONAME, dealTitleDeedDtls);
		    				}else {
		    					LOGGER.error("Title deed locations are not associated to deal branch:"+dealCustomer.getF_CUSTOMERID());
		    					IBCommonUtils.raiseUnparameterizedEvent(44000264);
		    				}
		    			}
		    		}
	    		}
	    	}else {
	    		LOGGER.error("One/More title deeds are not part of the primary customer:"+dealCustomer.getF_CUSTOMERID());
	    		IBCommonUtils.raiseUnparameterizedEvent(44000264);
	    	}
	    }else {
	    	LOGGER.error("No primary customer associated to deal:"+islamicBankingObject.getDealID());
	    	IBCommonUtils.raiseUnparameterizedEvent(44000264);
	    }
		return IBCommonUtils.getNextBuildingBlockDtls(islamicBankingObject.getProcessConfigID(),
				islamicBankingObject.getStepID(), islamicBankingObject.getPhaseID());

	}
	/**
	 * This method will check all the sending title deeds are associated to customer or not
	 * @param dealCustomer
	 * @param titleDeedIDList
	 * @return boolean
	 */
	 private boolean validateTitleDeedsToDealPrimaryCustomer(IBOIB_IDI_DealCustomerDetail dealCustomer,
			List<TitleDeedInfo> titleDeedIDList) {
		 boolean flag = true;
		 	Map inputParams = new HashMap<>();
			SearchTitleDeedDtlsRqType rq = new SearchTitleDeedDtlsRqType();
			rq.setPartyId(dealCustomer.getF_CUSTOMERID());
			inputParams.put("searchTitleDeedDtlsRqType", rq);
			HashMap outputParams = MFExecuter.executeMF("CE_FilterTitleDeedDtl_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), inputParams);
			SearchTitleDeedDtlsRsType rs = (SearchTitleDeedDtlsRsType) outputParams.get("searchTitleDeedDtlsRs");
			if (rs != null && rs.getListTitleDeedIdDtls() != null) {
				for(TitleDeedInfo titleDeedIDUI : titleDeedIDList) {
					boolean available = false;
					for(TitleDeedDetailsType titleDeedBE : rs.getListTitleDeedIdDtls().getTitleDeedDetails()) {
						if(titleDeedIDUI.getTitleDeedID().equals(titleDeedBE.getTitleDeedIdpk())){
							available = true;
							break;
						}
					}
					if(!available) 
						return false;
				}
			}else {
				flag = false;
			}
	     return flag;
	}

	 /**
	  * This method will validate whether the title deed location is part of deal branch
	  * @param dealID
	  * @param farmLocation
	  */
	private boolean validateTitleDeed(String dealID, String farmLocation) {
		boolean flag = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_DLI_DealDetails dealDetails = (IBOIB_DLI_DealDetails) factory
				.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, dealID, true);
		String dealBranchCode = dealDetails.getF_BranchSortCode();
		if (dealBranchCode != null && farmLocation != null) {
			ListGenericCodeRs listGenericCodeRs = IBCommonUtils.getGCList(dealBranchCode);
			for (GcCodeDetail codeDetails : listGenericCodeRs.getGcCodeDetails()) {
				if (farmLocation.equals(codeDetails.getCodeValue())) {
					flag = true;
					break;
				}
			}
		}
		return flag;
	}
	@Override
    public boolean validateBuildingBlockDetails(IslamicBankingObject islamicBankingObject, AbstractBuildingBlock abstractBuildingBlock) {
        return true;
    }
	
	 @Override
	public AbstractBuildingBlock getBuildingBlockDetails(IslamicBankingObject islamicBankingObject) {
		LinkTitleDeedInfo linkTitleDeedInfo = new LinkTitleDeedInfo();
		List<TitleDeedInfo> titleDeeds = new ArrayList<>();
		List<TitleDeedAreaAndCoordinateDtls> titleDeedCoordinates = new ArrayList<>();
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String whereClause = " WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		params.add(islamicBankingObject.getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> titleDeedDetailsList = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME,
				whereClause, params, null, false);
		if (titleDeedDetailsList != null && !titleDeedDetailsList.isEmpty()) {

			for (IBOCE_IB_DealTitleDeedDtls dealTitleDeed : titleDeedDetailsList) {
				TitleDeedInfo titleDeedInfo = new TitleDeedInfo();
				titleDeedInfo.setTitleDeedID(dealTitleDeed.getF_IBTITLEDEEDID());

				CE_TITLEDEEDDETAILSID titleDeedID = new CE_TITLEDEEDDETAILSID();
				titleDeedID.setF_TITLEDEEDID(dealTitleDeed.getF_IBTITLEDEEDID());
				titleDeedID.setF_TITLEDEEDVERSION(Integer.parseInt(dealTitleDeed.getF_IBTITLEDEEDVERSIONNUM()));
				IBOCE_TITLEDEEDDETAILS titleDeedDetail = (IBOCE_TITLEDEEDDETAILS) BankFusionThreadLocal
						.getPersistanceFactory().findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedID, true);

				titleDeedInfo.setTitleDeedLandPlannumber(titleDeedDetail.getF_LANDPLANNUMBER());
				titleDeedInfo.setTitleDeedLandPlotnumber(titleDeedDetail.getF_LANDPLOTNUMBER());

				titleDeedInfo.setTitleDeedSource(
						IBCommonUtils.getGCChildDesc("TITLEDEEDSOURCE", titleDeedDetail.getF_TITLEDEEDSOURCE()));
				titleDeedInfo.setTitleDeedType(
						IBCommonUtils.getGCChildDesc("TITLEDEEDTYPE", titleDeedDetail.getF_TITLEDEEDTYPE()));
				// titleDeedInfo.setTitleDeedVersion(dealTitleDeed.getF_IBTITLEDEEDVERSIONNUM());
				titleDeedInfo.setTitleDeedYear(titleDeedDetail.getF_TITLEDEEDYEAR());
				titleDeedInfo.setTitleDeedID(dealTitleDeed.getF_IBTITLEDEEDID());
				titleDeedInfo.setTitleDeedNumber(titleDeedDetail.getF_TITLEDEEDNUMBER());

				params.clear();
				params.add(dealTitleDeed.getF_IBTITLEDEEDID());
				List<IBOCE_TITLEDEEDLOCATION> titleDeedLocationDetails = (List) factory.findByQuery(
						IBOCE_TITLEDEEDLOCATION.BONAME, TITLE_DEED_LOCATION_WHERE_CLAUSE, params, null, false);
				for (IBOCE_TITLEDEEDLOCATION titleDeedLocation : titleDeedLocationDetails) {
					TitleDeedAreaAndCoordinateDtls titleDeedAreaAndCoordinateDtls = new TitleDeedAreaAndCoordinateDtls();
					titleDeedAreaAndCoordinateDtls.setEastCoordinate(titleDeedLocation.getF_LOCEASTDEGREE().toString());
					titleDeedAreaAndCoordinateDtls.setEastCoordinateO(titleDeedLocation.getF_LOCEASTSECTION().toString());
					titleDeedAreaAndCoordinateDtls.setNorthCoordinate(titleDeedLocation.getF_LOCNORTHDEGREE().toString());
					titleDeedAreaAndCoordinateDtls.setNorthCoordinateO(titleDeedLocation.getF_LOCNORTHSECTION().toString());
					titleDeedAreaAndCoordinateDtls.setSerail(titleDeedLocation.getF_SERIAL());
					titleDeedAreaAndCoordinateDtls.setTitleDeedId(titleDeedLocation.getF_TITLEDEEDID());
					titleDeedCoordinates.add(titleDeedAreaAndCoordinateDtls);
				}

				titleDeeds.add(titleDeedInfo);
			}
		}
		linkTitleDeedInfo.setTitleDeedInfoList(titleDeeds);
		linkTitleDeedInfo.setTitleDeedAreaAndCoordinateDtls(titleDeedCoordinates);
		return linkTitleDeedInfo;
	}
/*
	@Override
	public boolean executeReverseAction(IslamicBankingObject islamicBankingObject) {
		HashMap<String, IslamicBankingObject> inputs = new HashMap<>();
		islamicBankingObject.setMode(IBConstants.BB_MODE_REVERSAL);
		inputs.put(CeConstants.TASKINPUT_PAYLOAD_INPUT, islamicBankingObject);
		MFExecuter.executeMF("CE_IB_TitleDeed_PRC", BankFusionThreadLocal.getBankFusionEnvironment(),
				inputs);
		return true;
	}*/

}
