package com.ce.ib.buildingblock;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_BuildingBlockConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.buildingBlock.AbstractIslamicBuildingBlock;
import com.misys.ib.buildingBlock.BuildingBlockConstants;

import bf.com.misys.ce.ib.types.DealRescheduleEditableTags;

public class DealRescheduleBuildingBlock extends AbstractIslamicBuildingBlock {

	public DealRescheduleBuildingBlock() {
	}

	@Override
	public Object populateBuildingBlock(IBOIB_CFG_BuildingBlockConfig buildingBlockConfig, boolean isDealEnquiry) {
		String mode = CommonConstants.EMPTY_STRING;
		String editMode = CommonConstants.EMPTY_STRING;
		if (buildingBlockConfig != null) {
			mode = buildingBlockConfig.getF_BUILDINGBLOCKMODE();
			editMode = buildingBlockConfig.getF_EDITMODES();
		}
		if (isDealEnquiry) {
			mode = BuildingBlockConstants.MODE_VIEW;
		}

		DealRescheduleEditableTags dealRescheduleEditableTags = new DealRescheduleEditableTags();
		if (mode.equals(BuildingBlockConstants.MODE_VIEW)) {
			dealRescheduleEditableTags.setViewOnly(true);
		} else {
			dealRescheduleEditableTags.setViewOnly(false);
		}
		if (!IBCommonUtils.isNullOrEmpty(editMode) && editMode.equals("NORESCHPROFIT")) {
			dealRescheduleEditableTags.setNoRescheduleProfit(false);
		} else {
			dealRescheduleEditableTags.setNoRescheduleProfit(true);
		}
		return dealRescheduleEditableTags;
	}

}
