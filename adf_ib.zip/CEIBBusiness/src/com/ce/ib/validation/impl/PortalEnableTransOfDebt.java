package com.ce.ib.validation.impl;

import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class PortalEnableTransOfDebt implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        
        String udfPortalStatus = "PORTAL_STATUS";
        String portalStatus = (String) CeUtils.getUDFValueByName(bankingObject.getDealID(), udfPortalStatus);
        
        String status = BankFusionPropertySupport.getPropertyBasedOnConfLocation(ValidationExceptionConstants.PROPERTIES_FILE,
            ValidationExceptionConstants.PORTAL_STATUS, "", CeConstants.ADFIBCONFIGLOCATION);
        
        if(null != portalStatus && portalStatus.equals(status)) {
            return true;
        }
        
        return false;
    }

}
