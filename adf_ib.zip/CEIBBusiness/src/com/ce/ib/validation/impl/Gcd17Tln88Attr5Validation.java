package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.ib.validation.IValidation;

import bf.com.misys.ib.types.IslamicBankingObject;

public class Gcd17Tln88Attr5Validation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If Attribute 5 is 1 and GROUPCD 17 TOOL no 88 then it should go for approval to group 3
		 */
		boolean isAttr5Value1 = false;
		BigDecimal attr5Value = DealValidationUtil.getAttributeValue(5, 17, 88, bankingObject);
		if(null != attr5Value && BigDecimal.ONE.compareTo(attr5Value) == 0)
		{
			isAttr5Value1 = true;
		}
		return isAttr5Value1;
	}

}
