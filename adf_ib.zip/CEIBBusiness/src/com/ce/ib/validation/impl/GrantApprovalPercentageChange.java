package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.constant.CommonConstants;

import bf.com.misys.ib.types.IslamicBankingObject;

public class GrantApprovalPercentageChange implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject islamicBankingObject) {
        boolean isPercentageChanged = false;
        BigDecimal expectedGrantAppPercentage = AssetStudyAndInfoUtil .getExpectedGrantAppPercentage(islamicBankingObject.getDealID());
        BigDecimal enteredGrantAppPercentage = AssetStudyAndInfoUtil.getEnteredGrantAppPercentage(islamicBankingObject.getDealID());
        if (expectedGrantAppPercentage.compareTo(enteredGrantAppPercentage) != CommonConstants.INTEGER_ZERO) {
            isPercentageChanged = true;
        }
        return isPercentageChanged;
    }

}
