package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetCategory;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IBF_ProductAssetConfig;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.AssetProgressReportDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressPriceUnpriceValidation implements IValidation {
	private static final String MACHINE_TYPE_ASSET_QUERY = " where "+IBOIB_IBF_ProductAssetConfig.ASSETCATEGORYID+" = ? and "+IBOIB_IBF_ProductAssetConfig.PRODUCTID+" = ?";
    @Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isfieldEmpty = false;
		// AssetProgressReportDetails asstProgressReportDtls = new
		// AssetProgressReportDetails();

		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode("RETRIEVE");
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
		for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
				.getAssetProgressReportList()) {
			if (assetProgressReport.getReportStatus().equals("New")) {
				for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
						.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
					if (assetProgressDetails.getReportID().equals(assetProgressReport.getReportID())) {
						if (assetProgressDetails.getFinalCostAfterDeduction().getCurrencyAmount()
								.compareTo(BigDecimal.ZERO) > 0 && assetProgressDetails.getIsAssetPriced()
								&& isAssetMachine(assetProgressDetails.getAssetCategory().getCategory()))
							if (IBCommonUtils.isNullOrEmpty(assetProgressDetails.getMachineNumber())
									|| IBCommonUtils.isNullOrEmpty(assetProgressDetails.getMachineType())
									|| IBCommonUtils.isNullOrEmpty(assetProgressDetails.getPriceListNumber())
									|| assetProgressDetails.getPriceListYear().equals(0)) {
								return true;
							}
					}
				}
			}
		}
		return isfieldEmpty;
	}

	boolean isAssetMachine(String assetID) {
		boolean isMachine = false;
		ArrayList<String> queryParams = new ArrayList<String>();
		IBOIB_AST_AssetCategory assetCategory = (IBOIB_AST_AssetCategory) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOIB_AST_AssetCategory.BONAME, assetID, true);
		String parentCategoryID = assetCategory.getF_PARENTCATEGORY();
		queryParams.add(parentCategoryID);
		queryParams.add(CeConstants.MACHINE_TYPE_ASSET_PRODUCTID);
		List<IBOIB_IBF_ProductAssetConfig> productAssetConfigList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOIB_IBF_ProductAssetConfig.BONAME, MACHINE_TYPE_ASSET_QUERY, queryParams, null, true);
		if (productAssetConfigList != null && !productAssetConfigList.isEmpty()) {
			isMachine = true;
		}
		return isMachine;
	}

}
