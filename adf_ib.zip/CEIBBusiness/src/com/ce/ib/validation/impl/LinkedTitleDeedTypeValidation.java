package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class LinkedTitleDeedTypeValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If the customer is linked with title deed Type 17 then it should go for Approval to group 3
		 */
		boolean isTDType17Linked = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		/*String whereClause = "WHERE "+ IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> linkedTitleDeeds = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME, whereClause, params, null, false);
		for(IBOCE_IB_DealTitleDeedDtls eachLinkedTDs : linkedTitleDeeds)
		{
			params.clear();
			params.add(eachLinkedTDs.getF_IBTITLEDEEDID());
			params.add(eachLinkedTDs.getF_IBTITLEDEEDVERSIONNUM());
			String whereClauseTDDtls = "WHERE "+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK + " = ? AND "
					+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDVERSIONPK + " = ?";
		}*/
		String selectQuery = "SELECT a."+IBOCE_IB_DealTitleDeedDtls.IBDEALTITLEDEEDID + " as "
				+ IBOCE_IB_DealTitleDeedDtls.IBDEALTITLEDEEDID + " FROM " + IBOCE_IB_DealTitleDeedDtls.BONAME
				+ " AS a, "+ IBOCE_TITLEDEEDDETAILS.BONAME + " AS b WHERE a." + IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID 
				+ " = b." + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK + " AND a." + IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDVERSIONNUM
				+ " = b." + IBOCE_TITLEDEEDDETAILS.TITLEDEEDVERSIONPK + " AND a." + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER
				+ " = ? AND b." + IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		params.add("17");
		List<SimplePersistentObject> resultSet = factory.executeGenericQuery(selectQuery, params, null, false);
		if(!resultSet.isEmpty())
		{
			isTDType17Linked = true;
		}
		return isTDType17Linked;
	}

}
