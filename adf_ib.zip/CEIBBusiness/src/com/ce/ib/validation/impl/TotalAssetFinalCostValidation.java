package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class TotalAssetFinalCostValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		BigDecimal delta = AssetStudyAndInfoUtil.processFinalCost(bankingObject,
				BankFusionThreadLocal.getBankFusionEnvironment());
		if (delta.compareTo(BigDecimal.ZERO) != 0) {
			return true;
		}
		return false;

	}

}
