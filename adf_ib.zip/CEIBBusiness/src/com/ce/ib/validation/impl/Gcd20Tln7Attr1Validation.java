package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.DealValidationUtil;
import com.ce.ib.validation.IValidation;

import bf.com.misys.ib.types.IslamicBankingObject;

public class Gcd20Tln7Attr1Validation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - For GROUP CD 20 And TOOL No 7 If the Attribute-1 Is less than 10 it should go to approval to group 3
		 */
		boolean isAttr1ValueLessThan10 = false;
		BigDecimal attr1Value = DealValidationUtil.getAttributeValue(1, 20, 7, bankingObject);
		if(null != attr1Value && (new BigDecimal(10)).compareTo(attr1Value) > 0)
		{
			isAttr1ValueLessThan10 = true;
		}
		return isAttr1ValueLessThan10;
	}

}
