package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.validation.IValidation;

import bf.com.misys.ib.types.IslamicBankingObject;

public class InitialFeeDeductDisbursment implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        String udfNameInitialFee = "INITIAL_FEE_AMOUNT";
        String udfNameFeeCollection = "INITIAL_FEE_COLLECTION_METHOD";
        
        BigDecimal initialFee = (BigDecimal) CeUtils.getUDFValueByNameFromAdditionalDtls(bankingObject.getDealID(), udfNameInitialFee);
        String initialFeeCollection = (String) CeUtils.getUDFValueByNameFromAdditionalDtls(bankingObject.getDealID(), udfNameFeeCollection);
        
        if (initialFee.compareTo(BigDecimal.ZERO)>0) {
            if(initialFeeCollection.equals("DEDUCT FROM DISBURSEMENT")) {
                return true;
            }
        }

        return false;

    }
}
