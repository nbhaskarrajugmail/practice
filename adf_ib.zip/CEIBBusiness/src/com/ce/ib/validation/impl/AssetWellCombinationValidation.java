package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechincalAsset;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalWell;
import com.ce.bankfusion.ib.fatom.GetAssetAttributeNames;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_AST_AssetDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetDtls;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetWellCombinationValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		/*
		 * If existing asset in Technical analysis is used as a Asset in Study BB for
		 * specific asset GRPCD 10 and TOOLNO4,5 AND GRP 12 and TOOL No 6 with Cross
		 * combination and Well status 1 and Well condition 1 Then it should go for
		 * approval to group 3
		 */
		boolean isWellCondition = isWellCondition(bankingObject);
		boolean isAssetCoondition = isAssetCondition(bankingObject);

		if (isAssetCoondition && isWellCondition) {
			return true;
		}

		return false;
	}

	private boolean isAssetCondition(IslamicBankingObject bankingObject) {
		boolean isAssetCondition = false;

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String technicalFarmDtlsWhereClause = "WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_TechnicalFarm> technicalFarmDtlList = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
				technicalFarmDtlsWhereClause, params, null, false);
		for (IBOCE_IB_TechnicalFarm eachtechnicalFarmDtl : technicalFarmDtlList) {
			String technicalAssetDtlsWhereClause = "WHERE " + IBOCE_IB_TechincalAsset.IBREFERENCENUMBER + " = ?";
			params.clear();
			params.add(eachtechnicalFarmDtl.getBoID());
			List<IBOCE_IB_TechincalAsset> technicalAssetDtlList = factory.findByQuery(IBOCE_IB_TechincalAsset.BONAME,
					technicalAssetDtlsWhereClause, params, null, false);
			for (IBOCE_IB_TechincalAsset eachtechnicalAssetDtl : technicalAssetDtlList) {
				String dealAssetDtlsWhereClause = "WHERE " + IBOIB_DLI_DealAssetDtls.DEALNO + " = ?";
				params.clear();
				params.add(bankingObject.getDealID());
				List<IBOIB_DLI_DealAssetDtls> dealAssetDtlList = factory.findByQuery(IBOIB_DLI_DealAssetDtls.BONAME,
						dealAssetDtlsWhereClause, params, null, false);
				for (IBOIB_DLI_DealAssetDtls eachdealAsset : dealAssetDtlList) {
					String assetDtlsWhereClause = "WHERE " + IBOIB_AST_AssetDetails.ASSETDETAILSID + " = ?";
					params.clear();
					params.add(eachdealAsset.getF_ASSETDETAILSID());
					List<IBOIB_AST_AssetDetails> assetDtlList = factory.findByQuery(IBOIB_AST_AssetDetails.BONAME,
							assetDtlsWhereClause, params, null, false);
					for (IBOIB_AST_AssetDetails eachAssetDtl : assetDtlList) {
						if (eachAssetDtl.getF_CATEGORY().equals(eachtechnicalAssetDtl.getF_IBASSETCATEGORY())) {
							String assetCategoryID = eachAssetDtl.getF_CATEGORY();
							GetAssetAttributeNames assetAttributeNames = new GetAssetAttributeNames(
									BankFusionThreadLocal.getBankFusionEnvironment());
							assetAttributeNames.setF_IN_categoryID(assetCategoryID);
							assetAttributeNames.setF_IN_onlyAttributeMode(false);
							assetAttributeNames.setF_IN_dealID("Dummy");
							assetAttributeNames.process(BankFusionThreadLocal.getBankFusionEnvironment());
							Integer groupcd = assetAttributeNames.getF_OUT_GROUPCD();
							Integer toolNo = assetAttributeNames.getF_OUT_TOOLNO();
							if ((groupcd == 10 && (toolNo == 4 || toolNo == 5)) || (groupcd == 12 && toolNo == 6)) {
								isAssetCondition = true;
							}

						}
					}

				}

			}
		}

		return isAssetCondition;

	}

	private boolean isWellCondition(IslamicBankingObject bankingObject) {
		boolean isWellCondition = false;

		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String technicalFarmDtlsWhereClause = "WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_TechnicalFarm> technicalFarmDtlList = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
				technicalFarmDtlsWhereClause, params, null, false);
		for (IBOCE_IB_TechnicalFarm eachtechnicalFarmDtl : technicalFarmDtlList) {
			String technicalWellDtlsWhereClause = "WHERE " + IBOCE_IB_TechnicalWell.IBREFERENCENUMBER + " = ?";
			params.clear();
			params.add(eachtechnicalFarmDtl.getBoID());
			List<IBOCE_IB_TechnicalWell> technicalWellDtlList = factory.findByQuery(IBOCE_IB_TechnicalWell.BONAME,
					technicalWellDtlsWhereClause, params, null, false);
			for (IBOCE_IB_TechnicalWell eachtechnicalWellDtl : technicalWellDtlList) {
				if (eachtechnicalWellDtl.getF_IBWELLSTATUS().equalsIgnoreCase("1")
						&& eachtechnicalWellDtl.getF_IBISWELLUSED().equalsIgnoreCase("1")) {
					isWellCondition = true;
				}
			}
		}

		return isWellCondition;

	}

}
