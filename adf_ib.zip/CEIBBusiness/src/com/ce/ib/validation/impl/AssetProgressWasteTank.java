package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.core.CommonConstants;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressWasteTank implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		String wasteTankToolID = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.WASTE_TANK_TOOL_ID, "",
				CeConstants.ADFIBCONFIGLOCATION);

		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode(CeConstants.MODE_RETRIEVE);
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
		boolean wasteTank = false;
		BigDecimal wasteTankProgress = BigDecimal.ZERO;

		for (AssetProgressDetails assetProgressDetails : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
				.getAssetProgressDetailsList()) {
			if (assetProgressDetails.getToolNO().toString().equals(wasteTankToolID)) {
				wasteTank = true;
				wasteTankProgress = assetProgressDetails.getInvoiceCompletionPercentage();
			}
		}
		if (wasteTank) {

			if (wasteTankProgress.compareTo(new BigDecimal(50)) > CommonConstants.INTEGER_ZERO
					&& wasteTankProgress.compareTo(new BigDecimal(100)) < CommonConstants.INTEGER_ZERO) {
				for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
						.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
					if ((wasteTankToolID.equals(assetProgressDetails.getToolNO().toString()))
							&& assetProgressDetails.getAllowedFinalCost().getCurrencyAmount()
									.compareTo(assetProgressDetails.getActualFinalCost().getCurrencyAmount()) > 0) {
						return true;
					}
				}
			}
		}
		return isException;
	}
}
