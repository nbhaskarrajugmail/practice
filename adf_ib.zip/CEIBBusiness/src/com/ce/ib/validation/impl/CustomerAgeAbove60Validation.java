package com.ce.ib.validation.impl;

import java.sql.Date;
import java.time.Period;
import org.apache.commons.lang.StringUtils;

import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.spi.types.CustomerDetails;
import bf.com.misys.ib.types.IslamicBankingObject;

public class CustomerAgeAbove60Validation implements IValidation {
	private static String PARTY_TYPE_PERSONAL = "1062";
	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isCustomerAgeAbove60 = false;
		String primaryPartyID = IBCommonUtils.getDealPrimaryPartyID(bankingObject.getDealID());
		if (StringUtils.isNotBlank(primaryPartyID)) {
			CustomerDetails customerDetails = IBCommonUtils.getPartyDetailsFromPartyID(primaryPartyID,
					BankFusionThreadLocal.getBankFusionEnvironment());
			if (customerDetails.getCustomerBasicDetails().getPartyType().equals(PARTY_TYPE_PERSONAL)
					&& null != customerDetails && null != customerDetails.getPersonalDetails()
					&& IBCommonUtils.isNotEmpty(customerDetails.getPersonalDetails().getDateOfBirth().toString())) {
				Date customerAge = customerDetails.getPersonalDetails().getDateOfBirth();
				Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
				Period ageDifference = Period.between(customerAge.toLocalDate(), businessDate.toLocalDate());
				if (ageDifference.getYears() > 60) {
					isCustomerAgeAbove60 = true;
				}
			}
		}
		return isCustomerAgeAbove60;

	}

}
