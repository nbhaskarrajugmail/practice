package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ce.bankfusion.ib.fatom.AssetProgressingFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.AssetProgressDetails;
import bf.com.misys.ib.types.AssetProgressReport;
import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressNormalPrtHouse50Perc implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		List<String> normalProtectedHouseList = new ArrayList<>();
		String normalProtectedHouse = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
				CeConstants.ASSET_PROGRESS_RULES_CONF_FILE, CeConstants.NORMAL_PROTECTED_HOUSE, "",CeConstants.ADFIBCONFIGLOCATION);

		if (normalProtectedHouse != null && !normalProtectedHouse.isEmpty()) {
			normalProtectedHouseList = IBCommonUtils.isNotEmpty(normalProtectedHouse)? Arrays.asList(normalProtectedHouse.split(",")): new ArrayList<String>();
		}
		AssetProgressingFatom assetProgressingFatom = new AssetProgressingFatom(
				IBCommonUtils.getBankFusionEnvironment());
		assetProgressingFatom.setF_IN_islamicBankingObject(bankingObject);
		assetProgressingFatom.setF_IN_mode("RETRIEVE");
		assetProgressingFatom.process(IBCommonUtils.getBankFusionEnvironment());
		if (assetProgressingFatom.getF_OUT_assetProgressReportDetails().getAssetProgressReportListCount() == 1) {
			for (AssetProgressReport assetProgressReport : assetProgressingFatom.getF_OUT_assetProgressReportDetails()
					.getAssetProgressReportList()) {
				if (assetProgressReport.getReportStatus().equals("New")) {
					for (AssetProgressDetails assetProgressDetails : assetProgressingFatom
							.getF_OUT_assetProgressReportDetails().getAssetProgressDetailsList()) {
						if (assetProgressDetails.getReportID().equals(assetProgressReport.getReportID())) {
							if (normalProtectedHouseList.contains(assetProgressDetails.getToolNO().toString())
									&& assetProgressDetails.getAllowedFinalCost().getCurrencyAmount().compareTo(
											assetProgressDetails.getActualFinalCost().getCurrencyAmount()) > 0)
								return true;
						}
					}
				}
			}
		}
		return isException;
	}

}
