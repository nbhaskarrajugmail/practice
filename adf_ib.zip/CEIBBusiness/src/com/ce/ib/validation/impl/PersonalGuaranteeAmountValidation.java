package com.ce.ib.validation.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.util.CollateralRequestDtlsUtils;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class PersonalGuaranteeAmountValidation implements IValidation {	
	
	@Override
		public boolean validate(IslamicBankingObject bankingObject) {
			/*
			 * Agenda - For personal Guarantee if the amount is going beyond 250k then it should go for Approval to grp 2
			 */
        String whereClause = "WHERE " + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " = ? AND " + IBOCE_IB_CollateralRevaluationDetails.IBREQUESTTYPE + " = ? ";
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        BigDecimal availableBalance = CollateralRequestDtlsUtils.readPersonalRequestAvailableBalance();

		boolean isAmountExceeded = false;
		String dealID= bankingObject.getDealID();		
		ArrayList<String> queryParams = new ArrayList<String>();
		queryParams.add(dealID);
		queryParams.add("Personal");
	        
		List<IBOCE_IB_CollateralRevaluationDetails> collateralDealDtls = factory.findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, whereClause, queryParams, null, true);
		if(!collateralDealDtls.isEmpty() && collateralDealDtls!=null){            
			for (IBOCE_IB_CollateralRevaluationDetails eachCollDtlsFromDB : collateralDealDtls) { 
			    if(eachCollDtlsFromDB.getF_IBCOVERVALUE().compareTo(availableBalance)==1) {
			    	 isAmountExceeded=true;
			    }
		    }
		}		
		return isAmountExceeded;
	}
}
