package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class RescheduleCheckSubsidy implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        String selectQueryFarm = "WHERE " + IBOCE_IB_DealReschedule.IBDEALID + " = ? ";
        ArrayList<String> param = new ArrayList<>();
        param.add(bankingObject.getDealID());
        List<IBOCE_IB_DealReschedule> farmDetail = factory.findByQuery(IBOCE_IB_DealReschedule.BONAME,
            selectQueryFarm, param, null, false);
        if(farmDetail != null) {
        IBOCE_IB_DealReschedule farmItem = farmDetail.get(0);
        if(farmItem.isF_IBINCLUDESUBSIDY()) {
            return true;
        }
        }
        return false;
    }

}
