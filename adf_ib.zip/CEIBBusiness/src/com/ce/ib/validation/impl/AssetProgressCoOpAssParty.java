package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.ib.validation.IValidation;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressCoOpAssParty implements IValidation {
	private static String GET_REPORTS_BY_DEAL_QUERY = " WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + " = ?";

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isException = false;
		if (CeUtils.checkIfCooperativeParty(bankingObject.getDealID())) {
			ArrayList<String> params = new ArrayList<>();
			params.add(bankingObject.getDealID());
			List<IBOCE_IB_AssetProgressReport> assetProgressReportList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
			if (assetProgressReportList != null && assetProgressReportList.size() == 1) {
				if (assetProgressReportList.get(0).getF_IBCOLLECTADVANCEPAY().equalsIgnoreCase("NO")) {
					return true;
				}
			}
		}
		return isException;
	}

}
