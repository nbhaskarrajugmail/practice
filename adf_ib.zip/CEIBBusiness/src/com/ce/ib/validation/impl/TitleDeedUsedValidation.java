package com.ce.ib.validation.impl;

import java.sql.Date;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealTitleDeedDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_TechnicalFarm;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class TitleDeedUsedValidation implements IValidation {

	private static final int DEALPERIODINYEARS = 3;
	private static final String SOILTYPE = "1";

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {

		boolean isTdLessThan3Years = isTdLessThan3Years(bankingObject);
		boolean isSoilType = isSoilType(bankingObject);

		if (isTdLessThan3Years && isSoilType) {
			return true;
		}

		return false;

	}

	public boolean isTdLessThan3Years(IslamicBankingObject bankingObject) {
		boolean isTdLessThan3Years = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String dealTDWhereClause = "WHERE " + IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_DealTitleDeedDtls> tdsLinkedToDeal = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME,
				dealTDWhereClause, params, null, false);
		for (IBOCE_IB_DealTitleDeedDtls tdLinkedToDeal : tdsLinkedToDeal) {
			String dealsLinkedToTDWhereClause = "WHERE " + IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDID + " = ? AND "
					+ IBOCE_IB_DealTitleDeedDtls.IBTITLEDEEDVERSIONNUM + " = ? AND "
					+ IBOCE_IB_DealTitleDeedDtls.IBDEALNUMBER + " != ?";
			params.clear();
			params.add(tdLinkedToDeal.getF_IBTITLEDEEDID());
			params.add(tdLinkedToDeal.getF_IBTITLEDEEDVERSIONNUM());
			params.add(bankingObject.getDealID());
			List<IBOCE_IB_DealTitleDeedDtls> dealsLinkedToTD = factory.findByQuery(IBOCE_IB_DealTitleDeedDtls.BONAME,
					dealsLinkedToTDWhereClause, params, null, false);
			for (IBOCE_IB_DealTitleDeedDtls dealLinkedToTD : dealsLinkedToTD) {
				String dealID = dealLinkedToTD.getF_IBDEALNUMBER();
				IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealID);
				Date dealStartDate = dealDtls.getF_DealStartDate();
				Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
				Period dealPeriod = Period.between(dealStartDate.toLocalDate(), businessDate.toLocalDate());
				if (dealPeriod.getYears() < DEALPERIODINYEARS) {
					isTdLessThan3Years = true;
					break;
				}

			}
		}
		return isTdLessThan3Years;

	}

	public boolean isSoilType(IslamicBankingObject bankingObject) {
		boolean isSoilType = false;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String technicalFarmDtlsWhereClause = "WHERE " + IBOCE_IB_TechnicalFarm.IBDEALID + " = ?";
		ArrayList<String> params = new ArrayList<>();
		params.add(bankingObject.getDealID());
		List<IBOCE_IB_TechnicalFarm> technicalFarmDtlList = factory.findByQuery(IBOCE_IB_TechnicalFarm.BONAME,
				technicalFarmDtlsWhereClause, params, null, false);
		for (IBOCE_IB_TechnicalFarm eachtechnicalFarmDtl : technicalFarmDtlList) {
			if (eachtechnicalFarmDtl.getF_IBSOILTYPE().equals(SOILTYPE)) {
				isSoilType = true;
			}
		}
		return isSoilType;

	}
}