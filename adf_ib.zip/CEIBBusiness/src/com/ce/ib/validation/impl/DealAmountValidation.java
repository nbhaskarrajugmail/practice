package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DealAmountValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isAmountBreached = false;
		String dealID = bankingObject.getDealID();
		//IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOIB_DLI_DealDetails dealDtls = IBCommonUtils.getDealDetails(dealID);
		if(null != dealDtls && (new BigDecimal(2000000.00)).compareTo(dealDtls.getF_DealAmt()) < 0 )
		{
			isAmountBreached = true;
		}
		return isAmountBreached;
	}

}
