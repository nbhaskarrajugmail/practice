package com.ce.ib.validation.impl;

import java.util.ArrayList;
import java.util.List;

import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealAssetChargesdtls;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.IslamicBankingObject;

public class FeesWaiveValidation implements IValidation {

	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		boolean isAnyFeeWaived = false;
		String whereClause = "WHERE " + IBOIB_DLI_DealAssetChargesdtls.DealNo + " = ? AND "
				+ IBOIB_DLI_DealAssetChargesdtls.STEPID + " = ? AND "
				+ IBOIB_DLI_DealAssetChargesdtls.SRVCID + " = ? AND "
				+ IBOIB_DLI_DealAssetChargesdtls.ISWAIVED + " = ? ";
		ArrayList<String> params = new ArrayList<>();
		bankingObject.setTransactionID(bankingObject.getDealID());
		params.add(bankingObject.getDealID());
		params.add(bankingObject.getStepID());
		params.add(bankingObject.getTransactionID());
		params.add("Y");
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		List<IBOIB_DLI_DealAssetChargesdtls> waivedCharges = factory.findByQuery(IBOIB_DLI_DealAssetChargesdtls.BONAME, whereClause, params, null, false);
		if(!waivedCharges.isEmpty())
		{
			isAnyFeeWaived = true;
		}
		
		return isAnyFeeWaived;
	}

}
