package com.ce.ib.validation.impl;

import java.math.BigDecimal;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.util.AssetStudyAndInfoUtil;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class FinalCostLeftOverAssetStudyInfoValidation implements IValidation {
	private transient final static Log LOGGER = LogFactory
			.getLog(FinalCostLeftOverAssetStudyInfoValidation.class.getName());
	@Override
	public boolean validate(IslamicBankingObject bankingObject) {
		/*
		 * Agenda - If the include liability is true then it should go for Approval
		 */
		boolean finalCostLeftOver = false;
		AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(BankFusionThreadLocal.getBankFusionEnvironment());
		assetInfoAndStudyFatom.setF_IN_islamicBankingObject(bankingObject);
		assetInfoAndStudyFatom.setF_IN_mode(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE);
		assetInfoAndStudyFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
		AssetThirdPartyDetailsList assetTPDtlList = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList();
		
		String totalFinalCostUdfName = BankFusionPropertySupport.getPropertyBasedOnConfLocation(CeConstants.UDFPROPERTY,
				CeConstants.TOTAL_FINAL_COST_UDFNAME, "", CeConstants.ADFIBCONFIGLOCATION);
		BigDecimal totalFinalCost = (BigDecimal)AssetStudyAndInfoUtil.getUDFValue(totalFinalCostUdfName, bankingObject.getDealID());
		LOGGER.info("Total final cost for the Deal :"+bankingObject.getDealID()+" is:"+totalFinalCost.doubleValue());
		BigDecimal totalAssetsCost = BigDecimal.ZERO;
		for(AssetThirdPartyDetails assetTPDtl : assetTPDtlList.getAssetThirdPartyDetails()) {
			totalAssetsCost = totalAssetsCost.add(assetTPDtl.getFinalCost().getCurrencyAmount());
		}
		LOGGER.info("Total Assets final cost for the Deal :"+bankingObject.getDealID()+" is:"+totalAssetsCost.doubleValue());
		if(totalAssetsCost.compareTo(totalFinalCost)!=0) {
			finalCostLeftOver = true;
			LOGGER.info("There is left over of final cost for the Deal :"+bankingObject.getDealID()+" and returning true");
		}
		return finalCostLeftOver;
	}

}
