package com.ce.ib.validation.impl;

import com.ce.bankfusion.ib.fatom.AssetInfoAndStudyFatom;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProcessConfig;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.ib.types.AssetThirdPartyDetails;
import bf.com.misys.ib.types.AssetThirdPartyDetailsList;
import bf.com.misys.ib.types.IslamicBankingObject;

public class Gcd0Tln368NormalProcessValidation implements IValidation {

    @Override
    public boolean validate(IslamicBankingObject bankingObject) {
        String normalLoanProcess = BankFusionPropertySupport.getPropertyBasedOnConfLocation(ValidationExceptionConstants.PROPERTIES_FILE,
            ValidationExceptionConstants.NORMAL_LOAN_PROCESS, "", CeConstants.ADFIBCONFIGLOCATION);
        String normalLoanOriginationProcess =
            BankFusionPropertySupport.getPropertyBasedOnConfLocation(ValidationExceptionConstants.PROPERTIES_FILE,
                ValidationExceptionConstants.NORMAL_LOAN_ORIGINATION_PROCESS, "", CeConstants.ADFIBCONFIGLOCATION);
        
        IBOIB_CFG_ProcessConfig processConfig = (IBOIB_CFG_ProcessConfig) BankFusionThreadLocal.getPersistanceFactory()
            .findByPrimaryKey(IBOIB_CFG_ProcessConfig.BONAME, bankingObject.getProcessConfigID(), true);
        if (processConfig.getF_TEMPLATEID().equalsIgnoreCase(normalLoanProcess)
            || processConfig.getF_TEMPLATEID().equalsIgnoreCase(normalLoanOriginationProcess)) {
            AssetInfoAndStudyFatom assetInfoAndStudyFatom = new AssetInfoAndStudyFatom(BankFusionThreadLocal.getBankFusionEnvironment());
            assetInfoAndStudyFatom.setF_IN_islamicBankingObject(bankingObject);
            assetInfoAndStudyFatom.setF_IN_mode(CeConstants.ASSET_AND_STUDY_WITH_FINAL_ONLY_MODE);
            assetInfoAndStudyFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
            AssetThirdPartyDetailsList assetList = assetInfoAndStudyFatom.getF_OUT_assetThirdPartyDetailsList();
            for (AssetThirdPartyDetails eachAssetDtl : assetList.getAssetThirdPartyDetails()) {
                if (eachAssetDtl.getGroupCD() == 0 && eachAssetDtl.getToolNO() == 368) {
                    return true;
                }

            }
        }
        return false;
    }

}
