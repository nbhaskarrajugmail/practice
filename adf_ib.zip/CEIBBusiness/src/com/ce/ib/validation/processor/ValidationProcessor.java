package com.ce.ib.validation.processor;

import com.ce.bankfusion.ib.util.ValidationExceptionConstants;
import com.ce.bankfusion.ib.util.ValidationsUtil;
import com.ce.ib.validation.IValidation;
import com.misys.bankfusion.util.IBCommonUtils;

import bf.com.misys.ib.types.IslamicBankingObject;
import bf.com.misys.ib.types.Validation;

public class ValidationProcessor {

	public static boolean processValidation(IslamicBankingObject ibObj, String validationID)
	{
		Validation validationDefiniton = ValidationsUtil.getValidation(validationID);
		boolean isValidationBreached = false;
		try
		{
			Class validationImplClass = Class.forName(validationDefiniton.getImplClass());
			IValidation validationImplClassInstance = (IValidation) validationImplClass.newInstance();
			isValidationBreached = validationImplClassInstance.validate(ibObj);
		}
		catch(Exception e)
		{
			//TODO - throw the error
			e.printStackTrace();
			IBCommonUtils.raiseParametrizedEvent(ValidationExceptionConstants.E_VALIDATION_PROCESSING_FAILED, 
					new String[] {ValidationsUtil.getValidation(validationID).getName()});
		}
		return isValidationBreached;
	}

}
