package com.ce.ib.fatoms.batch.scheduleUpdateProcess;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_ScheduleBreakupUpdateTag;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

/**
 * 
 * @author Anusha Bheemunipalli
 * @Description Schedule update batch to update breakup customized table upon
 *              repayment collection during EOD
 */
public class ScheduleUpdateBatchProcess extends AbstractBatchProcess {
	private transient final static Log LOGGER = LogFactory.getLog(ScheduleUpdateBatchProcess.class.getName());

	private AbstractProcessAccumulator accumulator;
	private ScheduleUpdateBatchFatomContext context;
	private static final String PAGING_SQL = " WHERE " + IBOCE_IB_ScheduleBreakupUpdateTag.IBROWSEQ
			+ " BETWEEN ? AND ? ";
	private static final String breakupDtls_whereClause = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";

	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public ScheduleUpdateBatchProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = (ScheduleUpdateBatchFatomContext) context;
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();
	}

	@Override
	protected void initialiseAccumulator() {
		accumulator = new ScheduleUpdateBatchAccumulator(new Object[0]);
	}

	@SuppressWarnings("unchecked")
	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		LOGGER.info("Processing Schedule breakup table update batch process");
		int pageSize = 0;
		int fromValue = 0;
		int toValue = 0;
		pageSize = context.getPageSize();
		pagingData.setCurrentPageNumber(pageToProcess);
		fromValue = ((pageToProcess - 1) * pageSize) + 1;
		toValue = pageToProcess * pageSize;
		LOGGER.info("processing from " + fromValue + " to " + toValue);

		if (context != null) {
			ArrayList<Integer> paramList = new ArrayList<>();
			paramList.add(fromValue);
			paramList.add(toValue);
			List<IBOCE_IB_ScheduleBreakupUpdateTag> tagResult = factory
					.findByQuery(IBOCE_IB_ScheduleBreakupUpdateTag.BONAME, PAGING_SQL, paramList, null, true);

			if (tagResult != null && !tagResult.isEmpty()) {
				for (IBOCE_IB_ScheduleBreakupUpdateTag breakupUpdateTag : tagResult) {
					BigDecimal prevReschProfitPaidAmount = RescheduleUtils
							.getPaidRescheduleProfit(breakupUpdateTag.getF_IBLOANREFERENCE());
					updateScheduleTable(breakupUpdateTag);
					BigDecimal updatedReschProfitPaidAmount = RescheduleUtils
							.getPaidRescheduleProfit(breakupUpdateTag.getF_IBLOANREFERENCE());
					BigDecimal adjustAmount = updatedReschProfitPaidAmount.subtract(prevReschProfitPaidAmount);
					if (adjustAmount.compareTo(BigDecimal.ZERO) == 1) {
						RescheduleUtils.callRescheduleProfitBackOfficeRequest(breakupUpdateTag.getF_IBACCOUNTID(),
								breakupUpdateTag.getF_IBLOANREFERENCE(), breakupUpdateTag.getBoID(), adjustAmount);
					}
					factory.commitTransaction();
					factory.beginTransaction();
				}
			}
		}

		return accumulator;
	}

	private void updateScheduleTable(IBOCE_IB_ScheduleBreakupUpdateTag breakupUpdateTag) {
		LOGGER.info("updating Breakup customized table : begin");
		BigDecimal hundred = new BigDecimal(100);
		LOGGER.info("Processing for AccountID : " + breakupUpdateTag.getF_IBACCOUNTID());
		ArrayList<Object> params = new ArrayList<>();
		params.add(breakupUpdateTag.getF_IBLOANREFERENCE());
		params.add(breakupUpdateTag.getF_IBDUEDATE());
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME,
				breakupDtls_whereClause, params, null, true);

		if (ibPaymentSchResult != null && !ibPaymentSchResult.isEmpty()) {
			if (breakupUpdateTag.isF_IBISFULLYPAID()) {
				// repayment is fully paid
				LOGGER.info("Repayment is fully paid for loan reference: " + breakupUpdateTag.getF_IBLOANREFERENCE());
				for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
					paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
					paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
					paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				}
			} else {
				// fetching total repayment principal, profit and fees for the billDate
				BigDecimal totalRepaymentPrincipal = BigDecimal.ZERO;
				BigDecimal totalRepaymentProfit = BigDecimal.ZERO;
				for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
					totalRepaymentPrincipal = totalRepaymentPrincipal.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
					totalRepaymentProfit = totalRepaymentProfit.add(paymentSchBreakup.getF_IBPROFITAMT())
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				}

				// fetching the percentages for Principal, Profit at Asset level
				HashMap<String, BigDecimal> assetIdWithPrincipalPercentage = new HashMap<>();
				HashMap<String, BigDecimal> assetIdWithProfitPercentage = new HashMap<>();
				BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
				BigDecimal assetProfitPercentage = BigDecimal.ZERO;
				BigDecimal remAssetPrincipalPercentage = new BigDecimal(100);
				BigDecimal remAssetProfitPercentage = new BigDecimal(100);
				BigDecimal assetProfitAmount = BigDecimal.ZERO;
				int i = 1;
				for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
					assetProfitAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					if (i == ibPaymentSchResult.size()) {
						assetPrincipalPercentage = remAssetPrincipalPercentage;
						assetProfitPercentage = remAssetProfitPercentage;
					} else {
						if (totalRepaymentPrincipal.compareTo(BigDecimal.ZERO) > 0) {
							assetPrincipalPercentage = (paymentSchBreakup.getF_IBPRINCIPALAMT().multiply(hundred))
									.divide(totalRepaymentPrincipal, 0, RoundingMode.UP);
						}
						if (totalRepaymentProfit.compareTo(BigDecimal.ZERO) > 0) {
							assetProfitPercentage = (assetProfitAmount.multiply(hundred)).divide(totalRepaymentProfit,
									0, RoundingMode.UP);
						}
					}
					assetIdWithPrincipalPercentage.put(paymentSchBreakup.getF_IBASSETID(), assetPrincipalPercentage);
					assetIdWithProfitPercentage.put(paymentSchBreakup.getF_IBASSETID(), assetProfitPercentage);
					remAssetPrincipalPercentage = remAssetPrincipalPercentage.subtract(assetPrincipalPercentage);
					remAssetProfitPercentage = remAssetProfitPercentage.subtract(assetProfitPercentage);
					++i;
				}

				// updating breakup table
				updatePaymentBreakupTable(breakupUpdateTag.getF_IBPRINCIPALPAID(),
						breakupUpdateTag.getF_IBINTERESTPAID(), hundred, breakupUpdateTag.getF_IBACCOUNTID(),
						ibPaymentSchResult, assetIdWithPrincipalPercentage, assetIdWithProfitPercentage);
			}
		} else {
			LOGGER.info("Not an IB Deal Account for Breakup table to update");
		}
		LOGGER.info("updating Breakup customized table : end");
	}

	private void updatePaymentBreakupTable(BigDecimal principalPaid, BigDecimal profitPaid, BigDecimal hundred,
			String accountId, List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult,
			HashMap<String, BigDecimal> assetIdWithPrincipalPercentage,
			HashMap<String, BigDecimal> assetIdWithProfitPercentage) {

		IBOLendingFeature loanDtls = (IBOLendingFeature) factory.findByPrimaryKey(IBOLendingFeature.BONAME, accountId,
				true);
		String collectionOrderProfile = loanDtls.getF_COLLECTIONORDER();
		BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
		BigDecimal assetProfitPercentage = BigDecimal.ZERO;
		BigDecimal remPrincipalPaid = principalPaid;
		BigDecimal remProfitPaid = profitPaid;
		BigDecimal assetPrincipalPaidAmount = BigDecimal.ZERO;
		BigDecimal assetProfitAndFeesPaidAmount = BigDecimal.ZERO;
		int j = 1;
		boolean isAssetProfitAndFeesFullyPaid = false;
		boolean isAssetPrincipalFullyPaid = false;

		LOGGER.info("Updating breakup table for BillDate : " + ibPaymentSchResult.get(0).getF_IBBILLDATE());
		LOGGER.info("Collection order profile : " + collectionOrderProfile);
		LOGGER.info("Principal Paid : " + principalPaid);
		LOGGER.info("Profit Paid : " + profitPaid);

		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			isAssetProfitAndFeesFullyPaid = false;
			isAssetPrincipalFullyPaid = false;
			assetPrincipalPercentage = assetIdWithPrincipalPercentage.get(paymentSchBreakup.getF_IBASSETID());
			assetProfitPercentage = assetIdWithProfitPercentage.get(paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Principal Percentage / AssetId : " + assetPrincipalPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Profit Percentage / AssetId : " + assetProfitPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());
			
			assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
					RoundingMode.UP);
			if (j == ibPaymentSchResult.size()) {
				assetProfitAndFeesPaidAmount = remProfitPaid;
				if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()
						.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset"+ paymentSchBreakup.getF_IBASSETID()+" is "+ isAssetProfitAndFeesFullyPaid);
				}
				assetPrincipalPaidAmount = remPrincipalPaid;
			} else {
				assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if(assetPrincipalPaidAmount.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMT()) >= 0) {
					assetPrincipalPaidAmount = paymentSchBreakup.getF_IBPRINCIPALAMT();
					isAssetPrincipalFullyPaid = true;
					LOGGER.info("Principal Fully Paid for Asset"+ paymentSchBreakup.getF_IBASSETID()+" is "+ isAssetPrincipalFullyPaid);
				}
				assetProfitAndFeesPaidAmount = (profitPaid.multiply(assetProfitPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()
						.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset"+ paymentSchBreakup.getF_IBASSETID()+" is "+ isAssetProfitAndFeesFullyPaid);
				}
				remPrincipalPaid = remPrincipalPaid.subtract(assetPrincipalPaidAmount);
				remProfitPaid = remProfitPaid.subtract(assetProfitAndFeesPaidAmount);
			}
			
			if(isAssetPrincipalFullyPaid) {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
			}else {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(assetPrincipalPaidAmount);
			}
			if (isAssetProfitAndFeesFullyPaid) {
				paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
			} else {
				if (collectionOrderProfile.indexOf('I') > collectionOrderProfile.indexOf('F')) {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) > 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBPROFITAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) == 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
					} else {
						paymentSchBreakup.setF_IBPROFITAMTPAID(assetProfitAndFeesPaidAmount);
					}
				} else {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) > 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						paymentSchBreakup.setF_IBPROFITAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) == 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					} else {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(assetProfitAndFeesPaidAmount);
					}
				}
			}
			++j;
		}
	}

}
