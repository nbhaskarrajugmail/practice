package com.ce.ib.fatoms.batch.loanPostingUpdateProcess;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_LoanPostingBreakupUpdateTag;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class LoanPostingUpdateBatchProcess extends AbstractBatchProcess {

	private transient final static Log LOGGER = LogFactory.getLog(LoanPostingUpdateBatchProcess.class.getName());

	private AbstractProcessAccumulator accumulator;
	private LoanPostingUpdateBatchFatomContext context;
	private static final String PAGING_SQL = " WHERE " + IBOCE_IB_LoanPostingBreakupUpdateTag.IBROWSEQ
			+ " BETWEEN ? AND ? ";
	private static final String LOANPOSTINGDTLS_WHERECLAUSE = "WHERE " + IBOCE_IB_LoanPostingBreakupUpdateTag.IBACCOUNTID + " = ? AND "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBREPAYMENTDATE + " = ?";

	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();

	public LoanPostingUpdateBatchProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = (LoanPostingUpdateBatchFatomContext) context;
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();
		
	}

	@Override
	protected void initialiseAccumulator() {
		accumulator = new LoanPostingUpdateBatchAccumulator(new Object[0]);
		
	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		LOGGER.info("Processing LoanPostingUpdateBatchProcess batch process");
		int pageSize = 0;
		int fromValue = 0;
		int toValue = 0;
		pageSize = context.getPageSize();
		pagingData.setCurrentPageNumber(pageToProcess);
		fromValue = ((pageToProcess - 1) * pageSize) + 1;
		toValue = pageToProcess * pageSize;
		LOGGER.info("processing from " + fromValue + " to " + toValue);
		if (context != null) {
			ArrayList<Integer> paramList = new ArrayList<>();
			paramList.add(fromValue);
			paramList.add(toValue);
			List<IBOCE_IB_LoanPostingBreakupUpdateTag> tagResult = factory
					.findByQuery(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME, PAGING_SQL, paramList, null, true);

			if (tagResult != null && !tagResult.isEmpty()) {
				for (IBOCE_IB_LoanPostingBreakupUpdateTag breakupUpdateTag : tagResult) {
					LOGGER.info(tagResult);

					if (breakupUpdateTag.getF_IBSTATUS().equalsIgnoreCase("UNPROCESSED")) {
						ArrayList<Object> params = new ArrayList<>();
						params.add(breakupUpdateTag.getF_IBDEALID());
						IBOIB_DLI_DealDetails dealDtls = (IBOIB_DLI_DealDetails) factory
								.findByPrimaryKey(IBOIB_DLI_DealDetails.BONAME, breakupUpdateTag.getF_IBDEALID(), true);
						try {
							CEUtil ceUtil = new CEUtil();
							String drTxnCode = null;
							String crTxnCode = null;
							drTxnCode = ceUtil.getModuleConfigurationValue(RescheduleUtils.MODULE_NAME_IB, RescheduleUtils.EOD_DEBIT_PARAM_NAME);
							crTxnCode = ceUtil.getModuleConfigurationValue(RescheduleUtils.MODULE_NAME_IB, RescheduleUtils.EOD_CREDIT_PARAM_NAME);
							if (breakupUpdateTag.getF_IBINSTALLMENTPROFIT().compareTo(BigDecimal.ZERO) > 0) {
								LOGGER.info("Posting the installment Profit for the dealID -->"
										+ breakupUpdateTag.getF_IBDEALID());
								String debitAcctIdProfit = RescheduleUtils.getUnearnedAcc(
										dealDtls.getF_BranchSortCode(), dealDtls.getF_IsoCurrencyCode());
								String creditAcctIdProfit = RescheduleUtils.getUpfrontIncomeAcc(
										dealDtls.getF_BranchSortCode(), dealDtls.getF_IsoCurrencyCode());
								String narrative = breakupUpdateTag.getF_IBACCOUNTID() + "$Profit for the Account Id "
										+ breakupUpdateTag.getF_IBACCOUNTID() + ", Repayment date "
										+ breakupUpdateTag.getF_IBREPAYMENTDATE();
								
								RescheduleUtils.callBackOfficePostingRequest(dealDtls.getF_DealAccountId(),
										breakupUpdateTag.getF_IBDEALID(), breakupUpdateTag.getBoID(),
										breakupUpdateTag.getF_IBINSTALLMENTPROFIT(), creditAcctIdProfit,
										debitAcctIdProfit, narrative,drTxnCode,crTxnCode);
								LOGGER.info("Posted the installment Profit for the dealID -->"
										+ breakupUpdateTag.getF_IBDEALID());
							}
							if (breakupUpdateTag.getF_IBRESCHEDULEPROFIT().compareTo(BigDecimal.ZERO) > 0) {
								LOGGER.info("Posting the Reschedule Profit for the dealID -->"+breakupUpdateTag.getF_IBDEALID());
								String debitAcctIdResFees = RescheduleUtils.getUnearnedAcc(dealDtls.getF_BranchSortCode(),
										dealDtls.getF_IsoCurrencyCode());
								String creditAcctIdResFees = RescheduleUtils.getRescheduleEarnedAcc(
										dealDtls.getF_BranchSortCode(), dealDtls.getF_IsoCurrencyCode());
								String narrative = breakupUpdateTag.getF_IBACCOUNTID()+"$Resch Profit for the Account Id "
										+ breakupUpdateTag.getF_IBACCOUNTID() + ", Repayment date "
										+ breakupUpdateTag.getF_IBREPAYMENTDATE();
								RescheduleUtils.callBackOfficePostingRequest(dealDtls.getF_DealAccountId(),
										breakupUpdateTag.getF_IBDEALID(), breakupUpdateTag.getBoID(),
										breakupUpdateTag.getF_IBRESCHEDULEPROFIT(), creditAcctIdResFees, debitAcctIdResFees,
										narrative,drTxnCode,crTxnCode);
								LOGGER.info("Posted the Reschedule Profit for the dealID -->"+breakupUpdateTag.getF_IBDEALID());
							}
							breakupUpdateTag.setF_IBSTATUS("PROCESSED");
							LOGGER.info(" Loan Posting Done for the Account ID : " + breakupUpdateTag.getF_IBACCOUNTID());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							LOGGER.error("Error While Posting the Profit : Exception : " + e.getMessage());
							e.printStackTrace();
							factory.rollbackTransaction();
							factory.beginTransaction();
							throw e;
						}

					}
				}
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}
		LOGGER.info("LoanPostingUpdateBatchProcess completed successfully");
		return accumulator;
	}

	/*private void updateScheduleTable(IBOCE_IB_LoanPostingBreakupUpdateTag breakupUpdateTag) {
		LOGGER.info("updating Breakup customized table : begin");
		LOGGER.info("Processing for AccountID : " + breakupUpdateTag.getF_IBACCOUNTID());
		ArrayList<Object> params = new ArrayList<>();
		params.add(breakupUpdateTag.getF_IBACCOUNTID());
		params.add(breakupUpdateTag.getF_IBREPAYMENTDATE());
		List<IBOCE_IB_LoanPostingBreakupUpdateTag> loanPostingResult = factory.findByQuery(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME,
				LOANPOSTINGDTLS_WHERECLAUSE, params, null, true);
		if (loanPostingResult != null && !loanPostingResult.isEmpty())
		{
			loanPostingResult.get(0).setF_IBSTATUS("PROCESSED");
			
		}

		
	}*/
		
}
