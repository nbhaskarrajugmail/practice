package com.ce.ib.fatoms.batch.loanPostingUpdateProcess;

import java.util.ArrayList;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class LoanPostingUpdateBatchAccumulator extends AbstractProcessAccumulator{

	private ArrayList<Object> erroneousPostings = null;
	private ArrayList<Object> sucessPostings = null;

	public LoanPostingUpdateBatchAccumulator(Object[] args) {
		super(args);
		erroneousPostings = new ArrayList<Object>();
		sucessPostings = new ArrayList<Object>();
	}

	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		

	}

	@Override
	public void acceptChanges() {
		

	}

	@SuppressWarnings("unchecked")
	public void accumulateTotals(Object[] o) {
		erroneousPostings.addAll((ArrayList) o[0]);
		sucessPostings.addAll((ArrayList) o[1]);
	}

	@Override
	public Object[] getMergedTotals() {
		Object[] o = new Object[1];
		return o;
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] o = new Object[1];
		return o;
	}

	@Override
	public void mergeAccumulatedTotals(Object[] paramArrayOfObject) {
		

	}

	@Override
	public void restoreState() {
		

	}

	@Override
	public void storeState() {
		

	}

}
