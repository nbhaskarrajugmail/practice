package com.ce.ib.fatoms.batch.repaymentreminderprocess;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RepaymentReminderTag;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.EmailAndSMSUtil;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_IDI_DealCustomerDetail;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import edu.emory.mathcs.backport.java.util.Arrays;

/**
 * 
 * @author Bhaskar N
 * @Description DealHoldBatch Process will check the deal against configured rules and markd as hold
 */
public class RepaymentReminderBatchProcess extends AbstractBatchProcess {
	private transient final static Log LOGGER = LogFactory
			.getLog(RepaymentReminderBatchProcess.class.getName());

    private AbstractProcessAccumulator accumulator;
    private RepaymentReminderBatchFatomContext context;

    private static final String PAGING_SQL = " WHERE " + IBOCE_IB_RepaymentReminderTag.IBROWSEQ + " BETWEEN ? AND ? ";
    private static final String DEAL_SQL = " WHERE "+ IBOIB_DLI_DealDetails.DealAccountId +" = ?";
    
    IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public RepaymentReminderBatchProcess(AbstractPersistableFatomContext context) {
        super(context);
        this.context = (RepaymentReminderBatchFatomContext) context;
    }

    @Override
    public AbstractProcessAccumulator getAccumulator() {
        return accumulator;
    }

    @Override
    public void init() {
        initialiseAccumulator();
    }

    @Override
    protected void initialiseAccumulator() {
        accumulator = new RepaymentReminderBatchAccumulator(new Object[0]);
    }

    @SuppressWarnings("unchecked")
    @Override
    public AbstractProcessAccumulator process(int pageToProcess) {
    	LOGGER.info("Processing RepaymentReminder Batch");
    	String subject = BankFusionPropertySupport.getPropertyBasedOnConfLocation(
    			CeConstants.REPAYMENT_REMINDER_PROPERTY_FILE, "repaymentReminderSubject", "",
    			CeConstants.ADFIBCONFIGLOCATION);
    	Integer reminderThree = (Integer) ModuleConfiguration.getInstance().getModuleConfigurationValue("CESADADINTERFACE",
				"REPAY_REMIND_3");
    	int pageSize = 0;
        int fromValue = 0;
        int toValue = 0;
        Iterator<IBOCE_IB_RepaymentReminderTag> repaymentReminderTagIterator = null;
        List repaymentReminderTagList = null;
        IBOCE_IB_RepaymentReminderTag repaymentReminderTag = null;
        pageSize = context.getPageSize();
        pagingData.setCurrentPageNumber(pageToProcess);
        fromValue = ((pageToProcess - 1) * pageSize) + 1;
        toValue = pageToProcess * pageSize;
        LOGGER.info("processing from "+fromValue +" to "+toValue);
        Date businessDate = IBCommonUtils.getBFBusinessDate();

        if (context != null) {
        	
            ArrayList<Integer> paramList = new ArrayList<Integer>();
            paramList.add(fromValue);
            paramList.add(toValue);
            repaymentReminderTagList = factory.findByQuery(IBOCE_IB_RepaymentReminderTag.BONAME, PAGING_SQL, paramList, null, false);
            if (repaymentReminderTagList != null && !repaymentReminderTagList.isEmpty()) {
            	repaymentReminderTagIterator = repaymentReminderTagList.iterator();
                while (repaymentReminderTagIterator.hasNext()) {
                	try {
                	repaymentReminderTag = repaymentReminderTagIterator.next();
                	//get the schedulerepayment and populate the params and send email
                	ArrayList params = new ArrayList();
                	params.add(repaymentReminderTag.getF_LOANACCOUNTID());
                	List<IBOIB_DLI_DealDetails> dealDetails = factory.findByQuery(IBOIB_DLI_DealDetails.BONAME, DEAL_SQL, params, null, true);
                	long diffInMillies = Math.abs(businessDate.getTime() - repaymentReminderTag.getF_REPAYMENTDT().getTime());
                    long days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
                	if(dealDetails!=null && !dealDetails.isEmpty() && (days<=1 || repaymentReminderTag.getF_DUEAMT().compareTo(BigDecimal.ZERO)>0)) {
                		String dealID = dealDetails.get(0).getBoID();
                		String customerName = EmailAndSMSUtil.getCustomerName(dealID);
                		Map<String, String> paramMap = new HashMap<String, String>();
                		paramMap.put("CustomerFullName", customerName);
                		paramMap.put("RepaymentNumber", repaymentReminderTag.getF_IBREPAYMENTNUMBER().toString());
                		paramMap.put("LoanAccountNumber", repaymentReminderTag.getF_LOANACCOUNTID().toString());
	                	paramMap.put("RepaymentAmount", repaymentReminderTag.getF_PAYMENTAMT().toString());
	                	paramMap.put("DueAmount", repaymentReminderTag.getF_DUEAMT().toString());
	                	paramMap.put("RepaymentDueDate", repaymentReminderTag.getF_REPAYMENTDT().toString());
	                	
	                	if(days == reminderThree)  {
	                		List<String> partyIds = EmailAndSMSUtil.getPartyIds(dealID);
	                		IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(dealID);
	                		partyIds.add(dealCustomerDetail.getF_CUSTOMERID());
	                		EmailAndSMSUtil.sendEmailAndSMS(dealID, "CE_IB_RepaymentNotificationEmail", "CE_IB_RepaymentNotificationSMS", subject, paramMap, partyIds);
	                	}else {
	                		 IBOIB_IDI_DealCustomerDetail dealCustomerDetail = IBCommonUtils.getDealPrimaryPartyDetails(dealID);
	                		 EmailAndSMSUtil.sendEmailAndSMS(dealID, "CE_IB_RepaymentNotificationEmail", "CE_IB_RepaymentNotificationSMS", subject, paramMap, Arrays.asList(new String[] {dealCustomerDetail.getF_CUSTOMERID()}));
	                	}
                	}
                	}catch(Exception e) {
                		LOGGER.error("Error occured in sending reminder to repayment id :"+repaymentReminderTag.getBoID());
                	}
                }
            }
        }

        return accumulator;
    }
    public static void main(String as[]) throws Exception{
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    	Date businessDate = sdf.parse("2021-11-23");
    	Calendar cal = Calendar.getInstance();
    	cal.setTime(businessDate);
    	cal.add(Calendar.DATE, -45);
    	Date reminder45 = cal.getTime();
    	System.out.println("-45:"+reminder45);
    	cal.setTime(businessDate);
    	cal.add(Calendar.DATE, -15);
    	Date reminder15 = cal.getTime();
    	System.out.println("-15:"+reminder15);
    	cal.setTime(businessDate);
    	cal.add(Calendar.DATE, -1);
    	Date reminder1 = cal.getTime();
    	System.out.println("-1:"+reminder1);
    	cal.setTime(businessDate);
    	cal.add(Calendar.DATE, 15);
    	Date reminder_15 = cal.getTime();
    	System.out.println("15:"+reminder_15);
    	long diffInMillies = Math.abs(businessDate.getTime() - reminder45.getTime());
        long days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        System.out.println(days);
        int x = -45;
        if(days == (x*-1)) {
        	System.out.println("i am true"+(days == (x*-1)));
        }
    	}
}
