package com.ce.ib.fatoms.batch.loanPostingUpdateProcess;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class LoanPostingUpdateBatchPreProcess implements IBatchPreProcess {
	
	private BankFusionEnvironment env;

    @Override
    public void init(BankFusionEnvironment env) {
        this.env = env;
    }

    @Override
    public void process(AbstractFatomContext arg0) {
    }

}



