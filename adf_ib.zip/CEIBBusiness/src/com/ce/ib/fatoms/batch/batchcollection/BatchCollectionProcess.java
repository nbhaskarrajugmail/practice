package com.ce.ib.fatoms.batch.batchcollection;

import static com.ce.adf.CEConstants.EMPTY;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchCollTag;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchTxnNationalIDMap;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.fatom.RetrieveCustomerLoans;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.financialgateway.BatchCollectionConstants;
import com.misys.bankfusion.calendar.functions.SubtractDaysFromDate;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ub.fatoms.batch.BatchUtil;
import com.misys.ub.fatoms.batch.EODConstants;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOFinancialPostingMessage;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanActivity;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CMN_BatchProcessLog;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusTxnDtls;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_FIN_AmortizationDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOpseudonyms;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.core.PostingHelper;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.fatoms.ValidateAndPostingSurplusAmt;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.services.IPersistenceService;
import com.trapedza.bankfusion.postingengine.gateway.interfaces.IPostingMessage;
import com.trapedza.bankfusion.postingengine.gateway.interfaces.IPostingRouter;
import com.trapedza.bankfusion.postingengine.router.PostingResponse;
import com.trapedza.bankfusion.postingengine.services.IPostingEngine;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.IServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;
import com.trapedza.bankfusion.servercommon.utils.FatomUtils;
import com.trapedza.bankfusion.systeminformation.PostingMessageConstants;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.CustomerDueDetail;

public class BatchCollectionProcess extends AbstractBatchProcess {

	private BatchCollectionContext batchCollectionContext;
	private IPersistenceObjectsFactory factory;
	private AbstractProcessAccumulator accumulator;
	String batchReference;
	String debitAccountID;
	String debitTxnCode;
	String creditTxnCode;
	String suspenseAccount;
	String txnType;
	String runningBalRecID;
	// String creditAccountNumber;
	String transactionID;
	int gracePeriod = Integer
			.parseInt(IBCommonUtils.getModuleConfigurationValue("CESADADINTERFACE", "SUBSIDY_GRACE_PERIOD").getValue());
	private static final String CREDIT_POSTING_ACTION = "+";

	private static final String DEBIT_POSTING_ACTION = "-";

	private static final String CLASS_NAME = BatchCollectionProcess.class.getName();
	private static final transient Log LOGGER = LogFactory.getLog(CLASS_NAME);
	private static final String WHERE_CLAUSE = " WHERE " + IBOCE_ADF_BatchCollTag.ROWSEQ + " BETWEEN ? AND ? ";
	private static final String QUERY_SUBSIDY = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? ";
	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static final String NATIONA_ID_WHERE_CLAUSE = " WHERE " + IBOCE_ADF_BatchTxnNationalIDMap.BATCHID
			+ "=? AND " + IBOCE_ADF_BatchTxnNationalIDMap.LOANACCOUNTID + "=?";
	private static final String LOAN_REPAYMENT_WHERE_CLAUSE = "WHERE " + IBOLoanRepayments.ACCOUNTID + "=? AND "
			+ IBOLoanRepayments.DUEDATE + "<=? AND " + IBOLoanRepayments.DUEDATE + ">? ORDER BY "
			+ IBOLoanRepayments.DUEDATE;
	private static final String LOAN_REPAYMENT_PAID_WHERE_CLAUSE = "WHERE " + IBOLoanRepayments.ACCOUNTID + "=? AND "
			+ IBOLoanRepayments.PAIDDATE + "=? ";
	private static final String LOAN_ACTIVITY_WHERE = "WHERE "+IBOLoanActivity.ACCOUNTID+"=? AND "+IBOLoanActivity.ACTIVITYDATE+"=? ORDER BY "+IBOLoanActivity.ACTIVITYDATE +" DESC";
	private static final String PRINCIPAL = "PRINCIPAL";
	private static final String PROFIT = "PROFIT";
	private static final String FEES = "FEES";
	private static final String SUBSIDY = "SUBSIDY";

	IServiceManager sm = ServiceManagerFactory.getInstance().getServiceManager();
	private String subsidyAccount;
	String subsidyDrTxnCode = IBCommonUtils.getModuleConfigurationValue("CESADADINTERFACE", "SADADSUBDRTXNCODE")
			.getValue();
	String subsidyCrTxnCode = IBCommonUtils.getModuleConfigurationValue("CESADADINTERFACE", "SADADSUBCRTXNCODE")
			.getValue();

	public BatchCollectionProcess(AbstractPersistableFatomContext context) {
		super(context);
		batchCollectionContext = (BatchCollectionContext) context;

	}

	public BatchCollectionProcess(BankFusionEnvironment environment, AbstractPersistableFatomContext context,
			Integer priority) {
		super(environment, context, priority);
		batchCollectionContext = (BatchCollectionContext) context;
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return accumulator;
	}

	@Override
	public void init() {
		batchCollectionContext = (BatchCollectionContext) context;
		initialiseAccumulator();

	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[1];
		accumulatorArgs[0] = Integer.valueOf(0);
		accumulator = new BatchCollectionAccumulator(accumulatorArgs);
		accumulator.accumulateTotals(accumulatorArgs);
		subsidyAccount = getSubsidyAcc();

	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		// TODO Auto-generated method stub
		LOGGER.info("BatchCollectionProcess:process-Start");
		batchCollectionContext = (BatchCollectionContext) context;
		Object[] additionalParams = batchCollectionContext.getAdditionalProcessParams();
		debitAccountID = (String) batchCollectionContext.getInputTagDataMap().get("debitAccountNumber");
		runningBalRecID = (String) batchCollectionContext.getInputTagDataMap().get("runningBalRecID");
		debitTxnCode = (String) additionalParams[0];
		creditTxnCode = (String) additionalParams[1];
		suspenseAccount = (String) additionalParams[2];
		batchReference = (String) batchCollectionContext.getInputTagDataMap().get("batchReference");
		txnType = (String) batchCollectionContext.getInputTagDataMap().get("txnType");
		// creditAccountNumber = (String)
		// batchCollectionContext.getInputTagDataMap().get("creditAccountNumber");
		transactionID = (String) batchCollectionContext.getInputTagDataMap().get("transactionID");
		pagingData.setCurrentPageNumber(pageToProcess);

		factory = BankFusionThreadLocal.getPersistanceFactory();
		if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
			int pageSize = batchCollectionContext.getPageSize();
			int fromValue = ((pageToProcess - 1) * pageSize) + 1;
			int toValue = pageToProcess * pageSize;
			ArrayList params = new ArrayList();
			params.add(fromValue);
			params.add(toValue);

			List batchCollectionList = factory.findByQuery(IBOCE_ADF_BatchCollTag.BONAME, WHERE_CLAUSE, params, null,
					false);

			if (null != batchCollectionList && batchCollectionList.size() > 0) {
				Iterator<IBOCE_ADF_BatchCollTag> batchCollectionID = batchCollectionList.iterator();
				BankFusionThreadLocal.setCurrentPageRecordIDs(batchCollectionList);

				while (batchCollectionID.hasNext()) {
					IBOCE_ADF_BatchCollTag batchCollection = batchCollectionID.next();
					IBOCE_BATCHTXNDETAIL batchTxnDetails = getBatchTxnDetails(batchCollection.getF_ID());
					try {
						doSettleTransaction(batchCollection, batchTxnDetails);
						factory.commitTransaction();
						factory.beginTransaction();
					} catch (Exception exception) {
						factory.rollbackTransaction();
						factory.beginTransaction();
						LOGGER.error("Error occured while processing the account : " + batchCollection.getBoID()
								+ "\n Error Message : " + exception.getStackTrace());

						updateFailedRecordProcessState(batchCollection.getBoID(), exception);
						factory.commitTransaction();
						factory.beginTransaction();
					}

					// raise a business event and do the financial posting
				}

			}
		} else {
		}
		LOGGER.info("BatchCollectionProcess:process-End");
		return accumulator;
	}

	private IBOCE_BATCHTXNDETAIL getBatchTxnDetails(String f_ID) {
		IBOCE_BATCHTXNDETAIL batchtxndetail = (IBOCE_BATCHTXNDETAIL) factory
				.findByPrimaryKey(IBOCE_BATCHTXNDETAIL.BONAME, f_ID, true);
		return batchtxndetail;
	}

	private void doSettleTransaction(IBOCE_ADF_BatchCollTag batchCollTag, IBOCE_BATCHTXNDETAIL batchTxnDetails) {

		String creditAccountID = CommonConstants.EMPTY_STRING;
		String nationalID = CommonConstants.EMPTY_STRING;
		boolean isLoanAccount = false;
		if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
			if (!StringUtils.isEmpty(batchTxnDetails.getF_CREDITACC())) {
				creditAccountID = batchTxnDetails.getF_CREDITACC();
				isLoanAccount = true;
			} else if (!StringUtils.isEmpty(batchTxnDetails.getF_INTERNALACC())) {
				creditAccountID = batchTxnDetails.getF_INTERNALACC();
			} else if (!StringUtils.isEmpty(batchTxnDetails.getF_NATIONALID())) {
				isLoanAccount = true;
				// addAccountsForNationalId(batchTxnDetails, postingMessages, now);
				nationalID = batchTxnDetails.getF_NATIONALID();
			}
		}
		if (!StringUtils.isEmpty(creditAccountID)) {
			String newTransactionID = CommonConstants.EMPTY_STRING;
			if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
				newTransactionID = GUIDGen.getNewGUID();
			} else {
				newTransactionID = transactionID;
			}
			boolean status = prepareAndPostTxn(creditAccountID, newTransactionID, batchTxnDetails.getF_AMOUNT(),
					batchTxnDetails.getF_NARRATIVE(), creditAccountID + "$", batchTxnDetails.getF_VALUEDATE(),
					isLoanAccount);
			if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT) && status) {
				IBOCE_BATCHTXNDETAIL batchtxndetail = getBatchTxnDetails(runningBalRecID);
				if (batchtxndetail != null) {
					BigDecimal amount = batchtxndetail.getF_BATCHRUNNINGAMNT().add(batchTxnDetails.getF_AMOUNT());
					batchtxndetail.setF_BATCHRUNNINGAMNT(amount);
				}
				batchTxnDetails.setF_HOSTTXNREF(transactionID);
				batchTxnDetails.setF_STATUS("PROCESSED");
			}
		}
		if (!StringUtils.isEmpty(nationalID)) {
			RetrieveCustomerLoans customerLoans = new RetrieveCustomerLoans();
			customerLoans.setF_IN_batchID(batchCollTag.getF_ID());
			customerLoans.setF_IN_nationalID(nationalID);
			customerLoans.process(getEnvironment());
			List<Boolean> processedStatus = new ArrayList<>();
			for (CustomerDueDetail customerDueDetail : customerLoans.getF_OUT_customerDueDetailsList()
					.getCustomerDueDetails()) {
				if (customerDueDetail.getDueAmountPaid().getCurrencyAmount()
						.compareTo(BigDecimal.ZERO) > CommonConstants.INTEGER_ZERO && customerDueDetail.isProcess()) {
					String transactionID = GUIDGen.getNewGUID();
					boolean status = prepareAndPostTxn(customerDueDetail.getDealAccountID(), transactionID,
							customerDueDetail.getDueAmountPaid().getCurrencyAmount(), batchTxnDetails.getF_NARRATIVE(),
							customerDueDetail.getDealAccountID() + "$", batchTxnDetails.getF_VALUEDATE(),
							isLoanAccount);
					ArrayList params = new ArrayList<>();
					params.add(customerDueDetail.getBatchID());
					params.add(customerDueDetail.getDealAccountID());
					List<IBOCE_ADF_BatchTxnNationalIDMap> batchTxnNationalIDMaps = factory.findByQuery(
							IBOCE_ADF_BatchTxnNationalIDMap.BONAME, NATIONA_ID_WHERE_CLAUSE, params, null, true);
					if (status) {
						IBOCE_BATCHTXNDETAIL batchtxndetail = getBatchTxnDetails(runningBalRecID);
						if (batchtxndetail != null) {
							BigDecimal amount = batchtxndetail.getF_BATCHRUNNINGAMNT()
									.add(batchTxnDetails.getF_AMOUNT());
							batchtxndetail.setF_BATCHRUNNINGAMNT(amount);
						}
						if (batchTxnNationalIDMaps != null) {
							batchTxnNationalIDMaps.get(0).setF_TRANSACTIONID(transactionID);
						} else {
							createBatchTxnNationalIDMap(customerDueDetail, customerDueDetail.getBatchID(),
									transactionID);
						}
					}
					processedStatus.add(status);
				}
			}
			boolean isAnyRecordFailed = false;
			for (Boolean status : processedStatus) {
				if (!status) {
					isAnyRecordFailed = true;
					break;
				}
			}
			if (txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
				if (isAnyRecordFailed)
					batchTxnDetails.setF_STATUS("PARTPROCESSED");
				else
					batchTxnDetails.setF_STATUS("PROCESSED");
			}
		}

	}

	private void createBatchTxnNationalIDMap(CustomerDueDetail customerDueDetails, String recId, String transactionID) {

		IBOCE_ADF_BatchTxnNationalIDMap createObj = (IBOCE_ADF_BatchTxnNationalIDMap) BankFusionThreadLocal
				.getPersistanceFactory().getStatelessNewInstance(IBOCE_ADF_BatchTxnNationalIDMap.BONAME);
		createObj.setF_BATCHID(recId);
		createObj.setF_DUEAMOUNT(customerDueDetails.getDueAmount().getCurrencyAmount());
		createObj.setF_DUEAMOUNTPAID(customerDueDetails.getDueAmountPaid().getCurrencyAmount());
		createObj.setF_DUEDATE(customerDueDetails.getDueDate());
		createObj.setF_LOANACCOUNTID(customerDueDetails.getDealAccountID());
		createObj.setF_PROCESS(customerDueDetails.getProcess());
		createObj.setF_ROLE(customerDueDetails.getUserRole());
		createObj.setF_TRANSACTIONID(transactionID);
		BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, createObj);

	}

	private boolean prepareAndPostTxn(String creditAccountID, String transactionID, BigDecimal amount, String narrative,
			String narrativePrefix, Date transactionDate, boolean isLoanAccount) {
		boolean status = true;
		try {
			if (!isLoanAccount) {
				if(creditAccountID.equals(debitAccountID))
					return status;
				
				IBOAttributeCollectionFeature creditAccountDetails = FinderMethods.getAccountBO(creditAccountID);
				IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(debitAccountID);
				IPostingMessage debitPostingMessage = getFinPostingMessage(debitAccountDetails, debitAccountID, amount,
						debitTxnCode, DEBIT_POSTING_ACTION, transactionID, narrative, narrativePrefix, batchReference,
						transactionDate);

				IPostingMessage creditPostingMessage = getFinPostingMessage(creditAccountDetails, creditAccountID,
						amount, creditTxnCode, CREDIT_POSTING_ACTION, transactionID, narrative, narrativePrefix,
						batchReference, transactionDate);
				ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
				postingMessageList.add(debitPostingMessage);
				postingMessageList.add(creditPostingMessage);
				postTransaction(postingMessageList);
			}
			if (isLoanAccount) {
				String loanreference = CommonConstants.EMPTY_STRING;
				ArrayList params = new ArrayList();
				params.add(creditAccountID);
				ArrayList<IBOLendingFeature> loanDetails = (ArrayList<IBOLendingFeature>) factory
						.findByQuery(IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, null, true);
				if (null != loanDetails && !loanDetails.isEmpty()) {
					loanreference = loanDetails.get(0).getF_LOANREFERENCE();
				}

				
				params.clear();
				params = new ArrayList<>();
				Date fromDate = transactionDate;
				Date toDate = SubtractDaysFromDate.run(transactionDate, gracePeriod);
				params.add(creditAccountID);
				params.add(fromDate);
				params.add(toDate);
				List<IBOLoanRepayments> loanRepayments = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery(IBOLoanRepayments.BONAME, LOAN_REPAYMENT_WHERE_CLAUSE, params, null, true);
				Date dueDate = new Date();
				if (loanRepayments != null && !loanRepayments.isEmpty()) {
					dueDate = loanRepayments.get(0).getF_DUEDATE();
					loanRepayments.get(0).setF_PAIDDATE(new java.sql.Date(transactionDate.getTime()));
				}
				Map<String, BigDecimal> breakupAmounts = getBreakupAmount(loanreference, dueDate);

				processLoanPostings(creditAccountID, amount, transactionDate, narrative, narrativePrefix,
						breakupAmounts.get(SUBSIDY),dueDate,transactionID);

				updateBreakupAmounts(getSchBreakUp(loanreference, dueDate));
				updateLoanRepaymentAndActivity(creditAccountID,transactionDate);
				
			}
		} catch (Exception exception) {
			BankFusionThreadLocal.getPersistanceFactory().rollbackTransaction();
			BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
			LOGGER.error("Error occured while processing the account : " + creditAccountID + "\n Error Message : "
					+ BatchUtil.getExceptionAsString(exception));

			updateFailedRecordProcessState(creditAccountID, exception);
			status = false;
		}
		return status;
	}

	private void updateLoanRepaymentAndActivity(String creditAccountID, Date transactionDate) {
		ArrayList params = new ArrayList<>();
		params.add(creditAccountID);
		params.add(SystemInformationManager.getInstance().getBFBusinessDate());
		List<IBOLoanActivity> loanActivity = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLoanActivity.BONAME, LOAN_ACTIVITY_WHERE, params, null, true);
		if (loanActivity != null && !loanActivity.isEmpty()) {
			for (IBOLoanActivity iboLoanActivity : loanActivity) {
				iboLoanActivity.setF_ACTIVITYDATE(new java.sql.Date(transactionDate.getTime()));
			}
		}
		List<IBOLoanRepayments> loanRepayments = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLoanRepayments.BONAME, LOAN_REPAYMENT_PAID_WHERE_CLAUSE, params, null, true);
		if(loanRepayments!=null && !loanRepayments.isEmpty()) {
			for (IBOLoanRepayments iboLoanRepayments : loanRepayments) {
				iboLoanRepayments.setF_PAIDDATE(new java.sql.Date(transactionDate.getTime()));
			}
		}
		
	}

	private void processSubsidy(String loanAccountID, Date transactionDate, BigDecimal subsidyAmt) {
		try {
			if (subsidyAmt.compareTo(BigDecimal.ZERO) > 0) {
				ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
				LOGGER.info("Subsidy Amount:" + subsidyAmt);
				// String subsidyAcc = getSubsidyAcc();
				String transactionID = GUIDGen.getNewGUID();
				IBOAttributeCollectionFeature creditAccountDetails = FinderMethods.getAccountBO(loanAccountID);
				IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(subsidyAccount);
				IPostingMessage debitPostingMessage = getFinPostingMessage(debitAccountDetails, subsidyAccount,
						subsidyAmt, subsidyDrTxnCode, DEBIT_POSTING_ACTION, transactionID, "Subsidy Collection",loanAccountID, batchReference,
						transactionDate);

				IPostingMessage creditPostingMessage = getFinPostingMessage(creditAccountDetails, loanAccountID,
						subsidyAmt, subsidyCrTxnCode, CREDIT_POSTING_ACTION, transactionID, "Subsidy Collection",loanAccountID, batchReference,
						transactionDate);

				postingMessageList.add(debitPostingMessage);
				postingMessageList.add(creditPostingMessage);
				postTransaction(postingMessageList);
			}
		} catch (Exception e) {
			LOGGER.error("Error occured while processing the Subsidy posting for account : " + loanAccountID
					+ "\n Error Message : " + BatchUtil.getExceptionAsString(e));
		}
	}

	/**
	 * Updates the failed record status
	 * 
	 * @param accountId
	 * @param ex
	 */
	private void updateFailedRecordProcessState(String accountId, Exception ex) {
		IPersistenceObjectsFactory privateFactory = null;
		try {
			IPersistenceService pService = (IPersistenceService) ServiceManagerFactory.getInstance().getServiceManager()
					.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
			privateFactory = pService.getPrivatePersistenceFactory(false);
			privateFactory.beginTransaction();
			createLogMessage(accountId, ex.getLocalizedMessage(), EODConstants.STATUS_ERROR, privateFactory);
			privateFactory.commitTransaction();
		} catch (Exception e) {
			if (privateFactory != null) {
				privateFactory.rollbackTransaction();
			}
			LOGGER.error("Error occured while updating the unprocessed record for Credit Interest Application of : "
					+ accountId + "\nError message : " + BatchUtil.getExceptionAsString(e));
		} finally {
			if (privateFactory != null)
				privateFactory.closePrivateSession();
		}
	}

	/**
	 * This method is used to create log error message
	 * 
	 * @param key
	 * @param message
	 * @param status
	 */
	private void createLogMessage(String key, String message, String status, IPersistenceObjectsFactory factory) {

		IBOUB_CMN_BatchProcessLog batchException = (IBOUB_CMN_BatchProcessLog) factory
				.getStatelessNewInstance(IBOUB_CMN_BatchProcessLog.BONAME);
		batchException.setBoID(GUIDGen.getNewGUID());
		batchException.setF_PROCESSNAME(batchReference);
		batchException.setF_RUNDATETIME(SystemInformationManager.getInstance()
				.getBFBusinessDateTime(BankFusionThreadLocal.getBankFusionEnvironment().getRuntimeMicroflowID()));
		batchException.setF_RECORDID(key);

		if (status.equalsIgnoreCase(EODConstants.STATUS_ERROR)
				|| status.equalsIgnoreCase(EODConstants.STATUS_WARNING)) {
			if (LOGGER.isErrorEnabled()) {
				LOGGER.error("Error processing for Account [ " + key + " ] Reason :- " + message);
			}
			if (null == message) {
				message = CommonConstants.EMPTY_STRING;
			}
			message = message.replaceAll(",", "");
			message = message.replaceAll(":", "");
			message = message.replaceAll("':", "");

			batchException.setF_ERRORMESSAGE(message);
			batchException.setF_STATUS(status);
		} else {
			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("Unprocessed Account [ " + key + " ] ");
			}
			batchException.setF_STATUS(status);
		}
		factory.create(IBOUB_CMN_BatchProcessLog.BONAME, batchException);

	}

	public static IBOFinancialPostingMessage getFinPostingMessage(IBOAttributeCollectionFeature attrColFtr,
			String account, BigDecimal txnAmount, String transactionCode, String postingAction, String transactionID,
			String narrative, String narrativePrefix, String batchReference, Date transactionDate) {

		IBOFinancialPostingMessage finPostingMessage = (IBOFinancialPostingMessage) BankFusionThreadLocal
				.getPersistanceFactory().getStatelessNewInstance(IBOFinancialPostingMessage.BONAME);
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
		FatomUtils.createStandardItemsMessage(finPostingMessage, env);
		PostingHelper.setDefaultValuesForFinPosting(finPostingMessage, env);

		finPostingMessage.setTransactionRef(batchReference);
		finPostingMessage.setMessageType(PostingMessageConstants.FINANCIAL_POSTING_MESSAGE);
		finPostingMessage.setMessageID(GUIDGen.getNewGUID());
		finPostingMessage.setInitiatedByuserID(BankFusionThreadLocal.getUserId());
		finPostingMessage.setAuthenticatingUserID(BankFusionThreadLocal.getUserId());
		finPostingMessage.setAcctCurrencyCode(attrColFtr.getF_ISOCURRENCYCODE());
		finPostingMessage.setBranchID(attrColFtr.getF_BRANCHSORTCODE());
		finPostingMessage.setPrimaryID(account);
		finPostingMessage.setProductID(attrColFtr.getF_PRODUCTID());
		finPostingMessage.setValueDate(transactionDate);
		finPostingMessage.setF_USERTYPE(env.getUserType());
		finPostingMessage.setTransactionID(transactionID);
		finPostingMessage.setPERouterProfileID(attrColFtr.getF_PEROUTERPROFILEID());
		finPostingMessage.setTransCode(transactionCode);

		finPostingMessage.setF_AMOUNT(txnAmount.abs());
		finPostingMessage.setF_ACTUALAMOUNT(txnAmount.abs());
		finPostingMessage.setNarrative(narrative);
		finPostingMessage.setF_SIGN(postingAction);

		finPostingMessage.setF_TXNCURRENCYCODE(attrColFtr.getF_ISOCURRENCYCODE());
		finPostingMessage.setF_FORWARDVALUED(false);

		finPostingMessage.setRunTimeBPID(BankFusionThreadLocal.getBankFusionEnvironment().getRuntimeMicroflowID());
		finPostingMessage.setTransactionDate(transactionDate);
		finPostingMessage.setNarrative(
				narrativePrefix + PostingHelper.getBuildedNarrative(finPostingMessage, CommonConstants.EMPTY_STRING));

		return finPostingMessage;
	}

	public static void postTransaction(ArrayList<IPostingMessage> postingMessageList) {
		if (postingMessageList != null && !postingMessageList.isEmpty()) {
			IPostingEngine postingEngine = (IPostingEngine) ServiceManager
					.getService(ServiceManager.POSTING_ENGINE_SERVICE);
			IPostingRouter postingRouter = (IPostingRouter) postingEngine.getNewInstance();

			ArrayList postResult = postingRouter.post(postingMessageList,
					BankFusionThreadLocal.getBankFusionEnvironment());
			postingEngine.postingComplete();
			PostingResponse postingResponse = null;

			for (int counter = 0; counter < postResult.size(); counter++) {
				postingResponse = (PostingResponse) postResult.get(counter);

				if (postingResponse.getStatus() != 0) {
					throw new BankFusionException(postingResponse.getErrorNumber(), postingResponse.getErrMessage());
				}
			}
		}
	}

	private List<IBOCE_IB_PaymentSchBreakup> getSchBreakUp(String loanRef, Date duedate) {
		ArrayList<Object> params = new ArrayList<Object>();
		List<IBOCE_IB_PaymentSchBreakup> schBreakupList = null;

		params.clear();
		params.add(loanRef);
		params.add(duedate);
		String schBreakUpSQL = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
				+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
		schBreakupList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME,
				schBreakUpSQL, params, null, true);

		return schBreakupList;
	}

	private String getSubsidyAcc() {
		String subsidyAcc = "";
		CEUtil ceUtil = new CEUtil();
		String subsidyAccPseudonym = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SUBSIDYACC");
		IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOpseudonyms.BONAME, subsidyAccPseudonym, true);
		String contextValue = "SAR";
		if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
			contextValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
		}
		@SuppressWarnings("rawtypes")
		List finderResult = FinderMethods.findAccountByPseudoname(subsidyAccPseudonym, "SAR",
				pseudDtls.getF_FINDERALTERNATIVE1(), contextValue, BankFusionThreadLocal.getBankFusionEnvironment(),
				null);
		if (finderResult != null && !finderResult.isEmpty()) {
			subsidyAcc = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
		}
		return subsidyAcc;
	}

	private void updateBreakupAmounts(List<IBOCE_IB_PaymentSchBreakup> schBreakupList) {
		for (IBOCE_IB_PaymentSchBreakup schBreakup : schBreakupList) {
			schBreakup.setF_IBSUBSIDYAMTPAID(schBreakup.getF_IBSUBSIDYAMNT());
		}
	}

	private Map<String, BigDecimal> getBreakupAmount(String loanReference, Date dueDate) {
		LOGGER.info("Inside getSubsidyAmount:" + IBOCE_IB_PaymentSchBreakup.BONAME);
		Map<String, BigDecimal> breakupAmount = new HashMap<>();
		BigDecimal principalAmount = BigDecimal.ZERO;
		BigDecimal profitAmount = BigDecimal.ZERO;
		BigDecimal feesAmount = BigDecimal.ZERO;
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList();
		params.add(loanReference);
		params.add(dueDate);
		List<IBOCE_IB_PaymentSchBreakup> payBreakUps = (List<IBOCE_IB_PaymentSchBreakup>) factory
				.findByQuery("CE_IB_PaymentSchBreakup", QUERY_SUBSIDY, params, null, false);
		if (null != payBreakUps && !payBreakUps.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup payBreakup : payBreakUps) {
				principalAmount = principalAmount.add(payBreakup.getF_IBPRINCIPALAMT())
						.subtract(payBreakup.getF_IBPRINCIPALAMTPAID());
				profitAmount = profitAmount.add(payBreakup.getF_IBPROFITAMT())
						.subtract(payBreakup.getF_IBPROFITAMTPAID());
				feesAmount = feesAmount.add(payBreakup.getF_IBSCHEDULEFEEAMT())
						.subtract(payBreakup.getF_IBSCHEDULEFEESAMTPAID());
				subsidyAmount = subsidyAmount.add(payBreakup.getF_IBSUBSIDYAMNT())
						.subtract(payBreakup.getF_IBSUBSIDYAMTPAID());
			}
		}
		breakupAmount.put(PRINCIPAL, principalAmount);
		breakupAmount.put(PROFIT, profitAmount);
		breakupAmount.put(FEES, feesAmount);
		breakupAmount.put(SUBSIDY, subsidyAmount);
		return breakupAmount;
	}

	private static String loanRepayments_whereClause = "WHERE " + IBOLoanRepayments.PAIDDATE + " =? and "
			+ IBOLoanRepayments.ACCOUNTID + "= ?";

	public void processLoanPostings(String loanAccount, BigDecimal txnAmount, Date txnDate, String narrative,
			String narrativePrefix, BigDecimal subsidyAmount, Date dueDate, String transactionID) throws Exception {

		String loanAcc = loanAccount;
		String loanReference = EMPTY;
		String collectionOrderProfile = EMPTY;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAccount);
		List lenFtrResult = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME,
				" WHERE " + IBOLendingFeature.ACCOUNTID + " = ?", params, null, true);
		if (lenFtrResult != null && !lenFtrResult.isEmpty()) {
			loanReference = ((IBOLendingFeature) lenFtrResult.get(0)).getF_LOANREFERENCE();
			collectionOrderProfile = ((IBOLendingFeature) lenFtrResult.get(0)).getF_COLLECTIONORDER();

		}
		BigDecimal excessPaymentAmount = BigDecimal.ZERO;
		ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
		ArrayList<Object> inputParams = new ArrayList<Object>();
		inputParams.add(loanReference);
		String whereAllRecords = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereAllRecords, inputParams, null, true);
		BigDecimal totalAmount = BigDecimal.ZERO;
		BigDecimal totalPaidAmount = BigDecimal.ZERO;
		if (ibPaymentSchResult != null) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
				totalAmount = totalAmount.add(paymentSchBreakup.getF_IBPRINCIPALAMT()
						.add(paymentSchBreakup.getF_IBPROFITAMT()).add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
				totalPaidAmount = totalPaidAmount
						.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID().add(paymentSchBreakup.getF_IBPROFITAMTPAID())
								.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()));
			}
			BigDecimal totalUnPaidAmount = totalAmount.subtract(totalPaidAmount);
			excessPaymentAmount = txnAmount.subtract(totalUnPaidAmount);
			if (excessPaymentAmount.compareTo(BigDecimal.ZERO) > 0)
				txnAmount = totalUnPaidAmount;
		}
		LOGGER.info("updateSadadRqExcludingExcessAmount excessPaymentAmount : " + excessPaymentAmount);

		try {
			populateAndCallBackOfficeRequest(postingMessageList, loanAcc, txnAmount, txnDate, narrative,
					narrativePrefix,subsidyAmount,transactionID);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw e;
		}
		BigDecimal scheduleFeeAmtPaid = updateScheduleTable(loanAccount, loanReference, txnAmount, dueDate,
				collectionOrderProfile);

		if (scheduleFeeAmtPaid.compareTo(BigDecimal.ZERO) > 0) {
			BigDecimal totalSadadPaymentAmt = txnAmount;
			callRescheduleProfitBackOfficeRequest(loanAcc, scheduleFeeAmtPaid, txnDate, batchReference);
			txnAmount = totalSadadPaymentAmt;
		}

		if (excessPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
			// TODO Extra amount Posting
			IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
					.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);

			IServiceManager servicemanager = ServiceManagerFactory.getInstance().getServiceManager();
			IPersistenceService persistenceService = (IPersistenceService) servicemanager
					.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
			IPersistenceObjectsFactory factory = persistenceService.getPrivatePersistenceFactory(true);
			factory.beginTransaction();
			CEUtil ceUtilss = new CEUtil();
			String dTxnCode = ceUtilss.getModuleConfigurationValue("LENDING", "2149_DR");
			String cTxnCode = ceUtilss.getModuleConfigurationValue("LENDING", "2149_CR");

			if (!CeUtils.getSurplusAccount(loanAcc).isEmpty()) {
				RescheduleUtils.callBackOfficePostingRequest(loanAcc, loanReference, batchReference,
						excessPaymentAmount, CeUtils.getSurplusAccount(loanAcc), debitAccountID,
						loanAcc + "$" + "Loan Excess Amount Posting", dTxnCode, cTxnCode);
			} else {
				ValidateAndPostingSurplusAmt validateAndPostingSurplusAmt = new ValidateAndPostingSurplusAmt(
						BankFusionThreadLocal.getBankFusionEnvironment());

				String surplusAccount = validateAndPostingSurplusAmt.getSurplusAccount(
						loanAccDtl.getF_ISOCURRENCYCODE(), loanAccDtl.getF_BRANCHSORTCODE(),
						loanAccDtl.getF_CUSTOMERCODE());

				IBOUB_CNF_SurplusAccountDetails surplusAccountDetails = (IBOUB_CNF_SurplusAccountDetails) factory
						.getStatelessNewInstance(IBOUB_CNF_SurplusAccountDetails.BONAME);
				surplusAccountDetails.setBoID(loanAcc);
				surplusAccountDetails.setF_UBSURPLUSACCOUNT(surplusAccount);
				factory.create(IBOUB_CNF_SurplusAccountDetails.BONAME, surplusAccountDetails);

				RescheduleUtils.callBackOfficePostingRequest(loanAcc, loanReference, batchReference,
						excessPaymentAmount, surplusAccount, debitAccountID,
						loanAcc + "$" + "Sadad Excess Amount Posting", dTxnCode, cTxnCode);
			}

			IBOUB_CNF_SurplusTxnDtls surplusTxnDtls = (IBOUB_CNF_SurplusTxnDtls) factory
					.getStatelessNewInstance(IBOUB_CNF_SurplusTxnDtls.BONAME);

			surplusTxnDtls.setBoID(GUIDGen.getNewGUID());
			surplusTxnDtls.setF_ISOCURRENCYCODE(loanAccDtl.getF_ISOCURRENCYCODE());
			surplusTxnDtls.setF_PAYMENTACCOUNT(debitAccountID);
			surplusTxnDtls.setF_SURPLUSAMOUNT(excessPaymentAmount);
			surplusTxnDtls.setF_UBACCOUNTID(loanAcc);
			surplusTxnDtls.setF_PAYMENTMODE("CASH");
			surplusTxnDtls.setF_TRANSACTIONDATE(SystemInformationManager.getInstance().getBFBusinessDate());

			factory.create(IBOUB_CNF_SurplusTxnDtls.BONAME, surplusTxnDtls);
			factory.commitTransaction();
			factory.beginTransaction();
		}

		LOGGER.info("Transaction successful : ");
	}

	private BigDecimal updateScheduleTable(String loanAccount, String loanRef, BigDecimal txnAmount, Date dueDate,
			String collectionOrderProfile) {
		LOGGER.info("updating Breakup customized table : begin");
		BigDecimal scheduleFeeAmtPaid = BigDecimal.ZERO;
		BigDecimal hundred = new BigDecimal(100);
		ArrayList<Object> params = new ArrayList<Object>();

		LOGGER.info("Loan Reference: " + loanRef);

		params.clear();
		params.add(SystemInformationManager.getInstance().getBFBusinessDate());
		params.add(loanAccount);
		List<IBOLoanRepayments> loanRepaymentDtls = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLoanRepayments.BONAME, loanRepayments_whereClause, params, null, true);
		if (loanRepaymentDtls != null && !loanRepaymentDtls.isEmpty()) {
			BigDecimal prevReschProfitPaidAmount = getPaidRescheduleProfit(loanRef);
			for (IBOLoanRepayments loanRepaymentDtl : loanRepaymentDtls) {
				params.clear();
				params.add(loanRef);
				params.add(loanRepaymentDtl.getF_DUEDATE());
				String where = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
						+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
				List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery("CE_IB_PaymentSchBreakup", where, params, null, true);
				if (ibPaymentSchResult != null && !ibPaymentSchResult.isEmpty()) {
					if (loanRepaymentDtl.getF_REPAYMENTUNPAID().compareTo(BigDecimal.ZERO) == 0) {
						// repayment is fully paid
						LOGGER.info("Repayment is fully paid for loan reference: " + loanRef);
						for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
							paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
							paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
							paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						}
					} else {
						// fetching total repayment principal, profit and fees for the billDate
						BigDecimal totalRepaymentPrincipal = BigDecimal.ZERO;
						BigDecimal totalRepaymentProfit = BigDecimal.ZERO;
						// BigDecimal totalRepaymentFees = BigDecimal.ZERO;
						for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
							totalRepaymentPrincipal = totalRepaymentPrincipal
									.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
							totalRepaymentProfit = totalRepaymentProfit.add(paymentSchBreakup.getF_IBPROFITAMT())
									.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						}

						// fetching the percentages for Principal, Profit, Fees at Asset level
						HashMap<String, BigDecimal> assetIdWithPrincipalPercentage = new HashMap<>();
						HashMap<String, BigDecimal> assetIdWithProfitPercentage = new HashMap<>();
						BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
						BigDecimal assetProfitPercentage = BigDecimal.ZERO;
						BigDecimal remAssetPrincipalPercentage = new BigDecimal(100);
						BigDecimal remAssetProfitPercentage = new BigDecimal(100);
						BigDecimal assetProfitAmount = BigDecimal.ZERO;
						int i = 1;
						for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
							assetProfitAmount = paymentSchBreakup.getF_IBPROFITAMT()
									.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
							if (i == ibPaymentSchResult.size()) {
								assetPrincipalPercentage = remAssetPrincipalPercentage;
								assetProfitPercentage = remAssetProfitPercentage;
							} else {
								if (totalRepaymentPrincipal.compareTo(BigDecimal.ZERO) > 0) {
									assetPrincipalPercentage = (paymentSchBreakup.getF_IBPRINCIPALAMT()
											.multiply(hundred)).divide(totalRepaymentPrincipal, 0, RoundingMode.UP);
								}
								if (totalRepaymentProfit.compareTo(BigDecimal.ZERO) > 0) {
									assetProfitPercentage = (assetProfitAmount.multiply(hundred))
											.divide(totalRepaymentProfit, 0, RoundingMode.UP);
								}
							}
							assetIdWithPrincipalPercentage.put(paymentSchBreakup.getF_IBASSETID(),
									assetPrincipalPercentage);
							assetIdWithProfitPercentage.put(paymentSchBreakup.getF_IBASSETID(), assetProfitPercentage);
							remAssetPrincipalPercentage = remAssetPrincipalPercentage
									.subtract(assetPrincipalPercentage);
							remAssetProfitPercentage = remAssetProfitPercentage.subtract(assetProfitPercentage);
							++i;
						}

						// updating breakup table
						updatePaymentBreakupTable(loanRepaymentDtl.getF_PRINCIPALPAID(),
								loanRepaymentDtl.getF_INTERESTPAID(), hundred, collectionOrderProfile,
								ibPaymentSchResult, assetIdWithPrincipalPercentage, assetIdWithProfitPercentage);
					}
				}
			}
			BigDecimal updatedReschProfitPaidAmount = getPaidRescheduleProfit(loanRef);
			scheduleFeeAmtPaid = updatedReschProfitPaidAmount.subtract(prevReschProfitPaidAmount);
		}

		LOGGER.info("updating Breakup customized table : end");
		return scheduleFeeAmtPaid;
	}

	@SuppressWarnings("unchecked")
	private BigDecimal getPaidRescheduleProfit(String loanRef) {
		ArrayList<Object> inputParams = new ArrayList<Object>();
		inputParams.add(loanRef);
		String whereAllRecords = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereAllRecords, inputParams, null, true);
		BigDecimal paidScheduledFeeAmt = BigDecimal.ZERO;
		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			paidScheduledFeeAmt = paidScheduledFeeAmt.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
		}
		return paidScheduledFeeAmt;
	}

	@SuppressWarnings("rawtypes")
	private void updatePaymentBreakupTable(BigDecimal principalPaid, BigDecimal profitPaid, BigDecimal hundred,
			String collectionOrderProfile, List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult,
			HashMap<String, BigDecimal> assetIdWithPrincipalPercentage,
			HashMap<String, BigDecimal> assetIdWithProfitPercentage) {

		BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
		BigDecimal assetProfitPercentage = BigDecimal.ZERO;
		BigDecimal remPrincipalPaid = principalPaid;
		BigDecimal remProfitPaid = profitPaid;
		BigDecimal assetPrincipalPaidAmount = BigDecimal.ZERO;
		BigDecimal assetProfitAndFeesPaidAmount = BigDecimal.ZERO;
		int j = 1;
		boolean isAssetProfitAndFeesFullyPaid = false;
		boolean isAssetPrincipalFullyPaid = false;

		LOGGER.info("Updating breakup table for BillDate : " + ibPaymentSchResult.get(0).getF_IBBILLDATE());
		LOGGER.info("Collection order profile : " + collectionOrderProfile);
		LOGGER.info("Principal Paid : " + principalPaid);
		LOGGER.info("Profit Paid : " + profitPaid);

		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			isAssetProfitAndFeesFullyPaid = false;
			isAssetPrincipalFullyPaid = false;
			assetPrincipalPercentage = assetIdWithPrincipalPercentage.get(paymentSchBreakup.getF_IBASSETID());
			assetProfitPercentage = assetIdWithProfitPercentage.get(paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Principal Percentage / AssetId : " + assetPrincipalPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());
			LOGGER.info("Profit Percentage / AssetId : " + assetProfitPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());

			if (j == ibPaymentSchResult.size()) {
				assetProfitAndFeesPaidAmount = remProfitPaid;
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				assetPrincipalPaidAmount = remPrincipalPaid;
			} else {
				assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetPrincipalPaidAmount.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMT()) >= 0) {
					assetPrincipalPaidAmount = paymentSchBreakup.getF_IBPRINCIPALAMT();
					isAssetPrincipalFullyPaid = true;
					LOGGER.info("Principal Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID() + " is "
							+ isAssetPrincipalFullyPaid);
				}
				assetProfitAndFeesPaidAmount = (profitPaid.multiply(assetProfitPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					LOGGER.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				remPrincipalPaid = remPrincipalPaid.subtract(assetPrincipalPaidAmount);
				remProfitPaid = remProfitPaid.subtract(assetProfitAndFeesPaidAmount);
			}

			if (isAssetPrincipalFullyPaid) {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
			} else {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(assetPrincipalPaidAmount);
			}
			if (isAssetProfitAndFeesFullyPaid) {
				paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
			} else {
				if (collectionOrderProfile.indexOf('I') > collectionOrderProfile.indexOf('F')) {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) > 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBPROFITAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) == 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
					} else {
						paymentSchBreakup.setF_IBPROFITAMTPAID(assetProfitAndFeesPaidAmount);
					}
				} else {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) > 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						paymentSchBreakup.setF_IBPROFITAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) == 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					} else {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(assetProfitAndFeesPaidAmount);
					}
				}
			}
			++j;
		}
	}

	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	private void populateAndCallBackOfficeRequest(ArrayList<IPostingMessage> postingMessageList, String creditAccountID,
			BigDecimal txnAmount, Date txnDate, String narrative, String narrativePrefix,BigDecimal subsidyAmt, String transactionID) throws Exception {
		IBOAttributeCollectionFeature creditAccountDetails = FinderMethods.getAccountBO(creditAccountID);
		IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(debitAccountID);
		IPostingMessage debitPostingMessage = getFinPostingMessage(debitAccountDetails, debitAccountID, txnAmount,
				debitTxnCode, DEBIT_POSTING_ACTION, transactionID, narrative, narrativePrefix, batchReference, txnDate);

		IPostingMessage creditPostingMessage = getFinPostingMessage(creditAccountDetails, creditAccountID, txnAmount,
				creditTxnCode, CREDIT_POSTING_ACTION, transactionID, narrative, narrativePrefix, batchReference,
				txnDate);
		postingMessageList.add(debitPostingMessage);
		postingMessageList.add(creditPostingMessage);
		postTransaction(postingMessageList);
		processSubsidy(creditAccountID, txnDate, subsidyAmt);
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Object callRescheduleProfitBackOfficeRequest(String loanAccID, BigDecimal txnAmount, Date txnDate,
			String batchReference) {
		// BackOfficeAccountPostingRq request = getF_IN_backOfficeRequest();

		CEUtil ceUtil = new CEUtil();
		String earnedAccount = null;
		String loanAcc = loanAccID;
		LOGGER.info("loanAcc: " + loanAcc);
		ArrayList<String> params = new ArrayList<String>();
		String whereClause = "WHERE " + IBOUB_FIN_AmortizationDetails.ACCOUNTID + " =? ";
		params.add(loanAcc);
		List<IBOUB_FIN_AmortizationDetails> amortizationDetailsList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOUB_FIN_AmortizationDetails.BONAME, whereClause, params, null, true);
		if (null != amortizationDetailsList && !amortizationDetailsList.isEmpty())
			earnedAccount = amortizationDetailsList.get(0).getF_EARNEDACCOUNTID();
		IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
		if (null != earnedAccount && earnedAccount.trim().length() > 0) {
			String deferredIncome = getDeferredIncomeAcc(loanAccDtl.getF_ISOCURRENCYCODE());
			String drTxnCode = EMPTY;
			String crTxnCode = EMPTY;
			drTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_DR");
			LOGGER.info("Inst drTxnCode:" + drTxnCode);
			crTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_CR");
			LOGGER.info("Inst crTxnCode:" + crTxnCode);

			String txnID = GUIDGen.getNewGUID();
			Date busDate = SystemInformationManager.getInstance().getBFBusinessDate();
			IBOAttributeCollectionFeature creditAccountDetails = FinderMethods.getAccountBO(deferredIncome);
			IBOAttributeCollectionFeature debitAccountDetails = FinderMethods.getAccountBO(earnedAccount);
			IPostingMessage debitPostingMessage = getFinPostingMessage(debitAccountDetails, earnedAccount, txnAmount,
					drTxnCode, DEBIT_POSTING_ACTION, txnID, "", "", batchReference, busDate);

			IPostingMessage creditPostingMessage = getFinPostingMessage(creditAccountDetails, deferredIncome, txnAmount,
					crTxnCode, CREDIT_POSTING_ACTION, txnID, "", "", batchReference, busDate);
			ArrayList<IPostingMessage> postingMessageList = new ArrayList<>();
			postingMessageList.add(debitPostingMessage);
			postingMessageList.add(creditPostingMessage);
			postTransaction(postingMessageList);
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	private String getDeferredIncomeAcc(String currencyCode) {
		String bankAccID = EMPTY;
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue("IB", "DEFERREDINCACCT");
		LOGGER.info("getDeferredIncomeAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOpseudonyms.BONAME, chargeReceivingAccPseudonym, true);
		String contextValue = currencyCode;
		LOGGER.info("getF_FINDERALTERNATIVE1: " + pseudDtls.getF_FINDERALTERNATIVE1());
		if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
			contextValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
			LOGGER.info("contextValue" + contextValue);
		}
		List finderResult = FinderMethods.findAccountByPseudoname(chargeReceivingAccPseudonym, currencyCode,
				pseudDtls.getF_FINDERALTERNATIVE1(), contextValue, BankFusionThreadLocal.getBankFusionEnvironment(),
				null);
		if (finderResult != null && !finderResult.isEmpty()) {
			bankAccID = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
			LOGGER.info("bankAccID:" + bankAccID);
		}
		return bankAccID;
	}

}
