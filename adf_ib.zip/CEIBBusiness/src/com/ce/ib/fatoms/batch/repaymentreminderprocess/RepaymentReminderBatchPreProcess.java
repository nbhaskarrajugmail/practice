package com.ce.ib.fatoms.batch.repaymentreminderprocess;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * @author Bhaskar N
 * 
 */
public class RepaymentReminderBatchPreProcess implements IBatchPreProcess {

    private BankFusionEnvironment env;

    @Override
    public void init(BankFusionEnvironment env) {
        this.env = env;
    }

    @Override
    public void process(AbstractFatomContext arg0) {
    }

}
