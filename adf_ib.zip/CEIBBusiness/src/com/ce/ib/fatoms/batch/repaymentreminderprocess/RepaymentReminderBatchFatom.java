package com.ce.ib.fatoms.batch.repaymentreminderprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_RepaymentReminderTag;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_RepaymentNotificationEmailAndSMS;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_JOBSTATUS;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * @author Bhaskar N
 * @description Sends the reminder to customers before the repayment schedule date 
 */
public class RepaymentReminderBatchFatom extends AbstractCE_IB_RepaymentNotificationEmailAndSMS {

	private static final long serialVersionUID = 1L;

	private transient final static Log LOGGER = LogFactory
			.getLog(RepaymentReminderBatchFatom.class.getName());
	
	private static String jobId = "REPAY_INV_GEN";

	private static final String BATCH_PROCESS_NAME = "RepaymentReminderBatch";
	
	private static String INSERT_REPAY_REMIND_QUERY = "INSERT INTO CUSTOMEXTN.CE_IBTB_REPAYMENTREMINDERTAG (CEIBROWSEQ,CEIBREPAYMENTREMINDERIDPK, CEIBREPAYMENTNUMBER, CELOANACCOUNTID, CEPAYMENTAMT, CEDUEAMT, CEREPAYMENTDT ,VERSIONNUM) " + 
			" SELECT ((ROW_NUMBER() OVER (ORDER BY LNLOANSCHEDULEIDPK)) +  (SELECT COALESCE(MAX(CAST (CEIBROWSEQ AS INTEGER) ), 0) FROM CUSTOMEXTN.CE_IBTB_REPAYMENTREMINDERTAG)) CEROWSEQPK, LS.LNLOANSCHEDULEIDPK, " + 
			" LS.LNREPAYMENTNUMBER, LS.LNLOANACCOUNTID, LS.LNPAYMENTAMT, (SELECT SUM(REPAYMENTUNPAID) due FROM WASADMIN.LOANREPAYMENTS LRP WHERE LRP.ACCOUNTID = LS.LNLOANACCOUNTID  and LRP.STATUS != 'F') CEDUEAMT, LS.LNPAYMENTDT,0 VERSIONNUM " + 
			" FROM LENDING.LNTB_LOANSCHEDULE LS WHERE TRUNC(LNPAYMENTDT) = TRUNC(?)";
	
	private static String LAST_SUCCESS_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Success' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " DESC ";
	
	private static String FIRST_FAIL_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Failed' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " ASC ";
	
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal
			.getPersistanceFactory();

	public RepaymentReminderBatchFatom(BankFusionEnvironment env) {
		super(env);

	}

	public RepaymentReminderBatchFatom(String batchProcessName) {

	}

	public static void main(String as[]) throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date businessDate = sdf.parse("2021-11-23");
		Calendar cal = Calendar.getInstance();
		cal.setTime(businessDate);
		cal.add(Calendar.DATE, -45);
		Date reminder45 = cal.getTime();
		System.out.println("-45:"+reminder45);
		cal.setTime(businessDate);
		cal.add(Calendar.DATE, -15);
		Date reminder15 = cal.getTime();
		System.out.println("-15:"+reminder15);
		cal.setTime(businessDate);
		cal.add(Calendar.DATE, -1);
		Date reminder1 = cal.getTime();
		System.out.println("-1:"+reminder1);
		cal.setTime(businessDate);
		cal.add(Calendar.DATE, 15);
		Date reminder_15 = cal.getTime();
		System.out.println("15:"+reminder_15);
	}
	

	@SuppressWarnings("deprecation")
	protected void processBatch(BankFusionEnvironment environment,
			AbstractFatomContext context) {
		try {
			Integer reminderOne = (Integer) ModuleConfiguration.getInstance().getModuleConfigurationValue("CESADADINTERFACE",
					"REPAY_REMIND_1");
			Integer reminderTwo = (Integer) ModuleConfiguration.getInstance().getModuleConfigurationValue("CESADADINTERFACE",
					"REPAY_REMIND_2");
			Integer reminderThree = (Integer) ModuleConfiguration.getInstance().getModuleConfigurationValue("CESADADINTERFACE",
					"REPAY_REMIND_3");
			Integer INVGEN_DAYS_BEFORE_DUEDATE = (Integer) ModuleConfiguration.getInstance().getModuleConfigurationValue("CESADADINTERFACE",
					"INVGEN_DAYS_BEFORE_DUEDATE");
			Date businessDate = IBCommonUtils.getBFBusinessDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(businessDate);
			cal.add(Calendar.DATE, reminderOne);
			Date reminderOneDate = cal.getTime();
			cal.setTime(businessDate);
			cal.add(Calendar.DATE, reminderTwo);
			Date reminderTwoDate = cal.getTime();
			cal.setTime(businessDate);
			cal.add(Calendar.DATE, reminderThree);
			Date reminderThreeDate = cal.getTime();
			LOGGER.info("Generating SMS/EMAIL for reminder one date :"+reminderOneDate+" and reminder two date :"+reminderTwoDate);
			if (LOGGER.isInfoEnabled())
				LOGGER.info("Repayment Reminder Batch Process Started.....");
			RepaymentReminderBatchFatomContext repayReminderContext = null;
			boolean batchStatus = true;
			deleteRepaymentReminderTagData();
			insertRepaymentReminderTagData(new java.sql.Date(reminderOneDate.getTime()));
			factory.commitTransaction();
			factory.beginTransaction();
			insertRepaymentReminderTagData(new java.sql.Date(reminderTwoDate.getTime()));
			factory.commitTransaction();
			factory.beginTransaction();
			insertRepaymentReminderTagData(new java.sql.Date(reminderThreeDate.getTime()));
			factory.commitTransaction();
			factory.beginTransaction();
			cal.setTime(businessDate);
			cal.add(Calendar.DATE, INVGEN_DAYS_BEFORE_DUEDATE);
			businessDate = cal.getTime();
			insertRepaymentReminderTagData(new java.sql.Date(businessDate.getTime()));
			factory.commitTransaction();
			factory.beginTransaction();
			/*Date lastSuccessEODDate = getLastSuccessDate();
			if(businessDate.after(lastSuccessEODDate)) {
				Date missedDate = businessDate;
				while(missedDate.after(lastSuccessEODDate)) {
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(missedDate);
					calendar.add(Calendar.DATE, -1);
					missedDate = calendar.getTime();
					insertRepaymentReminderTagData(new java.sql.Date(missedDate.getTime()));
					factory.commitTransaction();
					factory.beginTransaction();
				}
			}*/
			repayReminderContext = (RepaymentReminderBatchFatomContext) context;
			repayReminderContext.setInputTagDataMap(getInDataMap());
			BatchService service = (BatchService) ServiceManager
					.getService(ServiceManager.BATCH_SERVICE);
			
			service.runBatch(environment, repayReminderContext);
			setF_OUT_BATCH_STATUS(batchStatus);
		
		} catch (Exception e) {
			if (LOGGER.isErrorEnabled())
				LOGGER.error("RepaymentReminderBatchFatom - processBatch() : Exception : "+ e.getMessage());
			factory.rollbackTransaction();
			factory.beginTransaction();
		}
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Repayment Reminder Batch Process Initiated");
		
		factory.rollbackTransaction();
		factory.beginTransaction();
	}
	@SuppressWarnings("deprecation")
	private void insertRepaymentReminderTagData(java.sql.Date date) {
		try {
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = null;
			ps = con.prepareStatement(INSERT_REPAY_REMIND_QUERY);
			ps.setDate(1, date);
			int result = ps.executeUpdate();
			LOGGER.info("result:" + result);
			LOGGER.info("Statement:" + ps.toString());
			LOGGER.info("Data inserted into tag");
		} catch (SQLException e) {
			LOGGER.warn("No Accoutns are avaialble for processing");
			LOGGER.error(e);
		}
	}

	private void deleteRepaymentReminderTagData() {
		factory.bulkDeleteAll(IBOCE_IB_RepaymentReminderTag.BONAME);	
		factory.commitTransaction();
		factory.beginTransaction();
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Deleted all RepaymentReminderTag records ");
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new RepaymentReminderBatchFatomContext(BATCH_PROCESS_NAME);
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
		
	}
	
	@SuppressWarnings("unchecked")
	private Date getLastSuccessDate() {

		@SuppressWarnings("rawtypes")
		ArrayList params = new ArrayList();
		params.add(jobId);
		IBOCE_JOBSTATUS jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME,
				LAST_SUCCESS_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			return jobStatus.getF_JOBEXECDATE();
		}

		jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, FIRST_FAIL_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			Date date = jobStatus.getF_JOBEXECDATE();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, -1);
			date = new Date(cal.getTime().getTime());
			return date;
		}
		return null;
	}

	



}
