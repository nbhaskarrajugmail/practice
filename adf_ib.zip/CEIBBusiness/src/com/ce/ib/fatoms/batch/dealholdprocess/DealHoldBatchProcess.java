package com.ce.ib.fatoms.batch.dealholdprocess;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealHoldTag;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.ce.ib.cfg.dto.HoldRule;
import com.ce.ib.cfg.dto.RuleDTO;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOUBTB_NOMCODEACCOUNTTAG;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import bf.com.misys.cbs.types.RuleExecRsData;

/**
 * 
 * @author Bhaskar N
 * @Description DealHoldBatch Process will check the deal against configured rules and markd as hold
 */
public class DealHoldBatchProcess extends AbstractBatchProcess {
	private transient final static Log LOGGER = LogFactory
			.getLog(DealHoldBatchProcess.class.getName());

    private AbstractProcessAccumulator accumulator;
    private DealHoldBatchFatomContext context;

    private static final String PAGING_SQL = " WHERE " + IBOCE_IB_DealHoldTag.IBROWSEQ + " BETWEEN ? AND ? ";
    
    IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

    public DealHoldBatchProcess(AbstractPersistableFatomContext context) {
        super(context);
        this.context = (DealHoldBatchFatomContext) context;
    }

    @Override
    public AbstractProcessAccumulator getAccumulator() {
        return accumulator;
    }

    @Override
    public void init() {
        initialiseAccumulator();
    }

    @Override
    protected void initialiseAccumulator() {
        accumulator = new DealHoldBatchAccumulator(new Object[0]);
    }

    @SuppressWarnings("unchecked")
    @Override
    public AbstractProcessAccumulator process(int pageToProcess) {
    	LOGGER.info("Processing Deal HoldBatch");
    	com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal.setApplicationID("IslamicBanking");
    	int pageSize = 0;
        int fromValue = 0;
        int toValue = 0;
        Iterator<IBOCE_IB_DealHoldTag> dealHoldTagIterator = null;
        List DealHoldTagList = null;
        IBOCE_IB_DealHoldTag dealHoldTag = null;
        HoldRule holdRule = getHoldRule();

        pageSize = context.getPageSize();
        pagingData.setCurrentPageNumber(pageToProcess);
        fromValue = ((pageToProcess - 1) * pageSize) + 1;
        toValue = pageToProcess * pageSize;
        LOGGER.info("processing from "+fromValue +" to "+toValue);

        if (context != null) {
        	
            ArrayList<Integer> paramList = new ArrayList<Integer>();
            paramList.add(fromValue);
            paramList.add(toValue);
            DealHoldTagList = factory.findByQuery(IBOCE_IB_DealHoldTag.BONAME, PAGING_SQL, paramList, null, false);
            if (DealHoldTagList != null && !DealHoldTagList.isEmpty()) {
            	dealHoldTagIterator = DealHoldTagList.iterator();
                while (dealHoldTagIterator.hasNext()) {
                	dealHoldTag = dealHoldTagIterator.next();
                	for(RuleDTO rule : holdRule.getRule()) {
            			if(rule.getStatus().toUpperCase().equals("ACTIVE") && execRule(dealHoldTag.getBoID(), rule.getId())) {
            				LOGGER.info("Deal "+dealHoldTag.getBoID()+" passed with rule "+rule.getId());
							DealHoldUtil.holdDeal(dealHoldTag.getBoID(), StringUtils.isEmpty(rule.getReason())?rule.getId():rule.getReason());
						}
            		}
                }
            }
        }

        return accumulator;
    }

    private static boolean execRule(String dealId, String ruleId) {
		String ruleOutput = "";
		RuleExecRsData ruleResponse = IBCommonUtils.getRuleAndExecute(ruleId, dealId);
		if (null != ruleResponse && null != ruleResponse.getRuleData()) {
			List<String> responseList = (List<String>) ruleResponse.getRuleData();
			if (ruleResponse.getRuleType().equals(IBConstants.RULE_TYPE_CONDITION_CONSTANT)
					&& ruleResponse.getRuleData() != null && responseList.size() > CommonConstants.INTEGER_ZERO
					&& responseList.get(CommonConstants.INTEGER_ZERO) != null) {
				ruleOutput = String.valueOf(responseList.get(CommonConstants.INTEGER_ZERO));
				if (ruleOutput.equalsIgnoreCase("true"))
					return true;
			}
		}
		return false;
	}
    private HoldRule getHoldRule() {
		String confPath = System.getProperty(CeConstants.ADFIBCONFIGLOCATION);
		String filePath = confPath.concat(CeConstants.HOLD_RULES_FILE);
		JAXBContext jaxbContext;
		HoldRule holdRule = null;
		try {
			jaxbContext = JAXBContext.newInstance(HoldRule.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			InputStream inStream = new FileInputStream(filePath);
			holdRule = (HoldRule) jaxbUnmarshaller.unmarshal(inStream);
			if(LOGGER.isInfoEnabled() && holdRule!=null && holdRule.getRule()!=null && !holdRule.getRule().isEmpty()) {
				for(RuleDTO rule : holdRule.getRule()) {
					LOGGER.info("Rule configured :"+rule.getId());
				}
			}
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage());
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		}
		return holdRule;
	}
}
