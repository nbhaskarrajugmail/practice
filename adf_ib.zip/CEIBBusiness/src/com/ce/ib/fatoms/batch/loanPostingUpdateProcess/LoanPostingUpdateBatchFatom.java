package com.ce.ib.fatoms.batch.loanPostingUpdateProcess;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_LoanPostingBreakupUpdateTag;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_LoanPostingUpdateBatch;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.ProductConfiguration;

public class LoanPostingUpdateBatchFatom extends AbstractCE_IB_LoanPostingUpdateBatch{

	private static final long serialVersionUID = 1L;

	private transient final static Log LOGGER = LogFactory.getLog(LoanPostingUpdateBatchFatom.class.getName());

	private static final String BATCH_PROCESS_NAME = "LoanPostingUpdateBatchProcess";

	private static final String LOANREPAYMENTS_WHERECLAUSE = "WHERE " + IBOLoanRepayments.DUEDATE + " =? ";
	private static final String DEALDTLS_WHERECLAUSE = "WHERE " + IBOIB_DLI_DealDetails.DealAccountId + " =? ";
	private static final String BREAKUPDTLS_WHERECLAUSE = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
	private static final String LOANPOSTING_WHERECLAUSE = "WHERE " + IBOCE_IB_LoanPostingBreakupUpdateTag.IBACCOUNTID + " = ? AND "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBREPAYMENTDATE + " = ?";
	private static final String LOANPOSTINGDELETE_WHERECLAUSE = "WHERE "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBREPAYMENTDATE + " < ? AND "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBSTATUS + "= ? ";
	private static final String LOANPOSTING_UPDATE_WHERECLAUSE = "WHERE "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBREPAYMENTDATE + " < ? AND "
			+ IBOCE_IB_LoanPostingBreakupUpdateTag.IBSTATUS + "!= ? ";
	private int insertedRecordCount = 0;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public LoanPostingUpdateBatchFatom(BankFusionEnvironment env) {
		super(env);
	}

	public LoanPostingUpdateBatchFatom(String batchProcessName) {

	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new LoanPostingUpdateBatchFatomContext(BATCH_PROCESS_NAME);
		
	}

	@Override
	protected void processBatch(BankFusionEnvironment environment, AbstractFatomContext context) {
		LOGGER.info("Loan Posting Batch Process Started.....");
		LoanPostingUpdateBatchFatomContext loanPostingUpdateContext = null;
		boolean batchStatus = true;
		try {
			deleteLoanPostingUpdateTagData();
			UpdateRowIndexNonProcessedRecords();
			insertLoanPostingUpdateTagData();
			factory.commitTransaction();
			factory.beginTransaction();
			loanPostingUpdateContext = (LoanPostingUpdateBatchFatomContext) context;
			loanPostingUpdateContext.setInputTagDataMap(getInDataMap());
			BatchService service = (BatchService) ServiceManager.getService(ServiceManager.BATCH_SERVICE);
			batchStatus = service.runBatch(environment, loanPostingUpdateContext);
			setF_OUT_BATCH_STATUS(batchStatus);

		} catch (Exception e) {
			LOGGER.error("LoanPostingUpdateBatchFatom - processBatch() : Exception : " + e.getMessage());
			factory.rollbackTransaction();
			factory.beginTransaction();
		}
		LOGGER.info("Loan Posting Update Batch Process Initiated");

		factory.rollbackTransaction();
		factory.beginTransaction();

		
	}

	private void insertLoanPostingUpdateTagData() {
		ArrayList<Object> params = new ArrayList<>();
		params.add(IBCommonUtils.getBFBusinessDate());
		List<IBOLoanRepayments> loanRepaymentDtls = (List<IBOLoanRepayments>) factory
				.findByQuery(IBOLoanRepayments.BONAME, LOANREPAYMENTS_WHERECLAUSE, params, null, true);
		if (loanRepaymentDtls != null && !loanRepaymentDtls.isEmpty()) {
			LOGGER.info("No of repayments found in Loan Repayment table with business date: "
					+ IBCommonUtils.getBFBusinessDate() + " is :" + loanRepaymentDtls.size());
			for (IBOLoanRepayments loanRepaymentDtl : loanRepaymentDtls) {
				params.clear();
				params.add(loanRepaymentDtl.getF_ACCOUNTID());
				params.add(IBCommonUtils.getBFBusinessDate());
				List<IBOCE_IB_LoanPostingBreakupUpdateTag> loanPostingDtls = (List<IBOCE_IB_LoanPostingBreakupUpdateTag>) factory
						.findByQuery(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME, LOANPOSTING_WHERECLAUSE, params, null,
								true);
				if (loanPostingDtls.isEmpty() && loanPostingDtls.size() == 0) {
					params.clear();
					params.add(loanRepaymentDtl.getF_ACCOUNTID());
					List<IBOIB_DLI_DealDetails> dealDtls = (List<IBOIB_DLI_DealDetails>) factory
							.findByQuery(IBOIB_DLI_DealDetails.BONAME, DEALDTLS_WHERECLAUSE, params, null, true);
					for (IBOIB_DLI_DealDetails dealDtl : dealDtls) {
						ProductConfiguration productConfiguration = IBCommonUtils
								.loadProductConfiguration(dealDtl.getBoID());
						if (dealDtl != null && RescheduleUtils.isNonFrontLoadedManual(dealDtl.getF_ProductContextCode(),
								dealDtl.getF_DealAccountId(), productConfiguration.isIsHostScheduleGenerator())) {
							params.clear();
							params.add(dealDtl.getBoID());
							params.add(IBCommonUtils.getBFBusinessDate());
							List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal
									.getPersistanceFactory().findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME,
											BREAKUPDTLS_WHERECLAUSE, params, null, true);
							if (ibPaymentSchResult != null && !ibPaymentSchResult.isEmpty()) {
								BigDecimal installmentProfitAmt = new BigDecimal(0);
								BigDecimal rescheduleProfitAmt = new BigDecimal(0);

								for (IBOCE_IB_PaymentSchBreakup eachPaymentSch : ibPaymentSchResult) {
									installmentProfitAmt = installmentProfitAmt.add(eachPaymentSch.getF_IBPROFITAMT());
									rescheduleProfitAmt = rescheduleProfitAmt.add(eachPaymentSch.getF_IBSCHEDULEFEEAMT());
								}
								LOGGER.info("installmentProfitAmt for the dealid: " + dealDtl.getBoID()
										+ " and the Repayment Date:" + loanRepaymentDtl.getF_DUEDATE());
								if (installmentProfitAmt.compareTo(BigDecimal.ZERO) > 0
										|| rescheduleProfitAmt.compareTo(BigDecimal.ZERO) > 0) {
									LOGGER.info("Inserting the data into LoanPostingBreakupUpdateTag the dealid: "
											+ dealDtl.getBoID() + " and the Repayment Date:"
											+ loanRepaymentDtl.getF_DUEDATE());
									IBOCE_IB_LoanPostingBreakupUpdateTag loanPostingUpdateTag = (IBOCE_IB_LoanPostingBreakupUpdateTag) factory
											.getStatelessNewInstance(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME);
									loanPostingUpdateTag.setBoID(GUIDGen.getNewGUID());
									loanPostingUpdateTag.setF_IBACCOUNTID(dealDtl.getF_DealAccountId());
									loanPostingUpdateTag.setF_IBREPAYMENTDATE(loanRepaymentDtl.getF_DUEDATE());
									loanPostingUpdateTag.setF_IBDEALID(dealDtl.getBoID());
									loanPostingUpdateTag.setF_IBINSTALLMENTPROFIT(installmentProfitAmt);
									loanPostingUpdateTag.setF_IBRESCHEDULEPROFIT(rescheduleProfitAmt);
									loanPostingUpdateTag.setF_IBSTATUS("UNPROCESSED");
									loanPostingUpdateTag.setF_IBROWSEQ(++insertedRecordCount);
									factory.create(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME, loanPostingUpdateTag);
								}
								if (insertedRecordCount % 10 == 0) {
									factory.commitTransaction();
									factory.beginTransaction();
								}
							}

						}
					}
				}
			}
		}
	}	
			


	private void deleteLoanPostingUpdateTagData() {
		LOGGER.info("Entering the method deleteLoanPostingUpdateTagData");
		ArrayList<Object> params = new ArrayList<>();
		java.sql.Date date = IBCommonUtils.getCalendarServiceDate(IBCommonUtils.getBFBusinessDate()).toSQLDate();
		params.add(date);
		params.add("PROCESSED");
		int recordsDeleted = factory.bulkDelete(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME, LOANPOSTINGDELETE_WHERECLAUSE, params);
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Deleted "+recordsDeleted+" Processed Records LoanPostingBreakupUpdateTag records less than :"
					+ IBCommonUtils.getBFBusinessDate());

	}
	private void UpdateRowIndexNonProcessedRecords() {
		LOGGER.info("Entering the method UpdateRowIndexNonProcessedRecords");
		java.sql.Date date = IBCommonUtils.getCalendarServiceDate(IBCommonUtils.getBFBusinessDate()).toSQLDate();
		ArrayList<Object> params = new ArrayList<>();
		params.add(date);
		params.add("PROCESSED");
		List<IBOCE_IB_LoanPostingBreakupUpdateTag> existingNotProcessedList = (List<IBOCE_IB_LoanPostingBreakupUpdateTag>) factory
				.findByQuery(IBOCE_IB_LoanPostingBreakupUpdateTag.BONAME, LOANPOSTING_UPDATE_WHERECLAUSE, params, null,
						true);
		for (IBOCE_IB_LoanPostingBreakupUpdateTag loanPostingBreakupUpdateTag : existingNotProcessedList) {
			loanPostingBreakupUpdateTag.setF_IBROWSEQ(++insertedRecordCount);
		}
		factory.commitTransaction();
		factory.beginTransaction();
		LOGGER.info("Completed the method UpdateRowIndexNonProcessedRecords");
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
		
		
	}

}
