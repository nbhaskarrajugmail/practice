package com.ce.ib.fatoms.batch.dealholdprocess;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealHoldTag;
import com.ce.bankfusion.ib.steps.refimpl.AbstractCE_IB_HoldDeal;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.ib.cfg.dto.HoldRule;
import com.ce.ib.cfg.dto.RuleDTO;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ub.fatoms.batch.nominalcodeprocess.NominalCodeBatchFatomContext;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOUBTB_NOMCODEACCOUNTTAG;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * @author Bhaskar N
 * @description Marks the deal as hold if mathches with the configured rules
 */
public class DealHoldBatchFatom extends AbstractCE_IB_HoldDeal {

	private static final long serialVersionUID = 1L;

	private transient final static Log LOGGER = LogFactory
			.getLog(DealHoldBatchFatom.class.getName());

	private static final String BATCH_PROCESS_NAME = "DealHoldBatch";
	
	private static String dealDetailQuery = " WHERE " + IBOIB_DLI_DealDetails.Status + " NOT IN (?,?,?,?) ";
	
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal
			.getPersistanceFactory();

	public DealHoldBatchFatom(BankFusionEnvironment env) {
		super(env);

	}

	public DealHoldBatchFatom(String batchProcessName) {

	}

	

	@SuppressWarnings("deprecation")
	protected void processBatch(BankFusionEnvironment environment,
			AbstractFatomContext context) {
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Deal Hold Batch Process Started.....");
		DealHoldBatchFatomContext dealHoldContext = null;
		boolean batchStatus = true;

		try {
			deleteDealHoldTagData();
			insertDealHoldTagData();
			factory.commitTransaction();
			factory.beginTransaction();
			dealHoldContext = (DealHoldBatchFatomContext) context;
			dealHoldContext.setInputTagDataMap(getInDataMap());
			BatchService service = (BatchService) ServiceManager
					.getService(ServiceManager.BATCH_SERVICE);
			
			//dealHoldContext.getInputTagDataMap().put("RULES", getHoldRule());
			service.runBatch(environment, dealHoldContext);
			setF_OUT_BATCH_STATUS(batchStatus);
		
		} catch (Exception e) {
			if (LOGGER.isErrorEnabled())
				LOGGER.error("DealHoldBatchFatom - processBatch() : Exception : "+ e.getMessage());
			factory.rollbackTransaction();
			factory.beginTransaction();
		}
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Deal Hold Batch Process Initiated");
		
		factory.rollbackTransaction();factory.beginTransaction();
	}
	private void insertDealHoldTagData() {
		ArrayList<String> params = new ArrayList<>();
		params.add(IBConstants.CLOSED);
		params.add(IBConstants.CANCELLED);
		params.add(CeConstants.DEAL_STATUS_EXPIRED);
		params.add(IBConstants.REJECTED);
		List<IBOIB_DLI_DealDetails> deals = IBCommonUtils.getPersistanceFactory()
				.findByQuery(IBOIB_DLI_DealDetails.BONAME, dealDetailQuery.toString(), params, null, false);
		int insertedRecordCount = 0;
		for(IBOIB_DLI_DealDetails dealDetail : deals) {
			IBOCE_IB_DealHoldTag dealHoldTag = (IBOCE_IB_DealHoldTag) factory
					.getStatelessNewInstance(IBOCE_IB_DealHoldTag.BONAME);

			dealHoldTag.setBoID(dealDetail.getBoID());
			dealHoldTag.setF_IBROWSEQ(++insertedRecordCount);
			factory.create(IBOCE_IB_DealHoldTag.BONAME,
					dealHoldTag);
			if(insertedRecordCount%10 ==0) {
				factory.commitTransaction();
				factory.beginTransaction();
			}

		}
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Deal records inserted " + insertedRecordCount);
		
	}

	private void deleteDealHoldTagData() {
		factory.bulkDeleteAll(IBOCE_IB_DealHoldTag.BONAME);	
		factory.commitTransaction();
		factory.beginTransaction();
		if (LOGGER.isInfoEnabled())
			LOGGER.info("Delete all Deal records ");
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new DealHoldBatchFatomContext(BATCH_PROCESS_NAME);
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
		
	}

	



}
