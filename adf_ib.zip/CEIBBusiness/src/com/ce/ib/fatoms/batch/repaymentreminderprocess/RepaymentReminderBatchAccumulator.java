package com.ce.ib.fatoms.batch.repaymentreminderprocess;

import java.util.ArrayList;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

/**
 * 
 * @author Bhaskar N
 * 
 */
public class RepaymentReminderBatchAccumulator extends AbstractProcessAccumulator {

	private ArrayList<Object> erroneousPostings = null;
	private ArrayList<Object> sucessPostings = null;

	public RepaymentReminderBatchAccumulator(Object[] args) {
		super(args);
		erroneousPostings = new ArrayList<Object>();
		sucessPostings = new ArrayList<Object>();
	}

	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		// TODO Auto-generated method stub

	}

	@Override
	public void acceptChanges() {
		// TODO Auto-generated method stub

	}

	@SuppressWarnings("unchecked")
	public void accumulateTotals(Object[] o) {
		erroneousPostings.addAll((ArrayList) o[0]);
		sucessPostings.addAll((ArrayList) o[1]);
	}

	@Override
	public Object[] getMergedTotals() {
		Object[] o = new Object[1];
		return o;
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] o = new Object[1];
		return o;
	}

	@Override
	public void mergeAccumulatedTotals(Object[] paramArrayOfObject) {
		// TODO Auto-generated method stub

	}

	@Override
	public void restoreState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void storeState() {
		// TODO Auto-generated method stub

	}

}
