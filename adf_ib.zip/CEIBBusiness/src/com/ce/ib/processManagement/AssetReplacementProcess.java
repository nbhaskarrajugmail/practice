package com.ce.ib.processManagement;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetMigrationData;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressPricingDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetReplacementProcess extends AbstractIslamicProcessManager {

    private static final String GET_ASSET_REPLACED_QUERY =
        " WHERE " + IBOCE_IB_AssetMigrationData.IBDEALNO + " =? AND " + IBOCE_IB_AssetMigrationData.IBASSETREPLACED + "=?";
    private static final String GET_ASSET_REPLACED_CANCEL_QUERY =
            " WHERE " + IBOCE_IB_AssetMigrationData.IBDEALNO + " =? AND " + IBOCE_IB_AssetMigrationData.IBPROCESSED + "=?";

    private static final String GET_REPORTS_BY_DEAL_QUERY =
        " WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + " = ? AND " + IBOCE_IB_AssetProgressReport.IBSTATUS + " != ?";

    private static final Integer E_NEW_ASSET_REPLACEMENT_NOT_ALLOWED_IB = 44000432;

    private static final Integer E_ASSET_REPLACEMENT_NOT_ALLOWED_NO_LOAN_ACC_IB = 44000433;

    private static final Integer E_ASSET_REPLACE_NOT_ALLOW_BEF_ASSET_DISB_IB = 44000438;

    private static final String STATUS_DISBURSED = "Disbursed";

    @Override
    public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		if (status.equals(IBConstants.DECISION_REJECTED) || status.equals(IBConstants.DECISION_CANCELLED)) {
			System.err.println();
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList params = new ArrayList<>();
	        params.add(islamicBankingObject.getDealID());
	        params.add(false);
	        factory.bulkDelete(IBOCE_IB_AssetMigrationData.BONAME, GET_ASSET_REPLACED_CANCEL_QUERY, params);
		}

		return true;
	}

    @Override
    public String generateTransactionID(String transactionID, String dealID) {
        return GUIDGen.getNewGUID();
    }

    @Override
    public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
        IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
        ArrayList<String> params = new ArrayList<>();
        params.add(islamicBankingObject.getDealID());
        params.add("N");

        List<IBOCE_IB_AssetMigrationData> assetReplacementInProgressList =
            factory.findByQuery(IBOCE_IB_AssetMigrationData.BONAME, GET_ASSET_REPLACED_QUERY, params, null, true);
        if (assetReplacementInProgressList != null && !assetReplacementInProgressList.isEmpty()) {
            IBCommonUtils.raiseUnparameterizedEvent(E_NEW_ASSET_REPLACEMENT_NOT_ALLOWED_IB);
        }

        IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
        if (dealDetails != null && dealDetails.getF_DealAccountId().equals(CommonConstants.EMPTY_STRING)) {
            IBCommonUtils.raiseUnparameterizedEvent(E_ASSET_REPLACEMENT_NOT_ALLOWED_NO_LOAN_ACC_IB);
        }
        params.clear();
        params.add(islamicBankingObject.getDealID());
        params.add(STATUS_DISBURSED);
        List<IBOCE_IB_AssetProgressReport> assetProgressReportList =
            factory.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
        if (assetProgressReportList != null && !assetProgressReportList.isEmpty()) {
            IBCommonUtils.raiseUnparameterizedEvent(E_ASSET_REPLACE_NOT_ALLOW_BEF_ASSET_DISB_IB);
        }
    }
}
