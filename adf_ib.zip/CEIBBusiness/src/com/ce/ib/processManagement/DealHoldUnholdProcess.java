/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.DealHoldUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DealHoldUnholdProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(DealHoldUnholdProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		return false;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of DealUnholdProcess" + islamicBankingObject.getDealID());
		String reason = DealHoldUtil.isDealOnHold(islamicBankingObject.getDealID());
		if(StringUtils.isBlank(reason))
		{
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_NOT_ON_HOLD);
		}
		logger.info("Exiting validateProcessDetails of DealUnholdProcess" + islamicBankingObject.getDealID());
	}
}
