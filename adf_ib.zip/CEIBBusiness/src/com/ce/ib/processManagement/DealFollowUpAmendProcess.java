/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.util.DealFollowUpUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class DealFollowUpAmendProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(DealFollowUpAmendProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		return false;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of DealFollowUpAmendProcess" + islamicBankingObject.getDealID());
		// No negatives followups to amend
		DealFollowUpUtils.isPrevFollowUpStatusPositive(islamicBankingObject.getDealID());

		// validates if the previous neg follow up is assigned to different user
		DealFollowUpUtils.validateUserAssignedToAmendFollowup(islamicBankingObject.getDealID());

		// validates the period between previous followup date and current business date
		DealFollowUpUtils.validatePrevFollowUpDate(islamicBankingObject.getDealID());

		// Once all above conditions satisfies, change the current followup status to In
		// Progress in follow up configuration
		DealFollowUpUtils.updateFollowUpStatus(islamicBankingObject.getDealID());

		logger.info("Exiting validateProcessDetails of DealFollowUpAmendProcess" + islamicBankingObject.getDealID());
	}
}
