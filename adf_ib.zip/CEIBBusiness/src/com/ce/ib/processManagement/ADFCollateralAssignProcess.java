package com.ce.ib.processManagement;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_CollateralRevaluationDetails;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealCollateralDtls;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealRelationshipDetails;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.ib.constants.RescheduleConstants;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ADFCollateralAssignProcess extends AbstractIslamicProcessManager {

    private static final Log LOGGER = LogFactory.getLog(ADFCollateralAssignProcess.class.getName());

    @Override
    public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
        boolean flag = false;
        String dealRelationShipDtlsQuery = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_DealRelationshipDetails.IBDEALID + " =?";
        String dealReqEvaluationQuery = CeConstants.QUERYSTRING_WHERE + IBOCE_IB_CollateralRevaluationDetails.IBDEALID + " =?";
        String dealCollateralQuery = " WHERE " + IBOCE_IB_DealCollateralDtls.IBDEALID + " =?";

        ArrayList<String> params = new ArrayList<>();
        params.add(islamicBankingObject.getDealID());

        IBOIB_CFG_StepDetails stepDetailsObj =
            IBCommonUtils.getStepDetails(islamicBankingObject.getStepID(), islamicBankingObject.getProcessConfigID());
        if (stepDetailsObj == null) {
            stepDetailsObj = IBCommonUtils.getStepDetails(islamicBankingObject.getStepID());
        }
        //relationShip
        List<IBOCE_IB_DealRelationshipDetails> dealRelationshipList = IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDtlsQuery, params, null, true);
        if (!IBCommonUtils.isNullOrEmpty(dealRelationshipList)) {
            for (IBOCE_IB_DealRelationshipDetails result : dealRelationshipList) {
                String stepStatus = updateStatus(islamicBankingObject.getDealID(), status, stepDetailsObj, result.getF_IBSTATUS());
                result.setF_IBSTATUS(stepStatus);
                flag = true;
            }
        }
        //Removing Deleted DEAL STATUS having value as deleted.
        if(status.equals("CANCEL") || status.equals("REJECT")) {
            IPersistenceObjectsFactory factory = IBCommonUtils.getPersistanceFactory();
            factory.commitTransaction();
            factory.beginTransaction();
          
          StringBuilder dealRelationShipDelete = new StringBuilder(CeConstants.QUERYSTRING_WHERE
              + IBOCE_IB_DealRelationshipDetails.IBDEALID + " =? AND "+IBOCE_IB_DealRelationshipDetails.IBDEALSTATUS+" = 'DELETED'");
         
          ArrayList<String> queryParams = new ArrayList<>();
          queryParams.add(islamicBankingObject.getDealID());
          List<IBOCE_IB_DealRelationshipDetails> resultSet = factory.findByQuery(
              IBOCE_IB_DealRelationshipDetails.BONAME, dealRelationShipDelete.toString(), queryParams, null, true);
          if (resultSet != null && !resultSet.isEmpty()) {
              for (IBOCE_IB_DealRelationshipDetails dealRelationship : resultSet) {
                  dealRelationship.setF_IBDEALSTATUS(CeConstants.ASSET_PAYOFF_STATUS_NEW);
                  dealRelationship.setF_IBTRANSACTIONID("");
              }
          }
          factory.commitTransaction();
          factory.beginTransaction();
          String deleteRelation = CeConstants.QUERYSTRING_WHERE
              + IBOCE_IB_DealRelationshipDetails.IBDEALID + " =? AND "+IBOCE_IB_DealRelationshipDetails.IBTRANSACTIONID+" = ?";
          queryParams.add(islamicBankingObject.getTransactionID());
          factory.bulkDeleteall(IBOCE_IB_DealRelationshipDetails.BONAME, deleteRelation.toString(), queryParams);
          factory.commitTransaction();
          factory.beginTransaction();
        }
        // collateral
        List<IBOCE_IB_DealCollateralDtls> dealCollateralList =
            IBCommonUtils.getPersistanceFactory().findByQuery(IBOCE_IB_DealCollateralDtls.BONAME, dealCollateralQuery, params, null, true);
        if (!IBCommonUtils.isNullOrEmpty(dealCollateralList)) {
            for (IBOCE_IB_DealCollateralDtls result : dealCollateralList) {
                String stepStatus = updateStatus(islamicBankingObject.getDealID(), status, stepDetailsObj, result.getF_IBSTATUS());
                result.setF_IBSTATUS(stepStatus);
                flag = true;
            }
        }
        // RequestEval
        List<IBOCE_IB_CollateralRevaluationDetails> reqEvalList = IBCommonUtils.getPersistanceFactory()
            .findByQuery(IBOCE_IB_CollateralRevaluationDetails.BONAME, dealReqEvaluationQuery, params, null, true);
        if (!IBCommonUtils.isNullOrEmpty(reqEvalList)) {
            for (IBOCE_IB_CollateralRevaluationDetails result : reqEvalList) {
                String stepStatus = updateStatus(islamicBankingObject.getDealID(), status, stepDetailsObj, result.getF_IBSTEPSTATUS());
                result.setF_IBSTEPSTATUS(stepStatus);
                flag = true;
            }
        }
        if (flag) {
            return true;
        }
        return false;
    }

    private String updateStatus(String dealID, String status, IBOIB_CFG_StepDetails stepDetailsObj, String resultStatus) {
        if (resultStatus != null && !IBCommonUtils.isNullOrEmpty(status)) {
            if (!resultStatus.equals(RescheduleConstants.STATUS_COMPLETED)) {
                resultStatus = status;
            }
            if (resultStatus.equals(RescheduleConstants.STATUS_COMPLETED)) {
                LOGGER.info("Status Changed to COMPLETED for deal = " + dealID);
            } else if (stepDetailsObj != null && stepDetailsObj.getF_STEPTYPE().equals(IBConstants.STEP_TYPE_APPROVAL)) {
                resultStatus = status;
            }
        }
        return resultStatus;
    }

    @Override
    public String generateTransactionID(String transactionID, String dealID) {
        return IBCommonUtils.getNewGUID();
    }
}