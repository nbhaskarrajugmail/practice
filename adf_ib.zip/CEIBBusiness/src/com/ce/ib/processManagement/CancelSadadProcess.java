/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: CancelSadadProcess.java,v.1.0,August 14, 2020 15:20:12 Ramachandra
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.fatom.ReadSadadPayments;
import com.ce.bankfusion.ib.util.CeConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class CancelSadadProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(DealHoldUnholdProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		return false;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of CancelSadadProcess" + islamicBankingObject.getDealID());
		ReadSadadPayments sadadPayments = new ReadSadadPayments();
		sadadPayments.setF_IN_islamicBankingObject(islamicBankingObject);
		sadadPayments.process(BankFusionThreadLocal.getBankFusionEnvironment());
		if(!sadadPayments.isF_OUT_isUserActionApplicable())
		{
			IBCommonUtils.raiseUnparameterizedEvent(CeConstants.E_DEAL_HAS_NO_ACTIVE_INVOICE);
		}
		logger.info("Exiting validateProcessDetails of CancelSadadProcess" + islamicBankingObject.getDealID());
	}
}
