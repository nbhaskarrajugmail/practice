/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class TransferOfDebtActvnProcess extends AbstractIslamicProcessManager {

	private static final Log logger = LogFactory.getLog(TransferOfDebtActvnProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of TransferOfDebtReqProcess" + islamicBankingObject.getDealID());
//		TODO:Chethan BN Get the Error message details from Amr and update here
		/*if (!TransferOfDebtReqUtils.isDealActive(islamicBankingObject.getDealID())) {
			String[] msgArgs = { islamicBankingObject.getDealID() };
			IBCommonUtils.raiseParametrizedEvent(35200001, msgArgs);
		}
		if (!TransferOfDebtReqUtils.isArrearDeal(islamicBankingObject.getDealID())) {
			IBCommonUtils.raiseUnparameterizedEvent(35100073);
		}*/
		logger.info("Exiting validateProcessDetails of TransferOfDebtReqProcess" + islamicBankingObject.getDealID());
	}
}
