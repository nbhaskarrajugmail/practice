package com.ce.ib.processManagement;

import java.util.ArrayList;
import java.util.List;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressPricingDtl;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_AssetProgressReport;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_DLI_DealDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class AssetProgressingProcess extends AbstractIslamicProcessManager {

	private static String GET_REPORTS_BY_DEAL_QUERY = " WHERE " + IBOCE_IB_AssetProgressReport.IBDEALNO + " = ? AND ("
			+ IBOCE_IB_AssetProgressReport.IBSTATUS + " = ? OR "+ IBOCE_IB_AssetProgressReport.IBSTATUS + " = ?)";
	private static String GET_ASSET_REPORTS_BY_REPORTID_QUERY = " WHERE " + IBOCE_IB_AssetProgressDtl.IBREPORTID + " = ? ";
	private static final String STATUS_DISBURSED = "Disbursed";
	private static final String STATUS_NEW = "New";
	private static final String STATUS_APPROVED = "Approved";
	private static final Integer E_NEW_ASSET_PROGRESS_NOT_ALLOWED_IB = 44000401;
	private static final Integer E_ASSET_PROGRESS_NOT_ALLOWED_NO_LOAN_ACC_IB = 44000403;

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		if (status.equals(IBConstants.DECISION_REJECTED) || status.equals(IBConstants.DECISION_CANCELLED)) {
			System.err.println();
			IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
			ArrayList<String> params = new ArrayList<>();
			params.add(islamicBankingObject.getDealID());
			params.add(STATUS_NEW);
			params.add(STATUS_APPROVED);
			List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory
					.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
			if (assetProgressReportList != null && !assetProgressReportList.isEmpty()) {
				String boID = assetProgressReportList.get(0).getBoID();
				String reportID = assetProgressReportList.get(0).getF_IBREPORTID();
				factory.remove(IBOCE_IB_AssetProgressReport.BONAME, boID, true);
				params.clear();
				params.add(reportID);
				factory.bulkDelete(IBOCE_IB_AssetProgressDtl.BONAME, GET_ASSET_REPORTS_BY_REPORTID_QUERY, params);
				factory.bulkDelete(IBOCE_IB_AssetProgressPricingDtl.BONAME, GET_ASSET_REPORTS_BY_REPORTID_QUERY, params);
			}
		}

		return true;
	}

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		String GET_REPORTS_BY_DEAL_QUERY = " WHERE "+IBOCE_IB_AssetProgressReport.IBDEALNO+" = ? AND "+IBOCE_IB_AssetProgressReport.IBSTATUS+" != ?";
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> params = new ArrayList<>();
		params.add(islamicBankingObject.getDealID());
		params.add(STATUS_DISBURSED);
		List<IBOCE_IB_AssetProgressReport> assetProgressReportList = factory
				.findByQuery(IBOCE_IB_AssetProgressReport.BONAME, GET_REPORTS_BY_DEAL_QUERY, params, null, true);
		if (assetProgressReportList != null && !assetProgressReportList.isEmpty()) {
			IBCommonUtils.raiseUnparameterizedEvent(E_NEW_ASSET_PROGRESS_NOT_ALLOWED_IB);
		}

		IBOIB_DLI_DealDetails dealDetails = IBCommonUtils.getDealDetails(islamicBankingObject.getDealID());
		if (dealDetails != null && dealDetails.getF_DealAccountId().equals(CommonConstants.EMPTY_STRING)) {
			IBCommonUtils.raiseUnparameterizedEvent(E_ASSET_PROGRESS_NOT_ALLOWED_NO_LOAN_ACC_IB);
		}
	}
}
