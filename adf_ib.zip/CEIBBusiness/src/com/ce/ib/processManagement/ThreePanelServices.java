package com.ce.ib.processManagement;

import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.types.IslamicBankingObject;

public class ThreePanelServices extends AbstractIslamicProcessManager{

	
	    @Override
	    public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {

	        return true;
	    }

	    @Override
	    public String generateTransactionID(String transactionID, String dealID) {
	        return GUIDGen.getNewGUID();
	    }
	
	    @Override
	    public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
    		String dealID = islamicBankingObject.getDealID();
			if(!dealID.equals("DummyDeal")) {
				IBCommonUtils.raiseUnparameterizedEvent(44000805);
			}
	    }
}
