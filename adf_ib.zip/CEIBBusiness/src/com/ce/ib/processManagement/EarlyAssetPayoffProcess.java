/* ***********************************************************************************
 * Copyright (c) 2005, 2008 Misys International Banking Systems Ltd. All Rights Reserved.
 *
 * This software is the proprietary information of Misys Financial Systems Ltd.
 * Use is subject to license terms.
 *
 * ********************************************************************************
 * $Id: EarlySettlementProcess.java,v.1.0,Oct 31, 2014 7:05:12 AM Vinod Kumar
 *
 */
package com.ce.ib.processManagement;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_EarlyAssetPayoffDtls;
import com.ce.bankfusion.ib.fatom.GetAssetPayOffDtls;
import com.ce.bankfusion.ib.util.CeConstants;
import com.ce.bankfusion.ib.util.EarlyAssetPayoffUtils;
import com.ce.bankfusion.ib.util.SadadPaymentUtils;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_StepDetails;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.CalendarUtil;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.processManagement.AbstractIslamicProcessManager;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SadadPaymentDetails;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.ib.spi.types.LoanPayments;
import bf.com.misys.ib.spi.types.messages.ReadLoanDetailsRs;
import bf.com.misys.ib.types.EarlyAssetPayoffDtls;
import bf.com.misys.ib.types.IslamicBankingObject;

public class EarlyAssetPayoffProcess extends AbstractIslamicProcessManager {

	private static final String SADAD_PAYMENT_SUCCESS_STATUS = "S";
	private static final Log logger = LogFactory.getLog(EarlyAssetPayoffProcess.class.getName());

	@Override
	public String generateTransactionID(String transactionID, String dealID) {
		return GUIDGen.getNewGUID();
	}

	@Override
	public boolean updateProcessStatus(IslamicBankingObject islamicBankingObject, String status) {
		IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtls = EarlyAssetPayoffUtils
				.getAssetPayoffExistingObjStatusNotCompleted(islamicBankingObject.getDealID(), false);

		IBOIB_CFG_StepDetails stepDetailsObj = IBCommonUtils.getStepDetails(islamicBankingObject.getStepID(),
				islamicBankingObject.getProcessConfigID());

		if (assetPayoffDtls != null) {

			if (!assetPayoffDtls.getF_IBSTATUS().equals(CeConstants.ASSET_PAYOFF_STATUS_COMPLETED)) {
				assetPayoffDtls.setF_IBSTATUS(status);
				assetPayoffDtls.setF_IBRECLASTMODIFIEDBY(IBCommonUtils.getUserId());
				assetPayoffDtls.setF_IBRECLASTMODIFIEDDATE(IBCommonUtils.getBFBusinessDateTime());
				assetPayoffDtls.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
			}

			if (stepDetailsObj != null && stepDetailsObj.getF_STEPTYPE().equals(IBConstants.STEP_TYPE_APPROVAL)) {
				assetPayoffDtls.setF_IBRECAPPROVEDBY(IBCommonUtils.getUserId());
				assetPayoffDtls.setF_IBRECAPPROVEDDATE(IBCommonUtils.getBFBusinessDateTime());
				assetPayoffDtls.setF_IBRECSYSDATE(IBCommonUtils.getBFSystemDateTime());
				prepareAndRaiseBillInvoice(islamicBankingObject);
			}
			if (status.equals(IBConstants.DECISION_REJECTED) || status.equals(IBConstants.DECISION_CANCELLED)) {
				prepareCancelBillInvoice(islamicBankingObject, assetPayoffDtls);
             }
			return true;
		} else if (logger.isDebugEnabled()) {
			logger.debug("There is no entry in Deal EarlyAssetPayoffProcess Details with this Transaction ID :"
					+ islamicBankingObject.getTransactionID());
		}
		return false;
	}
	
	private void prepareCancelBillInvoice(IslamicBankingObject islamicBankingObject,
			IBOCE_IB_EarlyAssetPayoffDtls assetPayoffDtls) {
		ReadLoanDetailsRs readLoanDetails = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());
		boolean businessDatePaymentAlreadyExists = false;
		LoanPayments businessDatePayment = null;
		int repaymentNo = 0;
		for (LoanPayments loanPayment : readLoanDetails.getDealDetails().getPaymentSchedule()) {
			if (CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(), loanPayment.getRepaymentDate())) {
				businessDatePaymentAlreadyExists = true;
				businessDatePayment = loanPayment;
				break;
			}
			if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
					loanPayment.getRepaymentDate())) {
				repaymentNo++;
			}
		}
		repaymentNo++;
		ArrayList<Date> repatmentDatesList = new ArrayList<Date>();
		if (businessDatePaymentAlreadyExists && !IBCommonUtils.isNullOrEmpty(businessDatePayment.getRepaymentStatus())
				&& businessDatePayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_UNPAID))
			repatmentDatesList.add(businessDatePayment.getRepaymentDate());
		else
		{
			if (businessDatePaymentAlreadyExists &&
					!IBCommonUtils.isNullOrEmpty(businessDatePayment.getRepaymentStatus())
					&& !businessDatePayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_UNPAID))
			{
				repatmentDatesList.add(AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(), 1));
				repaymentNo++;
			}
			else
				repatmentDatesList.add(IBCommonUtils.getBFBusinessDate());
			businessDatePayment = null;
		}
		
		ArrayList<Object> params = new ArrayList<Object>();
		List<IBOCE_BILLINVOICE> billInvoiceRecordsList = getExistingBillInvoiceRecords(readLoanDetails,
				repatmentDatesList, params);
		boolean isInvoicePaid = isInvoiceAlreadyPaid(billInvoiceRecordsList);
		if (!isInvoicePaid) {
			if (null == businessDatePayment)
				SadadPaymentUtils.cancelInvoiceForRepayment(islamicBankingObject.getDealID(),
						readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID(),
						repatmentDatesList);
			if (null != businessDatePayment)
				SadadPaymentUtils.updateInvoiceForAssetPayOffRepayment(islamicBankingObject.getDealID(),
						readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID(),
						businessDatePayment.getRepaymentDate(), businessDatePayment.getRepaymentAmt(), repaymentNo,
						islamicBankingObject.getTransactionID());
		}
	}

	private boolean isInvoiceAlreadyPaid(List<IBOCE_BILLINVOICE> billInvoiceRecordsList) {
		if (null != billInvoiceRecordsList && !billInvoiceRecordsList.isEmpty()) {
			ArrayList<Object> params = new ArrayList<Object>();
			for (IBOCE_BILLINVOICE billInvoiceRecord : billInvoiceRecordsList) {
				params.add(billInvoiceRecord.getF_BILLINVOICENO());
				String Where_Clause = " WHERE " + IBOCE_SadadPaymentDetails.BillInvoiceNo + " = ?";
				List<IBOCE_SadadPaymentDetails> ibSadadPayments = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery(IBOCE_SadadPaymentDetails.BONAME, Where_Clause, params, null, false);
				if (null != ibSadadPayments && !ibSadadPayments.isEmpty()) {
					for (IBOCE_SadadPaymentDetails sadadPayments : ibSadadPayments) {
						if (SADAD_PAYMENT_SUCCESS_STATUS.equals(sadadPayments.getF_STATUS())) {
							return true;
						}

					}
				}
			}
		}
		return false;
	}

	private List<IBOCE_BILLINVOICE> getExistingBillInvoiceRecords(ReadLoanDetailsRs readLoanDetails,
			ArrayList<Date> repatmentDatesList, ArrayList<Object> params) {
		params.add(readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID());
		params.add(SadadMessageConstants.REPAY);
		params.add(repatmentDatesList.get(0));
		params.add(SadadMessageConstants.EXPIRE);
		StringBuffer billInvoiceWhereClause = new StringBuffer(
				"WHERE  " + IBOCE_BILLINVOICE.BILLACCT + "=? and " + IBOCE_BILLINVOICE.BILLCATEGORY + "=? ");
		billInvoiceWhereClause.append(
				" AND " + IBOCE_BILLINVOICE.BILLDUEDATE + "=?" + " AND " + IBOCE_BILLINVOICE.BILLACTION + " <> ?");
		
		List<IBOCE_BILLINVOICE> billInvoiceRecordsList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceWhereClause.toString(), params, null, true);
		return billInvoiceRecordsList;
	}
	private void prepareAndRaiseBillInvoice(IslamicBankingObject islamicBankingObject) {
		BankFusionEnvironment bankFusionEnvironment = IBCommonUtils.getBankFusionEnvironment();
		GetAssetPayOffDtls getAssetPayOffDtls = getAssetPayoffDetails(islamicBankingObject, bankFusionEnvironment);
		ReadLoanDetailsRs readLoanDetails = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());
		boolean businessDatePaymentAlreadyExists = false;
		LoanPayments businessDatePayment = null;
		int repaymentNo = 0;
		for (LoanPayments loanPayment : readLoanDetails.getDealDetails().getPaymentSchedule()) {
			if (CalendarUtil.IsDate1EqualsToDate2(IBCommonUtils.getBFBusinessDate(),
					loanPayment.getRepaymentDate())) {
				businessDatePaymentAlreadyExists = true;
				businessDatePayment = loanPayment;
				if (businessDatePaymentAlreadyExists && !IBCommonUtils.isNullOrEmpty(loanPayment.getRepaymentStatus())
						&& !loanPayment.getRepaymentStatus().equals(IBConstants.REPAYMENT_STATUS_UNPAID))
					repaymentNo++;
				break;
			}
			if (CalendarUtil.IsDate1GreaterThanDate2(IBCommonUtils.getBFBusinessDate(),
					loanPayment.getRepaymentDate())) {
				repaymentNo++;
			}
		}
		repaymentNo++;
		businessDatePayment = prepareNewRepaymentAmounts(readLoanDetails, getAssetPayOffDtls.getF_OUT_earlyAssetPayoffDtls(),
				businessDatePaymentAlreadyExists, businessDatePayment, islamicBankingObject);
		SadadPaymentUtils.updateInvoiceForAssetPayOffRepayment(islamicBankingObject.getDealID(),
				readLoanDetails.getDealDetails().getLoanBasicDetails().getLoanAccountNo().getAccountID(),
				businessDatePayment.getRepaymentDate(), businessDatePayment.getRepaymentAmt(), repaymentNo,islamicBankingObject.getTransactionID());
	}

	private GetAssetPayOffDtls getAssetPayoffDetails(IslamicBankingObject islamicBankingObject,
			BankFusionEnvironment bankFusionEnvironment) {
		GetAssetPayOffDtls getAssetPayOffDtls = new GetAssetPayOffDtls(bankFusionEnvironment);
		getAssetPayOffDtls.setF_IN_islamicBankingObject(islamicBankingObject);
		getAssetPayOffDtls.setF_IN_mode(CeConstants.INPUT_MODE_LOAD);
		getAssetPayOffDtls.setF_IN_BBMode(IBConstants.VIEWMODE);
		getAssetPayOffDtls.process(bankFusionEnvironment);
		return getAssetPayOffDtls;
	}

	@Override
	public void validateProcessDetails(IslamicBankingObject islamicBankingObject) {
		logger.info("Entering validateProcessDetails of EarlyAssetPayoffProcess" + islamicBankingObject.getDealID());
		ReadLoanDetailsRs readLoanDetailsRs = IBCommonUtils.getLoanDetails(islamicBankingObject.getDealID());
		EarlyAssetPayoffUtils.validateAssetPayoffMultipleRequests(islamicBankingObject.getDealID());
		
		// validating atleast one asset is disbursed or not
		EarlyAssetPayoffUtils.validateDealDisbursementAmount(readLoanDetailsRs);
		
		// Reschedule is not allowed when loan is in Arrear state, hence stopping early
		// asset payoff in this case
		EarlyAssetPayoffUtils.validateArrearDeal(readLoanDetailsRs);
		
		//check if assets exist for the deal, are to be recalled?
		EarlyAssetPayoffUtils.validateNoOfAssetsForAssetPayoff(islamicBankingObject.getDealID());
		logger.info("Exiting validateProcessDetails of EarlyAssetPayoffProcess" + islamicBankingObject.getDealID());
	}
	private LoanPayments prepareNewRepaymentAmounts(ReadLoanDetailsRs readLoanDetails, EarlyAssetPayoffDtls assetPayoffDtls, boolean businessDatePaymentAlreadyExists, LoanPayments businessDatePayment,IslamicBankingObject islamicBankingObject) {
		if (readLoanDetails != null && assetPayoffDtls != null) {
			logger.info("inside addNewRepayment : Begin");
			logger.info("businessDatePaymentAlreadyExists"+businessDatePaymentAlreadyExists);
			BigDecimal profitAmount = assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingProfitAmount()
					.getCurrencyAmount().add(assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingFeesAmount()
							.getCurrencyAmount());
			String status = CommonConstants.EMPTY_STRING;
			if(businessDatePayment != null)
			 status = businessDatePayment.getRepaymentStatus();
			// if there is already a business date repayment which is UNPAID in the
			// schedule, then add the
			// total remaining amount to the principal amount
			if (businessDatePaymentAlreadyExists
					&& !IBCommonUtils.isNullOrEmpty(status) && status.equals(IBConstants.REPAYMENT_STATUS_UNPAID)) {
				businessDatePayment.setPrincipleAmt(businessDatePayment.getPrincipleAmt().add(assetPayoffDtls
						.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment
						.setPrincipalAmtUnpaid(businessDatePayment.getPrincipalAmtUnpaid().add(assetPayoffDtls
								.getEarlyAssetPayoffCollDtls().getTotalRemainingPrincipalAmount().getCurrencyAmount()));
				businessDatePayment.setProfitAmt(businessDatePayment.getProfitAmt().add(profitAmount));
				businessDatePayment.setProfitAmtUnpaid(businessDatePayment.getProfitAmtUnpaid().add(profitAmount));
				businessDatePayment.setRepaymentAmt(businessDatePayment.getRepaymentAmt().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
				businessDatePayment.setRepaymentAmtUnPaid(businessDatePayment.getRepaymentAmtUnPaid().add(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount()));
			}
			// if there is no business date repayment exists in the current schedule, then
			// add a new repayment
			else {

				businessDatePayment = new LoanPayments();
				businessDatePayment.setIsoCurrencyCode(islamicBankingObject.getCurrency());
				businessDatePayment.setFeeAmt(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setFeeAmtUnpaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setPrincipalAmtUnpaid(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setPrincipleAmt(assetPayoffDtls.getEarlyAssetPayoffCollDtls()
						.getTotalRemainingPrincipalAmount().getCurrencyAmount());
				businessDatePayment.setProfitAmt(profitAmount);
				businessDatePayment.setProfitAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setProfitAmtUnpaid(profitAmount);
				businessDatePayment.setRepaymentAmt(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				businessDatePayment.setRepaymentAmtPaid(BigDecimal.ZERO);
				businessDatePayment.setRepaymentAmtUnPaid(
						assetPayoffDtls.getEarlyAssetPayoffCollDtls().getTotalRemainingAmount().getCurrencyAmount());
				if (businessDatePaymentAlreadyExists
						&& !IBCommonUtils.isNullOrEmpty(status) && !status.equals(IBConstants.REPAYMENT_STATUS_UNPAID))
					businessDatePayment.setRepaymentDate(
							AddDaysToDate.run(IBCommonUtils.getBFBusinessDate(), 1));
				else
					businessDatePayment.setRepaymentDate(IBCommonUtils.getBFBusinessDate());
				businessDatePayment.setRepaymentStatus(IBConstants.REPAYMENT_STATUS_UNPAID);
				businessDatePayment.setRepaymentType(IBConstants.REPAYMENT);
				
			}
			
		}
		return businessDatePayment;
	}
}
