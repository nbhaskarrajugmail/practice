package com.misys.ce.adapter.api.mappings.request;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.misys.bankfusion.ib.bo.refimpl.IBOIB_CFG_ProductConfiguration;
import com.misys.bankfusion.ib.util.IBConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.util.IBCommonUtils;
import com.misys.ib.adapter.api.mappings.common.IRequestMapper;
import com.misys.ib.adapter.common.AdaptorUtil;
import com.misys.ib.adapter.common.MapperConstants;
import com.misys.ib.adapter.common.UpdateScheduleGenSetting;
import com.misys.ib.adapter.commons.PropertyUtils;

import bf.com.misys.financialposting.types.BackOfficeAccountPostingRq;
import bf.com.misys.financialposting.types.FxInfo;
import bf.com.misys.financialposting.types.PostingLeg;
import bf.com.misys.financialposting.types.TxnDetails;
import bf.com.misys.ib.spi.types.PaymentSchedule;
import bf.com.misys.ib.spi.types.messages.PostManualCollectionDetailsRq;

public class CollectInstallmentsRequestMapper implements IRequestMapper {

    @Override
    public Object convert(Object data) {
        PostManualCollectionDetailsRq manualCollectionReq = (PostManualCollectionDetailsRq) data;
        int a=0;
        BackOfficeAccountPostingRq postingReq = new BackOfficeAccountPostingRq();
        BigDecimal totalRepaymentAmount = getTotalRepaymentAnpount(manualCollectionReq);
        postingReq.setBackOfficePostingLegs(prepareAccountingEntries(manualCollectionReq, totalRepaymentAmount));
        setTxnDetails(manualCollectionReq, postingReq);
       
       IBOIB_CFG_ProductConfiguration details = AdaptorUtil.getProductConfDtls(manualCollectionReq.getDealInput().getSubProductID());
       if(details.ISHOSTSCHEDULEGEN.equals(IBConstants.YES))
       { UpdateScheduleGenSetting scheduleGenSetting = new UpdateScheduleGenSetting();
        scheduleGenSetting.updateScheduleGenerationSetting(manualCollectionReq.getLoanAccountNo().getAccountID(), Boolean.FALSE);
       }
       return postingReq;
    }

    private BigDecimal getTotalRepaymentAnpount(PostManualCollectionDetailsRq manualCollectionReq) {
        BigDecimal totalRepaymentAmount = new BigDecimal(0);
        for (PaymentSchedule paymentSchedule : manualCollectionReq.getPaymentSchedule().getPaymentSchedule()) {
            totalRepaymentAmount = totalRepaymentAmount.add(paymentSchedule.getRepaymentAmt());
        }
        return totalRepaymentAmount;
    }

    private void setTxnDetails(PostManualCollectionDetailsRq manualCollectionReq, BackOfficeAccountPostingRq postingReq) {
        TxnDetails txnDetails = (TxnDetails) AdaptorUtil.intializeDefaultvalues(new TxnDetails());
        txnDetails.setTransactionId(manualCollectionReq.getTransactionID());
        txnDetails.setValueDate(new Timestamp(manualCollectionReq.getValueDate().getTime()));
        txnDetails.setBranchSortCode(manualCollectionReq.getDealInput().getDealBranch());
        txnDetails.setForcePost(false);
        txnDetails.setChannelId(BankFusionThreadLocal.getChannel());
        postingReq.setTxnDetails(txnDetails);
    }

    private PostingLeg[] prepareAccountingEntries(PostManualCollectionDetailsRq manualCollectionReq, BigDecimal totalRepaymentAmount) {
        // Adding two legs one for credit to funding Account one for debit from loan Account
        PostingLeg[] postingLegs = new PostingLeg[2];
        postingLegs[0] = prepareCreditLeg(manualCollectionReq, totalRepaymentAmount);
        postingLegs[1] = prepareDebitLeg(manualCollectionReq, totalRepaymentAmount);
        return postingLegs;
    }

    /**
     * 
     * @param manualCollectionReq
     * @param totalRepaymentAmount
     * @return
     */
    private PostingLeg prepareCreditLeg(PostManualCollectionDetailsRq manualCollectionReq, BigDecimal totalRepaymentAmount) {
    	String mainDealID = (String)manualCollectionReq.getExtentionDetails().getUserExtension();
    	String loanAccountID = IBCommonUtils.getDealDetails(mainDealID).getF_DealAccountId();
    	PostingLeg creditLeg = (PostingLeg) AdaptorUtil.intializeDefaultvalues(new PostingLeg());
        creditLeg.setAccountId(manualCollectionReq.getLoanAccountNo().getAccountID());
        creditLeg.setTransactionCurrency(manualCollectionReq.getSettlementCurrency());
        creditLeg.setAmount(totalRepaymentAmount);
        creditLeg.setCreditDebitIndicator(MapperConstants.CREDIT_INDICATOR);
        creditLeg.setTransactionCode(PropertyUtils.getDefaultCreditTransactionCode());
        FxInfo amountToBaseEquivalentFxDetail = (FxInfo) AdaptorUtil.intializeDefaultvalues(new FxInfo());
        amountToBaseEquivalentFxDetail.setExchangeRateType(MapperConstants.EXCHANGE_SPOT);
        amountToBaseEquivalentFxDetail.setMultiplyDivide(MapperConstants.EXCHANGE_RATE_MULTIPLY);
        creditLeg.setAmountToBaseEquivalentFxDetail(amountToBaseEquivalentFxDetail);
        creditLeg.setBaseEquivalentAmount(totalRepaymentAmount);
        creditLeg.setNarrative(loanAccountID+"$Liability collection Posting");
        return creditLeg;
    }

    private PostingLeg prepareDebitLeg(PostManualCollectionDetailsRq manualCollectionReq, BigDecimal totalRepaymentAmount) {
    	String mainDealID = (String)manualCollectionReq.getExtentionDetails().getUserExtension();
    	String loanAccountID = IBCommonUtils.getDealDetails(mainDealID).getF_DealAccountId();
        PostingLeg debitLeg = (PostingLeg) AdaptorUtil.intializeDefaultvalues(new PostingLeg());
        if (!manualCollectionReq.getFundingAccountID().getAccountFormatType().equals(MapperConstants.PSEUDONYM_FORMAT_TYPE)) {
            debitLeg.setAccountId(manualCollectionReq.getFundingAccountID().getAccountID());
        }
        else {
            debitLeg.setAccountId((String) AdaptorUtil.getPsedonymInternalAcc(manualCollectionReq.getFundingAccountID()
                    .getAccountID(), PropertyUtils.getContextForPseudonym(), manualCollectionReq.getDealInput().getDealBranch(),
                    manualCollectionReq.getSettlementCurrency()));

        }
        debitLeg.setTransactionCurrency(manualCollectionReq.getSettlementCurrency());
        debitLeg.setAmount(totalRepaymentAmount);
        debitLeg.setCreditDebitIndicator(MapperConstants.DEBIT_INDICATOR);
        debitLeg.setTransactionCode(PropertyUtils.getDefaultDebitTransactionCode());
        FxInfo amountToBaseEquivalentFxDetail = (FxInfo) AdaptorUtil.intializeDefaultvalues(new FxInfo());
        amountToBaseEquivalentFxDetail.setExchangeRateType(MapperConstants.EXCHANGE_SPOT);
        amountToBaseEquivalentFxDetail.setMultiplyDivide(MapperConstants.EXCHANGE_RATE_MULTIPLY);
        debitLeg.setAmountToBaseEquivalentFxDetail(amountToBaseEquivalentFxDetail);
        debitLeg.setBaseEquivalentAmount(totalRepaymentAmount);
        debitLeg.setNarrative(loanAccountID+"$Liability collection Posting");
        return debitLeg;
    }
}
