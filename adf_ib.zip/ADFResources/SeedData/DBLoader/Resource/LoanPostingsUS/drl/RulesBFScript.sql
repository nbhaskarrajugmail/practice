DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1451';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  NULL,
  '{"operator":"and","expressions":[{"colval":"4d54148e00010123","coldisp":"Deal Information.Reschedule Schedule Fees Amount","opval":">","opdisp":">","val":"0","rhstype":"sysvalue"}],"nestedexpressions":[]}',
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableBoolean"]',
  'Condition',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  3,
  'IslamicBankingRule1451',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1452';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  'Deal Information.Reschedule Schedule Fees Amount',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1452',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1453';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  'Deal Information.Reschedule Schedule Fees Amount-Deal Information.Reschedule Schedule Fees Amount*0.015',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1453',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1454';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  'Deal Information.Reschedule Schedule Fees Amount*0.015',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1454',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1455';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  NULL,
  '{"operator":"and","expressions":[{"colval":"804339770001ffhh","coldisp":"Deal Information.Is Non-Front Loaded Manual","opval":"==","opdisp":"==","val":"true","rhstype":"sysvalue"},{"colval":"4d54148e00010123","coldisp":"Deal Information.Reschedule Schedule Fees Amount","opval":">","opdisp":">","val":"0","rhstype":"sysvalue"}],"nestedexpressions":[]}',
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableBoolean","bf.com.misys.ib.types.PostingDetails"]',
  'Condition',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"isNonFrontLoadedManual","_entityAttributeName":"Is Non-Front Loaded Manual","_serviceId":"CB_CFG_LoadGCListOfSystemParam_SRV","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"Boolean","_isUDF":false},{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1455',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1456';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  'Deal Information.Deferred Income Account',
  NULL,
  '["bf.com.misys.ib.types.PostingDetails","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"deferredIncomeAcc","_entityAttributeName":"Deferred Income Account","_serviceId":"","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"String","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1456',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1457';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  ' Deal Information.UnEarned Account',
  NULL,
  '["bf.com.misys.ib.types.PostingDetails","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"unEarnedAccount","_entityAttributeName":"UnEarned Account","_serviceId":"","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"String","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1457',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1458';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  ' Deal Information.Earned Account',
  NULL,
  '["bf.com.misys.ib.types.PostingDetails","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"earnedAccount","_entityAttributeName":"Earned Account","_serviceId":"","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"String","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1458',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1459';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  NULL,
  '{"operator":"and","expressions":[{"colval":"4d54148e00010123","coldisp":"Deal Information.Reschedule Schedule Fees Amount","opval":"<","opdisp":"<","val":"0","rhstype":"sysvalue"}],"nestedexpressions":[]}',
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableBoolean"]',
  'Condition',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1459',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1460';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  ' Deal Information.Refund Reschedule Profit_Paid Schedule Fees-Deal Information.Reschedule Schedule Fees Amount',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_REFUNDRESCHDTLS","_entityAttributeId":"f_IBPIADSCHEDULEFEEAMT","_entityAttributeName":"Refund Reschedule Profit_Paid Schedule Fees","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","_dataType":"Amount","_isUDF":false},{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1460',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1461';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  ' Deal Information.Refund Reschedule Profit_Paid Schedule Fees-Deal Information.Reschedule Schedule Fees Amount-((Deal Information.Refund Reschedule Profit_Paid Schedule Fees-Deal Information.Reschedule Schedule Fees Amount)*0.015)',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_REFUNDRESCHDTLS","_entityAttributeId":"f_IBPIADSCHEDULEFEEAMT","_entityAttributeName":"Refund Reschedule Profit_Paid Schedule Fees","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","_dataType":"Amount","_isUDF":false},{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1461',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1462';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  '(Deal Information.Refund Reschedule Profit_Paid Schedule Fees-Deal Information.Reschedule Schedule Fees Amount)*0.015',
  NULL,
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_REFUNDRESCHDTLS","_entityAttributeId":"f_IBPIADSCHEDULEFEEAMT","_entityAttributeName":"Refund Reschedule Profit_Paid Schedule Fees","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_REFUNDRESCHDTLS","_dataType":"Amount","_isUDF":false},{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1462',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1463';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  NULL,
  '{"operator":"and","expressions":[{"colval":"804339770001ffhh","coldisp":"Deal Information.Is Non-Front Loaded Manual","opval":"==","opdisp":"==","val":"true","rhstype":"sysvalue"},{"colval":"4d54148e00010123","coldisp":"Deal Information.Reschedule Schedule Fees Amount","opval":"<","opdisp":"<","val":"0","rhstype":"sysvalue"}],"nestedexpressions":[]}',
  '["com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","bf.com.misys.cbs.types.MutableBoolean","bf.com.misys.ib.types.PostingDetails"]',
  'Condition',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"isNonFrontLoadedManual","_entityAttributeName":"Is Non-Front Loaded Manual","_serviceId":"CB_CFG_LoadGCListOfSystemParam_SRV","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"Boolean","_isUDF":false},{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"CE_IB_DealReschedule","_entityAttributeId":"f_IBSCHEDULEFEES","_entityAttributeName":"Reschedule Schedule Fees Amount","_serviceId":"","_entityClass":"com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_DealReschedule","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1463',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1464';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  NULL,
  '{"operator":"and","expressions":[{"colval":"804339770001ffgg","coldisp":"Deal Information.Reschedule Remaing Profit Amount","opval":">","opdisp":">","val":"0","rhstype":"sysvalue"}],"nestedexpressions":[]}',
  '["bf.com.misys.cbs.types.MutableBoolean","bf.com.misys.ib.types.PostingDetails"]',
  'Condition',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"reschRemaingProfitAmt","_entityAttributeName":"Reschedule Remaing Profit Amount","_serviceId":"","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1464',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_RULEEXTENSION
WHERE BFRULEIDPK = 'IslamicBankingRule1465';
INSERT INTO BANKFUSION.BFTB_RULEEXTENSION
(
  BFTHENSTRING,
  BFWHENSTRING,
  BFIMPORTLIST,
  BFRULETYPE,
  BFPACKAGENAME,
  BFINPUTLIST,
  BFSTATUS,
  BFFORMAT,
  VERSIONNUM,
  BFRULEIDPK,
  BFOUTPUTLIST
)
VALUES
(
  'Deal Information.Reschedule Remaing Profit Amount',
  NULL,
  '["bf.com.misys.ib.types.PostingDetails","bf.com.misys.cbs.types.MutableString"]',
  'Formula',
  NULL,
  '{"_metaDataListList":[{"_systemParameterId":"DEALINFO","_systemParameterName":"Deal Information","_entityName":"PostingDetails","_entityAttributeId":"reschRemaingProfitAmt","_entityAttributeName":"Reschedule Remaing Profit Amount","_serviceId":"","_entityClass":"bf.com.misys.ib.types.PostingDetails","_dataType":"Amount","_isUDF":false}]}',
  'Y',
  'drl',
  0,
  'IslamicBankingRule1465',
  NULL
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3c6980dsHn';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1451',
  '01178f3c6980dsHn',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  1
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3ce0f46sbP';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1452',
  '01178f3ce0f46sbP',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3d03f55sh6';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1453',
  '01178f3d03f55sh6',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3d1ac7csl3';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1454',
  '01178f3d1ac7csl3',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3d48960ssQ';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1455',
  '01178f3d48960ssQ',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3d723d7szS';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1456',
  '01178f3d723d7szS',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3d90aa1t4S';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1457',
  '01178f3d90aa1t4S',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3dee91etJR';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1458',
  '01178f3dee91etJR',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3e411adtWa';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1459',
  '01178f3e411adtWa',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3eb8bd1trv';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1460',
  '01178f3eb8bd1trv',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3ec5938tuK';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1461',
  '01178f3ec5938tuK',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3ed45cbtx0';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1462',
  '01178f3ed45cbtx0',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3eef4a2u1d';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1463',
  '01178f3eef4a2u1d',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3fa436auU0';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1464',
  '01178f3fa436auU0',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);

DELETE
FROM BANKFUSION.BFTB_APPLICATIONCATEGORIES
WHERE BFIDPKPK = '01178f3fb1546uWU';
INSERT INTO BANKFUSION.BFTB_APPLICATIONCATEGORIES
(
  BFRESOURCEID,
  BFIDPKPK,
  BFAPPLICATIONVERSION,
  BFAPPLICATIONID,
  BFAPPCATEGORY,
  BFTYPE,
  VERSIONNUM
)
VALUES
(
  'IslamicBankingRule1465',
  '01178f3fb1546uWU',
  '4.0',
  'IslamicBanking',
  'Accounting Entries',
  28,
  0
);


