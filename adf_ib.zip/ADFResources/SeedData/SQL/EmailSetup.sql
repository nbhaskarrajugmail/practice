UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFVALUE = 'rafedmail@adf.gov.sa'
WHERE BFPROPIDPK = 'FromEmailAddress';
UPDATE BANKFUSION.BFTB_PROPERTY
   SET BFVALUE = 'mail.adf.gov.sa'
WHERE BFPROPIDPK = 'mail.smtp.host';