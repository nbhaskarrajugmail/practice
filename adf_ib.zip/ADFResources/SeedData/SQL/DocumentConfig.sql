INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db3e6761QUi',
  'محضر موافقة مجلس الإدارة على قرض مشاريع متخصصة',
  'Active',
  'محضر موافقة مجلس الإدارة على قرض مشاريع متخصصة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db438f11QVd',
  'تسجيل اجراءات الطلبات',
  'Active',
  'تسجيل اجراءات الطلبات',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db4e5681QX6',
  ' تقرير الإئتمان المالي(سمة)',
  'Active',
  ' تقرير الإئتمان المالي(سمة)',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db521f21QXX',
  'تسجيل بيانات نتائج الاستعلام عن طلبات سمة',
  'Active',
  'تسجيل بيانات نتائج الاستعلام عن طلبات سمة',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db62b321QZP',
  'عقد القرض',
  'Active',
  'عقد القرض',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db669af1QZs',
  'مستندات اخرى-للعقد',
  'Active',
  'مستندات اخرى-للعقد',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db6b24e1Qal',
  'سند إقرار وتعهد',
  'Active',
  'سند إقرار وتعهد',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db789b91Qbq',
  'تسجيل البيانات الاساسية للعقود',
  'Active',
  'تسجيل البيانات الاساسية للعقود',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db8743b1Qdc',
  'تقرير الانجاز',
  'Active',
  'تقرير الانجاز',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db8b39b1QeT',
  'خطاب امر صرف',
  'Active',
  'خطاب امر صرف',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db904c81Qf2',
  'اقرار استلام أعيان',
  'Active',
  'اقرار استلام أعيان',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db962321Qfd',
  'فواتير صرف تقرير الانجاز',
  'Active',
  'فواتير صرف تقرير الانجاز',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db9a6fc1QgW',
  'مستندات اخرى لتقرير الانجاز',
  'Active',
  'مستندات اخرى لتقرير الانجاز',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3dba11ed1Qh9',
  'تسجيل تقرير الانجاز',
  'Active',
  'تسجيل تقرير الانجاز
',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b45697e7d0itn',
  'Passport',
  'Active',
  'Passport',
  'D',
  0,
  '116abf73f05a0jQh',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ab75ce302Zg',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  0,
  '116b2c62e1f32BW0',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ab8da3402gV',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  0,
  '116b2c62e1f32BW0',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4abe748a03Qp',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4abf25c803bI',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4abf9fa503pz',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ac09d1903sk',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ac0f0b703uW',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad698f5075Z',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  1,
  '116b2c69399d2Bgd',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad73c23077c',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  1,
  '116b2c6a55052BiR',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad8030407AR',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  1,
  '116b2c6aa8312Biz',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad8f9ea07D4',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  1,
  '116b2c6b1efb2BkI',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad96a9807FB',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  1,
  '116b2c6bd6032Bm4',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ad9d7f207Gu',
  'برنت الاحوال المدنية',
  'Active',
  'برنت الاحوال المدنية',
  'D',
  1,
  '116b2c6b99ab2BlE',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4ada8fbd07JN',
  'برنت التأمينات الاجتماعية ',
  'Active',
  'برنت التأمينات الاجتماعية ',
  'D',
  1,
  '116b2c6c13292BmY',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4b37d63e01mJ',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  0,
  '116b2c62e1f32BW0',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4bcc20a20K7p',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4bcc20b00K7w',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4bcc20bc0K83',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4bcc20c90K8A',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b4bcc20d50K8H',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b502d81ee03NF',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  0,
  '116b2c62e1f32BW0',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b502f3c3603Rs',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b502fa0ee03Yi',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b503078d303hJ',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b508e0dfb0qTh',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b508e0e0b0qTo',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b508e8fd40t9o',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b5178e1aa07tt',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b517aaa2d07xl',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb2508c6601mA',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb2508c7b01mH',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb2508c8b01mO',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb2508c9a01mV',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb2508caa01mc',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb36618490CSh',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb366a9080CUp',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb367e6610CYd',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb74473d50EAW',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb744d0d60EC2',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb74550420EE5',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb745ff6d0EH0',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116bb7468dda0EJL',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116abf7391ef0jPe',
  'Passport/ID',
  'Active',
  'OBS - Passport ',
  'C',
  1,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116abf73f05a0jQh',
  'Passport',
  'Active',
  'Passport',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116abf742ce80jR5',
  'Passport/ID',
  'Active',
  'Passport / ID',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116abf76812e0jVy',
  'Passport',
  'Active',
  'Passport',
  'D',
  1,
  '116abf73f05a0jQh',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af335657e031c',
  'Salary Cert.',
  'Active',
  'Salary Certification',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af335fba5032y',
  'Proof of address',
  'Active',
  'Proof of Address',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33acd8203F8',
  'Salary Cert.',
  'Active',
  'Salary Certification',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33b2a1503G8',
  'Proof of address',
  'Active',
  'Proof of address',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33b806203Gh',
  'Driving License',
  'Active',
  'Driving License',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33d38ee03LK',
  'Driving License',
  'Active',
  'Driving License',
  'D',
  0,
  '116af33b806203Gh',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33db53503Mv',
  'Passport',
  'Active',
  'Passport',
  'D',
  0,
  '116abf73f05a0jQh',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33df95a03Oj',
  'Salary Cert.',
  'Active',
  'Salary Certification',
  'D',
  0,
  '116af33acd8203F8',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116af33e96cd03Qf',
  'Proof of address',
  'Active',
  'Proof of address',
  'D',
  0,
  '116af33b2a1503G8',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b035d17880IMM',
  'Salary Cert.',
  'Active',
  'Salary Certification',
  'D',
  0,
  '116af33acd8203F8',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b035d17990IMT',
  'Proof of address',
  'Active',
  'Proof of address',
  'D',
  0,
  '116af33b2a1503G8',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b035d1d290IMe',
  'Proof of address',
  'Active',
  'Proof of address',
  'D',
  0,
  '116af33b2a1503G8',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c62e1f32BW0',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  1,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c669a8a2Bc8',
  'Customer Idenitty',
  'Active',
  'Customer Identity',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6847512Bez',
  'Commercial/Trade Register',
  'Active',
  'Commercial/Trade Register',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c69399d2Bgd',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6a55052BiR',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6aa8312Biz',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6ade7f2Bjo',
  'شهادة وفاة',
  'Active',
  'شهادة وفاة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6b1efb2BkI',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6b606c2Bkm',
  'صك حصر ورثة',
  'Active',
  'صك حصر ورثة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6b99ab2BlE',
  'برنت الاحوال المدنية',
  'Active',
  'برنت الاحوال المدنية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6bd6032Bm4',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6c13292BmY',
  'برنت التأمينات الاجتماعية ',
  'Active',
  'برنت التأمينات الاجتماعية ',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6c57112Bn2',
  ' بطاقة بيطرية من الزراعة ',
  'Active',
  ' بطاقة بيطرية من الزراعة ',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6c9ab92BnW',
  'برنت الأحوال المدنية',
  'Active',
  'برنت الأحوال المدنية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b2c6e2ed72BrR',
  'Registration of the Dealers',
  'Active',
  'Registration of the Dealers
تسجيل اسماء المتعاملين
',
  'C',
  1,
  '116b2c62e1f32BW0',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bd6dd7f1ETZ',
  'تسجيل البيانات الاساسية للطلب',
  'Active',
  'تسجيل البيانات الاساسية للطلب',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bd9b2151EYa',
  'خطاب وزارة الزراعة',
  'Active',
  'خطاب وزارة الزراعة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bd9ee671EZ3',
  'استمارة تقييم المشروع',
  'Active',
  'استمارة تقييم المشروع
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bda24b21EZU',
  'ترخيص اقامة المشروع',
  'Active',
  'ترخيص اقامة المشروع
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bda74fa1Ea4',
  'دراسة الجدوى الفنية والاقتصادية',
  'Active',
  'دراسة الجدوى الفنية والاقتصادية
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdab0de1Eau',
  'اخر ميزانيتين',
  'Active',
  'اخر ميزانيتين
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdafab51EbR',
  'عقد التأسيس',
  'Active',
  'عقد التأسيس
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdb39721Ebu',
  'موافقة مجلس الادارة على طلب القرض',
  'Active',
  'موافقة مجلس الادارة على طلب القرض
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdb78d01EcN',
  'تفويض من مجلس الادارة لمندوب المراجعة',
  'Active',
  'تفويض من مجلس الادارة لمندوب المراجعة
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdbfd291EdX',
  'شهادة السعودة',
  'Active',
  'شهادة السعودة
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdd1f801EfL',
  'شهادة الزكاة والدخل',
  'Active',
  'شهادة الزكاة والدخل
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bdd62e91EgD',
  'خطاب وزارة الشئون الاجتماعية',
  'Active',
  'خطاب وزارة الشئون الاجتماعية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bddcfc31Egt',
  'نموذج طلب',
  'Active',
  'نموذج طلب
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bded3731EiZ',
  'ايصال رسوم الكشف',
  'Active',
  'ايصال رسوم الكشف
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf3442a1FDJ',
  'شهادة خبرة للنحالين',
  'Active',
  'شهادة خبرة للنحالين',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf387ea1FEC',
  'اقرار البائع',
  'Active',
  'اقرار البائع',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf3fee11FEu',
  'اقرار  المشتري',
  'Active',
  'اقرار  المشتري',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf4452b1FFn',
  'اقرار المشتري بالمحافظة على الاعيان',
  'Active',
  'اقرار المشتري بالمحافظة على الاعيان
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf4cb591FGZ',
  'الاستمارة الاولية لمقابلة المقترض(قرض عادي(',
  'Active',
  'الاستمارة الاولية لمقابلة المقترض(قرض عادي',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf520081FH7',
  'اقرار البيانات الائتمانية(سمة)',
  'Active',
  'اقرار البيانات الائتمانية(سمة)',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf54ba31FHu',
  'اقرار بتركيب لوحة',
  'Active',
  'اقرار بتركيب لوحة
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf57a761FIJ',
  'اقرارات (الطلبات)',
  'Active',
  'اقرارات (الطلبات)
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf5abb21FIj',
  'الاستمارة الاولية لمقابلة المقترض(قرض مشاريع',
  'Active',
  'الاستمارة الاولية لمقابلة المقترض(قرض مشاريع
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf5e76c1FJB',
  'خطاب الثروة السمكية',
  'Active',
  'خطاب الثروة السمكية
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3bf6724e1FKN',
  'نموذج تقييم القروض العادية',
  'Active',
  'نموذج تقييم القروض العادية
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3c158e241G9j',
  'رخصة الصيد',
  'Active',
  'رخصة الصيد 
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3c15ed3c1GAK',
  'إقرار تركيب عداد قياس الابار ',
  'Active',
  'إقرار تركيب عداد قياس الابار ',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3c164eea1GBL',
  'السجل الزراعي',
  'Active',
  'السجل الزراعي',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cdc7f931KzY',
  ' نموذج الركائز الثلاث',
  'Active',
  ' نموذج الركائز الثلاث',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cdece5a1L4C',
  'تسجيل البيانات الاساسية للحيازات',
  'Active',
  'تسجيل البيانات الاساسية للحيازات',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cdff1891L68',
  'صورة وثيقة الحيازة',
  'Active',
  'صورة وثيقة الحيازة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce0296c1L6Z',
  'رسم كروكي',
  'Active',
  'رسم كروكي',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce064c11L71',
  'محضر التجزئة',
  'Active',
  'محضر التجزئة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce0a4281L7t',
  'اصل الحيازة',
  'Active',
  'اصل الحيازة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce1b3601L9p',
  'تسجيل بيانات التقرير الفني',
  'Active',
  'تسجيل بيانات التقرير الفني',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce224da1LAc',
  'التقرير الفني',
  'Active',
  'التقرير الفني',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce267271LBU',
  'رخصة حفر البئر',
  'Active',
  'رخصة حفر البئر',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce2a0311LBw',
  'تقرير انتاجية المياه',
  'Active',
  'تقرير انتاجية المياه',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce2d9631LCO',
  'تحليل عينة المياة',
  'Active',
  'تحليل عينة المياة',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce3163b1LCq',
  'خطاب الكشف الفني',
  'Active',
  'خطاب الكشف الفني',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce355f81LDh',
  'خطاب حرس الحدود',
  'Active',
  'خطاب حرس الحدود',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce4b9d81LGF',
  'تسجيل دراسة تكلفة القروض العادية',
  'Active',
  'تسجيل دراسة تكلفة القروض العادية',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce512e01LHK',
  'الدراسة النهائية',
  'Active',
  'الدراسة النهائية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce54c221LHn',
  'عروض الاسعار',
  'Active',
  'عروض الاسعار
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce5805c1LID',
  'خطاب تصدير',
  'Active',
  'خطاب تصدير',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce5be731LIg',
  'خطاب الغاء قرار المنح',
  'Active',
  'خطاب الغاء قرار المنح',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce5f8321LJW',
  'قرار منح/قروض عادية',
  'Active',
  'قرار منح/قروض عادية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce6e6c51LLJ',
  'تسجيل دراسة تكلفة المشاريع المتخصصة',
  'Active',
  'تسجيل دراسة تكلفة المشاريع المتخصصة
',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce855161LNh',
  'خطاب تبليغ',
  'Active',
  'خطاب تبليغ
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce88dd61LO8',
  'خطاب الضمانات',
  'Active',
  'خطاب الضمانات
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce8fb331LPC',
  'مذكرة العرض على المجلس',
  'Active',
  'مذكرة العرض على المجلس
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce932c11LPd',
  'مذكرة العرض على النائب للاتمان',
  'Active',
  'مذكرة العرض على النائب للاتمان
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce966231LQ4',
  'مذكرة العرض على مدير الادارة العامة لتمويل المشاري',
  'Active',
  'مذكرة العرض على مدير الادارة العامة لتمويل المشاريع
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce9a0b81LQu',
  'مذكرة اللجنة للقروض التي تزيد عن 3 ملايين ريال',
  'Active',
  'مذكرة اللجنة للقروض التي تزيد عن 3 ملايين ريال
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ce9dc421LRN',
  'استمارة مقابلة مقترض',
  'Active',
  'استمارة مقابلة مقترض
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cea0e8c1LRn',
  'تقرير لجنة مقابلة المقترض',
  'Active',
  'تقرير لجنة مقابلة المقترض
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cea4e0f1LSG',
  'قرار منح/مشاريع',
  'Active',
  'قرار منح/مشاريع
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cee08b41LYL',
  'تسجيل الاسماء الاضافية',
  'Active',
  'تسجيل الاسماء الاضافية',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cee65ed1LZR',
  'اقرارات الكفلاء',
  'Active',
  'اقرارات الكفلاء
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cee9b611LZs',
  'صك الوكالة/الولاية',
  'Active',
  'صك الوكالة/الولاية
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ceece6c1LaI',
  'خطاب المحكمة',
  'Active',
  'خطاب المحكمة
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3ceefbb91Lah',
  'اقرار البيانات الائتمانية(سمة)/ للكفيل',
  'Active',
  'اقرار البيانات الائتمانية(سمة)/ للكفيل
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf04ecf1LdI',
  'تسجيل بيانات الصكوك المرفقة مع الطلب',
  'Active',
  'تسجيل بيانات الصكوك المرفقة مع الطلب
',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf0cc841Le8',
  'صورة الصك',
  'Active',
  'صورة الصك
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf10cac1Lf0',
  'خطاب رهن الصك',
  'Active',
  'خطاب رهن الصك
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf14d471LfU',
  'خطاب اجراء التثمين',
  'Active',
  'خطاب اجراء التثمين',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf1920c1Lfz',
  'خطاب الكفالة الشخصية',
  'Active',
  'خطاب الكفالة الشخصية
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf1cfa11LgR',
  'مرئيات الادارة القانونية',
  'Active',
  'مرئيات الادارة القانونية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cf2b7511LiD',
  'تسجيل وتثمين الأراضي الزراعية',
  'Active',
  'تسجيل وتثمين الأراضي الزراعية',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cfe802b1M0D',
  'نموذج تقدير ارض زراعية',
  'Active',
  'نموذج تقدير ارض زراعية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cfeb5bf1M11',
  'ملحق نموذج التقدير',
  'Active',
  'ملحق نموذج التقدير',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3cfef2e71M1V',
  'اخرى ، تقدير الارض الزراعية',
  'Active',
  'اخرى ، تقدير الارض الزراعية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d0013461M3c',
  'نموذج تقدير العقار',
  'Active',
  'نموذج تقدير العقار
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d004ec61M43',
  'تسجيل وتثمين العقارات',
  'Active',
  'تسجيل وتثمين العقارات
',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d00f9a21M5W',
  'وثيقة الضمان',
  'Active',
  'وثيقة الضمان
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d0131ba1M5y',
  'الصك المرهون',
  'Active',
  'الصك المرهون
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d0168b11M6n',
  'الضمان البنكي',
  'Active',
  'الضمان البنكي
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d01b2861M7J',
  'مرئيات الادارة القانونية حول الضمانات',
  'Active',
  'مرئيات الادارة القانونية حول الضمانات
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d01e71c1M7k',
  'صك كفالة',
  'Active',
  'صك كفالة
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d022f7b1M8F',
  'رهن أصول المشروع المشمولة بالخدمات الإئتمانية ( ال',
  'Active',
  'رهن أصول المشروع المشمولة بالخدمات الإئتمانية ( المعدات والآلات )
',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d0264681M94',
  'رهن المحافظ الإستثمارية',
  'Active',
  'رهن المحافظ الإستثمارية',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d0291b81M9T',
  'التنازل عن إيرادات العقود',
  'Active',
  'التنازل عن إيرادات العقود',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3d04747d1MCS',
  'تسجيل وثائق الضمان للطلب',
  'Active',
  'تسجيل وثائق الضمان للطلب
',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3daff9791QMT',
  'سند ضمان إضافي لإجراء عقد جديد',
  'Active',
  'سند ضمان إضافي لإجراء عقد جديد',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db02f001QMu',
  'سند ضمان إضافي لإجراء تقويم القسط',
  'Active',
  'سند ضمان إضافي لإجراء تقويم القسط',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db07aa01QNp',
  'سند ضمان إضافي لإجراء العقد تحت الصرف',
  'Active',
  'سند ضمان إضافي لإجراء العقد تحت الصرف',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db0c1011QOK',
  'سند ضمان إضافي لإجراء اعادة جدولة المتبقي',
  'Active',
  'سند ضمان إضافي لإجراء اعادة جدولة المتبقي',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db117c91QOt',
  'سند ضمان إضافي لإجراء تأجيل قسط',
  'Active',
  'سند ضمان إضافي لإجراء تأجيل قسط',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db152ac1QPj',
  'سند ضمان إضافي لإجراء  توزيع قسط',
  'Active',
  'سند ضمان إضافي لإجراء  توزيع قسط',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db183ae1QQA',
  'سند ضمان إضافي لإجراء  تعديل قيمة القسط',
  'Active',
  'سند ضمان إضافي لإجراء  تعديل قيمة القسط',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db1c20a1QQd',
  'سند ضمان إضافي لإجراء  تعديل تواريخ الأقساط',
  'Active',
  'سند ضمان إضافي لإجراء  تعديل تواريخ الأقساط',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db231911QRi',
  'سند ضمان إضافي لإجراء  نقل الدين',
  'Active',
  'سند ضمان إضافي لإجراء  نقل الدين',
  'D',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116b3db2f4981QSi',
  'إصدار سندات الضمان الإضافية',
  'Active',
  'إصدار سندات الضمان الإضافية',
  'C',
  0,
  NULL,
  'C'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da585338805ln',
  'برنت التأمينات الاجتماعية ',
  'Active',
  'برنت التأمينات الاجتماعية ',
  'D',
  1,
  '116b2c6c13292BmY',
  'Y'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58a521305zu',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58b1dfd062q',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58b9042064c',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58bf6bb067A',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58c4e34068u',
  'برنت الاحوال المدنية',
  'Active',
  'برنت الاحوال المدنية',
  'D',
  0,
  '116b2c6b99ab2BlE',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116da58cca9e06Bc',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfb6bb3b00j2',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfb6bb4e00j9',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfb6bb5d00jG',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfb6bb6c00jN',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfb6bb7d00jU',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfbeee45018Z',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfbeee53018g',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfbeee61018n',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfbeee6f018u',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfbeee7d0191',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfc0421201Dc',
  'هوية المتعامل',
  'Active',
  'هوية المتعامل',
  'D',
  0,
  '116b2c69399d2Bgd',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfc0421f01Dj',
  'السجل  التجاري',
  'Active',
  'السجل  التجاري',
  'D',
  0,
  '116b2c6a55052BiR',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfc0422b01Dq',
  'سجل الجمعية التعاونيه',
  'Active',
  'سجل الجمعية التعاونيه',
  'D',
  0,
  '116b2c6aa8312Biz',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfc0423801Dx',
  'نموذج تحديث البيانات',
  'Active',
  'نموذج تحديث البيانات',
  'D',
  0,
  '116b2c6b1efb2BkI',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116dcfc0424401E4',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'Active',
  'اقرار العميل بالموافقة على الاطلاعلى بيان سمه',
  'D',
  0,
  '116b2c6bd6032Bm4',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116eb20b6a0b04t5',
  ' تقرير الإئتمان المالي(سمة)',
  'Active',
  ' تقرير الإئتمان المالي(سمة)',
  'D',
  0,
  '116b3db4e5681QX6',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116eb20486ab03hn',
  ' تقرير الإئتمان المالي(سمة)',
  'Active',
  ' تقرير الإئتمان المالي(سمة)',
  'D',
  0,
  '116b3db4e5681QX6',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENT
(
  CBCATDOCIDPK,
  CBCATDOCNAME,
  CBCATDOCSTATUS,
  CBCATDOCDESCRIPTION,
  CBCATDOCTYPE,
  VERSIONNUM,
  CBPARENTCATDOCID,
  CBISUPDATED
)
VALUES
(
  '116eb208928a04ah',
  ' تقرير الإئتمان المالي(سمة)',
  'Active',
  ' تقرير الإئتمان المالي(سمة)',
  'D',
  0,
  '116b3db4e5681QX6',
  'N'
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cf25c5c1Lhb',
  '116b3cf04ecf1LdI',
  '116b3cf14d471LfU',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cf25c5c1Lhc',
  '116b3cf04ecf1LdI',
  '116b3cf1920c1Lfz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cf25c5c1Lhd',
  '116b3cf04ecf1LdI',
  '116b3cf1cfa11LgR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cff98a81M2i',
  '116b3cf2b7511LiD',
  '116b3cfe802b1M0D',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cff98a81M2j',
  '116b3cf2b7511LiD',
  '116b3cfeb5bf1M11',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cff98a81M2k',
  '116b3cf2b7511LiD',
  '116b3cfef2e71M1V',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d004ed01M44',
  '116b3d004ec61M43',
  '116b3d0013461M3c',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474841MCT',
  '116b3d04747d1MCS',
  '116b3d00f9a21M5W',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCU',
  '116b3d04747d1MCS',
  '116b3d0131ba1M5y',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCV',
  '116b3d04747d1MCS',
  '116b3d0168b11M6n',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCW',
  '116b3d04747d1MCS',
  '116b3d01b2861M7J',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCX',
  '116b3d04747d1MCS',
  '116b3d01e71c1M7k',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCY',
  '116b3d04747d1MCS',
  '116b3d022f7b1M8F',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCZ',
  '116b3d04747d1MCS',
  '116b3d0264681M94',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3d0474851MCa',
  '116b3d04747d1MCS',
  '116b3d0291b81M9T',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSj',
  '116b3db2f4981QSi',
  '116b3daff9791QMT',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSk',
  '116b3db2f4981QSi',
  '116b3db02f001QMu',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSl',
  '116b3db2f4981QSi',
  '116b3db07aa01QNp',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSm',
  '116b3db2f4981QSi',
  '116b3db0c1011QOK',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSn',
  '116b3db2f4981QSi',
  '116b3db117c91QOt',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSo',
  '116b3db2f4981QSi',
  '116b3db152ac1QPj',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSp',
  '116b3db2f4981QSi',
  '116b3db183ae1QQA',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSq',
  '116b3db2f4981QSi',
  '116b3db1c20a1QQd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db2f4a01QSr',
  '116b3db2f4981QSi',
  '116b3db231911QRi',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db438f81QVe',
  '116b3db438f11QVd',
  '116b3db3e6761QUi',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db521f91QXY',
  '116b3db521f21QXX',
  '116b3db4e5681QX6',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db789c01Qbr',
  '116b3db789b91Qbq',
  '116b3db62b321QZP',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db789c01Qbs',
  '116b3db789b91Qbq',
  '116b3db669af1QZs',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3db789c01Qbt',
  '116b3db789b91Qbq',
  '116b3db6b24e1Qal',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3dba11f51QhA',
  '116b3dba11ed1Qh9',
  '116b3db8743b1Qdc',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3dba11f51QhB',
  '116b3dba11ed1Qh9',
  '116b3db8b39b1QeT',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3dba11f51QhC',
  '116b3dba11ed1Qh9',
  '116b3db904c81Qf2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3dba11f51QhD',
  '116b3dba11ed1Qh9',
  '116b3db962321Qfd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3dba11f51QhE',
  '116b3dba11ed1Qh9',
  '116b3db9a6fc1QgW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zh',
  '116b4ab75ce302Zg',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zi',
  '116b4ab75ce302Zg',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zj',
  '116b4ab75ce302Zg',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zk',
  '116b4ab75ce302Zg',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zl',
  '116b4ab75ce302Zg',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zm',
  '116b4ab75ce302Zg',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zn',
  '116b4ab75ce302Zg',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zo',
  '116b4ab75ce302Zg',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zp',
  '116b4ab75ce302Zg',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zq',
  '116b4ab75ce302Zg',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab75ce302Zr',
  '116b4ab75ce302Zg',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3c02gW',
  '116b4ab8da3402gV',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gX',
  '116b4ab8da3402gV',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gY',
  '116b4ab8da3402gV',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gZ',
  '116b4ab8da3402gV',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02ga',
  '116b4ab8da3402gV',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gb',
  '116b4ab8da3402gV',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gc',
  '116b4ab8da3402gV',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gd',
  '116b4ab8da3402gV',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02ge',
  '116b4ab8da3402gV',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3d02gf',
  '116b4ab8da3402gV',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4ab8da3e02gg',
  '116b4ab8da3402gV',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64601mK',
  '116b4b37d63e01mJ',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64701mL',
  '116b4b37d63e01mJ',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64701mM',
  '116b4b37d63e01mJ',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64701mN',
  '116b4b37d63e01mJ',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64701mO',
  '116b4b37d63e01mJ',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64701mP',
  '116b4b37d63e01mJ',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64801mQ',
  '116b4b37d63e01mJ',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64801mR',
  '116b4b37d63e01mJ',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64801mS',
  '116b4b37d63e01mJ',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64901mT',
  '116b4b37d63e01mJ',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b4b37d64901mU',
  '116b4b37d63e01mJ',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NG',
  '116b502d81ee03NF',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NH',
  '116b502d81ee03NF',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NI',
  '116b502d81ee03NF',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NJ',
  '116b502d81ee03NF',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NK',
  '116b502d81ee03NF',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NL',
  '116b502d81ee03NF',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f603NM',
  '116b502d81ee03NF',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f703NN',
  '116b502d81ee03NF',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f703NO',
  '116b502d81ee03NF',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f703NP',
  '116b502d81ee03NF',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b502d81f703NQ',
  '116b502d81ee03NF',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116abf742cef0jR6',
  '116abf742ce80jR5',
  '116abf73f05a0jQh',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116af33beff703HS',
  '116af335657e031c',
  '116af33acd8203F8',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116af33c1c8103IG',
  '116af335fba5032y',
  '116af33b2a1503G8',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32Bt9',
  '116b2c62e1f32BW0',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtA',
  '116b2c62e1f32BW0',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtB',
  '116b2c62e1f32BW0',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtC',
  '116b2c62e1f32BW0',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtD',
  '116b2c62e1f32BW0',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtE',
  '116b2c62e1f32BW0',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtF',
  '116b2c62e1f32BW0',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtG',
  '116b2c62e1f32BW0',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtH',
  '116b2c62e1f32BW0',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtI',
  '116b2c62e1f32BW0',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbb32BtJ',
  '116b2c62e1f32BW0',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtN',
  '116b2c6e2ed72BrR',
  '116b2c6c9ab92BnW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtO',
  '116b2c6e2ed72BrR',
  '116b2c6c57112Bn2',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtP',
  '116b2c6e2ed72BrR',
  '116b2c6c13292BmY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtQ',
  '116b2c6e2ed72BrR',
  '116b2c6bd6032Bm4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtR',
  '116b2c6e2ed72BrR',
  '116b2c6b99ab2BlE',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtS',
  '116b2c6e2ed72BrR',
  '116b2c6b606c2Bkm',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtT',
  '116b2c6e2ed72BrR',
  '116b2c6b1efb2BkI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtU',
  '116b2c6e2ed72BrR',
  '116b2c6ade7f2Bjo',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtV',
  '116b2c6e2ed72BrR',
  '116b2c6aa8312Biz',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtW',
  '116b2c6e2ed72BrR',
  '116b2c6a55052BiR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b2c6ecbc02BtX',
  '116b2c6e2ed72BrR',
  '116b2c69399d2Bgd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab01L2a',
  '116b3bd6dd7f1ETZ',
  '116b3bd9b2151EYa',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2b',
  '116b3bd6dd7f1ETZ',
  '116b3bd9ee671EZ3',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2c',
  '116b3bd6dd7f1ETZ',
  '116b3bda24b21EZU',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2d',
  '116b3bd6dd7f1ETZ',
  '116b3bda74fa1Ea4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2e',
  '116b3bd6dd7f1ETZ',
  '116b3bdab0de1Eau',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2f',
  '116b3bd6dd7f1ETZ',
  '116b3bdafab51EbR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2g',
  '116b3bd6dd7f1ETZ',
  '116b3bdb39721Ebu',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2h',
  '116b3bd6dd7f1ETZ',
  '116b3bdb78d01EcN',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab11L2i',
  '116b3bd6dd7f1ETZ',
  '116b3bdbfd291EdX',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2j',
  '116b3bd6dd7f1ETZ',
  '116b3bdd1f801EfL',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2k',
  '116b3bd6dd7f1ETZ',
  '116b3bdd62e91EgD',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2l',
  '116b3bd6dd7f1ETZ',
  '116b3bddcfc31Egt',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2m',
  '116b3bd6dd7f1ETZ',
  '116b3bded3731EiZ',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2n',
  '116b3bd6dd7f1ETZ',
  '116b3bf3442a1FDJ',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2o',
  '116b3bd6dd7f1ETZ',
  '116b3bf387ea1FEC',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2p',
  '116b3bd6dd7f1ETZ',
  '116b3bf3fee11FEu',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2q',
  '116b3bd6dd7f1ETZ',
  '116b3bf4452b1FFn',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab21L2r',
  '116b3bd6dd7f1ETZ',
  '116b3bf4cb591FGZ',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2s',
  '116b3bd6dd7f1ETZ',
  '116b3bf520081FH7',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2t',
  '116b3bd6dd7f1ETZ',
  '116b3bf54ba31FHu',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2u',
  '116b3bd6dd7f1ETZ',
  '116b3bf57a761FIJ',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2v',
  '116b3bd6dd7f1ETZ',
  '116b3bf5abb21FIj',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2w',
  '116b3bd6dd7f1ETZ',
  '116b3bf5e76c1FJB',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2x',
  '116b3bd6dd7f1ETZ',
  '116b3bf6724e1FKN',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2y',
  '116b3bd6dd7f1ETZ',
  '116b3cdc7f931KzY',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab31L2z',
  '116b3bd6dd7f1ETZ',
  '116b3c158e241G9j',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab41L30',
  '116b3bd6dd7f1ETZ',
  '116b3c15ed3c1GAK',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cde4ab41L31',
  '116b3bd6dd7f1ETZ',
  '116b3c164eea1GBL',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce15c451L98',
  '116b3cdece5a1L4C',
  '116b3cdff1891L68',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce15c451L99',
  '116b3cdece5a1L4C',
  '116b3ce0296c1L6Z',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce15c451L9A',
  '116b3cdece5a1L4C',
  '116b3ce064c11L71',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce15c451L9B',
  '116b3cdece5a1L4C',
  '116b3ce0a4281L7t',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFf',
  '116b3ce1b3601L9p',
  '116b3ce224da1LAc',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFg',
  '116b3ce1b3601L9p',
  '116b3ce267271LBU',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFh',
  '116b3ce1b3601L9p',
  '116b3ce2a0311LBw',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFi',
  '116b3ce1b3601L9p',
  '116b3ce2d9631LCO',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFj',
  '116b3ce1b3601L9p',
  '116b3ce3163b1LCq',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce473861LFk',
  '116b3ce1b3601L9p',
  '116b3ce355f81LDh',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce693c91LKJ',
  '116b3ce4b9d81LGF',
  '116b3ce512e01LHK',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce693c91LKK',
  '116b3ce4b9d81LGF',
  '116b3ce54c221LHn',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce693c91LKL',
  '116b3ce4b9d81LGF',
  '116b3ce5805c1LID',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce693c91LKM',
  '116b3ce4b9d81LGF',
  '116b3ce5be731LIg',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3ce693c91LKN',
  '116b3ce4b9d81LGF',
  '116b3ce5f8321LJW',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4501LXb',
  '116b3ce6e6c51LLJ',
  '116b3ce512e01LHK',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4501LXc',
  '116b3ce6e6c51LLJ',
  '116b3ce5805c1LID',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4501LXd',
  '116b3ce6e6c51LLJ',
  '116b3ce5be731LIg',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4501LXe',
  '116b3ce6e6c51LLJ',
  '116b3ce855161LNh',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXf',
  '116b3ce6e6c51LLJ',
  '116b3ce88dd61LO8',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXg',
  '116b3ce6e6c51LLJ',
  '116b3ce8fb331LPC',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXh',
  '116b3ce6e6c51LLJ',
  '116b3ce932c11LPd',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXi',
  '116b3ce6e6c51LLJ',
  '116b3ce966231LQ4',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXj',
  '116b3ce6e6c51LLJ',
  '116b3ce9a0b81LQu',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXk',
  '116b3ce6e6c51LLJ',
  '116b3ce9dc421LRN',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXl',
  '116b3ce6e6c51LLJ',
  '116b3cea0e8c1LRn',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cedb4511LXm',
  '116b3ce6e6c51LLJ',
  '116b3cea4e0f1LSG',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cef9f331Lbu',
  '116b3cee08b41LYL',
  '116b3cee65ed1LZR',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cef9f331Lbv',
  '116b3cee08b41LYL',
  '116b3cee9b611LZs',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cef9f331Lbw',
  '116b3cee08b41LYL',
  '116b3ceece6c1LaI',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cef9f331Lbx',
  '116b3cee08b41LYL',
  '116b3ceefbb91Lah',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cf25c5c1LhZ',
  '116b3cf04ecf1LdI',
  '116b3cf0cc841Le8',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116b3cf25c5c1Lha',
  '116b3cf04ecf1LdI',
  '116b3cf10cac1Lf0',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116df8237dce0bBt',
  '116df8237dc90bBs',
  '116af33b806203Gh',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116e1c5c030a04J3',
  '116e1c5c030104J2',
  '116df8235ed40bBZ',
  0
);

INSERT INTO CBS.CBTB_CATEGORYDOCUMENTMAP
(
  CBCATDOCMAPIDPK,
  CBCATEGORYID,
  CBDOCUMENTID,
  VERSIONNUM
)
VALUES
(
  '116e1c60eb1604aK',
  '116e1c60eb0e04aJ',
  '116df8235ed40bBZ',
  0
);

INSERT INTO CBS.CBTB_RULEFACTOR
(
  CBFACTORIDPK,
  CBNAME,
  CBSTATUS,
  CBDESCRIPTION,
  CBSOURCE,
  CBFORMULATEXT,
  CBFORMULATYPE,
  VERSIONNUM
)
VALUES
(
  '116e1cb8b28e0AEw',
  'Age',
  'ACTIVE',
  'Age Factor',
  'System Parameter + Formula',
  'IslamicBankingRule1207',
  'Fixed',
  1
);

INSERT INTO CBS.CBTB_RULEFACTORSYSPARAMMAP
(
  CBRULEFACTORSYSPARAMMAPIDPK,
  CBSYSTEMPARAMETERSID,
  CBFACTORID,
  CBATTRIBUTEORDER,
  CBPARAMETERTYPE,
  VERSIONNUM
)
VALUES
(
  '116e1cc3e1470AY2',
  '1473892757',
  '116e1cb8b28e0AEw',
  1,
  'Range',
  0
);

