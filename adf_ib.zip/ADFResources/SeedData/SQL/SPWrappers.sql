CREATE OR REPLACE PROCEDURE            CUSTOMEXTN.ExecuteSP2 ( sp_name varchar2, v_toolno number , v_grp_cd number ,
v_var1 number , v_var2 number , v_var3 number , v_var4 number , v_var5 number ,
v_res1 out number , v_res2 out number , v_res3 out number ,v_res4 out number,
okval out varchar2 , msg out  varchar2 , v_cur_listser number default null , v_bld number default null  ,
 v_stdy_ach_flg number default 1  , v_dealno varchar2 default null ) IS

v_res11 number ;
v_res12 number ;
v_res13 number ;
v_res14 number ;
okval1 boolean ;
msg1 varchar2(100);
--v_cur_listser1 number;
--v_stdy_ach_flg1 number;
--v_bld1 number;
vstring varchar2(1000);
BEGIN
      vstring := 'begin ' || sp_name || '(:v_toolno,:v_grp_cd,:v_var1,:v_var2,:v_var3,:v_var4,:v_var5,:v_res11,:v_res12,:v_res13,:v_res14,:okval1,:msg1,:v_cur_listser,:v_bld,:v_stdy_ach_flg,:v_dealno); end;';
      execute immediate vstring
	  using in v_toolno, in v_grp_cd, in v_var1, in v_var2, in v_var3, in v_var4, in v_var5, out v_res11, out v_res12, out v_res13, out v_res14, out okval1, out msg1, in v_cur_listser,in v_bld, in v_stdy_ach_flg, in v_dealno;

	 v_res1 := v_res11 ;
	 v_res2 := v_res12 ;
	 v_res3 := v_res13 ;
	 v_res4 := v_res14 ;
	 -- okval := okval1 ;
	 msg := msg1 ;
	 
	 okval := 'f';
	 if okval1 = true then
	 	okval := 't';
	 end if;
END;
@

CREATE OR REPLACE PROCEDURE            CUSTOMEXTN.ExecuteSP3 ( sp_name varchar2, v_toolno number , v_grp_cd number ,
v_var1 number , v_var2 number , v_var3 number , v_var4 number , v_var5 number ,
v_res1 out number , v_res2 out number , v_res3 out number , v_res4 out number,
okval out varchar2 , msg out varchar2 , v_cur_listser number default null   ,
 v_stdy_ach_flg number default 1  , v_dealno varchar2 default null ) IS

v_res11 number ;
v_res12 number ;
v_res13 number ;
v_res14 number ;
okval1 boolean ;
msg1 varchar2(100);
--v_cur_listser1 number;
--v_stdy_ach_flg1 number;
vstring varchar2(1000);
BEGIN
      vstring := 'begin ' || sp_name || '(:v_toolno,:v_grp_cd,:v_var1,:v_var2,:v_var3,:v_var4,:v_var5,:v_res11,:v_res12,:v_res13,:v_res14,:okval1,:msg1,:v_cur_listser,:v_stdy_ach_flg,:v_dealno); end;';
      execute immediate vstring
	  using in v_toolno, in v_grp_cd, in v_var1, in v_var2, in v_var3, in v_var4, in v_var5, out v_res11, out v_res12, out v_res13, out v_res14, out okval1, out msg1, in v_cur_listser, in v_stdy_ach_flg, in v_dealno;

	 v_res1 := v_res11 ;
	 v_res2 := v_res12 ;
	 v_res3 := v_res13 ;
	 v_res4 := v_res14 ;
	 -- okval := okval1 ;
	 msg := msg1 ;
	 
	 okval := 'f';
	 if okval1 = true then
	 	okval := 't';
	 end if;
END;
@
CREATE OR REPLACE PROCEDURE           CUSTOMEXTN.ExecuteSP4 ( sp_name varchar2, v_toolno number , v_grp_cd number ,
v_var1 number , v_var2 number , v_var3 number , v_var4 number , v_var5 number ,
v_res1 out number , v_res2 out number , v_res3 out number ,v_res4 out number,
 v_txt_res out varchar2 , okval out varchar2 , msg out varchar2  ,
 v_cur_listser number default null , v_stdy_ach_flg number default 1 , v_dealno varchar2 default null ) IS

v_res11 number ;
v_res12 number ;
v_res13 number ;
v_res14 number ;
okval1 boolean ;
msg1 varchar2(100);
--v_cur_listser1 number;
--v_stdy_ach_flg1 number;
v_txt_res1 varchar2(100);
vstring varchar2(1000);
BEGIN
      vstring := 'begin ' || sp_name || '(:v_toolno,:v_grp_cd,:v_var1,:v_var2,:v_var3,:v_var4,:v_var5,:v_res11,:v_res12,:v_res13,:v_res14,:v_txt_res1,:okval1,:msg1,:v_cur_listser,:v_stdy_ach_flg,:v_dealno); end;';
      execute immediate vstring
	  using in v_toolno, in v_grp_cd, in v_var1, in v_var2, in v_var3, in v_var4, in v_var5, out v_res11, out v_res12, out v_res13, out v_res14,out v_txt_res1, out okval1, out msg1, in v_cur_listser, in v_stdy_ach_flg, in v_dealno;

	 v_res1 := v_res11 ;
	 v_res2 := v_res12 ;
	 v_res3 := v_res13 ;
	 v_res4 := v_res14 ;
	 -- okval := okval1 ;
	 msg := msg1 ;
	 v_txt_res :=v_txt_res1;
	 okval := 'f';
	 if okval1 = true then
	 	okval := 't';
	 end if;
END;
@
