package com.misys.ce.restcontroller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ce.party.CEValidateNationalID;
import com.trapedza.bankfusion.core.CommonConstants;


@RestController
@RequestMapping("CEValidation")
public class ValidateNationalIDController {
	
	private transient final static Log logger = LogFactory.getLog(ValidateNationalIDController.class.getName());

	@RequestMapping(value = { "/checkValidNationalId/{nationalId}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET }, headers = { "Accept=application/json" })
	public String isValidNationalId(@PathVariable String nationalId
									 ) {
		
		CEValidateNationalID validator = new CEValidateNationalID();
		boolean response = validator.isValidNationalID(nationalId);
		
		if(response) {
		return CommonConstants.Y;
		}
		
		
		return CommonConstants.N;	
		
	}

}
