package com.misys.ce.restcontroller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ce.party.CEValidatePartyName;
@RestController
@RequestMapping("ValidatePartyArabicName")
public class ValidatePartyArabicName {

	
	private transient final static Log logger = LogFactory.getLog(ValidatePartyArabicName.class.getName());

	@RequestMapping(value = { "/checkValidPartyName/{partyName}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET }, headers = { "Accept=application/json" })
	public String checkValidPartyName(@PathVariable String partyName) {
		
		CEValidatePartyName validatorPartyName = new CEValidatePartyName();
		String Response = validatorPartyName.isValidPartyName(partyName);
		return Response;
		
	}
	
}
