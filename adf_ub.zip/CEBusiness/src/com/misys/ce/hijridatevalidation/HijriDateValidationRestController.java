package com.misys.ce.hijridatevalidation;

import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trapedza.bankfusion.core.CommonConstants;

@RestController
@RequestMapping("HijriDateValidationRestController")
public class HijriDateValidationRestController {
	private transient final static Log logger = LogFactory.getLog(HijriDateValidationRestController.class.getName());

	@RequestMapping(value = { "/getHijriDate/{guarrenteDocDate}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET }, headers = { "Accept=application/json" })
	public String getHijriDate(@PathVariable String guarrenteDocDate) {
		String status = CommonConstants.Y;
		DateTimeFormatter hijrahFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
				.withChronology(HijrahChronology.INSTANCE);
		try {
			HijrahDate date = hijrahFormatter.parse(guarrenteDocDate, HijrahDate::from);
			if (logger.isInfoEnabled())
				logger.info("HijriDateValidationRestController:getHijriDate: A valid date entered:" + date);
		} catch (DateTimeParseException dtpe) {
			logger.error("HijriDateValidationRestController:getHijriDate: invalid date entered:" + guarrenteDocDate
					+ " :Error:" + dtpe.getLocalizedMessage());
			return CommonConstants.N;
		}
		return status;
	}

}
