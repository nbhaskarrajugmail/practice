package com.misys.ce.hijridatevalidation;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("HijriDateConversionPartyStatusRestController")

public class HijriDateConversionPartyStatusRestController {


	private transient final static Log logger = LogFactory.getLog(HijriDateConversionPartyStatusRestController.class.getName());

	@RequestMapping(value = { "/getHijriDate/{deceasedDate}" }, method = {
			org.springframework.web.bind.annotation.RequestMethod.GET }, headers = { "Accept=application/json" })
	public Date getHijriDate(@PathVariable String deceasedDate) {
		//String status = CommonConstants.Y
		// conversion of hijri to Gregorian
		String DateArr[] = deceasedDate.split("-");
	       HijrahDate hijriDate = HijrahChronology.INSTANCE.date(Integer.parseInt(DateArr[2]), Integer.parseInt(DateArr[1]), Integer.parseInt(DateArr[0]));
	       DateTimeFormatter customFormatterGregorian = DateTimeFormatter.ofPattern("MM-dd-yyyy");
	       String gregorianDateInString = IsoChronology.INSTANCE.date(hijriDate).format(customFormatterGregorian);
	       DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
	       dateFormat.setLenient(false);
	       Date gregorianDate = null;
	       try {
			 gregorianDate = dateFormat.parse(gregorianDateInString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//DateTimeFormatter hijrahFormatter = DateTimeFormatter.ofPattern("MM-dd-yyyy")
				//.withChronology(HijrahChronology.INSTANCE);
		try {
			HijrahDate date = customFormatterGregorian.parse(deceasedDate, HijrahDate::from);
			if (logger.isInfoEnabled())
				logger.info("HijriDateValidationRestController:getHijriDate: A valid date entered:" + date);
		} catch (DateTimeParseException dtpe) {
			logger.error("HijriDateValidationRestController:getHijriDate: invalid date entered:" + deceasedDate
					+ " :Error:" + dtpe.getLocalizedMessage());
			//return CommonConstants.N;
		}
		return gregorianDate;
		
	}





}
