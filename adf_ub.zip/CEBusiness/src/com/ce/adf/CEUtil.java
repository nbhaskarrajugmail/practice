package com.ce.adf;

import static com.ce.adf.CEConstants.*;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.cbs.config.ModuleConfiguration;

public class CEUtil {
	/** Added By Subhajit */
	private transient final static Log logger = LogFactory.getLog(CEUtil.class.getName());
	/** **/
	static DateFormat expDateFormat = new SimpleDateFormat("yyyy-MM-dd");
	// List of all date formats that we want to parse.
	@SuppressWarnings("serial")
	private List<SimpleDateFormat> dateFormats = new ArrayList<SimpleDateFormat>() {
		{
			add(new SimpleDateFormat("yyyy/MM/dd"));
			add(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"));
			add(new SimpleDateFormat("dd-MM-yyyy"));
		}
	};

	public String convertStringToDate(String input) {
		String formatedDate = null;
		Date date = null;
		if (isNotEmpty(input)) {
			for (SimpleDateFormat format : dateFormats) {
				try {
					format.setLenient(false);
					date = format.parse(input);
					formatedDate = expDateFormat.format(date);
				} catch (ParseException e) {
				}
				if (formatedDate != null)
					break;
			}
		}
		return formatedDate;
	}

	public static Boolean isNotEmpty(String input) {
		if (input == null || input == EMPTY || input.isEmpty() || input.equalsIgnoreCase("null"))
			return false;
		else
			return true;
	}

	public static String getDate() throws Exception {
		Calendar cal = Calendar.getInstance();
		return expDateFormat.format(cal.getTime());
	}

	/** Added by Subhajit
	 * 
	 * @param moduleName
	 * @param paramName
	 * @return */
	public String getModuleConfigurationValue(String moduleName, String paramName) {
		String moduleValue = ModuleConfiguration.getInstance()
				.getModuleConfigurationValue(moduleName, paramName).toString();
		if (moduleValue == null || moduleValue == CommonConstants.EMPTY_STRING) {
			if (logger.isErrorEnabled())
				logger.error("Module configuration not defined for ModuleName " + moduleName
						+ " and ParamName= " + paramName);
		}
		return moduleValue;
	}
	public static Timestamp getTimeStamp() {
		 Date date= new Date();
		 long time = date.getTime();
		 Timestamp ts = new Timestamp(time);
		 return ts;
	}
}
