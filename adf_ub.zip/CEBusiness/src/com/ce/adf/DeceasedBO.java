package com.ce.adf;

import java.math.BigDecimal;
import java.sql.Date;

public class DeceasedBO {
	 
		private String 	loanAcctNo;
		private String 	loanBranch;	
		private String 	borrowerNationalID;
		private String 	borrowerName;	
		private String 	alhafizaNo;	
		private String 	alhafizaSrc;
		private String 	alhafizaDate;	
		private String 	repFullName;	
		private String 	repNationalID;	
		private String 	repContactNo;	
		private Date 	regDate;	
		private Date 	daethDate;	
		private String 	refNo;		
		private Date 	refStartDate;	
		private Date 	refEndDate;	
		private String 	uploadBy;	
		private Date 	uploadedDate;	
		private String 	uploadStatus;	
		private String 	failurReason;	
		private String 	isApproved;
		private String 	approverID;	
		private Date 	approvedDate;	
		private Date 	downloadBatchDate;
		private String 	downloadBatchNo;	
		private String 	userRemarks;
		private String 	loanPlace;
		private BigDecimal outstanding;
		
		
		public String getLoanPlace(){
			return loanPlace;
		}
		
		public void setLoanPlace(String lplace){
			loanPlace = lplace;
		}
		
		public String getLoanAcctNo() {
			return loanAcctNo;
		}

		public void setLoanAcctNo(String loanAcctNo) {
			this.loanAcctNo = loanAcctNo;
		}

		public String getLoanBranch() {
			return loanBranch;
		}

		public void setLoanBranch(String loanBranch) {
			this.loanBranch = loanBranch;
		}

		public String getBorrowerNationalID() {
			return borrowerNationalID;
		}

		public void setBorrowerNationalID(String borrowerNationalID) {
			this.borrowerNationalID = borrowerNationalID;
		}

		public String getBorrowerName() {
			return borrowerName;
		}

		public void setBorrowerName(String borrowerName) {
			System.out.println("Borrower Name:"+borrowerName);
			this.borrowerName = borrowerName;
		}

		public String getAlhafizaNo() {
			return alhafizaNo;
		}

		public void setAlhafizaNo(String alhafizaNo) {
			this.alhafizaNo = alhafizaNo;
		}

		public String getAlhafizaSrc() {
			return alhafizaSrc;
		}

		public void setAlhafizaSrc(String alhafizaSrc) {
			this.alhafizaSrc = alhafizaSrc;
		}

		public String getAlhafizaDate() {
			return alhafizaDate;
		}

		public void setAlhafizaDate(String alhafizaDate) {
			this.alhafizaDate = alhafizaDate;
		}

		public String getRepFullName() {
			return repFullName;
		}

		public void setRepFullName(String repFullName) {
			this.repFullName = repFullName;
		}

		public String getRepNationalID() {
			return repNationalID;
		}

		public void setRepNationalID(String repNationalID) {
			this.repNationalID = repNationalID;
		}

		public String getRepContactNo() {
			return repContactNo;
		}

		public void setRepContactNo(String repContactNo) {
			this.repContactNo = repContactNo;
		}

		public Date getRegDate() {
			return regDate;
		}

		public void setRegDate(Date regDate) {
			this.regDate = regDate;
		}

		public Date getDaethDate() {
			return daethDate;
		}

		public void setDaethDate(Date daethDate) {
			this.daethDate = daethDate;
		}

		public String getRefNo() {
			return refNo;
		}

		public void setRefNo(String refNo) {
			this.refNo = refNo;
		}

		public Date getRefStartDate() {
			return refStartDate;
		}

		public void setRefStartDate(Date refStartDate) {
			this.refStartDate = refStartDate;
		}

		public Date getRefEndDate() {
			return refEndDate;
		}

		public void setRefEndDate(Date refEndDate) {
			this.refEndDate = refEndDate;
		}

		public String getUploadBy() {
			return uploadBy;
		}

		public void setUploadBy(String uploadBy) {
			this.uploadBy = uploadBy;
		}

		public Date getUploadedDate() {
			return uploadedDate;
		}

		public void setUploadedDate(Date uploadedDate) {
			this.uploadedDate = uploadedDate;
		}

		public String getUploadStatus() {
			return uploadStatus;
		}

		public void setUploadStatus(String uploadStatus) {
			this.uploadStatus = uploadStatus;
		}

		public String getFailurReason() {
			return failurReason;
		}

		public void setFailurReason(String failurReason) {
			this.failurReason = failurReason;
		}

		public String getIsApproved() {
			return isApproved;
		}

		public void setIsApproved(String isApproved) {
			this.isApproved = isApproved;
		}

		public String getApproverID() {
			return approverID;
		}

		public void setApproverID(String approverID) {
			this.approverID = approverID;
		}

		public Date getApprovedDate() {
			return approvedDate;
		}

		public void setApprovedDate(Date approvedDate) {
			this.approvedDate = approvedDate;
		}

		public Date getDownloadBatchDate() {
			return downloadBatchDate;
		}

		public void setDownloadBatchDate(Date downloadBatchDate) {
			this.downloadBatchDate = downloadBatchDate;
		}

		public String getDownloadBatchNo() {
			return downloadBatchNo;
		}

		public void setDownloadBatchNo(String downloadBatchNo) {
			this.downloadBatchNo = downloadBatchNo;
		}

		public String getUserRemarks() {
			return userRemarks;
		}

		public void setUserRemarks(String userRemarks) {
			this.userRemarks = userRemarks;
		}

	    public DeceasedBO(){}
	 
	    public DeceasedBO(String name, String maths, String science, String english) {
	        this.borrowerNationalID = borrowerNationalID;
	        this.borrowerName = borrowerName;
	        this.alhafizaNo = alhafizaNo;
	        this.alhafizaSrc = alhafizaSrc;
	    }

		public BigDecimal getOutstanding() {
			return outstanding;
		}

		public void setOutstanding(BigDecimal outstanding) {
			this.outstanding = outstanding;
		}
	 
}