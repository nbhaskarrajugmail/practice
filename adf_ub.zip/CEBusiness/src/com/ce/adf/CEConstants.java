package com.ce.adf;

public class CEConstants {
	public static final String EMPTY = "";
	public static final String F = "Failed";
	public static final String S = "Success";
	public static final String PARTIAL = "Partial";

	public static final String currencyCode = "SAR";
	public static final String CE_SADAD_INTERFACE = "CESADADINTERFACE";

	// Party
	public static final String personalParty = "1062";
	public static final String DeceasedDocType = "Death Certificate";

	// Event Code
	public static final int CE_DEATH_CERT_NOT_UPLOADED = 44000015;
	public static final int CE_BATCHGATEWAY_SUCESS = 44000016;
	public static final int CE_BATCHGATEWAY_FAIL = 44000017;

	// Module Config
	public static final String BAT_MODULE_NAME = "BAT";
	public static final String BAT_BG_MODULE_FPATH = "DefaultFilePath";

	// ELM_Yakeen Endpoint
	public static final String ELM_Yakeen_URL = "ELM_Yakeen_URL";

}