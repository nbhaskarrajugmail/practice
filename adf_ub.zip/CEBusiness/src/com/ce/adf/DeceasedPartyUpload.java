package com.ce.adf;

import static com.ce.adf.CEConstants.F;
import static com.ce.adf.CEConstants.S;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;


//import oracle.jdbc.pool.OracleDataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ce.party.CE_PTY_DeceassedprtyUpload;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PTY_DeceasedPartyDtls;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyDetailsView;
import com.trapedza.bankfusion.core.CommonConstants;
 
public class DeceasedPartyUpload {
	
		Log logger = LogFactory.getLog(CE_PTY_DeceassedprtyUpload.class);
		CEUtil ceUtil = new CEUtil();
		private BigDecimal outStandingAmt;
				
	    public void uploadXLData(String filePath) throws SQLException {
//	    	DeceasedPartyUpload readExcel = new DeceasedPartyUpload();
	    	processDeceasedRecord(filePath);
	    }
	    
	    private void processDeceasedRecord(String filePath) throws SQLException{
	    	 uploadDeceasedRecords(filePath);
	    }
	 
	    private void uploadDeceasedRecords(String filePath) throws SQLException {
	    	try{
	    		List<DeceasedBO> deceasedRecords = getDeceasedRecordsFromExcel(filePath);
	        	setDeceasedRecords(deceasedRecords);
	        	logger.info("Record inserted");
	    	}
	    	catch(Exception e){
	    		e.printStackTrace();
	    	}
	    	finally{
	    	}
	    	
		}
	    
	    private void setDeceasedRecords(List<DeceasedBO> deceasedList) throws Exception{
	        Date date = new Date(0);  
	        
	    	String userID =  BankFusionThreadLocal.getBankFusionEnvironment().getUserID();
	    	IBOCE_PTY_DeceasedPartyDtls ptyDtls = null;
	    	for(DeceasedBO deceasedDetail : deceasedList){
    		if(deceasedDetail.getLoanAcctNo()!=null) {
	    			ptyDtls = (IBOCE_PTY_DeceasedPartyDtls)BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_PTY_DeceasedPartyDtls.BONAME, deceasedDetail.getLoanAcctNo(), true);
	    		}
	    		
	    		if(ptyDtls!=null)
	    			continue;
	    		if(deceasedDetail.getAlhafizaNo() != null){
//	    			System.out.println(" ");
	    			logger.info("Loan No: "+deceasedDetail.getLoanAcctNo() + ""+deceasedDetail.getRefStartDate());
	    			String loanAcctNo = deceasedDetail.getLoanAcctNo();
	    			String nationalID = deceasedDetail.getBorrowerNationalID();
	    			
	    			String failureMsg = validateLoanDetails(loanAcctNo, nationalID);
	    			logger.info("isValidLoan: "+failureMsg);
	    			
	    			ptyDtls = (IBOCE_PTY_DeceasedPartyDtls)BankFusionThreadLocal.getPersistanceFactory().getStatelessNewInstance(IBOCE_PTY_DeceasedPartyDtls.BONAME);
	    			ptyDtls.setBoID(deceasedDetail.getLoanAcctNo());
	    			ptyDtls.setF_ALHAFIZADT(Integer.parseInt(deceasedDetail.getAlhafizaDate()));
	    			ptyDtls.setF_LOANBR(deceasedDetail.getLoanBranch());
	    			ptyDtls.setF_ALHAFIZANO(deceasedDetail.getAlhafizaNo());
	    			ptyDtls.setF_ALHAFIZASRC(deceasedDetail.getAlhafizaSrc());
	    			ptyDtls.setF_APPROVED(false);
	    			ptyDtls.setF_APPROVEDDT(SystemInformationManager.getInstance().getBFBusinessDate());
	    			ptyDtls.setF_APPROVERID(userID);
	    			ptyDtls.setF_BORROWERNAME(deceasedDetail.getBorrowerName());
	    			ptyDtls.setF_BORROWERNATID(Integer.parseInt(deceasedDetail.getBorrowerNationalID()));
	    			ptyDtls.setF_DAETHDATE( deceasedDetail.getDaethDate());
	    			ptyDtls.setF_LOANPLACE(deceasedDetail.getLoanPlace());
	    			ptyDtls.setF_REFENDDT(deceasedDetail.getRefEndDate());
	    			ptyDtls.setF_REFNO(Integer.parseInt(deceasedDetail.getRefNo()));
	    			ptyDtls.setF_REFSTARTDT(deceasedDetail.getRefStartDate());
	    			ptyDtls.setF_REGDATE(deceasedDetail.getRegDate());
	    			logger.info("Failure Message"+failureMsg);
	    			
	    			ptyDtls.setF_REJREASON(failureMsg);
	    			ptyDtls.setF_REMARKS(" ");
	    			ptyDtls.setF_REPCONTACNO(deceasedDetail.getRepContactNo());
	    			ptyDtls.setF_REPFULLNAME(deceasedDetail.getRepFullName());
	    			ptyDtls.setF_REPNATID(Integer.parseInt(deceasedDetail.getRepNationalID()));
	    			ptyDtls.setF_ULDT(SystemInformationManager.getInstance().getBFBusinessDate());
	    			ptyDtls.setF_ULSTATUS(failureMsg != "" ? F : S);
	    			ptyDtls.setF_UPUSERID(userID);
	    			ptyDtls.setF_OUTSTANDINGAMT(outStandingAmt);
	    			BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_PTY_DeceasedPartyDtls.BONAME, ptyDtls);
	    			
	    			
	    		}
	    		
	    	}
	    	
	    }

		private List<DeceasedBO> getDeceasedRecordsFromExcel(String filePath) {
	        List<DeceasedBO> studentList = new ArrayList<DeceasedBO>();
	        FileInputStream fis = null;
	        String startDate = null;
	        String endDate = null;
	       logger.info("In Deceased Recrds Read method");
	        try {
	            fis = new FileInputStream(filePath);
	            DataFormatter formatter = new DataFormatter(Locale.US);
	            Workbook workbook = null;
	            // Using XSSF for xlsx format, for xls use HSSF
	            //Workbook workbook = new XSSFWorkbook(fis);
	            
	            try {
					workbook = WorkbookFactory.create(new File(filePath));
				} catch (InvalidFormatException e) {
					logger.info("Exception during reading file");
					e.printStackTrace();
				}
	 
	            int numberOfSheets = workbook.getNumberOfSheets();
	 
	            //looping over each workbook sheet
	            for (int i = 0; i < numberOfSheets; i++) {
	                Sheet sheet = workbook.getSheetAt(i);
	                Iterator<Row> rowIterator = sheet.iterator();
	                
	                //iterating over each row
	                while (rowIterator.hasNext()) {
	                    Row row = (Row) rowIterator.next();
	                    Iterator<Cell> cellIterator = row.cellIterator();
	                    DeceasedBO deceasedBO = new DeceasedBO();
	 
	                    //Iterating over each cell (column wise)  in a particular row.
	                    while (cellIterator.hasNext()) {
	                        Cell cell = (Cell) cellIterator.next();
	                        //The Cell Containing String will is name.
	                        //logger.info("Cell Type: " +cell.getCellType() + "Col Index: "+cell.getColumnIndex() + "Row Index: "+cell.getRowIndex());
	                        
	                        if(cell.getRowIndex() == 1){
	                        	if (cell.getColumnIndex() == 0){
	                        		startDate = formatter.formatCellValue(row.getCell(cell.getColumnIndex()));
	                            	logger.info("Start Date::"+startDate);
	                        	}
	                        	if (cell.getColumnIndex() == 1){
	                        		endDate = formatter.formatCellValue(row.getCell(cell.getColumnIndex()));
	                            	logger.info("End Date::"+endDate);
	                        	}
	                        	
	                        }
	                        
	                        if(cell.getRowIndex() > 1){
	                    		//logger.info("SPK Col Name: " +cell.getNumericCellValue() + "count: "+rowCount);
	                    		String val = formatter.formatCellValue(row.getCell(cell.getColumnIndex()));
	                    		
	                    		deceasedBO.setRefStartDate(java.sql.Date.valueOf
	                					(ceUtil.convertStringToDate(startDate)));
	                    		deceasedBO.setRefEndDate(java.sql.Date.valueOf
	                					(ceUtil.convertStringToDate(endDate)));
	                    		
	                    		if (cell.getColumnIndex() == 2)
	                    			deceasedBO.setBorrowerNationalID(val);
	                    		if (cell.getColumnIndex() == 3)
	                    			deceasedBO.setBorrowerName(val);
	                    		if (cell.getColumnIndex() == 4)
	                    			deceasedBO.setAlhafizaNo(val);
	                    		if (cell.getColumnIndex() == 5)
	                    			deceasedBO.setAlhafizaSrc(val);
	                    		if (cell.getColumnIndex() == 6)
	                    			deceasedBO.setAlhafizaDate(val);
	                    		if (cell.getColumnIndex() == 7)
	                    			deceasedBO.setLoanAcctNo(val);
	                    		if (cell.getColumnIndex() == 8)
	                    			deceasedBO.setLoanPlace(val);
	                    		if (cell.getColumnIndex() == 9)
	                    			deceasedBO.setRepFullName(val);
	                    		if (cell.getColumnIndex() == 10)
	                    			deceasedBO.setRepNationalID(val);
	                    		if (cell.getColumnIndex() == 11)
	                    			deceasedBO.setRepContactNo(val);
	                    		if (cell.getColumnIndex() == 12)
	                    			deceasedBO.setRefNo(val);
	                    		if (cell.getColumnIndex() == 13){
	                    			deceasedBO.setRegDate(java.sql.Date.valueOf
	                    					(ceUtil.convertStringToDate(val)));
	                    		}
	                    		if (cell.getColumnIndex() == 14){
	                    			logger.info("Death Date"+val);
	                    			deceasedBO.setDaethDate(java.sql.Date.valueOf
	                    					(ceUtil.convertStringToDate(val)));
	                    		}
	                    		if(deceasedBO.getLoanAcctNo()!=null){
	                    		IBOAttributeCollectionFeature loanAccDtls = (IBOAttributeCollectionFeature)BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, deceasedBO.getLoanAcctNo(), true);
	                    		if(loanAccDtls!=null){
	                    			deceasedBO.setLoanBranch(loanAccDtls.getF_BRANCHSORTCODE());
	                    		}else
	                    			deceasedBO.setLoanBranch(" ");
	                    		}else
	                    			deceasedBO.setLoanBranch(" ");
	                    		
	                    		logger.info("Loan Branch:"+deceasedBO.getLoanBranch());
	                    		//logger.info("Val: "+val + "Col Index: "+cell.getColumnIndex());
	                    	}
	                    }
	                    studentList.add(deceasedBO);
	                }
	            }
	 
	            fis.close();
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return studentList;
	    }
		
		private String validateLoanDetails(String loanAcctNo, String nationalID) throws SQLException{
			String failureMsg = "";
			outStandingAmt = BigDecimal.ZERO;
			if(nationalID.length() < 10 ){
				failureMsg = "Invalid National ID";
			}else if( loanAcctNo.length() < 10){
				failureMsg = "Invalid Loan Account Number";
			}
			else{
				String nationalIDChk = " WHERE " +IBOPT_PFN_PartyDetailsView.NATIONALID+" = ?";
				ArrayList<String> params = new ArrayList<String>();
				params.add(nationalID);
				List partyResult = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOPT_PFN_PartyDetailsView.BONAME, nationalIDChk, params, null, true);
				if(partyResult==null || partyResult.isEmpty()){
					failureMsg = "Invalid National ID";
					return failureMsg;
				}
				String loanAcctNoChk = " WHERE "+ IBOLendingFeature.ACCOUNTID+" = ?";//TODO change the query to LOs
				params.clear();
				params.add(loanAcctNo);
				List loanAccResult = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME, loanAcctNoChk, params, null, true);
				if(loanAccResult==null || loanAccResult.isEmpty()){
					failureMsg = "Invalid Loan Account No";
					return failureMsg;
				}else{
					IBOLendingFeature loanDtls = (IBOLendingFeature)loanAccResult.get(0);
					outStandingAmt = loanDtls.getF_REDUCINGPRINCIPAL();
				}
			}
			
			return failureMsg;
		}
	 
	 
}