package com.ce.party;

import com.ce.party.util.PartyUtil;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FetchFarmLocationBkp;

import bf.com.misys.cbs.services.ListTieredGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;

public class CE_FetchFarmLocBkp extends AbstractCE_FetchFarmLocationBkp{

    public CE_FetchFarmLocBkp(BankFusionEnvironment env){
        super(env);
      }
      
      public void process(BankFusionEnvironment env){

              ListTieredGenericCodeRs farmGC = PartyUtil.getTieredGC("BRANCHNAME_FL", getF_IN_branchCode());
              for(GcCodeDetail gcItem : farmGC.getListTieredCodes().getGcCodeDetails()) {
                  if(gcItem.getCodeReference().equals(getF_IN_farmLocation())){
                      setF_OUT_farmLocationDesc(gcItem.getCodeDescription());          
                      break;
                      }

          }
      }
}
