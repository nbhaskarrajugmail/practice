package com.ce.party.util;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCBVW_GENERICCODE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PTY_DeceasedPartyDtls;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;

import bf.com.misys.cbs.services.ListGenericCodeRq;
import bf.com.misys.cbs.services.ListGenericCodeRs;
import bf.com.misys.cbs.services.ListTieredGenericCodeRq;
import bf.com.misys.cbs.services.ListTieredGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.InputListHostGCRq;
import bf.com.misys.cbs.types.InputListTieredGCRq;

public class PartyUtil {

	public List<IBOCE_PTY_DeceasedPartyDtls> convertVectorToList(
			VectorTable inputVector) {
		List<IBOCE_PTY_DeceasedPartyDtls> partyDtls = new ArrayList<IBOCE_PTY_DeceasedPartyDtls>();

		if ((inputVector != null) && (inputVector.size() > 0)) {
			for (int i = 0; i < inputVector.size(); ++i) {
				IBOCE_PTY_DeceasedPartyDtls party = (IBOCE_PTY_DeceasedPartyDtls) BankFusionThreadLocal
						.getPersistanceFactory().getStatelessNewInstance(
								IBOCE_PTY_DeceasedPartyDtls.BONAME);
				HashMap row = inputVector.getRowTags(i);
				party.setBoID((String) row.get("BOID"));
				party.setF_REJREASON((String) row.get("REJREASON"));
				party.setF_UPUSERID((String) row.get("UPUSERID"));
				party.setF_REMARKS((String) row.get("REMARKS"));
				party.setF_BORROWERNATID((int) row.get("BORROWERNATID"));
				party.setF_APPROVED((boolean) row.get("APPROVED"));
				party.setF_REFNO((int) row.get("REFNO"));
				party.setF_REFENDDT((Date) row.get("REFENDDT"));
				party.setF_ULSTATUS((String) row.get("ULSTATUS"));
				party.setF_APPROVED((boolean) row.get("APPROVED"));
				party.setF_APPROVERID((String) row.get("APPROVERID"));
				party.setF_BORROWERNAME((String) row.get("BORROWERNAME"));
				party.setF_LOANBR((String) row.get("LOANBR"));
				party.setF_REFSTARTDT((Date) row.get("REFSTARTDT"));
				party.setF_APPROVEDDT((Date) row.get("APPROVEDDT"));
				party.setF_REPCONTACNO((String) row.get("REPCONTACNO"));
				party.setF_REGDATE((Date) row.get("REGDATE"));
				party.setF_REPFULLNAME((String) row.get("REPFULLNAME"));
				party.setF_DLBATCHDT((Date) row.get("DLBATCHDT"));
				party.setBoID((String) row.get("LOANACCTNO"));
				party.setF_ALHAFIZANO((String) row.get("ALHAFIZANO"));
				party.setF_ALHAFIZADT((int) row.get("ALHAFIZADT"));
				party.setF_DAETHDATE((Date) row.get("DAETHDATE"));
				party.setF_ALHAFIZASRC((String) row.get("ALHAFIZASRC"));
				party.setF_REPNATID((int) row.get("REPNATID"));
				party.setVersionNum((int) row.get("VERSIONNUM"));
				party.setF_DLBATCHNO((int) row.get("DLBATCHNO"));
				party.setF_ULDT((Date) row.get("ULDT"));
				party.setF_LOANPLACE((String) row.get("LOANPLACE"));
				partyDtls.add(party);
			}
		}

		return partyDtls;

	}

	public static ListGenericCodeRs getGCList(String cbReference) {
		String CB_GCD_LISTGENERICCODES_SRV = "CB_GCD_ListGenericCodes_SRV";
		HashMap paramsargupdate = new HashMap();
		ListGenericCodeRq listGenericCodeRq = new ListGenericCodeRq();
		InputListHostGCRq inputListHostGCRq = new InputListHostGCRq();
		inputListHostGCRq.setCbReference(cbReference);
		listGenericCodeRq.setInputListCodeValueRq(inputListHostGCRq);
		paramsargupdate.put("listGenericCodeRq", listGenericCodeRq);
		HashMap readRqMap = MFExecuter.executeMF("CB_GCD_ListGenericCodes_SRV",
				BankFusionThreadLocal.getBankFusionEnvironment(),
				paramsargupdate);

		ListGenericCodeRs listGenericCodeRs = (ListGenericCodeRs) readRqMap
				.get("listGenericCodeRs");
		return listGenericCodeRs;
	}

	public static Map getGCMap(String cbReference) {
		HashMap gcMap = new HashMap();
		ListGenericCodeRs gcValuesList = getGCList(cbReference);
		for (GcCodeDetail gcCodeDetail : gcValuesList.getGcCodeDetails()) {
			gcMap.put(gcCodeDetail.getCodeReference(),
					gcCodeDetail.getCodeDescription());
		}
		return gcMap;
	}

	public static String getGCReference(String parent, String description) {

		String reference = description;
		IPersistenceObjectsFactory factory = BankFusionThreadLocal
				.getPersistanceFactory();

		String whereClause = " WHERE " + IBOCBVW_GENERICCODE.CODETYPE
				+ " = ? AND " + IBOCBVW_GENERICCODE.DESCRIPTION + " = ?";
		ArrayList params = new ArrayList();
		params.add(parent);
		params.add(description);
		List<IBOCBVW_GENERICCODE> gcCodeList = (List<IBOCBVW_GENERICCODE>) factory
				.findByQuery(IBOCBVW_GENERICCODE.BONAME, whereClause, params,
						null, true);

		if (gcCodeList.size() != 0) {
			reference = gcCodeList.get(0).getF_SUBCODETYPE();
		}
	  
		return reference;
	}
	
	/**
   * <description>methods return all branch code list with parent BRANCHNAME_FL
   * @param parent BRANCHNAME_FL
   * @param node
   * @return String 
   */
	 public static String getFarmLocationDesc(String titleDeedFarmLoc, String farmLocationRef) {
	     final Log LOGGER = LogFactory.getLog(PartyUtil.class.getName());
	      LOGGER.info("TitleDeed Farm Location : "+titleDeedFarmLoc);
	      ListTieredGenericCodeRs gcResp = getTieredGC("BRANCHNAME_FL", farmLocationRef);//branch name
	      if (null != gcResp && null != gcResp.getListTieredCodes()) {
	          GcCodeDetail[] gcCodeDetails = gcResp.getListTieredCodes().getGcCodeDetails();
	          if (null != gcCodeDetails && gcCodeDetails.length > 0) {
	              for (GcCodeDetail gcCodeDetail : gcCodeDetails) {
	                  if (gcCodeDetail.getCodeReference().equals(titleDeedFarmLoc)) {
	                      LOGGER.info("generic code for branh : "+titleDeedFarmLoc+ " is :  " + gcCodeDetail.getCodeDescription()+" with branch : " + farmLocationRef);
	                      return gcCodeDetail.getCodeDescription();
	                      
	                  }
	              }

	          }
	      }
	        return "";
	  }

	 
	  public static  ListTieredGenericCodeRs getTieredGC(String parent, String node) {
	      HashMap outputParams =null;
	      try {
	          HashMap inputParams = new HashMap();
	          ListTieredGenericCodeRq parentrequest = new ListTieredGenericCodeRq();
	          InputListTieredGCRq inputListTieredGCRq = new InputListTieredGCRq();
	          inputListTieredGCRq.setCbParentReference(parent);
	          inputListTieredGCRq.setCbNodeReference(node);
	          parentrequest.setInputListTieredGCRq(inputListTieredGCRq);
	          inputParams.put("listTieredGenericCodeRq", parentrequest);
	          outputParams = MFExecuter.executeMF("CB_GCD_ListTieredGenericCode_SRV", inputParams,BankFusionThreadLocal.getUserLocator().getStringRepresentation());
	      }
	      catch (Exception e) {
	         e.printStackTrace();
	      }
	      ListTieredGenericCodeRs listGenericCodeRs = null;
	      if (null != outputParams) {
	          listGenericCodeRs = (ListTieredGenericCodeRs) outputParams.get("listTieredGenericCodeRs");
	      }
	      return listGenericCodeRs;
	  }
}
