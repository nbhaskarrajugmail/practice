package com.ce.party;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SearchTitleDeedByNumber;

public class SearchTitleDeedNumber extends AbstractCE_SearchTitleDeedByNumber{


	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER+" LIKE ?";
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal
			.getPersistanceFactory();

	public SearchTitleDeedNumber() {
		super();
	}
	
	public SearchTitleDeedNumber(BankFusionEnvironment env){
		
	}
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		final Log LOGGER = LogFactory.getLog(SearchTitleDeedNumber.class.getName());
				
		String titleDeedNumber = getF_IN_titleDeedNumber();
		
		fetchTitleDeedDetails(titleDeedNumber);

}
	
	protected void fetchTitleDeedDetails(String titleDeedNumber){
		ArrayList<String> titleDeedParam = new ArrayList<String>();
		
		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
		if (titleDeedNumber == null || titleDeedNumber.isEmpty()) {
			//titleDeedID = "%";
            titleDeedParam.add("%");
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
            
			boolean select = true;
			Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
			Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
				if (titleDeedType.getF_STATUS().equals("ACTIVE")) {
				TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
				titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
				
				titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
				titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
				titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
				titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
				titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
				titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
				titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
				titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
				titleDeedDetailsType.setSelect(select);
				select = false;
				titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
				titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
				titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
				titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
				titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
				titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
				titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
				titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
				titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
				titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
				titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
				titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
				titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
				titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
				titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
			}
			setF_OUT_titleDeeddtlsList(listTitleDeedIdDtlsType);
			
		}
		}
		
		else {
			titleDeedParam.clear();
            titleDeedParam.add(titleDeedNumber);
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
            
			boolean select = true;
			
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
				if(titleDeedType.getF_STATUS().equals("ACTIVE")) {
				TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
				titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
				titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
				titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
				titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
				titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
				titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
				titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
				titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
				titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
				titleDeedDetailsType.setSelect(select);
				select = false;
				titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
				titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
				titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
				titleDeedDetailsType.setTitleDeedSource(titleDeedType.getF_TITLEDEEDSOURCE());
				titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
				titleDeedDetailsType.setTitleDeedType(titleDeedType.getF_TITLEDEEDTYPE());
				titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
				titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
				titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
				titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
				titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
				titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
				titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
				titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
				titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
			}
			setF_OUT_titleDeeddtlsList(listTitleDeedIdDtlsType);
			
		
			
		}
		
		
		
	}	
		
}


}
