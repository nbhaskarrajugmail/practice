package com.ce.party;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.PagingData;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_ReadAllActiveTitleDeed;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

@SuppressWarnings("deprecation")
public class CE_ReadActiveTitleDeed extends AbstractCE_PTY_ReadAllActiveTitleDeed {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8842213293137053246L;

	private static final Log logger = LogFactory.getLog(CE_ReadActiveTitleDeed.class.getName());

	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? ORDER BY "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " ASC";
	private final String titleDeedWhere_TitleDeedNumber = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " = ? ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER
			+ " ASC";
	private final String titleDeedWhere_TitleDeedNumberLike = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " LIKE ? ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER
			+ " ASC";

	private final String titleDeedShareHolderDtlsByParty = " WHERE " + IBOCE_TITLEDEEDSHAREHOLDER.PARTYID + " = ? ";
	private final String titleDeedDtlByTitleDeedID = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK + " = ? ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " ASC";

	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
	private static final String PARTY_ID = "PARTY_ID";
	private static final String TITLE_DEED = "TITLE_DEED";

	private Map<String, String> titleDeedSourceMap = null;
	private Map<String, String> titleDeedTypeMap = null;

	public CE_ReadActiveTitleDeed(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {

		SearchTitleDeedDtlsRqType searchTitleDeedDtlsRq = getF_IN_SearchTitleDeedDtlsRq();
		String partyId = searchTitleDeedDtlsRq.getPartyId();
		String titleDeedId = searchTitleDeedDtlsRq.getTitleDeedId();
		int pageSize = PAGE_SIZE;
		int pageNo = getF_IN_SearchTitleDeedDtlsRq().getPagingInfo().getPagingRequest().getRequestedPage();
		IPagingData pagingData = null;

/*		if (getF_IN_PagedQuery() != null && getF_IN_PagedQuery().getPagingRequest() != null) {
			pageSize = getF_IN_PagedQuery().getPagingRequest().getNumberOfRows();
			pageNo = getF_IN_PagedQuery().getPagingRequest().getRequestedPage();
		}
*/
		if (pageSize == 0)
			pageSize = PAGE_SIZE;
		if (pageNo == 0)
			pageNo = PAGE_NO;

		if ((partyId != null && !partyId.isEmpty()) || (titleDeedId != null && !titleDeedId.isEmpty())) {
			logger.info("Search Title Deed Details with Party Id Or Title Deed Id ");
			pagingData = new PagingData(pageNo, pageSize);
			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			this.fetchAllActiveTitleDeedDtlsByPartyAndTitleDeed(pagingData, partyId, titleDeedId, env);
		} else {
			logger.info("Search All Active Title Deed Details ");
			pagingData = new PagingData(pageNo, pageSize);
			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			this.fetchAllActiveTitleDeedDtls(pagingData, env);
		}
	}

	@Override
	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		@SuppressWarnings("unchecked")
		Map<String, String> supportedData = pagingState.getPagingHelper().getPagingModel();
		SearchTitleDeedDtlsRqType searchTitleDeedDtlsRq = getF_IN_SearchTitleDeedDtlsRq();
		String partyId = searchTitleDeedDtlsRq.getPartyId();
		String titleDeedId = searchTitleDeedDtlsRq.getTitleDeedId();
		supportedData.put(PARTY_ID, partyId);
		supportedData.put(TITLE_DEED, titleDeedId);
		return pagingState;
	}

	@Override
	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map map) {

		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		String partyID = (String) pagingModel.get(PARTY_ID);
		String titleDeedID = (String) pagingModel.get(TITLE_DEED);

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (map.containsKey("PAGENO")) {
			pageNo = (Integer) map.get("PAGENO");
		}
		if (map.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) map.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);

			if ((partyID != null && !partyID.isEmpty()) || (titleDeedID != null && !titleDeedID.isEmpty())) {
				logger.info("Search Title Deed Details with Party ID Or Title Deed ID ");
				resultVector = this.fetchAllActiveTitleDeedDtlsByPartyAndTitleDeed(pagingData, partyID, titleDeedID,
						env);
			} else {
				logger.info("Search All Active Title Deed Details ");
				resultVector = this.fetchAllActiveTitleDeedDtls(pagingData, env);
			}
		}
		return resultVector;
	}

	@SuppressWarnings("unchecked")
	private VectorTable fetchAllActiveTitleDeedDtls(IPagingData pagingData, BankFusionEnvironment env) {

		if (titleDeedSourceMap == null)
			titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		if (titleDeedTypeMap == null)
			titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");

		List<IBOCE_TITLEDEEDDETAILS> titleDeedList = null;

		String titleDeedNumber = getF_IN_TitleDeedNumber();
		// when title deed number is available
		if (titleDeedNumber != null && !titleDeedNumber.isEmpty()) {
			ArrayList<String> titleDeedParam = new ArrayList<String>();
			titleDeedParam.add("ACTIVE");
			titleDeedParam.add(titleDeedNumber);
			if (titleDeedNumber.contains("%")) {
				titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
						titleDeedWhere_TitleDeedNumberLike, titleDeedParam, pagingData, false);
			} else {
				titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
						titleDeedWhere_TitleDeedNumber, titleDeedParam, pagingData, false);
			}
		} else {
			// All "ACTIVE" record
			ArrayList<String> titleDeedParam = new ArrayList<String>();
			titleDeedParam.add("ACTIVE");
			titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
					titleDeedWhere, titleDeedParam, pagingData, false);

		}

		return this.createResponse(titleDeedList, pagingData);
	}

	@SuppressWarnings("unchecked")
	private VectorTable fetchAllActiveTitleDeedDtlsByPartyAndTitleDeed(IPagingData pagingData, String partyId,
			String titleDeedId, BankFusionEnvironment env) {

		if (titleDeedSourceMap == null)
			titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		if (titleDeedTypeMap == null)
			titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");

		VectorTable result = new VectorTable();
		ArrayList<String> titleDeedParam = new ArrayList<String>();
		List<IBOCE_TITLEDEEDDETAILS> titleDeedList = null;
		if (partyId != null && !partyId.isEmpty()) {
			// party search
			titleDeedParam.add(partyId);
			List<IBOCE_TITLEDEEDSHAREHOLDER> titledeedshareholders = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, titleDeedShareHolderDtlsByParty, titleDeedParam,
					    null, false);

			if (titledeedshareholders != null && titledeedshareholders.size() > 0) {

				Map<String, Boolean> titleDeedIdMap = new HashMap<String, Boolean>();
				for (IBOCE_TITLEDEEDSHAREHOLDER titledeedshareholder : titledeedshareholders) {
					// when filtering with both party & title deed
					// LIKE not supported in filter
					if (!titleDeedId.isEmpty() && !titleDeedId.contains("%")) {
						if (titleDeedId.equals(titledeedshareholder.getF_TITLEDEEDID())) {
							titleDeedIdMap.put(titledeedshareholder.getF_TITLEDEEDID(), Boolean.TRUE);
						}
						continue;
					}
					titleDeedIdMap.put(titledeedshareholder.getF_TITLEDEEDID(), Boolean.TRUE);
				}

				if (titleDeedIdMap.size() > 0) {
					titleDeedParam.clear();
					titleDeedParam.add("ACTIVE");

					StringBuilder inQuery = new StringBuilder();
					inQuery.append(" WHERE ");
					inQuery.append(IBOCE_TITLEDEEDDETAILS.STATUS);
					inQuery.append(" = ? AND ");
					inQuery.append(IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK);
					inQuery.append(" IN (");

					for (String titleDeedID : titleDeedIdMap.keySet()) {
						titleDeedParam.add(titleDeedID);
						inQuery.append("?,");
					}
					// remove last COMMA
					inQuery.replace(inQuery.length() - 1, inQuery.length(), ")");
					inQuery.append(" ORDER BY ");
					inQuery.append(IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER);

					titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
							IBOCE_TITLEDEEDDETAILS.BONAME, inQuery.toString(), titleDeedParam, pagingData, false);
				}
			}

		} else if (titleDeedId != null && !titleDeedId.isEmpty()) {
			// title deed id search
			titleDeedParam.clear();
			titleDeedParam.add("ACTIVE");
			titleDeedParam.add(titleDeedId);
			titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
					titleDeedDtlByTitleDeedID, titleDeedParam, pagingData, false);
		} else {
			result = this.fetchAllActiveTitleDeedDtls(pagingData, env);
		}
		result = this.createResponse(titleDeedList, pagingData);
		return result;
	}

	private VectorTable createResponse(List<IBOCE_TITLEDEEDDETAILS> titleDeedList, IPagingData pagingData) {

		VectorTable vectorTable = new VectorTable();

		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
		SearchTitleDeedDtlsRsType searchTitleDeedRs = new SearchTitleDeedDtlsRsType();
		boolean select = true;
		if (titleDeedList != null) {
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
				this.prepareListTitleDeedIdDtlsType(listTitleDeedIdDtlsType, titleDeedType, select);
				select = false;
				Map<String, Object> map = this.prepareMap(titleDeedType);
				VectorTable newRow = new VectorTable(map);
				vectorTable.addAll(newRow);
			}
		}

		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		vectorTable.setPagingData(pageData);

		searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
		searchTitleDeedRs.setPagingInfo(pagedQuery);
		setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
		setF_OUT_PaginatedData(vectorTable);

		return vectorTable;
	}

	private void prepareListTitleDeedIdDtlsType(ListTitleDeedIdDtlsType listTitleDeedIdDtlsType,
			IBOCE_TITLEDEEDDETAILS titleDeedType, Boolean select) {
		TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
		titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
		CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
		titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
		titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
		titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
		titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
		titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
		titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
		titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
		titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
		titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
		titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
		titleDeedDetailsType.setSelect(select);
		titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
		titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
		titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
		titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
		titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
		titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
		titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
		titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
		titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
		titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
		titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
		titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
		titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
		titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
		titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
		listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
	}

	private Map<String, Object> prepareMap(IBOCE_TITLEDEEDDETAILS titleDeedType) {

		Map<String, Object> map = new HashMap<>();
		CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
		map.put("versionNumber", titledeeddetailsid.getF_TITLEDEEDVERSION());
		map.put("SELECT", Boolean.FALSE);
		map.put("TITLEDEEDIDPK", titledeeddetailsid.getF_TITLEDEEDID());
		map.put("TITLEDEEDVERSIONPK", titledeeddetailsid.getF_TITLEDEEDVERSION());
		map.put("TITLEDEEDSTATUS", titleDeedType.getF_TITLEDEEDSTATUS());
		map.put("TRANSACTIONTYPE", titleDeedType.getF_TRANSACTIONTYPE());
		map.put("RECCREATEDBY", titleDeedType.getF_RECCREATEDBY());
		map.put("VALIDTO", titleDeedType.getF_VALIDTO());
		map.put("VERSIONNUM", titleDeedType.getVersionNum());
		map.put("NOTES", titleDeedType.getF_NOTES());
		map.put("VALIDTOHIJRI", titleDeedType.getF_VALIDTOHIJRI());
		map.put("NOTESFORAMEND", titleDeedType.getF_NOTESFORAMEND());
		map.put("LINKEDTOCOLLATERAL", titleDeedType.getF_LINKEDTOCOLLATERAL());
		map.put("STATUS", titleDeedType.getF_STATUS());
		map.put("RECLASTMODIFIEDBY", titleDeedType.getF_RECLASTMODIFIEDBY());
		map.put("TITLEDEEDYEAR", titleDeedType.getF_TITLEDEEDYEAR());
		map.put("TITLEDEEDNUMBER", titleDeedType.getF_TITLEDEEDNUMBER());
		map.put("RETAILINDEX", titleDeedType.getF_RETAILINDEX());
		map.put("VALIDFROMHIJRI", titleDeedType.getF_VALIDFROMHIJRI());
		map.put("REASONFORCHANGE", titleDeedType.getF_REASONFORCHANGE());
		map.put("LANDPLOTNUMBER", titleDeedType.getF_LANDPLOTNUMBER());
		map.put("RECSYSDATE", titleDeedType.getF_RECSYSDATE());
		map.put("DICISSIONSTATUS", titleDeedType.getF_DICISSIONSTATUS());
		map.put("RECAPPROVEDBY", titleDeedType.getF_RECAPPROVEDBY());
		map.put("RECCREATEDON", titleDeedType.getF_RECCREATEDON());
		map.put("TRANSACTIONDATE", titleDeedType.getF_TRANSACTIONDATE());
		map.put("VALIDFROM", titleDeedType.getF_VALIDFROM());
		map.put("RECLASTMODIFIEDDATE", titleDeedType.getF_RECLASTMODIFIEDDATE());
		map.put("FARMLOCATION", titleDeedType.getF_FARMLOCATION());
		map.put("BRANCHSHORTCODE", titleDeedType.getF_BRANCHSORTCODE());
		map.put("RECAPPROVEDDATE", titleDeedType.getF_RECAPPROVEDDATE());
		map.put("SPLITINDICATOR", titleDeedType.getF_SPLITINDICATOR());
		map.put("LANDPLANNUMBER", titleDeedType.getF_LANDPLANNUMBER());
		map.put("TITLEDEEDSOURCE", titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
		map.put("AREASIZE", titleDeedType.getF_AREASIZE());
		map.put("TITLEDEEDTYPE", titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
		map.put("CompositeBoid", titleDeedType.getCompositeBOID());
		return map;
	}

}