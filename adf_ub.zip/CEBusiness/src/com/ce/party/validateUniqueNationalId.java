package com.ce.party;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_ValidateUniqueNationalId;

import bf.com.misys.cbs.types.events.Event;

public class validateUniqueNationalId extends AbstractCE_ValidateUniqueNationalId{
	

	private final int E_UNIQUE_NATIONALID = 44000046;
	private static final Log LOGGER = LogFactory.getLog(validateUniqueNationalId.class);
	private static final String FIND_PARTY_PERSONAL_DET = "WHERE " + IBOPT_PFN_PersonalDetails.NATIONALID + " = ?";
	public validateUniqueNationalId(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		String nationalId = getF_IN_nationalId();
		if (!(nationalId==null || nationalId.isEmpty())) {
			validateNationalId(nationalId,env);
		}
		
	}
	private void validateNationalId(String nationalId,BankFusionEnvironment env) {
		LOGGER.info("Entered nationalId is" + nationalId);
		ArrayList<String> params = new ArrayList<>();
		params.add(nationalId);

		List<IBOPT_PFN_PersonalDetails> partyPersonalDetails = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_PARTY_PERSONAL_DET, params, null, true);

		if (!(partyPersonalDetails == null || partyPersonalDetails.isEmpty())) {
			raiseEvent(E_UNIQUE_NATIONALID,env);
		}
	
	}
	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}

}
