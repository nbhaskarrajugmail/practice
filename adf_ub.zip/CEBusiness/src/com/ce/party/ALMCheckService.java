package com.ce.party;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.NodeList;

import com.ce.adf.CEUtil;
import com.ce.payments.CE_SadadPaymentReqBuilder;

import static com.ce.adf.CEConstants.*;


public class ALMCheckService {
	Log logger = LogFactory.getLog(CE_SadadPaymentReqBuilder.class);
	CEUtil utils = new CEUtil();
	private String wsURL =utils.getModuleConfigurationValue(CE_SADAD_INTERFACE, ELM_Yakeen_URL);
	
	public String callAMLService(String nationalID,String companyID,String birthDate){
		String response = EMPTY;
		logger.info("IN AML Check Service......");
		String request = prepareRequest(nationalID, companyID, birthDate);
		logger.info(request);
		try{
			response = postRequest(request);
		}catch(Exception e){
			
		}
		return response;
	}
	
	public String prepareRequest(String nationalID,String companyID,String birthDate){
		StringBuilder reqBuilder = new StringBuilder();
		reqBuilder.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ce=\"CE_ADF_PartyAML.wsdl\">")
		   .append("<soapenv:Header/>")
		   .append("<soapenv:Body>")
		      .append("<ce:partyALMRequest>");
		      if(nationalID!=null && !nationalID.equals(EMPTY)){
		         reqBuilder.append("<nationalID>").append(nationalID).append("</nationalID>")
		         .append("<birthDate>").append(birthDate.toString()).append("</birthDate>")
		         .append("<regNumber></regNumber>");
		      }else{
		    	  reqBuilder.append("<nationalID></nationalID>")
			         .append("<birthDate></birthDate>")
		         .append("<regNumber>"+companyID+"</regNumber>");
		      }
		      reqBuilder  .append("<regDate>test</regDate>")
		      .append("</ce:partyALMRequest>")
		   .append("</soapenv:Body>")
		.append("</soapenv:Envelope>");
		 return reqBuilder.toString();     
	}
	
	public  String pushRequest(String xmlInput ) throws IOException{
		String outputString = EMPTY;
		try{
			logger.info("pushRequest: "+xmlInput);
			SOAPMessage reply = null;
			SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
		    SOAPConnection connection = soapConnFactory.createConnection();
			SOAPMessage msg = getMsg(xmlInput);
			logger.info("Got Reqest message");
			reply = connection.call(msg, wsURL);
			logger.info("got response from wsdl");
			ByteArrayOutputStream stream = new ByteArrayOutputStream();
			reply.writeTo(stream);
			outputString = new String(stream.toByteArray(), "utf-8");
			logger.info(outputString);
		    connection.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return outputString;
		
	}
	/**
	 * 
	 * @param req
	 * @param SOAPAction
	 * @return
	 * converts string request message into soapmessage 
	 */
	private static SOAPMessage getMsg(String req){
	    SOAPMessage msg = null;
	    try
	    {
	      MessageFactory msgFactory = MessageFactory.newInstance();
	      msg = msgFactory.createMessage();
	      MimeHeaders hd = msg.getMimeHeaders();
	      hd.addHeader("SOAPAction", "partyALMCheckReq");
	      SOAPPart part = msg.getSOAPPart();
	      StreamSource msgSrc = new StreamSource(new StringReader((String)req));
	      part.setContent(msgSrc);
	      msg.saveChanges();
	    }
	    catch (SOAPException e)
	    {
	    	e.printStackTrace();
	    }
	    return msg;
 }
	
	
	/** @param xmlInput
	 * @return
	 * @throws IOException */
	public String postRequest(String xmlInput) throws IOException, SOAPException {
		logger.info(xmlInput);
		SOAPMessage reply = null;
		SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
		SOAPConnection connection = soapConnFactory.createConnection();
		SOAPMessage msg = getMsg(xmlInput);
		logger.info("Got Reqest message"+msg);
		reply = connection.call(msg, wsURL);
		connection.close();
		
		String firstName = EMPTY;
		String middleName = EMPTY;
		String lastName = EMPTY;
		String crName = EMPTY;
		String gender= EMPTY;
		SOAPBody body = reply.getSOAPBody();
	    NodeList returnList = body.getElementsByTagName("ce:partyALMResponse");
		for (int k = 0; k < returnList.getLength(); k++) {
			NodeList innerResultList = returnList.item(k).getChildNodes();
			for (int l = 0; l < innerResultList.getLength(); l++) {
				String choice = innerResultList.item(l).getNodeName();
				switch (choice) {
				case "firstName":
					firstName = innerResultList.item(l).getTextContent().trim();
					break;
				case "middleName":
					middleName = innerResultList.item(l).getTextContent().trim();
					break;
				case "lastName":
					lastName = innerResultList.item(l).getTextContent().trim();
					break;
				case "companyName":
					crName = innerResultList.item(l).getTextContent().trim();
					break;
				case "gender":
					gender = innerResultList.item(l).getTextContent().trim();
					break;
				default:
					logger.info("No info found for this list" + innerResultList.item(l).getTextContent().trim());
				}
			}
			logger.info("FirstName: " + firstName + "MiddleName: " + middleName + "LastName: " + lastName
					+ "CompanyName: " + crName + "gender: " + gender);
		}
	    
	    String outputString = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ce=\"CE_ADF_PartyAML.wsdl\">"+
				   "<soapenv:Body>"+
				    "  <ce:partyALMResponse>"+
			 		" <firstName>"+firstName+"</firstName>"+
			 		" <middleName>"+middleName+"</middleName>"+
			 		" <lastName>"+lastName+"</lastName>"+
			 		" <gender>"+gender+"</gender>"+
				    " <companyName>"+crName+"</companyName>"+
				      "</ce:partyALMResponse>"+
				   "</soapenv:Body>"+
				"</soapenv:Envelope>";
		
		logger.info("outputString: "+outputString);
		return outputString;
	}
}
