package com.ce.party;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.microflow.MFExecuter;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FilterTitleDeedDtls;

import bf.com.misys.cbs.services.ListTieredGenericCodeRq;
import bf.com.misys.cbs.services.ListTieredGenericCodeRs;
import bf.com.misys.cbs.types.GcCodeDetail;
import bf.com.misys.cbs.types.InputListTieredGCRq;
import bf.com.misys.cbs.types.events.Event;

public class CE_FilterTitleDeedDtls extends AbstractCE_FilterTitleDeedDtls {

	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK+" LIKE ?" + " AND " + IBOCE_TITLEDEEDDETAILS.STATUS+" = ? ";
	private final String filterByParentWhere = " WHERE " + IBOCE_PARENTTITLEDEEDDTLS.TITLEDEEDID+" LIKE ?";
	private final String shareHolderWhere = " WHERE " + IBOCE_TITLEDEEDSHAREHOLDER.PARTYID+" = ? ";
	private final int TITLEDEED_NOT_ATTACHED_PARTYID = 44000018;
	private final int TITLEDEED_NOT_ACTIVE = 44000019;
	private transient final static Log LOGGER = LogFactory.getLog(CE_FilterTitleDeedDtls.class.getName());
	//private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public CE_FilterTitleDeedDtls() {
		super();
	}
	
	public CE_FilterTitleDeedDtls(BankFusionEnvironment env){
		
	}
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		final Log LOGGER = LogFactory.getLog(CE_FilterTitleDeedDtls.class.getName());
				
		SearchTitleDeedDtlsRqType searchTitleDeedDtlsRqType = new SearchTitleDeedDtlsRqType();
		
		searchTitleDeedDtlsRqType = getF_IN_searchTitleDeedDtlsRqType();
		
		fetchTitleDeedDetails(searchTitleDeedDtlsRqType);
		
		
}
	
	
	private String getFarmLocationDesc(String titleDeedFarmLoc) {
	    LOGGER.info("TitleDeed Farm Location : "+titleDeedFarmLoc);
	    String farmLocationRef = BankFusionThreadLocal.getUserSession().getBranchSortCode();
	    ListTieredGenericCodeRs gcResp = getTieredGC("BRANCHNAME_FL", farmLocationRef);//branch name
	    if (null != gcResp && null != gcResp.getListTieredCodes()) {
	        GcCodeDetail[] gcCodeDetails = gcResp.getListTieredCodes().getGcCodeDetails();
	        if (null != gcCodeDetails && gcCodeDetails.length > 0) {
	            for (GcCodeDetail gcCodeDetail : gcCodeDetails) {
	                if (gcCodeDetail.getCodeReference().equals(titleDeedFarmLoc)) {
	                    LOGGER.info("generic code for branh : "+titleDeedFarmLoc+ " is :  " + gcCodeDetail.getCodeDescription()+" with branch : " + farmLocationRef);
	                    return gcCodeDetail.getCodeDescription();
	                    
	                }
	            }

	        }
	    }
        return "";
	}
	@SuppressWarnings("unchecked")
  private  ListTieredGenericCodeRs getTieredGC(String parent, String node) {
      HashMap outputParams =null;
      try {
          HashMap inputParams = new HashMap();
          ListTieredGenericCodeRq parentrequest = new ListTieredGenericCodeRq();
          InputListTieredGCRq inputListTieredGCRq = new InputListTieredGCRq();
          inputListTieredGCRq.setCbParentReference(parent);
          inputListTieredGCRq.setCbNodeReference(node);
          parentrequest.setInputListTieredGCRq(inputListTieredGCRq);
          inputParams.put("listTieredGenericCodeRq", parentrequest);
          outputParams = MFExecuter.executeMF("CB_GCD_ListTieredGenericCode_SRV", inputParams,BankFusionThreadLocal.getUserLocator().getStringRepresentation());
      }
      catch (Exception e) {
         e.printStackTrace();
      }
      ListTieredGenericCodeRs listGenericCodeRs = null;
      if (null != outputParams) {
          listGenericCodeRs = (ListTieredGenericCodeRs) outputParams.get("listTieredGenericCodeRs");
      }
      return listGenericCodeRs;
  }
	
	protected void fetchTitleDeedDetails(SearchTitleDeedDtlsRqType searchTitleDeedDtls){
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
		String partyID = searchTitleDeedDtls.getPartyId();
		String titleDeedID = searchTitleDeedDtls.getTitleDeedId();
		ArrayList<String> titleDeedParam = new ArrayList<String>();
		ArrayList<String> shareHolderParam = new ArrayList<String>();
		Boolean filterByParent = true;
		
		SearchTitleDeedDtlsRsType searchTitleDeedRs = new SearchTitleDeedDtlsRsType();
		
		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
		
		Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");
		Map<String,String> titleFarmLocationMap = PartyUtil.getGCMap("BRANCHNAME_FL");
		
		
		
		if ((partyID == null || (partyID.isEmpty()))&&(titleDeedID == null || titleDeedID.isEmpty())) {
			//titleDeedID = "%";
            titleDeedParam.add("%");
            titleDeedParam.add("ACTIVE");
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
            
			boolean select = true;
			
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
			    
				TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
				titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
				
				titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
				titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
				titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
				titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
				titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
				titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
				titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
				titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
				titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
				titleDeedDetailsType.setSelect(select);
				select = false;
				titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
				titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
				titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
				titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
				titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
				titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
				titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
				titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
				titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
				titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
				titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
				titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
				titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
				titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
				titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
			}
			
			if(filterByParent) {
			ListTitleDeedIdDtlsType listTitleDeedIdDtlsTypeCopy = listTitleDeedIdDtlsType;
      ArrayList<String> filterParentParam = new ArrayList<String>();
      filterParentParam.add("%");
      List<IBOCE_PARENTTITLEDEEDDTLS> titleDeedParentList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
          IBOCE_PARENTTITLEDEEDDTLS.BONAME, filterByParentWhere, filterParentParam, null, false);
                for(TitleDeedDetailsType titleDeed : listTitleDeedIdDtlsTypeCopy.getTitleDeedDetails()) {
              
              for(IBOCE_PARENTTITLEDEEDDTLS parent : titleDeedParentList) {
                  if(parent.getF_TITLEDEEDID().equals(titleDeed.getTitleDeedIdpk())) {
                      for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
                          if(parent.getF_TITLEDEEDNUMBER().equals(TD.getTitleDeedNumber())){
                              listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
                          }
                      }
                  }
              }
              
          }
      }
			searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
			setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
			
		}
		
		if ((partyID == null || partyID.isEmpty())&& (!(titleDeedID == null || titleDeedID.isEmpty()))) {
			titleDeedParam.clear();
            titleDeedParam.add(titleDeedID);
            titleDeedParam.add("ACTIVE");
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
			
			if (titleDeedList==null || titleDeedList.isEmpty()) {
				raiseEvent(TITLEDEED_NOT_ACTIVE, env);
			}
            
			boolean select = true;
			
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
				TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
				titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
				titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
				titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
				titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
				titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
				titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
				titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
				titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
				titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
				titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
				titleDeedDetailsType.setSelect(select);
				select = false;
				titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
				titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
				titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
				titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
				titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
				titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
				titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
				titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
				titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
				titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
				titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
				titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
				titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
				titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
				titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
			}
			
			if(filterByParent) {
		      ListTitleDeedIdDtlsType listTitleDeedIdDtlsTypeCopy = listTitleDeedIdDtlsType;
		      ArrayList<String> filterParentParam = new ArrayList<String>();
		      filterParentParam.add("%");
		      List<IBOCE_PARENTTITLEDEEDDTLS> titleDeedParentList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		          IBOCE_PARENTTITLEDEEDDTLS.BONAME, filterByParentWhere, filterParentParam, null, false);
		                for(TitleDeedDetailsType titleDeed : listTitleDeedIdDtlsTypeCopy.getTitleDeedDetails()) {
		              
		              for(IBOCE_PARENTTITLEDEEDDTLS parent : titleDeedParentList) {
		                  if(parent.getF_TITLEDEEDID().equals(titleDeed.getTitleDeedIdpk())) {
		                      for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
		                          if(parent.getF_TITLEDEEDNUMBER().equals(TD.getTitleDeedNumber())){
		                              listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
		                          }
		                      }
		                  }
		              }
		              
		          }
		      }
			searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
			setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
			
		
			
		}
		
		if (!(partyID == null || partyID.isEmpty())&& (titleDeedID == null || titleDeedID.isEmpty())) {
			
			shareHolderParam.clear();
			shareHolderParam.add(partyID);
			List<IBOCE_TITLEDEEDSHAREHOLDER> shareHolderList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
					IBOCE_TITLEDEEDSHAREHOLDER.BONAME, shareHolderWhere, shareHolderParam, null, false);
			if(shareHolderList==null || shareHolderList.isEmpty() ) {
				raiseEvent(TITLEDEED_NOT_ATTACHED_PARTYID, env);
			}
			
			
			for (IBOCE_TITLEDEEDSHAREHOLDER shareHolderType : shareHolderList) {
				
				 String titleDeedId = shareHolderType.getF_TITLEDEEDID();
				 titleDeedParam.clear();
				 titleDeedParam.add(titleDeedId);
				 titleDeedParam.add("ACTIVE");
					List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
			                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
					boolean select = true;
					
					for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
						TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
						titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
						CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
						titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
						titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
						titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
						titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
						titleDeedDetailsType.setFarmLocationDescription(PartyUtil
							.getFarmLocationDesc(titleDeedType.getF_FARMLOCATION(), titleDeedType.getF_BRANCHSORTCODE()));
						titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
						titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
						titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
						titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
						titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
						titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
						titleDeedDetailsType.setSelect(select);
						select = false;
						titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
						titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
						titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
						titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
						titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
						titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
						titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
						titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
						titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
						titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
						titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
						titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
						titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
						titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
						titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
						listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
					}
					
			}
			
			if(filterByParent) {
		      ListTitleDeedIdDtlsType listTitleDeedIdDtlsTypeCopy = listTitleDeedIdDtlsType;
		      ArrayList<String> filterParentParam = new ArrayList<String>();
		      filterParentParam.add("%");
		      List<IBOCE_PARENTTITLEDEEDDTLS> titleDeedParentList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		          IBOCE_PARENTTITLEDEEDDTLS.BONAME, filterByParentWhere, filterParentParam, null, false);
		                for(TitleDeedDetailsType titleDeed : listTitleDeedIdDtlsTypeCopy.getTitleDeedDetails()) {
		              
		              for(IBOCE_PARENTTITLEDEEDDTLS parent : titleDeedParentList) {
		                  if(parent.getF_TITLEDEEDID().equals(titleDeed.getTitleDeedIdpk())) {
		                      for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
		                          if(parent.getF_TITLEDEEDNUMBER().equals(TD.getTitleDeedNumber())){
		                              listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
		                          }
		                      }
		                  }
		              }
		              
		          }
		      }
			
			ListTitleDeedIdDtlsType listTDDtlsCopy = listTitleDeedIdDtlsType;
			for (TitleDeedDetailsType titleDeed : listTDDtlsCopy.getTitleDeedDetails()) {
				int titleDeedCount = 0;
				for (TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
					if (titleDeed.getTitleDeedIdpk().equals(TD.getTitleDeedIdpk())) {
						titleDeedCount++;
					}
					if (titleDeedCount > 1) {

						listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
						titleDeedCount--;
					}

				}
			}
			
			if(isF_IN_isSplitTd()) {
			ArrayList<String> filterSplitParam = new ArrayList<String>();
			String filterSplitWhere = " WHERE " + IBOCE_TITLEDEEDSPLITDTLS.TITLEDEEDID+" LIKE ?";
			filterSplitParam.add("%");
		     List<IBOCE_TITLEDEEDSPLITDTLS> titleDeedSplitList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		    		 IBOCE_TITLEDEEDSPLITDTLS.BONAME, filterSplitWhere, filterSplitParam, null, false);
		     for(IBOCE_TITLEDEEDSPLITDTLS eachTdSplitDtl :titleDeedSplitList)
		     {
		    	 for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails())
		    	 {
		    		 if(eachTdSplitDtl.getF_TITLEDEEDID().equals(TD.getTitleDeedIdpk()))
		    		 {
		    			 listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
		    		 }
		    	 }
		     }
		    
			}
			searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
			setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
		}
		
		if (!(partyID == null || partyID.isEmpty())&& (!(titleDeedID == null || titleDeedID.isEmpty()))) {
			shareHolderParam.clear();
			shareHolderParam.add(partyID);
			List<IBOCE_TITLEDEEDSHAREHOLDER> shareHolderList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
					IBOCE_TITLEDEEDSHAREHOLDER.BONAME, shareHolderWhere, shareHolderParam, null, false);
			if (shareHolderList==null || shareHolderList.isEmpty()) {
				raiseEvent(TITLEDEED_NOT_ATTACHED_PARTYID, env);
			}
			for (IBOCE_TITLEDEEDSHAREHOLDER shareHolderDtlsType : shareHolderList) {
			if (shareHolderDtlsType.getF_TITLEDEEDID().equals(titleDeedID)) {
				titleDeedParam.clear();
				titleDeedParam.add(titleDeedID);
				titleDeedParam.add("ACTIVE");
				List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
				
				if(titleDeedList==null || titleDeedList.isEmpty()) {
					raiseEvent(TITLEDEED_NOT_ACTIVE, env);
				}
				boolean select = true;
				
				for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
					TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
					titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
					CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
					titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
					titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
					titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
					titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
					titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
					titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
					titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
					titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
					titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
					titleDeedDetailsType.setSelect(select);
					select = false;
					titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
					titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
					titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
					titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
					titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
					titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
					titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
					titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
					titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
					titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
					titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
					titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
					titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
					titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
					titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
					listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
				}
				
			}
			
		}
			
			if(filterByParent) {
		      ListTitleDeedIdDtlsType listTitleDeedIdDtlsTypeCopy = listTitleDeedIdDtlsType;
		      ArrayList<String> filterParentParam = new ArrayList<String>();
		      filterParentParam.add("%");
		      List<IBOCE_PARENTTITLEDEEDDTLS> titleDeedParentList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		          IBOCE_PARENTTITLEDEEDDTLS.BONAME, filterByParentWhere, filterParentParam, null, false);
		                for(TitleDeedDetailsType titleDeed : listTitleDeedIdDtlsTypeCopy.getTitleDeedDetails()) {
		              
		              for(IBOCE_PARENTTITLEDEEDDTLS parent : titleDeedParentList) {
		                  if(parent.getF_TITLEDEEDID().equals(titleDeed.getTitleDeedIdpk())) {
		                      for(TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
		                          if(parent.getF_TITLEDEEDNUMBER().equals(TD.getTitleDeedNumber())){
		                              listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
		                          }
		                      }
		                  }
		              }
		              
		          }
		      }
			
			ListTitleDeedIdDtlsType listTDDtlsCopy = listTitleDeedIdDtlsType;
			for (TitleDeedDetailsType titleDeed : listTDDtlsCopy.getTitleDeedDetails()) {
				int titleDeedCount = 0;
				for (TitleDeedDetailsType TD : listTitleDeedIdDtlsType.getTitleDeedDetails()) {
					if (titleDeed.getTitleDeedIdpk().equals(TD.getTitleDeedIdpk())) {
						titleDeedCount++;
					}
					if (titleDeedCount > 1) {

						listTitleDeedIdDtlsType.removeTitleDeedDetails(TD);
						titleDeedCount--;
					}

				}
			}

			searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
			setF_OUT_searchTitleDeedDtlsRs(searchTitleDeedRs);
		
		}
		
	}	
	
	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}
		
	
}