package com.ce.party.userexit.host;

import static com.ce.adf.CEConstants.CE_DEATH_CERT_NOT_UPLOADED;
import static com.ce.adf.CEConstants.DeceasedDocType;
import static com.ce.adf.CEConstants.personalParty;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import bf.com.misys.msgs.party.v12.MessageStatus;
import bf.com.misys.msgs.party.v12.PartyBasicDtls;
import bf.com.misys.msgs.party.v12.PartyPublicStsDtls;
import bf.com.misys.msgs.party.v12.PartyStatusUserExitRs;
import bf.com.misys.msgs.party.v12.RsHeader;
import bf.com.misys.party.ws.RqPayload;
import bf.com.misys.party.ws.RsPayload;

import com.ce.events.EventHelper;
import com.misys.bankfusion.common.runtime.BankFusionEnvironment;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.party.userexit.host.AbstractPublicPartyStatusValidator;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

public class CEPublicPartyStatusImpl extends AbstractPublicPartyStatusValidator{
    Log log = LogFactory.getLog(CEPublicPartyStatusImpl.class);
	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
	
	protected RsHeader validatePartyStatus(PartyBasicDtls payLoad) {
		log.info("Inside CEPublicPartyStatusImpl validatePartyStatus:"+payLoad.getPartyType()+"/"+payLoad.getPublicStsDtls());
        RsHeader rsHeader = new RsHeader();
        PartyStatusUserExitRs response = new PartyStatusUserExitRs();
        EventHelper events = new EventHelper();
        if(personalParty.equalsIgnoreCase(payLoad.getPartyType())){
        for(PartyPublicStsDtls partyStatus : payLoad.getPublicStsDtls()){
        	if("007".equalsIgnoreCase(partyStatus.getPartyPublicStsDtl().getPartyPublicSts())){
        		RqPayload rqPayload = new RqPayload();
                String req = "UNIQUE_ID="+GUIDGen.getNewGUID()+";PARTYID="+payLoad.getPartyId()+";PT_PFN_PartyDocumentData;";
                rqPayload.setRqParam(req);
                Map<String, RqPayload> params = new HashMap<String, RqPayload>();
        		params.put("requestPayload", rqPayload);
        		HashMap<String, RsPayload> result = MFExecuter.executeMF("CB_PTY_ReadPartyDetailsWS_SRV", BankFusionThreadLocal.getBankFusionEnvironment(), params);
        		RsPayload rsPayload = (RsPayload)result.get("responsePayload");
        		log.info("Rs from Party"+rsPayload.getRsParam());
        		boolean isDeceasedCertAttached = validateDeceasedDoc(rsPayload.getRsParam());
        		log.info("isDeceasedCertAttached: "+isDeceasedCertAttached);
                if (!isDeceasedCertAttached) {
                	events.raiseBusinessEvent(CE_DEATH_CERT_NOT_UPLOADED);
                    }
        	}
        }
        }
        MessageStatus status = new MessageStatus();
        response.setPartyHeaderRs(rsHeader);
        status.setOverallStatus("S");
        rsHeader.setStatus(status);
		return rsHeader;
}	
	
private boolean validateDeceasedDoc(String docDetails) {
	boolean isDCAvl = false;
	log.info("Inside validateDeceasedDoc: "+docDetails);
	String[] s2 = docDetails.split(";");
	for(String s3 : s2){
		if(s3.startsWith("PT_PFN_PartyDocumentData#DOCTYPE")){
			String s4 = s3.substring(s3.indexOf("=")+1);
			if(DeceasedDocType.equalsIgnoreCase(s4)){
				log.info("s4:"+s4 + "\n");
				isDCAvl = true;
				break;
			}
		}
	}
		return isDCAvl;
	}
}
