
package com.ce.party;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.pf.common.functions.PartyConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_PrepareDedupCheck;

import bf.com.misys.cbs.types.DedupeKeys;
import bf.com.misys.cbs.types.PartyBasicDtls;
import bf.com.misys.cbs.types.ReadPtyDedupConfigOp;

public class PrepareDedupCheck extends AbstractCE_PTY_PrepareDedupCheck {
	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(PrepareDedupCheck.class);
	ReadPtyDedupConfigOp readPtyDedupConfigOp = new ReadPtyDedupConfigOp();

	private final static Log log = LogFactory.getLog(PrepareDedupCheck.class.getName());

	public PrepareDedupCheck() {
		super();
	}

	public PrepareDedupCheck(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment env) {
		super(env);
	}

	PartyBasicDtls partybasicDetails = new PartyBasicDtls();
	// String partyType=partybasicDetails.getPartyType();

	public void process(BankFusionEnvironment env) throws BankFusionException {

		log.info("Custom setting Dedup values");
		readPtyDedupConfigOp = getF_IN_readPtyDedupConfigOp();

		partybasicDetails = getF_IN_partyBasicDtls();
		String partyType = partybasicDetails.getPartyType();

		if (PartyConstants.PARTY_TYPE_PERSONAL.equalsIgnoreCase(partyType)) {
			log.info("preparePersonalDedupChecks start");

			preparePersonalDedupChecks(partybasicDetails);
			log.info("preparePersonalDedupChecks end");

		}

		else if (PartyConstants.PARTY_TYPE_ENTERPRISE.equalsIgnoreCase(partyType)) {
			log.info("prepareEnterpriselDedupChecks start");
			prepareEnterpriselDedupChecks(partybasicDetails);
			log.info("prepareEnterpriselDedupChecks end");
		}

		/*
		 * else if(PartyConstants.REPORTING_GROUP.equalsIgnoreCase(partyType)){
		 * log.info("prepareReportinglDedupChecks start");
		 * prepareReportinglDedupChecks(); log.info("prepareReportinglDedupChecks end");
		 * }
		 */
	}

	private void preparePersonalDedupChecks(PartyBasicDtls partyBasicDetails) {
		log.info("inside preparePersonalDedupChecks method and started execution"+getF_IN_nationalId());

		String lastName=getF_IN_lastName();
		if(getF_IN_gender()!=null && !("").equals(getF_IN_gender())) {
			lastName=getF_IN_lastName()+"#"+getF_IN_gender();
		}

		for (DedupeKeys dedupKey : readPtyDedupConfigOp.getPerPtySearchKeys()) {
			log.info("dedupKey:::::::::"+dedupKey.getSearchKey());

			switch (dedupKey.getSearchKey()) {
			case "First Name":
				dedupKey.setSearchValue(getF_IN_firstName());
				break;
			case "Last Name":
				dedupKey.setSearchValue(lastName);
				break;
			case "Middle Name":
				dedupKey.setSearchValue(getF_IN_middleName());
				break;
			case "National Unique Identifier":
				dedupKey.setSearchValue(getF_IN_nationalId());
				break;
			// case "National Unique Identifier Type":
			// dedupKey.setSearchValue(getF_IN_nationalIdtype()); break;
			case "Date of Birth":
				dedupKey.setSearchValue(getF_IN_dateOfBirth());
			}
		}

		setF_OUT_readPtyDedupConfigOp(readPtyDedupConfigOp);
		log.info("inside preparePersonalDedupChecks method and end  execution");

	}

	private void prepareEnterpriselDedupChecks(PartyBasicDtls partyBasicDetails) {

		log.info("inside prepareEnterpriselDedupChecks method and started execution");

		for (DedupeKeys dedupKey : readPtyDedupConfigOp.getEntPtySearchKeys()) {
			switch (dedupKey.getSearchKey()) {
			case "Enterprise name":
				dedupKey.setSearchValue(getF_IN_enterpriseName());
				break;
			case "Registered number":
				dedupKey.setSearchValue(getF_IN_registeredID());
				break;
			}

			setF_OUT_readPtyDedupConfigOp(readPtyDedupConfigOp);
		}
		log.info("inside prepareEnterpriselDedupChecks method and end execution");

	}

	/*
	 * private void prepareReportinglDedupChecks() {
	 * log.info("inside prepareReportinglDedupChecks method and started execution");
	 * 
	 * for(DedupeKeys dedupKey:readPtyDedupConfigOp.getRepGrpPtySearchKeys()) {
	 * switch(dedupKey.getSearchKey()) { case "Group name":
	 * dedupKey.setSearchValue(getF_IN_groupName()); break; case "Group Purpose":
	 * dedupKey.setSearchValue(getF_IN_groupPurpose()); break; case
	 * "Group Establishment Date":
	 * dedupKey.setSearchValue(getF_IN_groupEstablishmentDate()); break; } }
	 * 
	 * setF_OUT_readPtyDedupConfigOp(readPtyDedupConfigOp);
	 * log.info("inside prepareReportinglDedupChecks method and end  execution");
	 * 
	 * }
	 */

}