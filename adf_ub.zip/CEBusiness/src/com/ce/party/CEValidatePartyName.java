package com.ce.party;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;

public class CEValidatePartyName {
	


	private final static Log log = LogFactory.getLog(CEValidatePartyName.class.getName());

	public String isValidPartyName(String name) {
        
		//Boolean status = false;
		Connection con = null;
		CallableStatement cstmt = null;
		CB_CMN_PrivateSession privateSession = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory privateFactory = privateSession.createSession();
		String str = null;

		try {

			
			privateSession.beginTransaction();

			con = privateFactory.getJDBCConnection();
			

			String command = "{? = call CUSTOMEXTN.NAME_ADJ.NAME_FLTR(?,?)}";
			cstmt = con.prepareCall(command);
			cstmt.registerOutParameter(1, Types.VARCHAR);

			cstmt.setString(2, name);
			cstmt.setInt(3,1);
			cstmt.execute();
			str = cstmt.getString(1);
			privateSession.commitTransaction();

			//if (str.equals("true")) {
				//status = true;
			//}

		} catch (SQLException se) {
			log.error(se.getMessage());
			privateSession.rollBack();
			//status =  false;
		} finally {
			try {
				cstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			privateSession.closeSession();
		}

		//status = false;
		return str;

	}


	

}
