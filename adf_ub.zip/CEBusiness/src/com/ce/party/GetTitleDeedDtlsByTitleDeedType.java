package com.ce.party;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_GetTitleDeedDtlsByTitleDeedType;



public class GetTitleDeedDtlsByTitleDeedType extends AbstractCE_GetTitleDeedDtlsByTitleDeedType{

	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE+" = ?" + " AND " + IBOCE_TITLEDEEDDETAILS.STATUS+" = ? ";
	private final String shareHolderWhere = " WHERE " + IBOCE_TITLEDEEDSHAREHOLDER.TITLEDEEDID+" = ? ";
	private final String titleDeedLocWhere = " WHERE " + IBOCE_TITLEDEEDLOCATION.TITLEDEEDID+" = ? ";
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal
			.getPersistanceFactory();

	public GetTitleDeedDtlsByTitleDeedType() {
		super();
	}
	
	public GetTitleDeedDtlsByTitleDeedType(BankFusionEnvironment env){
		
	}
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		final Log LOGGER = LogFactory.getLog(GetTitleDeedDtlsByTitleDeedType.class.getName());
				
		String titleDeedType = getF_IN_titleDeedType();
		fetchTitleDeedDetails(titleDeedType);

}
	
	protected void fetchTitleDeedDetails(String titleDeedType){
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
		ArrayList<String> titleDeedParam = new ArrayList<String>();
		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
		
			//titleDeedID = "%";
            titleDeedParam.add(titleDeedType);
            titleDeedParam.add("ACTIVE");
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
            
			boolean select = true;
			
			for (IBOCE_TITLEDEEDDETAILS titleDeedDtls : titleDeedList) {
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedDtls.getCompositeBOID();
				populateShareHolder(titledeeddetailsid.getF_TITLEDEEDID());
				populateTitleDeedLocationDetails(titledeeddetailsid.getF_TITLEDEEDID());
				TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
				titleDeedDetailsType.setAreaSize(titleDeedDtls.getF_AREASIZE());
				titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDetailsType.setDicissionStatus(titleDeedDtls.getF_DICISSIONSTATUS());
				titleDeedDetailsType.setFarmLocation(titleDeedDtls.getF_FARMLOCATION());
				titleDeedDetailsType.setLandPlanNumber(titleDeedDtls.getF_LANDPLANNUMBER());
				titleDeedDetailsType.setLandPlotNumber(titleDeedDtls.getF_LANDPLOTNUMBER());
				titleDeedDetailsType.setLinkedToCollateral(titleDeedDtls.getF_LINKEDTOCOLLATERAL());
				titleDeedDetailsType.setNotes(titleDeedDtls.getF_NOTES());
				titleDeedDetailsType.setReasonForChange(titleDeedDtls.getF_REASONFORCHANGE());
				titleDeedDetailsType.setRetailIndex(titleDeedDtls.getF_RETAILINDEX());
				titleDeedDetailsType.setSelect(select);
				select = false;
				titleDeedDetailsType.setSplitIndicator(titleDeedDtls.getF_SPLITINDICATOR());
				titleDeedDetailsType.setStatus(titleDeedDtls.getF_STATUS());
				titleDeedDetailsType.setTitleDeedNumber(titleDeedDtls.getF_TITLEDEEDNUMBER());
				titleDeedDetailsType.setTitleDeedSource(titleDeedDtls.getF_TITLEDEEDSOURCE());
				titleDeedDetailsType.setTitleDeedStatus(titleDeedDtls.getF_TITLEDEEDSTATUS());
				titleDeedDetailsType.setTitleDeedType(titleDeedDtls.getF_TITLEDEEDTYPE());
				titleDeedDetailsType.setTitleDeedYear(titleDeedDtls.getF_TITLEDEEDYEAR());
				titleDeedDetailsType.setTransactionDate(titleDeedDtls.getF_TRANSACTIONDATE());
				titleDeedDetailsType.setTransactionNotes(titleDeedDtls.getF_NOTESFORAMEND());
				titleDeedDetailsType.setTransactionType(titleDeedDtls.getF_TRANSACTIONTYPE());
				titleDeedDetailsType.setValidFrom(titleDeedDtls.getF_VALIDFROM());
				titleDeedDetailsType.setValidFromHijri(titleDeedDtls.getF_VALIDFROMHIJRI());
				titleDeedDetailsType.setValidTo(titleDeedDtls.getF_VALIDTO());
				titleDeedDetailsType.setValidToHijri(titleDeedDtls.getF_VALIDTOHIJRI());
				titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
			}
			setF_OUT_titleDeedDtlsTypeList(listTitleDeedIdDtlsType);
			
		}
	
	private void populateShareHolder(String titleDeedId) {
		ArrayList<String> shareHolderParam = new ArrayList<String>();
		shareHolderParam.add(titleDeedId);
		List<IBOCE_TITLEDEEDSHAREHOLDER> shareHolderList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOCE_TITLEDEEDSHAREHOLDER.BONAME,shareHolderWhere, shareHolderParam, null, false);
		
		ListShareHolderDtlsType titleShareList = new ListShareHolderDtlsType();
		boolean select = true;
		if(shareHolderList!=null && (!shareHolderList.isEmpty())) {
			
			for(IBOCE_TITLEDEEDSHAREHOLDER ptitle:shareHolderList){
				ShareHolderDtlsType shareHolderDtl = new ShareHolderDtlsType();
				shareHolderDtl.setShareHolderIdpk(ptitle.getBoID());
				shareHolderDtl.setNotes(ptitle.getF_NOTES());
				shareHolderDtl.setOwnershipStatus(ptitle.getF_OWNERSHIPSTATUS());
				shareHolderDtl.setOwnershipType(ptitle.getF_OWNERSHIPTYPE());
				shareHolderDtl.setPartId(ptitle.getF_PARTYID());
				shareHolderDtl.setPartyName(ptitle.getF_SHAREPARTYNAME());
				shareHolderDtl.setSharePercentage(ptitle.getF_SHAREPERCENTAGE());
				
				shareHolderDtl.setSelect(select);
				select= false;
				//shareHolderDtl.setSerialNumber(index+"");
				
				
				titleShareList.addShareHolderDetails(shareHolderDtl);
			}
			setF_OUT_shareHolderDtlsList(titleShareList);
		}
		else {
			setF_OUT_shareHolderDtlsList(new ListShareHolderDtlsType());
		}
		
	}
	
	private void populateTitleDeedLocationDetails(String titleDeedId) {
		ArrayList<String> titleDeedLocParam = new ArrayList<String>();
		titleDeedLocParam.add(titleDeedId);
		List<IBOCE_TITLEDEEDLOCATION> titleDeedLocList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOCE_TITLEDEEDLOCATION.BONAME,titleDeedLocWhere, titleDeedLocParam, null, false);
		
		ListTitleDeedLocDtlsType titleDeedLt = new ListTitleDeedLocDtlsType();
		boolean select = true;
		if(titleDeedLocList!=null && (!titleDeedLocList.isEmpty())) {
			for(IBOCE_TITLEDEEDLOCATION tdeedDtl:titleDeedLocList){
				TitleDeedLocationdtlsType tDeed = new TitleDeedLocationdtlsType();
				tDeed.setTitleDeedLocIdpk(tdeedDtl.getBoID());
				tDeed.setLocationEastDegree(tdeedDtl.getF_LOCEASTDEGREE());
				tDeed.setLocationEastSection(tdeedDtl.getF_LOCEASTSECTION());
				tDeed.setLocationNorthDegree(tdeedDtl.getF_LOCNORTHDEGREE());
				tDeed.setLocationNorthSection(tdeedDtl.getF_LOCNORTHSECTION());
				tDeed.setSerial(tdeedDtl.getF_SERIAL());
				tDeed.setSelect(select);
				select= false;
				titleDeedLt.addTitleDeedLocDtls(tDeed);
			
				//index++;
			}
			setF_OUT_titleDeedDtlsLocList(titleDeedLt);
		}
		else {
			setF_OUT_titleDeedDtlsLocList(new ListTitleDeedLocDtlsType());
		}
		
		
	}
		
		
	}		
	

