package com.ce.party;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.ce.types.FarmLandLocationdtlsType;
import com.misys.ce.types.FarmLandNeighbourdtlsType;
import com.misys.ce.types.FarmLandTitleDeeddtlsType;
import com.misys.ce.types.ListFarmLandLocationDtlsType;
import com.misys.ce.types.ListFarmLandNeighbourDtlsType;
import com.misys.ce.types.ListParentTitleDeedDtlsType;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListSplitTitleDeedDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.ParentTitleDeeddtlsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.SplitTitleDeeddtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDLOCDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDNEIGHBOURDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_AmendTitleDeedDetails;

import bf.com.misys.cbs.types.events.Event;

public class AmendTitleDeedDetails extends AbstractCE_AmendTitleDeedDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	
	private final static String TITLEDEEDSOURCE = "TITLEDEEDSOURCE";
	private final static String TITLEDEEDTYPE = "TITLEDEEDTYPE";

	public AmendTitleDeedDetails() {
		super();
	}

	public AmendTitleDeedDetails(BankFusionEnvironment env) {

	}
	private final int SHAREHOLDER_INFO_MANDATORY = 44000020;
	private final int TITLEDEED_LOC_MANDATORY = 44000021;
	private final int PERCENTAGE_SHOULDBE_HUNDRED = 44000022;
	private final int OWNERSHIP_STATUS_ONE_CURRENT = 44000023;
	private final int SPLI_PERC_HUNDRED = 44000024;
	private final int SPLIT_DETAILS_REQUIRED = 44000042;
	private final int LOCDTLS_SHOULD_BE_UNIQUE = 44000025;
	private final int OWNERSHIP_STATUS_CURRENT_FOR_OWNER = 44000026;
	private final int MORETHAN_ONE_ROW_FOR_PARTNERSHIP = 44000027;
	private final int PARENT_TITLE_DEED_CANT_BE_EMPTY = 44000031;
	private final int TITLEDDEYEAR_FROMDATE_SHOULD_BE_SAME = 44000029;
	private final int PARENT_TITLE_DEEDTYPE_CANNOTBE_5OR11OR16 = 44000032;
	private final int OUTSIDEKSA_TITLEDEEDTYPE_MUST_BE_21OR22 = 44000033;
	private final int TO_DATE_SHOULD_BE_MANDATORY = 44000034;
	private final int SPLIT_INDICATOR_CANNOT_BE_USED = 44000035;
	private final int FARMLAND_DTLS_CANANOT_BE_USED = 44000036;
	private final int REASONFOR_CHANGE_CANNOT_BE_EMPTY = 44000039;
	private final int AMEND_TITLEDEED_NOT_POSSIBLE = 44000040;
	private final int TITLEDEEDTYPE_CAN_BE_AMENDED_ONLY_ONCE = 44000041;
	private final int SHAREHOLDER_PARTYID_CANNOT_BE_DUPLICATE = 44000043;
	private final int SPLIT_TITLEDEED_NUMBER_CANNOT_BE_DUPLICATE = 44000044;
	private final int CONTRACTNUMBER_MANDATORY = 44000046;
	private final int AREA_SIZE_ZERO = 44000443;
	BigDecimal percentage = CommonConstants.BIGDECIMAL_ZERO;
	BigDecimal splitPercentage = CommonConstants.BIGDECIMAL_ZERO;
	private final BigDecimal AMOUNT_HUNDRED = BigDecimal.valueOf(100);
	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK+" = ?";
	private final String splitDetailsWhere = " WHERE " + IBOCE_TITLEDEEDSPLITDTLS.TITLEDEEDID+" = ?";
	private final String titleDeedFarmLocWhere = " WHERE " + IBOCE_FARMLANDLOCDTLS.CONTRACTNUM+" = ?";
	private final String titleDeedFarmNeighbourWhere = " WHERE " + IBOCE_FARMLANDLOCDTLS.CONTRACTNUM+" = ?";

	public void process(BankFusionEnvironment env) throws BankFusionException {
		final Log LOGGER = LogFactory.getLog(AmendTitleDeedDetails.class.getName());
		
		TitleDeedDetailsType titleDeedDtlsType = new TitleDeedDetailsType();
		TitleDeedDetailsType titleDeedDtlsTypeDB = new TitleDeedDetailsType();
		ListShareHolderDtlsType listShareHolderDtlsType = new ListShareHolderDtlsType();
		ListTitleDeedLocDtlsType listTitleDeedLocDtlsType = new ListTitleDeedLocDtlsType();
	    ListParentTitleDeedDtlsType listParentTitleDeedDtlsType = new ListParentTitleDeedDtlsType();
	    FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType = new FarmLandTitleDeeddtlsType();
	    ListFarmLandLocationDtlsType listFarmLandLocationDtlsType = new ListFarmLandLocationDtlsType();
	    ListFarmLandNeighbourDtlsType listFarmLandNeighbourDtlsType = new ListFarmLandNeighbourDtlsType();
	    ListSplitTitleDeedDtlsType listSplitTitleDeedDtlsType = new ListSplitTitleDeedDtlsType();
	    titleDeedDtlsType = getF_IN_titleDeedDtlsType();
	    listShareHolderDtlsType = getF_IN_shareHolderDtlsList();
	    listTitleDeedLocDtlsType = getF_IN_titleDeedLocationDtlsList();
	    listParentTitleDeedDtlsType = getF_IN_parentTitleDeedDtlsList();
	    farmLandTitleDeedDtlsType = getF_IN_farmLandTitleDeedDtlsType();
	    listFarmLandLocationDtlsType = getF_IN_farmLandLocationDtlsList();
	    listFarmLandNeighbourDtlsType = getF_IN_farmLandNeighbourDtlsList();
	    listSplitTitleDeedDtlsType = getF_IN_splitTitleDeedDtlsList();
	    titleDeedDtlsTypeDB = getF_IN_titleDeedDtlsTypeDB();
	    validateTitleDeedDetailsInfo(titleDeedDtlsType,titleDeedDtlsTypeDB);
	    
	    String titleDeedSourceRefCode = PartyUtil.getGCReference(TITLEDEEDSOURCE, titleDeedDtlsTypeDB.getTitleDeedSource());
		String titleDeedTypeRefCode = PartyUtil.getGCReference(TITLEDEEDTYPE,titleDeedDtlsTypeDB.getTitleDeedType());
		titleDeedDtlsTypeDB.setTitleDeedSource(titleDeedSourceRefCode);
		titleDeedDtlsTypeDB.setTitleDeedType(titleDeedTypeRefCode);
		
		titleDeedSourceRefCode = PartyUtil.getGCReference(TITLEDEEDSOURCE, titleDeedDtlsType.getTitleDeedSource());
		titleDeedTypeRefCode = PartyUtil.getGCReference(TITLEDEEDTYPE,titleDeedDtlsType.getTitleDeedType());
		titleDeedDtlsType.setTitleDeedSource(titleDeedSourceRefCode);
		titleDeedDtlsType.setTitleDeedType(titleDeedTypeRefCode);
		
	    if ((titleDeedDtlsTypeDB.getTitleDeedNumber().equals(titleDeedDtlsType.getTitleDeedNumber()))&&(titleDeedDtlsTypeDB.getTitleDeedYear().equals(titleDeedDtlsType.getTitleDeedYear()))&&
	    	(titleDeedDtlsTypeDB.getTitleDeedSource().equals(titleDeedDtlsType.getTitleDeedSource()))&&(titleDeedDtlsTypeDB.getTitleDeedType().equals(titleDeedDtlsType.getTitleDeedType()))&&
	    	(titleDeedDtlsTypeDB.getLandPlanNumber().equals(titleDeedDtlsType.getLandPlanNumber()))&&(titleDeedDtlsTypeDB.getLandPlotNumber().equals(titleDeedDtlsType.getLandPlotNumber())))
	    {
	    	updateTitleDeedDetails(titleDeedDtlsType);
	    }
	    else {
	    	Integer titleDeedVersion = titleDeedDtlsTypeDB.getVersionNumber();
	    	titleDeedVersion = titleDeedVersion+1;
	    	titleDeedDtlsTypeDB.setStatus("INACTIVE");
	    	//status = "INACTIVE";
	    	updateTitleDeedDetails(titleDeedDtlsTypeDB);
	    	createTitleDeedDetails(titleDeedDtlsType,titleDeedVersion);
	    	
	    }
	    //updateTitleDeedDetails(titleDeedDtlsType);
	    ShareHolderDtlsType shareHolderDetailsCreateList[] = listShareHolderDtlsType.getShareHolderDetails();
	    if (shareHolderDetailsCreateList.length==0) {
	    	raiseEvent(SHAREHOLDER_INFO_MANDATORY, env);
	    }
	    validateShareHolderInfo(shareHolderDetailsCreateList);
	    ArrayList shareId = new ArrayList<>();
	    shareId.add(titleDeedDtlsType.getTitleDeedIdpk());
		String clause = "where " + IBOCE_TITLEDEEDSHAREHOLDER.TITLEDEEDID + " = ? ";
		factory.bulkDelete(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, clause, shareId);
	    
		for (ShareHolderDtlsType shareHolderDetailsType : shareHolderDetailsCreateList) {
			
				updateShareHolderDetails(shareHolderDetailsType,titleDeedDtlsType);
			
		}
		
		TitleDeedLocationdtlsType tilteDeedLocDetailsCreateList[] = listTitleDeedLocDtlsType.getTitleDeedLocDtls();
		if (tilteDeedLocDetailsCreateList.length<4) {
	    	raiseEvent(TITLEDEED_LOC_MANDATORY, env);
	    }
		validateTitleDeedLocDetails(tilteDeedLocDetailsCreateList);
		if(tilteDeedLocDetailsCreateList.length!=0) {
		for (TitleDeedLocationdtlsType titleDeedLocDetailsType : tilteDeedLocDetailsCreateList) {
			
			String titleDeedLocId = (null==titleDeedLocDetailsType.getTitleDeedLocIdpk())?"":titleDeedLocDetailsType.getTitleDeedLocIdpk();


//			String titleDeedLocId = titleDeedDtlsType.getTitleDeedNumber()+titleDeedLocDetailsType.getSerial();
			IBOCE_TITLEDEEDLOCATION titleDeedLocDtls = (IBOCE_TITLEDEEDLOCATION) factory
					.findByPrimaryKey(IBOCE_TITLEDEEDLOCATION.BONAME, (titleDeedLocId), true);
			
			if(titleDeedLocDtls == null) {
				
				updateTitleDeedLocDetails(titleDeedLocDetailsType,titleDeedDtlsType,titleDeedLocId);
			}
			else {
				deleteTitleDeedLocDetails(titleDeedLocId);
				updateTitleDeedLocDetails(titleDeedLocDetailsType,titleDeedDtlsType,titleDeedLocId);
			}
			
		}
		}

		ParentTitleDeeddtlsType parentTitleDeedDetailsCreateList[] = listParentTitleDeedDtlsType.getParentTitleDeedDtls();
		validateParentTitleDeedDetailsInfo(titleDeedDtlsType,parentTitleDeedDetailsCreateList);
		
		String parentTDWhere = " WHERE " + IBOCE_PARENTTITLEDEEDDTLS.TITLEDEEDID + " = ?";
		ArrayList<String> params = new ArrayList<String>();
		params.clear();
		params.add(titleDeedDtlsType.getTitleDeedIdpk());
		List<IBOCE_PARENTTITLEDEEDDTLS> parentTitleDeedList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_PARENTTITLEDEEDDTLS.BONAME, parentTDWhere, params, null, true);
		if (parentTitleDeedList != null && (!parentTitleDeedList.isEmpty())) {
			for (IBOCE_PARENTTITLEDEEDDTLS parentTitleDeedDtls : parentTitleDeedList) {
				String parentTitleDeedIdPk = titleDeedDtlsType.getTitleDeedNumber()
						+ parentTitleDeedDtls.getF_TITLEDEEDNUMBER();
				deleteParentTitleDeedDetails(parentTitleDeedIdPk);
			}
		}
		if(parentTitleDeedDetailsCreateList.length!=0) {
			for (ParentTitleDeeddtlsType parentTitleDeedDtlsType : parentTitleDeedDetailsCreateList) {

				String parentTitleDeedIdPk = titleDeedDtlsType.getTitleDeedNumber()
						+ parentTitleDeedDtlsType.getTitleDeedNumber();
				updateParentTitleDeedDetails(parentTitleDeedDtlsType, titleDeedDtlsType, parentTitleDeedIdPk);
			}
		}
		
		 SplitTitleDeeddtlsType splitDetailsCreateList[] = listSplitTitleDeedDtlsType.getSplitTitleDeedDtls();
		 
	        validateSplitDetailsInfo(splitDetailsCreateList,titleDeedDtlsType);
	        
	        ArrayList splitdetailParam = new ArrayList();
	        splitdetailParam.add(titleDeedDtlsType.getTitleDeedIdpk());
	        List<IBOCE_TITLEDEEDSPLITDTLS> splitDetailsList = BankFusionThreadLocal.getPersistanceFactory()
 				.findByQuery(IBOCE_TITLEDEEDSPLITDTLS.BONAME, splitDetailsWhere, splitdetailParam, null, false);
		 
	        
	        if(splitDetailsCreateList.length!=0) {
	        for (SplitTitleDeeddtlsType splitDtlsType : splitDetailsCreateList) {
	        	
//	        	titleDeedSourceRefCode = PartyUtil.getGCReference(TITLEDEEDSOURCE, splitDtlsType.getTitleDeedSource());
//	    		titleDeedTypeRefCode = PartyUtil.getGCReference(TITLEDEEDTYPE,splitDtlsType.getTitleDeedType());
//	    		splitDtlsType.setTitleDeedSource(titleDeedSourceRefCode);
//	    		splitDtlsType.setTitleDeedType(titleDeedTypeRefCode);
	        	
	        	String SplitIdpk = null;
	        	ArrayList<String> titleDeedNumberList = new ArrayList<String>();
	        	if(splitDetailsList.size()>0) {
	        		
	        		for (IBOCE_TITLEDEEDSPLITDTLS TITLEDEEDSPLITDTLS : splitDetailsList) {
	        			String titleDeedNumber = TITLEDEEDSPLITDTLS.getF_TITLEDEEDNUMBER();
	        			
	        			titleDeedNumberList.add(titleDeedNumber);
						
					}
	        		
	        		if(titleDeedNumberList.contains(splitDtlsType.getTitleDeedNumber())) {
	        			
	        			SplitIdpk = splitDtlsType.getSplitTitleDeedIdpk();
	        			deleteSplitTitleDeedDetails(SplitIdpk);
						UpdateSplitTitleDetails(splitDtlsType,titleDeedDtlsType,SplitIdpk);
	        		}
	        		else {
	        			SplitIdpk = GUIDGen.getNewGUID();
	        			UpdateSplitTitleDetails(splitDtlsType,titleDeedDtlsType,SplitIdpk);
	        		}
	        		
	        	}
	        	else {
	        		SplitIdpk = GUIDGen.getNewGUID();
        			UpdateSplitTitleDetails(splitDtlsType,titleDeedDtlsType,SplitIdpk);
	        	}
	        	
	        	/*IBOCE_TITLEDEEDSPLITDTLS splitTitleDeedDtls = (IBOCE_TITLEDEEDSPLITDTLS) factory.findByPrimaryKey(
	    				IBOCE_TITLEDEEDSPLITDTLS.BONAME, splitDtlsType.getSplitTitleDeedIdpk(), true);
	    		if(splitTitleDeedDtls == null) {
	    			return;
	    		}
	    		else {
	    			
	    		}*/
	        	    
			}
	        }
        if(farmLandTitleDeedDtlsType!=null) {
        	
        	IBOCE_FARMLANDDTLS farmLandDtls = (IBOCE_FARMLANDDTLS) factory.findByPrimaryKey(
    				IBOCE_FARMLANDDTLS.BONAME, titleDeedDtlsType.getTitleDeedIdpk(), true);
    		if(farmLandDtls == null) {
    			UpdateFarmLandDetails(farmLandTitleDeedDtlsType,titleDeedDtlsType);
    		}
    		else {
    			    deleteFarmLandTitleDeedDetails(titleDeedDtlsType.getTitleDeedIdpk());
    	        	UpdateFarmLandDetails(farmLandTitleDeedDtlsType,titleDeedDtlsType);
    		}
        }
        
           
		
        FarmLandLocationdtlsType farmLandLocDetailsCreateList[] = listFarmLandLocationDtlsType.getFarmLandLocationDtls();
        
        
        if(farmLandLocDetailsCreateList.length!=0) {
        	if(farmLandTitleDeedDtlsType.getContractNumber()==null || farmLandTitleDeedDtlsType.getContractNumber().isEmpty()) {
        		raiseEvent(CONTRACTNUMBER_MANDATORY, env);
        	}
        	else {
        		
        		 for (FarmLandLocationdtlsType farmLandLocDtlsType : farmLandLocDetailsCreateList) {
        	        	ArrayList farmLocParam = new ArrayList();
        	        	farmLocParam.add(farmLandTitleDeedDtlsType.getContractNumber());
        	            List<IBOCE_FARMLANDLOCDTLS> farmLocList = BankFusionThreadLocal.getPersistanceFactory()
        	    				.findByQuery(IBOCE_FARMLANDLOCDTLS.BONAME, titleDeedFarmLocWhere, farmLocParam, null, false);
        	        	String farmLocId = null;
        	        	ArrayList<String> contractNumList = new ArrayList<String>();
        	        	//IBOCE_FARMLANDLOCDTLS farmLandLocDtls = (IBOCE_FARMLANDLOCDTLS) factory.findByPrimaryKey(
        	    			//	IBOCE_FARMLANDLOCDTLS.BONAME, farmLandLocDtlsType.getFarmLandLocationidpk(), true);
        	        	
        	        	if(farmLocList.size()>0) {
        	        		
        	        		for (IBOCE_FARMLANDLOCDTLS FARMLOCDTLS : farmLocList) {
        	        			String contractNum = farmLandTitleDeedDtlsType.getContractNumber();
        	        			
        	        			contractNumList.add(contractNum);
        						
        					}
        	        		
        	        		if(contractNumList.contains(farmLandTitleDeedDtlsType.getContractNumber())) {
        	        			
        	        			farmLocId = farmLandLocDtlsType.getFarmLandLocationidpk();
        	        			deleteFarmLandLocTitleDeedDetails(farmLocId);
            					UpdateFarmLandLoDetails(farmLandLocDtlsType,farmLandTitleDeedDtlsType,farmLocId,titleDeedDtlsType);
        	        		}
        	        		else {
        	        			farmLocId = GUIDGen.getNewGUID();
        	        			UpdateFarmLandLoDetails(farmLandLocDtlsType,farmLandTitleDeedDtlsType,farmLocId,titleDeedDtlsType);
        	        		}
        	        		
        	        	}
        	        	else {
        	        		farmLocId = GUIDGen.getNewGUID();
    	        			UpdateFarmLandLoDetails(farmLandLocDtlsType,farmLandTitleDeedDtlsType,farmLocId,titleDeedDtlsType);
        	        	}
        	        	
        	        	
        	    		/*if(farmLandLocDtls == null) {
        	    			return;
        	    		}
        	    		else {
        	    			deleteFarmLandLocTitleDeedDetails(farmLandLocDtlsType);
        					UpdateFarmLandLoDetails(farmLandLocDtlsType,farmLandTitleDeedDtlsType);
        	    		}*/
        	        	    
        				
        			} 
        	}
       
        }
        
       
        FarmLandNeighbourdtlsType farmLandNeighbourDetailsCreateList[] = listFarmLandNeighbourDtlsType.getFarmLandNeighbourDtls();
        validateFarmLandDetailsDetailsInfo(titleDeedDtlsType,farmLandTitleDeedDtlsType,farmLandLocDetailsCreateList,farmLandNeighbourDetailsCreateList);
        if(farmLandNeighbourDetailsCreateList.length!=0) {
        for (FarmLandNeighbourdtlsType farmLandNeighbourDtlsType : farmLandNeighbourDetailsCreateList) {
        	
        	String farmNeighbourId = titleDeedDtlsType.getTitleDeedIdpk()+farmLandNeighbourDtlsType.getPartyId();
        	IBOCE_FARMLANDNEIGHBOURDTLS farmLandNeighbourDtls = (IBOCE_FARMLANDNEIGHBOURDTLS) factory.findByPrimaryKey(
    				IBOCE_FARMLANDNEIGHBOURDTLS.BONAME, farmNeighbourId, true);
    		if(farmLandNeighbourDtls == null) {
    			UpdateFarmLandNeighbourDetails(farmLandNeighbourDtlsType,titleDeedDtlsType,farmNeighbourId);
    		}
    		else {
    			deleteFarmLandNeighbourDetails(farmNeighbourId);
				UpdateFarmLandNeighbourDetails(farmLandNeighbourDtlsType,titleDeedDtlsType,farmNeighbourId);
    		}
        	    
		}
        }
    }
	private void updateTitleDeedDetails(TitleDeedDetailsType titleDeedDetails) {
		
		CE_TITLEDEEDDETAILSID titleDeedDtlsId = new CE_TITLEDEEDDETAILSID();
		titleDeedDtlsId.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titleDeedDtlsId.setF_TITLEDEEDVERSION(titleDeedDetails.getVersionNumber());

		IBOCE_TITLEDEEDDETAILS titleDeedDtls = (IBOCE_TITLEDEEDDETAILS) factory
				.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedDtlsId , true);
		
		if(titleDeedDtls == null) {
			return;
		}
		
		titleDeedDtls.setCompositeBOID(titleDeedDtlsId);
		titleDeedDtls.setF_AREASIZE(titleDeedDetails.getAreaSize());
		titleDeedDtls.setF_DICISSIONSTATUS(titleDeedDetails.getDicissionStatus());
		titleDeedDtls.setF_BRANCHSORTCODE(titleDeedDetails.getBranchShortCode());
		titleDeedDtls.setF_FARMLOCATION(titleDeedDetails.getFarmLocation());
		titleDeedDtls.setF_LANDPLANNUMBER(titleDeedDetails.getLandPlanNumber());
		titleDeedDtls.setF_LANDPLOTNUMBER(titleDeedDetails.getLandPlotNumber());
		titleDeedDtls.setF_LINKEDTOCOLLATERAL(titleDeedDetails.getLinkedToCollateral());
		titleDeedDtls.setF_NOTES(titleDeedDetails.getNotes());
		titleDeedDtls.setF_REASONFORCHANGE(titleDeedDetails.getReasonForChange());
		titleDeedDtls.setF_RETAILINDEX(titleDeedDetails.getRetailIndex());
		titleDeedDtls.setF_SPLITINDICATOR(titleDeedDetails.getSplitIndicator());
		titleDeedDtls.setF_STATUS(titleDeedDetails.getStatus());
		titleDeedDtls.setF_TITLEDEEDNUMBER(titleDeedDetails.getTitleDeedNumber());
		titleDeedDtls.setF_TITLEDEEDSOURCE(titleDeedDetails.getTitleDeedSource());
		titleDeedDtls.setF_TITLEDEEDSTATUS(titleDeedDetails.getTitleDeedStatus());
		titleDeedDtls.setF_TITLEDEEDTYPE(titleDeedDetails.getTitleDeedType());
		
		//titleDeedDtlsId.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		//titleDeedDtlsId.setF_TITLEDEEDVERSION(titleDeedDetails.getVersionNumber());
		
		titleDeedDtls.setF_TITLEDEEDYEAR(titleDeedDetails.getTitleDeedYear());
		titleDeedDtls.setF_VALIDFROM(titleDeedDetails.getValidFrom());
		titleDeedDtls.setF_VALIDFROMHIJRI(titleDeedDetails.getValidFromHijri());
		titleDeedDtls.setF_VALIDTO(titleDeedDetails.getValidTo());
		titleDeedDtls.setF_VALIDTOHIJRI(titleDeedDetails.getValidToHijri());
		titleDeedDtls.setF_NOTESFORAMEND(titleDeedDetails.getTransactionNotes());
		titleDeedDtls.setF_REASONFORCHANGE(titleDeedDetails.getReasonForChange());
		titleDeedDtls.setF_TRANSACTIONDATE(titleDeedDetails.getTransactionDate());
		titleDeedDtls.setF_TRANSACTIONTYPE(titleDeedDetails.getTransactionType());
		
	
	}
	
	private void updateShareHolderDetails(ShareHolderDtlsType shareHolderDetailsType,TitleDeedDetailsType titleDeedDetails) {

		IBOCE_TITLEDEEDSHAREHOLDER shareHolderDtls = (IBOCE_TITLEDEEDSHAREHOLDER) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDSHAREHOLDER.BONAME);
		shareHolderDtls.setBoID(GUIDGen.getNewGUID());
		shareHolderDtls.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		shareHolderDtls.setF_PARTYID(shareHolderDetailsType.getPartId());
		shareHolderDtls.setF_SHAREPARTYNAME(shareHolderDetailsType.getPartyName());
		shareHolderDtls.setF_SHAREPERCENTAGE(shareHolderDetailsType.getSharePercentage());
		shareHolderDtls.setF_OWNERSHIPTYPE(shareHolderDetailsType.getOwnershipType());
		shareHolderDtls.setF_OWNERSHIPSTATUS(shareHolderDetailsType.getOwnershipStatus());
		shareHolderDtls.setF_NOTES(shareHolderDetailsType.getNotes());
		factory.create(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, shareHolderDtls);

	}
	
	private void updateTitleDeedLocDetails(TitleDeedLocationdtlsType titleDeedLocDtlsType,TitleDeedDetailsType titleDeedDetails,String titleDeedLocId) {

		IBOCE_TITLEDEEDLOCATION titleDeedLocDtls = (IBOCE_TITLEDEEDLOCATION) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDLOCATION.BONAME);
		
		titleDeedLocDtls.setBoID(titleDeedLocId.isEmpty()?(titleDeedDetails.getTitleDeedNumber() + titleDeedLocDtlsType.getSerial()):titleDeedLocId);
		titleDeedLocDtls.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titleDeedLocDtls.setF_SERIAL(titleDeedLocDtlsType.getSerial());;
		titleDeedLocDtls.setF_LOCNORTHDEGREE(titleDeedLocDtlsType.getLocationNorthDegree());
		titleDeedLocDtls.setF_LOCNORTHSECTION(titleDeedLocDtlsType.getLocationNorthSection());
		titleDeedLocDtls.setF_LOCEASTDEGREE(titleDeedLocDtlsType.getLocationEastDegree());
		titleDeedLocDtls.setF_LOCEASTSECTION(titleDeedLocDtlsType.getLocationEastSection());
		factory.create(IBOCE_TITLEDEEDLOCATION.BONAME, titleDeedLocDtls);
	}
	
	private void updateParentTitleDeedDetails(ParentTitleDeeddtlsType parentTitleDeedDtlsType,TitleDeedDetailsType titleDeedDetails,String parentTitleDeedId) {

		
		IBOCE_PARENTTITLEDEEDDTLS parentTitleDeedDtls = (IBOCE_PARENTTITLEDEEDDTLS) factory
				.getStatelessNewInstance(IBOCE_PARENTTITLEDEEDDTLS.BONAME);
		parentTitleDeedDtls.setBoID(parentTitleDeedId);
		parentTitleDeedDtls.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		parentTitleDeedDtls.setF_TITLEDEEDNUMBER(parentTitleDeedDtlsType.getTitleDeedNumber());
		parentTitleDeedDtls.setF_TITLEDEEDPLANNUMBER(parentTitleDeedDtlsType.getTitleDeedPlanNo());
		parentTitleDeedDtls.setF_TITLEDEEDPLOTNUMBER(parentTitleDeedDtlsType.getTitleDeedPlotNo());
		parentTitleDeedDtls.setF_TITLEDEEDSOURCE(parentTitleDeedDtlsType.getTitleDeedSource());
		parentTitleDeedDtls.setF_TITLEDEEDTYPE(parentTitleDeedDtlsType.getTitleDeedType());
		parentTitleDeedDtls.setF_TITLEDEEDYEAR(parentTitleDeedDtlsType.getTitleDeedYear());
		factory.create(IBOCE_PARENTTITLEDEEDDTLS.BONAME, parentTitleDeedDtls);

	}
	
	private void UpdateFarmLandDetails(FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType,TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_FARMLANDDTLS farmLandDtls = (IBOCE_FARMLANDDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDDTLS.BONAME);
		farmLandDtls.setBoID(titleDeeddtlsType.getTitleDeedIdpk());
		farmLandDtls.setF_CONTRACTDATE(farmLandTitleDeedDtlsType.getContractDate());
		farmLandDtls.setF_CONTRACTNUMBER(farmLandTitleDeedDtlsType.getContractNumber());
		farmLandDtls.setF_CONTRACTSRC(farmLandTitleDeedDtlsType.getContractSource());
		farmLandDtls.setF_ENGOFFDATE(farmLandTitleDeedDtlsType.getEngineerOfficeDate());
		farmLandDtls.setF_ENGOFFNAME(farmLandTitleDeedDtlsType.getEngineerOfficeName());
		farmLandDtls.setF_FARMNAME(farmLandTitleDeedDtlsType.getFarmName());
		farmLandDtls.setF_IRGSRC(farmLandTitleDeedDtlsType.getIrrigationSource());
		farmLandDtls.setF_OWNERNAME(farmLandTitleDeedDtlsType.getOwnerName());
		factory.create(IBOCE_FARMLANDDTLS.BONAME, farmLandDtls);
	}
	
	private void UpdateFarmLandLoDetails(FarmLandLocationdtlsType farmLandLocationDtlsType,FarmLandTitleDeeddtlsType farmLandDtlsType,String farmLocId,TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_FARMLANDLOCDTLS farmLandLocDtls = (IBOCE_FARMLANDLOCDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDLOCDTLS.BONAME);
		farmLandLocDtls.setBoID(farmLocId);
		farmLandLocDtls.setF_TITLEDEEDID(titleDeeddtlsType.getTitleDeedIdpk());
		farmLandLocDtls.setF_CONTRACTNUM(farmLandDtlsType.getContractNumber());
		farmLandLocDtls.setF_DIRECTION(farmLandLocationDtlsType.getDirection());
		farmLandLocDtls.setF_BORDER(farmLandLocationDtlsType.getBordering());
		farmLandLocDtls.setF_LENGTH(farmLandLocationDtlsType.getLength());
		factory.create(IBOCE_FARMLANDLOCDTLS.BONAME, farmLandLocDtls);
	}
	
	private void UpdateSplitTitleDetails(SplitTitleDeeddtlsType splittitleDtlsType,TitleDeedDetailsType titleDeedDtls,String splitTitleDeedIdpk) {
		IBOCE_TITLEDEEDSPLITDTLS splitTitleDeedDtls = (IBOCE_TITLEDEEDSPLITDTLS) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDSPLITDTLS.BONAME);
		splitTitleDeedDtls.setBoID(splitTitleDeedIdpk);
		splitTitleDeedDtls.setF_PERCENTAGE(splittitleDtlsType.getSplitPercentage());
		splitTitleDeedDtls.setF_TITLEDEEDID(titleDeedDtls.getTitleDeedIdpk());
		splitTitleDeedDtls.setF_TITLEDEEDNUMBER(splittitleDtlsType.getTitleDeedNumber());
		splitTitleDeedDtls.setF_TITLEDEEDPLANNUMBER(splittitleDtlsType.getTitleDeedPlanNo());
		splitTitleDeedDtls.setF_TITLEDEEDPLOTNUMBER(splittitleDtlsType.getTitleDeedPlotNo());
		splitTitleDeedDtls.setF_TITLEDEEDSOURCE(splittitleDtlsType.getTitleDeedSource());
		splitTitleDeedDtls.setF_TITLEDEEDTYPE(splittitleDtlsType.getTitleDeedType());
		splitTitleDeedDtls.setF_TITLEDEEDYEAR(splittitleDtlsType.getTitleDeedYear());
		factory.create(IBOCE_TITLEDEEDSPLITDTLS.BONAME, splitTitleDeedDtls);
	}
	private void UpdateFarmLandNeighbourDetails(FarmLandNeighbourdtlsType farmLandNeighbourDtl,TitleDeedDetailsType titleDeedDtls,String farmNeighbourId) {
		IBOCE_FARMLANDNEIGHBOURDTLS farmLandNeighbourDtls = (IBOCE_FARMLANDNEIGHBOURDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME);
		farmLandNeighbourDtls.setBoID(farmNeighbourId);
		farmLandNeighbourDtls.setF_PARTYID(farmLandNeighbourDtl.getPartyId());
		farmLandNeighbourDtls.setF_PARTYNAME(farmLandNeighbourDtl.getPartyName());
		farmLandNeighbourDtls.setF_TITLEDEEDID(titleDeedDtls.getTitleDeedIdpk());
		factory.create(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME, farmLandNeighbourDtls);
	}
	
	private void deleteShareHolderDetails(String shareHolderId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, (shareHolderId), false);

	}
	private void deleteTitleDeedLocDetails(String titleDeedLocId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_TITLEDEEDLOCATION.BONAME, (titleDeedLocId), false);

	}
	private void deleteParentTitleDeedDetails(String parentTitleDeedId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);
    	IBOCE_PARENTTITLEDEEDDTLS parentTitleDeedDtls = (IBOCE_PARENTTITLEDEEDDTLS) factory.findByPrimaryKey(
				IBOCE_PARENTTITLEDEEDDTLS.BONAME, parentTitleDeedId, true);
    	if(null != parentTitleDeedDtls)
    		factory.remove(IBOCE_PARENTTITLEDEEDDTLS.BONAME, (parentTitleDeedId), false);

	}
	private void deleteSplitTitleDeedDetails(String splitTitleDeedIdpk) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_TITLEDEEDSPLITDTLS.BONAME, (splitTitleDeedIdpk), false);

	}
	private void deleteFarmLandLocTitleDeedDetails(String farmLocId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_FARMLANDLOCDTLS.BONAME, (farmLocId), false);

	}
	
	private void deleteFarmLandTitleDeedDetails(String titleDeedId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_FARMLANDDTLS.BONAME, (titleDeedId), false);

	}
	private void deleteFarmLandNeighbourDetails(String farmNeighbourId) {

		// IBOCE_TITLEDEEDDETAILS titleDeedDtlsDelete =
		// (IBOCE_TITLEDEEDDETAILS)factory.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME,
		// titleDeedDtlsType.getIdPk(), false);

		factory.remove(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME, (farmNeighbourId), false);

	}
	private void createTitleDeedDetails(TitleDeedDetailsType titleDeedDetails,Integer titleDeedVersion) {
		IBOCE_TITLEDEEDDETAILS titleDeedDtls = (IBOCE_TITLEDEEDDETAILS) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDDETAILS.BONAME);
		
		titleDeedDtls.setF_AREASIZE(titleDeedDetails.getAreaSize());
		titleDeedDtls.setF_DICISSIONSTATUS(titleDeedDetails.getDicissionStatus());
		titleDeedDtls.setF_BRANCHSORTCODE(titleDeedDetails.getBranchShortCode());
		titleDeedDtls.setF_FARMLOCATION(titleDeedDetails.getFarmLocation());
		titleDeedDtls.setF_LANDPLANNUMBER(titleDeedDetails.getLandPlanNumber());
		titleDeedDtls.setF_LANDPLOTNUMBER(titleDeedDetails.getLandPlotNumber());
		titleDeedDtls.setF_LINKEDTOCOLLATERAL(titleDeedDetails.getLinkedToCollateral());
		titleDeedDtls.setF_NOTES(titleDeedDetails.getNotes());
		titleDeedDtls.setF_REASONFORCHANGE(titleDeedDetails.getReasonForChange());
		titleDeedDtls.setF_RETAILINDEX(titleDeedDetails.getRetailIndex());
		titleDeedDtls.setF_SPLITINDICATOR(titleDeedDetails.getSplitIndicator());
		titleDeedDtls.setF_STATUS("ACTIVE");
		titleDeedDtls.setF_TITLEDEEDNUMBER(titleDeedDetails.getTitleDeedNumber());
		titleDeedDtls.setF_TITLEDEEDSOURCE(titleDeedDetails.getTitleDeedSource());
		titleDeedDtls.setF_TITLEDEEDSTATUS(titleDeedDetails.getTitleDeedStatus());
		titleDeedDtls.setF_TITLEDEEDTYPE(titleDeedDetails.getTitleDeedType());
		CE_TITLEDEEDDETAILSID titledeeddetailsid = new CE_TITLEDEEDDETAILSID();
		titledeeddetailsid.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titledeeddetailsid.setF_TITLEDEEDVERSION(titleDeedVersion);
		titleDeedDtls.setCompositeBOID(titledeeddetailsid);
		//titleDeedDtls.setCompositeBOID(1);
		titleDeedDtls.setF_TITLEDEEDYEAR(titleDeedDetails.getTitleDeedYear());
		titleDeedDtls.setF_VALIDFROM(titleDeedDetails.getValidFrom());
		titleDeedDtls.setF_VALIDFROMHIJRI(titleDeedDetails.getValidFromHijri());
		titleDeedDtls.setF_VALIDTO(titleDeedDetails.getValidTo());
		titleDeedDtls.setF_VALIDTOHIJRI(titleDeedDetails.getValidToHijri());
		titleDeedDtls.setF_TRANSACTIONDATE(titleDeedDetails.getTransactionDate());
		titleDeedDtls.setF_TRANSACTIONTYPE(titleDeedDetails.getTransactionType());
		titleDeedDtls.setF_NOTESFORAMEND(titleDeedDetails.getTransactionNotes());
		factory.create(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedDtls);
	}
	
	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}
	
	private void validateShareHolderInfo(ShareHolderDtlsType[] shareHolderDetailsCreateList) {
		ArrayList<String> ownershipStatusList = new ArrayList<String>();
		ArrayList<String> partyIdList = new ArrayList<String>();
		int count = 0;
		for (ShareHolderDtlsType shareHolderDtlsType : shareHolderDetailsCreateList) {
			String ownershipType = shareHolderDtlsType.getOwnershipType();
			percentage = percentage.add(shareHolderDtlsType.getSharePercentage());
			String ownershipStatus = shareHolderDtlsType.getOwnershipStatus();
			if ((ownershipType.equals("OWNER"))&&(ownershipStatus.equals("CURRENT"))) {
				count++;
			}
			if (count>1) {
				raiseEvent(OWNERSHIP_STATUS_CURRENT_FOR_OWNER, env);
			}
			
			if ((ownershipType.equals("PARTNERSHIP"))&&(shareHolderDetailsCreateList.length<=1)) {
				raiseEvent(MORETHAN_ONE_ROW_FOR_PARTNERSHIP, env);
			}
			
			ownershipStatusList.add(ownershipStatus);
            String partyId = shareHolderDtlsType.getPartId();
			
			/*if(partyIdList.contains(partyId)) {
				raiseEvent(SHAREHOLDER_PARTYID_CANNOT_BE_DUPLICATE, env);
			}
			partyIdList.add(partyId);
			*/
		}
		if ((percentage.compareTo(AMOUNT_HUNDRED) == 1)) {
			raiseEvent(PERCENTAGE_SHOULDBE_HUNDRED, env);
		}
		
		if(!ownershipStatusList.contains("CURRENT")) {
			raiseEvent(OWNERSHIP_STATUS_ONE_CURRENT, env);
		}
		
		
		
	}
	
private void validateSplitDetailsInfo(SplitTitleDeeddtlsType[] splitTitleDtlsTypeList,TitleDeedDetailsType titleDeedDtlsType) {
		
	    ArrayList<String> titleDeedNumberList = new ArrayList<String>();
		
		if(titleDeedDtlsType.getSplitIndicator().equals("YES")) {
			if(splitTitleDtlsTypeList.length==0) {
				raiseEvent(SPLIT_DETAILS_REQUIRED, env);
			}
			
		}
		if(splitTitleDtlsTypeList.length>0) {
			for (SplitTitleDeeddtlsType splitDetilsType : splitTitleDtlsTypeList) {
				
				String titleDeedNumber = splitDetilsType.getTitleDeedNumber();
				if(titleDeedNumberList.contains(titleDeedNumber)) {
					raiseEvent(SPLIT_TITLEDEED_NUMBER_CANNOT_BE_DUPLICATE, env);
				}
				titleDeedNumberList.add(titleDeedNumber);
				splitPercentage = splitPercentage.add(splitDetilsType.getSplitPercentage());
				
			}
			if ((splitPercentage.compareTo(AMOUNT_HUNDRED) == 1)|| (splitPercentage.compareTo(AMOUNT_HUNDRED) == -1)) {
				raiseEvent(SPLI_PERC_HUNDRED, env);
			}
		}
		
		
		
		
	}
	
private void validateTitleDeedLocDetails(TitleDeedLocationdtlsType[] titleDeedLocDetailsList) {
	     //ArrayList<TitleDeedLocationdtlsValObj> titleDeedLocList = new ArrayList<TitleDeedLocationdtlsValObj>();
	     //ArrayList<TitleDeedLocationdtlsValObj> transformedObjectList = new ArrayList<TitleDeedLocationdtlsValObj>();
	    if(!isDuplicteTitleDeedLocDtls(titleDeedLocDetailsList)) {
	    	raiseEvent(LOCDTLS_SHOULD_BE_UNIQUE, env);
	    }
		/*for (TitleDeedLocationdtlsValObj OldTitleDeedLocDtl : transformedObjectList) {
			
			if(titleDeedLocList.contains(OldTitleDeedLocDtl)) {
				raiseEvent(LOCDTLS_SHOULD_BE_UNIQUE, env);
			}
			titleDeedLocList.add(OldTitleDeedLocDtl);

		}*/
				
	}

private boolean isDuplicteTitleDeedLocDtls(TitleDeedLocationdtlsType[] titleDeedLocDetailsList) {
	ArrayList<TitleDeedLocationdtlsValObj> transformedObjectList = new ArrayList<TitleDeedLocationdtlsValObj>();
	
	HashSet filterDuplicates= new HashSet();
	
	
	for(TitleDeedLocationdtlsType titleDeedLocType :titleDeedLocDetailsList) {
		String appendedValue="";
		TitleDeedLocationdtlsValObj transformedObject = new TitleDeedLocationdtlsValObj();
		transformedObject.set_locationEastDegree(titleDeedLocType.getLocationEastDegree());
		transformedObject.set_locationNorthDegree(titleDeedLocType.getLocationNorthDegree());
		transformedObject.set_locationNorthSection(titleDeedLocType.getLocationNorthSection());
		transformedObject.set_locationEastSection(titleDeedLocType.getLocationEastSection());
		transformedObjectList.add(transformedObject);
		appendedValue= String.valueOf(titleDeedLocType.getLocationEastDegree())+String.valueOf(titleDeedLocType.getLocationNorthDegree())+
				String.valueOf(titleDeedLocType.getLocationNorthSection())+String.valueOf(titleDeedLocType.getLocationEastSection());
		filterDuplicates.add(appendedValue);
	}
	if(filterDuplicates.size()<transformedObjectList.size()) {
		return false;
	}
	return true;
}

private void validateTitleDeedDetailsInfo(TitleDeedDetailsType titleDeedDtlsType,TitleDeedDetailsType titleDeedDtlsDB) {
	
	ArrayList titleDeedParam = new ArrayList();
	String titleDeedTypeDB = titleDeedDtlsDB.getTitleDeedType();
	String titleDeedStatus = titleDeedDtlsType.getTitleDeedStatus();
	String titleDeedYear =String.valueOf(titleDeedDtlsType.getTitleDeedYear());
	String fromDate = titleDeedDtlsType.getValidFromHijri();
	String DateArr[] = null  ;
	if(!fromDate.isEmpty())
	{
	DateArr = fromDate.split("-");
	}
	if ((DateArr != (null)) && !titleDeedYear.equals(DateArr[2])) {
    	raiseEvent(TITLEDDEYEAR_FROMDATE_SHOULD_BE_SAME, env);
    }
    if(fromDate.equals("") && !titleDeedYear.equals("0"))
    {
    	raiseEvent(TITLEDDEYEAR_FROMDATE_SHOULD_BE_SAME, env);
    }
    
    BigDecimal areaSize = titleDeedDtlsType.getAreaSize();
	if(areaSize.compareTo(BigDecimal.ZERO) == 0 || areaSize.compareTo(BigDecimal.ZERO)<1)
	{
		raiseEvent(AREA_SIZE_ZERO, env);
	}
	
	String titleDeedType = titleDeedDtlsType.getTitleDeedType();
	if(titleDeedType.equals("11")) {
		if (titleDeedDtlsType.getValidToHijri()==null || titleDeedDtlsType.getValidToHijri().isEmpty()) {
			raiseEvent(TO_DATE_SHOULD_BE_MANDATORY, env);
		}
		
	}
	
	if(titleDeedType.equals("1")||titleDeedType.equals("2")){ 
		if(titleDeedDtlsType.getSplitIndicator().equals("YES")) {
			raiseEvent(SPLIT_INDICATOR_CANNOT_BE_USED, env);
		}
		
	}
	
	if(titleDeedStatus.equals("INACTIVE")) {
		if (titleDeedDtlsType.getReasonForChange().equals(null)||titleDeedDtlsType.getReasonForChange().isEmpty()) {
			raiseEvent(REASONFOR_CHANGE_CANNOT_BE_EMPTY, env);
		}
	}
	
	if((titleDeedTypeDB.equals("3")||titleDeedTypeDB.equals("6"))&&((!titleDeedType.equals("3"))&&(!titleDeedType.equals("6")))) {
		
		raiseEvent(AMEND_TITLEDEED_NOT_POSSIBLE, env);
	}
	
	titleDeedParam.add(titleDeedDtlsType.getTitleDeedIdpk());
	int count = 0;
	String titleDeedTypeFromDBPrevious = null;
	List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
            IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
	
	if(titleDeedList.size()>1) {
		for (IBOCE_TITLEDEEDDETAILS titleDeedDtlsTypeFromDB : titleDeedList) {
			String titleDeedTypeFromDB = titleDeedDtlsTypeFromDB.getF_TITLEDEEDTYPE();
			
			if (!titleDeedTypeFromDB.equals(titleDeedTypeFromDBPrevious)) {
				count=count+1;
				if(!titleDeedType.equals(titleDeedTypeDB)) {
					if(count==1) {
						raiseEvent(TITLEDEEDTYPE_CAN_BE_AMENDED_ONLY_ONCE, env);
				
					
				}
			}
				
		}
			titleDeedTypeFromDBPrevious = titleDeedTypeFromDB;
		}
	}
	
	
	
}

private void validateParentTitleDeedDetailsInfo(TitleDeedDetailsType titleDeedDtlsType,ParentTitleDeeddtlsType[] parentTitleDeedDtlsList) {
	 
	String titleDeedType = titleDeedDtlsType.getTitleDeedType();
	String titleDeedSource = titleDeedDtlsType.getTitleDeedSource();
	int titleDeedTypeInt = Integer.valueOf(titleDeedType);
	int titleDeedSourceInt = Integer.valueOf(titleDeedSource);
	if((titleDeedTypeInt==5 || titleDeedTypeInt==11)&&(titleDeedSourceInt>=3&&titleDeedSourceInt<=1713)) {
		if(parentTitleDeedDtlsList.length==0) {
			raiseEvent(PARENT_TITLE_DEED_CANT_BE_EMPTY, env);
			
		}
		else {
			for (ParentTitleDeeddtlsType parentTitleDeeddtlsType : parentTitleDeedDtlsList) {
				if(parentTitleDeeddtlsType.getTitleDeedType().equals("5")||parentTitleDeeddtlsType.getTitleDeedType().equals("11")||parentTitleDeeddtlsType.getTitleDeedType().equals("16")) {
					raiseEvent(PARENT_TITLE_DEEDTYPE_CANNOTBE_5OR11OR16, env);
				}
				
			}
		}
			
		
		
	}
	
	if ((titleDeedSource.equals("9000")) && (!titleDeedType.equals("21")&&!titleDeedType.equals("22"))) {
		
		raiseEvent(OUTSIDEKSA_TITLEDEEDTYPE_MUST_BE_21OR22, env);
	}
	
   
}

private void validateFarmLandDetailsDetailsInfo(TitleDeedDetailsType titleDeedDtlsType,FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType,FarmLandLocationdtlsType[] farmLandLocDtlsType,FarmLandNeighbourdtlsType[] farmLandNeighbourDtlsType) {
      if(!titleDeedDtlsType.getTitleDeedType().equals("18")) {
		String contractNumber = farmLandTitleDeedDtlsType.getContractNumber();
		if ((!contractNumber.isEmpty())||(farmLandLocDtlsType.length!=0)||(farmLandNeighbourDtlsType.length!=0)) {
			raiseEvent(FARMLAND_DTLS_CANANOT_BE_USED, env);
		}
		
	}
}
}
