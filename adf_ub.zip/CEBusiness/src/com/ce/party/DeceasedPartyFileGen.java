package com.ce.party;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.ub.systeminformation.IBusinessInformation;
import com.misys.ub.systeminformation.IBusinessInformationService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PTY_DeceasedPartyDtls;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_DeceasedPartyFileGen;

import bf.com.misys.cbs.types.events.Event;

/**
 * 
 * @author Rajeevan
 * Desc: This class will generate a .csv file with the details of deceased party.
 */
public class DeceasedPartyFileGen extends AbstractCE_PTY_DeceasedPartyFileGen{
	
	private static final long serialVersionUID = 1L;
	Log logger = LogFactory.getLog(DeceasedPartyFileGen.class);
	
	private StringBuilder stringBuilder;
	private static IBusinessInformation bizInfo;
	private final String MODULE_NAME = "PARTY";
	private final String MODULE_PARAMETER = "DECEASED_PTY_FILE_LOC";
	private final int fileGenConfirmEvent = 44000010;
	
	private final String getMaxBatchNoQuery = "SELECT MAX(A." + IBOCE_PTY_DeceasedPartyDtls.DLBATCHNO + ") AS " + IBOCE_PTY_DeceasedPartyDtls.DLBATCHNO + 
			" FROM " + IBOCE_PTY_DeceasedPartyDtls.BONAME + " A WHERE A." + IBOCE_PTY_DeceasedPartyDtls.DLBATCHDT + " BETWEEN ? AND ?"  ;
	
	static {
		IBusinessInformationService ubInformationService = (IBusinessInformationService) ServiceManagerFactory.getInstance()
				.getServiceManager().getServiceForName(IBusinessInformationService.BUSINESS_INFORMATION_SERVICE);
		bizInfo = ubInformationService.getBizInfo();
	}
	
	public DeceasedPartyFileGen(BankFusionEnvironment env){
		super(env);
	}
	
	
	public void process(BankFusionEnvironment env){
		
		VectorTable deceasedPrtyDtlsTable = new VectorTable();
		
		deceasedPrtyDtlsTable = getF_IN_deceasedPartyDtls();

		
		if ((deceasedPrtyDtlsTable != null) && (deceasedPrtyDtlsTable.size() > 0)) {
			int batchNo = generateBatchNumber();
			boolean isFileGenReq = false;
			Object obj = bizInfo.getModuleConfigurationValue(MODULE_NAME, MODULE_PARAMETER, env);
			String fileLoc = CommonConstants.EMPTY_STRING;
			if (null != obj) {
				fileLoc  = (String)obj;
			}
			
			File file = new File(fileLoc + File.separator + "Deceased_Party_File_" + batchNo + ".csv");
			BufferedWriter writer = null;
			stringBuilder = new StringBuilder();
			
			stringBuilder = createFileHeader(batchNo);
			
			
			for (int i = 0; i < deceasedPrtyDtlsTable.size(); ++i) {
				
				HashMap row = deceasedPrtyDtlsTable.getRowTags(i);
				boolean isApproved = (boolean) row.get("APPROVED");
				int existingBatchNumber = (int) row.get("DLBATCHNO");
				String accountNumber = (String) row.get("BOID");
				String status = (String) row.get("ULSTATUS");
				
				if(isApproved && (existingBatchNumber==0) && status.equals("Success")) {
					isFileGenReq = true;
					stringBuilder = createFileBody(row);
					updateDeceasedPtyDtlsTable(batchNo, accountNumber);
				}
				
			}	
			try {
				if(isFileGenReq) {
					writer = new BufferedWriter(new FileWriter(file));
					writer.write(stringBuilder.toString());	
					raiseEvent(fileGenConfirmEvent, env);
				}
				 
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
			    if (writer != null)
					try {
						writer.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
			
		}
		
	}
	
	/**
	 * Method to create the csv file header
	 * @return stringBuilder
	 */
	private StringBuilder createFileHeader(int batchNumber) {
		
		stringBuilder.append("This needs to be confirmed by the bank;");
		stringBuilder.append("\n");
		stringBuilder.append(batchNumber);
		stringBuilder.append(" operation number;");
		stringBuilder.append("\n");
		stringBuilder.append("Ref No;");
		stringBuilder.append("National ID No;");
		stringBuilder.append("Name;");
		stringBuilder.append("Another ID Part1;");
		stringBuilder.append("Another ID Part1;");
		stringBuilder.append("ID Loc Code;");
		stringBuilder.append("ID Loc Name Of Location;");
		stringBuilder.append("Amount");
		stringBuilder.append("\n");
		
		return stringBuilder;
	}
	
	/**
	 * Method to create the body of the csv file
	 * @param inputVector
	 * @return stringBuilder
	 */
	private StringBuilder createFileBody(HashMap row){
		
		stringBuilder.append((Integer) row.get("REFNO"));
		stringBuilder.append(";");
		stringBuilder.append((Integer) row.get("BORROWERNATID"));
		stringBuilder.append(";");
		
		// Arabic Adjustments
		String zano = (String) row.get("ALHAFIZANO") + ";";
		stringBuilder.append("\u202B");
		zano = zano + (String) row.get("BORROWERNAME");
		zano = (String) row.get("ALHAFIZANO") + ";" + zano;
		zano = (String) row.get("LOANBR") + ";" + ";" + zano;
		zano = (BigDecimal) row.get("OUTSTANDINGAMT") + ";" + zano;
		stringBuilder.append(zano);
		stringBuilder.append("\u202C");
		stringBuilder.append("\n");
		
		return stringBuilder;
	}
	
	/**
	 * Method to generate the unique batch number
	 * @return batchNumber
	 */
	private int generateBatchNumber() {
		
		int batchNumber = 0;
		List deceasedPtyList;
		SimplePersistentObject simplePersistentObject;
		
		Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
		
		int year = businessDate.getYear();
				
	    Date startDate = Date.valueOf( year + "-01-01" );
	    Date endDate = Date.valueOf( year + "-12-31" );
	    
		ArrayList params = new ArrayList();
		params.add(startDate);
		params.add(endDate);
				
		deceasedPtyList = BankFusionThreadLocal.getPersistanceFactory().executeGenericQuery(getMaxBatchNoQuery, params, null, false);
		if(null!=deceasedPtyList && deceasedPtyList.size()!=0) {
			Iterator deceasedPtyListIterator = deceasedPtyList.iterator();
			while(deceasedPtyListIterator.hasNext()) {
				simplePersistentObject = (SimplePersistentObject)deceasedPtyListIterator.next();
				batchNumber = (int) simplePersistentObject.getDataMap().get(IBOCE_PTY_DeceasedPartyDtls.DLBATCHNO);
				if(batchNumber==0) {
					batchNumber = year*100;
				}else {
					batchNumber = batchNumber + 1;
				}
			}
		}else {
			batchNumber = year*100;
		}

		return batchNumber;
	}
	/**
	 * Method to update the batch generated date and the batch number in the deceased party details table
	 * @param batchNo
	 */
    private void updateDeceasedPtyDtlsTable(int batchNo, String accountId) {
    	IBOCE_PTY_DeceasedPartyDtls deceasedParty = (IBOCE_PTY_DeceasedPartyDtls)BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOCE_PTY_DeceasedPartyDtls.BONAME, accountId, false);
    	deceasedParty.setF_DLBATCHDT(SystemInformationManager.getInstance().getBFBusinessDate());
    	deceasedParty.setF_DLBATCHNO(batchNo);
    }
    
    /**
     * Method to raise event based on the event number
     * @param eventNo
     * @param env
     */
    private void raiseEvent(int eventNo,BankFusionEnvironment env) {
    	Event event = new Event();
    	event.setEventNumber(eventNo);
    	EventsHelper eventsHelper = new EventsHelper();
    	eventsHelper.handleEvent(event, env);
    }
	
		
}
