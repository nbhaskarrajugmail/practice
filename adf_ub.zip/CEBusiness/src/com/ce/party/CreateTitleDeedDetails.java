package com.ce.party;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.ce.types.FarmLandLocationdtlsType;
import com.misys.ce.types.FarmLandNeighbourdtlsType;
import com.misys.ce.types.FarmLandTitleDeeddtlsType;
import com.misys.ce.types.ListFarmLandLocationDtlsType;
import com.misys.ce.types.ListFarmLandNeighbourDtlsType;
import com.misys.ce.types.ListParentTitleDeedDtlsType;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListSplitTitleDeedDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.ParentTitleDeeddtlsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.SplitTitleDeeddtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDLOCDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDNEIGHBOURDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_CreateTitleDeedDetails;

import bf.com.misys.cbs.types.events.Event;

public class CreateTitleDeedDetails extends AbstractCE_PTY_CreateTitleDeedDetails {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public CreateTitleDeedDetails() {
		super();
	}

	public CreateTitleDeedDetails(BankFusionEnvironment env) {

	}

	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " = ?" + " AND "
			+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDYEAR + " = ? "+ " AND " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDSOURCE + " = ?"
			+ " AND "+ IBOCE_TITLEDEEDDETAILS.TITLEDEEDTYPE + " = ?"+ " AND " + IBOCE_TITLEDEEDDETAILS.LANDPLANNUMBER + " = ?"
			+ " AND " + IBOCE_TITLEDEEDDETAILS.LANDPLOTNUMBER + " = ?";
	private final int SHAREHOLDER_INFO_MANDATORY = 44000020;
	private final int TITLEDEED_LOC_MANDATORY = 44000021;
	private final int PERCENTAGE_SHOULDBE_HUNDRED = 44000022;
	private final int OWNERSHIP_STATUS_ONE_CURRENT = 44000023;
	private final int SPLI_PERC_HUNDRED = 44000024;
	private final int SPLIT_DETAILS_REQUIRED = 44000042;
	private final int LOCDTLS_SHOULD_BE_UNIQUE = 44000025;
	private final int OWNERSHIP_STATUS_CURRENT_FOR_OWNER = 44000026;
	private final int MORETHAN_ONE_ROW_FOR_PARTNERSHIP = 44000027;
	private final int PARENT_TITLE_DEED_CANT_BE_EMPTY = 44000031;
	private final int TITLEDDEYEAR_FROMDATE_SHOULD_BE_SAME = 44000029;
	private final int PARENT_TITLE_DEEDTYPE_CANNOTBE_5OR11OR16 = 44000032;
	private final int OUTSIDEKSA_TITLEDEEDTYPE_MUST_BE_21OR22 = 44000033;
	private final int TO_DATE_SHOULD_BE_MANDATORY = 44000034;
	private final int SPLIT_INDICATOR_CANNOT_BE_USED = 44000035;
	private final int SHAREHOLDER_PARTYID_CANNOT_BE_DUPLICATE = 44000043;
	private final int FARMLAND_DTLS_CANANOT_BE_USED = 44000036;
	private final int SPLIT_TITLEDEED_NUMBER_CANNOT_BE_DUPLICATE = 44000044;
	private final int TITLEDEED_COMBINATION_UNIQUE = 44000045;
	private final int AREA_SIZE_ZERO = 44000443;
	
	BigDecimal percentage = CommonConstants.BIGDECIMAL_ZERO;
	BigDecimal splitPercentage = CommonConstants.BIGDECIMAL_ZERO;
	private final BigDecimal AMOUNT_HUNDRED = BigDecimal.valueOf(100);
	BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();

	public void process(BankFusionEnvironment env) throws BankFusionException {
		final Log LOGGER = LogFactory.getLog(CreateTitleDeedDetails.class.getName());

		TitleDeedDetailsType titleDeedDtlsType = new TitleDeedDetailsType();
		ListShareHolderDtlsType listShareHolderDtlsType = new ListShareHolderDtlsType();
		ListTitleDeedLocDtlsType listTitleDeedLocDtlsType = new ListTitleDeedLocDtlsType();
		ListParentTitleDeedDtlsType listParentTitleDeedDtlsType = new ListParentTitleDeedDtlsType();
		FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType = new FarmLandTitleDeeddtlsType();
		ListFarmLandLocationDtlsType listFarmLandLocationDtlsType = new ListFarmLandLocationDtlsType();
		ListFarmLandNeighbourDtlsType listFarmLandNeighbourDtlsType = new ListFarmLandNeighbourDtlsType();
		ListSplitTitleDeedDtlsType listSplitTitleDeedDtlsType = new ListSplitTitleDeedDtlsType();
		titleDeedDtlsType = getF_IN_titleDeedDetailsType();
		listShareHolderDtlsType = getF_IN_shareHolderDtlsList();
		listTitleDeedLocDtlsType = getF_IN_titleDeedLocDtlsList();
		listParentTitleDeedDtlsType = getF_IN_parentTitleDeedDtlsList();
		farmLandTitleDeedDtlsType = getF_IN_farmLandTitleDeedDtlsType();
		listFarmLandLocationDtlsType = getF_IN_farmLandLocationDtlsList();
		listFarmLandNeighbourDtlsType = getF_IN_farmLandNeighbourDtlsList();
		listSplitTitleDeedDtlsType = getF_IN_splitTitleDeedDtlsList();
		validateTitleDeedDetailsInfo(titleDeedDtlsType);
		createTitleDeedDetails(titleDeedDtlsType);

		ShareHolderDtlsType shareHolderDetailsCreateList[] = listShareHolderDtlsType.getShareHolderDetails();
		if (shareHolderDetailsCreateList.length == 0) {
			raiseEvent(SHAREHOLDER_INFO_MANDATORY, env);
		}
		validateShareHolderInfo(shareHolderDetailsCreateList);
		for (ShareHolderDtlsType shareHolderDetailsType : shareHolderDetailsCreateList) {
			// BigDecimal percentage = shareHolderDetailsType.getSharePercentage();
			IBOCE_TITLEDEEDSHAREHOLDER shareHolderDtls = (IBOCE_TITLEDEEDSHAREHOLDER) factory.findByPrimaryKey(
					IBOCE_TITLEDEEDSHAREHOLDER.BONAME,
					titleDeedDtlsType.getTitleDeedNumber() + shareHolderDetailsType.getPartId(), true);
			if (shareHolderDtls == null) {

				createShareHolderDetails(shareHolderDetailsType, titleDeedDtlsType);
			}

			// createShareHoldetDetails(shareHolderDetailsType);
		}

		TitleDeedLocationdtlsType tilteDeedLocDetailsCreateList[] = listTitleDeedLocDtlsType.getTitleDeedLocDtls();
		if (tilteDeedLocDetailsCreateList.length < 4) {
			raiseEvent(TITLEDEED_LOC_MANDATORY, env);
		}
		validateTitleDeedLocDetails(tilteDeedLocDetailsCreateList);
		for (TitleDeedLocationdtlsType titleDeedLocDetailsType : tilteDeedLocDetailsCreateList) {

//			IBOCE_TITLEDEEDLOCATION titleDeedLocDtls = (IBOCE_TITLEDEEDLOCATION) factory.findByPrimaryKey(
//					IBOCE_TITLEDEEDLOCATION.BONAME,
//					titleDeedDtlsType.getTitleDeedNumber() + titleDeedLocDetailsType.getSerial(), true);
//			if (titleDeedLocDtls == null) {
//				createTitleDeedLocDetails(titleDeedLocDetailsType, titleDeedDtlsType);
//			}
			
			createTitleDeedLocDetails(titleDeedLocDetailsType, titleDeedDtlsType);
		}

		ParentTitleDeeddtlsType parentTitleDeedDetailsCreateList[] = listParentTitleDeedDtlsType
				.getParentTitleDeedDtls();
		validateParentTitleDeedDetailsInfo(titleDeedDtlsType, parentTitleDeedDetailsCreateList);
		for (ParentTitleDeeddtlsType parentTitleDeedDtlsType : parentTitleDeedDetailsCreateList) {

			IBOCE_PARENTTITLEDEEDDTLS parentTitleDeedDtls = (IBOCE_PARENTTITLEDEEDDTLS) factory.findByPrimaryKey(
					IBOCE_PARENTTITLEDEEDDTLS.BONAME,
					titleDeedDtlsType.getTitleDeedNumber() + parentTitleDeedDtlsType.getTitleDeedNumber(), true);
			if (parentTitleDeedDtls == null) {
				createParentTitleDeedDetails(parentTitleDeedDtlsType, titleDeedDtlsType);
			}
		}
		IBOCE_FARMLANDDTLS farmLandDtls = (IBOCE_FARMLANDDTLS) factory.findByPrimaryKey(IBOCE_FARMLANDDTLS.BONAME,
				titleDeedDtlsType.getTitleDeedIdpk(), true);
		if (farmLandDtls == null) {
			createFarmLandDetails(farmLandTitleDeedDtlsType, titleDeedDtlsType);
		}
		FarmLandLocationdtlsType farmLandLocDetailsCreateList[] = listFarmLandLocationDtlsType
				.getFarmLandLocationDtls();
		for (FarmLandLocationdtlsType farmLandLocDtlsType : farmLandLocDetailsCreateList) {
			String farmLandLocidpk = GUIDGen.getNewGUID();
			IBOCE_FARMLANDLOCDTLS farmLandLocDtls = (IBOCE_FARMLANDLOCDTLS) factory
					.findByPrimaryKey(IBOCE_FARMLANDLOCDTLS.BONAME, farmLandLocidpk, true);
			if (farmLandLocDtls == null) {
				createFarmLandLoDetails(farmLandLocDtlsType, farmLandTitleDeedDtlsType, farmLandLocidpk,titleDeedDtlsType);
			}
		}

		SplitTitleDeeddtlsType splitDetailsCreateList[] = listSplitTitleDeedDtlsType.getSplitTitleDeedDtls();
		validateSplitDetailsInfo(splitDetailsCreateList, titleDeedDtlsType);
		for (SplitTitleDeeddtlsType splitDtlsType : splitDetailsCreateList) {
			String splitIdpk = GUIDGen.getNewGUID();
			IBOCE_TITLEDEEDSPLITDTLS splitTitleDtls = (IBOCE_TITLEDEEDSPLITDTLS) factory
					.findByPrimaryKey(IBOCE_TITLEDEEDSPLITDTLS.BONAME, splitIdpk, true);
			if (splitTitleDtls == null) {
				createSplitTitleDetails(splitDtlsType, splitIdpk, titleDeedDtlsType);
			}
		}

		FarmLandNeighbourdtlsType farmLandNeighbourDetailsCreateList[] = listFarmLandNeighbourDtlsType
				.getFarmLandNeighbourDtls();
		validateFarmLandDetailsDetailsInfo(titleDeedDtlsType, farmLandTitleDeedDtlsType, farmLandLocDetailsCreateList,
				farmLandNeighbourDetailsCreateList);
		for (FarmLandNeighbourdtlsType farmLandNeighbourDtlsType : farmLandNeighbourDetailsCreateList) {
			IBOCE_FARMLANDNEIGHBOURDTLS frmLandNeighbourDtls = (IBOCE_FARMLANDNEIGHBOURDTLS) factory.findByPrimaryKey(
					IBOCE_FARMLANDNEIGHBOURDTLS.BONAME,
					titleDeedDtlsType.getTitleDeedIdpk() + farmLandNeighbourDtlsType.getPartyId(), true);
			if (frmLandNeighbourDtls == null) {
				createFarmLandNeighbourDetails(farmLandNeighbourDtlsType, titleDeedDtlsType);
			}
		}
	}

	private void createTitleDeedDetails(TitleDeedDetailsType titleDeedDetails) {
		IBOCE_TITLEDEEDDETAILS titleDeedDtls = (IBOCE_TITLEDEEDDETAILS) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDDETAILS.BONAME);

		titleDeedDtls.setF_AREASIZE(titleDeedDetails.getAreaSize());
		titleDeedDtls.setF_DICISSIONSTATUS(titleDeedDetails.getDicissionStatus());
		titleDeedDtls.setF_BRANCHSORTCODE(titleDeedDetails.getBranchShortCode());
		titleDeedDtls.setF_FARMLOCATION(titleDeedDetails.getFarmLocation());
		titleDeedDtls.setF_LANDPLANNUMBER(titleDeedDetails.getLandPlanNumber());
		titleDeedDtls.setF_LANDPLOTNUMBER(titleDeedDetails.getLandPlotNumber());
		titleDeedDtls.setF_LINKEDTOCOLLATERAL(titleDeedDetails.getLinkedToCollateral());
		titleDeedDtls.setF_NOTES(titleDeedDetails.getNotes());
		titleDeedDtls.setF_REASONFORCHANGE(titleDeedDetails.getReasonForChange());
		titleDeedDtls.setF_RETAILINDEX(titleDeedDetails.getRetailIndex());
		titleDeedDtls.setF_SPLITINDICATOR(titleDeedDetails.getSplitIndicator());
		titleDeedDtls.setF_STATUS("ACTIVE");
		titleDeedDtls.setF_TITLEDEEDNUMBER(titleDeedDetails.getTitleDeedNumber());
		titleDeedDtls.setF_TITLEDEEDSOURCE(titleDeedDetails.getTitleDeedSource());
		titleDeedDtls.setF_TITLEDEEDSTATUS(titleDeedDetails.getTitleDeedStatus());
		titleDeedDtls.setF_TITLEDEEDTYPE(titleDeedDetails.getTitleDeedType());
		CE_TITLEDEEDDETAILSID titledeeddetailsid = new CE_TITLEDEEDDETAILSID();
		titledeeddetailsid.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titledeeddetailsid.setF_TITLEDEEDVERSION(1);
		titleDeedDtls.setCompositeBOID(titledeeddetailsid);
		// titleDeedDtls.setCompositeBOID(1);
		titleDeedDtls.setF_TITLEDEEDYEAR(titleDeedDetails.getTitleDeedYear());
		titleDeedDtls.setF_VALIDFROM(titleDeedDetails.getValidFrom());
		titleDeedDtls.setF_VALIDFROMHIJRI(titleDeedDetails.getValidFromHijri());
		titleDeedDtls.setF_VALIDTO(titleDeedDetails.getValidTo());
		titleDeedDtls.setF_VALIDTOHIJRI(titleDeedDetails.getValidToHijri());
		factory.create(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedDtls);
	}

	private void createShareHolderDetails(ShareHolderDtlsType shareHolderDetailsType,
			TitleDeedDetailsType titleDeedDtlsType) {
		IBOCE_TITLEDEEDSHAREHOLDER shareHolderDtls = (IBOCE_TITLEDEEDSHAREHOLDER) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDSHAREHOLDER.BONAME);
		shareHolderDtls.setBoID(GUIDGen.getNewGUID());
		shareHolderDtls.setF_TITLEDEEDID(titleDeedDtlsType.getTitleDeedIdpk());
		shareHolderDtls.setF_PARTYID(shareHolderDetailsType.getPartId());
		shareHolderDtls.setF_SHAREPARTYNAME(shareHolderDetailsType.getPartyName());
		shareHolderDtls.setF_SHAREPERCENTAGE(shareHolderDetailsType.getSharePercentage());
		shareHolderDtls.setF_OWNERSHIPTYPE(shareHolderDetailsType.getOwnershipType());
		shareHolderDtls.setF_OWNERSHIPSTATUS(shareHolderDetailsType.getOwnershipStatus());
		shareHolderDtls.setF_NOTES(shareHolderDetailsType.getNotes());
		factory.create(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, shareHolderDtls);
	}

	private void createTitleDeedLocDetails(TitleDeedLocationdtlsType titleDeedLocDtlsType,
			TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_TITLEDEEDLOCATION titleDeedLocDtls = (IBOCE_TITLEDEEDLOCATION) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDLOCATION.BONAME);
//		titleDeedLocDtls.setBoID(titleDeeddtlsType.getTitleDeedNumber() + titleDeedLocDtlsType.getSerial());
		String titleDeedLocationIDPK = GUIDGen.getNewGUID();
		titleDeedLocDtls.setBoID(titleDeedLocationIDPK);
		titleDeedLocDtls.setF_TITLEDEEDID(titleDeeddtlsType.getTitleDeedIdpk());
		titleDeedLocDtls.setF_SERIAL(titleDeedLocDtlsType.getSerial());
		;
		titleDeedLocDtls.setF_LOCNORTHDEGREE(titleDeedLocDtlsType.getLocationNorthDegree());
		titleDeedLocDtls.setF_LOCNORTHSECTION(titleDeedLocDtlsType.getLocationNorthSection());
		titleDeedLocDtls.setF_LOCEASTDEGREE(titleDeedLocDtlsType.getLocationEastDegree());
		titleDeedLocDtls.setF_LOCEASTSECTION(titleDeedLocDtlsType.getLocationEastSection());
		factory.create(IBOCE_TITLEDEEDLOCATION.BONAME, titleDeedLocDtls);
	}

	private void createParentTitleDeedDetails(ParentTitleDeeddtlsType parentTitleDeedDtlsType,
			TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_PARENTTITLEDEEDDTLS parentTitleDeedDtls = (IBOCE_PARENTTITLEDEEDDTLS) factory
				.getStatelessNewInstance(IBOCE_PARENTTITLEDEEDDTLS.BONAME);
		parentTitleDeedDtls
				.setBoID(titleDeeddtlsType.getTitleDeedNumber() + parentTitleDeedDtlsType.getTitleDeedNumber());
		parentTitleDeedDtls.setF_TITLEDEEDID(titleDeeddtlsType.getTitleDeedIdpk());
		parentTitleDeedDtls.setF_TITLEDEEDNUMBER(parentTitleDeedDtlsType.getTitleDeedNumber());
		parentTitleDeedDtls.setF_TITLEDEEDPLANNUMBER(parentTitleDeedDtlsType.getTitleDeedPlanNo());
		parentTitleDeedDtls.setF_TITLEDEEDPLOTNUMBER(parentTitleDeedDtlsType.getTitleDeedPlotNo());
		parentTitleDeedDtls.setF_TITLEDEEDSOURCE(parentTitleDeedDtlsType.getTitleDeedSource());
		parentTitleDeedDtls.setF_TITLEDEEDTYPE(parentTitleDeedDtlsType.getTitleDeedType());
		parentTitleDeedDtls.setF_TITLEDEEDYEAR(parentTitleDeedDtlsType.getTitleDeedYear());
		factory.create(IBOCE_PARENTTITLEDEEDDTLS.BONAME, parentTitleDeedDtls);
	}

	private void createFarmLandDetails(FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType,
			TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_FARMLANDDTLS farmLandDtls = (IBOCE_FARMLANDDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDDTLS.BONAME);
		farmLandDtls.setBoID(titleDeeddtlsType.getTitleDeedIdpk());
		farmLandDtls.setF_CONTRACTDATE(farmLandTitleDeedDtlsType.getContractDate());
		farmLandDtls.setF_CONTRACTNUMBER(farmLandTitleDeedDtlsType.getContractNumber());
		farmLandDtls.setF_CONTRACTSRC(farmLandTitleDeedDtlsType.getContractSource());
		farmLandDtls.setF_ENGOFFDATE(farmLandTitleDeedDtlsType.getEngineerOfficeDate());
		farmLandDtls.setF_ENGOFFNAME(farmLandTitleDeedDtlsType.getEngineerOfficeName());
		farmLandDtls.setF_FARMNAME(farmLandTitleDeedDtlsType.getFarmName());
		farmLandDtls.setF_IRGSRC(farmLandTitleDeedDtlsType.getIrrigationSource());
		farmLandDtls.setF_OWNERNAME(farmLandTitleDeedDtlsType.getOwnerName());
		factory.create(IBOCE_FARMLANDDTLS.BONAME, farmLandDtls);
	}

	private void createFarmLandLoDetails(FarmLandLocationdtlsType farmLandLocationDtlsType,
			FarmLandTitleDeeddtlsType farmLandDtlsType, String farmLandLocId,TitleDeedDetailsType titleDeeddtlsType) {
		IBOCE_FARMLANDLOCDTLS farmLandLocDtls = (IBOCE_FARMLANDLOCDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDLOCDTLS.BONAME);
		farmLandLocDtls.setBoID(farmLandLocId);
		farmLandLocDtls.setF_TITLEDEEDID(titleDeeddtlsType.getTitleDeedIdpk());
		farmLandLocDtls.setF_CONTRACTNUM(farmLandDtlsType.getContractNumber());
		farmLandLocDtls.setF_DIRECTION(farmLandLocationDtlsType.getDirection());
		farmLandLocDtls.setF_BORDER(farmLandLocationDtlsType.getBordering());
		farmLandLocDtls.setF_LENGTH(farmLandLocationDtlsType.getLength());
		factory.create(IBOCE_FARMLANDLOCDTLS.BONAME, farmLandLocDtls);
	}

	private void createSplitTitleDetails(SplitTitleDeeddtlsType splittitleDtlsType, String splitId,
			TitleDeedDetailsType titleDeedDtls) {
		IBOCE_TITLEDEEDSPLITDTLS splitTitleDeedDtls = (IBOCE_TITLEDEEDSPLITDTLS) factory
				.getStatelessNewInstance(IBOCE_TITLEDEEDSPLITDTLS.BONAME);
		splitTitleDeedDtls.setBoID(splitId);
		splitTitleDeedDtls.setF_PERCENTAGE(splittitleDtlsType.getSplitPercentage());
		splitTitleDeedDtls.setF_TITLEDEEDID(titleDeedDtls.getTitleDeedIdpk());
		splitTitleDeedDtls.setF_TITLEDEEDNUMBER(splittitleDtlsType.getTitleDeedNumber());
		splitTitleDeedDtls.setF_TITLEDEEDPLANNUMBER(splittitleDtlsType.getTitleDeedPlanNo());
		splitTitleDeedDtls.setF_TITLEDEEDPLOTNUMBER(splittitleDtlsType.getTitleDeedPlotNo());
		splitTitleDeedDtls.setF_TITLEDEEDSOURCE(splittitleDtlsType.getTitleDeedSource());
		splitTitleDeedDtls.setF_TITLEDEEDTYPE(splittitleDtlsType.getTitleDeedType());
		splitTitleDeedDtls.setF_TITLEDEEDYEAR(splittitleDtlsType.getTitleDeedYear());
		factory.create(IBOCE_TITLEDEEDSPLITDTLS.BONAME, splitTitleDeedDtls);
	}

	private void createFarmLandNeighbourDetails(FarmLandNeighbourdtlsType farmLandNeighbourDtl,
			TitleDeedDetailsType titleDeedDtls) {
		IBOCE_FARMLANDNEIGHBOURDTLS farmLandNeighbourDtls = (IBOCE_FARMLANDNEIGHBOURDTLS) factory
				.getStatelessNewInstance(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME);
		farmLandNeighbourDtls.setBoID(titleDeedDtls.getTitleDeedIdpk() + farmLandNeighbourDtl.getPartyId());
		farmLandNeighbourDtls.setF_PARTYID(farmLandNeighbourDtl.getPartyId());
		farmLandNeighbourDtls.setF_PARTYNAME(farmLandNeighbourDtl.getPartyName());
		farmLandNeighbourDtls.setF_TITLEDEEDID(titleDeedDtls.getTitleDeedIdpk());
		factory.create(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME, farmLandNeighbourDtls);
	}

	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}

	private void validateShareHolderInfo(ShareHolderDtlsType[] shareHolderDetailsCreateList) {
		ArrayList<String> ownershipStatusList = new ArrayList<String>();
		ArrayList<String> partyIdList = new ArrayList<String>();
		int count = 0;
		for (ShareHolderDtlsType shareHolderDtlsType : shareHolderDetailsCreateList) {
			String ownershipType = shareHolderDtlsType.getOwnershipType();
			percentage = percentage.add(shareHolderDtlsType.getSharePercentage());
			String ownershipStatus = shareHolderDtlsType.getOwnershipStatus();
			if ((ownershipType.equals("OWNER")) && (ownershipStatus.equals("CURRENT"))) {
				count++;
			}
			if (count > 1) {
				raiseEvent(OWNERSHIP_STATUS_CURRENT_FOR_OWNER, env);
			}

			if ((ownershipType.equals("PARTNERSHIP")) && (shareHolderDetailsCreateList.length <= 1)) {
				raiseEvent(MORETHAN_ONE_ROW_FOR_PARTNERSHIP, env);
			}

			ownershipStatusList.add(ownershipStatus);
			String partyId = shareHolderDtlsType.getPartId();

			/*if (partyIdList.contains(partyId)) {
				raiseEvent(SHAREHOLDER_PARTYID_CANNOT_BE_DUPLICATE, env);
			}
			partyIdList.add(partyId);*/
		}
		if ((percentage.compareTo(AMOUNT_HUNDRED) == 1)) {
			raiseEvent(PERCENTAGE_SHOULDBE_HUNDRED, env);
		}

		if (!ownershipStatusList.contains("CURRENT")) {
			raiseEvent(OWNERSHIP_STATUS_ONE_CURRENT, env);
		}

	}

	private void validateSplitDetailsInfo(SplitTitleDeeddtlsType[] splitTitleDtlsTypeList,
			TitleDeedDetailsType titleDeedDtlsType) {

		ArrayList<String> titleDeedNumberList = new ArrayList<String>();
		if (titleDeedDtlsType.getSplitIndicator().equals("YES")) {
			if (splitTitleDtlsTypeList.length == 0) {
				raiseEvent(SPLIT_DETAILS_REQUIRED, env);
			}

		}
		if (splitTitleDtlsTypeList.length > 0) {
			for (SplitTitleDeeddtlsType splitDetilsType : splitTitleDtlsTypeList) {

				String titleDeedNumber = splitDetilsType.getTitleDeedNumber();
				if (titleDeedNumberList.contains(titleDeedNumber)) {
					raiseEvent(SPLIT_TITLEDEED_NUMBER_CANNOT_BE_DUPLICATE, env);
				}
				titleDeedNumberList.add(titleDeedNumber);

				splitPercentage = splitPercentage.add(splitDetilsType.getSplitPercentage());

			}
			if ((splitPercentage.compareTo(AMOUNT_HUNDRED) == 1) || (splitPercentage.compareTo(AMOUNT_HUNDRED) == -1)) {
				raiseEvent(SPLI_PERC_HUNDRED, env);
			}
		}

	}

	private void validateTitleDeedLocDetails(TitleDeedLocationdtlsType[] titleDeedLocDetailsList) {
		// ArrayList<TitleDeedLocationdtlsValObj> titleDeedLocList = new
		// ArrayList<TitleDeedLocationdtlsValObj>();
		// ArrayList<TitleDeedLocationdtlsValObj> transformedObjectList = new
		// ArrayList<TitleDeedLocationdtlsValObj>();
		if (!isDuplicteTitleDeedLocDtls(titleDeedLocDetailsList)) {
			raiseEvent(LOCDTLS_SHOULD_BE_UNIQUE, env);
		}
		/*
		 * for (TitleDeedLocationdtlsValObj OldTitleDeedLocDtl : transformedObjectList)
		 * {
		 * 
		 * if(titleDeedLocList.contains(OldTitleDeedLocDtl)) {
		 * raiseEvent(LOCDTLS_SHOULD_BE_UNIQUE, env); }
		 * titleDeedLocList.add(OldTitleDeedLocDtl);
		 * 
		 * }
		 */

	}

	private boolean isDuplicteTitleDeedLocDtls(TitleDeedLocationdtlsType[] titleDeedLocDetailsList) {
		ArrayList<TitleDeedLocationdtlsValObj> transformedObjectList = new ArrayList<TitleDeedLocationdtlsValObj>();

		HashSet filterDuplicates = new HashSet();

		for (TitleDeedLocationdtlsType titleDeedLocType : titleDeedLocDetailsList) {
			String appendedValue = "";
			TitleDeedLocationdtlsValObj transformedObject = new TitleDeedLocationdtlsValObj();
			transformedObject.set_locationEastDegree(titleDeedLocType.getLocationEastDegree());
			transformedObject.set_locationNorthDegree(titleDeedLocType.getLocationNorthDegree());
			transformedObject.set_locationNorthSection(titleDeedLocType.getLocationNorthSection());
			transformedObject.set_locationEastSection(titleDeedLocType.getLocationEastSection());
			transformedObjectList.add(transformedObject);
			appendedValue = String.valueOf(titleDeedLocType.getLocationEastDegree())
					+ String.valueOf(titleDeedLocType.getLocationNorthDegree())
					+ String.valueOf(titleDeedLocType.getLocationNorthSection())
					+ String.valueOf(titleDeedLocType.getLocationEastSection());
			filterDuplicates.add(appendedValue);
		}
		if (filterDuplicates.size() < transformedObjectList.size()) {
			return false;
		}
		return true;
	}

	private void validateTitleDeedDetailsInfo(TitleDeedDetailsType titleDeedDtlsType) {
		ArrayList titleDeedParam = new ArrayList();
		String titleDeedYear = String.valueOf(titleDeedDtlsType.getTitleDeedYear());
		String fromDate = titleDeedDtlsType.getValidFromHijri();
		String DateArr[] = null  ;
		if(!fromDate.isEmpty())
		{
		DateArr = fromDate.split("-");
		}
		if (!(DateArr == (null)) && !titleDeedYear.equals(DateArr[2])) {
	    	raiseEvent(TITLEDDEYEAR_FROMDATE_SHOULD_BE_SAME, env);
	    }
	    
		BigDecimal areaSize = titleDeedDtlsType.getAreaSize();
		if(areaSize.compareTo(BigDecimal.ZERO) == 0 || areaSize.compareTo(BigDecimal.ZERO)<1)
		{
			raiseEvent(AREA_SIZE_ZERO, env);
		}
		
		String titleDeedType = titleDeedDtlsType.getTitleDeedType();
		if (titleDeedType.equals("11")) {
			if (titleDeedDtlsType.getValidToHijri() == null || titleDeedDtlsType.getValidToHijri().isEmpty()) {
				raiseEvent(TO_DATE_SHOULD_BE_MANDATORY, env);
			}

		}

		if (titleDeedType.equals("1") || titleDeedType.equals("2")) {
			if (titleDeedDtlsType.getSplitIndicator().equals("YES")) {
				raiseEvent(SPLIT_INDICATOR_CANNOT_BE_USED, env);
			}

		}

		titleDeedParam.add(titleDeedDtlsType.getTitleDeedNumber());
		titleDeedParam.add(titleDeedDtlsType.getTitleDeedYear());
		titleDeedParam.add(titleDeedDtlsType.getTitleDeedSource());
		titleDeedParam.add(titleDeedDtlsType.getTitleDeedType());
		titleDeedParam.add(titleDeedDtlsType.getLandPlanNumber());
		titleDeedParam.add(titleDeedDtlsType.getLandPlotNumber());
		List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);

		if (titleDeedList.size()>0) {
			raiseEvent(TITLEDEED_COMBINATION_UNIQUE, env);
		}

	}

	private void validateParentTitleDeedDetailsInfo(TitleDeedDetailsType titleDeedDtlsType,
			ParentTitleDeeddtlsType[] parentTitleDeedDtlsList) {

		String titleDeedType = titleDeedDtlsType.getTitleDeedType();
		String titleDeedSource = titleDeedDtlsType.getTitleDeedSource();
		int titleDeedTypeInt = Integer.valueOf(titleDeedType);
		int titleDeedSourceInt = Integer.valueOf(titleDeedSource);
		if ((titleDeedTypeInt == 5 || titleDeedTypeInt == 11)
				&& (titleDeedSourceInt >= 3 && titleDeedSourceInt <= 1713)) {
			if (parentTitleDeedDtlsList.length == 0) {
				raiseEvent(PARENT_TITLE_DEED_CANT_BE_EMPTY, env);

			} else {

				for (ParentTitleDeeddtlsType parentTitleDeeddtlsType : parentTitleDeedDtlsList) {
					if (parentTitleDeeddtlsType.getTitleDeedType().equals("5")
							|| parentTitleDeeddtlsType.getTitleDeedType().equals("11")
							|| parentTitleDeeddtlsType.getTitleDeedType().equals("16")) {
						raiseEvent(PARENT_TITLE_DEEDTYPE_CANNOTBE_5OR11OR16, env);
					}

				}
			}

		}

		if ((titleDeedSource.equals("9000")) && (!titleDeedType.equals("21") && !titleDeedType.equals("22"))) {

			raiseEvent(OUTSIDEKSA_TITLEDEEDTYPE_MUST_BE_21OR22, env);
		}

	}

	private void validateFarmLandDetailsDetailsInfo(TitleDeedDetailsType titleDeedDtlsType,
			FarmLandTitleDeeddtlsType farmLandTitleDeedDtlsType, FarmLandLocationdtlsType[] farmLandLocDtlsType,
			FarmLandNeighbourdtlsType[] farmLandNeighbourDtlsType) {
		if (!titleDeedDtlsType.getTitleDeedType().equals("18")) {
			String contractNumber = farmLandTitleDeedDtlsType.getContractNumber();
			if ((!contractNumber.isEmpty()) || (farmLandLocDtlsType.length != 0)
					|| (farmLandNeighbourDtlsType.length != 0)) {
				raiseEvent(FARMLAND_DTLS_CANANOT_BE_USED, env);
			}

		}
	}
}
