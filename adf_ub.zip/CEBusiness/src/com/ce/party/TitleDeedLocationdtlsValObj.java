package com.ce.party;

public class TitleDeedLocationdtlsValObj {
	
	
	private java.math.BigDecimal _locationEastSection;

    /**
     * Field _locationEastDegree.
     */
    private java.math.BigDecimal _locationEastDegree;

    /**
     * Field _locationNorthSection.
     */
    private java.math.BigDecimal _locationNorthSection;

    /**
     * Field _locationNorthDegree.
     */
    private java.math.BigDecimal _locationNorthDegree;

	public java.math.BigDecimal get_locationEastSection() {
		return _locationEastSection;
	}

	public void set_locationEastSection(java.math.BigDecimal _locationEastSection) {
		this._locationEastSection = _locationEastSection;
	}

	public java.math.BigDecimal get_locationEastDegree() {
		return _locationEastDegree;
	}

	public void set_locationEastDegree(java.math.BigDecimal _locationEastDegree) {
		this._locationEastDegree = _locationEastDegree;
	}

	public java.math.BigDecimal get_locationNorthSection() {
		return _locationNorthSection;
	}

	public void set_locationNorthSection(java.math.BigDecimal _locationNorthSection) {
		this._locationNorthSection = _locationNorthSection;
	}

	public java.math.BigDecimal get_locationNorthDegree() {
		return _locationNorthDegree;
	}

	public void set_locationNorthDegree(java.math.BigDecimal _locationNorthDegree) {
		this._locationNorthDegree = _locationNorthDegree;
	}
    
    

}
