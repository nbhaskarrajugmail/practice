package com.ce.party;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PTY_DeceasedPartyDtls;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FilterDeceasedParty;

public class CE_FilterDeceasedParty extends AbstractCE_FilterDeceasedParty {
	
	Log logger = LogFactory.getLog(CE_FilterDeceasedParty.class);
	private static final long serialVersionUID = 1L;

	public CE_FilterDeceasedParty(BankFusionEnvironment env){
		super(env);
	}
	
	StringBuilder where_Clause;

	public void process(BankFusionEnvironment env){
		logger.info("Inside process of CE_FilterDeceasedParty");
		ArrayList<Object> params =  prepareQuery();
		List<IBOCE_PTY_DeceasedPartyDtls>	result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_PTY_DeceasedPartyDtls.BONAME, where_Clause.toString(), params, null, true);
		VectorTable queryRes =populateResponse(result);
		setF_OUT_result(queryRes);
	}

	

	private VectorTable populateResponse(List<IBOCE_PTY_DeceasedPartyDtls> result) {
		logger.info("CE_FilterDeceasedParty: Inside populateResponse");
		VectorTable table = new VectorTable();
		try{
			if (result==null)
				return table;
			boolean isFirstRecord = true;
			int count =1;
			HashMap<String,Object> dataMap  = new HashMap<String,Object>();
			for(IBOCE_PTY_DeceasedPartyDtls dataRec:result){
				dataMap.put("ALHAFIZADT", dataRec.getF_ALHAFIZADT());
				dataMap.put("ALHAFIZANO", dataRec.getF_ALHAFIZANO());
				dataMap.put("ALHAFIZASRC", dataRec.getF_ALHAFIZASRC());
				dataMap.put("APPROVED", dataRec.isF_APPROVED());
				dataMap.put("APPROVEDDT", dataRec.getF_APPROVEDDT());
				dataMap.put("APPROVERID", dataRec.getF_APPROVERID());
				dataMap.put("BORROWERNAME", dataRec.getF_BORROWERNAME());
				dataMap.put("BORROWERNATID", dataRec.getF_BORROWERNATID());
				dataMap.put("DAETHDATE", dataRec.getF_DAETHDATE());
				dataMap.put("DLBATCHDT", dataRec.getF_DLBATCHDT());
				dataMap.put("DLBATCHNO", dataRec.getF_DLBATCHNO());
				dataMap.put("boID", dataRec.getBoID());
				dataMap.put("LOANBR", dataRec.getF_LOANBR());
				dataMap.put("LOANPLACE", dataRec.getF_LOANPLACE());
				dataMap.put("OUTSTANDINGAMT", dataRec.getF_OUTSTANDINGAMT());
				dataMap.put("REFENDDT", dataRec.getF_REFENDDT());
				dataMap.put("REFNO", dataRec.getF_REFNO());
				dataMap.put("REFSTARTDT", dataRec.getF_REFSTARTDT());
				dataMap.put("REGDATE", dataRec.getF_REGDATE());
				dataMap.put("REJREASON", dataRec.getF_REJREASON());
				dataMap.put("REMARKS", dataRec.getF_REMARKS());
				dataMap.put("REPCONTACNO", dataRec.getF_REPCONTACNO());
				dataMap.put("REPFULLNAME", dataRec.getF_REPFULLNAME());
				dataMap.put("REPNATID", dataRec.getF_REPNATID());
				dataMap.put("ULDT", dataRec.getF_ULDT());
				dataMap.put("ULSTATUS", dataRec.getF_ULSTATUS());
				dataMap.put("UPUSERID", dataRec.getF_UPUSERID());
				dataMap.put("VERSIONNUM", dataRec.getVersionNum());
				if(isFirstRecord){
					dataMap.put("SELECT", true);
				}else{
					dataMap.put("SELECT",false);
				}
				dataMap.put("SRNO",count);
				count++;
				table.addAll(new VectorTable(dataMap));
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
				return table;
	}

	private ArrayList<Object> prepareQuery() {
		logger.info("Prepare filter query");
		ArrayList<Object> params = new ArrayList<Object>();
		try{
			String loanAccNum = getF_IN_loanAccNumber();
			int nationalID=0;
			int batchNumber=0;
			int loanRef=0;
			if(getF_IN_nationalID()!=null)
			nationalID= getF_IN_nationalID();
			if(getF_IN_loanRef()!=null)
			  loanRef= getF_IN_loanRef();
			if(getF_IN_batchNumber()!=null)
			  batchNumber= getF_IN_batchNumber();
			String branchNum = getF_IN_branchCode();
			boolean isEligibility = isF_IN_eligibility();
			Date startDt = getF_IN_startDate();
			Date endDt = getF_IN_endDate();
			boolean isFirstCondition = true;
			where_Clause = new StringBuilder(" WHERE ");
			if(loanAccNum!=null && !loanAccNum.equals(CommonConstants.EMPTY_STRING) && !loanAccNum.equals("%")){
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.LOANACCTNO).append(" LIKE ? ");
				params.add("%"+loanAccNum+"%");
				isFirstCondition = false;
			}
			if(loanRef!=0){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.REFNO).append(" LIKE ? ");
				params.add("%"+loanRef+"%");
				isFirstCondition = false;
			}if(nationalID!=0){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.BORROWERNATID).append(" LIKE ? ");
				params.add("%"+nationalID+"%");
				isFirstCondition = false;
			}if(batchNumber!=0){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.DLBATCHNO).append(" = ? ");
				params.add(batchNumber);
				isFirstCondition = false;
			}if(branchNum!=null && !branchNum.equals(CommonConstants.EMPTY_STRING)){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.LOANBR).append(" LIKE ? ");
				params.add("%"+branchNum+"%");
				isFirstCondition = false;
			}if(startDt!=null && !startDt.equals(CommonConstants.EMPTY_STRING)){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.REFENDDT).append( " >= ? ");
				params.add(startDt);
				isFirstCondition = false;
			}if(endDt!=null && !endDt.equals(CommonConstants.EMPTY_STRING)){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.REFENDDT).append( " <= ? ");
				params.add(endDt);
				isFirstCondition = false;
			}
			if(isEligibility==true || isEligibility == false){
				if(!isFirstCondition)
					where_Clause.append(" AND ");
				where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.APPROVED).append( " = ? ");
				params.add(isEligibility);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return params;
	}
}
