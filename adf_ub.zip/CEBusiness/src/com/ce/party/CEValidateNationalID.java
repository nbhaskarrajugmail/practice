package com.ce.party;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;

public class CEValidateNationalID {

	private final static Log log = LogFactory.getLog(CEValidateNationalID.class.getName());

	public boolean isValidNationalID(String nationalID) {

		Connection con = null;
		CallableStatement cstmt = null;
		CB_CMN_PrivateSession privateSession = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory privateFactory = privateSession.createSession();

		try {

			
			privateSession.beginTransaction();

			con = privateFactory.getJDBCConnection();
			

			String command = "{call CUSTOMEXTN.VALIDATENATIONALID(?,?)}";
			cstmt = con.prepareCall(command);
			cstmt.registerOutParameter(2, Types.VARCHAR);

			cstmt.setString(1, nationalID);
			cstmt.execute();
			String str = cstmt.getString(2);
			privateSession.commitTransaction();

			if (str.equals("Y")) {
				return true;
			}

		} catch (SQLException se) {
			log.error(se.getMessage());
			privateSession.rollBack();
			return false;
		} finally {
			try {
				cstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			privateSession.closeSession();
		}

		return false;

	}

}
