package com.ce.party;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import bf.com.misys.types.deceased.party.DeceasedRs;
import bf.com.misys.types.deceased.party.DeceasedRsList;
import bf.com.misys.types.deceased.party.StatusDetails;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PTY_DeceasedPartyDtls;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_ReadDeceasedParty;

public class CE_ReadDeceasedParty extends AbstractCE_ReadDeceasedParty {
	
	/**
	 * 
	 */
	Log logger = LogFactory.getLog(CE_ReadDeceasedParty.class);
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("deprecation")
	public CE_ReadDeceasedParty(BankFusionEnvironment env){
		super(env);
	}
	
	StringBuilder where_Clause;

	@SuppressWarnings({ "unchecked", "null" })
	public void process(BankFusionEnvironment env){
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.process method Starts");
		}
		ArrayList<Object> params =  prepareQuery();
		StatusDetails param	= new StatusDetails();
		param.setStatus("Success");
		param.setReason(CommonConstants.EMPTY_STRING);
		List<IBOCE_PTY_DeceasedPartyDtls> result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_PTY_DeceasedPartyDtls.BONAME, where_Clause.toString(), params, null, true);
		DeceasedRsList queryRes =populateResponse(result);
		setF_OUT_response(queryRes);
		if(null == result ||(null != result && result.size() == 0)){
			param.setStatus("Failure");
			param.setReason("No Record Found");
		}
		setF_OUT_statusDetails(param);
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.process method Ends");
		}
	}

	/**
	 * @param result
	 * @return
	 */
	private DeceasedRsList populateResponse(List<IBOCE_PTY_DeceasedPartyDtls> result) {
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.populateResponse method Starts");
		}
		DeceasedRsList descList = new DeceasedRsList();
		if (result==null)
			return descList;
		for(IBOCE_PTY_DeceasedPartyDtls dataRec:result){
			DeceasedRs vDeceasedRes	= new DeceasedRs();
			vDeceasedRes.setALHAFIZADT(new String(CommonConstants.EMPTY_STRING + dataRec.getF_ALHAFIZADT()));
			vDeceasedRes.setALHAFIZANO(dataRec.getF_ALHAFIZANO());
			vDeceasedRes.setALHAFIZASRC(dataRec.getF_ALHAFIZASRC());
			if(dataRec.isF_APPROVED()) {
				vDeceasedRes.setAPPROVED(CommonConstants.Y);
			} else {
				vDeceasedRes.setAPPROVED(CommonConstants.N);
			}
			if(null != dataRec.getF_APPROVEDDT()){
				vDeceasedRes.setAPPROVEDDT(dataRec.getF_APPROVEDDT().toString());
			} else {
				vDeceasedRes.setAPPROVEDDT(CommonConstants.EMPTY_STRING);
			}
			vDeceasedRes.setAPPROVERID(dataRec.getF_APPROVERID());
			vDeceasedRes.setBORROWERNAME(dataRec.getF_BORROWERNAME());
			vDeceasedRes.setBORROWERNATID(new String(CommonConstants.EMPTY_STRING + dataRec.getF_BORROWERNATID()));
			if(null != dataRec.getF_DAETHDATE()){
				vDeceasedRes.setDAETHDATE(dataRec.getF_DAETHDATE().toString());
			} else {
				vDeceasedRes.setDAETHDATE(CommonConstants.EMPTY_STRING);
			}
			if(null != dataRec.getF_DLBATCHDT()){
				vDeceasedRes.setDLBATCHDT(dataRec.getF_DLBATCHDT().toString());
			} else {
				vDeceasedRes.setDLBATCHDT(CommonConstants.EMPTY_STRING);
			}
			vDeceasedRes.setDLBATCHNO(new String(CommonConstants.EMPTY_STRING + dataRec.getF_DLBATCHNO()));
			vDeceasedRes.setBoID(dataRec.getBoID());
			vDeceasedRes.setLOANBR(dataRec.getF_LOANBR());
			vDeceasedRes.setLOANPLACE(dataRec.getF_LOANPLACE());
			if(null != dataRec.getF_OUTSTANDINGAMT()){
				vDeceasedRes.setOUTSTANDINGAMT(dataRec.getF_OUTSTANDINGAMT().toString());
			} else {
				vDeceasedRes.setOUTSTANDINGAMT(CommonConstants.EMPTY_STRING);
			}
			if(null!= dataRec.getF_REFENDDT()){
				vDeceasedRes.setREFENDDT(dataRec.getF_REFENDDT().toString());
			} else {
				vDeceasedRes.setREFENDDT(CommonConstants.EMPTY_STRING);
			}
			vDeceasedRes.setREFNO(new String(CommonConstants.EMPTY_STRING + dataRec.getF_REFNO()));
			if(null != dataRec.getF_REFSTARTDT()){
				vDeceasedRes.setREFSTARTDT(dataRec.getF_REFSTARTDT().toString());
			} else {
				vDeceasedRes.setREFSTARTDT(CommonConstants.EMPTY_STRING);
			}
			if(null != dataRec.getF_REGDATE()){
				vDeceasedRes.setREGDATE(dataRec.getF_REGDATE().toString());
			} else {
				vDeceasedRes.setREGDATE(CommonConstants.EMPTY_STRING);
			}
			vDeceasedRes.setREJREASON(dataRec.getF_REJREASON());
			vDeceasedRes.setREMARKS(dataRec.getF_REMARKS());
			vDeceasedRes.setREPCONTACNO(dataRec.getF_REPCONTACNO());
			vDeceasedRes.setREPFULLNAME(dataRec.getF_REPFULLNAME());
			vDeceasedRes.setREPNATID(new String (CommonConstants.EMPTY_STRING + dataRec.getF_REPNATID()));
			if(null != dataRec.getF_ULDT()){
				vDeceasedRes.setULDT(dataRec.getF_ULDT().toString());
			} else {
				vDeceasedRes.setULDT(CommonConstants.EMPTY_STRING);
			}
			vDeceasedRes.setULSTATUS(dataRec.getF_ULSTATUS());
			vDeceasedRes.setUPUSERID(dataRec.getF_UPUSERID());
			descList.addDeceasedRes(vDeceasedRes);
		}
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.populateResponse method Ends");
		}
		return descList;
	}

	/**
	 * @return
	 */
	private ArrayList<Object> prepareQuery() {
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.prepareQuery method Starts");
		}
		Long nationalID	= new Long(0);
		if(null != getF_IN_request() && null != getF_IN_request().getNationalID()) {
			 nationalID	= Long.parseLong(getF_IN_request().getNationalID());
		}
		ArrayList<Object> params = new ArrayList<Object>();
		where_Clause = new StringBuilder(" WHERE ");
		if(nationalID != 0) {
			where_Clause.append(IBOCE_PTY_DeceasedPartyDtls.BORROWERNATID).append(" = ?");
			params.add(nationalID);
		}
		if(logger.isInfoEnabled()){
			logger.info("CE_ReadDeceasedParty.prepareQuery method Ends");
		}
		return params;
	}
	
	
	
}
