package com.ce.party;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.DeceasedPartyUpload;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.refresh.util.FileUtility;
import com.misys.ub.systeminformation.IBusinessInformationService;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_DeceassedprtyUpload;

public class CE_PTY_DeceassedprtyUpload extends AbstractCE_PTY_DeceassedprtyUpload {
	/**
	 * This Class will read all files from the source location and Upload the data into Table with specified format.
	 * once data is uploaded from file then the source file will be renamed and moved into out location.   
	 */
	private static final long serialVersionUID = 1L;
	Log logger = LogFactory.getLog(CE_PTY_DeceassedprtyUpload.class);

	public CE_PTY_DeceassedprtyUpload(BankFusionEnvironment env){
		super(env);
	}
	/**
	 * This method will initiate the Upload process
	 */
	public void process(BankFusionEnvironment env){
		logger.info("Deceassed Party Upload Start");
		IBusinessInformationService busInfo =  (IBusinessInformationService) ServiceManagerFactory.getInstance().getServiceManager().getServiceForName("BusinessInformationService");
		
		String fileInLocation = (String) busInfo.getBizInfo().getModuleConfigurationValue("PARTY",
				"Deceased_Upload_IN", BankFusionThreadLocal.getBankFusionEnvironment());
		
		logger.info("File Location:"+fileInLocation);
		
		String fileOutLocation = (String) busInfo.getBizInfo().getModuleConfigurationValue("PARTY",
				"Deceased_Upload_Out", BankFusionThreadLocal.getBankFusionEnvironment());
		logger.info("File Location:"+fileOutLocation);
		
		try{
			File file = new File(fileInLocation);
			File fileout = new File(fileOutLocation);
			if(file.isDirectory()){
				DeceasedPartyUpload partyUpload = new DeceasedPartyUpload();
				 File[] files = file.listFiles();
				 for(File srcFile:files){
					 logger.info("Record processing for File:"+srcFile.getPath());
					 partyUpload.uploadXLData(srcFile.getPath());
					 moveFile(srcFile, fileout);
				 }
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		logger.info("Deceassed Party Upload End");
		
	}
	

	/**
	 * @param srcFile
	 * @param desFile
	 * @param createDesDir
	 */
	public void moveFile(File srcFile, File desDir) {
		boolean createDesDir = true;
		String srcFileName = srcFile.getName();
		srcFileName = srcFileName.substring(0,srcFileName.lastIndexOf("xls"));
		srcFileName = srcFileName+SystemInformationManager.getInstance().getBFBusinessDateTimeAsString();
		try {
			if(srcFile.exists()){
				FileUtils.moveFileToDirectory(srcFile, desDir, createDesDir);
				FileUtils.deleteQuietly(srcFile);
				File destFile = new File(desDir.getAbsolutePath()+"\\"+srcFile.getName());
				destFile.renameTo(new File(desDir.getAbsolutePath()+"\\"+srcFileName+".xlsx"));
			}
		} catch (IOException e1) {
			try {
				FileUtils.copyFileToDirectory(srcFile, desDir);

			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}
	}
}
