package com.ce.party;

import java.io.IOException;
import java.time.LocalDate;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.party.userexit.host.AbstractPersonalDetailsValidator;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyDetailsView;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.msgs.party.v12.MessageStatus;
import bf.com.misys.msgs.party.v12.PartyBasicDtls;
import bf.com.misys.msgs.party.v12.PartyPersonalUserExitRq;
import bf.com.misys.msgs.party.v12.PartyPersonalUserExitRs;
import bf.com.misys.msgs.party.v12.RqHeader;
import bf.com.misys.msgs.party.v12.RsHeader;

@SuppressWarnings("deprecation")
public class CE_PTY_PersonalPartyValidator extends AbstractPersonalDetailsValidator {

	String partyID = null;
	String partyCategory = null;
	// String PartyCategory = null;
	String nationalId = null;
	Date DOB = null;
	private final int NATIONALID_DOB_CANNOT_BE_EMPTY = 44000003;
	private final int NATIONALID_DOB_NOT_VALID = 44000004;
	private final int NAMES_ARE_NOT_VALID = 44000006;
	private final int NOT_VALID_FOR = 40580112;
	public static final String MAINTAIN_PARTY_MFID = "PT_PAM_MaintainParty_PRC";
	private static final String getpartyDetailsWhrClause = " WHERE  " + IBOPT_PFN_PartyDetailsView.PARTYID + " =? ";
	private final static Log log = LogFactory.getLog(CE_PTY_PersonalPartyValidator.class.getName());

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public PartyPersonalUserExitRs validatePersonalParty(PartyPersonalUserExitRq payLoad) {
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();

		PartyPersonalUserExitRs personalPartyRs = new PartyPersonalUserExitRs();

		partyID = payLoad.getPartyPersonalUserExit().getPartyBasicDtls().getPartyId();
		partyCategory = payLoad.getPartyPersonalUserExit().getPartyBasicDtls().getPartyCategory();
		nationalId = payLoad.getPartyPersonalUserExit().getPartyTaxDtl().getGstRegistration().getIdReference();
		DOB = payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getDateOfBirth();
		String fristName = payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl()
				.getFirstName();
		String middleName = payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl()
				.getMiddleNames();
		String lastName = payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl()
				.getLastName();
		String name = fristName + " " + middleName + " " + lastName;

		ArrayList<String> params = new ArrayList<String>();
		params.add(partyID);
		IBOPT_PFN_PartyDetailsView PartyDetails = (IBOPT_PFN_PartyDetailsView) BankFusionThreadLocal
				.getPersistanceFactory()
				.findFirstByQuery(IBOPT_PFN_PartyDetailsView.BONAME, getpartyDetailsWhrClause, params, true);

		if (MAINTAIN_PARTY_MFID.equalsIgnoreCase(BankFusionThreadLocal.getMFId())) {
			if ((nationalId == null || nationalId.isEmpty()) || (DOB == null)) {
				raiseEvent(NATIONALID_DOB_CANNOT_BE_EMPTY, env);
			} else {
				CEValidateNationalID validate = new CEValidateNationalID();
				if (!validate.isValidNationalID(nationalId)) {
					EventsHelper.handleEvent(NOT_VALID_FOR, new Object[] { "National ID" }, new HashMap(), env);
				}
				if ((partyCategory.equalsIgnoreCase("FULL"))) {
					if ((!PartyDetails.getF_NATIONALID().equalsIgnoreCase(nationalId))
							|| (!PartyDetails.getF_DATEOFBIRTH().equals(DOB))
							|| (!PartyDetails.getF_NAME().equalsIgnoreCase(name))) {
						try {
							HijrahDate hijraDate = GregorianToHijriConversion(DOB);
							FFCConnectionPersonal(payLoad, env, nationalId, hijraDate);
						} catch (SAXException e) {
							e.printStackTrace();
						} catch (IOException e) {
							e.printStackTrace();
						} catch (ParserConfigurationException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}

		RsHeader response = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setOverallStatus("S");
		response.setStatus(status);
		personalPartyRs.setPartyHeaderRs(response);
		return personalPartyRs;
	}

	@SuppressWarnings("static-access")
	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}

	private void FFCConnectionPersonal(PartyPersonalUserExitRq payLoad, BankFusionEnvironment env, String nationalId,
			HijrahDate dob) throws SAXException, IOException, ParserConfigurationException {

		ALMCheckService almCheckService = new ALMCheckService();
		String response = almCheckService.callAMLService(nationalId, "", dob.toString());
		if (response == null || response.equals("")) {
			log.info(" [CE_PTY_PersonalPartyValidator] [response] is empty for " + nationalId);
			raiseEvent(NATIONALID_DOB_NOT_VALID, env);
		}
		String firstName = getParameter(response, "firstName");
		String middleName = getParameter(response, "middleName");
		String lastName = getParameter(response, "lastName");

		if ((firstName == null || firstName.isEmpty()) || (middleName == null || middleName.isEmpty())
				|| (lastName == null || lastName.isEmpty())) {
			log.info(" [CE_PTY_PersonalPartyValidator] [nationalId] [firstName] [middleName] [lastName] ["
					+ nationalId + "] [" + firstName + "] [" + middleName + "] [" + lastName + "]");
			raiseEvent(NATIONALID_DOB_NOT_VALID, env);
		}

		if (!(payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl().getFirstName()
				.equalsIgnoreCase(firstName))
				|| !(payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl()
						.getMiddleNames().equalsIgnoreCase(middleName))
				|| !(payLoad.getPartyPersonalUserExit().getPartyPersonDtl().getNameDtls()[0].getNameDtl().getLastName()
						.equalsIgnoreCase(lastName))) {

			raiseEvent(NAMES_ARE_NOT_VALID, env);
		}
	}

	private HijrahDate GregorianToHijriConversion(Date dateOfBirth) {
		Calendar cal = new GregorianCalendar();
		cal.setTime(dateOfBirth);
		HijrahDate hijriDate = HijrahChronology.INSTANCE
				.date(LocalDate.of(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE)));
		DateTimeFormatter dateFormater = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		hijriDate.format(dateFormater);
		System.out.println(hijriDate);
		return hijriDate;
	}

	protected RsHeader validateUniqueAlternateId(PartyBasicDtls payLoad, RqHeader rqHeader) {
		RsHeader response = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setOverallStatus("S");
		response.setStatus(status);
		return response;
	}

	private String getParameter(String response, String parameter) {
		String value = "";
		int startPossition = response.indexOf("<" + parameter + ">") + parameter.length() + 2;
		int endPossition = response.indexOf("</" + parameter + ">");
		log.info(startPossition + " " + endPossition);
		if (startPossition == -1 || endPossition == -1)
			return value;
		value = response.substring(startPossition, endPossition);
		return value;
	}

}