package com.ce.party;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.FarmLandLocationdtlsType;
import com.misys.ce.types.FarmLandNeighbourdtlsType;
import com.misys.ce.types.FarmLandTitleDeeddtlsType;
import com.misys.ce.types.ListFarmLandLocationDtlsType;
import com.misys.ce.types.ListFarmLandNeighbourDtlsType;
import com.misys.ce.types.ListParentTitleDeedDtlsType;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListSplitTitleDeedDtlsType;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.ParentTitleDeeddtlsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.SplitTitleDeeddtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDLOCDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FARMLANDNEIGHBOURDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_PARENTTITLEDEEDDTLS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSPLITDTLS;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FetchTitleDeedDtls;

public class CE_FetchTitleDeedDtls extends AbstractCE_FetchTitleDeedDtls{
	
	/**
	 * This class is to fetch Title Deed Details
	 */
	private static final long serialVersionUID = 1L;
	Log logger = LogFactory.getLog(CE_FetchTitleDeedDtls.class);
	
	public CE_FetchTitleDeedDtls(BankFusionEnvironment env){
		super(env);
	}
	
	public void process(BankFusionEnvironment env){
		logger.info("Fetching of Title Deed Details Process Start....");
		//String titleID = getF_IN_titleID();
		
		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
		listTitleDeedIdDtlsType = getF_IN_titleDeedDtlsList();
		
		TitleDeedDetailsType titleDeedDetailsList[] = listTitleDeedIdDtlsType.getTitleDeedDetails();
		//System.out.println();
		boolean isRecordSelected = false;
		for (TitleDeedDetailsType titleDeedDtlsType:titleDeedDetailsList)
		{
			if((titleDeedDtlsType.getSelect().equals(true))&& !(titleDeedDtlsType.getTitleDeedNumber().isEmpty() || (titleDeedDtlsType.getTitleDeedNumber().equals(null)) )) {
				isRecordSelected = true;
				String titleDeedWhere = " WHERE "+IBOCE_TITLEDEEDLOCATION.TITLEDEEDID+" = ? ";
				ArrayList<String> params = new ArrayList<String>();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				
				//int index =1;
				//boolean select = true;
				List<IBOCE_TITLEDEEDLOCATION> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDLOCATION.BONAME, titleDeedWhere, params, null, true);
				if(titleDeedList!=null && (!titleDeedList.isEmpty())){
					populateTitleDeedLocationDetails(titleDeedList,titleDeedDtlsType.getTitleDeedNumber());
				}
				else {
					setF_OUT_TitleDeedLocDtlstypeList(new ListTitleDeedLocDtlsType());
				}
				
				titleDeedWhere = " WHERE "+IBOCE_PARENTTITLEDEEDDTLS.TITLEDEEDID +" = ?";
				params.clear();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				List<IBOCE_PARENTTITLEDEEDDTLS> parentTitleDeed = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_PARENTTITLEDEEDDTLS.BONAME, titleDeedWhere, params, null, true);
				if(parentTitleDeed!=null && (!parentTitleDeed.isEmpty())){
					populateParentTitleDeedDtls(parentTitleDeed,titleDeedDtlsType.getTitleDeedNumber());
				}
				else {
					setF_OUT_ParentTitleDeedDtlsList(new ListParentTitleDeedDtlsType());
				}
				/**
				 * Title Deed share holder details population
				 */
				//index =1;
				titleDeedWhere = " WHERE "+IBOCE_TITLEDEEDSHAREHOLDER.TITLEDEEDID +" = ?";
				params.clear();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				List<IBOCE_TITLEDEEDSHAREHOLDER> titleShareHolder = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDSHAREHOLDER.BONAME, titleDeedWhere, params, null, true);
				if(titleShareHolder!=null && (!titleShareHolder.isEmpty())){
					populateShareHolder(titleShareHolder,titleDeedDtlsType.getTitleDeedNumber());
				}
				else {
					setF_OUT_ShareHolderDtlsList(new ListShareHolderDtlsType());
				}
				
				/**
				 * Title Deed Split details population
				 */
				titleDeedWhere = " WHERE "+IBOCE_TITLEDEEDSPLITDTLS.TITLEDEEDID + " = ?";
				params.clear();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				List<IBOCE_TITLEDEEDSPLITDTLS> titleSplitDetails = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDSPLITDTLS.BONAME, titleDeedWhere, params, null, true);
				if(titleSplitDetails!=null && (!titleSplitDetails.isEmpty())){
					populateSplitDetails(titleSplitDetails);
				}
				else {
					setF_OUT_splitDetailsTypeList(new ListSplitTitleDeedDtlsType());
				}
				/**
				 * Farm Land Neighbour details population
				 */
				titleDeedWhere = " WHERE "+IBOCE_FARMLANDNEIGHBOURDTLS.TITLEDEEDID + " = ?";
				params.clear();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				List<IBOCE_FARMLANDNEIGHBOURDTLS> farmLandNeighbourDtl = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_FARMLANDNEIGHBOURDTLS.BONAME, titleDeedWhere, params, null, true);
				if(farmLandNeighbourDtl!=null && (!farmLandNeighbourDtl.isEmpty())){
					populateNeighbourDtl(farmLandNeighbourDtl);
				}
				else {
					setF_OUT_farmLandNeighbourDtlsTypeList(new ListFarmLandNeighbourDtlsType());
				}
				/**
				 * Farm Land details population
				 */
				titleDeedWhere = " WHERE "+IBOCE_FARMLANDDTLS.TITLEDEEDID + " = ?";
				params.clear();
				params.add(titleDeedDtlsType.getTitleDeedIdpk());
				List<IBOCE_FARMLANDDTLS> farmLandDtl = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_FARMLANDDTLS.BONAME, titleDeedWhere, params, null, true);
				if(farmLandDtl!=null && (!farmLandDtl.isEmpty())){
					populateFarmLandDtl(farmLandDtl);
					/**
					 * Farm Land location details population
					 */
					String farmLandLocWhere = " WHERE "+IBOCE_FARMLANDLOCDTLS.TITLEDEEDID + " = ?";
					for (IBOCE_FARMLANDDTLS farmLandTitleDeedDetailsType:farmLandDtl) {
						
						params.clear();
						params.add(farmLandTitleDeedDetailsType.getBoID());
						List<IBOCE_FARMLANDLOCDTLS> farmLandLocDtl = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_FARMLANDLOCDTLS.BONAME, farmLandLocWhere, params, null, true);
						if(farmLandLocDtl!=null && (!farmLandLocDtl.isEmpty())){
							populateFarmLandLocDtl(farmLandLocDtl);
						}
						else {
              setF_OUT_farmLandLocationDtlsTypeList(new ListFarmLandLocationDtlsType());
						}
					}
					
				}else {
            setF_OUT_farmLandLocationDtlsTypeList(new ListFarmLandLocationDtlsType());
            setF_OUT_farmLandDtlsType(new FarmLandTitleDeeddtlsType());
				}
				
				
				
				
				logger.info("Fetch Details of Title Deed Details End....");
			}
			/*else {
				setF_OUT_TitleDeedLocDtlstypeList(new ListTitleDeedLocDtlsType());
				setF_OUT_ShareHolderDtlsList(new ListShareHolderDtlsType());
				setF_OUT_ParentTitleDeedDtlsList(new ListParentTitleDeedDtlsType());
				//setF_OUT_farmLandDtlsType(new farmlan);
				setF_OUT_farmLandLocationDtlsTypeList(new ListFarmLandLocationDtlsType());
				setF_OUT_farmLandNeighbourDtlsTypeList(new ListFarmLandNeighbourDtlsType());
				setF_OUT_splitDetailsTypeList(new ListSplitTitleDeedDtlsType());
			}*/
			}
		
		if (!isRecordSelected) {
			setF_OUT_TitleDeedLocDtlstypeList(new ListTitleDeedLocDtlsType());
			setF_OUT_ShareHolderDtlsList(new ListShareHolderDtlsType());
			setF_OUT_ParentTitleDeedDtlsList(new ListParentTitleDeedDtlsType());
			//setF_OUT_farmLandDtlsType(new farmlan);
			setF_OUT_farmLandLocationDtlsTypeList(new ListFarmLandLocationDtlsType());
			setF_OUT_farmLandNeighbourDtlsTypeList(new ListFarmLandNeighbourDtlsType());
			setF_OUT_splitDetailsTypeList(new ListSplitTitleDeedDtlsType());
		}
		}
		
		/**
		 * Title Deed Location details population
		 */
		
		//else {
			//setF_OUT_TitleDeedLocDtlstypeList(null);
		//}
		/**
		 * Parent Title Deed details population
		 */
		//index =1;
		

	/**
	 * 
	 * @param titleShareHolder
	 * @param select
	 * @param index
	 */
	private void populateShareHolder(List<IBOCE_TITLEDEEDSHAREHOLDER> titleShareHolder, String titleDeedNumber) {
		Map<String,String> ownershipTypeMap = PartyUtil.getGCMap("OWNERSHIPTYPE");
		Map<String,String> ownershipStatusMap = PartyUtil.getGCMap("OWNERSHIPSTATUS");

		boolean select = true;
		logger.info("Populate Share Holder Details start...");
		ListShareHolderDtlsType titleShare = new ListShareHolderDtlsType();
		for(IBOCE_TITLEDEEDSHAREHOLDER ptitle:titleShareHolder){
				ShareHolderDtlsType shareHolderDtl = new ShareHolderDtlsType();
				shareHolderDtl.setShareHolderIdpk(ptitle.getBoID());
				shareHolderDtl.setNotes(ptitle.getF_NOTES());
				shareHolderDtl.setOwnershipStatus((ownershipStatusMap.get(ptitle.getF_OWNERSHIPSTATUS())));
				shareHolderDtl.setOwnershipType((ownershipTypeMap.get(ptitle.getF_OWNERSHIPTYPE())));
				shareHolderDtl.setPartId(ptitle.getF_PARTYID());
				shareHolderDtl.setPartyName(ptitle.getF_SHAREPARTYNAME());
				shareHolderDtl.setSharePercentage(ptitle.getF_SHAREPERCENTAGE());
				if(getF_IN_viewMode().equalsIgnoreCase("VIEW"))
				{
					shareHolderDtl.setOwnershipStatus((ptitle.getF_OWNERSHIPSTATUS()));
					shareHolderDtl.setOwnershipType((ptitle.getF_OWNERSHIPTYPE()));
				}

				shareHolderDtl.setSelect(select);
				select = false;
				// shareHolderDtl.setSerialNumber(index+"");

				titleShare.addShareHolderDetails(shareHolderDtl);
			
		}
		setF_OUT_ShareHolderDtlsList(titleShare);
		logger.info("Populate of Share Holder details end....");
	}

	/**
	 * 
	 * @param parentTitleDeed
	 * @param select
	 * @param index
	 */
	 
	private void populateParentTitleDeedDtls(List<IBOCE_PARENTTITLEDEEDDTLS> parentTitleDeed, String titleDeedNumber) {
		Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");

		boolean select = true;
		logger.info("Populate of Parent Title Deed Details start....");
		ListParentTitleDeedDtlsType parentTitle = new ListParentTitleDeedDtlsType();
		for(IBOCE_PARENTTITLEDEEDDTLS ptitle:parentTitleDeed){
			if (ptitle.getBoID().equals(titleDeedNumber + ptitle.getF_TITLEDEEDNUMBER())) {
				ParentTitleDeeddtlsType pTitleDeed = new ParentTitleDeeddtlsType();
				pTitleDeed.setParentTitleDeedIdpk(ptitle.getBoID());
				pTitleDeed.setTitleDeedNumber(ptitle.getF_TITLEDEEDNUMBER());
				pTitleDeed.setTitleDeedPlanNo(ptitle.getF_TITLEDEEDPLANNUMBER());
				pTitleDeed.setTitleDeedPlotNo(ptitle.getF_TITLEDEEDPLOTNUMBER());
				pTitleDeed.setTitleDeedSource((titleDeedSourceMap.get(ptitle.getF_TITLEDEEDSOURCE())));
				pTitleDeed.setTitleDeedType((titleDeedTypeMap.get(ptitle.getF_TITLEDEEDTYPE())));
				pTitleDeed.setTitleDeedYear(ptitle.getF_TITLEDEEDYEAR());
				if(getF_IN_viewMode().equalsIgnoreCase("VIEW"))
				{
					pTitleDeed.setTitleDeedSource((ptitle.getF_TITLEDEEDSOURCE()));
					pTitleDeed.setTitleDeedType((ptitle.getF_TITLEDEEDTYPE()));
				}
				pTitleDeed.setSelect(select);
				select = false;
				// pTitleDeed.setSerialNumber(index+"");

				parentTitle.addParentTitleDeedDtls(pTitleDeed);
			}
		}
		setF_OUT_ParentTitleDeedDtlsList(parentTitle);
		logger.info("Populate of Parent Title Deed Details End....");
	}

	/**
	 * This method populate Title Deed Location details into Grid 
	 * @param titleDeedList
	 * @param titleDeedNumber() 
	 * @param select
	 * @param index
	 */
	private void populateTitleDeedLocationDetails(List<IBOCE_TITLEDEEDLOCATION> titleDeedList, String titleDeedNumber) {
		boolean select = true;
		logger.info("Populate Title Deed Location Detail start..");
		ListTitleDeedLocDtlsType titleDeedLt = new ListTitleDeedLocDtlsType();
		
		for(IBOCE_TITLEDEEDLOCATION tdeedDtl:titleDeedList){
//			if (tdeedDtl.getBoID().equals(titleDeedNumber + tdeedDtl.getF_SERIAL())) {
				TitleDeedLocationdtlsType tDeed = new TitleDeedLocationdtlsType();
				tDeed.setTitleDeedLocIdpk(tdeedDtl.getBoID());
				tDeed.setLocationEastDegree(tdeedDtl.getF_LOCEASTDEGREE());
				tDeed.setLocationEastSection(tdeedDtl.getF_LOCEASTSECTION());
				tDeed.setLocationNorthDegree(tdeedDtl.getF_LOCNORTHDEGREE());
				tDeed.setLocationNorthSection(tdeedDtl.getF_LOCNORTHSECTION());
				tDeed.setSerial(tdeedDtl.getF_SERIAL());
				tDeed.setSelect(select);
				select = false;
				titleDeedLt.addTitleDeedLocDtls(tDeed);

				// index++;
//			}
		}
		setF_OUT_TitleDeedLocDtlstypeList(titleDeedLt);
		logger.info("Populate Title Deed Location Detail end..");
		
	}
	
	private void populateSplitDetails(List<IBOCE_TITLEDEEDSPLITDTLS> titleDeedSplit) {
		Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");

		boolean select = true;
		logger.info("Populate Title Deed split Detail start..");
		ListSplitTitleDeedDtlsType titleDeedSplitDetails = new ListSplitTitleDeedDtlsType();
		for(IBOCE_TITLEDEEDSPLITDTLS tdeedSplitDtl:titleDeedSplit){
			SplitTitleDeeddtlsType tDeed = new SplitTitleDeeddtlsType();
			tDeed.setSplitTitleDeedIdpk(tdeedSplitDtl.getBoID());
			tDeed.setSplitPercentage(tdeedSplitDtl.getF_PERCENTAGE());
			tDeed.setTitleDeedNumber(tdeedSplitDtl.getF_TITLEDEEDNUMBER());
			tDeed.setTitleDeedPlanNo(tdeedSplitDtl.getF_TITLEDEEDPLANNUMBER());
			tDeed.setTitleDeedPlotNo(tdeedSplitDtl.getF_TITLEDEEDPLOTNUMBER());
			tDeed.setTitleDeedSource((titleDeedSourceMap.get(tdeedSplitDtl.getF_TITLEDEEDSOURCE())));
			tDeed.setTitleDeedType((titleDeedTypeMap.get(tdeedSplitDtl.getF_TITLEDEEDTYPE())));
			tDeed.setTitleDeedYear(tdeedSplitDtl.getF_TITLEDEEDYEAR());
			if(getF_IN_viewMode().equalsIgnoreCase("VIEW"))
			{
				tDeed.setTitleDeedSource((tdeedSplitDtl.getF_TITLEDEEDSOURCE()));
				tDeed.setTitleDeedType((tdeedSplitDtl.getF_TITLEDEEDTYPE()));
			}
			tDeed.setSelect(select);
			select= false;
			titleDeedSplitDetails.addSplitTitleDeedDtls(tDeed);
		
			//index++;
		}
		setF_OUT_splitDetailsTypeList(titleDeedSplitDetails);
		logger.info("Populate Title Deed Split Detail end..");
		
	}
	
	private void populateNeighbourDtl(List<IBOCE_FARMLANDNEIGHBOURDTLS> farmLandNeighbour) {
		boolean select = true;
		logger.info("Populate Title Deed farm land neighbour Detail start..");
		ListFarmLandNeighbourDtlsType farmLandNeighbourDetailsList = new ListFarmLandNeighbourDtlsType();
		
		for(IBOCE_FARMLANDNEIGHBOURDTLS farmLandNeighbourDtl:farmLandNeighbour){
			FarmLandNeighbourdtlsType tDeed = new FarmLandNeighbourdtlsType();
			tDeed.setFarmLandNeighbouridpk(farmLandNeighbourDtl.getBoID());
			tDeed.setPartyId(farmLandNeighbourDtl.getF_PARTYID());
			tDeed.setPartyName(farmLandNeighbourDtl.getF_PARTYNAME());
			tDeed.setSelect(select);
			select= false;
			farmLandNeighbourDetailsList.addFarmLandNeighbourDtls(tDeed);
		
			//index++;
		}
		setF_OUT_farmLandNeighbourDtlsTypeList(farmLandNeighbourDetailsList);
		logger.info("Populate Title Deed FarmLand Neighbour Detail end..");
		
	}
	
	private void populateFarmLandDtl(List<IBOCE_FARMLANDDTLS> farmLandDetail) {
		Map<String,String> contractSourceMap = PartyUtil.getGCMap("CONTRACTSOURCE");
		Map<String,String> irrigationSourceMap = PartyUtil.getGCMap("IRRIGATIONSOURCE");

		//boolean select = true;
		logger.info("Populate farm Land Detail start..");
		//ListFarmLandNeighbourDtlsType farmLandNeighbourDetailsList = new ListFarmLandNeighbourDtlsType();
		
		for(IBOCE_FARMLANDDTLS farmLandDtl:farmLandDetail){
			FarmLandTitleDeeddtlsType tDeed = new FarmLandTitleDeeddtlsType();
			tDeed.setTitleDeedIdpk(farmLandDtl.getBoID());
			tDeed.setContractDate(farmLandDtl.getF_CONTRACTDATE());
			tDeed.setContractNumber(farmLandDtl.getF_CONTRACTNUMBER());
			tDeed.setContractSource((contractSourceMap.get(farmLandDtl.getF_CONTRACTSRC())));
			tDeed.setEngineerOfficeDate(farmLandDtl.getF_ENGOFFDATE());
			tDeed.setEngineerOfficeName(farmLandDtl.getF_ENGOFFNAME());
			tDeed.setFarmName(farmLandDtl.getF_FARMNAME());
			tDeed.setIrrigationSource((irrigationSourceMap.get(farmLandDtl.getF_IRGSRC())));
			tDeed.setOwnerName(farmLandDtl.getF_OWNERNAME());
			if(getF_IN_viewMode().equalsIgnoreCase("VIEW"))
			{
				tDeed.setContractSource((farmLandDtl.getF_CONTRACTSRC()));
				tDeed.setIrrigationSource((farmLandDtl.getF_IRGSRC()));
			}
			setF_OUT_farmLandDtlsType(tDeed);
			//index++;
		}
		
		logger.info("Populate Title Deed FarmLand Detail end..");
		
	}
	
	private void populateFarmLandLocDtl(List<IBOCE_FARMLANDLOCDTLS> farmLandLocDetails) {
		Map<String,String> farmLandDirectionMap = PartyUtil.getGCMap("FARMLANDDIRECTION");
		
		boolean select = true;
		logger.info("Populate Title Deed farm land location Detail start..");
		ListFarmLandLocationDtlsType farmLandLocationdtlsList = new ListFarmLandLocationDtlsType();
		
		for(IBOCE_FARMLANDLOCDTLS farmLandLoactionDtl:farmLandLocDetails){
			FarmLandLocationdtlsType tDeed = new FarmLandLocationdtlsType();
			tDeed.setFarmLandLocationidpk(farmLandLoactionDtl.getBoID());
			tDeed.setBordering(farmLandLoactionDtl.getF_BORDER());
			tDeed.setDirection((farmLandDirectionMap.get(farmLandLoactionDtl.getF_DIRECTION())));
			tDeed.setLength(farmLandLoactionDtl.getF_LENGTH());
			if(getF_IN_viewMode().equalsIgnoreCase("VIEW"))
			{
				tDeed.setDirection((farmLandLoactionDtl.getF_DIRECTION()));
			}
			tDeed.setSelect(select);
			select= false;
			farmLandLocationdtlsList.addFarmLandLocationDtls(tDeed);
		
			//index++;
		}
		setF_OUT_farmLandLocationDtlsTypeList(farmLandLocationdtlsList);
		logger.info("Populate Title Deed FarmLand location Detail end..");
		
	}
	
	

}
