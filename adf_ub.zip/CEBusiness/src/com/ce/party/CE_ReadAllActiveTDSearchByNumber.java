package com.ce.party;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.PagingData;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_ReadAllActiveTDSearchByNumber;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

@SuppressWarnings("serial")
public class CE_ReadAllActiveTDSearchByNumber extends AbstractCE_PTY_ReadAllActiveTDSearchByNumber {

    private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? ORDER BY "
        + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " ASC";
    private final String titleDeedWhere_TitleDeedNumber = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? AND "
        + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " LIKE ? ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER
        + " ASC";
    private final String titleDeedWhere_TitleDeedNumberLike = " WHERE " + IBOCE_TITLEDEEDDETAILS.STATUS + " = ? AND "
        + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER + " LIKE ? ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDNUMBER
        + " ASC";
	private static final Integer PAGE_SIZE = 10;
  private static final Integer PAGE_NO = 1;
  private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
  private Map<String, String> titleDeedSourceMap = null;
  private Map<String, String> titleDeedTypeMap = null;

 
	public CE_ReadAllActiveTDSearchByNumber() {
		super();
	}

	@SuppressWarnings("deprecation")
	public CE_ReadAllActiveTDSearchByNumber(BankFusionEnvironment env) {

	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	    if (titleDeedSourceMap == null) {
	        titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
	    }
	      if (titleDeedTypeMap == null) {
	        titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");
	      }
	   int pageSize = PAGE_SIZE;
	    int pageNo = getF_IN_searchTitleDeedDtlsByNumberRq().getPagedQuery().getPagingRequest().getRequestedPage();
	    IPagingData pagingData = null;

	    if (pageSize == 0)
	      pageSize = PAGE_SIZE;
	    if (pageNo == 0)
	      pageNo = PAGE_NO;

	      pagingData = new PagingData(pageNo, pageSize);
	      pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
	      this.fetchAllActiveTitleDeedDtls(pagingData, env);
	}

    private VectorTable fetchAllActiveTitleDeedDtls(IPagingData pagingData, BankFusionEnvironment env) {

    List<IBOCE_TITLEDEEDDETAILS> titleDeedList = null;

    String titleDeedNumber =  getF_IN_searchTitleDeedDtlsByNumberRq().getTitleDeedNumber().getTitleDeedNumber();
    // when title deed number is available
    if (titleDeedNumber != null && !titleDeedNumber.isEmpty()) {
      ArrayList<String> titleDeedParam = new ArrayList<String>();
      titleDeedParam.add("ACTIVE");
      titleDeedParam.add("%"+titleDeedNumber+"%");
      if (titleDeedNumber.contains("%")) {
        titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
            titleDeedWhere_TitleDeedNumberLike, titleDeedParam, pagingData, false);
      } else {
        titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
            titleDeedWhere_TitleDeedNumber, titleDeedParam, pagingData, false);
      }
    } else {
      // All "ACTIVE" record
      ArrayList<String> titleDeedParam = new ArrayList<String>();
      titleDeedParam.add("ACTIVE");
      titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_TITLEDEEDDETAILS.BONAME,
          titleDeedWhere, titleDeedParam, pagingData, false);

    }
        return this.createResponse(titleDeedList, pagingData, null);
        
    }

    private VectorTable createResponse(List<IBOCE_TITLEDEEDDETAILS> titleDeedList, IPagingData pagingData, Object object) {
        VectorTable vectorTable = new VectorTable();

        ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();
        SearchTitleDeedDtlsRsType searchTitleDeedRs = new SearchTitleDeedDtlsRsType();

        boolean select = false;

        if (titleDeedList != null) {
          for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
            this.prepareListTitleDeedIdDtlsType(listTitleDeedIdDtlsType, titleDeedType, select);
            select = false;
            Map<String, Object> map = this.prepareMap(titleDeedType);
            VectorTable newRow = new VectorTable(map);
            vectorTable.addAll(newRow);
          }
        } 

        PagedQuery pagedQuery = new PagedQuery();
        PagingRequest pagingRequest = new PagingRequest();
        pagingRequest.setNumberOfRows(pagingData.getPageSize());
        pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
        pagingRequest.setTotalPages(pagingData.getTotalPages());
        pagedQuery.setPagingRequest(pagingRequest);
        pagedQuery.setQueryData(listTitleDeedIdDtlsType);

        Object pageData[] = new Object[4];
        pageData[0] = pagingRequest.getRequestedPage();
        pageData[1] = pagingRequest.getNumberOfRows();
        pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
        vectorTable.setPagingData(pageData);

        searchTitleDeedRs.setListTitleDeedIdDtls(listTitleDeedIdDtlsType);
        searchTitleDeedRs.setPagingInfo(pagedQuery);
        setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
        setF_OUT_PaginatedData(vectorTable);
        return vectorTable;
    }

    private Map<String, Object> prepareMap(IBOCE_TITLEDEEDDETAILS titleDeedType) {

        Map<String, Object> map = new HashMap<>();
        CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
        map.put("versionNumber", titledeeddetailsid.getF_TITLEDEEDVERSION());
        map.put("SELECT", Boolean.FALSE);
        map.put("TITLEDEEDIDPK", titledeeddetailsid.getF_TITLEDEEDID());
        map.put("TITLEDEEDVERSIONPK", titledeeddetailsid.getF_TITLEDEEDVERSION());
        map.put("TITLEDEEDSTATUS", titleDeedType.getF_TITLEDEEDSTATUS());
        map.put("TRANSACTIONTYPE", titleDeedType.getF_TRANSACTIONTYPE());
        map.put("RECCREATEDBY", titleDeedType.getF_RECCREATEDBY());
        map.put("VALIDTO", titleDeedType.getF_VALIDTO());
        map.put("VERSIONNUM", titleDeedType.getVersionNum());
        map.put("NOTES", titleDeedType.getF_NOTES());
        map.put("VALIDTOHIJRI", titleDeedType.getF_VALIDTOHIJRI());
        map.put("NOTESFORAMEND", titleDeedType.getF_NOTESFORAMEND());
        map.put("LINKEDTOCOLLATERAL", titleDeedType.getF_LINKEDTOCOLLATERAL());
        map.put("STATUS", titleDeedType.getF_STATUS());
        map.put("RECLASTMODIFIEDBY", titleDeedType.getF_RECLASTMODIFIEDBY());
        map.put("TITLEDEEDYEAR", titleDeedType.getF_TITLEDEEDYEAR());
        map.put("TITLEDEEDNUMBER", titleDeedType.getF_TITLEDEEDNUMBER());
        map.put("RETAILINDEX", titleDeedType.getF_RETAILINDEX());
        map.put("VALIDFROMHIJRI", titleDeedType.getF_VALIDFROMHIJRI());
        map.put("REASONFORCHANGE", titleDeedType.getF_REASONFORCHANGE());
        map.put("LANDPLOTNUMBER", titleDeedType.getF_LANDPLOTNUMBER());
        map.put("RECSYSDATE", titleDeedType.getF_RECSYSDATE());
        map.put("DICISSIONSTATUS", titleDeedType.getF_DICISSIONSTATUS());
        map.put("RECAPPROVEDBY", titleDeedType.getF_RECAPPROVEDBY());
        map.put("RECCREATEDON", titleDeedType.getF_RECCREATEDON());
        map.put("TRANSACTIONDATE", titleDeedType.getF_TRANSACTIONDATE());
        map.put("VALIDFROM", titleDeedType.getF_VALIDFROM());
        map.put("RECLASTMODIFIEDDATE", titleDeedType.getF_RECLASTMODIFIEDDATE());
        map.put("FARMLOCATION", titleDeedType.getF_FARMLOCATION());
        map.put("BRANCHSORTCODE", titleDeedType.getF_BRANCHSORTCODE());
        map.put("RECAPPROVEDDATE", titleDeedType.getF_RECAPPROVEDDATE());
        map.put("SPLITINDICATOR", titleDeedType.getF_SPLITINDICATOR());
        map.put("LANDPLANNUMBER", titleDeedType.getF_LANDPLANNUMBER());
        map.put("TITLEDEEDSOURCE", titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
        map.put("AREASIZE", titleDeedType.getF_AREASIZE());
        map.put("TITLEDEEDTYPE", titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
        map.put("CompositeBoid", titleDeedType.getCompositeBOID());
        return map;
      }

    private void prepareListTitleDeedIdDtlsType(ListTitleDeedIdDtlsType listTitleDeedIdDtlsType, IBOCE_TITLEDEEDDETAILS titleDeedType,
        boolean select) {
        TitleDeedDetailsType titleDeedDetailsType = new TitleDeedDetailsType();
        titleDeedDetailsType.setAreaSize(titleDeedType.getF_AREASIZE());
        CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
        titleDeedDetailsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
        titleDeedDetailsType.setDicissionStatus(titleDeedType.getF_DICISSIONSTATUS());
        titleDeedDetailsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
        titleDeedDetailsType.setFarmLocation(titleDeedType.getF_FARMLOCATION());
        titleDeedDetailsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
        titleDeedDetailsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
        titleDeedDetailsType.setLinkedToCollateral(titleDeedType.getF_LINKEDTOCOLLATERAL());
        titleDeedDetailsType.setNotes(titleDeedType.getF_NOTES());
        titleDeedDetailsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
        titleDeedDetailsType.setRetailIndex(titleDeedType.getF_RETAILINDEX());
        titleDeedDetailsType.setSelect(select);
        titleDeedDetailsType.setSplitIndicator(titleDeedType.getF_SPLITINDICATOR());
        titleDeedDetailsType.setStatus(titleDeedType.getF_STATUS());
        titleDeedDetailsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
        titleDeedDetailsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
        titleDeedDetailsType.setTitleDeedStatus(titleDeedType.getF_TITLEDEEDSTATUS());
        titleDeedDetailsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
        titleDeedDetailsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
        titleDeedDetailsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
        titleDeedDetailsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
        titleDeedDetailsType.setTransactionType(titleDeedType.getF_TRANSACTIONTYPE());
        titleDeedDetailsType.setValidFrom(titleDeedType.getF_VALIDFROM());
        titleDeedDetailsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
        titleDeedDetailsType.setValidTo(titleDeedType.getF_VALIDTO());
        titleDeedDetailsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
        titleDeedDetailsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
        listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDetailsType);
        
    }
    @Override
    public ActivityStepPagingState createActivityStepPagingState() {
      ActivityStepPagingState pagingState = super.createActivityStepPagingState();
      return pagingState;
    }
    @Override
    public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
        @SuppressWarnings("rawtypes") Map map) {

      VectorTable resultVector = new VectorTable();


      int pageSize = PAGE_SIZE;
      int pageNo = PAGE_NO;

      if (map.containsKey("PAGENO")) {
        pageNo = (Integer) map.get("PAGENO");
      }
      if (map.containsKey("NUMBEROFROWS")) {
        pageSize = (Integer) map.get("NUMBEROFROWS");
      }

      IPagingData pagingData = new PagingData(pageNo, pageSize);

      if (pagingData != null) {
        pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
        if (pagingData.getCurrentPageNumber() == 0)
          pagingData.setCurrentPageNumber(pageNo);
        if (pagingData.getPageSize() == 0)
          pagingData.setPageSize(pageSize);

        pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);

        resultVector = this.fetchAllActiveTitleDeedDtls(pagingData, env);
      }
      return resultVector;
    }
    
}
