package com.ce.party;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.SAXException;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.party.userexit.host.AbstractEnterpriseDetailsValidator;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyDetailsView;
import com.trapedza.bankfusion.core.EventsHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import bf.com.misys.cbs.types.events.Event;
import bf.com.misys.msgs.party.v12.MessageStatus;
import bf.com.misys.msgs.party.v12.PartyBasicDtls;
import bf.com.misys.msgs.party.v12.PartyEnterpriseUserExitRq;
import bf.com.misys.msgs.party.v12.PartyEnterpriseUserExitRs;
import bf.com.misys.msgs.party.v12.RqHeader;
import bf.com.misys.msgs.party.v12.RsHeader;

public class CE_PTY_EnterprisePartyValidator extends AbstractEnterpriseDetailsValidator{
	
	String partyID = null;
	String partyCategory = null;
	String registeredId = null;
	private final int REGISTEREDID_CAN_NOT_BE_EMPTY = 44000005;
	private final int REGISTEREDID_NOT_VALID= 44000007;
	private final int ENTERPRISE_NAME_NOT_VALID = 44000008;
	public static final String MAINTAIN_PARTY_MFID = "PT_PAM_MaintainParty_PRC";
	private static final String getpartyDetailsWhrClause = " WHERE  " + IBOPT_PFN_PartyDetailsView.PARTYID + " =? ";
	private static final transient Log LOGGER = LogFactory.getLog(CE_PTY_EnterprisePartyValidator.class);

	private final static Log log = LogFactory.getLog(CE_PTY_EnterprisePartyValidator.class.getName());

	public PartyEnterpriseUserExitRs validateEntParty(PartyEnterpriseUserExitRq payLoad) {
		BankFusionEnvironment env = BankFusionThreadLocal.getBankFusionEnvironment();
		PartyEnterpriseUserExitRs enterprisePartyRs = new PartyEnterpriseUserExitRs();
		partyID = payLoad.getPartyEnterpriseUserExit().getPartyBasicDtls().getPartyId();
		partyCategory = payLoad.getPartyEnterpriseUserExit().getPartyBasicDtls().getPartyCategory();
		registeredId = payLoad.getPartyEnterpriseUserExit().getEntPtyBasicDtls().getRegNumber();
		//registeredId = payLoad1.getUpdateEntPartyDtlsInput().getEntpBasicDtls().getRegNumber();
		ArrayList<String> params = new ArrayList<String>();
		params.add(partyID);
		IBOPT_PFN_PartyDetailsView PartyDetails = (IBOPT_PFN_PartyDetailsView) BankFusionThreadLocal.getPersistanceFactory()
				.findFirstByQuery(IBOPT_PFN_PartyDetailsView.BONAME, getpartyDetailsWhrClause,params,true);
		if(MAINTAIN_PARTY_MFID.equalsIgnoreCase(BankFusionThreadLocal.getMFId())) {

			if ((registeredId == null || registeredId.isEmpty())) {
				raiseEvent(REGISTEREDID_CAN_NOT_BE_EMPTY, env);
			} else {
				if (partyCategory.equalsIgnoreCase("FULL")) {
					
					if(!PartyDetails.getF_REGISTEREDNUMBER().equals(registeredId)) {
					try {
						FFCConnectionEnterprise(payLoad,env,registeredId);
					} catch (SAXException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ParserConfigurationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				}
			}
			}
		
		
		
		RsHeader response = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setOverallStatus("S");
		response.setStatus(status);
		enterprisePartyRs.setPartyHeaderRs(response);

		return enterprisePartyRs;
	}
	
	
	protected RsHeader validateUniqueAlternateId(PartyBasicDtls payLoad, RqHeader rqHeader) {
		RsHeader response = new RsHeader();
		MessageStatus status = new MessageStatus();
		status.setOverallStatus("S");
		response.setStatus(status);
		return response;
	}
	
	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}
	
	private void FFCConnectionEnterprise(PartyEnterpriseUserExitRq payLoad,BankFusionEnvironment env,String regNumber)
			throws ParserConfigurationException, SAXException, IOException {
		ALMCheckService almCheckService = new ALMCheckService();
		String response = almCheckService.callAMLService("", regNumber, "");
		
		String enterPriseName =  getParameter(response, "companyName");
		
		if ((enterPriseName == null || enterPriseName.isEmpty())) {
			raiseEvent(REGISTEREDID_NOT_VALID, env);
		}

		if (!(payLoad.getPartyEnterpriseUserExit().getPartyBasicDtls().getName().equalsIgnoreCase(enterPriseName))) {
			
			raiseEvent(ENTERPRISE_NAME_NOT_VALID, env);

		}
	}
	
	private String getParameter(String response,String parameter) {
        String value = "";
		
		int startPossition = response.indexOf("<"+parameter+">")+parameter.length()+2;
		int endPossition = response.indexOf("</"+parameter+">");
		log.info(startPossition+" " + endPossition);
		if(startPossition==-1 || endPossition == -1)
		return value;
		value = response.substring(startPossition, endPossition);
		
		return value;
	}

}

	
