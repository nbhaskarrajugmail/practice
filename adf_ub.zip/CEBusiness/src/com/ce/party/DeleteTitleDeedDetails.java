package com.ce.party;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_DeleteTitleDeedDetails;

public class DeleteTitleDeedDetails extends AbstractCE_DeleteTitleDeedDetails{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	public DeleteTitleDeedDetails() {
		super();
	}

	public DeleteTitleDeedDetails(BankFusionEnvironment env) {

	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		final Log LOGGER = LogFactory.getLog(DeleteTitleDeedDetails.class.getName());
		
		ListTitleDeedIdDtlsType listTitleDeedDtlsType = new ListTitleDeedIdDtlsType();
		listTitleDeedDtlsType = getF_IN_listTitleDeedDtlsType();
		TitleDeedDetailsType titleDeedDlsTypeList[] = listTitleDeedDtlsType.getTitleDeedDetails();
		for (TitleDeedDetailsType titleDeedDetailsType : titleDeedDlsTypeList) {
			if(titleDeedDetailsType.getSelect().equals(true)) {
				 updateTitleDeedDetails(titleDeedDetailsType);
				 updateTitleDeedDetailsPreviousVersion(titleDeedDetailsType);
			}
			
		}
	 
	}
	private void updateTitleDeedDetails(TitleDeedDetailsType titleDeedDetails) {
		
		CE_TITLEDEEDDETAILSID titleDeedDtlsId = new CE_TITLEDEEDDETAILSID();
		titleDeedDtlsId.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titleDeedDtlsId.setF_TITLEDEEDVERSION(titleDeedDetails.getVersionNumber());

		IBOCE_TITLEDEEDDETAILS titleDeedDtls = (IBOCE_TITLEDEEDDETAILS) factory
				.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedDtlsId , true);
		
		if(titleDeedDtls == null) {
			return;
		}
		titleDeedDtls.setF_STATUS("DELETED");	
	}
	
private void updateTitleDeedDetailsPreviousVersion(TitleDeedDetailsType titleDeedDetails) {
		int versionNumber = titleDeedDetails.getVersionNumber();
		versionNumber = versionNumber-1;
		CE_TITLEDEEDDETAILSID titleDeedDtlsId = new CE_TITLEDEEDDETAILSID();
		titleDeedDtlsId.setF_TITLEDEEDID(titleDeedDetails.getTitleDeedIdpk());
		titleDeedDtlsId.setF_TITLEDEEDVERSION(versionNumber);

		IBOCE_TITLEDEEDDETAILS titleDeedDtls = (IBOCE_TITLEDEEDDETAILS) factory
				.findByPrimaryKey(IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedDtlsId , true);
		
		if(titleDeedDtls == null) {
			return;
		}		
		titleDeedDtls.setF_STATUS("ACTIVE");
	}


}
