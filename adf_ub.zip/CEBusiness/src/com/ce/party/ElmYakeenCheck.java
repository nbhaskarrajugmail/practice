package com.ce.party;

import java.io.IOException;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import bf.com.misys.cbs.types.events.Event;
import com.trapedza.bankfusion.core.EventsHelper;
import com.misys.party.constant.PartyConstant;
import com.misys.pf.common.functions.PartyConstants;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_ElmYakeenChk;

import bf.com.misys.cbs.types.PartyBasicDtls;

public class ElmYakeenCheck extends AbstractCE_PTY_ElmYakeenChk {

	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(PrepareDedupCheck.class);

	private final static Log log = LogFactory.getLog(PrepareDedupCheck.class.getName());

	public ElmYakeenCheck() {
		super();
	}

	public ElmYakeenCheck(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment env) {
		super(env);
	}

	String nationalId = null;
	String dateOfBirth = null;
	String registeredNumber = null;
	PartyBasicDtls partyBasicDetails = new PartyBasicDtls();
	private final int NATIONALID_DOB_CANNOT_BE_EMPTY = 44000003;
	private final int NATIONALID_DOB_NOT_VALID = 44000004;
	private final int REGISTEREDID_CAN_NOT_BE_EMPTY = 44000005;
	private final int REGISTEREDID_NOT_VALID= 44000007;
	private final int NOT_VALID_FOR=40580112;
	private final int E_HIJRI_DATE_FORMAT = 44000425;

	public void process(BankFusionEnvironment env) throws BankFusionException {

		nationalId = getF_IN_nationalId();
		dateOfBirth = getF_IN_dateOfBirth();
		partyBasicDetails = getF_IN_PartyBasicDtls();
		registeredNumber = getF_IN_registeredId();
		String partyCategory = partyBasicDetails.getPartyCategory();
		if (PartyConstants.PARTY_TYPE_PERSONAL.equalsIgnoreCase(partyBasicDetails.getPartyType())) {
			HijrahDate hijraDate = GregorianToHijriConversion(dateOfBirth, env);

			CEValidateNationalID validate = new CEValidateNationalID();
			if (!validate.isValidNationalID(nationalId)) {
				EventsHelper.handleEvent(NOT_VALID_FOR, new Object[] { "National ID" }, new HashMap(), env);
			}

			if (PartyConstants.FULL_PARTYCATEGORY.equalsIgnoreCase(partyCategory)) {
				if ((nationalId == null || nationalId.isEmpty()) || (dateOfBirth == null || dateOfBirth.isEmpty())) {
					raiseEvent(NATIONALID_DOB_CANNOT_BE_EMPTY, env);
				} else {
					try {
						FFCConnectionPersonal(env, nationalId, hijraDate);
					} catch (SAXException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (ParserConfigurationException e) {
						e.printStackTrace();
					}
				}
			}
		}

		else if (PartyConstants.PARTY_TYPE_ENTERPRISE.equalsIgnoreCase(partyBasicDetails.getPartyType())) {

			if (PartyConstants.FULL_PARTYCATEGORY.equalsIgnoreCase(partyCategory)) {
				if ((registeredNumber == null) || (registeredNumber.isEmpty())) {
					raiseEvent(REGISTEREDID_CAN_NOT_BE_EMPTY, env);
				} else {
					try {
						FFCConnectionEnterprise(env, registeredNumber);
					} catch (ParserConfigurationException e) {
						e.printStackTrace();
					} catch (SAXException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	protected void raiseEvent(int eventNumer, BankFusionEnvironment env) {
		Event event = new Event();
		event.setEventNumber(eventNumer);
		EventsHelper eventsHelper = new EventsHelper();
		eventsHelper.handleEvent(event, env);
	}

	private void FFCConnectionPersonal(BankFusionEnvironment env,String nationalId,HijrahDate dob)
			throws SAXException, IOException, ParserConfigurationException {

		ALMCheckService almCheckService = new ALMCheckService();
		String response = almCheckService.callAMLService(nationalId, "", dob.toString());
		if (response == null || response.equals("")) {
			log.info("[response] is empty for " + nationalId);
			raiseEvent(NATIONALID_DOB_NOT_VALID, env);
		}
		String firstName = getParameter(response, "firstName");
		String middleName = getParameter(response, "middleName");
		String lastName = getParameter(response, "lastName");
		String gender = getParameter(response, "gender");
		log.info("Gender::::" + gender);
		if ((firstName == null || firstName.isEmpty()) || (middleName == null || middleName.isEmpty())
				|| (lastName == null || lastName.isEmpty())) {
			log.info("[nationalId] [firstName] [middleName] [lastName] [" + nationalId + "] [" + firstName
					+ "] [" + middleName + "] [" + lastName + "]");
			raiseEvent(NATIONALID_DOB_NOT_VALID, env);
		} else {
			CEValidatePartyName partyName = new CEValidatePartyName();
			firstName = partyName.isValidPartyName(firstName);
			middleName = partyName.isValidPartyName(middleName);
			lastName = partyName.isValidPartyName(lastName);

			setF_OUT_firstName(firstName);
			setF_OUT_MiddleName(middleName);
			setF_OUT_lastName(lastName);
			setF_OUT_gender(gender);
		}
	}

	private void FFCConnectionEnterprise(BankFusionEnvironment env,String regNumber)
			throws ParserConfigurationException, SAXException, IOException {
		ALMCheckService almCheckService = new ALMCheckService();
		String response = almCheckService.callAMLService("", regNumber, "");
		
		String enterPriseName =  getParameter(response, "companyName");
		if(enterPriseName == null || enterPriseName.isEmpty()) {
			raiseEvent(REGISTEREDID_NOT_VALID, env);
		}
		else {
		setF_OUT_enterpriseName(enterPriseName);
		}
	}

	private HijrahDate GregorianToHijriConversion(String dateOfBirth, BankFusionEnvironment env) {
		HijrahDate hijriDate = null;
		String DateArr[] = dateOfBirth.split("-");
		try {
			hijriDate = HijrahChronology.INSTANCE.date(Integer.parseInt(DateArr[2]), Integer.parseInt(DateArr[1]),
					Integer.parseInt(DateArr[0]));
		} catch (Exception dtex) {
			raiseEvent(E_HIJRI_DATE_FORMAT, env);
		}
		DateTimeFormatter customFormatterGregorian = DateTimeFormatter.ofPattern("MM-dd-yyyy");
		String gregorianDateInString = IsoChronology.INSTANCE.date(hijriDate).format(customFormatterGregorian).toString();
		setF_OUT_dateOfBirthInString(gregorianDateInString);

		return hijriDate;
	}
	
	private String getParameter(String response,String parameter) {
		String value = "";
			
		int startPossition = response.indexOf("<"+parameter+">")+parameter.length()+2;
		int endPossition = response.indexOf("</"+parameter+">");
		log.info(startPossition+" " + endPossition);
		if(startPossition==-1 || endPossition == -1)
		return value;
		value = response.substring(startPossition, endPossition);
		
		return value;
	}

}