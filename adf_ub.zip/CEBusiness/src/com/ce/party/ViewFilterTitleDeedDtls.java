package com.ce.party;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.party.util.PartyUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.ListShareHolderDtlsType;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.ListTitleDeedLocDtlsType;
import com.misys.ce.types.SearchTitleDeedDtlsRqType;
import com.misys.ce.types.SearchTitleDeedDtlsRsType;
import com.misys.ce.types.ShareHolderDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.misys.ce.types.TitleDeedLocationdtlsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDLOCATION;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDSHAREHOLDER;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_ViewFilterTitleDeedDtls;

public class ViewFilterTitleDeedDtls extends AbstractCE_ViewFilterTitleDeedDtls {


	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	private final String titleDeedWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK+" = ?" + " ORDER BY " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDVERSIONPK + " DESC";
	private final String titleDeedVersionWhere = " WHERE " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDIDPK+" = ?" + " AND " + IBOCE_TITLEDEEDDETAILS.TITLEDEEDVERSIONPK+" = ? ";
	private final String shareHolderWhere = " WHERE " + IBOCE_TITLEDEEDSHAREHOLDER.TITLEDEEDID+" = ? ";
	private final String titleDeedLocWhere = " WHERE " + IBOCE_TITLEDEEDLOCATION.TITLEDEEDID+" = ? ";
	
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal
			.getPersistanceFactory();

	public ViewFilterTitleDeedDtls() {
		super();
	}
	
	public ViewFilterTitleDeedDtls(BankFusionEnvironment env){
		
	}
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		final Log LOGGER = LogFactory.getLog(ViewFilterTitleDeedDtls.class.getName());
		
		Map<String,String> titleDeedSourceMap = PartyUtil.getGCMap("TITLEDEEDSOURCE");
		Map<String,String> titleDeedTypeMap = PartyUtil.getGCMap("TITLEDEEDTYPE");
		//Map<String,String> farmLocationTypeMap = PartyUtil.getGCMap("0000");
		Map<String,String> titleDeedStatusMap = PartyUtil.getGCMap("TITLEDEEDSTATUS");
		Map<String,String> retailIndexMap = PartyUtil.getGCMap("RETAILINDEX");
		Map<String,String> decissionStatusMap = PartyUtil.getGCMap("DECISSIONSTATUS");
		Map<String,String> collateralLinkMap = PartyUtil.getGCMap("COLLATERALLINK");
		Map<String,String> titleDeedTxnTypeMap = PartyUtil.getGCMap("TITLEDEEDTXNTYPE");
		Map<String,String> tdStatusMap = PartyUtil.getGCMap("TDSTATUS");
		
		ListTitleDeedIdDtlsType listTitleDeedIdDtlsType = new ListTitleDeedIdDtlsType();		
		ArrayList titleDeedParam = new ArrayList();
		ListTitleDeedIdDtlsType listTitleDeedDtlsType = new ListTitleDeedIdDtlsType();
		listTitleDeedDtlsType = getF_IN_listTitleDeedDtlsType();
		String titleDeedId = getF_IN_titleDeedId();
		Integer versionNumber = 0;
		versionNumber = getF_IN_versionNumber();
		if ((titleDeedId==null || titleDeedId.isEmpty())&&(versionNumber==null)) {
		TitleDeedDetailsType titleDeedDtlsList[] = listTitleDeedDtlsType.getTitleDeedDetails();
		boolean isRecordSelected = false;
		
		for (TitleDeedDetailsType titleDeedDetailsType : titleDeedDtlsList) {
			if (titleDeedDetailsType.getSelect().equals(true)) {
				titleDeedParam.clear();
	            titleDeedParam.add(titleDeedDetailsType.getTitleDeedIdpk());
				List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
		                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedWhere, titleDeedParam, null, false);
	            boolean select = true;
				
				for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
					TitleDeedDetailsType titleDeedDtlsType = new TitleDeedDetailsType();
					titleDeedDtlsType.setAreaSize(titleDeedType.getF_AREASIZE());
					CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
					
					titleDeedDtlsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
					titleDeedDtlsType.setDicissionStatus(decissionStatusMap.get(titleDeedType.getF_DICISSIONSTATUS()));
					titleDeedDtlsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
					titleDeedDtlsType.setFarmLocation(PartyUtil.getFarmLocationDesc(titleDeedType.getF_FARMLOCATION(),titleDeedType.getF_BRANCHSORTCODE()));
					titleDeedDtlsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
					titleDeedDtlsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
					titleDeedDtlsType.setLinkedToCollateral(collateralLinkMap.get(titleDeedType.getF_LINKEDTOCOLLATERAL()));
					titleDeedDtlsType.setNotes(titleDeedType.getF_NOTES());
					titleDeedDtlsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
					titleDeedDtlsType.setRetailIndex(retailIndexMap.get(titleDeedType.getF_RETAILINDEX()));
					titleDeedDtlsType.setSelect(select);
					select = false;
					titleDeedDtlsType.setSplitIndicator(collateralLinkMap.get(titleDeedType.getF_SPLITINDICATOR()));
					titleDeedDtlsType.setStatus(tdStatusMap.get(titleDeedType.getF_STATUS()));
					titleDeedDtlsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
					titleDeedDtlsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
					titleDeedDtlsType.setTitleDeedStatus(titleDeedStatusMap.get(titleDeedType.getF_TITLEDEEDSTATUS()));
					titleDeedDtlsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
					titleDeedDtlsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
					titleDeedDtlsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
					titleDeedDtlsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
					titleDeedDtlsType.setTransactionType(titleDeedTxnTypeMap.get(titleDeedType.getF_TRANSACTIONTYPE()));
					titleDeedDtlsType.setValidFrom(titleDeedType.getF_VALIDFROM());
					titleDeedDtlsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
					titleDeedDtlsType.setValidTo(titleDeedType.getF_VALIDTO());
					titleDeedDtlsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
					titleDeedDtlsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
					listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDtlsType);
				}
				
				setF_OUT_listTitleDeedDtlsType(listTitleDeedIdDtlsType);
			}
			}
			
		//fetchTitleDeedDetails(searchTitleDeedDtlsRqType);

}
		else {
			titleDeedParam.clear();
            titleDeedParam.add(titleDeedId);
            titleDeedParam.add(versionNumber);
			List<IBOCE_TITLEDEEDDETAILS> titleDeedList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
	                IBOCE_TITLEDEEDDETAILS.BONAME, titleDeedVersionWhere, titleDeedParam, null, false);
            boolean select = true;
			
			for (IBOCE_TITLEDEEDDETAILS titleDeedType : titleDeedList) {
				TitleDeedDetailsType titleDeedDtlsType = new TitleDeedDetailsType();
				titleDeedDtlsType.setAreaSize(titleDeedType.getF_AREASIZE());
				CE_TITLEDEEDDETAILSID titledeeddetailsid = (CE_TITLEDEEDDETAILSID) titleDeedType.getCompositeBOID();
				
				titleDeedDtlsType.setTitleDeedIdpk(titledeeddetailsid.getF_TITLEDEEDID());
				titleDeedDtlsType.setDicissionStatus(decissionStatusMap.get(titleDeedType.getF_DICISSIONSTATUS()));
				titleDeedDtlsType.setBranchShortCode(titleDeedType.getF_BRANCHSORTCODE());
				titleDeedDtlsType.setFarmLocation(PartyUtil.getFarmLocationDesc(titleDeedType.getF_FARMLOCATION(),titleDeedType.getF_BRANCHSORTCODE()));
				titleDeedDtlsType.setLandPlanNumber(titleDeedType.getF_LANDPLANNUMBER());
				titleDeedDtlsType.setLandPlotNumber(titleDeedType.getF_LANDPLOTNUMBER());
				titleDeedDtlsType.setLinkedToCollateral(collateralLinkMap.get(titleDeedType.getF_LINKEDTOCOLLATERAL()));
				titleDeedDtlsType.setNotes(titleDeedType.getF_NOTES());
				titleDeedDtlsType.setReasonForChange(titleDeedType.getF_REASONFORCHANGE());
				titleDeedDtlsType.setRetailIndex(retailIndexMap.get(titleDeedType.getF_RETAILINDEX()));
				titleDeedDtlsType.setSelect(select);
				select = false;
				titleDeedDtlsType.setSplitIndicator(collateralLinkMap.get(titleDeedType.getF_SPLITINDICATOR()));
				titleDeedDtlsType.setStatus(tdStatusMap.get(titleDeedType.getF_STATUS()));
				titleDeedDtlsType.setTitleDeedNumber(titleDeedType.getF_TITLEDEEDNUMBER());
				titleDeedDtlsType.setTitleDeedSource(titleDeedSourceMap.get(titleDeedType.getF_TITLEDEEDSOURCE()));
				titleDeedDtlsType.setTitleDeedStatus(titleDeedStatusMap.get(titleDeedType.getF_TITLEDEEDSTATUS()));
				titleDeedDtlsType.setTitleDeedType(titleDeedTypeMap.get(titleDeedType.getF_TITLEDEEDTYPE()));
				titleDeedDtlsType.setTitleDeedYear(titleDeedType.getF_TITLEDEEDYEAR());
				titleDeedDtlsType.setTransactionDate(titleDeedType.getF_TRANSACTIONDATE());
				titleDeedDtlsType.setTransactionNotes(titleDeedType.getF_NOTESFORAMEND());
				titleDeedDtlsType.setTransactionType(titleDeedTxnTypeMap.get(titleDeedType.getF_TRANSACTIONTYPE()));
				titleDeedDtlsType.setValidFrom(titleDeedType.getF_VALIDFROM());
				titleDeedDtlsType.setValidFromHijri(titleDeedType.getF_VALIDFROMHIJRI());
				titleDeedDtlsType.setValidTo(titleDeedType.getF_VALIDTO());
				titleDeedDtlsType.setValidToHijri(titleDeedType.getF_VALIDTOHIJRI());
				titleDeedDtlsType.setVersionNumber(titledeeddetailsid.getF_TITLEDEEDVERSION());
				listTitleDeedIdDtlsType.addTitleDeedDetails(titleDeedDtlsType);
			}
			
			setF_OUT_listTitleDeedDtlsType(listTitleDeedIdDtlsType);
			populateShareHolder(titleDeedId);
			populateTitleDeedLocationDetails(titleDeedId);
			
		}
	
	
	}
	
	private void populateShareHolder(String titleDeedId) {
		Map<String,String> ownershipTypeMap = PartyUtil.getGCMap("OWNERSHIPTYPE");
		Map<String,String> ownershipStatusMap = PartyUtil.getGCMap("OWNERSHIPSTATUS");
		
		ArrayList<String> shareHolderParam = new ArrayList<String>();
		shareHolderParam.add(titleDeedId);
		List<IBOCE_TITLEDEEDSHAREHOLDER> shareHolderList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOCE_TITLEDEEDSHAREHOLDER.BONAME,shareHolderWhere, shareHolderParam, null, false);
		
		ListShareHolderDtlsType titleShareList = new ListShareHolderDtlsType();
		boolean select = true;
		if(shareHolderList!=null && (!shareHolderList.isEmpty())) {
			
			for(IBOCE_TITLEDEEDSHAREHOLDER ptitle:shareHolderList){
				ShareHolderDtlsType shareHolderDtl = new ShareHolderDtlsType();
				shareHolderDtl.setShareHolderIdpk(ptitle.getBoID());
				shareHolderDtl.setTitleDeedId(ptitle.getF_TITLEDEEDID());
				shareHolderDtl.setNotes(ptitle.getF_NOTES());
				shareHolderDtl.setOwnershipStatus(ownershipStatusMap.get(ptitle.getF_OWNERSHIPSTATUS()));
				shareHolderDtl.setOwnershipType(ownershipTypeMap.get(ptitle.getF_OWNERSHIPTYPE()));
				shareHolderDtl.setPartId(ptitle.getF_PARTYID());
				shareHolderDtl.setPartyName(ptitle.getF_SHAREPARTYNAME());
				shareHolderDtl.setSharePercentage(ptitle.getF_SHAREPERCENTAGE());
				
				shareHolderDtl.setSelect(select);
				select= false;
				//shareHolderDtl.setSerialNumber(index+"");
				
				
				
				titleShareList.addShareHolderDetails(shareHolderDtl);
			}
			setF_OUT_shareHolderDtlsList(titleShareList);
		}
		else {
			setF_OUT_shareHolderDtlsList(new ListShareHolderDtlsType());
		}
		
	}
	
	private void populateTitleDeedLocationDetails(String titleDeedId) {
		ArrayList<String> titleDeedLocParam = new ArrayList<String>();
		titleDeedLocParam.add(titleDeedId);
		List<IBOCE_TITLEDEEDLOCATION> titleDeedLocList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOCE_TITLEDEEDLOCATION.BONAME,titleDeedLocWhere, titleDeedLocParam, null, false);
		
		ListTitleDeedLocDtlsType titleDeedLt = new ListTitleDeedLocDtlsType();
		boolean select = true;
		if(titleDeedLocList!=null && (!titleDeedLocList.isEmpty())) {
			for(IBOCE_TITLEDEEDLOCATION tdeedDtl:titleDeedLocList){
				TitleDeedLocationdtlsType tDeed = new TitleDeedLocationdtlsType();
				tDeed.setTitleDeedLocIdpk(tdeedDtl.getBoID());
				tDeed.setTitleDeedId(tdeedDtl.getF_TITLEDEEDID());
				tDeed.setLocationEastDegree(tdeedDtl.getF_LOCEASTDEGREE());
				tDeed.setLocationEastSection(tdeedDtl.getF_LOCEASTSECTION());
				tDeed.setLocationNorthDegree(tdeedDtl.getF_LOCNORTHDEGREE());
				tDeed.setLocationNorthSection(tdeedDtl.getF_LOCNORTHSECTION());
				tDeed.setSerial(tdeedDtl.getF_SERIAL());
				tDeed.setSelect(select);
				select= false;
				titleDeedLt.addTitleDeedLocDtls(tDeed);
			
				//index++;
			}
			setF_OUT_titleDeedLocList(titleDeedLt);
		}
		else {
			setF_OUT_titleDeedLocList(new ListTitleDeedLocDtlsType());
		}
		
		
	}
		
	}	
		
	



