package com.ce.party;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.Chronology;
import org.joda.time.LocalDate;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.chrono.IslamicChronology;

import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.ListTitleDeedIdDtlsType;
import com.misys.ce.types.TitleDeedDetailsType;
import com.trapedza.bankfusion.bo.refimpl.CE_TITLEDEEDDETAILSID;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TITLEDEEDDETAILS;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PopulateHijriDate;

public class PopulateHijriDate extends AbstractCE_PopulateHijriDate{



	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	
	

	public PopulateHijriDate() {
		super();
	}
	
	public PopulateHijriDate(BankFusionEnvironment env){
		
	}
	
	public void process(BankFusionEnvironment env) throws BankFusionException {
		
		final Log LOGGER = LogFactory.getLog(PopulateHijriDate.class.getName());
				
		  String hijriDate = getF_IN_hijriDate();
          GregorianToHijriConversion(hijriDate);

}
	
	private void GregorianToHijriConversion(String gregorianDate) {
		
	       String DateArr[] = gregorianDate.split("-");
	       HijrahDate hijriDate = HijrahChronology.INSTANCE.date(Integer.parseInt(DateArr[2]), Integer.parseInt(DateArr[1]), Integer.parseInt(DateArr[0]));
	       DateTimeFormatter customFormatterGregorian = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	       String gregorianDateInString = IsoChronology.INSTANCE.date(hijriDate).format(customFormatterGregorian).toString();
	       DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	       dateFormat.setLenient(false);
	       Date utilDate = null;
	       try {
	    	   utilDate = dateFormat.parse(gregorianDateInString);
	    	   java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		       setF_OUT_fromDate(sqlDate);
	    	   
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       

	}




}
