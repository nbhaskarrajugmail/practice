package com.ce.party.bg;

import static com.ce.adf.CEConstants.*;
import static com.ce.sadad.util.SadadMessageConstants.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;


import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.ws.security.util.UUIDGenerator;
import org.w3c.dom.Document;

import com.ce.adf.CEUtil;
import com.ce.events.EventHelper;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.Creation;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.CurrencyInformation;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails.TxnItem;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails.TxnItem.ChequeDeposits;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails.TxnItem.Currency;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails.TxnItem.Mandatory;
import com.ce.party.bg.TFSBatchPosting.TFSBatchInformation.TransactionDetails.TxnItem.Optional;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_GenerateBatchFileDetails;

public class GenerateBatchGateWayFile extends
		AbstractCE_PTY_GenerateBatchFileDetails {
	final ObjectFactory objectFactory = new ObjectFactory();
	private static final long serialVersionUID = 1L;
	Log logger = LogFactory.getLog(GenerateBatchGateWayFile.class);
	public final String referenceNum = UUIDGenerator.getUUID();
	String userBranch = EMPTY;
	
	public GenerateBatchGateWayFile(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		logger.info("Inside process GenerateBatchGateWayFile");
		EventHelper events = new EventHelper();
		VectorTable deceasedPrtyDtlsTable = new VectorTable();
		deceasedPrtyDtlsTable = getF_IN_deceasedPartyDetails();
		if ((deceasedPrtyDtlsTable != null)
				&& (deceasedPrtyDtlsTable.size() > 0)) {
			try {
				logger.info("GenerateBatchGateWayFile: Before generate");
				generateBGXML(deceasedPrtyDtlsTable, env);
				logger.info("GenerateBatchGateWayFile: Generate Success");
				events.raiseBusinessEvent(CE_BATCHGATEWAY_SUCESS);
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("GenerateBatchGateWayFile: Fail"+e);
				events.raiseBusinessEvent(CE_BATCHGATEWAY_FAIL);
			}
		}
	}

	Document outputDoc;

	public void generateBGXML(VectorTable deceasedPrtyDtlsTable,
			BankFusionEnvironment env) throws Exception {
		StringWriter writer = null;
		try {
			genAcctReq(deceasedPrtyDtlsTable, env);
			TransformerFactory transFactory = TransformerFactory.newInstance();
			Transformer transformer = transFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
					"yes");
			transformer.setOutputProperty(
					"{http://xml.apache.org/xslt}indent-amount", "4");
			writer = new StringWriter();
			transformer.transform(new DOMSource(outputDoc), new StreamResult(writer));
		} catch (Exception e) {
			throw e;
		}
	}

	private void genAcctReq(VectorTable deceasedPrtyDtlsTable,
			BankFusionEnvironment env) throws Exception {
		userBranch = env.getUserBranch();
		TFSBatchPosting batchPosting = objectFactory.createTFSBatchPosting();
		batchPosting.setDescription("DesceasedPartyBatchGateWayFile");

		TFSBatchInformation batchInfo = objectFactory
				.createTFSBatchPostingTFSBatchInformation();
		batchInfo.setProcessed(0);
		String batchno = deceasedPrtyDtlsTable.getRowTags(0).get("DLBATCHNO").toString();
		batchInfo.setBatchReference(batchno);
		batchInfo.setReversals(0);
		

		CurrencyInformation currInfo = objectFactory
				.createTFSBatchPostingTFSBatchInformationCurrencyInformation();
		currInfo.setCurrencyAmount(getTotalAmt(deceasedPrtyDtlsTable));
		currInfo.setISOCurrencyCode(currencyCode);
		batchInfo.setCurrencyInformation(currInfo);

		Creation creation = objectFactory
				.createTFSBatchPostingTFSBatchInformationCreation();
		creation.setDate(getBusinessDate());
		batchInfo.setCreation(creation);

		TransactionDetails transactionDetails = objectFactory
				.createTFSBatchPostingTFSBatchInformationTransactionDetails();
		transactionDetails
				.setItemCount(deceasedPrtyDtlsTable.size() + 1);
		batchInfo.setTransactionDetails(transactionDetails);

		for (int i = 0; i < deceasedPrtyDtlsTable.size(); ++i) {
			HashMap row = deceasedPrtyDtlsTable.getRowTags(i);
			buildCreditLeg(row, batchInfo, deceasedPrtyDtlsTable);
		}
		
		buildDebitLeg(batchInfo, deceasedPrtyDtlsTable);

		batchPosting.setTFSBatchInformation(batchInfo);

		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance("com.ce.party.bg");
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
					Boolean.TRUE);
			JAXBElement<TFSBatchPosting> jaxbElement = new JAXBElement<TFSBatchPosting>(
					new QName("TFSBatchPosting"), TFSBatchPosting.class,
					batchPosting);
			String obj = (String) ModuleConfiguration.getInstance()
					.getModuleConfigurationValue(BAT_MODULE_NAME, BAT_BG_MODULE_FPATH);
			String fileLoc = CommonConstants.EMPTY_STRING;
			
			if (null != obj) {
				fileLoc = (String) obj + File.separator + env.getUserID() + userBranch;
			}
			logger.info("File Path: "+fileLoc);
			logger.info("Generated File Path:: "+fileLoc + File.separator
					+ "BG" +batchno + "_" + CEUtil.getDate() + ".xml");
			File file = new File(fileLoc + File.separator
					+ "BG" +batchno + "_" + CEUtil.getDate() + ".xml");
			FileWriter sw = new FileWriter(file);

			jaxbMarshaller.marshal(jaxbElement, sw);
			jaxbMarshaller.marshal(jaxbElement, System.out);
			sw.close();
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void buildCreditLeg(HashMap row, TFSBatchInformation batchInfo, VectorTable deceasedPrtyDtlsTable) {
		    String crTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue(CE_SADAD_INTERFACE, SADAD_BG_CR_TXNCODE);
			Integer zeroB = 0;
			TxnItem txnItem = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItem();
			txnItem.setPostingType("N");

			Mandatory mandatory = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemMandatory();
			mandatory.setDRCRFlag("C");
			mandatory.setAccountID((String)row.get("BOID"));
			mandatory.setAmount((BigDecimal)row.get("OUTSTANDINGAMT"));
			mandatory.setNarrative("Batch Credit Transaction");
			mandatory.setTxnCode(crTxnCode);
			txnItem.setMandatory(mandatory);

			Optional optional = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemOptional();
			optional.setReference(referenceNum);
			//optional.setSourceBranch((String) row.get("LOANPLACE"));
			optional.setSourceBranch(userBranch);
			optional.setValueDate(getBusinessDate());
			optional.setShortName((String) row.get("BORROWERNAME"));
			optional.setMaturityDate(getBusinessDate());
			optional.setBankChequeIssue(zeroB);
			optional.setCoinsAmount(zeroB);
			optional.setNotesAmount(zeroB);
			optional.setChequesCount(zeroB);
			optional.setTakeWhatYouCan(zeroB);
			optional.setForcedNotice(zeroB);
			txnItem.setOptional(optional);

			Currency currency = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemCurrency();
			currency.setCurrency(currencyCode);
			currency.setExchangeRate(zeroB);
			currency.setExchangeRateType("SPOT");
			currency.setBaseEquivalent(zeroB);
			txnItem.setCurrency(currency);

			ChequeDeposits chequeDeposits = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemChequeDeposits();
			chequeDeposits.setChequeDraftNumber(zeroB);
			chequeDeposits.setPayeeAccountID(EMPTY);
			chequeDeposits.setPayeeDepositAction(EMPTY);
			chequeDeposits.setPayeeDepositAmount(zeroB);
			txnItem.setChequeDeposits(chequeDeposits);
			
			batchInfo.getTransactionDetails().getTxnItem().add(txnItem);
		}

	private void buildDebitLeg(TFSBatchInformation batchInfo, VectorTable deceasedPrtyDtlsTable) {
		    String interAcctNo = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue(CE_SADAD_INTERFACE, SADAD_BG_DR_ACCT);
		    String drTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue(CE_SADAD_INTERFACE, SADAD_BG_DR_TXNCODE);
			Integer zeroB = 0;
			TxnItem txnItem = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItem();
			txnItem.setPostingType("N");

			Mandatory mandatory = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemMandatory();
			mandatory.setDRCRFlag("D");
			mandatory.setAccountID(interAcctNo);
			mandatory.setAmount(getTotalAmt(deceasedPrtyDtlsTable));
			mandatory.setNarrative("Batch Debit Transaction");
			mandatory.setTxnCode(drTxnCode);
			txnItem.setMandatory(mandatory);

			Optional optional = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemOptional();
			optional.setReference(referenceNum);
			optional.setSourceBranch(userBranch);
			optional.setValueDate(getBusinessDate());
			optional.setShortName("Internal A/C");//To change
			optional.setMaturityDate(getBusinessDate());
			optional.setBankChequeIssue((int) zeroB);
			optional.setCoinsAmount(zeroB);
			optional.setNotesAmount(zeroB);
			optional.setChequesCount(zeroB);
			optional.setTakeWhatYouCan(zeroB);
			optional.setForcedNotice(zeroB);
			txnItem.setOptional(optional);

			Currency currency = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemCurrency();
			currency.setCurrency(currencyCode);
			currency.setExchangeRate(zeroB);
			currency.setExchangeRateType("SPOT");
			currency.setBaseEquivalent(zeroB);
			txnItem.setCurrency(currency);
			
			ChequeDeposits chequeDeposits = objectFactory
					.createTFSBatchPostingTFSBatchInformationTransactionDetailsTxnItemChequeDeposits();
			chequeDeposits.setChequeDraftNumber(zeroB);
			chequeDeposits.setPayeeAccountID(EMPTY);
			chequeDeposits.setPayeeDepositAction(EMPTY);
			chequeDeposits.setPayeeDepositAmount(zeroB);
			chequeDeposits.setInstrumentType(EMPTY);
			txnItem.setChequeDeposits(chequeDeposits);
			
			batchInfo.getTransactionDetails().getTxnItem().add(txnItem);
	}

	private BigDecimal getTotalAmt(VectorTable deceasedPrtyDtlsTable) {
		BigDecimal totalAmt = BigDecimal.ZERO;
		for (int i = 0; i < deceasedPrtyDtlsTable.size(); ++i) {
			HashMap row = deceasedPrtyDtlsTable.getRowTags(i);
			BigDecimal amountRec = (BigDecimal) row.get("OUTSTANDINGAMT");
			totalAmt = totalAmt.add(amountRec);
		}
		return totalAmt;
	}
	private String getBusinessDate(){
		DateFormat expDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date bDate = SystemInformationManager.getInstance().getBFBusinessDate();
		String businessDate =  expDateFormat.format(bDate);
		return businessDate;
	}
}
