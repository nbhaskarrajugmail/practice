/**
 * 
 */
package com.ce.core.finance.batch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/** @author Subhajit */
public class ExtractFinanceDetailsPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(ExtractFinanceDetailsPostProcess.class
			.getName());

	private BankFusionEnvironment environment;
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus status;

	/**
	 * 
	 */
	public ExtractFinanceDetailsPostProcess() {

	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.IBatchPostProcess#init(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment, com.trapedza.bankfusion.batch.fatom.AbstractFatomContext, com.trapedza.bankfusion.batch.process.engine.IBatchStatus)
	 */
	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext ctx, IBatchStatus batchStatus) {

		this.environment = env;
		this.context = ctx;
		this.status = batchStatus;
	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.IBatchPostProcess#process(com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator)
	 */
	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {
		if(logger.isInfoEnabled())
			logger.info("Into PostProcess method---");
		
		return status;
	}
}
