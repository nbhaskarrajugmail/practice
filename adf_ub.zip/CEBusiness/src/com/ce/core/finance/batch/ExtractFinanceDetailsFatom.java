/**
 * 
 */
package com.ce.core.finance.batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_ExtractFinanceDetailsBatch;

/** @author Subhajit */
public class ExtractFinanceDetailsFatom extends AbstractCE_ExtractFinanceDetailsBatch {

	private transient final static Log logger = LogFactory.getLog(ExtractFinanceDetailsFatom.class
			.getName());
	private static final String BATCH_PROCESS_NAME = "CEExtractTxnDetails";
	
	private IPersistenceObjectsFactory factory;
	private Map dataMap;

	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_TXNSRIDTAG "
			+ "(CEROWSEQPK,CETRANSACTIONSRID,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY SRNO) CEROWSEQPK,"
			+ " TRANSACTIONSRID,  0 VERSIONNUM FROM WASADMIN.UBTB_TRANSACTION WHERE UBTYPE IN('N','I') AND "
			+ "TRANSACTIONSRID NOT IN(SELECT CETXNSRIDPK FROM CUSTOMEXTN.CETB_FINTXNDETAILS)";

	/**
	 * 
	 */
	public ExtractFinanceDetailsFatom(BankFusionEnvironment env) {
		super(env);
	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#getFatomContext()
	 */
	@Override
	protected AbstractFatomContext getFatomContext() {
		return new ExtractFinanceDetailsContext("CEExtractTxnDetails");
	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#processBatch(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment, com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {

		logger.info("At processBatch method");
		
		dataMap = getInDataMap();
		context.setInputTagDataMap(dataMap);
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		this.factory.bulkDeleteAll("CE_TXNSRIDTAG");
		this.factory.commitTransaction();
		this.factory.beginTransaction();
		
		/*Timestamp datetime = SystemInformationManager.getInstance().getBFBusinessDateTime();
		datetime.setHours(0);
		datetime.setMinutes(0);
		datetime.setSeconds(0);
		datetime.setNanos(0);*/
		
		try {
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			//ps.setTimestamp(1, datetime);
			
			logger.info("Statement:" + ps.toString());
			ps.execute();
			this.factory.commitTransaction();
		    this.factory.beginTransaction();
		    logger.info("Data inserted into tag");
			
		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:"
					+ sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// Should not come here as this is already
			// handled in handler
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
		logger.info("Call Batch Service");
		BatchService service = (BatchService) ServiceManager.getService("BatchService");
		boolean status = service.runBatch(env, context);
		setF_OUT_Status(status);

	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#setOutputTags(com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
		// TODO Auto-generated method stub

	}

	

}
