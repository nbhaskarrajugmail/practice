/**
 * 
 */
package com.ce.core.finance.batch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

/** @author Subhajit */
public class ExtractFinanceDetailsAccumulator extends AbstractProcessAccumulator {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = ExtractFinanceDetailsAccumulator.class.getName();
	private transient final static Log logger = LogFactory.getLog(CLASS_NAME);
	public ExtractFinanceDetailsAccumulator(Object[] args) {
		super(args);
	}

	@Override
	public void accumulateTotals(Object[] data) {
	}

	@Override
	public Object[] getMergedTotals() {
		return null;
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		return null;
	}

	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator accumulator) {
	}

	@Override
	public void mergeAccumulatedTotals(Object[] accumulatedTotals) {
	}

	@Override
	public void acceptChanges() {
	}

	@Override
	public void restoreState() {
	}

	@Override
	public void storeState() {
	}

}
