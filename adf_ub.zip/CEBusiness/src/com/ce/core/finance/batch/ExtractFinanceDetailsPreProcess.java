/**
 * 
 */
package com.ce.core.finance.batch;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * @author Subhajit
 *
 */
public class ExtractFinanceDetailsPreProcess implements IBatchPreProcess {

	/**
	 * 
	 */
	public ExtractFinanceDetailsPreProcess() {
		// TODO Auto-generated constructor stub
	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.IBatchPreProcess#init(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment)
	 */
	@Override
	public void init(BankFusionEnvironment arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.IBatchPreProcess#process(com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	public void process(AbstractFatomContext arg0) {
		// TODO Auto-generated method stub

	}

}
