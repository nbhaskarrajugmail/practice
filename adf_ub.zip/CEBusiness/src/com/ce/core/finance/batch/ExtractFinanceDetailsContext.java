package com.ce.core.finance.batch;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

public class ExtractFinanceDetailsContext extends AbstractPersistableFatomContext {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String PROCESS_CLASSNAME = loadProcessClassName("CEExtractTxnDetails",
			"com.ce.core.finance.batch.ExtractFinanceDetailsProcess");
	private Map inputTagDataMap;
	private Map outputTagDataMap;
	private String batchProcessName;
	private String serviceName;
	private Object[] additionalParams;

	public ExtractFinanceDetailsContext(String batchProcessName) {
		this.batchProcessName = batchProcessName;
		this.additionalParams = new Object[2];
		this.inputTagDataMap = new HashMap();
		this.outputTagDataMap = new HashMap();
	}

	public ExtractFinanceDetailsContext() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isMultiNodeSupported() {

		return false;
	}

	@Override
	public void setOutputTagDataMap(Map outDataMap) {
		this.outputTagDataMap = outDataMap;
	}

	@Override
	public Map getOutputTagDataMap() {
		return this.outputTagDataMap;
	}

	@Override
	public void setInputTagDataMap(Map inDataMap) {
		this.inputTagDataMap = inDataMap;

	}

	@Override
	public Map getInputTagDataMap() {
		return this.inputTagDataMap;
	}

	@Override
	public String getBatchProcessName() {
		return this.batchProcessName;
	}

	@Override
	public void setBatchProcessName(String batchProcessName) {
		this.batchProcessName = batchProcessName;
	}

	@Override
	public void setAdditionalProcessParams(Object[] additionalParams) {
		this.additionalParams = Arrays.copyOf(additionalParams, additionalParams.length);

	}

	@Override
	public Object[] getAdditionalProcessParams() {
		return Arrays.copyOf(this.additionalParams, this.additionalParams.length);
	}

	@Override
	public String getProcessClassName() {
		return PROCESS_CLASSNAME;
	}

	// @Override
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	// @Override
	public String getServiceName() {
		return this.serviceName;
	}

}
