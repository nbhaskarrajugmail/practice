/**
 * 
 */
package com.ce.core.finance.batch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOAccount;
import com.trapedza.bankfusion.bo.refimpl.IBOBalanceSheetFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_FINTXNDETAILS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_TXNSRIDTAG;
import com.trapedza.bankfusion.bo.refimpl.IBONominalCodes;
import com.trapedza.bankfusion.bo.refimpl.IBOTransaction;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

/** @author Subhajit */
public class ExtractFinanceDetailsProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(ExtractFinanceDetailsProcess.class
			.getName());
	private static String GENERIC_QUERY = "SELECT " + IBOCE_TXNSRIDTAG.TRANSACTIONSRID
			+ " AS TRANSACTIONSRID FROM " + IBOCE_TXNSRIDTAG.BONAME + " WHERE "
			+ IBOCE_TXNSRIDTAG.ROWSEQ + " BETWEEN ? AND ? ";
	
	String NOMINALCODE_Query = " WHERE " + IBOBalanceSheetFeature.ACCOUNTID + " = ?";
	String TXN_BY_TXN_REF = " WHERE " + IBOTransaction.TRANSACTIONID + " = ?";
	private static String LETTER_N = "N";
	private static String CREDIT = "C";
	private static String TRANSACTIONSRID = "TRANSACTIONSRID";

	private IPersistenceObjectsFactory factory;

	private AbstractProcessAccumulator accumulator;

	/** @param context */
	public ExtractFinanceDetailsProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = ((ExtractFinanceDetailsContext) context);
	}

	public ExtractFinanceDetailsProcess(BankFusionEnvironment environment,
			AbstractPersistableFatomContext context, Integer priority) {
		super(environment, context, priority);
	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.runtime.impl.AbstractBatchProcess#process(int)
	 */
	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		if (logger.isInfoEnabled())
			logger.info("ExtractFinanceDetailsProcess -- process method");
		this.factory = BankFusionThreadLocal.getPersistanceFactory();

		int pageSize = this.context.getPageSize();
		int fromValue = (pageToProcess - 1) * pageSize + 1;
		int toValue = pageToProcess * pageSize;
		ArrayList params1 = new ArrayList();
		params1.add(Integer.valueOf(fromValue));
		params1.add(Integer.valueOf(toValue));

		List<SimplePersistentObject> records = this.factory.executeGenericQuery(GENERIC_QUERY, params1,
				null, true);

		for (SimplePersistentObject record : records) {
			String srid = (String) record.getDataMap().get(TRANSACTIONSRID);
			IBOTransaction transaction = (IBOTransaction) factory.findByPrimaryKey(
					IBOTransaction.BONAME, srid, true);
			String accountId = transaction.getF_ACCOUNTPRODUCT_ACCPRODID();
			IBOAccount account = (IBOAccount) factory.findByPrimaryKey(IBOAccount.BONAME, accountId,
					true);

			ArrayList<String> param = new ArrayList<String>();
			param.add(accountId);
			IBOBalanceSheetFeature balanceSheetFeatue = (IBOBalanceSheetFeature) factory
					.findFirstByQuery(IBOBalanceSheetFeature.BONAME, NOMINALCODE_Query, param, true);
			String nominalCode = "";
			if (balanceSheetFeatue != null) {
				if (transaction.getF_DEBITCREDITFLAG().equalsIgnoreCase(CREDIT)) {
					nominalCode = balanceSheetFeatue.getF_CRNOMINALCODE();
				} else {
					nominalCode = balanceSheetFeatue.getF_DRNOMINALCODE();
				}
			}
			IBONominalCodes nominalCodeObj = (IBONominalCodes) factory.findByPrimaryKey(
					IBONominalCodes.BONAME, nominalCode, true);

			IBOCE_FINTXNDETAILS txnDetails = (IBOCE_FINTXNDETAILS) factory
					.getStatelessNewInstance(IBOCE_FINTXNDETAILS.BONAME);
			txnDetails.setBoID(srid);
			txnDetails.setF_TXNID(transaction.getF_TRANSACTIONID());
			txnDetails.setF_ACCOUNTID(transaction.getF_ACCOUNTPRODUCT_ACCPRODID());
			txnDetails.setF_AMOUNT(transaction.getF_AMOUNT());
			txnDetails.setF_CURRENCY(transaction.getF_ISOCURRENCYCODE());
			txnDetails.setF_TXNCODE(transaction.getF_CODE());
			txnDetails.setF_POSTINGDATE(transaction.getF_POSTINGDATE());
			txnDetails.setF_VALUEDATE(transaction.getF_VALUEDATE());
			String narrative = transaction.getF_NARRATION();
			String loanAccountNumber = CommonConstants.EMPTY_STRING;
			String txnNarrative = CommonConstants.EMPTY_STRING;
			List<String> narrativeBreakup = new ArrayList<>();
			if (narrative != null && !narrative.isEmpty()) {
				narrativeBreakup = (null != narrative && narrative.trim().length() > 0)? Arrays.asList(narrative.split("\\$")): new ArrayList<String>();
			}
			if(narrativeBreakup.size()==2) {
				loanAccountNumber = narrativeBreakup.get(0);
				txnNarrative  = narrativeBreakup.get(1);
			}else {
				txnNarrative = narrative;
			}
			if (loanAccountNumber.isEmpty()) {
				ArrayList<String> txnParam = new ArrayList<String>();
				txnParam.add(transaction.getF_TRANSACTIONID());
				List<IBOTransaction> txnList = factory.findByQuery(IBOTransaction.BONAME, TXN_BY_TXN_REF, txnParam, null,
						true);
				for (IBOTransaction txn : txnList) {
					if (!txn.getBoID().equals(transaction.getBoID())) {
						narrative = txn.getF_NARRATION();
					}
				}
				if (narrative != null && !narrative.isEmpty()) {
					narrativeBreakup = (null != narrative && narrative.trim().length() > 0)? Arrays.asList(narrative.split("\\$")): new ArrayList<String>();
				}
				if(narrativeBreakup.size()==2) {
					loanAccountNumber = narrativeBreakup.get(0);
					txnNarrative  = narrativeBreakup.get(1);
				}else {
					txnNarrative = narrative;
				}
			}
			txnDetails.setF_LOANACCOUNTID(loanAccountNumber);
			txnDetails.setF_PRINTED(false);
			txnDetails.setF_NARRATION(txnNarrative);
			txnDetails.setF_CUSTID(account.getF_CUSTOMERCODE());
			txnDetails.setF_CUSTNAME(account.getF_ACCOUNTNAME());
			txnDetails.setF_DRCRFLAG(transaction.getF_DEBITCREDITFLAG());
			txnDetails.setF_TXNDATE(transaction.getF_TRANSACTIONDATE());
			txnDetails.setF_BRANCH(transaction.getF_SOURCEBRANCH());
			if (null != nominalCodeObj) {
				txnDetails.setF_GLCODE(nominalCode);
				txnDetails.setF_GLDESC(nominalCodeObj.getF_NOMINALDESCRIPTION());
			}
			txnDetails.setF_PROCESSED(LETTER_N);

			factory.create(IBOCE_FINTXNDETAILS.BONAME, txnDetails);
		}

		return this.accumulator;
	}

	/** @param environment
	 * @param context
	 * @param priority */
	public ExtractFinanceDetailsProcess(BankFusionEnvironment environment,
			AbstractFatomContext context, Integer priority) {
		super(environment, context, priority);

	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.runtime.impl.AbstractBatchProcess#getAccumulator()
	 */
	@Override
	public AbstractProcessAccumulator getAccumulator() {

		return this.accumulator;
	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.runtime.impl.AbstractBatchProcess#init()
	 */
	@Override
	public void init() {
		initialiseAccumulator();

	}

	/* (non-Javadoc)
	 * @see com.misys.bankfusion.subsystem.batch.runtime.impl.AbstractBatchProcess#initialiseAccumulator()
	 */
	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new ExtractFinanceDetailsAccumulator(accumulatorArgs);

	}

}
