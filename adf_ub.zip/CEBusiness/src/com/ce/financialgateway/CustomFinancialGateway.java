package com.ce.financialgateway;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.ce.financialgateway.restservice.CustomerLiabilitiesExt;
import com.ce.financialgateway.restservice.CustomerLiabilityRs;
import com.ce.financialgateway.restservice.IBRestCallHelper;
import com.misys.bankfusion.clearing.batch.BaseBatchFileCreatorHelper;
import com.misys.bankfusion.clearing.batch.IBatchFileCreatorHelper;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.config.ModuleConfiguration;
import com.misys.ce.types.BatchHeaderDetails;
import com.misys.ce.types.BatchPosting;
import com.misys.fbe.common.util.CommonUtil;
import com.misys.ub.batchfile.BatchFileCreatorIP;
import com.trapedza.bankfusion.bo.refimpl.IBOBatchFileLog;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOTransactionScreenControl;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.fatoms.BatchFileCreateFatom;
import com.trapedza.bankfusion.steps.refimpl.IBatchFileCreateFatom;

import bf.com.misys.ub.types.BatchGatewayInputs;
import bf.com.misys.ub.types.BatchUXEnhancementRq;
import bf.com.misys.ub.types.FileLocation;
import bf.com.misys.ub.types.FinancialGatewayResponse;
import bf.com.misys.ub.types.Parameters;

/**
 * 
 * @author sarfaraz.dilawar
 * 
 */
public class CustomFinancialGateway {
	Log logger = LogFactory.getLog(CustomFinancialGateway.class.getName());

	private IBatchFileCreatorHelper batchFileCreatorHelper = new BaseBatchFileCreatorHelper();

	private static final String FIND_BATCH_TXNS = " WHERE " + IBOCE_BATCHTXNDETAIL.BATCHREF + " =? AND "
			+ IBOCE_BATCHTXNDETAIL.STATUS + " <> 'PROCESSED'";

	SimpleDateFormat fileDateFormar = new SimpleDateFormat("yyyyMMddHHmmss");

	String debitTxnCode = "";
	String creditTxnCode = "";

	public BatchUXEnhancementRq createBatchGatewayfile(BatchHeaderDetails headr, BatchPosting posting) {
		BatchUXEnhancementRq batchUXEnhancementRq = new BatchUXEnhancementRq();
		debitTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.debitTxnCode");
		creditTxnCode = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.creditTxnCode");
		String gatewayRef = BatchCollectionUtil.getNextSequence(BatchCollectionConstants.BATCH_GATEWAY_PREFIX);
		BatchFileCreatorIP creator = new BatchFileCreatorIP();
		String generatedFileName = headr.getBatchRef() + "."
				+ fileDateFormar.format(SystemInformationManager.getInstance().getBFBusinessDateTime());
		creator.setBatchFileLocation(batchFileCreatorHelper.getBatchFilePath(generatedFileName));
		creator.setBatchReference(gatewayRef);
		creator.setPostDirectly(false);
		creator.setSupportNonExistingAccountInIP(true);
		creator.setPostingDetails(getPostingInstructions(headr));
		if (creator.getPostingDetails().hasData()) {
			createBatchFile(creator);
			BatchGatewayInputs batchGatewayInputs = new BatchGatewayInputs();
			FileLocation batchFileLocation = new FileLocation();
			batchFileLocation.setFileName(generatedFileName + ".1.xml");
			batchGatewayInputs.setBatchFileLocation(batchFileLocation);
			batchGatewayInputs.setValidationProfile("Clearing");
			batchGatewayInputs.setValidateAndPost(posting.getBatchGatewayPhases().equals("1"));
			batchGatewayInputs.setPostingOption(Integer.parseInt(posting.getActionOnBatchError()));
			Map serviceInputMap = new HashMap();
			String ref = GUIDGen.getNewGUID();
			batchUXEnhancementRq.setIsBatchResumable(false);
			batchUXEnhancementRq.setIsStatusRequired(true);
			batchUXEnhancementRq.setMicroflowID("UB_BAT_QueuedBatchGateway_SRV");
			Parameters parameters = new Parameters();
			parameters.setParamName("BatchGatewayInputs");
			parameters.setParamValue(batchGatewayInputs);
			batchUXEnhancementRq.addParameters(0, parameters);
			batchUXEnhancementRq.setUniqueBatchReference(ref);
		}
		return batchUXEnhancementRq;
	}

	public void updateRecordStatus(FinancialGatewayResponse resp, BatchHeaderDetails headr) {
		if (resp.getBatchStatus()) {

			if (headr.getTxnType().equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
				IBOBatchFileLog batch = (IBOBatchFileLog) BankFusionThreadLocal.getPersistanceFactory()
						.findByPrimaryKey(IBOBatchFileLog.BONAME, resp.getBatchReference());
				if (batch != null) {
					BigDecimal totalAmnt = batch.getF_BATCHCURRENCYCREDITTOTAL();

					String FINDTXN = " WHERE " + IBOCE_BATCHTXNDETAIL.BATCHREF + " = ? AND "
							+ IBOCE_BATCHTXNDETAIL.INTERNALACC + " = ? AND " + IBOCE_BATCHTXNDETAIL.BATCHRUNNINGAMNT
							+ " <> ? ";
					ArrayList prams = new ArrayList();
					prams.add(headr.getBatchRefSearch());
					prams.add(headr.getInternalAcc());
					prams.add(BigDecimal.ZERO);
					IBOCE_BATCHTXNDETAIL txnDtl = (IBOCE_BATCHTXNDETAIL) BankFusionThreadLocal.getPersistanceFactory()
							.findFirstByQuery(IBOCE_BATCHTXNDETAIL.BONAME, FINDTXN, prams, true);
					if (txnDtl != null) {
						BigDecimal amnt = txnDtl.getF_BATCHRUNNINGAMNT().subtract(totalAmnt);
						txnDtl.setF_BATCHRUNNINGAMNT(amnt);
					}
				}
			}

			IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, headr.getBatchRef(), true);
			fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PROCESSED);
			ArrayList param = new ArrayList();
			param.add(headr.getBatchRef());
			List<IBOCE_BATCHTXNDETAIL> listofUnProcessedRecs = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, FIND_BATCH_TXNS, param, null, true);
			for (IBOCE_BATCHTXNDETAIL dtlRec : listofUnProcessedRecs) {
				if (dtlRec.getF_PROCESSING().equals(CommonConstants.N)) {
					fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PARTPROCESSED);
					dtlRec.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_UNPROCESSED);
				} else {
					dtlRec.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_PROCESSED);
					dtlRec.setF_HOSTTXNREF(resp.getBatchTransactionId());
					dtlRec.setF_BATCHGWREF(resp.getBatchReference());
					dtlRec.setF_PROCESSING(CommonConstants.EMPTY_STRING);
				}
			}
		}
	}

	private void createBatchFile(BatchFileCreatorIP batchFileCreatorInput) {
		IBatchFileCreateFatom batchFileCreateFatom = new BatchFileCreateFatom(
				BankFusionThreadLocal.getBankFusionEnvironment());
		batchFileCreateFatom
				.setF_IN_POSTDIRECTLY((batchFileCreatorInput.isPostDirectly()) ? CommonConstants.Y : CommonConstants.N);
		batchFileCreateFatom.setF_IN_BATCHFILELOCN(batchFileCreatorInput.getBatchFileLocation());
		batchFileCreateFatom.setF_IN_BATCHREFERENCE(batchFileCreatorInput.getBatchReference());
		batchFileCreateFatom.setF_IN_INPUTLIST(batchFileCreatorInput.getPostingDetails());
		batchFileCreateFatom.setF_IN_ISOCURRENCYCODEDEFAULT(BatchCollectionConstants.DEFAULT_CURRENCY);
		batchFileCreateFatom.setF_IN_canGetNonExistingAccount(
				Boolean.valueOf(batchFileCreatorInput.isSupportNonExistingAccountInIP()));
		batchFileCreateFatom.process(BankFusionThreadLocal.getBankFusionEnvironment());
	}

	private String getDebitAccountNumber(BatchHeaderDetails headr) {
		IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, headr.getBatchRef(), true);
		fileDtls.setF_INTERNALACC(headr.getInternalAcc());
		fileDtls.setF_BANKID(headr.getBankID());
		if (StringUtils.isEmpty(headr.getInternalAcc())) {
			return getSettlementAccount(headr.getBankID());
		} else {
			return headr.getInternalAcc();
		}
	}

	private VectorTable getPostingInstructions(BatchHeaderDetails headr) {

		VectorTable postingMessages = new VectorTable();
		Timestamp now = SystemInformationManager.getInstance().getBFBusinessDateTime();
		ArrayList params = new ArrayList();
		params.add(headr.getBatchRef());
		List<IBOCE_BATCHTXNDETAIL> transactionList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, FIND_BATCH_TXNS, params, null, false);
		BigDecimal totalAmount = new BigDecimal(0);
		for (IBOCE_BATCHTXNDETAIL transactionDetail : transactionList) {
			if (transactionDetail.getF_PROCESSING().equalsIgnoreCase(CommonConstants.Y)) {
				totalAmount = totalAmount.add(transactionDetail.getF_AMOUNT());
				if (totalAmount.compareTo(headr.getAmountToBeProcessed()) > 0) {
					CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_AMOUNT_EXCEEDED);
				}
				if (!StringUtils.isEmpty(transactionDetail.getF_CREDITACC())) {
					postingMessages.addAll(new VectorTable(getTransactionDataMap(transactionDetail,
							transactionDetail.getF_CREDITACC(), transactionDetail.getF_AMOUNT(), now)));
				} else if (!StringUtils.isEmpty(transactionDetail.getF_INTERNALACC())) {
					postingMessages.addAll(new VectorTable(getTransactionDataMap(transactionDetail,
							transactionDetail.getF_INTERNALACC(), transactionDetail.getF_AMOUNT(), now)));
				} else if (!StringUtils.isEmpty(transactionDetail.getF_NATIONALID())) {
					addAccountsForNationalId(transactionDetail, postingMessages, now);
				}
			}
		}
		if (totalAmount.compareTo(new BigDecimal(0)) > 0) {
			postingMessages.addAll(new VectorTable(getTransactionDataMap(totalAmount, "D", headr.getBatchRef(),
					getFixedNarrative(debitTxnCode), getDebitAccountNumber(headr), CommonConstants.EMPTY_STRING, now)));
		}
		return postingMessages;
	}

	private VectorTable addAccountsForNationalId(IBOCE_BATCHTXNDETAIL transactionDetail, VectorTable postingMessages,
			Timestamp now) {
		IBRestCallHelper helper = new IBRestCallHelper();
		CustomerLiabilityRs liabilities = helper.getCustomerLiabilities(transactionDetail.getF_NATIONALID());
		BigDecimal balanceAmount = transactionDetail.getF_AMOUNT();
		for (CustomerLiabilitiesExt thisLiability : liabilities.getLiabilities()) {
			if (balanceAmount.compareTo(BigDecimal.valueOf(0)) > 0) {
				String account = thisLiability.getDealAccountID();
				BigDecimal amount = thisLiability.getLiabilityAmount().getAmount();
				if (balanceAmount.compareTo(amount) >= 0) {
					balanceAmount = balanceAmount.subtract(amount);
					postingMessages
							.addAll(new VectorTable(getTransactionDataMap(transactionDetail, account, amount, now)));
				} else {
					postingMessages.addAll(
							new VectorTable(getTransactionDataMap(transactionDetail, account, balanceAmount, now)));
					balanceAmount = balanceAmount.subtract(balanceAmount);
				}
			}
		}
		return postingMessages;
	}

	private Map<String, Object> getTransactionDataMap(IBOCE_BATCHTXNDETAIL tDtl, String account, BigDecimal amount,
			Timestamp now) {
		return getTransactionDataMap(amount, "C", tDtl.getF_BATCHREF(), tDtl.getF_NARRATIVE(), account,
				tDtl.getF_CHEQUENO(), now);
	}

	private Map<String, Object> getTransactionDataMap(BigDecimal transactionAmount, String postingAction,
			String transactionReference, String narrative, String accountNumber, String chequeDraftNo,
			Timestamp valueDateTime) {
		Map rowMap = new HashMap();
		Integer chequeDraftNumber = StringUtils.isEmpty(chequeDraftNo) ? 0 : Integer.parseInt(chequeDraftNo);
		rowMap.put("INSTRUMENTTYPE", 0);
		rowMap.put("ACCOUNTID", accountNumber);
		rowMap.put("MESSAGETYPE", "N");
		rowMap.put("AMOUNT", transactionAmount);
		rowMap.put("BASEEQUIVALENTAMOUNT", transactionAmount);
		rowMap.put("POSTINGACTION", postingAction);
		rowMap.put("CODE", postingAction.equals("C") ? creditTxnCode : debitTxnCode);
		if (StringUtils.isEmpty(narrative)) {
			narrative = getFixedNarrative(creditTxnCode);
		}
		rowMap.put("NARRATION", narrative);
		if (chequeDraftNumber == null)
			rowMap.put("CHEQUEDRAFTNUMBER", new Long(0));
		else
			rowMap.put("CHEQUEDRAFTNUMBER", new Long(chequeDraftNumber));
		rowMap.put("SOURCEBRANCH", BankFusionThreadLocal.getUserSession().getBranchSortCode());
		rowMap.put("REFERENCE", transactionReference);
		rowMap.put("VALUEDATE", valueDateTime);
		return rowMap;
	}

	private String getFixedNarrative(String misCode) {
		String narrative = misCode;
		IBOTransactionScreenControl transactionControl = (IBOTransactionScreenControl) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOTransactionScreenControl.BONAME, misCode);
		if (transactionControl != null) {
			narrative = CommonUtil.getCodeDescription("TSCFXDNRTVE", transactionControl.getF_FIXEDNARRATIVE());
		}
		return narrative;
	}

	private String getSettlementAccount(String bankId) {
		String GET_SETTLEMENT_QUERY = "SELECT SETTLEMENTACCOUNT FROM "
				+ BankFusionPropertySupport.getProperty("System.DefaultSchema", "WASADMIN") + " .BANKS WHERE NSC = '"
				+ bankId + "'";
		ResultSet rs = null;
		try (PreparedStatement pstmt = BankFusionThreadLocal.getPersistanceFactory().getJDBCConnection()
				.prepareStatement(GET_SETTLEMENT_QUERY)) {
			rs = pstmt.executeQuery();
			if (rs != null && rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			logger.error("Error getting settlement account for other bank");
			throw new BankFusionException(e);
		} finally {
			BatchCollectionUtil.close(rs);
		}
		return "";
	}

}
