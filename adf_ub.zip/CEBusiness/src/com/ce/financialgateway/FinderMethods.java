package com.ce.financialgateway;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.StringUtils;

//import com.misys.bankfusion.subsystem.persistence.IPagingData;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class FinderMethods {

	public static List<IBOCE_BATCHFILEDETAIL> getListOfBatchReferences(String status, String fileName,
			BankFusionEnvironment env, IPagingData pagingData) {
		ArrayList params = new ArrayList();
		StringBuffer QUERY = new StringBuffer(" WHERE ");
		if (!StringUtils.isEmpty(status)) {
			QUERY.append(IBOCE_BATCHFILEDETAIL.STATUS + " = ? ");
			params.add(status);
		}
		if (!StringUtils.isEmpty(fileName)) {
			if (params.size() > 0)
				QUERY.append(" AND ");
			QUERY.append(IBOCE_BATCHFILEDETAIL.FILENAME + " like ? ");
			params.add(fileName);
		}
		if (params.size() > 0)
			return BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BATCHFILEDETAIL.BONAME,
					QUERY.toString(), params, pagingData, true);
		else
			return BankFusionThreadLocal.getPersistanceFactory().findAll(IBOCE_BATCHFILEDETAIL.BONAME, pagingData,
					true);
	}

	public static List<IBOCE_BATCHTXNDETAIL> getListOfBatchTransactions(String batchRef, String getUnProcessedRecs,
			BankFusionEnvironment env, IPagingData pagingData) {
		ArrayList params = new ArrayList();
		StringBuffer QUERY = new StringBuffer(" WHERE " + IBOCE_BATCHTXNDETAIL.BATCHREF + " =? ");
		params.add(batchRef);
		if (getUnProcessedRecs.equalsIgnoreCase("Y")) {
			QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.STATUS + " = ? ");
			params.add("UNPROCESSED");
		} else if (getUnProcessedRecs.equalsIgnoreCase("N")) {
			QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.STATUS + " <> ? ");
			params.add("UNPROCESSED");
		}
		return BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, QUERY.toString(),
				params, pagingData, true);
	}

	public static List<IBOCE_BATCHTXNDETAIL> getListOfBatchForIntAccount(String internalAcc, String branchCd,
			BankFusionEnvironment env, IPagingData pagingData) {
		StringBuffer QUERY = new StringBuffer(" WHERE " + IBOCE_BATCHTXNDETAIL.INTERNALACC + " = ?  AND "
				 + IBOCE_BATCHTXNDETAIL.STATUS + " = ? ");
		ArrayList params = new ArrayList();
		params.add(internalAcc);
		//params.add(BigDecimal.ZERO);
		params.add(BatchCollectionConstants.BATCH_STATUS_PROCESSED);
		String userBranch = BankFusionThreadLocal.getUserSession().getBranchSortCode();
		String headOfficeBranchesString = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT",
				"BatchInfo.headOffices");
		List headOfficeBranches = Arrays.asList(headOfficeBranchesString.split(","));
		if (!headOfficeBranches.contains(userBranch)) {
			QUERY.append(" AND ( " + IBOCE_BATCHTXNDETAIL.BRANCHCD + " = ?  OR  " + IBOCE_BATCHTXNDETAIL.BRANCHCD
					+ " IS NULL ) ");
			params.add(userBranch);
		}
		return BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, QUERY.toString(),
				params, pagingData, true);
	}

}
