package com.ce.financialgateway;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.ce.bankfusion.ib.bo.refimpl.IBOCE_ADF_BatchTxnNationalIDMap;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.ce.types.BatchHeaderDetails;
import com.misys.ce.types.BatchInfoDetails;
import com.misys.ce.types.BatchPosting;
import com.misys.fbe.common.util.CommonUtil;
import com.misys.ub.common.functions.UB_CMN_BatchUXEnhancementStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOAutoNumber;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_EnterpriseDetail;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FIN_FinancialGatewayHandler;

import bf.com.misys.ib.types.CustomerDueDetail;
import bf.com.misys.ib.types.CustomerDueDetailsList;
import bf.com.misys.ub.types.BatchUXEnhancementRq;
import bf.com.misys.ub.types.BatchUXEnhancementRs;
import bf.com.misys.ub.types.FinancialGatewayResponse;
import bf.com.misys.ub.types.Parameters;

public class FinancialGatewayHandler extends AbstractCE_FIN_FinancialGatewayHandler {

	private transient final static Log logger = LogFactory.getLog(FinancialGatewayHandler.class.getName());
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String MODE_GET_HEADER_DTLS = "GET_HEADER_DTLS";
	private static final String MODE_LOAD_TXN_DATA = "LOAD_TXN_DATA";
	private static final String MODE_SAVE_TXN_DATA = "SAVE_TXN_DATA";
	private static final String MODE_REMOVE_TXN_DATA = "REMOVE_TXN_DATA";
	private static final String MODE_GET_NATIONALID = "GET_NATIONALID";
	private static final String MODE_CREATE_BG_FILE = "CREATE_BG_FILE";
	private static final String MODE_UPDATE_BATCH_FILE_DTL = "UPDATE_BATCH_FILE_DTL";
	private static final String NATIONALID_WHERE_CLAUSE = "WHERE " + IBOCE_ADF_BatchTxnNationalIDMap.BATCHID + "=?";
	private static final String GET_TOTAL_AMNT = " SELECT SUM(CEAMOUNT) as TOTAL FROM CUSTOMEXTN.CETB_BATCHTXNDETAIL WHERE CEBATCHREF = ? AND CEPROCESSING = ? AND CESTATUS=?";

	public FinancialGatewayHandler(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		String mode = getF_IN_mode();
		logger.info("Mode for this call is : " + mode);
		switch (mode) {
		case MODE_GET_HEADER_DTLS:
			getHeaderDtls();
			break;

		case MODE_LOAD_TXN_DATA:
			loadTransactionDtl();
			break;

		case MODE_SAVE_TXN_DATA:
			saveTxnData();
			break;

		case MODE_REMOVE_TXN_DATA:
			removeTransaction();
			break;

		case MODE_GET_NATIONALID:
			getNationalId();
			break;

		case MODE_CREATE_BG_FILE:
			createBatchGatewayFile();
			break;

		case MODE_UPDATE_BATCH_FILE_DTL:
			updateFilenTxnDetails();
			break;

		}
	}

	private void createBatchGatewayFile() {
		System.err.println();
		String runningBalRecID = CommonConstants.EMPTY_STRING;
		BatchHeaderDetails header = getF_IN_header();
		IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, header.getBatchRef(), true);
		BigDecimal detailTblAmnt = getTotalAmountForBatch(header.getBatchRef());
		if (detailTblAmnt.compareTo(header.getAmountToBeProcessed()) > 0) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_AMOUNT_EXCEEDED);
		}
		if(header.getTxnType().equals(BatchCollectionConstants.TXN_TYPE_BANK)) {
			if(fileDtls.isF_ISLOADED()) {
				CommonUtil.handleUnParameterizedEvent(44000805);
			}
			fileDtls.setF_TXNTYPE(header.getTxnType());
			fileDtls.setF_BANKID(header.getBankID());
			fileDtls.setF_INTERNALACC(header.getInternalAcc());
			fileDtls.setF_AMNTTOPROCESS(header.getAmountToBeProcessed());
		}else {
			String TXN_CLAUSE = "WHERE "+IBOCE_BATCHTXNDETAIL.BATCHREF+"=? AND "+IBOCE_BATCHTXNDETAIL.INTERNALACC+"=? AND "+IBOCE_BATCHTXNDETAIL.AMOUNT+"=?";
			ArrayList params= new ArrayList<>();
			params.add(header.getBatchRefSearch());
			params.add(header.getInternalAcc());
			params.add(header.getAmountToBeProcessed());
			IBOCE_BATCHTXNDETAIL batchtxndetail= (IBOCE_BATCHTXNDETAIL) BankFusionThreadLocal.getPersistanceFactory().findFirstByQuery(IBOCE_BATCHTXNDETAIL.BONAME, TXN_CLAUSE, params, true);
			if(batchtxndetail!=null) {
				BigDecimal currentRunning = detailTblAmnt.add(batchtxndetail.getF_BATCHRUNNINGAMNT());
				if(currentRunning.compareTo(header.getAmountToBeProcessed())>CommonConstants.INTEGER_ZERO) {
					CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_AMOUNT_EXCEEDED);
				}
				runningBalRecID = batchtxndetail.getBoID();
			}
		}
		

		if (header.getProcessingStatus().equals(BatchCollectionConstants.BATCH_STATUS_PROCESSED)) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_RECORD_IS_PROCESSED);
		}

		/*if (StringUtils.isEmpty(posting.getActionOnBatchError())
				|| StringUtils.isEmpty(posting.getBatchGatewayPhases())) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_ACTION_N_PHASE_MANDATORY);
		}*/
		if (header.getTxnType().equals(BatchCollectionConstants.TXN_TYPE_GOVT)
				&& (StringUtils.isEmpty(header.getInternalAcc()) || StringUtils.isEmpty(header.getBatchRefSearch()))) {
			CommonUtil.handleParameterizedEvent(20016006, new String[] { "Internal Account and Batch Reference" });
		}
		BatchUXEnhancementRq batchUXEnhancementRq = new BatchUXEnhancementRq();
		batchUXEnhancementRq.setIsBatchResumable(false);
		batchUXEnhancementRq.setIsStatusRequired(true);
		batchUXEnhancementRq.setMicroflowID("CE_ADF_BatchCollectionBatch_SRV");
		Parameters parameters = new Parameters();
		parameters.setParamName("batchReference");
		parameters.setParamValue(header.getBatchRef());
		Parameters parameter1 = new Parameters();
		parameter1.setParamName("txnType");
		parameter1.setParamValue(header.getTxnType());
		Parameters parameter2 = new Parameters();
		parameter2.setParamName("debitAccForGovt");
		parameter2.setParamValue(header.getInternalAcc());
		
		Parameters parameter3 = new Parameters();
		parameter3.setParamName("runningBalRecID");
		parameter3.setParamValue(runningBalRecID);
		
		batchUXEnhancementRq.addParameters(0, parameters);
		batchUXEnhancementRq.addParameters(1, parameter1);
		batchUXEnhancementRq.addParameters(2, parameter2);
		batchUXEnhancementRq.addParameters(3, parameter3);
		//batchUXEnhancementRq.setUniqueBatchReference(ref);
		
		/*CustomFinancialGateway gateway = new CustomFinancialGateway();
		BatchUXEnhancementRq batchUXEnhancementRq = gateway.createBatchGatewayfile(header, posting);*/
		setF_OUT_outParam1(batchUXEnhancementRq);
		CommonUtil.handleUnParameterizedEvent(44000800);
	}

	private void updateFilenTxnDetails() {
		BatchHeaderDetails header = getF_IN_header();
		BatchUXEnhancementRq batchUBEnhance = (BatchUXEnhancementRq) getF_IN_inParam1();
		BatchPosting posting = (BatchPosting) getF_IN_inParam2();

		BatchUXEnhancementRs batchUXEnhancementRs = UB_CMN_BatchUXEnhancementStatus
				.run(batchUBEnhance.getUniqueBatchReference(), BankFusionThreadLocal.getBankFusionEnvironment());
		FinancialGatewayResponse financialGatewayResponse = (FinancialGatewayResponse) batchUXEnhancementRs
				.getBatchStatus();
		if (financialGatewayResponse!=null && financialGatewayResponse.isBatchStatus() && posting.getBatchGatewayPhases().equals("1")) {
			CustomFinancialGateway gateway = new CustomFinancialGateway();
			gateway.updateRecordStatus(financialGatewayResponse, header);
		}else {
			financialGatewayResponse = new FinancialGatewayResponse();
		}
		setF_OUT_outParam1(financialGatewayResponse);
	}

	private void getNationalId() {
		String id = "";
		String partyId = (String) getF_IN_inParam1();
		IBOPT_PFN_PersonalDetails personalParty = (IBOPT_PFN_PersonalDetails) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOPT_PFN_PersonalDetails.BONAME, partyId, true);
		if (personalParty != null) {
			id = personalParty.getF_NATIONALID();
		}else {
			IBOPT_PFN_EnterpriseDetail enterpriseDetail = (IBOPT_PFN_EnterpriseDetail) BankFusionThreadLocal
					.getPersistanceFactory().findByPrimaryKey(IBOPT_PFN_EnterpriseDetail.BONAME, partyId, true);
			id = enterpriseDetail.getF_REGISTEREDNUMBER();
		}
		setF_OUT_outParam1(id);
	}

	private void saveTxnData() {
		BatchInfoDetails batchInfo = (BatchInfoDetails) getF_IN_inParam1();
		BatchHeaderDetails batchHeader = getF_IN_header();
		String batchReference = batchHeader.getBatchRef();
		Date  currentDate =SystemInformationManager.getInstance().getBFBusinessDate();
		Calendar cal = Calendar.getInstance();
		cal.setTime(currentDate);
		int year = cal.get(Calendar.YEAR);
		if(batchReference.equals(CommonConstants.EMPTY_STRING)) {
			
			batchReference = BatchCollectionUtil.getNextSequence(year+"-");
		}
		validateData();
		String recId = batchInfo.getRecId();
		if (StringUtils.isEmpty(batchInfo.getRecId())) {
			IBOAutoNumber autoNumber= (IBOAutoNumber) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOAutoNumber.BONAME, "CETB_BATCHTXNDETAIL", true);
			int currentSeq = autoNumber.getF_IDVALUE()+1;
			recId = year+""+currentSeq;
			IBOCE_BATCHTXNDETAIL createObj = (IBOCE_BATCHTXNDETAIL) BankFusionThreadLocal.getPersistanceFactory()
					.getStatelessNewInstance(IBOCE_BATCHTXNDETAIL.BONAME);
			createObj.setF_AMOUNT(batchInfo.getAmount());
			createObj.setF_INTERNALACC(batchInfo.getInternalAccount());
			if (!StringUtils.isEmpty(batchInfo.getInternalAccount()))
				createObj.setF_BRANCHCD(batchInfo.getBranchCd());
			else
				createObj.setF_BRANCHCD("");
			createObj.setF_NATIONALID(batchInfo.getNationalId());
			createObj.setF_CREDITACC(batchInfo.getLoanAccount());
			createObj.setF_PROCESSING(batchInfo.getProcessInThisBatch());
			createObj.setF_VALUEDATE(batchInfo.getTxnDate());
			createObj.setF_VALUEDATEHIJRI(batchInfo.getTxnDateHijri());
			createObj.setF_NARRATIVE(batchInfo.getNarrative());
			createObj.setF_BATCHREF(batchReference);
			createObj.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_NEW);
			createObj.setF_PROCESSING(CommonConstants.Y);
			createObj.setF_BANKID(batchInfo.getPlaceholder());
			createObj.setF_CHEQUENO(batchInfo.getPlaceholder2());
			createObj.setF_PAYEENAME(batchInfo.getPlaceholder3());
			createObj.setF_CHEQUENUMBER(batchInfo.getChequeNumber());
			createObj.setF_CHEQUEDATE(batchInfo.getChequeDate().compareTo(new Date(0))<=0?null:batchInfo.getChequeDate());
			createObj.setF_MOFDOCDATE(batchInfo.getMOFDocDate().compareTo(new Date(0))<=0?null:batchInfo.getMOFDocDate());
			createObj.setF_MOFDOCNUMBER(batchInfo.getMOFDocNumber());
			createObj.setBoID(recId);
			BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_BATCHTXNDETAIL.BONAME, createObj);
			autoNumber.setF_IDVALUE(currentSeq);
		} else {
			IBOCE_BATCHTXNDETAIL updateObj = (IBOCE_BATCHTXNDETAIL) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOCE_BATCHTXNDETAIL.BONAME, batchInfo.getRecId(), true);
			updateObj.setF_AMOUNT(batchInfo.getAmount());
			updateObj.setF_INTERNALACC(batchInfo.getInternalAccount());
			if (!StringUtils.isEmpty(batchInfo.getInternalAccount()))
				updateObj.setF_BRANCHCD(batchInfo.getBranchCd());
			else
				updateObj.setF_BRANCHCD("");
			updateObj.setF_NATIONALID(batchInfo.getNationalId());
			updateObj.setF_CREDITACC(batchInfo.getLoanAccount());
			updateObj.setF_PROCESSING(batchInfo.getProcessInThisBatch());
			updateObj.setF_VALUEDATE(batchInfo.getTxnDate());
			updateObj.setF_VALUEDATEHIJRI(batchInfo.getTxnDateHijri());
			updateObj.setF_NARRATIVE(batchInfo.getNarrative());
			updateObj.setF_CHEQUENUMBER(batchInfo.getChequeNumber());
			updateObj.setF_CHEQUEDATE(batchInfo.getChequeDate().compareTo(new Date(0))<=0?null:batchInfo.getChequeDate());
			updateObj.setF_MOFDOCDATE(batchInfo.getMOFDocDate().compareTo(new Date(0))<=0?null:batchInfo.getMOFDocDate());
			updateObj.setF_MOFDOCNUMBER(batchInfo.getMOFDocNumber());
			updateObj.setF_BANKID(batchInfo.getPlaceholder());
			updateObj.setF_CHEQUENO(batchInfo.getPlaceholder2());
			updateObj.setF_PAYEENAME(batchInfo.getPlaceholder3());
		}
		if(batchInfo.getNationalId()!=null && !batchInfo.getNationalId().isEmpty()) {
			ArrayList params = new ArrayList<>();
			params.add(recId);
			BankFusionThreadLocal.getPersistanceFactory().bulkDelete(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, NATIONALID_WHERE_CLAUSE, params );
			CustomerDueDetailsList customerDueDetailsList= ((CustomerDueDetailsList)getF_IN_inParam3());
			for (CustomerDueDetail customerDueDetails : customerDueDetailsList.getCustomerDueDetails()) {
				IBOCE_ADF_BatchTxnNationalIDMap createObj = (IBOCE_ADF_BatchTxnNationalIDMap) BankFusionThreadLocal.getPersistanceFactory()
						.getStatelessNewInstance(IBOCE_ADF_BatchTxnNationalIDMap.BONAME);
				createObj.setF_BATCHID(recId);
				createObj.setF_DUEAMOUNT(customerDueDetails.getDueAmount().getCurrencyAmount());
				createObj.setF_DUEAMOUNTPAID(customerDueDetails.getDueAmountPaid().getCurrencyAmount());
				createObj.setF_DUEDATE(customerDueDetails.getDueDate());
				createObj.setF_LOANACCOUNTID(customerDueDetails.getDealAccountID());
				createObj.setF_PROCESS(customerDueDetails.getProcess());
				createObj.setF_ROLE(customerDueDetails.getUserRole());
				BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_ADF_BatchTxnNationalIDMap.BONAME, createObj);
			}
		}
		IBOCE_BATCHFILEDETAIL updateHeader = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, batchHeader.getBatchRef(), true);
		if(updateHeader!=null) {
			updateHeader.setF_BATCHDES(batchHeader.getBatchDesc());
			if(updateHeader.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_BANK)&& !updateHeader.isF_ISLOADED()) {
				updateHeader.setF_BANKID(batchHeader.getBankID());
				updateHeader.setF_INTERNALACC(batchHeader.getInternalAcc());
			}
			
			//updateHeader.setF_TXNTYPE(batchHeader.getTxnType());
			//updateHeader.setF_AMNTTOPROCESS(batchHeader.getAmountToBeProcessed());
		}else {
			IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory().getStatelessNewInstance(IBOCE_BATCHFILEDETAIL.BONAME);
			fileDtls.setBoID(batchReference);
			fileDtls.setF_FILENAME("");
			fileDtls.setF_BATCHREF(batchReference);
			fileDtls.setF_BANKID(batchHeader.getBankID());
			fileDtls.setF_BATCHDES(batchHeader.getBatchDesc());
			fileDtls.setF_TXNTYPE(batchHeader.getTxnType());
			fileDtls.setF_INTERNALACC(batchHeader.getInternalAcc());
			fileDtls.setF_AMNTTOPROCESS(batchHeader.getAmountToBeProcessed());
			fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_NEW);
			fileDtls.setF_RECCREATEDON(SystemInformationManager.getInstance().getBFBusinessDateTime());
			fileDtls.setF_RECCREATEDBY(BankFusionThreadLocal.getBankFusionEnvironment().getUserSession().getUserId());
			BankFusionThreadLocal.getPersistanceFactory().create(IBOCE_BATCHFILEDETAIL.BONAME, fileDtls);
		}
		getF_IN_header().setBatchRef(batchReference);
		setF_OUT_header(getF_IN_header());
		CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_WARN_DB_UPDATES);
	}

	private void validateData() {

		BatchInfoDetails batchInfo = (BatchInfoDetails) getF_IN_inParam1();
		BatchHeaderDetails batchHeader = getF_IN_header();
		if (batchInfo.getProcessInThisBatch().equals("N")) {
			return;
		}
		if (batchInfo.getStatus().equals(BatchCollectionConstants.BATCH_STATUS_PROCESSED)) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_RECORD_IS_PROCESSED);
		}

		BigDecimal detailTblAmnt = getTotalAmountForBatch(batchHeader.getBatchRef());
		BigDecimal totalAmnt = detailTblAmnt.add(batchInfo.getAmount());
		if (StringUtils.isEmpty(batchInfo.getRecId())) {
			if (totalAmnt.compareTo(batchHeader.getAmountToBeProcessed()) > 0) {
				CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_AMOUNT_EXCEEDED);
			}
		} else {
			if ((totalAmnt.subtract(getOldAmount(batchInfo.getRecId())))
					.compareTo(batchHeader.getAmountToBeProcessed()) > 0) {
				CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_AMOUNT_EXCEEDED);
			}
		}
		int internalACc = StringUtils.isEmpty(batchInfo.getInternalAccount()) ? 0 : 1;
		int loanAcc = StringUtils.isEmpty(batchInfo.getLoanAccount()) ? 0 : 1;
		int nationalId = StringUtils.isEmpty(batchInfo.getNationalId()) ? 0 : 1;
		if (internalACc + loanAcc + nationalId != 1) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_SELECT_ONE_ACCOUNT_ONLY);
		}
		String accountID = CommonConstants.EMPTY_STRING;
		String nationalID = CommonConstants.EMPTY_STRING;
		if(!batchInfo.getInternalAccount().isEmpty()) {
			accountID = batchInfo.getInternalAccount();
			
		}else if(!batchInfo.getLoanAccount().isEmpty()) {
			accountID = batchInfo.getLoanAccount();
		}else {
			nationalID = batchInfo.getNationalId();
		}
		if(!accountID.isEmpty()) {
			if(FinderMethods.getAccountBO(accountID)==null)
				CommonUtil.handleUnParameterizedEvent(40310264);
		}else {
			String FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_PersonalDetails.NATIONALIDTYPEID + " = ? AND "
					+ IBOPT_PFN_PersonalDetails.NATIONALID + " = ? ";
			String partyID = CommonConstants.EMPTY_STRING;
			ArrayList qParams = new ArrayList();
			qParams.add("NATIONAL_ID_001");
			qParams.add(nationalID);
			IBOPT_PFN_PersonalDetails personalDtl = (IBOPT_PFN_PersonalDetails) BankFusionThreadLocal
					.getPersistanceFactory()
					.findFirstByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_CUSTOMERID, qParams, true);
			if (personalDtl != null) {
				partyID = personalDtl.getBoID();
			} else {
				FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_EnterpriseDetail.REGISTEREDNUMBER + " = ? ";
				qParams.clear();
				qParams.add(nationalID);
				IBOPT_PFN_EnterpriseDetail enterpriseDetail = (IBOPT_PFN_EnterpriseDetail) BankFusionThreadLocal
						.getPersistanceFactory()
						.findFirstByQuery(IBOPT_PFN_EnterpriseDetail.BONAME, FIND_CUSTOMERID, qParams, true);
				if (enterpriseDetail != null) {
					partyID = enterpriseDetail.getBoID();
				}
			}
			if (partyID.isEmpty())
				CommonUtil.handleUnParameterizedEvent(44000463);
		}
		if (batchHeader.getTxnType().equals(BatchCollectionConstants.TXN_TYPE_GOVT)
				&& (StringUtils.isEmpty(batchHeader.getInternalAcc())
						|| StringUtils.isEmpty(batchHeader.getBatchRefSearch()))) {
			CommonUtil.handleParameterizedEvent(20016006, new String[] { "Internal Account and Batch Reference" });
		}
		if(StringUtils.isEmpty(batchInfo.getProcessInThisBatch())) {
			//BatchCollectionConstants.EVT_PROCESS_IN_BATCH_EMPTY
			CommonUtil.handleUnParameterizedEvent(44000459);
		}
	}

	private void removeTransaction() {
		setF_OUT_header(getF_IN_header());
		VectorTable vt = (VectorTable) getF_IN_inParam1();
		for (int i = 0; i < vt.size(); ++i) {
			HashMap row = vt.getRowTags(i);
			if ((Boolean) row.get(CommonConstants.SELECT)) {
				if (((String) row.get(BatchCollectionConstants.GRID_KEY_STATUS))
						.equals(BatchCollectionConstants.BATCH_STATUS_PROCESSED)) {
					CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_RECORD_IS_PROCESSED);
				} else {
					CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_WARN_DB_UPDATES);
					String key = (String) row.get(CommonConstants.BOID);
					BankFusionThreadLocal.getPersistanceFactory().remove(IBOCE_BATCHTXNDETAIL.BONAME, key, true);
				}
			}
		}
	}

	private void loadTransactionDtl() {
		BatchHeaderDetails header = getF_IN_header();
		if (header != null && header.getProcessingStatus().equals(BatchCollectionConstants.BATCH_STATUS_PROCESSED)) {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_RECORD_IS_PROCESSED);
		}
		VectorTable vt = (VectorTable) getF_IN_inParam1();
		BatchInfoDetails batchInfo = new BatchInfoDetails();
		if (vt.size() == 0) {
			batchInfo.setProcessInThisBatch(CommonConstants.Y);
			batchInfo.setTxnDate(header.getBatchUploadDate()!=null&&header.getBatchUploadDate().compareTo(new Date(0))!=0?header.getBatchUploadDate():SystemInformationManager.getInstance().getBFBusinessDate());
			batchInfo.setStatus(BatchCollectionConstants.BATCH_STATUS_NEW);
			batchInfo.setTxnDateHijri(
					BatchCollectionUtil.getHijriDate(batchInfo.getTxnDate()));
			batchInfo.setMOFDocDate(null);
			batchInfo.setChequeDate(null);
		}
		for (int i = 0; i < vt.size(); ++i) {
			HashMap row = vt.getRowTags(i);
			if ((Boolean) row.get(CommonConstants.SELECT)) {
				batchInfo.setAmount((BigDecimal) row.get("AMOUNT"));
				batchInfo.setBranchCd((String) row.get("BRANCHCD"));
				batchInfo.setInternalAccount((String) row.get("INTERNALACC"));
				batchInfo.setLoanAccount((String) row.get("CREDITACC"));
				batchInfo.setNarrative((String) row.get("NARRATIVE"));
				batchInfo.setNationalId((String) row.get("NATIONALID"));
				batchInfo.setTxnDate((Date) row.get("VALUEDATE"));
				batchInfo.setTxnDateHijri((String) row.get("VALUEDATEHIJRI"));
				batchInfo.setRecId((String) row.get("BOID"));
				batchInfo.setProcessInThisBatch((String) row.get("PROCESSDESC"));
				batchInfo.setStatus((String) row.get("STATUS"));
				batchInfo.setGatewayRef((String) row.get("BATCHGWREF"));
				batchInfo.setPlaceholder((String) row.get("BANKID"));
				batchInfo.setPlaceholder2((String) row.get("CHEQUENO"));
				batchInfo.setPlaceholder3((String) row.get("PAYEENAME"));
				batchInfo.setMOFDocDate((Date) row.get("MOFDOCDATE"));
				batchInfo.setMOFDocNumber((String) row.get("MOFDOCNUMBER"));
				batchInfo.setChequeDate((Date) row.get("CHEQUEDATE"));
				batchInfo.setChequeNumber((String) row.get("CHEQUENUMBER"));
			}

		}
		setF_OUT_outParam1(batchInfo);
	}

	private void getHeaderDtls() {
		BatchHeaderDetails header = new BatchHeaderDetails();
		String batchRef = (String) getF_IN_inParam1();
		String purpose = (String) getF_IN_inParam2();
		VectorTable result = (VectorTable) getF_IN_inParam3();
		
		IBOCE_BATCHFILEDETAIL headerDtls = (IBOCE_BATCHFILEDETAIL) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOCE_BATCHFILEDETAIL.BONAME, batchRef, true);
		if (headerDtls != null) {
			header.setAmountToBeProcessed(BatchCollectionUtil.getScaledAmount(headerDtls.getF_AMNTTOPROCESS()));
			header.setBankID(headerDtls.getF_BANKID());
			header.setBatchDesc(headerDtls.getF_BATCHDES());
			header.setBatchFileName(headerDtls.getF_FILENAME());
			header.setBatchRef(headerDtls.getF_BATCHREF());
			header.setInternalAcc(headerDtls.getF_INTERNALACC());
			header.setProcessingStatus(headerDtls.getF_STATUS());
			header.setTxnType(headerDtls.getF_TXNTYPE());
			Date date = new java.sql.Date(headerDtls.getF_RECCREATEDON().getTime());
			//Date date = headerDtls.getF_RECCREATEDON().toLocalDateTime();
			header.setBatchUploadDate(date);
			String txnType = headerDtls.getF_TXNTYPE();
			if (headerDtls.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_BANK)) {
				if (purpose.equals("P")) {
					txnType = BatchCollectionConstants.TXN_TYPE_GOVT;
					header.setTxnType(txnType);
					header.setBankID(CommonConstants.EMPTY_STRING);
					header.setBatchRefSearch(headerDtls.getF_BATCHREF());
					if (result.size() == 1) {
						BigDecimal amount = BigDecimal.ZERO;
						for (int i = 0; i < result.size(); i++) {
							HashMap row = result.getRowTags(i);
							amount = amount.add((BigDecimal) row.get("AMOUNT"));
						}
						header.setAmountToBeProcessed(amount);
					}
				}
			}
			if(StringUtils.isEmpty(txnType))
			{
				header.setShowBankId(true);
				header.setShowInternalAcc(true);
			}
			else
			{
				header.setShowBankId(
						txnType.equals(BatchCollectionConstants.TXN_TYPE_BANK) ? true : false);
				header.setShowInternalAcc(
						txnType.equals(BatchCollectionConstants.TXN_TYPE_GOVT) ? true : false);
			}
		}
		setF_OUT_header(header);
	}

	private BigDecimal getTotalAmountForBatch(String batchRef) {
		BigDecimal totalAmnt = new BigDecimal(0);
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			stmt = BankFusionThreadLocal.getPersistanceFactory().getJDBCConnection().prepareStatement(GET_TOTAL_AMNT);
			stmt.setString(1, batchRef);
			stmt.setString(2, "Y");
			stmt.setString(3, "NEW");
			rs = stmt.executeQuery();
			if (rs.next()) {
				totalAmnt = rs.getBigDecimal(1);
			}
		} catch (SQLException e) {
			logger.error(e);
		} finally {
			BatchCollectionUtil.close(stmt);
			BatchCollectionUtil.close(rs);
		}
		return totalAmnt==null ? BigDecimal.ZERO : totalAmnt ;
	}

	private BigDecimal getOldAmount(String recId) {
		BigDecimal oldAmnt = null;
		VectorTable vt = (VectorTable) getF_IN_inParam2();
		for (int i = 0; i < vt.size(); ++i) {
			HashMap row = vt.getRowTags(i);
			if (((String) row.get("BOID")).equals(recId)) {
				oldAmnt = (BigDecimal) row.get("AMOUNT");
			}
		}
		return oldAmnt;
	}

}
