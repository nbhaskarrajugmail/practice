package com.ce.financialgateway.restservice;

import java.math.BigDecimal;

public class CurrencyAmount {
	String currency;
	BigDecimal amount;
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	
	
}
