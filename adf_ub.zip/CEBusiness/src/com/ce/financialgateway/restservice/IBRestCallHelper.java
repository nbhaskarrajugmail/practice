package com.ce.financialgateway.restservice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.ce.financialgateway.BatchCollectionConstants;
import com.ce.financialgateway.CustomFinancialGateway;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.fbe.common.util.CommonUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PersonalDetails;

public class IBRestCallHelper {
	Log logger = LogFactory.getLog(CustomFinancialGateway.class.getName());
	private static final String GET_CUST_LIABILITIES = "bfweb/retail/service/ce/ib/getCustomerLiabilityDetail/";
	String baseUrl = BankFusionPropertySupport.getProperty("IB_HOST_URL", "http://localhost:8080");

	String FIND_CUSTOMERID = " WHERE " + IBOPT_PFN_PersonalDetails.NATIONALIDTYPEID + " = ? AND "
			+ IBOPT_PFN_PersonalDetails.NATIONALID + " = ? ";

	
	public CustomerLiabilityRs getCustomerLiabilities(String nationalId) {
		CustomerLiabilityRs liabilities = new CustomerLiabilityRs();
		ArrayList qParams = new ArrayList();
		qParams.add("NATIONAL_ID_001");
		qParams.add(nationalId);
		IBOPT_PFN_PersonalDetails personalDtl = (IBOPT_PFN_PersonalDetails) BankFusionThreadLocal
				.getPersistanceFactory()
				.findFirstByQuery(IBOPT_PFN_PersonalDetails.BONAME, FIND_CUSTOMERID, qParams, true);
		if (personalDtl != null) {
			final String url = baseUrl + "/" + GET_CUST_LIABILITIES + "/" + personalDtl.getBoID();
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			headers.setBearerAuth(BankFusionThreadLocal.getUserLocator().getStringRepresentation());
			Map<String, String> params = new HashMap<String, String>();
			params.put("customerId", personalDtl.getBoID());
			HttpEntity<String> request = new HttpEntity<String>(headers);
			ResponseEntity<String> response = null;
			try {
				response = restTemplate.exchange(url, HttpMethod.GET, request, String.class, params);
			} catch (HttpStatusCodeException e) {
				logger.error(e.getMessage(), e);
				logger.error(e.getResponseBodyAsString());
			}
			if (response.getStatusCode().equals(HttpStatus.OK)) {
				Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd hh:mm:ss").create();
				liabilities = gson.fromJson(response.getBody(), CustomerLiabilityRs.class);
			}
		}else {
			CommonUtil.handleUnParameterizedEvent(BatchCollectionConstants.EVT_INVALID_NATIONALID);
		}
		return liabilities;
	}
}
