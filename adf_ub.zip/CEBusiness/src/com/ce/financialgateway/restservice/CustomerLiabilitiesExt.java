package com.ce.financialgateway.restservice;

import java.sql.Date;

public class CustomerLiabilitiesExt extends CustomerLiabilities {

	Date duedate;

	public Date getDuedate() {
		return duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}
	
}
