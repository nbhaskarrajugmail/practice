package com.ce.financialgateway.restservice;

import java.util.ArrayList;

public class CustomerLiabilityRs {

	ArrayList<CustomerLiabilitiesExt> liabilities ;

	public ArrayList<CustomerLiabilitiesExt> getLiabilities() {
		return liabilities;
	}

	public void setLiabilities(ArrayList<CustomerLiabilitiesExt> liabilities) {
		this.liabilities = liabilities;
	}
	
}
