package com.ce.financialgateway.restservice;

public class CustomerLiabilities {

    

    String userRole;
    String userRoleID;
	CurrencyAmount liabilityAmount;
    CurrencyAmount liabilityToBePaid;
    String dealId;
    String dealAccountID;
    public String getUserRoleID() {
		return userRoleID;
	}
	public void setUserRoleID(String userRoleID) {
		this.userRoleID = userRoleID;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public CurrencyAmount getLiabilityAmount() {
		return liabilityAmount;
	}
	public void setLiabilityAmount(CurrencyAmount liabilityAmount) {
		this.liabilityAmount = liabilityAmount;
	}
	public CurrencyAmount getLiabilityToBePaid() {
		return liabilityToBePaid;
	}
	public void setLiabilityToBePaid(CurrencyAmount liabilityToBePaid) {
		this.liabilityToBePaid = liabilityToBePaid;
	}
	public String getDealId() {
		return dealId;
	}
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}
	public String getDealAccountID() {
		return dealAccountID;
	}
	public void setDealAccountID(String dealAccountID) {
		this.dealAccountID = dealAccountID;
	}

}