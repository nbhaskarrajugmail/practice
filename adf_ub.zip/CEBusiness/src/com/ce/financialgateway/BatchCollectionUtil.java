package com.ce.financialgateway;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.service.ServiceManager;
import com.misys.bankfusion.subsystem.infrastructure.IAutoNumberService;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.core.BFCurrencyValue;

public class BatchCollectionUtil {

	public static String getNextSequence(String batchPreFix) {
		String id = CommonConstants.EMPTY_STRING;
		String key;
		if (batchPreFix.equals(BatchCollectionConstants.BATCH_GATEWAY_PREFIX)) {
			key = BatchCollectionConstants.GATEWAY_REF;
		} else {
			key = IBOCE_BATCHFILEDETAIL.BONAME;
		}
//		id = CB_CMN_AutoNumber.run(key, BankFusionThreadLocal.getBankFusionEnvironment());
		IAutoNumberService autoNumSrvc = (IAutoNumberService) ServiceManager.getService("AutoNumberService");
		id = autoNumSrvc.getNextId(key, CommonConstants.EMPTY_STRING, CommonConstants.EMPTY_STRING);
		if (id == null) {
			return GUIDGen.getNewGUID();
		}
		return batchPreFix + id.trim();
	}
	
	public static BigDecimal getScaledAmount(BigDecimal amount) {
		if (amount == null)
			amount = CommonConstants.BIGDECIMAL_ZERO;

		BFCurrencyValue scaledAmount = new BFCurrencyValue(BatchCollectionConstants.DEFAULT_CURRENCY, amount,
				BankFusionThreadLocal.getUserId());
		return scaledAmount.getRoundedAmount();
	}
	
	public static void close(ResultSet obj) {
		try {
			obj.close();
		} catch (Exception e) {
		}
	}

	public static void close(PreparedStatement obj) {
		try {
			obj.close();
		} catch (Exception e) {
		}
	}
	
	
	public static String getHijriDate(Date inputDate1) {
		 Date inputDate = new Date();
		 inputDate.setDate(inputDate1.getDate());
		 inputDate.setMonth(inputDate1.getMonth());
		 inputDate.setYear(inputDate1.getYear());
		 LocalDate localDate = inputDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		 HijrahDate hdate = HijrahChronology.INSTANCE.date(LocalDate.of(localDate.getYear(), localDate.getMonth(), localDate.getDayOfMonth()));
		 DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		 return hdate.format(FOMATTER);
	}
}
