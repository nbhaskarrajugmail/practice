
package com.ce.financialgateway;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.StringUtils;

import com.finastra.openapi.common.utils.CommonApiUtil;
import com.misys.bankfusion.clearing.common.ClearingUtil;
import com.misys.bankfusion.common.BankFusionMessages;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.util.DateUtils;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;
import com.misys.cbs.config.ModuleConfiguration;
import com.misys.fbe.uploadfile.FileUploadHandler;
import com.trapedza.bankfusion.bo.refimpl.IBOAutoNumber;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHFILEDETAIL;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.servercommon.services.autonumber.IAutoNumberService;


public class UploadDocument extends FileUploadHandler {

	Log logger = LogFactory.getLog(UploadDocument.class);
	
	ClearingUtil utils = new ClearingUtil();

	SimpleDateFormat fileDateFormar = new SimpleDateFormat("dd/MM/yyyy");
	private final static String DUPLICATE_FILE_QUERY = " WHERE " + IBOCE_BATCHFILEDETAIL.FILENAME + " = ? ";
	String batchReference = "";
	String message;
	
	@Override
	public HashMap<String, String> uploadFileData(byte[] fileByteArray) {
		HashMap<String, String> response = new HashMap();
		HashMap<String, Object> formData = getRequestData();
		String docUpload = (String) formData.get(BatchCollectionConstants.DOC_UPLOAD_MODE);
		if ((fileByteArray.length != 0) && (null != docUpload)) {
			copyFileInMessageGatewayFolder(fileByteArray, response);
			return response;
		}
		return super.uploadFileData(fileByteArray);
	}
	
	private void copyFileInMessageGatewayFolder(byte[] fileByteArray, HashMap<String, String> response) {
		Boolean success = false;
		String fileext = getFileExtn();
		String fileName = getFileName();
		CommonApiUtil.setBankFusionEnvironment();
		message = utils.getEventMessage(BatchCollectionConstants.EVT_UPLOAD_FAILED);
		if(isDuplicateFile(fileName)) {
			message = utils.getEventMessage(BatchCollectionConstants.EVT_DUPLICATE_FILE);
		}else {
			String dateForlderName = DateUtils.dateFormatter
					.format(SystemInformationManager.getInstance().getBFBusinessDate());
			String fileLocation = (String) ModuleConfiguration.getInstance().getModuleConfigurationValue("BAT", "BatchInfo.fileLocation");
			try {
				if (fileext.toUpperCase().equals("CSV") || fileext.toUpperCase().equals("XLSX")) {
					String file = fileLocation + File.separator + dateForlderName + File.separator + fileName;
					File newFile = new File(file);
					FileUtils.writeByteArrayToFile(newFile, fileByteArray);
					if (newFile.getName().toUpperCase().endsWith(".CSV")) {
						success = importCsvFile(newFile);
					} else {
						success = importxlsxFile(newFile);
					}
				} else {
					message = utils.getEventMessage(BatchCollectionConstants.EVT_FORMAT_NOT_SUPORTED);
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
		if(success)
			response.put("uploaded", success.toString());
		response.put("fileReference", success ? batchReference: "");
		response.put("fileID", success ?  getEventMessage(BatchCollectionConstants.EVT_UPLOADED_SUCCESS, new String[] {batchReference}) : message);
	}
	
	private boolean isDuplicateFile(String fileName) {
		CB_CMN_PrivateSession session = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory factory = session.createSession();
		try {
			factory.beginTransaction();
			ArrayList params = new ArrayList();
			params.add(fileName);
			List<IBOCE_BATCHFILEDETAIL> listOfFiles = factory.findByQuery(IBOCE_BATCHFILEDETAIL.BONAME, DUPLICATE_FILE_QUERY , params, null, true);
			if(listOfFiles!=null && !listOfFiles.isEmpty())
			{
				return true;
			}
		}finally {
			factory.commitTransaction();
			factory.closePrivateSession();
		}
		return false;
	}
	
	private Boolean importCsvFile(File f) throws IOException {
		BufferedReader fileReader = null;
		final String DELIMITER = ",";
		try {
			fileReader = new BufferedReader(new FileReader(f));
			String line = "";
			while ((line = fileReader.readLine()) != null) 
            {
                String[] tokens = line.split(DELIMITER);
                for(String token : tokens)
                {
                    System.out.println(token);
                }
            }
		} finally {
			fileReader.close();
		}
		return true;
	}
	
	private String getCellAsString(Row row, int idx) {
		Cell c = null;
		if(row.getCell(idx)==null) {
			c = row.createCell(idx);
			
		}else {
			c = row.getCell(idx);
		}
		c.setCellType(CellType.STRING);
		return c.getStringCellValue();
	}
	
	private boolean importxlsxFile(File f) throws Exception  {
		Boolean status = false;
		CB_CMN_PrivateSession session = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory factory = session.createSession();
		XSSFWorkbook wb = null;
		try {
			Date  currentDate =SystemInformationManager.getInstance().getBFBusinessDate();
			Calendar cal = Calendar.getInstance();
			cal.setTime(currentDate);
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH)+1;
			int date = cal.get(Calendar.DATE);
			batchReference = BatchCollectionUtil.getNextSequence(year+"-");
			//BatchCollectionConstants.BATCH_REF_PREFIX+CB_CMN_AutoNumber.run(IBOCE_BATCHFILEDETAIL.BONAME, BankFusionThreadLocal.getBankFusionEnvironment());
			factory.beginTransaction();
			OPCPackage pkg = OPCPackage.open(f);
			wb = new XSSFWorkbook(pkg);
			XSSFSheet sheet = wb.getSheetAt(0);
			int columnNamesRowNo = 1;
			IBOAutoNumber autoNumber= (IBOAutoNumber) factory.findByPrimaryKey(IBOAutoNumber.BONAME, "CETB_BATCHTXNDETAIL", true);
			int currentSeq = autoNumber.getF_IDVALUE();
			if(month==1 && date==1)
				currentSeq = 0;
			
			for(Row row: sheet) {
				if(row.getRowNum()==0) {
					String headerDetails = getCellAsString(row, row.getRowNum());
					if(null != headerDetails && !headerDetails.contains(","))
						columnNamesRowNo =0;
					status = createHeaderEntries(factory, headerDetails, f.getName());
					if(!status.booleanValue())
						return false;
					continue;
				}
				
				if(row.getRowNum()==columnNamesRowNo)
					continue;
				
				if(StringUtils.isEmpty(getCellAsString(row, 10)))
				    continue;
				
				IBOCE_BATCHTXNDETAIL txnDtls = (IBOCE_BATCHTXNDETAIL) factory.getStatelessNewInstance(IBOCE_BATCHTXNDETAIL.BONAME);
				txnDtls.setF_BATCHREF(batchReference);
				int colIdx = 1;
				
				txnDtls.setF_BANKID(getCellAsString(row, colIdx++));
				txnDtls.setF_INTERNALACC(getCellAsString(row, colIdx++));
				txnDtls.setF_BRANCHCD(getCellAsString(row, colIdx++));
				txnDtls.setF_CHEQUENO(getCellAsString(row, colIdx++));
				txnDtls.setF_NATIONALID(getCellAsString(row, colIdx++));
				txnDtls.setF_TXNREF(getCellAsString(row, colIdx++));
				txnDtls.setF_TXNDATE(getDateObject(getCellAsString(row, colIdx++)));
				txnDtls.setF_CREDITACC(getCellAsString(row, colIdx++));
				String amnt = getCellAsString(row, colIdx++).replace(",","");
				txnDtls.setF_AMOUNT(!StringUtils.isEmpty(amnt) ? new BigDecimal(amnt) : new BigDecimal(0));
				if(!StringUtils.isEmpty(txnDtls.getF_INTERNALACC())) {
					txnDtls.setF_BATCHRUNNINGAMNT(!StringUtils.isEmpty(amnt) ? new BigDecimal(amnt) : new BigDecimal(0));
				}
				String narrative = getCellAsString(row, colIdx++);
				txnDtls.setF_NARRATIVE(narrative);
				txnDtls.setF_VALUEDATEHIJRI(getCellAsString(row, colIdx++));
				txnDtls.setF_VALUEDATE(getDateObject(getCellAsString(row, colIdx++)));
				txnDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_NEW);
				txnDtls.setF_PROCESSING(CommonConstants.EMPTY_STRING);
				txnDtls.setF_CHEQUEDATE(null);
				txnDtls.setF_MOFDOCDATE(null);
				if(!(narrative.contains("SPAN")||(narrative.contains("BLLR")))) {
					currentSeq++;
			        txnDtls.setBoID(year+""+currentSeq);
			        factory.create(IBOCE_BATCHTXNDETAIL.BONAME, txnDtls);
				}else {
					logger.info("Record is already processed through Sadad, no need for Batch Upload");
				}
			}
			autoNumber.setF_IDVALUE(currentSeq);
			factory.commitTransaction();
		} catch (Exception e) {
			factory.rollbackTransaction();
			throw e;
		} finally {
			factory.closePrivateSession();
			wb.close();
		}
		return true;
	}
	
	
	
	private Date getDateObject(String dt) {
		java.util.Date dtObj = new Date(0);
		try {
			dtObj = fileDateFormar.parse(dt);
		} catch (ParseException e) {
			logger.error("Error in parsing date [] " + dt);
			dtObj = SystemInformationManager.getInstance().getBFBusinessDate();
		}
		return new Date(dtObj.getTime());
		
	}
	
	private Boolean createHeaderEntries(IPersistenceObjectsFactory factory, String headerString, String fileName) { //, BatchHeaderDetails hdrDetail
		IBOCE_BATCHFILEDETAIL fileDtls = (IBOCE_BATCHFILEDETAIL) factory.getStatelessNewInstance(IBOCE_BATCHFILEDETAIL.BONAME);
		fileDtls.setBoID(batchReference);
		fileDtls.setF_FILENAME(fileName);
		fileDtls.setF_BATCHREF(batchReference);
		String[] hdr = headerString.split(",");
		for(String token : hdr) {
			String[] dtls = token.split("=");
			if(dtls.length>=2) {
				switch (dtls[0].toString().trim().toUpperCase()) {
					case BatchCollectionConstants.HDR_TRANSACTIONTYPE :
						fileDtls.setF_TXNTYPE(dtls[1].trim());
						break;
						
					case BatchCollectionConstants.HDR_INTERNALACCOUNT :
						fileDtls.setF_INTERNALACC(dtls[1].trim());
						break;		

					case BatchCollectionConstants.HDR_BANKID :
						fileDtls.setF_BANKID(dtls[1].trim());
						break;	
						
					case BatchCollectionConstants.HDR_AMOUNTTOBEPROCESSED :
						fileDtls.setF_AMNTTOPROCESS(new BigDecimal(dtls[1].trim()));
						break;	
				}
			}
		}
		/*if(StringUtils.isEmpty(fileDtls.getF_TXNTYPE()) || !(fileDtls.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_BANK) 
				|| fileDtls.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_GOVT))) {
			message = utils.getEventMessage(BatchCollectionConstants.EVT_HEADER_ERROR);
			return false;
		}*/
		if(fileDtls.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_BANK)) {
			fileDtls.setF_INTERNALACC("");
		}else if(fileDtls.getF_TXNTYPE().equals(BatchCollectionConstants.TXN_TYPE_GOVT)) {
			fileDtls.setF_BANKID("");
			fileDtls.setF_AMNTTOPROCESS(new BigDecimal(0));
		}
		fileDtls.setF_STATUS(BatchCollectionConstants.BATCH_STATUS_NEW);
		fileDtls.setF_RECCREATEDON(SystemInformationManager.getInstance().getBFBusinessDateTime());
		fileDtls.setF_RECCREATEDBY(BankFusionThreadLocal.getBankFusionEnvironment().getUserSession().getUserId());
		factory.create(IBOCE_BATCHFILEDETAIL.BONAME, fileDtls);
		return true;
	}
	
	
	   public String getEventMessage(int eventNumber, String[] stringParams) {
			String  params = Arrays.asList(stringParams).toString().replace("[", "").replace("]", "");
		   return BankFusionMessages.getInstance().getFormattedEventMessage(eventNumber, new Object[]{params}, BankFusionThreadLocal.getUserSession().getUserLocale());
	   }
	
}
