package com.ce.financialgateway;

public class BatchCollectionConstants {

	public static final  String HDR_TRANSACTIONTYPE = "TRANSACTIONTYPE";
	public static final  String HDR_INTERNALACCOUNT = "INTERNALACCOUNT";
	public static final  String HDR_BANKID = "BANKID";
	public static final  String HDR_AMOUNTTOBEPROCESSED = "AMOUNTTOBEPROCESSED";
	
	public static final  String TXN_TYPE_BANK = "BANK";
	public static final  String TXN_TYPE_GOVT = "GOVT";
	
	public static final  String SHEETNAME = "BatchFile";
	
	public static final  String BATCH_REF_PREFIX = "BATCH";
	public static final  String BATCH_GATEWAY_PREFIX = "GATWEAY";
	public static final  String DOC_UPLOAD_MODE = "FIN_GATEWAY";
	public static final  String GATEWAY_REF = "GatewayBatchRef";
	
	
	
	public static final  String BRANCH_ALL = " ";
	public static final  String BATCH_STATUS_NEW = "NEW";
	public static final  String BATCH_STATUS_PROCESSED = "PROCESSED";
	public static final  String BATCH_STATUS_PARTPROCESSED = "PARTPROCESSED";
	
	public static final  String BATCH_STATUS_UNPROCESSED = "UNPROCESSED";
	
	public static final  String GRID_KEY_STATUS = "STATUS";
	public static final  String GRID_KEY_BOID = "BOID";
	public static final  String DEFAULT_CURRENCY = "SAR";
	
	public static final  String IDTYPE_NATIONALID = "NATIONAL_ID_001";
	
	
	public static final  int EVT_FORMAT_NOT_SUPORTED = 97500099;
	public static final  int EVT_UPLOADED_SUCCESS = 44009001;
	public static final  int EVT_UPLOAD_FAILED = 40112762;
	public static final  int EVT_DUPLICATE_FILE = 35100510;
	
	public static final  int EVT_HEADER_ERROR = 44009003;
	public static final  int EVT_ACTION_N_PHASE_MANDATORY = 44009006;
	public static final  int EVT_WARN_DB_UPDATES = 44009004;
	public static final  int EVT_RECORD_IS_PROCESSED = 44009007;
	public static final  int EVT_AMOUNT_EXCEEDED = 44009005;
	public static final  int EVT_SELECT_ONE_ACCOUNT_ONLY = 44009002;
	public static final  int EVT_INVALID_NATIONALID = 44009008;
	public static final  int EVT_PROCESS_IN_BATCH_EMPTY = 44000459;
	
	
	
	
	
}
