package com.ce.financialgateway;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.fbe.common.util.CommonUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BATCHTXNDETAIL;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.gateway.persistence.interfaces.IPagingData;
import com.trapedza.bankfusion.persistence.core.PagingData;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_FIN_GetTxnDetailPaginated;

import bf.com.misys.bankfusion.attributes.PagedQuery;
import bf.com.misys.bankfusion.attributes.PagingRequest;

public class GetTxnDetailPaginated extends AbstractCE_FIN_GetTxnDetailPaginated {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final transient Log LOGGER = LogFactory.getLog(GetTxnDetailPaginated.class.getName());

	ArrayList<Object> params = new ArrayList();
	String query = "";
	int pageNo;
	int totalPages;
	private static final Integer PAGE_SIZE = 10;
	private static final Integer PAGE_NO = 1;
	private static final Boolean REQUIRE_PAGINATION_SUPPORT = Boolean.TRUE;
	public GetTxnDetailPaginated(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
		getQuery();

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		IPagingData pagingData = null;

		if (getF_IN_PagedQuery() != null && getF_IN_PagedQuery().getPagingRequest() != null) {
			pageSize = getF_IN_PagedQuery().getPagingRequest().getNumberOfRows();
			pageNo = getF_IN_PagedQuery().getPagingRequest().getRequestedPage();
		}

		if (pageSize == 0)
			pageSize = PAGE_SIZE;
		if (pageNo == 0)
			pageNo = PAGE_NO;
		
		pagingData = new PagingData(pageNo, pageSize);
		pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
		this.runQuery(query, pagingData);
	}

	private VectorTable runQuery(String dynamicQuery, IPagingData pagingData) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Query used to fetch the data :" + dynamicQuery);
			LOGGER.info("Parameter Values for Query : " + params);
			LOGGER.info("Result Page Number : " + pagingData.getCurrentPageNumber());
		}

		List<SimplePersistentObject> resultSet = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BATCHTXNDETAIL.BONAME, query, params, pagingData, true);

		VectorTable newResultVector = getVectorTableFromList(resultSet,pagingData.getCurrentPageNumber());
		PagedQuery pagedQuery = new PagedQuery();
		PagingRequest pagingRequest = new PagingRequest();
		pagingRequest.setNumberOfRows(pagingData.getPageSize());
		pagingRequest.setRequestedPage(pagingData.getCurrentPageNumber());
		pagingRequest.setTotalPages(pagingData.getTotalPages());
		pagedQuery.setPagingRequest(pagingRequest);
		//pagedQuery.setQueryData(listTitleDeedIdDtlsType);

		Object pageData[] = new Object[4];
		pageData[0] = pagingRequest.getRequestedPage();
		pageData[1] = pagingRequest.getNumberOfRows();
		pageData[2] = pagedQuery.getPagingRequest().getTotalPages();
		newResultVector.setPagingData(pageData);

		
		//setF_OUT_SearchTitleDeedDtlsRs(searchTitleDeedRs);
		setF_OUT_result(newResultVector);
		setF_OUT_PaginatedData(newResultVector);
		totalPages = pagingData.getTotalPages();
		pagingData.getCurrentPageNumber();
		return newResultVector;
	}

	private VectorTable getVectorTableFromList(List<SimplePersistentObject> list, int pageNumber) {
		VectorTable vectorTable = new VectorTable();
		if (list != null && !list.isEmpty()) {
			Iterator var7 = list.iterator();
			System.err.println();
			//int idx = (pageNumber-1)*10+1;
			while (var7.hasNext()) {
				IBOCE_BATCHTXNDETAIL batchtxndetail = (IBOCE_BATCHTXNDETAIL) var7.next();
				Map<String, Object> attribute = new HashMap<>();
				attribute.put("BOID", batchtxndetail.getBoID());
				attribute.put("PROCESSDESC", batchtxndetail.getF_PROCESSING());
				attribute.put("AMOUNT", BatchCollectionUtil.getScaledAmount(batchtxndetail.getF_AMOUNT()));
				attribute.put("SRNO", batchtxndetail.getBoID().substring(4));
				attribute.put("SELECT", false);
				attribute.put("BANKID", batchtxndetail.getF_BANKID());
				attribute.put("BATCHGWREF", batchtxndetail.getF_BATCHGWREF());
				attribute.put("BATCHREF", batchtxndetail.getF_BATCHREF());
				attribute.put("BATCHRUNNINGAMNT", batchtxndetail.getF_BATCHRUNNINGAMNT());
				attribute.put("BRANCHCD", batchtxndetail.getF_BRANCHCD());
				attribute.put("CHEQUENO", batchtxndetail.getF_CHEQUENO());
				attribute.put("CREDITACC", batchtxndetail.getF_CREDITACC());
				attribute.put("DEBITACC", batchtxndetail.getF_DEBITACC());
				attribute.put("HOSTTXNREF", batchtxndetail.getF_HOSTTXNREF());
				attribute.put("INTERNALACC", batchtxndetail.getF_INTERNALACC());
				attribute.put("NARRATIVE", batchtxndetail.getF_NARRATIVE());
				attribute.put("NATIONALID", batchtxndetail.getF_NATIONALID());
				attribute.put("STATUS", batchtxndetail.getF_STATUS());
				attribute.put("TXNDATE", batchtxndetail.getF_VALUEDATE());
				attribute.put("TXNREF", batchtxndetail.getF_TXNREF());
				attribute.put("VALUEDATE", batchtxndetail.getF_VALUEDATE());
				attribute.put("VALUEDATEHIJRI", batchtxndetail.getF_VALUEDATEHIJRI());
				attribute.put("MOFDOCDATE", batchtxndetail.getF_MOFDOCDATE());
				attribute.put("MOFDOCNUMBER", batchtxndetail.getF_MOFDOCNUMBER());
				attribute.put("CHEQUEDATE", batchtxndetail.getF_CHEQUEDATE());
				attribute.put("CHEQUENUMBER", batchtxndetail.getF_CHEQUENUMBER());
				attribute.put("PAYEENAME", batchtxndetail.getF_PAYEENAME());
				vectorTable.addAll(new VectorTable(attribute));
			}
		}
		return vectorTable;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = super.createActivityStepPagingState();
		Map supportedData = pagingState.getPagingHelper().getPagingModel();
		supportedData.put("PAGING_QUERY", query);
		supportedData.put("PAGING_PARAMS", params);
		return pagingState;
	}

	public Object processPagingState(BankFusionEnvironment env, ActivityStepPagingState activitysteppagingstate,
			@SuppressWarnings("rawtypes") Map map) {
		
		VectorTable resultVector = new VectorTable();
		PagingHelper pagingHelper = activitysteppagingstate.getPagingHelper();
		@SuppressWarnings("rawtypes")
		Map pagingModel = pagingHelper.getPagingModel();
		query = (String) pagingModel.get("PAGING_QUERY");
		params =  (ArrayList<Object>) pagingModel.get("PAGING_PARAMS");
		

		int pageSize = PAGE_SIZE;
		int pageNo = PAGE_NO;

		if (map.containsKey("PAGENO")) {
			pageNo = (Integer) map.get("PAGENO");
		}
		if (map.containsKey("NUMBEROFROWS")) {
			pageSize = (Integer) map.get("NUMBEROFROWS");
		}

		IPagingData pagingData = new PagingData(pageNo, pageSize);

		if (pagingData != null) {
			pagingData.setTotalPages((Integer) map.get("TOTALPAGES"));
			if (pagingData.getCurrentPageNumber() == 0)
				pagingData.setCurrentPageNumber(pageNo);
			if (pagingData.getPageSize() == 0)
				pagingData.setPageSize(pageSize);

			pagingData.setRequiresTotalPages(REQUIRE_PAGINATION_SUPPORT);
			resultVector = runQuery(query, pagingData);
			
		}
		return resultVector;
	}

	private void getQuery() {
		if (getF_IN_filterAction().equals(CommonConstants.EMPTY_STRING)) {
			String getUnProcessedRecs = getF_IN_getUnProcessedRecs();
			String recID = getF_IN_batchInfo().getRecId();
			params.clear();
			StringBuffer QUERY = new StringBuffer(" WHERE " + IBOCE_BATCHTXNDETAIL.BATCHREF + " =? ");
			params.add(getF_IN_batchRef());
			if (getUnProcessedRecs.equalsIgnoreCase("Y")) {
				QUERY.append(" AND (" + IBOCE_BATCHTXNDETAIL.PROCESSING + " = ? OR " + IBOCE_BATCHTXNDETAIL.PROCESSING
						+ " IS NULL )");
				params.add("N");
			} else if (getUnProcessedRecs.equalsIgnoreCase("N")) {
				QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.PROCESSING + " = ? ");
				params.add("Y");
			}
			if (!recID.isEmpty()) {
				QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.ID + " = ? ");
				params.add(recID);
			}
			if (!getF_IN_batchInfo().getNarrative().isEmpty()) {
				QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.NARRATIVE + " LIKE '%" + getF_IN_batchInfo().getNarrative() + "%'");
			}
			QUERY.append(" ORDER BY "+IBOCE_BATCHTXNDETAIL.ID+"+0,"+IBOCE_BATCHTXNDETAIL.ID+" ASC");
			query = QUERY.toString();
		} else {
			StringBuffer QUERY = new StringBuffer();
			BigDecimal amount = getF_IN_batchInfo().getAmount();
			Date chequedate = getF_IN_batchInfo().getChequeDate();
			String chequenumber = getF_IN_batchInfo().getChequeNumber();
			String internalAccount = getF_IN_batchInfo().getInternalAccount();
			String loanAccount = getF_IN_batchInfo().getLoanAccount();
			Date newdate = new Date(0);
			Date mofDate = getF_IN_batchInfo().getMOFDocDate();
			Date txnDate = getF_IN_batchInfo().getTxnDate();
			String mofNumber = getF_IN_batchInfo().getMOFDocNumber();
			String narrative = getF_IN_batchInfo().getNarrative();
			String nationalID = getF_IN_batchInfo().getNationalId();
			String status = getF_IN_batchInfo().getStatus();
			String gatewayRef = getF_IN_batchInfo().getGatewayRef();
			if ((amount.compareTo(BigDecimal.ZERO) == CommonConstants.INTEGER_ZERO) && chequedate.compareTo(newdate)==0&& txnDate.compareTo(newdate)==0
					&& chequenumber.equals("") && internalAccount.equals("") && loanAccount.equals("")
					&& mofDate.compareTo(newdate)==0 && mofNumber.equals("") && narrative.equals("") && nationalID.equals("")
					&& status.equals("")) {
				CommonUtil.handleUnParameterizedEvent(35100184);
			} else {
				params.clear();
				if (!narrative.isEmpty()) {
					QUERY.append(" WHERE " + IBOCE_BATCHTXNDETAIL.NARRATIVE + " like '%" + narrative + "%'");
				} else {
					QUERY.append(" WHERE ");
				}
				if (amount.compareTo(BigDecimal.ZERO) > CommonConstants.INTEGER_ZERO) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.AMOUNT + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.AMOUNT + " = ? ");
					}
					params.add(amount);
				}
				if (chequedate.compareTo(newdate)!=0) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.CHEQUEDATE + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.CHEQUEDATE + " = ? ");
					}
					params.add(chequedate);
				}
				if (!chequenumber.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.CHEQUENUMBER + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.CHEQUENUMBER + " = ? ");
					}
					params.add(chequenumber);
				}
				if (!internalAccount.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.INTERNALACC + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.INTERNALACC + " = ? ");
					}
					params.add(internalAccount);
				}
				if (!nationalID.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.NATIONALID + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.NATIONALID + " = ? ");
					}
					params.add(nationalID);
				}
				if (!loanAccount.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.CREDITACC + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.CREDITACC + " = ? ");
					}
					params.add(loanAccount);
				}
				if (!mofNumber.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.MOFDOCNUMBER + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.MOFDOCNUMBER + " = ? ");
					}
					params.add(mofNumber);
				}
				if (mofDate.compareTo(newdate)!=0) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.MOFDOCDATE + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.MOFDOCDATE + " = ? ");
					}
					params.add(mofDate);
				}
				if (txnDate.compareTo(newdate)!=0) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.VALUEDATE + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.VALUEDATE + " = ? ");
					}
					params.add(txnDate);
				}
				if (!status.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.STATUS + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.STATUS + " = ? ");
					}
					params.add(status);
				}
				/*if (!gatewayRef.equals("")) {
					if (QUERY.length() > 7) {
						QUERY.append(" AND " + IBOCE_BATCHTXNDETAIL.BATCHGWREF + " = ? ");
					} else {
						QUERY.append(IBOCE_BATCHTXNDETAIL.BATCHGWREF + " = ? ");
					}
					params.add(gatewayRef);
				}*/
			}
			query = QUERY.toString();
		}
	}
}
