package com.ce.payments;

import static com.ce.adf.CEConstants.EMPTY;
import static com.ce.sadad.util.SadadMessageConstants.REPAY;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_FeesPaymentStatus;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_SadadPayments;
import com.ce.bankfusion.ib.util.CeUtils;
import com.ce.bankfusion.ib.util.RescheduleUtils;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.SadadMessageConstants;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SadadPaymentDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusTxnDtls;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_FIN_AmortizationDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOpseudonyms;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.fatoms.ValidateAndPostingSurplusAmt;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.services.IPersistenceService;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.IServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SadadPaymentReqBuilder;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRq;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRs;
import bf.com.misys.financialposting.types.PostingLeg;
import bf.com.misys.financialposting.types.TxnDetails;
import bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls;
import bf.com.misys.types.sadad.payment.SadadPmtDtlsRq;
import bf.com.misys.types.sadad.payment.SadadPmtDtlsRs;
import bf.com.misys.types.sadad.payment.SadadRequest;
import bf.com.misys.types.sadad.payment.SadadResponse;

public class CE_SadadPaymentReqBuilder extends AbstractCE_SadadPaymentReqBuilder {

	private IBOCE_BILLINVOICE invDtl = null;
	private String loanAcc = EMPTY;
	private String loanReference = EMPTY;
	private BigDecimal excessPaymentAmount = BigDecimal.ZERO;

	Log logger = LogFactory.getLog(CE_SadadPaymentReqBuilder.class);

	private static final long serialVersionUID = 1L;
	private static String loanRepayments_whereClause = "WHERE " + IBOLoanRepayments.PAIDDATE + " =? and "
			+ IBOLoanRepayments.ACCOUNTID + "= ?";

	@SuppressWarnings("deprecation")
	public CE_SadadPaymentReqBuilder(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		SadadRequest sadadRqList = getF_IN_request();
		SadadResponse sadadRs = new SadadResponse();
		SadadPmtDtlsRq[] sadadRqArray = sadadRqList.getTransactionDtl();
		for (SadadPmtDtlsRq sadadRq : sadadRqArray) {
			// reset for every request
			loanAcc = EMPTY;
			loanReference = EMPTY;

			String status = EMPTY;
			String errorDesc = EMPTY;
			String billInvoiceNo = EMPTY;
			try {

				String billAcct = sadadRq.getBillAcct();
				String billCategory = sadadRq.getBillCategory();
				String billCycle = sadadRq.getBillCycle();

				// invalid payment id
				String paymentID = this.getSadadPaymentID(sadadRq);
				if (paymentID.equalsIgnoreCase(SadadMessageConstants.SADAD_PAYMENT_ID_NOT_FOUND)) {
					status = "E";
					errorDesc = "Invalid Payment ID";
					if (sadadRq.getBillAcct() == null || sadadRq.getBillAcct().isEmpty()) {
						sadadRq.setBillAcct(SadadMessageConstants.SADAD_ACCOUNT_ID_NOT_FOUND);
					}
					logger.info("Validation : " + errorDesc);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}

				// invalid bill account
				if (sadadRq.getBillAcct() == null || sadadRq.getBillAcct().isEmpty()) {
					status = "E";
					errorDesc = "Invalid Bill Account";
					logger.info("Validation : " + errorDesc);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}

				if (billCategory.equals(SadadMessageConstants.FEE)) {
					logger.info("Fee bill account separation : " + SadadMessageConstants.FEE);
					int position = billAcct.length() - BillInvoiceHelper.MAX_PRECEDING_DIGIT_BILL_INVOICE_CYCLE;
					billCycle = billAcct.substring(position);
					billAcct = billAcct.substring(0, position);
					sadadRq.setBillAcct(billAcct);
					sadadRq.setBillCycle(billCycle);
					logger.info("Fee - billAcct : " + billAcct + " # billCycle : " + billCycle);
				}

				// invalid bill cycle
				if (sadadRq.getBillCycle() == null || sadadRq.getBillCycle().isEmpty()
						|| Integer.parseInt(sadadRq.getBillCycle()) == 0) {
					status = "E";
					errorDesc = "Invalid Bill Cycle";
					logger.info("Validation : " + errorDesc);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}

				// Payment Exists Already
				if (this.isTransactionAvailableAlready(paymentID, billAcct)) {
					status = "E";
					errorDesc = "Payment Exists Already";
					logger.info("Validation : " + errorDesc);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}

				// invalid bill account
				if (sadadRq.getBillCategory().equals(SadadMessageConstants.REPAY)
						&& !isValidAccount(sadadRq.getBillAcct())) {
					status = "E";
					errorDesc = "Invalid Account";
					logger.info("Validation : " + errorDesc);
					sadadRq.setBillAcct(SadadMessageConstants.SADAD_ACCOUNT_ID_NOT_FOUND);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}

				billInvoiceNo = this.fetchBillInvoiceNo(sadadRq);
				if (!billInvoiceNo.equals(EMPTY)) {
					logger.info("Payment Request process starting for Bill Invoice:" + billInvoiceNo);
					sadadRq.setBillInvoiceNo(billInvoiceNo);
					errorDesc = validateRequest(sadadRq);
					if (errorDesc.equals(EMPTY)) {
						logger.info("validateRequest successful : " + billInvoiceNo);
						if (invDtl.getF_BILLCATEGORY().equals(REPAY)) {
							// TODO Extra amount Posting
							excessPaymentAmount = updateSadadRqExcludingExcessAmount(loanReference, sadadRq);
							logger.info(
									"updateSadadRqExcludingExcessAmount excessPaymentAmount : " + excessPaymentAmount);
						}

						logger.info("populateAndCallBackOfficeRequest begin : " + billInvoiceNo);
						BackOfficeAccountPostingRs response = (BackOfficeAccountPostingRs) populateAndCallBackOfficeRequest(
								sadadRq, invDtl.getF_BILLCATEGORY());
						logger.info("populateAndCallBackOfficeRequest response : " + response);
						if (response != null && response.getTransactionId() != null) {
							logger.info("populateAndCallBackOfficeRequest successful : " + response.getTransactionId());
							BigDecimal scheduleFeeAmtPaid = updateScheduleTable(sadadRq);

							if (scheduleFeeAmtPaid.compareTo(BigDecimal.ZERO) > 0) {
								logger.info("callRescheduleProfitBackOfficeRequest through : " + sadadRq);
								BigDecimal totalSadadPaymentAmt = sadadRq.getPmtAmt();
								sadadRq.setPmtAmt(scheduleFeeAmtPaid);
								response = (BackOfficeAccountPostingRs) callRescheduleProfitBackOfficeRequest(sadadRq,
										invDtl.getF_BILLCATEGORY());
								sadadRq.setPmtAmt(totalSadadPaymentAmt);
							}

							if (null != response && response.getTransactionId() != null) {
								logger.info("callRescheduleProfitBackOfficeRequest successful : "
										+ response.getTransactionId());
								status = "S";
								errorDesc = CEConstants.S;
								if (invDtl.getF_BILLCATEGORY().equals(REPAY)
										&& excessPaymentAmount.compareTo(BigDecimal.ZERO) > 0) {
									// TODO Extra amount Posting
									IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
											.getPersistanceFactory()
											.findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);

									IServiceManager servicemanager = ServiceManagerFactory.getInstance()
											.getServiceManager();
									IPersistenceService persistenceService = (IPersistenceService) servicemanager
											.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
									IPersistenceObjectsFactory factory = persistenceService
											.getPrivatePersistenceFactory(true);
									factory.beginTransaction();
									CEUtil ceUtilss = new CEUtil();
									String dTxnCode = ceUtilss.getModuleConfigurationValue("LENDING", "2149_DR");
									String cTxnCode = ceUtilss.getModuleConfigurationValue("LENDING", "2149_CR");

									if (!CeUtils.getSurplusAccount(loanAcc).isEmpty()) {
										RescheduleUtils.callBackOfficePostingRequest(loanAcc, loanReference,
												sadadRq.getBillInvoiceNo().concat("1"), excessPaymentAmount,
												CeUtils.getSurplusAccount(loanAcc), getBankAcc(sadadRq),
												loanAcc + "$" + "Sadad Excess Amount Posting", dTxnCode, cTxnCode);
									} else {
										ValidateAndPostingSurplusAmt validateAndPostingSurplusAmt = new ValidateAndPostingSurplusAmt(
												env);

										String surplusAccount = validateAndPostingSurplusAmt.getSurplusAccount(
												loanAccDtl.getF_ISOCURRENCYCODE(), loanAccDtl.getF_BRANCHSORTCODE(),
												loanAccDtl.getF_CUSTOMERCODE());

										IBOUB_CNF_SurplusAccountDetails surplusAccountDetails = (IBOUB_CNF_SurplusAccountDetails) factory
												.getStatelessNewInstance(IBOUB_CNF_SurplusAccountDetails.BONAME);
										surplusAccountDetails.setBoID(loanAcc);
										surplusAccountDetails.setF_UBSURPLUSACCOUNT(surplusAccount);
										factory.create(IBOUB_CNF_SurplusAccountDetails.BONAME, surplusAccountDetails);

										RescheduleUtils.callBackOfficePostingRequest(loanAcc, loanReference,
												sadadRq.getBillInvoiceNo().concat("1"), excessPaymentAmount,
												surplusAccount, getBankAcc(sadadRq),
												loanAcc + "$" + "Sadad Excess Amount Posting", dTxnCode, cTxnCode);
									}

									IBOUB_CNF_SurplusTxnDtls surplusTxnDtls = (IBOUB_CNF_SurplusTxnDtls) factory
											.getStatelessNewInstance(IBOUB_CNF_SurplusTxnDtls.BONAME);

									surplusTxnDtls.setBoID(GUIDGen.getNewGUID());
									surplusTxnDtls.setF_ISOCURRENCYCODE(loanAccDtl.getF_ISOCURRENCYCODE());
									surplusTxnDtls.setF_PAYMENTACCOUNT(getBankAcc(sadadRq));
									surplusTxnDtls.setF_SURPLUSAMOUNT(excessPaymentAmount);
									surplusTxnDtls.setF_UBACCOUNTID(loanAcc);
									surplusTxnDtls.setF_PAYMENTMODE("CASH");
									surplusTxnDtls.setF_TRANSACTIONDATE(
											SystemInformationManager.getInstance().getBFBusinessDate());

									factory.create(IBOUB_CNF_SurplusTxnDtls.BONAME, surplusTxnDtls);
									factory.commitTransaction();
									factory.beginTransaction();
								}

								logger.info("Transaction successful : " + billInvoiceNo);
								// update bill invoice record only when transaction is successfully completed
								BigDecimal paidAmt = sadadRq.getPmtAmt();
								BigDecimal billAmount = invDtl.getF_BILLAMT();
								String newBillAction = SadadMessageConstants.UPDATE;
								if (paidAmt.compareTo(billAmount) >= 0) {
									billAmount = BigDecimal.ZERO;
									this.updateIBSadadPaymentRecord(billInvoiceNo);
								} else {
									billAmount = billAmount.subtract(paidAmt);
								}
								invDtl.setF_BILLAMT(billAmount);
								invDtl.setF_BILLACTION(newBillAction);

								logger.info("Transaction posted successfully for the BillInvoiceNo: " + billInvoiceNo);
								this.persistReqDetails(sadadRq, status, errorDesc);
								logger.info("Transaction posted successfully for the BillInvoiceNo - END : "
										+ billInvoiceNo);
								continue;
							} else {
								status = "E";
								errorDesc = "RescheduleProfitBackOffice Failed";
								logger.info("Failed :" + errorDesc);
								this.persistReqDetails(sadadRq, status, errorDesc);
								continue;
							}
						} else {
							status = "E";
							errorDesc = "Transaction failed";
							logger.info("Failed :" + errorDesc);
							this.persistReqDetails(sadadRq, status, errorDesc);
							continue;
						}
					} else {
						status = "E";
						logger.info("Error Description:" + errorDesc);
						this.persistReqDetails(sadadRq, status, errorDesc);
						continue;
					}
				} else {
					status = "E";
					errorDesc = "Bill invoice record not found";
					logger.info("Failed :" + errorDesc);
					this.persistReqDetails(sadadRq, status, errorDesc);
					continue;
				}
			} catch (BankFusionException be) {
				status = "E";
				errorDesc = "Transaction failed";
				logger.error("Failed :" + errorDesc);
				logger.error("BankFusionException Occured " + be.getMessage());
				this.persistReqDetails(sadadRq, status, errorDesc);
				continue;
			} catch (Exception e) {
				status = "E";
				errorDesc = "Transaction failed";
				logger.error("Exception occured " + e.getMessage());
				logger.info("Failed :" + errorDesc);
				this.persistReqDetails(sadadRq, status, errorDesc);
				continue;
			}
		}
		// No Error validation response on SADAD Payment rq. must be sent back
		// Instead just persist all Success/Failure case in SadadPayment Table
		// Response must always be Success when sent back to SADAD
		this.prepareResponse(sadadRs, "S", CEConstants.S);
		setF_OUT_response(sadadRs);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private BigDecimal updateScheduleTable(SadadPmtDtlsRq sadadRq) {
		logger.info("updating Breakup customized table : begin");
		BigDecimal scheduleFeeAmtPaid = BigDecimal.ZERO;
		BigDecimal hundred = new BigDecimal(100);
		ArrayList<Object> params = new ArrayList<Object>();
		if (invDtl.getF_BILLCATEGORY().equalsIgnoreCase(REPAY)) {
			params.add(invDtl.getF_BILLACCT());
			List lenFtrResult = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME,
					" WHERE " + IBOLendingFeature.ACCOUNTID + " = ?", params, null, true);
			if (lenFtrResult != null && !lenFtrResult.isEmpty()) {
				String loanRef = ((IBOLendingFeature) lenFtrResult.get(0)).getF_LOANREFERENCE();
				logger.info("Loan Reference: " + loanRef);
				if (logger.isInfoEnabled()) {
					logger.info("--------------------- " + "SadadPmtDtlsRq" + " ---------------------------");
					logger.info("--------------------- Interface XML (Begin) ---------------------------");
					logger.info("--------------------- Interface XML (" + sadadRq.getClass().getSimpleName()
							+ ") ---------------------------");
					Gson gson = new GsonBuilder().setPrettyPrinting().create();
					logger.info((gson.toJson(sadadRq)).replace("\"", " ").replace(",", "").replace("_", "\t"));
					logger.info("--------------------- Interface XML (End)   ---------------------------");
				}
				params.clear();
				params.add(sadadRq.getPmtDt());
				params.add(sadadRq.getBillAcct());
				List<IBOLoanRepayments> loanRepaymentDtls = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery(IBOLoanRepayments.BONAME, loanRepayments_whereClause, params, null, true);
				if (loanRepaymentDtls != null && !loanRepaymentDtls.isEmpty()) {
					BigDecimal prevReschProfitPaidAmount = getPaidRescheduleProfit(loanRef);
					for (IBOLoanRepayments loanRepaymentDtl : loanRepaymentDtls) {
						params.clear();
						params.add(loanRef);
						params.add(loanRepaymentDtl.getF_DUEDATE());
						String where = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
								+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
						List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal
								.getPersistanceFactory()
								.findByQuery("CE_IB_PaymentSchBreakup", where, params, null, true);
						if (ibPaymentSchResult != null && !ibPaymentSchResult.isEmpty()) {
							if (loanRepaymentDtl.getF_REPAYMENTUNPAID().compareTo(BigDecimal.ZERO) == 0) {
								// repayment is fully paid
								logger.info("Repayment is fully paid for loan reference: " + loanRef);
								for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
									paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
									paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
									paymentSchBreakup
											.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
								}
							} else {
								// fetching total repayment principal, profit and fees for the billDate
								BigDecimal totalRepaymentPrincipal = BigDecimal.ZERO;
								BigDecimal totalRepaymentProfit = BigDecimal.ZERO;
								// BigDecimal totalRepaymentFees = BigDecimal.ZERO;
								for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
									totalRepaymentPrincipal = totalRepaymentPrincipal
											.add(paymentSchBreakup.getF_IBPRINCIPALAMT());
									totalRepaymentProfit = totalRepaymentProfit
											.add(paymentSchBreakup.getF_IBPROFITAMT())
											.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
								}

								// fetching the percentages for Principal, Profit, Fees at Asset level
								HashMap<String, BigDecimal> assetIdWithPrincipalPercentage = new HashMap<>();
								HashMap<String, BigDecimal> assetIdWithProfitPercentage = new HashMap<>();
								BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
								BigDecimal assetProfitPercentage = BigDecimal.ZERO;
								BigDecimal remAssetPrincipalPercentage = new BigDecimal(100);
								BigDecimal remAssetProfitPercentage = new BigDecimal(100);
								BigDecimal assetProfitAmount = BigDecimal.ZERO;
								int i = 1;
								for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
									assetProfitAmount = paymentSchBreakup.getF_IBPROFITAMT()
											.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
									if (i == ibPaymentSchResult.size()) {
										assetPrincipalPercentage = remAssetPrincipalPercentage;
										assetProfitPercentage = remAssetProfitPercentage;
									} else {
										if (totalRepaymentPrincipal.compareTo(BigDecimal.ZERO) > 0) {
											assetPrincipalPercentage = (paymentSchBreakup.getF_IBPRINCIPALAMT()
													.multiply(hundred)).divide(totalRepaymentPrincipal, 0,
															RoundingMode.UP);
										}
										if (totalRepaymentProfit.compareTo(BigDecimal.ZERO) > 0) {
											assetProfitPercentage = (assetProfitAmount.multiply(hundred))
													.divide(totalRepaymentProfit, 0, RoundingMode.UP);
										}
									}
									assetIdWithPrincipalPercentage.put(paymentSchBreakup.getF_IBASSETID(),
											assetPrincipalPercentage);
									assetIdWithProfitPercentage.put(paymentSchBreakup.getF_IBASSETID(),
											assetProfitPercentage);
									remAssetPrincipalPercentage = remAssetPrincipalPercentage
											.subtract(assetPrincipalPercentage);
									remAssetProfitPercentage = remAssetProfitPercentage.subtract(assetProfitPercentage);
									++i;
								}

								// updating breakup table
								updatePaymentBreakupTable(loanRepaymentDtl.getF_PRINCIPALPAID(),
										loanRepaymentDtl.getF_INTERESTPAID(), hundred, lenFtrResult, ibPaymentSchResult,
										assetIdWithPrincipalPercentage, assetIdWithProfitPercentage);
							}
						}
					}
					BigDecimal updatedReschProfitPaidAmount = getPaidRescheduleProfit(loanRef);
					scheduleFeeAmtPaid = updatedReschProfitPaidAmount.subtract(prevReschProfitPaidAmount);
				}
			}
		} else {
			params.add(invDtl.getF_BILLINVOICENO());
			List<IBOCE_IB_FeesPaymentStatus> feesList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
					IBOCE_IB_FeesPaymentStatus.BONAME,
					"WHERE " + IBOCE_IB_FeesPaymentStatus.IBFEESPAYMENTINVOICENO + " = ?", params, null, true);
			if (feesList != null && !feesList.isEmpty()) {
				IBOCE_IB_FeesPaymentStatus feeDtls = feesList.get(0);
				BigDecimal feePaid = feeDtls.getF_IBFEESPAYMENTAMNTPAID();
				feePaid = feePaid.add(sadadRq.getPmtAmt());
				feeDtls.setF_IBFEESPAYMENTAMNTPAID(feePaid);
			}
		}
		logger.info("updating Breakup customized table : end");
		return scheduleFeeAmtPaid;
	}

	@SuppressWarnings("unchecked")
	private BigDecimal getPaidRescheduleProfit(String loanRef) {
		ArrayList<Object> inputParams = new ArrayList<Object>();
		inputParams.add(loanRef);
		String whereAllRecords = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereAllRecords, inputParams, null, true);
		BigDecimal paidScheduledFeeAmt = BigDecimal.ZERO;
		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			paidScheduledFeeAmt = paidScheduledFeeAmt.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID());
		}
		return paidScheduledFeeAmt;
	}

	@SuppressWarnings("unchecked")
	private BigDecimal updateSadadRqExcludingExcessAmount(String loanRef, SadadPmtDtlsRq sadadRq) {
		ArrayList<Object> inputParams = new ArrayList<Object>();
		inputParams.add(loanRef);
		String whereAllRecords = "WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? ";
		List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, whereAllRecords, inputParams, null, true);
		BigDecimal totalAmount = BigDecimal.ZERO;
		BigDecimal totalPaidAmount = BigDecimal.ZERO;
		logger.info("ibPaymentSchResult - loanRef: " + loanRef);
		logger.info("ibPaymentSchResult - size: " + ibPaymentSchResult.size());
		if (ibPaymentSchResult != null) {
			for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
				totalAmount = totalAmount.add(paymentSchBreakup.getF_IBPRINCIPALAMT()
						.add(paymentSchBreakup.getF_IBPROFITAMT()).add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
				totalPaidAmount = totalPaidAmount
						.add(paymentSchBreakup.getF_IBPRINCIPALAMTPAID().add(paymentSchBreakup.getF_IBPROFITAMTPAID())
								.add(paymentSchBreakup.getF_IBSCHEDULEFEESAMTPAID()));
			}
			BigDecimal totalUnPaidAmount = totalAmount.subtract(totalPaidAmount);
			excessPaymentAmount = sadadRq.getPmtAmt().subtract(totalUnPaidAmount);
			if (excessPaymentAmount.compareTo(BigDecimal.ZERO) > 0)
				sadadRq.setPmtAmt(totalUnPaidAmount);
			else
				excessPaymentAmount = BigDecimal.ZERO;
		}
		return excessPaymentAmount;
	}

	@SuppressWarnings("rawtypes")
	private void updatePaymentBreakupTable(BigDecimal principalPaid, BigDecimal profitPaid, BigDecimal hundred,
			List lenFtrResult, List<IBOCE_IB_PaymentSchBreakup> ibPaymentSchResult,
			HashMap<String, BigDecimal> assetIdWithPrincipalPercentage,
			HashMap<String, BigDecimal> assetIdWithProfitPercentage) {

		String collectionOrderProfile = ((IBOLendingFeature) lenFtrResult.get(0)).getF_COLLECTIONORDER();
		BigDecimal assetPrincipalPercentage = BigDecimal.ZERO;
		BigDecimal assetProfitPercentage = BigDecimal.ZERO;
		BigDecimal remPrincipalPaid = principalPaid;
		BigDecimal remProfitPaid = profitPaid;
		BigDecimal assetPrincipalPaidAmount = BigDecimal.ZERO;
		BigDecimal assetProfitAndFeesPaidAmount = BigDecimal.ZERO;
		int j = 1;
		boolean isAssetProfitAndFeesFullyPaid = false;
		boolean isAssetPrincipalFullyPaid = false;

		logger.info("Updating breakup table for BillDate : " + ibPaymentSchResult.get(0).getF_IBBILLDATE());
		logger.info("Collection order profile : " + collectionOrderProfile);
		logger.info("Principal Paid : " + principalPaid);
		logger.info("Profit Paid : " + profitPaid);

		for (IBOCE_IB_PaymentSchBreakup paymentSchBreakup : ibPaymentSchResult) {
			isAssetProfitAndFeesFullyPaid = false;
			isAssetPrincipalFullyPaid = false;
			assetPrincipalPercentage = assetIdWithPrincipalPercentage.get(paymentSchBreakup.getF_IBASSETID());
			assetProfitPercentage = assetIdWithProfitPercentage.get(paymentSchBreakup.getF_IBASSETID());
			logger.info("Principal Percentage / AssetId : " + assetPrincipalPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());
			logger.info("Profit Percentage / AssetId : " + assetProfitPercentage + ","
					+ paymentSchBreakup.getF_IBASSETID());

			if (j == ibPaymentSchResult.size()) {
				assetProfitAndFeesPaidAmount = remProfitPaid;
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					logger.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				assetPrincipalPaidAmount = remPrincipalPaid;
			} else {
				assetPrincipalPaidAmount = (principalPaid.multiply(assetPrincipalPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetPrincipalPaidAmount.compareTo(paymentSchBreakup.getF_IBPRINCIPALAMT()) >= 0) {
					assetPrincipalPaidAmount = paymentSchBreakup.getF_IBPRINCIPALAMT();
					isAssetPrincipalFullyPaid = true;
					logger.info("Principal Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID() + " is "
							+ isAssetPrincipalFullyPaid);
				}
				assetProfitAndFeesPaidAmount = (profitPaid.multiply(assetProfitPercentage)).divide(hundred, 0,
						RoundingMode.UP);
				if (assetProfitAndFeesPaidAmount.compareTo(
						paymentSchBreakup.getF_IBPROFITAMT().add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT())) >= 0) {
					assetProfitAndFeesPaidAmount = paymentSchBreakup.getF_IBPROFITAMT()
							.add(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					isAssetProfitAndFeesFullyPaid = true;
					logger.info("Principal and Profit Fully Paid for Asset" + paymentSchBreakup.getF_IBASSETID()
							+ " is " + isAssetProfitAndFeesFullyPaid);
				}
				remPrincipalPaid = remPrincipalPaid.subtract(assetPrincipalPaidAmount);
				remProfitPaid = remProfitPaid.subtract(assetProfitAndFeesPaidAmount);
			}

			if (isAssetPrincipalFullyPaid) {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(paymentSchBreakup.getF_IBPRINCIPALAMT());
			} else {
				paymentSchBreakup.setF_IBPRINCIPALAMTPAID(assetPrincipalPaidAmount);
			}
			if (isAssetProfitAndFeesFullyPaid) {
				paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
				paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
			} else {
				if (collectionOrderProfile.indexOf('I') > collectionOrderProfile.indexOf('F')) {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) > 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBPROFITAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBPROFITAMT()) == 0) {
						paymentSchBreakup.setF_IBPROFITAMTPAID(paymentSchBreakup.getF_IBPROFITAMT());
					} else {
						paymentSchBreakup.setF_IBPROFITAMTPAID(assetProfitAndFeesPaidAmount);
					}
				} else {
					if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) > 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
						paymentSchBreakup.setF_IBPROFITAMTPAID(
								assetProfitAndFeesPaidAmount.subtract(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()));
					} else if (assetProfitAndFeesPaidAmount.compareTo(paymentSchBreakup.getF_IBSCHEDULEFEEAMT()) == 0) {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(paymentSchBreakup.getF_IBSCHEDULEFEEAMT());
					} else {
						paymentSchBreakup.setF_IBSCHEDULEFEESAMTPAID(assetProfitAndFeesPaidAmount);
					}
				}
			}
			++j;
		}
	}

	private String persistReqDetails(SadadPmtDtlsRq sadadRq, String status, String statusDesc) {
		String billInvoiceNumber = sadadRq.getBillInvoiceNo();
		if (status == null || status.isEmpty()) {
			status = CEConstants.S;
		}
		if (statusDesc != null && statusDesc.length() > 30) {
			statusDesc = statusDesc.substring(0, 30);
		}
		if (billInvoiceNumber == null || billInvoiceNumber.isEmpty()) {
			billInvoiceNumber = SadadMessageConstants.SADAD_BILL_INVOICE_NO_NOT_APPLICABLE;
		}
		IServiceManager servicemanager = ServiceManagerFactory.getInstance().getServiceManager();
		IPersistenceService persistenceService = (IPersistenceService) servicemanager
				.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
		IPersistenceObjectsFactory factory = persistenceService.getPrivatePersistenceFactory(true);
		String primaryKey = GUIDGen.getNewGUID();
		logger.info("Persistance of Payment Request start.....");
		try {
			factory.beginTransaction();
			IBOCE_SadadPaymentDetails sadadPaymentDtls = (IBOCE_SadadPaymentDetails) factory
					.getStatelessNewInstance(IBOCE_SadadPaymentDetails.BONAME);
			sadadPaymentDtls.setBoID(primaryKey);
			sadadPaymentDtls.setF_AgencyId(sadadRq.getAgencyId());
			sadadPaymentDtls.setF_BankId(this.getGlobalPseudonym(sadadRq));
			sadadPaymentDtls.setF_BillAcct(sadadRq.getBillAcct());
			sadadPaymentDtls.setF_BillCategory(sadadRq.getBillCategory());
			sadadPaymentDtls.setF_BillInvoiceNo(billInvoiceNumber);
			sadadPaymentDtls.setF_PmtAmt(sadadRq.getPmtAmt());
			sadadPaymentDtls.setF_PmtDt(sadadRq.getPmtDt());
			sadadPaymentDtls.setF_PmtId(this.getSadadPaymentID(sadadRq));
			sadadPaymentDtls.setF_PmtStatusCode(
					sadadRq.getPmtStatusCode() == null ? CommonConstants.EMPTY_STRING : sadadRq.getPmtStatusCode());
			sadadPaymentDtls.setF_STATUS(status);
			sadadPaymentDtls.setF_STATUSDESCRIPTION(statusDesc);
			factory.create(IBOCE_SadadPaymentDetails.BONAME, sadadPaymentDtls);
			factory.commitTransaction();
			factory.beginTransaction();

			ArrayList<String> params = new ArrayList<String>();
			params.add(billInvoiceNumber);
			factory.findByQuery(IBOCE_BILLINVOICE.BONAME, "WHERE " + IBOCE_BILLINVOICE.BILLINVOICENO + " = ?", params,
					null, true);
			factory.commitTransaction();
			factory.beginTransaction();
			logger.info("Persistance of Payment Request end........");
		} catch (Exception e) {
			logger.error("Error Occured in Persistance of Payment Request");
			primaryKey = CommonConstants.EMPTY_STRING;
		}
		return primaryKey;
	}

	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	private Object populateAndCallBackOfficeRequest(SadadPmtDtlsRq sadadRq, String category) throws Exception {
		logger.info("Core Payment Service is Starting..." + category);
		BackOfficeAccountPostingRq request = getF_IN_backOfficeRequest();
		List<PostingLeg> postingLegs = new ArrayList<>();
		PostingLeg crLeg;
		PostingLeg drLeg;
		PostingLeg taxCrLeg;
		PostingLeg taxDrLeg;
		CEUtil ceUtil = new CEUtil();
		String taxLoanAcc = EMPTY;
		if (category.equals(REPAY)) {
			loanAcc = invDtl.getF_BILLACCT();
			logger.info("loanAcc: " + loanAcc);
		} else {
			taxLoanAcc = invDtl.getF_BILLACCT();
			String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue("CESADADINTERFACE",
					"SADAD_CHG_RECEIVE_ACC");
			logger.info("chargeReceivingAccPseudonym: " + chargeReceivingAccPseudonym);
			IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOpseudonyms.BONAME, chargeReceivingAccPseudonym, true);
			String contextValue = "SAR";
			logger.info("getF_FINDERALTERNATIVE1: " + pseudDtls.getF_FINDERALTERNATIVE1());
			if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
				contextValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
				logger.info("fee contextValue" + contextValue);
			}
			List finderResult = FinderMethods.findAccountByPseudoname(chargeReceivingAccPseudonym, "SAR",
					pseudDtls.getF_FINDERALTERNATIVE1(), contextValue, BankFusionThreadLocal.getBankFusionEnvironment(),
					null);
			if (finderResult != null && !finderResult.isEmpty()) {
				loanAcc = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
				logger.info("loanAcc:" + loanAcc);
			}
			if (invDtl.getF_BILLVATAMT().compareTo(BigDecimal.ZERO) > 0) {
				String taxRecAccPseudonym = ceUtil.getModuleConfigurationValue("CESADADINTERFACE",
						"SADAD_TAX_RECEIVE_ACC");
				logger.info("Tax ReceivingAccPseudonym: " + taxRecAccPseudonym);
				IBOpseudonyms taxPseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
						.findByPrimaryKey(IBOpseudonyms.BONAME, taxRecAccPseudonym, true);
				String curctxValue = "SAR";
				logger.info("getF_FINDERALTERNATIVE1: " + taxPseudDtls.getF_FINDERALTERNATIVE1());
				if (taxPseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
					curctxValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
					logger.info("tax contextValue" + curctxValue);
				}
				List result = FinderMethods.findAccountByPseudoname(taxRecAccPseudonym, "SAR",
						taxPseudDtls.getF_FINDERALTERNATIVE1(), curctxValue,
						BankFusionThreadLocal.getBankFusionEnvironment(), null);
				if (result != null && !result.isEmpty()) {
					taxLoanAcc = ((IBOAttributeCollectionFeature) result.get(0)).getBoID();
					logger.info("taxLoanAcc:" + taxLoanAcc);
				} else {
					String errorMsg = "TaxLoanAcc not configured in Module configuration for the parameter value [Tax receiving psuedoname] in CUSTOMEXTN module !";
					logger.error(errorMsg);
					throw new Exception(errorMsg);
				}
			}
		}
		String bankAcc = getBankAcc(sadadRq);
		String drTxnCode;
		String crTxnCode;
		String drTaxCode = EMPTY;
		String crTaxCode = EMPTY;
		BigDecimal taxAmt = invDtl.getF_BILLVATAMT();
		BigDecimal feeAmt = sadadRq.getPmtAmt().subtract(taxAmt);
		BackOfficeAccountPostingRs response = null;
		try {
			if (category.equals(REPAY)) {
				drTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_DR");
				crTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_CR");
				logger.info("drTxnCode : " + drTxnCode + " # crTxnCode :" + crTxnCode);
				IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
						.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
				logger.info("loanAcc : " + loanAcc + " # bankAcc: " + bankAcc);
				crLeg = populatePostingLeg(loanAcc, feeAmt, "C", EMPTY, crTxnCode, loanAccDtl.getF_ISOCURRENCYCODE());
				drLeg = populatePostingLeg(bankAcc, feeAmt, "D", EMPTY, drTxnCode, loanAccDtl.getF_ISOCURRENCYCODE());
				postingLegs.add(crLeg);
				postingLegs.add(drLeg);
				logger.info("crLeg : " + crLeg.getTransactionCode() + " # drLeg :" + drLeg.getTransactionCode());
			} else {
				drTxnCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADFEEDRTXNCODE");
				crTxnCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADFEECRTXNCODE");
				drTaxCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADTAXDRTXNCODE");
				crTaxCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADTAXCRTXNCODE");
				logger.info("drTxnCode : " + drTxnCode + " # crTxnCode :" + crTxnCode + "drTaxCode : " + drTaxCode
						+ " # crTaxCode :" + crTaxCode);
				IBOAttributeCollectionFeature taxAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, taxLoanAcc, true);
				logger.info("taxLoanAcc : " + taxLoanAcc + " # bankAcc: " + bankAcc);
				drLeg = populatePostingLeg(bankAcc, feeAmt, "D", EMPTY, drTxnCode, taxAccDtl.getF_ISOCURRENCYCODE());
				crLeg = populatePostingLeg(loanAcc, feeAmt, "C", EMPTY, crTxnCode, taxAccDtl.getF_ISOCURRENCYCODE());
				taxDrLeg = populatePostingLeg(bankAcc, taxAmt, "D", EMPTY, drTaxCode, taxAccDtl.getF_ISOCURRENCYCODE());
				taxCrLeg = populatePostingLeg(taxLoanAcc, taxAmt, "C", EMPTY, crTaxCode,
						taxAccDtl.getF_ISOCURRENCYCODE());
				postingLegs.add(crLeg);
				postingLegs.add(drLeg);
				postingLegs.add(taxCrLeg);
				postingLegs.add(taxDrLeg);
				logger.info("taxCrLeg : " + taxCrLeg.getTransactionCode() + " # taxDrLeg :"
						+ taxDrLeg.getTransactionCode());
			}

			request.setBackOfficePostingLegs(postingLegs.toArray(new PostingLeg[0]));
			TxnDetails txnDetails = new TxnDetails();
			txnDetails.setChannelId("SADAD");
			txnDetails.setForcePost(false);
			txnDetails.setTransactionId(GUIDGen.getNewGUID());
			txnDetails.setTransactionReference(sadadRq.getBillInvoiceNo());
			Date busDate = SystemInformationManager.getInstance().getBFBusinessDate();
			logger.info("busDate: " + busDate);
			if (sadadRq.getPmtDt().before(busDate)) {
				txnDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDateTime());
				logger.info(
						"Value Date came as Back Dates hence posted value date as Current Business Date................");
			} else {
				txnDetails.setValueDate(new Timestamp(sadadRq.getPmtDt().getTime()));
			}
			request.setTxnDetails(txnDetails);
			Map params = new HashMap();
			params.put("backOfficeAccountPostingRq", request);
			HashMap result = MFExecuter.executeMF("UB_R_UB_TXN_BackOfficeAccountPosting_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), params);

			logger.info("Before BackOfficeAccountPosting");
			response = (BackOfficeAccountPostingRs) result.get("backOfficeAccountPostingRs");
			logger.info("response: " + response);
			ErrorResponse errorResponse = (ErrorResponse) result.get("ErrorResponse");
			logger.info("errorResponse: " + errorResponse);
			logger.info("Core Payment Service is Ending...");
		} catch (Exception e) {
			logger.info("Code Fetch failure: " + e.getMessage());
		}

		return response;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Object callRescheduleProfitBackOfficeRequest(SadadPmtDtlsRq sadadRq, String category) {
		logger.info("callRescheduleProfitBackOfficeRequest Service is Starting..." + category);
		BackOfficeAccountPostingRq request = getF_IN_backOfficeRequest();
		PostingLeg[] postingLegs = new PostingLeg[2];
		PostingLeg crLeg = new PostingLeg();
		PostingLeg drLeg = new PostingLeg();
		CEUtil ceUtil = new CEUtil();
		String earnedAccount = null;
		if (category.equals(REPAY)) {
			loanAcc = invDtl.getF_BILLACCT();
			logger.info("loanAcc: " + loanAcc);
			ArrayList<String> params = new ArrayList<String>();
			String whereClause = "WHERE " + IBOUB_FIN_AmortizationDetails.ACCOUNTID + " =? ";
			params.add(loanAcc);
			List<IBOUB_FIN_AmortizationDetails> amortizationDetailsList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOUB_FIN_AmortizationDetails.BONAME, whereClause, params, null, true);
			if (null != amortizationDetailsList && !amortizationDetailsList.isEmpty())
				earnedAccount = amortizationDetailsList.get(0).getF_EARNEDACCOUNTID();
		}
		IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
		if (null != earnedAccount && earnedAccount.trim().length() > 0) {
			String deferredIncome = getDeferredIncomeAcc(loanAccDtl.getF_ISOCURRENCYCODE());
			String drTxnCode = EMPTY;
			String crTxnCode = EMPTY;
			if (category.equals(REPAY)) {
				drTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_DR");
				logger.info("Inst drTxnCode:" + drTxnCode);
				crTxnCode = ceUtil.getModuleConfigurationValue("LENDING", "2149_CR");
				logger.info("Inst crTxnCode:" + crTxnCode);
			}
			crLeg = populatePostingLeg(deferredIncome, sadadRq.getPmtAmt(), "C", EMPTY, crTxnCode,
					loanAccDtl.getF_ISOCURRENCYCODE());
			logger.info("crLeg:" + crLeg);
			drLeg = populatePostingLeg(earnedAccount, sadadRq.getPmtAmt(), "D", EMPTY, drTxnCode,
					loanAccDtl.getF_ISOCURRENCYCODE());
			logger.info("drLeg:" + drLeg);
			postingLegs[0] = crLeg;
			postingLegs[1] = drLeg;
			request.setBackOfficePostingLegs(postingLegs);

			TxnDetails txnDetails = new TxnDetails();
			txnDetails.setChannelId("SADAD");
			txnDetails.setForcePost(false);
			txnDetails.setTransactionId(GUIDGen.getNewGUID());
			txnDetails.setTransactionReference(sadadRq.getBillInvoiceNo());
			Date busDate = SystemInformationManager.getInstance().getBFBusinessDate();
			logger.info("busDate: " + busDate);
			if (sadadRq.getPmtDt().before(busDate)) {
				txnDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDateTime());
				logger.info(
						"Value Date came as Back Dates hence posted value date as Current Business Date................");
			} else {
				txnDetails.setValueDate(new Timestamp(sadadRq.getPmtDt().getTime()));
			}
			request.setTxnDetails(txnDetails);
			Map params = new HashMap();
			params.put("backOfficeAccountPostingRq", request);
			HashMap result = MFExecuter.executeMF("UB_R_UB_TXN_BackOfficeAccountPosting_SRV",
					BankFusionThreadLocal.getBankFusionEnvironment(), params);

			logger.info("Before BackOfficeAccountPosting");
			BackOfficeAccountPostingRs response = (BackOfficeAccountPostingRs) result.get("backOfficeAccountPostingRs");
			logger.info("response: " + response);
			ErrorResponse errorResponse = (ErrorResponse) result.get("ErrorResponse");
			logger.info("errorResponse: " + errorResponse);
			logger.info("callRescheduleProfitBackOfficeRequest Service is Ending...");
			return response;
		}
		return null;
	}

	private String getBankAcc(SadadPmtDtlsRq sadadRq) {
		String bankAccID = EMPTY;
		CEUtil ceUtil = new CEUtil();
		String bankId = this.getGlobalPseudonym(sadadRq);
		String pseudoname = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "BANKPSEUDONAME");
		@SuppressWarnings("rawtypes")
		List result = FinderMethods.findAccountByPseudoname(pseudoname, "SAR", "BANK", bankId,
				BankFusionThreadLocal.getBankFusionEnvironment(), null);
		if (result != null && !result.isEmpty()) {
			IBOAttributeCollectionFeature bankAccDtl = (IBOAttributeCollectionFeature) result.get(0);
			bankAccID = bankAccDtl.getBoID();
		}
		logger.info("Bank ID: ;" + bankAccID + "]");
		return bankAccID;
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	private String getDeferredIncomeAcc(String currencyCode) {
		String bankAccID = EMPTY;
		CEUtil ceUtil = new CEUtil();
		String chargeReceivingAccPseudonym = ceUtil.getModuleConfigurationValue("IB", "DEFERREDINCACCT");
		logger.info("getDeferredIncomeAcc PSEUDONYM: " + chargeReceivingAccPseudonym);
		IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOpseudonyms.BONAME, chargeReceivingAccPseudonym, true);
		String contextValue = currencyCode;
		logger.info("getF_FINDERALTERNATIVE1: " + pseudDtls.getF_FINDERALTERNATIVE1());
		if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
			contextValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
			logger.info("contextValue" + contextValue);
		}
		List finderResult = FinderMethods.findAccountByPseudoname(chargeReceivingAccPseudonym, currencyCode,
				pseudDtls.getF_FINDERALTERNATIVE1(), contextValue, BankFusionThreadLocal.getBankFusionEnvironment(),
				null);
		if (finderResult != null && !finderResult.isEmpty()) {
			bankAccID = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
			logger.info("bankAccID:" + bankAccID);
		}
		return bankAccID;
	}

	private PostingLeg populatePostingLeg(String accID, BigDecimal amt, String postingAction, String narrative,
			String txnCode, String txnCur) {
		PostingLeg postingLeg = new PostingLeg();
		postingLeg.setAccountId(accID);
		postingLeg.setAmount(amt);
		postingLeg.setCreditDebitIndicator(postingAction);
		postingLeg.setNarrative(narrative);
		postingLeg.setTransactionCode(txnCode);
		postingLeg.setTransactionCurrency(txnCur);
		return postingLeg;
	}

	private String validateRequest(SadadPmtDtlsRq sadadRq) {
		logger.info("Validation of Request started...");
		String errorDesc = EMPTY;
		String billInvNo = sadadRq.getBillInvoiceNo();
		BigDecimal paymt = sadadRq.getPmtAmt();
		if (paymt.compareTo(BigDecimal.ZERO) <= 0) {
			errorDesc = "Invalid Payment Amount" + paymt;
		}
		String bankAccID = getBankAcc(sadadRq);
		if (bankAccID.equals(EMPTY)) {
			errorDesc = "Bank Account is not Configured" + bankAccID;
		}
		logger.info("Validation of Request End..." + billInvNo + " / " + bankAccID);
		return errorDesc;
	}

	private String fetchBillInvoiceNo(SadadPmtDtlsRq sadadRq) {
		String billInvoiceNo = "";
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(sadadRq.getBillAcct());
		params.add(sadadRq.getBillCategory());
		int billCycle = Integer.parseInt(sadadRq.getBillCycle());
		params.add(billCycle);
		invDtl = null;
		String whereClause = " WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND " + IBOCE_BILLINVOICE.BILLCATEGORY
				+ " = ? AND " + IBOCE_BILLINVOICE.BILLCYCLE + " = ? ORDER BY " + IBOCE_BILLINVOICE.BILLGENDATE + ", "
				+ IBOCE_BILLINVOICE.BILLCYCLE + " DESC";
		@SuppressWarnings("unchecked")
		List<IBOCE_BILLINVOICE> result = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BILLINVOICE.BONAME, whereClause, params, null, false);
		if (result != null && !result.isEmpty()) {
			billInvoiceNo = result.get(0).getF_BILLINVOICENO();
			invDtl = result.get(0);
		}
		logger.info("billInvoiceNo found [" + billInvoiceNo + "]");
		return billInvoiceNo;
	}

	private String getGlobalPseudonym(SadadPmtDtlsRq sadadRq) {
		String pseudonym = "ALLBANKSADAD";
		if (null != sadadRq.getECollectionPmtMethodDtls().getBankId()
				&& !sadadRq.getECollectionPmtMethodDtls().getBankId().isEmpty()) {
			pseudonym = sadadRq.getECollectionPmtMethodDtls().getBankId();
		}
		return pseudonym;
	}

	@SuppressWarnings("rawtypes")
	private Boolean isValidAccount(String accountId) {
		logger.info("isValidAccount begin [" + accountId + "]");
		IBOAttributeCollectionFeature loanAccDtls = (IBOAttributeCollectionFeature) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, accountId, true);
		if (loanAccDtls != null) {
			ArrayList<String> params = new ArrayList<String>();
			params.add(loanAccDtls.getBoID());
			List lenFtrResult = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME,
					" WHERE " + IBOLendingFeature.ACCOUNTID + " = ?", params, null, true);
			if (lenFtrResult != null && !lenFtrResult.isEmpty())
				loanReference = ((IBOLendingFeature) lenFtrResult.get(0)).getF_LOANREFERENCE();
			logger.info("isValidAccount loanReference [" + loanReference + "]");
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	private void prepareResponse(SadadResponse sadadRs, String status, String errorDesc) {
		SadadPmtDtlsRs sadadPmtDtlsRs = new SadadPmtDtlsRs();
		sadadPmtDtlsRs.setStatus(status);
		sadadPmtDtlsRs.setErrorDescription(errorDesc);
		sadadRs.addTransactionRs(sadadPmtDtlsRs);
	}

	@SuppressWarnings("unchecked")
	private void updateIBSadadPaymentRecord(String billInvoiceNo) {
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(billInvoiceNo);
		String whereClause = " WHERE " + IBOCE_IB_SadadPayments.IBINVOICEID + " = ?";
		List<IBOCE_IB_SadadPayments> ibSadadPayments = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_IB_SadadPayments.BONAME, whereClause, params, null, false);
		if (ibSadadPayments != null && !ibSadadPayments.isEmpty()) {
			for (IBOCE_IB_SadadPayments ibSadadPayment : ibSadadPayments) {
				ibSadadPayment.setF_IBSTATUS("PAID");
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Boolean isTransactionAvailableAlready(String paymentID, String billAccount) {
		String existingPaymentIdentiferSQL = "WHERE " + IBOCE_SadadPaymentDetails.PmtId + " = ? AND "
				+ IBOCE_SadadPaymentDetails.BillAcct + " = ? ";
		ArrayList params = new ArrayList();
		params.add(paymentID);
		params.add(billAccount);
		List<IBOCE_SadadPaymentDetails> billInvoice = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_SadadPaymentDetails.BONAME, existingPaymentIdentiferSQL, params, null, true);
		// checking bill cycle from the last recent record in bill invoice table
		if (billInvoice != null && !billInvoice.isEmpty()) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	private String getSadadPaymentID(SadadPmtDtlsRq sadadRq) {
		if (sadadRq.getECollectionPmtMethodDtls() == null) {
			ECollectionPmtMethodDtls eCollectionPmtMethodDtls = new ECollectionPmtMethodDtls();
			sadadRq.setECollectionPmtMethodDtls(eCollectionPmtMethodDtls);
		}
		String paymentId = sadadRq.getECollectionPmtMethodDtls().getPmtId() == null
				? SadadMessageConstants.SADAD_PAYMENT_ID_NOT_FOUND
				: sadadRq.getECollectionPmtMethodDtls().getPmtId();
		return paymentId;
	}

}