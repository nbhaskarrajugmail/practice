package com.ce.ffcutils;

public class CEConstants {
	
	public static final String EMPTY = "";
	public static final String  SADADSUCCESSCODE = "I000000";

}
