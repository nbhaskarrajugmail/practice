package com.ce.ffcutils;

import static com.ce.adf.CEConstants.EMPTY;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.cbs.config.ModuleConfiguration;

public class CEUtil {
	static DateFormat expDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
	// List of all date formats that we want to parse.
	@SuppressWarnings("serial")
	private List<SimpleDateFormat> dateFormats = new ArrayList<SimpleDateFormat>() {
		{
			add(new SimpleDateFormat("yyyy/MM/dd"));
			add(new SimpleDateFormat("dd-MM-yyyy HH:mm:ss"));
			add(new SimpleDateFormat("dd-MM-yyyy"));
		}
	};

	public String convertStringToDate(String input) {
		String formatedDate = null;
		Date date = null;
		if (isNotEmpty(input)) {
			for (SimpleDateFormat format : dateFormats) {
				try {
					format.setLenient(false);
					date = format.parse(input);
					formatedDate = expDateFormat.format(date);
				} catch (ParseException e) {
				}
				if (formatedDate != null)
					break;
			}
		}
		return formatedDate;
	}

	public static Boolean isNotEmpty(String input) {
		if (input == null || input == EMPTY || input.isEmpty() || input.equalsIgnoreCase("null"))
			return false;
		else
			return true;
	}

	public static String getDate() throws Exception {
		Calendar cal = Calendar.getInstance();
		return expDateFormat.format(cal.getTime());
	}
}
