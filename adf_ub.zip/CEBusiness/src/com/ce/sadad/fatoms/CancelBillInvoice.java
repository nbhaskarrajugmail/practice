package com.ce.sadad.fatoms;

import static com.ce.adf.CEConstants.EMPTY;
import static com.ce.adf.CEConstants.F;
import static com.ce.adf.CEConstants.S;
import static com.ce.sadad.util.SadadMessageConstants.C_INV;
import static com.ce.sadad.util.SadadMessageConstants.EXPIRE;
import static com.ce.sadad.util.SadadMessageConstants.REPAY;
import static com.ce.sadad.util.SadadMessageConstants.SADADSUCCESSCODE;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_CancelBillInvoice;

/**
 * Class is part of EOD process to Cancel Bill Invoice based on various
 * condition.
 * 
 * @author Prasanna Kumar S
 */
public class CancelBillInvoice extends AbstractCE_CancelBillInvoice {

	private static final long serialVersionUID = 1L;
	private transient final static Log logger = LogFactory.getLog(CancelBillInvoice.class.getName());
	private IPersistenceObjectsFactory factory;
	static String strInvGenDaysBefore = "1";

	private static String UPDATE_BILL_INV_WHERECLAUSE = " WHERE  " + IBOCE_BILLINVOICE.ID + "=?";

	private static String FETCH_EXPIRED_BILLINVOICE = "WHERE " + IBOCE_BILLINVOICE.BILLACTION + " <> ? AND "
			+ IBOCE_BILLINVOICE.BILLAMT + " > ? AND " + IBOCE_BILLINVOICE.BILLCATEGORY + " = ? AND "
			+ IBOCE_BILLINVOICE.BILLGENDATE + " <> ?";

	private static String FETCH_BILLINVOICE = "WHERE " + IBOCE_BILLINVOICE.BILLACTION + " <> ? AND "
			+ IBOCE_BILLINVOICE.BILLAMT + " <= ? AND " + IBOCE_BILLINVOICE.BILLCATEGORY + " = ?";

	private static String BILL_INV_WHERECLAUSE = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";

	private static String LOAN_NEXT_SCHEDULE_FETCH = "WHERE  " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " = ? AND "
			+ IBOLN_LEN_LoanSchedule.PAYMENTDT + " > ? ORDER BY " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " ASC";

	private static String GENERIC_QUERY_BILLINVOICE = "SELECT cb." + IBOCE_BILLINVOICE.BILLINVOICENO
			+ " AS BILLINVOICENO, cb." + IBOCE_BILLINVOICE.BILLACCT + " AS BILLACCT, cb." + IBOCE_BILLINVOICE.BILLACTION
			+ " AS BILLACTION, cb." + IBOCE_BILLINVOICE.BILLAMT + " AS BILLAMT, cb." + IBOCE_BILLINVOICE.BILLCATEGORY
			+ " as BILLCATEGORY, cb." + IBOCE_BILLINVOICE.ID + " as ID from " + IBOCE_BILLINVOICE.BONAME + " cb,"
			+ IBOLN_LEN_LoanSchedule.BONAME + " ll where " + "cb." + IBOCE_BILLINVOICE.BILLACCT + " = ll."
			+ IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " and (cb." + IBOCE_BILLINVOICE.BILLDUEDATE + "+"
			+ strInvGenDaysBefore + ")=ll." + IBOLN_LEN_LoanSchedule.PAYMENTDT + " and cb."
			+ IBOCE_BILLINVOICE.BILLACTION + " <> ?  AND cb." + IBOCE_BILLINVOICE.BILLCATEGORY + "=?";

	@SuppressWarnings("deprecation")
	public CancelBillInvoice(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		logger.info("Inside CancelBillInvoice process()");
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		Date date = new Date(0);// To remove
		cancelBillInvoice(date, true, env);
	}

	@SuppressWarnings("unchecked")
	private void cancelBillInvoice(Date lastSuccessDate, boolean onlyForDay, BankFusionEnvironment env) {
		logger.info("Inside cancelBillInvoice");
		Map<String, Boolean> invoiceMap = new HashMap<String, Boolean>();
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = GUIDGen.getNewGUID();
		ArrayList<Object> params = new ArrayList<Object>();
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		params.add(EXPIRE);
		params.add("0");
		params.add(REPAY);
		params.add(today);
		// cancel the unpaid bill on before next due date
		List<IBOCE_BILLINVOICE> expiredInvoiceList = (List<IBOCE_BILLINVOICE>) factory
				.findByQuery(IBOCE_BILLINVOICE.BONAME, FETCH_EXPIRED_BILLINVOICE, params, null, true);
		for (IBOCE_BILLINVOICE expiredBillInvoice : expiredInvoiceList) {
			if (this.isNextScheduleInDue(expiredBillInvoice)) {
				InvoiceData data = new InvoiceData();
				expiredBillInvoice.setF_BILLACTION(EXPIRE);
				expiredBillInvoice.setF_BILLEXPDATE(SystemInformationManager.getInstance().getBFBusinessDate());
				data.setBillAccount(expiredBillInvoice.getF_BILLACCT());
				data.setBillAction(expiredBillInvoice.getF_BILLACTION());
				data.setBillAmount(expiredBillInvoice.getF_BILLAMT());
				data.setBillCategory(expiredBillInvoice.getF_BILLCATEGORY());
				int billCycle = 0;
				if (expiredBillInvoice.getBoID().contains("_")) {
					billCycle = Integer.parseInt(expiredBillInvoice.getBoID().split("_")[1]);
				} else {
					billCycle = BillInvoiceHelper.billInvoiceCycle(expiredBillInvoice.getF_BILLACCT(),
							expiredBillInvoice.getF_BILLDUEDATE());
				}
				data.setBillCycle(billCycle);
				data.setInvoiceId(expiredBillInvoice.getF_BILLINVOICENO());
				data.setDueDate(expiredBillInvoice.getF_BILLDUEDATE());

				invoiceMap.put(expiredBillInvoice.getBoID(), Boolean.TRUE);
				billInfoList.add(data);
			}
		}

		params = new ArrayList<Object>();
		params.add(EXPIRE);
		params.add("0");
		params.add(REPAY);
		// cancel the fully paid bill
		List<IBOCE_BILLINVOICE> invoiceList = (List<IBOCE_BILLINVOICE>) factory.findByQuery(IBOCE_BILLINVOICE.BONAME,
				FETCH_BILLINVOICE, params, null, true);
		for (IBOCE_BILLINVOICE invoiceData : invoiceList) {
			if (invoiceMap.containsKey(invoiceData.getBoID())) {
				// avoid adding multiple entries to SADAD on same bill account;
				continue;
			}
			InvoiceData data = new InvoiceData();
			invoiceData.setF_BILLACTION(EXPIRE);
			invoiceData.setF_BILLEXPDATE(SystemInformationManager.getInstance().getBFBusinessDate());
			data.setBillAccount(invoiceData.getF_BILLACCT());
			data.setBillAction(invoiceData.getF_BILLACTION());
			data.setBillAmount(invoiceData.getF_BILLAMT());
			data.setBillCategory(invoiceData.getF_BILLCATEGORY());
			int billCycle = 0;
			if (invoiceData.getBoID().contains("_")) {
				billCycle = Integer.parseInt(invoiceData.getBoID().split("_")[1]);
			} else {
				billCycle = BillInvoiceHelper.billInvoiceCycle(invoiceData.getF_BILLACCT(),
						invoiceData.getF_BILLDUEDATE());
			}
			data.setBillCycle(billCycle);
			data.setInvoiceId(invoiceData.getF_BILLINVOICENO());
			data.setDueDate(invoiceData.getF_BILLDUEDATE());
			invoiceMap.put(invoiceData.getBoID(), Boolean.TRUE);
			billInfoList.add(data);
		}

		params = new ArrayList<Object>();
		params.add(EXPIRE);
		params.add(REPAY);
		List<SimplePersistentObject> invoiceList1 = (List<SimplePersistentObject>) factory
				.executeGenericQuery(GENERIC_QUERY_BILLINVOICE, params, null, true);
		if (invoiceList1 != null) {
			for (SimplePersistentObject invoiceData1 : invoiceList1) {
				InvoiceData data = new InvoiceData();
				logger.info("Values:::" + invoiceData1.getDataMap().get("BILLINVOICENO"));
				String billInvoiceId = (String) invoiceData1.getDataMap().get("ID");
				if (invoiceMap.containsKey(billInvoiceId)) {
					// avoid adding multiple entries to SADAD on same bill account;
					continue;
				}
				ArrayList<Object> params2 = new ArrayList<>();
				params2.add(billInvoiceId);
				IBOCE_BILLINVOICE billInvoiceRecord = (IBOCE_BILLINVOICE) BankFusionThreadLocal.getPersistanceFactory()
						.findFirstByQuery(IBOCE_BILLINVOICE.BONAME, BILL_INV_WHERECLAUSE, params2, true);

				updateBillInvoiceDtls(billInvoiceId, EXPIRE);
				data.setBillAccount((String) invoiceData1.getDataMap().get("BILLACCT"));
				data.setBillAction((String) invoiceData1.getDataMap().get("BILLACTION"));
				data.setBillAmount((BigDecimal) invoiceData1.getDataMap().get("BILLAMT"));
				data.setBillCategory((String) invoiceData1.getDataMap().get("BILLCATEGORY"));
				int billCycle = 0;
				if (billInvoiceId.contains("_")) {
					billCycle = Integer.parseInt(billInvoiceId.split("_")[1]);
				} else {
					billCycle = BillInvoiceHelper.billInvoiceCycle(billInvoiceRecord.getF_BILLACCT(),
							billInvoiceRecord.getF_BILLDUEDATE());
				}
				data.setBillCycle(billCycle);
				data.setInvoiceId((String) invoiceData1.getDataMap().get("BILLINVOICENO"));
				data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());
				billInfoList.add(data);
			}
		}

		logger.info("billInfoList Size:::" + billInfoList);
		logger.info("Before calling build Cancel" + reqID);
		String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billInfoList, SadadMessageConstants.REPAY,
				reqID);
		logger.info("After calling build Cancel: " + message);

		SadadWebService wsCall = new SadadWebService();
		String response = null;
		String statusCode = null;
		try {
			logger.info("Before calling SADAD Cancel");
			response = wsCall.callSADAD(message, SadadMessageConstants.INVOICE);
			logger.info("After calling SADAD Cancel: " + response);
			statusCode = GenSADADReq.getStatusCode(response);
			logger.info("statusCode: " + statusCode);
		} catch (IOException | SOAPException e) {
			logger.error(e);
			if (e instanceof SOAPException)
				statusCode = "Webservice Connection Error";
			if (e instanceof IOException)
				statusCode = "Input Output Error";
			e.printStackTrace();
		}

		// Logging Job Status and output parameters
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(reqID);
		jobStatus.setJobId(C_INV);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		if (null != statusCode && !statusCode.isEmpty() && statusCode.equals(SADADSUCCESSCODE)) {
			jobStatus.setJobStatus(S);
			setF_OUT_Success(Boolean.TRUE);
		} else {
			jobStatus.setJobStatus(F);
			setF_OUT_Success(Boolean.TRUE);
		}
		jobStatus.setStatusDesc(statusCode);
		jobStatus.setRecordCount(invoiceList.size());
		ManageJobStatus.insertJobStatus(jobStatus);

		setF_OUT_ErrorCode(statusCode);
		setF_OUT_ErrorDesc(statusCode);
	}

	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return EMPTY;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateBillInvoiceDtls(String id, String billAction) {
		ArrayList columns = new ArrayList();
		columns.add(IBOCE_BILLINVOICE.BILLACTION);
		columns.add(IBOCE_BILLINVOICE.BILLEXPDATE);

		ArrayList paramValues = new ArrayList();
		paramValues.add(billAction);
		paramValues.add(SystemInformationManager.getInstance().getBFBusinessDate());

		ArrayList params = new ArrayList();
		params.add(id);
		this.factory.bulkUpdate(IBOCE_BILLINVOICE.BONAME, UPDATE_BILL_INV_WHERECLAUSE, params, columns, paramValues);
	}

	private Boolean isNextScheduleInDue(IBOCE_BILLINVOICE billinvoice) {
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		Date dueDate = billinvoice.getF_BILLDUEDATE();
		if (today.compareTo(dueDate) <= 0 || CEDateHelper.areDatesSame(dueDate, today)) {
			return Boolean.FALSE;
		}
		String loanAcc = billinvoice.getF_BILLACCT();
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		params.add(dueDate);
		@SuppressWarnings("unchecked")
		List<IBOLN_LEN_LoanSchedule> loanSchedules = (List<IBOLN_LEN_LoanSchedule>) factory
				.findByQuery(IBOLN_LEN_LoanSchedule.BONAME, LOAN_NEXT_SCHEDULE_FETCH, params, null, true);

		if (loanSchedules != null && loanSchedules.size() > 0 && loanSchedules.get(0) != null) {
			IBOLN_LEN_LoanSchedule loanSchedule = loanSchedules.get(0);
			Date nextPaymentDate = loanSchedule.getF_PAYMENTDT();
			Date tomorrow = AddDaysToDate.run(1, today);
			if (CEDateHelper.areDatesSame(nextPaymentDate, tomorrow)) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

}