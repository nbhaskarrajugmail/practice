package com.ce.sadad.fatoms;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.common.GUIDGen;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_UpdateBillInvoice;

public class UpdateBillInvoice extends AbstractCE_UpdateBillInvoice {

	private static final long serialVersionUID = 1L;

	private static String FETCH_RECORDS_QUERY = "SELECT ce." + IBOCE_BILLINVOICE.ID + " AS ID,ce."
			+ IBOCE_BILLINVOICE.BILLAMT + " AS BILLAMT,ce." + IBOCE_BILLINVOICE.BILLACCT + " AS BILLACCT,ce."
			+ IBOCE_BILLINVOICE.BILLACTION + " AS BILLACTION,ce." + IBOCE_BILLINVOICE.BILLCATEGORY
			+ " AS BILLCATEGORY,sum(l." + IBOLoanRepayments.REPAYMENTPAID + ") AS REPAYMENTPAID FROM "
			+ IBOCE_BILLINVOICE.BONAME + " ce, " + IBOLoanRepayments.BONAME + " l WHERE l."
			+ IBOLoanRepayments.ACCOUNTID + "=ce." + IBOCE_BILLINVOICE.BILLACCT + " AND l." + IBOLoanRepayments.PAIDDATE
			+ " BETWEEN ? AND  ? AND ce." + IBOCE_BILLINVOICE.BILLACTION + " <> ? GROUP BY l."
			+ IBOLoanRepayments.ACCOUNTID + ",ce." + IBOCE_BILLINVOICE.BILLACCT + ",ce." + IBOCE_BILLINVOICE.ID + ",ce."
			+ IBOCE_BILLINVOICE.BILLAMT + ",ce." + IBOCE_BILLINVOICE.BILLACTION + ",ce."
			+ IBOCE_BILLINVOICE.BILLCATEGORY;

	private static String SELECT_WHERE_QUERY = " WHERE " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " BETWEEN ? AND  ?";

	private static String BILL_INV_WHERECLAUSE = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";

	private transient final static Log logger = LogFactory.getLog(UpdateBillInvoice.class.getName());

	@SuppressWarnings("deprecation")
	public UpdateBillInvoice(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		logger.info("Inside Update Bill Invoice process");
		updateBillInvoice(env);
	}

	@SuppressWarnings("unchecked")
	public void updateBillInvoice(BankFusionEnvironment env) {
		Map<String, Boolean> invoiceMap = new HashMap<String, Boolean>();
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = GUIDGen.getNewGUID();

		Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
		ArrayList<Object> params = new ArrayList<>();
		ArrayList<Object> params1 = new ArrayList<>();

		int gracePeriod = 0;
		try {
			gracePeriod = BillInvoiceHelper.getGracePeriod();
			Date lastSuccessDate = ManageJobStatus.getLastSuccessDate(SadadMessageConstants.U_INV);
			if (lastSuccessDate != null) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(lastSuccessDate);
				cal.add(Calendar.DATE, 1);
				Date runDateFrom = cal.getTime();
				params.add(runDateFrom);
				params1.add(runDateFrom);
			} else {
				params.add(businessDate);
				params1.add(businessDate);
			}
			params.add(businessDate);
			params1.add(businessDate);
			params.add(SadadMessageConstants.EXPIRE);
			List<SimplePersistentObject> billInvoiceList = BankFusionThreadLocal.getPersistanceFactory()
					.executeGenericQuery(FETCH_RECORDS_QUERY, params, null, false);
			if (null != billInvoiceList && billInvoiceList.size() != 0) {
				logger.info("Here Inside if " + billInvoiceList.size());

				IBOLN_LEN_LoanSchedule schedules = (IBOLN_LEN_LoanSchedule) BankFusionThreadLocal
						.getPersistanceFactory()
						.findFirstByQuery(IBOLN_LEN_LoanSchedule.BONAME, SELECT_WHERE_QUERY, params1, true);

				if (schedules == null) {
					this.updateJobStatus(reqID, CEConstants.S, "No records", 0);
					setF_OUT_Status(Boolean.TRUE);
					return;
				}

				for (int i = 0; i < billInvoiceList.size(); i++) {
					Map<Object, Object> dataMap = ((SimplePersistentObject) billInvoiceList.get(i)).getDataMap();

					String billAction = (String) dataMap.get("BILLACTION");
					String billInvoiceId = (String) dataMap.get("ID");
					ArrayList<Object> paramsInner = new ArrayList<>();
					paramsInner.add((String) dataMap.get("ID"));
					IBOCE_BILLINVOICE billInvoiceRecord = (IBOCE_BILLINVOICE) BankFusionThreadLocal
							.getPersistanceFactory()
							.findFirstByQuery(IBOCE_BILLINVOICE.BONAME, BILL_INV_WHERECLAUSE, paramsInner, true);

					BigDecimal existingBillInvoiceAmt = (BigDecimal) dataMap.get("BILLAMT");
					BigDecimal repaymentAmt = (BigDecimal) dataMap.get("REPAYMENTPAID");
					BigDecimal finalBillAmount = existingBillInvoiceAmt;

					// if grace period expired then customer will loose the subsidy
					BigDecimal subsidyAmount = this.calculateSubsidy(billInvoiceRecord);
					finalBillAmount = finalBillAmount.add(subsidyAmount);
					billAction = SadadMessageConstants.UPDATE;

					if (repaymentAmt.compareTo(BigDecimal.ZERO) > 0) {
						// skip this bill invoice since there's no update
						finalBillAmount = finalBillAmount.subtract(repaymentAmt);
					}

					// avoid raising an update when there's no diff in amount
					if ((finalBillAmount.subtract(existingBillInvoiceAmt)).compareTo(BigDecimal.ZERO) != 0) {
						// amount can be negative on only when the amount is fully paid on or before
						// subsidy expire date
						if (finalBillAmount.compareTo(BigDecimal.ZERO) <= 0) {
							billAction = SadadMessageConstants.EXPIRE;
							finalBillAmount = BigDecimal.ZERO;
						}
						updateBillInvoiceDtls((String) dataMap.get("ID"), finalBillAmount, billAction);
						InvoiceData data = new InvoiceData();
						data.setBillAccount((String) dataMap.get("BILLACCT"));
						data.setBillAction(billAction);
						data.setBillCategory((String) dataMap.get("BILLCATEGORY"));
						data.setBillAmount(finalBillAmount);
						int billCycle = BillInvoiceHelper.billInvoiceCycle(data.getBillAccount(),
								billInvoiceRecord.getF_BILLDUEDATE());
						data.setBillCycle(billCycle);
						data.setInvoiceId(billInvoiceRecord.getF_BILLINVOICENO());
						data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());
						billInfoList.add(data);
					}
					invoiceMap.put(billInvoiceId, Boolean.TRUE);
				}
			}

			// Subsidy expire check on all bill invoice
			// note : repayments & corresponding subsidy calculations are done in the above
			// step already
			java.sql.Date today = this.getTodaySqlDatewithTimeZero();
			java.sql.Date subsidyExpireDate = this.getSqlDatewithTimeZero(lastSuccessDate);
			subsidyExpireDate = AddDaysToDate.run(1, this.getSqlDatewithTimeZero(lastSuccessDate));
			while (subsidyExpireDate.compareTo(today) <= 0) {
				ArrayList<Object> params2 = new ArrayList<>();
				params2.add(subsidyExpireDate);
				params2.add(SadadMessageConstants.EXPIRE);
				String billInvoiceSubsidyExpiryCheckSQL = "WHERE (" + IBOCE_BILLINVOICE.BILLDUEDATE + " + "
						+ gracePeriod + ") = ? AND " + IBOCE_BILLINVOICE.BILLACTION + " <> ?";
				List<IBOCE_BILLINVOICE> billinvoices = (List<IBOCE_BILLINVOICE>) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceSubsidyExpiryCheckSQL, params2, null, true);
				for (IBOCE_BILLINVOICE billInvoice : billinvoices) {
					// skip if already calculated
					if (!invoiceMap.containsKey(billInvoice.getBoID())) {
						BigDecimal subsidyAmount = this.calculateSubsidy(billInvoice);
						// prepare bill invoice update data
						if (subsidyAmount.compareTo(BigDecimal.ZERO) > 0) {
							BigDecimal finalBillAmount = billInvoice.getF_BILLAMT().add(subsidyAmount);
							billInvoice.setF_BILLAMT(finalBillAmount);
							InvoiceData data = new InvoiceData();
							data.setBillAccount(billInvoice.getF_BILLACCT());
							data.setBillAction(SadadMessageConstants.UPDATE);
							data.setBillCategory(billInvoice.getF_BILLCATEGORY());
							data.setBillAmount(finalBillAmount);
							int billCycle = 0;
							if (billInvoice.getBoID().contains("_")) {
								billCycle = Integer.parseInt(billInvoice.getBoID().split("_")[1]);
							} else {
								billCycle = BillInvoiceHelper.billInvoiceCycle(billInvoice.getF_BILLACCT(),
										billInvoice.getF_BILLDUEDATE());
							}
							data.setBillCycle(billCycle);
							data.setInvoiceId(billInvoice.getF_BILLINVOICENO());
							data.setDueDate(billInvoice.getF_BILLDUEDATE());
							billInvoice.setF_BILLACTION(SadadMessageConstants.UPDATE);
							billInfoList.add(data);
						}
					}
				}
				subsidyExpireDate = AddDaysToDate.run(1, subsidyExpireDate);
			}

			if (billInfoList != null && billInfoList.size() > 0) {
				logger.info("After fetching Invoice details" + billInvoiceList.size());
				logger.info("Before calling build Update" + reqID);
				String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billInfoList,
						SadadMessageConstants.REPAY, reqID);
				logger.info("After calling build Update: " + message);

				SadadWebService wsCall = new SadadWebService();
				String response = null;
				String statusCode = null;
				try {
					logger.info("Before calling SADAD Update");
					response = wsCall.callSADAD(message, SadadMessageConstants.INVOICE);
					logger.info("After calling SADAD Update: " + response);
					statusCode = GenSADADReq.getStatusCode(response);
					logger.info("statusCode: " + statusCode);
				} catch (IOException | SOAPException e) {
					logger.error(e);
					if (e instanceof SOAPException)
						statusCode = "Webservice Connection Error";
					if (e instanceof IOException)
						statusCode = "I/O Error";
					e.printStackTrace();
				}
				String status = CEConstants.F;
				if (null != statusCode && !statusCode.isEmpty()
						&& statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
					status = CEConstants.S;
				}
				this.updateJobStatus(reqID, status, statusCode, billInfoList.size());
			} else {
				this.updateJobStatus(reqID, CEConstants.S, "No records", 0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.updateJobStatus(reqID, CEConstants.F, "SUBSIDY_GRACE_PERIOD - MISSING", 0);
			setF_OUT_Status(Boolean.TRUE);
			return;
		}
		setF_OUT_Status(Boolean.TRUE);
	}

	private void updateBillInvoiceDtls(String id, BigDecimal amount, String billAction) {
		ArrayList<Object> columns = new ArrayList<>();
		columns.add(IBOCE_BILLINVOICE.BILLACTION);
		columns.add(IBOCE_BILLINVOICE.BILLAMT);

		ArrayList<Object> paramValues = new ArrayList<>();
		paramValues.add(billAction);
		paramValues.add(amount);

		ArrayList<Object> params = new ArrayList<>();
		params.add(id);
		BankFusionThreadLocal.getPersistanceFactory().bulkUpdate(IBOCE_BILLINVOICE.BONAME, BILL_INV_WHERECLAUSE, params,
				columns, paramValues);
	}

	private BigDecimal calculateSubsidy(IBOCE_BILLINVOICE billInvoice) throws Exception {
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		int gracePeriod = BillInvoiceHelper.getGracePeriod();
		java.sql.Date today = this.getTodaySqlDatewithTimeZero();
		java.sql.Date gracePeriodDate = AddDaysToDate.run(gracePeriod, billInvoice.getF_BILLDUEDATE());

		// if grace period is expired then deduct subsidy
		List<IBOCE_IB_PaymentSchBreakup> schBreakDtlList = null;
		if (today.compareTo(gracePeriodDate) == 0) {
			schBreakDtlList = BillInvoiceHelper.getSchBreakUp(billInvoice.getF_BILLACCT(),
					billInvoice.getF_BILLDUEDATE());
			if (schBreakDtlList != null && !schBreakDtlList.isEmpty()) {
				for (IBOCE_IB_PaymentSchBreakup payBreakup : schBreakDtlList) {
					if (payBreakup.getF_IBSUBSIDYAMNT() != null
							&& payBreakup.getF_IBSUBSIDYAMNT().compareTo(BigDecimal.ZERO) > 0) {
						subsidyAmount = subsidyAmount.add(payBreakup.getF_IBSUBSIDYAMNT());
					}
				}
			}
		}
		return subsidyAmount;
	}

	private java.sql.Date getTodaySqlDatewithTimeZero() {
		Date datetime = SystemInformationManager.getInstance().getBFBusinessDate();
		return CEDateHelper.utilDateToSqlDate(datetime);
	}

	private java.sql.Date getSqlDatewithTimeZero(Date datetime) {
		return CEDateHelper.utilDateToSqlDate(datetime);
	}

	private void updateJobStatus(String reqID, String status, String desc, int recordCount) {
		// Logging Job Status and output parameters
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(reqID);
		jobStatus.setJobId(SadadMessageConstants.U_INV);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		jobStatus.setJobStatus(status);
		jobStatus.setStatusDesc(desc);
		jobStatus.setRecordCount(recordCount);
		ManageJobStatus.insertJobStatus(jobStatus);
	}

}