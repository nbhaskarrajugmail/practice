package com.ce.sadad.fatoms;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import static com.ce.adf.CEConstants.*;
import static com.ce.sadad.util.SadadMessageConstants.*;
import com.ce.sadad.util.GenSADADAcctMngReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAccount;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_JOBSTATUS;
import com.trapedza.bankfusion.bo.refimpl.IBOCustomer;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_RegisterAccountToSADAD;


/** Class is part of EOD process to collect accounts of present business day and register to SADAD
 * 
 * @author Subhajit */
public class RegisterAccountToSADAD extends AbstractCE_RegisterAccountToSADAD {

	private static final long serialVersionUID = 1L;
	private transient final static Log logger = LogFactory.getLog(RegisterAccountToSADAD.class
			.getName());
	private IPersistenceObjectsFactory factory;

	private static String FETCH_ACCOUNTS = "SELECT A." + IBOAttributeCollectionFeature.ACCOUNTID
			+ " AS ACCOUNTID " + " FROM " + IBOAttributeCollectionFeature.BONAME + " A, "
			+ IBOCustomer.BONAME + " C WHERE A." + IBOAccount.OPENDATE + " > ? AND A."
			+ IBOAttributeCollectionFeature.CUSTOMERCODE + " = C." + IBOCustomer.CUSTOMERCODE
			+ " AND C." + IBOCustomer.CUSTOMERTYPE + " <> 'I' ";

	private static String FETCH_ACCOUNTS_ONEDAY = "SELECT A." + IBOAttributeCollectionFeature.ACCOUNTID
			+ " AS ACCOUNTID " + " FROM " + IBOAttributeCollectionFeature.BONAME + " A, "
			+ IBOCustomer.BONAME + " C WHERE A." + IBOAccount.OPENDATE + " = ? AND A."
			+ IBOAttributeCollectionFeature.CUSTOMERCODE + " = C." + IBOCustomer.CUSTOMERCODE
			+ " AND C." + IBOCustomer.CUSTOMERTYPE + " <> 'I' ";

	private static String LAST_SUCCESS_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND "
			+ IBOCE_JOBSTATUS.JOBSTATUS + " = 'Success' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE
			+ " DESC ";

	private static String FIRST_FAIL_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND "
			+ IBOCE_JOBSTATUS.JOBSTATUS + " = 'Failed' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE
			+ " ASC ";

	public RegisterAccountToSADAD(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	public void process(BankFusionEnvironment env) throws BankFusionException {
		logger.info("Inside RegisterAccountToSADAD process()");
		
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		if (isF_IN_AdhocRun()) {
			registerOpenedAccounts(getF_IN_AccountOpenRunDate(), true);
			return;
		}
		Date lastSuccessDate = getLastSuccessDate();
		if (null == lastSuccessDate) {
			lastSuccessDate = SystemInformationManager.getInstance().getBFBusinessDate();
			registerOpenedAccounts(lastSuccessDate, true);
		}
		registerOpenedAccounts(lastSuccessDate, false);
	}

	private Date getLastSuccessDate() {

		ArrayList params = new ArrayList();
		params.add(getF_IN_JOBID().trim());
		IBOCE_JOBSTATUS jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME,
				LAST_SUCCESS_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			return jobStatus.getF_JOBEXECDATE();
		}
		
		logger.info("getLastSuccessDate Query: "+FIRST_FAIL_DATE);
		logger.info("JOB ID: "+getF_IN_JOBID().trim());

		jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, FIRST_FAIL_DATE,
				params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			Date date = jobStatus.getF_JOBEXECDATE();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, -1);
			date = new Date(cal.getTime().getTime());
			return date;
		}
		return null;
	}

	private void registerOpenedAccounts(Date openDate, boolean onlyForDay) {
		ArrayList<Date> params = new ArrayList<Date>();
		params.add(openDate);
		List<SimplePersistentObject> accountList = null;
		if (onlyForDay) {
			accountList = factory.executeGenericQuery(FETCH_ACCOUNTS_ONEDAY, params, null, true);
		} else {
			accountList = factory.executeGenericQuery(FETCH_ACCOUNTS, params, null, true);
		}
		if (null == accountList || accountList.isEmpty())
			return;

		String requestId = GUIDGen.getNewGUID();
		//String message = XMLMessageGenerator.generateManageAccountMsg(accountList, requestId);
		logger.info("Before calling build Acct Mng");
		String message = GenSADADAcctMngReq.generateSOAPRequest(accountList, requestId);
		logger.info("After calling build Acct Mng: "+message);
		
		SadadWebService wsCall = new SadadWebService();
		String response = null;
		String statusCode = null;
		try {
			logger.info("Before calling SADAD Acct Mng");
			response = wsCall.callSADAD(message, SadadMessageConstants.REG_ACCT);
			logger.info("After calling SADAD Acct Mng: "+response);
			statusCode = GenSADADReq.getStatusCode(response);
		} catch (IOException | SOAPException e) {
			logger.error(e);
			if(e instanceof SOAPException)
				statusCode = "Webservice Connection Error";
			if(e instanceof IOException)
				statusCode = "Input Output Error";
			e.printStackTrace();
		}
		
		// Logging Job Status and output parameters
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(getF_IN_JOBID());
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		if (null != statusCode && !statusCode.isEmpty() && statusCode.equals(SADADSUCCESSCODE)){
			jobStatus.setJobStatus(S);
			setF_OUT_Success(Boolean.TRUE);
		}
		else {
			jobStatus.setJobStatus(F);
			setF_OUT_Success(Boolean.TRUE);
		}
		jobStatus.setStatusDesc(statusCode);
		jobStatus.setRecordCount(accountList.size());
		ManageJobStatus.insertJobStatus(jobStatus);

		setF_OUT_ErrorCode(statusCode);
		setF_OUT_ErrorDescription(statusCode);
	}

	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return EMPTY;
	}
}
