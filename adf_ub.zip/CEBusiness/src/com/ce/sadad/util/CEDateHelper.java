package com.ce.sadad.util;

import java.sql.Date;
import java.util.Calendar;

public class CEDateHelper {

	/**
	 * Compares ONLY Year,Month & Day of given dates
	 * 
	 * @param date1
	 * @param date2
	 * @return {@link Boolean}
	 */
	public static boolean areDatesSame(Date date1, Date date2) {
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date1);
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date2);
		if (cal1.get(Calendar.YEAR) != cal2.get(Calendar.YEAR))
			return false;
		if (cal1.get(Calendar.MONTH) != cal2.get(Calendar.MONTH))
			return false;
		if (cal1.get(Calendar.DATE) != cal2.get(Calendar.DATE))
			return false;
		return true;
	}

	/**
	 * Converts {@link java.util.Date} to {@link java.sql.Date}
	 * 
	 * @param date
	 * @return {@link java.sql.Date}
	 */
	public static java.sql.Date utilDateToSqlDate(java.util.Date utilDate) {
		java.util.Calendar cal = Calendar.getInstance();
		cal.setTime(utilDate);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return new java.sql.Date(cal.getTime().getTime());
	}

}