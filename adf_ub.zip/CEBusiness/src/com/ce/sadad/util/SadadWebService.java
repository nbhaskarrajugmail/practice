package com.ce.sadad.util;

import static com.ce.adf.CEConstants.*;
import static com.ce.sadad.util.SadadMessageConstants.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.cbs.config.ModuleConfiguration;
public class SadadWebService {

	private transient final static Log logger = LogFactory.getLog(SadadWebService.class.getName());
	
	String SOAPAction = "";
	String wsURL = "";

	/**
	 * Calls the Sadad Web Service for Registering Account
	 * @param request
	 * @return
	 * @throws IOException
	 * @throws SOAPException
	 */
	public String callSADAD(String request, String serviceName) throws IOException, SOAPException{
		String wsEndPoint = EMPTY;
		String wsAction = EMPTY;
		if(SadadMessageConstants.REG_ACCT.equalsIgnoreCase(serviceName)){
			wsEndPoint = (String) ModuleConfiguration.getInstance().
					getModuleConfigurationValue(CE_SADAD_INTERFACE, MANAGEACCOUNTURL);
			wsAction = (String) ModuleConfiguration.getInstance().
					getModuleConfigurationValue(CE_SADAD_INTERFACE, ACCT_NAMESPACE);
		}
		else if(SadadMessageConstants.INVOICE.equalsIgnoreCase(serviceName)){
			wsEndPoint = (String) ModuleConfiguration.getInstance().
					getModuleConfigurationValue(CE_SADAD_INTERFACE, BILL_INVOICE_URL);
			wsAction = (String) ModuleConfiguration.getInstance().
					getModuleConfigurationValue(CE_SADAD_INTERFACE, BILL_NAMESPACE);
		}
		logger.info("wsEndPoint: "+wsEndPoint);
		SOAPAction = wsAction;
		wsURL = wsEndPoint;
		return pushRequest(request);
	}
	
	/** @param xmlInput
	 * @return
	 * @throws IOException */
	public String pushRequest(String xmlInput) throws IOException, SOAPException {
		logger.info("Inside pushRequest: "+wsURL);
		SOAPMessage reply = null;
		SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
		SOAPConnection connection = soapConnFactory.createConnection();
		SOAPMessage msg = getMsg(xmlInput);
		reply = connection.call(msg, wsURL);
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		reply.writeTo(stream);
		String outputString = new String(stream.toByteArray(), "utf-8");
		connection.close();
		logger.info("Out of pushRequest: "+outputString);
		return outputString;

	}

	/** @param req
	 * @return */
	private SOAPMessage getMsg(String req) {

		SOAPMessage msg = null;
		try {
			logger.info("Inside getMsg: "+SOAPAction);
			MessageFactory msgFactory = MessageFactory.newInstance("SOAP 1.1 Protocol");
			msg = msgFactory.createMessage();
			MimeHeaders hd = msg.getMimeHeaders();
			hd.addHeader("SOAPAction", SOAPAction);
			SOAPPart part = msg.getSOAPPart();
			StreamSource msgSrc = new StreamSource(new StringReader((String) req));
			part.setContent(msgSrc);
			msg.saveChanges();
		} catch (SOAPException e) {
			logger.error("Error getting SOAPMessage-\n"+e);
			e.printStackTrace();

		}
		return msg;
	}
	/**
	 * @return the sOAPAction
	 */
	public String getSOAPAction() {
		return SOAPAction;
	}
	/**
	 * @param sOAPAction the sOAPAction to set
	 */
	public void setSOAPAction(String sOAPAction) {
		SOAPAction = sOAPAction;
	}
	/**
	 * @return the wsURL
	 */
	public String getWsURL() {
		return wsURL;
	}
	/**
	 * @param wsURL the wsURL to set
	 */
	public void setWsURL(String wsURL) {
		this.wsURL = wsURL;
	}
}
