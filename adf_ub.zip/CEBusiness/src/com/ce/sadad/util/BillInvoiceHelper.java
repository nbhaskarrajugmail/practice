package com.ce.sadad.util;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;

public class BillInvoiceHelper {

	public static Integer MAX_PRECEDING_DIGIT_BILL_INVOICE_CYCLE = 2;

	private static String FETCH_BILLINVOICEACCOUNT_COUNT = "WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
			+ IBOCE_BILLINVOICE.BILLSTATUS + " = ? AND " + IBOCE_BILLINVOICE.BILLCATEGORY + " = ?";

	private static String FETCH_BILLCYCLE = "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " = ? AND "
			+ IBOLN_LEN_LoanSchedule.PAYMENTDT + " = ?";

	private static String FETCH_BILLCYCLE_BY_ACCOUNT = "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID
			+ " = ? ORDER BY " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " ASC";

	private static String FETCH_BILLINVOICE_RECORD_ACCOUNT = "WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
			+ IBOCE_BILLINVOICE.BILLCATEGORY + " = ? ORDER BY " + IBOCE_BILLINVOICE.BILLCYCLE + " DESC";

	private static String FETCH_BILLINVOICE_RECORD_ACCOUNT_AND_DUEDATE = "WHERE " + IBOCE_BILLINVOICE.BILLACCT
			+ " = ? AND " + IBOCE_BILLINVOICE.BILLDUEDATE + " = ? AND" + IBOCE_BILLINVOICE.BILLCATEGORY
			+ " = ? ORDER BY " + IBOCE_BILLINVOICE.BILLCYCLE + " DESC";

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static int indetifyNewBillCycleByAccount(String accountNo, String billCategory) {
		Integer newBillCycle = 1;
		ArrayList params = new ArrayList();
		params.add(accountNo);
		params.add(billCategory);
		List<IBOCE_BILLINVOICE> billInvoice = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BILLINVOICE.BONAME, FETCH_BILLINVOICE_RECORD_ACCOUNT, params, null, true);
		// checking bill cycle from the last recent record in bill invoice table
		if (billInvoice != null && !billInvoice.isEmpty()) {
			newBillCycle = (billInvoice.get(0).getF_BILLCYCLE() == null) ? 1 : billInvoice.get(0).getF_BILLCYCLE();
			newBillCycle++;
		}
		return newBillCycle;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static int indetifyBillCycleByAccountAndDueDate(String accountNo, Date dueDate, String billCategory) {
		int billCycle = 1;
		ArrayList params = new ArrayList();
		params.add(accountNo);
		params.add(dueDate);
		params.add(billCategory);
		List<IBOCE_BILLINVOICE> billInvoice = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOCE_BILLINVOICE.BONAME, FETCH_BILLINVOICE_RECORD_ACCOUNT_AND_DUEDATE, params, null, true);
		// checking bill cycle from the last recent record in bill invoice table
		if (billInvoice != null && !billInvoice.isEmpty()) {
			billCycle = billInvoice.get(0).getF_BILLCYCLE();
		}
		return billCycle;
	}

	public static int billInvoiceCycle(String accountNo, Date dueDate) {
		int billCycle = 0;
		IBOLN_LEN_LoanSchedule schedule = fetchLoanScheduleByAccountNoAndDueDate(accountNo, dueDate);
		if (schedule != null) {
			billCycle = schedule.getF_REPAYMENTNUMBER();
		} else {
			schedule = fetchRescheduledLoanByAccountNoAndDueDate(accountNo, dueDate);
			if (schedule != null) {
				billCycle = schedule.getF_REPAYMENTNUMBER();
			}
		}
		return billCycle;
	}

	public static IBOLN_LEN_LoanSchedule fetchLoanScheduleByAccountNoAndDueDate(String accountNo, Date dueDate) {
		IBOLN_LEN_LoanSchedule schedule = null;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(accountNo);
		params.add(dueDate);
		@SuppressWarnings("unchecked")
		List<IBOLN_LEN_LoanSchedule> schedules = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLN_LEN_LoanSchedule.BONAME, FETCH_BILLCYCLE, params, null, true);
		if (schedules != null && schedules.size() == 1) {
			schedule = schedules.get(0);
		}
		return schedule;
	}

	public static IBOLN_LEN_LoanSchedule fetchRescheduledLoanByAccountNoAndDueDate(String accountNo, Date oldDueDate) {
		// On an assumption that loan will not be rescheduled backward by date
		IBOLN_LEN_LoanSchedule schedule = null;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(accountNo);
		@SuppressWarnings("unchecked")
		List<IBOLN_LEN_LoanSchedule> schedules = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLN_LEN_LoanSchedule.BONAME, FETCH_BILLCYCLE_BY_ACCOUNT, params, null, true);

		int nextIndex = 1;
		if (schedules != null) {
			for (int thisIndex = 0; thisIndex < schedules.size() - 1 && schedules.size() > 1; thisIndex++) {
				IBOLN_LEN_LoanSchedule thisSchedule = schedules.get(thisIndex);
				IBOLN_LEN_LoanSchedule nextSchedule = schedules.get(nextIndex);
				if (thisSchedule.getF_PAYMENTDT().compareTo(oldDueDate) >= 0
						&& nextSchedule.getF_PAYMENTDT().compareTo(oldDueDate) < 0) {
					schedule = nextSchedule;
					break;
				}
				nextIndex++;
			}
		}
		return schedule;
	}

	public static int billInvoiceCounter(String invoiceNoOrAccNo) {
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(invoiceNoOrAccNo);
		params.add(CEConstants.S);
		params.add(SadadMessageConstants.FEE);
		@SuppressWarnings("unchecked")
		List<IBOCE_BILLINVOICE> invoiceList = (List<IBOCE_BILLINVOICE>) BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_BILLINVOICE.BONAME, FETCH_BILLINVOICEACCOUNT_COUNT, params, null, true);
		return (invoiceList != null) ? invoiceList.size() : 0;
	}

	public static String feeBillInvoiceCounterStr(String invoiceNoOrAccNo) {
		int count = billInvoiceCounter(invoiceNoOrAccNo);
		// int count = indetifyNewBillCycleByAccount(invoiceNoOrAccNo,
		// SadadMessageConstants.FEE);
		// default 2 - supported up to 99 as per bank statement
		CEUtil ceUtil = new CEUtil();
		int offsetValue = Integer.parseInt(ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "FEE_INV_OFFSET"));
		count = count + offsetValue;
		return addPrecedingZeros(MAX_PRECEDING_DIGIT_BILL_INVOICE_CYCLE, String.valueOf(count), count);
	}

	public static String addPrecedingZeros(int maxLength, String result, int num) {
		return new String(new char[maxLength - result.length()]).replace("\0", "0") + num;
	}

	@SuppressWarnings("unchecked")
	public static List<IBOCE_IB_PaymentSchBreakup> getSchBreakUp(String loanAcc, Date duedate) {
		List<IBOCE_IB_PaymentSchBreakup> schBreakupList = null;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		List<Object> result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME,
				" WHERE " + IBOLendingFeature.ACCOUNTID + " = ?", params, null, true);
		if (result != null && !result.isEmpty()) {
			String loanRef = ((IBOLendingFeature) result.get(0)).getF_LOANREFERENCE();
			params.clear();
			params.add(loanRef);
			params.add(duedate);
			schBreakupList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID
							+ " = ? AND " + IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?", params, null, true);
			if (result != null && !result.isEmpty()) {
				return schBreakupList;
			}
		}
		return null;
	}

	public static int getGracePeriod() throws Exception {
		int gracePeriod = 0;
		try {
			CEUtil ceUtil = new CEUtil();
			gracePeriod = Integer
					.parseInt(ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SUBSIDY_GRACE_PERIOD"));
		} catch (NumberFormatException e) {
			e.printStackTrace();
			throw new Exception("SUBSIDY_GRACE_PERIOD - MISSING");
		}
		return gracePeriod;
	}

	public static IBOCE_BILLINVOICE getSuccessBillInvoiceDtlsByAccountAndDuedate(String loanAcc, Date dueDate) {
		String billInvoiceRecFetch = " WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
				+ IBOCE_BILLINVOICE.BILLDUEDATE + " = ? AND " + IBOCE_BILLINVOICE.BILLSTATUS + " = ? ORDER BY "
				+ IBOCE_BILLINVOICE.BILLGENDATE + " DESC";
		IBOCE_BILLINVOICE billInvDtl = null;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		params.add(dueDate);
		params.add(CEConstants.S);
		@SuppressWarnings("rawtypes")
		List result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BILLINVOICE.BONAME,
				billInvoiceRecFetch, params, null, true);
		if (result != null && !result.isEmpty()) {
			billInvDtl = (IBOCE_BILLINVOICE) result.get(0);
		}
		return billInvDtl;
	}

	public static IBOCE_BILLINVOICE getBillInvoiceDtlsByAccountAndDuedate(String loanAcc, Date dueDate) {
		String billInvoiceRecFetch = " WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
				+ IBOCE_BILLINVOICE.BILLDUEDATE + " = ? ORDER BY " + IBOCE_BILLINVOICE.BILLGENDATE + " DESC";
		IBOCE_BILLINVOICE billInvDtl = null;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		params.add(dueDate);
		@SuppressWarnings("rawtypes")
		List result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCE_BILLINVOICE.BONAME,
				billInvoiceRecFetch, params, null, true);
		if (result != null && !result.isEmpty()) {
			billInvDtl = (IBOCE_BILLINVOICE) result.get(0);
		}
		return billInvDtl;
	}

}