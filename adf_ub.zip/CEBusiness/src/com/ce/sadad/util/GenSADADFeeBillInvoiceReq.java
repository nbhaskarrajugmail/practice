package com.ce.sadad.util;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ce.sadad.invoice.InvoiceData;
import com.trapedza.bankfusion.core.SystemInformationManager;


public class GenSADADFeeBillInvoiceReq {

	public static String generateSOAPRequest(List<InvoiceData> billDetails, String billType, String reqID) {
		System.out.println("Inside generateSOAPRequest for FeeBillInvoice: ");

		StringBuilder xmlInput = GenSADADReq.buildBillInvoiceHeader();
		xmlInput = buildBillsMngAGW(xmlInput, billDetails, billType, reqID);

		xmlInput.append("</s:Body>");
		xmlInput.append("</s:Envelope>");

		String reqXML = xmlInput.toString();
		return reqXML;
	}
	
	private static StringBuilder buildBillsMngAGW(StringBuilder xmlInput, List<InvoiceData> billDetails, String billType, String reqID) {
		try{
			System.out.println("Inside buildBillsMngAGW : billType: "+billType);
			String funID = "";
	        xmlInput.append("  <BillsMngAGW").
			append("  xmlns=\"http://tempuri.org/\">").
			append("  <type").
			append("  xmlns:a=\"http://schemas.datacontract.org/2004/07/TahseelServices.BillsMngAGWRef\"").
			append("  xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">").
			append(" <a:PropertyChanged i:nil=\"true\"").
			append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
			append(" </a:PropertyChanged>");
	        xmlInput.append(" <a:bodyField>").
	        append(" <a:PropertyChanged i:nil=\"true\"").
			append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
			append(" </a:PropertyChanged>");
			if(SadadMessageConstants.REPAY.equalsIgnoreCase(billType)){
				System.out.println("SPK Req: "+reqID);
				xmlInput.append("<a:batchIdField>"+reqID+"</a:batchIdField>");
			}
			else{
				xmlInput.append(" <a:batchIdField i:nil=\"true\"></a:batchIdField>");
			}
	        
	        xmlInput = buildBodyField(xmlInput, billDetails, billType);
	        
	        if(SadadMessageConstants.FEE.equalsIgnoreCase(billType)){
	        	funID = SadadMessageConstants.F_BILL_INVOICE_FUN_ID;
	        }
	        else{
	        	funID = SadadMessageConstants.RP_BILL_INVOICE_FUN_ID;
	        }
	        xmlInput = GenSADADReq.buildMsgRqHdrField(xmlInput, reqID, funID);
	        xmlInput.append(" </type>").
			append(" </BillsMngAGW>");
		}
		catch(Exception e){
			e.printStackTrace();
		}

        return xmlInput;
}

	public static StringBuilder buildBodyField(StringBuilder xmlInput, List<InvoiceData> billDetails, String billType) {
		try{
			xmlInput.append(" <a:billListField>");
			for (InvoiceData billDetail : billDetails) {
				xmlInput.append(" <a:BillInfo_Type>").
				append(" <a:PropertyChanged i:nil=\"true\"").
				append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
				append(" </a:PropertyChanged>").
				append(" <a:actionDtField i:nil=\"true\"></a:actionDtField>").
			    append(" <a:actionReasonField>Update bill</a:actionReasonField>").
		        append(" <a:agencyIdField>"+SadadMessageConstants.AGENCY_ID+"</a:agencyIdField>").
		        append(" <a:benInfoField>").
		        append(" <a:PropertyChanged i:nil=\"true\"").
		        append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
		        append(" </a:PropertyChanged>").
		        append(" <a:benNameField>"+"SPK"+"</a:benNameField>").
		        append(" <a:benPOIField>").
		        append(" <a:PropertyChanged i:nil=\"true\"").
		        append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
		        append(" </a:PropertyChanged>").
		        append(" <a:pOINumField>1009457407</a:pOINumField>").
		        append(" <a:pOITypeField>NAT</a:pOITypeField>").
		        append(" </a:benPOIField>").
		        append(" </a:benInfoField>").
		        append(" <a:billAcctField>"+billDetail.getBillAccount()+"</a:billAcctField>").
		        append(" <a:billActionField>"+((billDetail.getBillAction() == null) ? "I" : billDetail.getBillAction())+"</a:billActionField>").
		        append(" <a:billActionFieldSpecified>true</a:billActionFieldSpecified>").
		        append(" <a:billAmtField>"+billDetail.getBillAmount()+"</a:billAmtField>").
		        append(" <a:billCategoryField>"+billDetail.getBillCategory()+"</a:billCategoryField>");
				
				if(billDetail.getBillCycle()>0) {
					xmlInput.append(" <a:billCycleField>" + billDetail.getBillCycle() + "</a:billCycleField>");
				} else {
					xmlInput.append(" <a:billCycleField i:nil=\"true\"></a:billCycleField>");
				}
				
				xmlInput.append(" <a:billDescField i:nil=\"true\"></a:billDescField>").
				append(" <a:billNumField i:nil=\"true\"></a:billNumField>").
		        append(" <a:billRefInfoField i:nil=\"true\"></a:billRefInfoField>").
		        append(" <a:billStatusCodeField>BillNew</a:billStatusCodeField>").
		        append(" <a:billStatusCodeFieldSpecified>false</a:billStatusCodeFieldSpecified>").
		        append(" <a:billSummListField i:nil=\"true\"></a:billSummListField>").
		        append(" <a:displayLabelArField i:nil=\"true\"></a:displayLabelArField>").
		        append(" <a:displayLabelEnField i:nil=\"true\"></a:displayLabelEnField>");

				if (billDetail.getDueDate() != null) {
					xmlInput.append(" <a:dueDtField>" + billDetail.getDueDate() + "</a:dueDtField>");
				} else {
					xmlInput.append(" <a:dueDtField>" + SystemInformationManager.getInstance().getBFBusinessDate()
							+ "</a:dueDtField>");
				}
				
				xmlInput.append(" <a:expDtField i:nil=\"true\"></a:expDtField>").
		        append(" <a:pmtOptionsField i:nil=\"true\"></a:pmtOptionsField>").
		        append(" <a:presDtField i:nil=\"true\"></a:presDtField>").
		        append(" <a:revenueEntryListField>").
		        append(" <a:RevenueEntryInfo_Type>").
		        append(" <a:PropertyChanged i:nil=\"true\"").
		        append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">").
		        append(" </a:PropertyChanged>").
		        append(" <a:amtField>"+billDetail.getBillAmount()+"</a:amtField>").
		        append(" <a:benAgencyIdField>"+SadadMessageConstants.AGENCY_ID+"</a:benAgencyIdField>").
		        append(" <a:gFSCodeField>14412316</a:gFSCodeField>").
		        append(" </a:RevenueEntryInfo_Type>").
		        append(" </a:revenueEntryListField>").
		        append(" </a:BillInfo_Type>");
			}
			xmlInput.append(" </a:billListField>");
			xmlInput.append(" </a:bodyField>");
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return xmlInput;
	}
	
	public static String getRequestId(String xmlStr) {
		String begin = "<a:batchIdField>";
		String end = "</a:batchIdField>";
		String culprit = "<.+";
		Pattern p = Pattern.compile(begin + ".+" + end);
		Matcher m = p.matcher(xmlStr);
		if (m.find()) {
			String match = m.group(0);
			match = match.replace(begin, "");
			match = match.replace(end, "");
			match = match.replaceAll(culprit, "");
			return match;
		}
		return "";
	}
	
}