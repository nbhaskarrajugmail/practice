package com.ce.sadad.util;

import java.util.List;

import org.apache.ws.security.util.UUIDGenerator;

import com.trapedza.bankfusion.core.SimplePersistentObject;

public class GenSADADAcctMngReq {

	public static String generateSOAPRequest(List<SimplePersistentObject> acctList, String reqId) {
		System.out.println("Inside generateSOAPRequest for AcctMsg: " + reqId);

		StringBuilder xmlInput = GenSADADReq.buildAcctMsgHeader();
		xmlInput = buildAcctsMngAGW(xmlInput, acctList, reqId);

		xmlInput.append("</soapenv:Body>");
		xmlInput.append("</soapenv:Envelope>");

		String reqXML = xmlInput.toString();
		return reqXML;
	}

	private static StringBuilder buildAcctsMngAGW(StringBuilder xmlInput, List<SimplePersistentObject> acctList,
			String reqId) {
		System.out.println("Inside buildAcctsMngAGW");
		xmlInput.append("<AcctsMngAGW").append(" xmlns=\"http://tempuri.org/\">").append("<acctsMng")
				.append(" xmlns:a=\"http://schemas.datacontract.org/2004/07/TahseelServices.AcctsMngAGWRef\"")
				.append(" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">");

		xmlInput = GenSADADReq.buildPropertyChanged(xmlInput);
		xmlInput.append("<a:bodyField>");
		xmlInput = GenSADADReq.buildPropertyChanged(xmlInput);
		xmlInput = buildBodyField(xmlInput, acctList);
		xmlInput = GenSADADReq.buildMsgRqHdrField(xmlInput, reqId, SadadMessageConstants.REG_ACCT_FUN_ID);
		xmlInput.append("</acctsMng>").append("</AcctsMngAGW>");

		return xmlInput;
	}

	private static StringBuilder buildBodyField(StringBuilder xmlInput, List<SimplePersistentObject> acctList) {
		xmlInput.append("<a:acctListField>");
		try{
			System.out.println("Inside buildBodyField");	
		String batchID = UUIDGenerator.getUUID();
		for (SimplePersistentObject acctDetails : acctList) {
			String acctNo = (String) acctDetails.getDataMap().get("ACCOUNTID");
			System.out.println("BatchID: " + batchID + " AccountNo: " + acctNo);
			xmlInput.append("<a:AcctInfo_Type>");
			xmlInput = GenSADADReq.buildPropertyChanged(xmlInput);
			xmlInput.append("<a:acctActionField>" + SadadMessageConstants.INITIAL + "</a:acctActionField>")
					.append("<a:acctActionFieldSpecified>true</a:acctActionFieldSpecified>")
					.append("<a:acctStatusCodeField>AcctNew</a:acctStatusCodeField>")
					.append("<a:acctStatusCodeFieldSpecified>false</a:acctStatusCodeFieldSpecified>")
					.append("<a:agencyIdField>" + SadadMessageConstants.AGENCY_ID + "</a:agencyIdField>")
					.append("<a:benPOIField i:nil=\"true\"></a:benPOIField>")
					.append("<a:billAcctField>" + acctNo + "</a:billAcctField>").append("</a:AcctInfo_Type>");
		}

		xmlInput.append("</a:acctListField>").append("<a:batchIdField>" + batchID + "</a:batchIdField>")
				.append("</a:bodyField>");
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return xmlInput;
	}
}
