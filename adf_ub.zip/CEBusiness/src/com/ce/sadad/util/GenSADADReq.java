package com.ce.sadad.util;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPMessage;

import org.w3c.dom.NodeList;

import com.ce.adf.CEUtil;
import com.trapedza.bankfusion.core.SystemInformationManager;

public class GenSADADReq {

	public static StringBuilder buildAcctMsgHeader() {
		StringBuilder xmlInput = new StringBuilder("<soapenv:Envelope")
				.append(" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"")
				.append(" xmlns:tem=\"http://tempuri.org/\"")
				.append(" xmlns:tah=\"http://schemas.datacontract.org/2004/07/TahseelServices.AcctsMngAGWRef\"")
				.append(" xmlns:ser=\"http://schemas.microsoft.com/2003/10/Serialization/\">")
				.append("<soapenv:Header/>").append("<soapenv:Body>");
		return xmlInput;
	}
	
	public static StringBuilder buildBillInvoiceHeader() {
		StringBuilder xmlInput = new StringBuilder("  <s:Envelope").
				append("  xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">").
				append("<s:Body>");
		return xmlInput;
	}

	public static StringBuilder buildMsgRqHdrField(StringBuilder xmlInput, String reqId, String funID) {
		try {
			System.out.println("Inside buildMsgRqHdrField " + CEUtil.getDate());
			xmlInput.append("<a:msgRqHdrField>").append("<a:PropertyChanged i:nil=\"true\"")
					.append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">")
					.append("</a:PropertyChanged>")
					.append("<a:clientDtField>" + SystemInformationManager.getInstance().getBFBusinessDate() + "</a:clientDtField>")
					.append("<a:echoDataField i:nil=\"true\"></a:echoDataField>")
					.append("<a:funcIdField>" + funID + "</a:funcIdField>")
					.append("<a:partnerInfoField>").append("<a:PropertyChanged i:nil=\"true\"")
					.append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">")
					.append("</a:PropertyChanged>").append("<a:partnerCodeField i:nil=\"true\"></a:partnerCodeField>")
					.append("<a:partnerIdField>" + SadadMessageConstants.PARTNER_ID + "</a:partnerIdField>")
					.append("<a:partnerTypeField>" + SadadMessageConstants.PARTNER_TYPE + "</a:partnerTypeField>")
					.append("</a:partnerInfoField>").append("<a:partyIdField i:nil=\"true\"></a:partyIdField>")
					.append("<a:proxyUserIdField i:nil=\"true\"></a:proxyUserIdField>")
					.append("<a:rqModeField>0</a:rqModeField>")
					.append("<a:rqModeFieldSpecified>false</a:rqModeFieldSpecified>")
					.append("<a:rqUIDField>" + reqId + "</a:rqUIDField>")
					.append("<a:sCIdField>" + SadadMessageConstants.SRC_ID + "</a:sCIdField>")
					.append("<a:userIdField i:nil=\"true\"></a:userIdField>")
					.append("<a:versionField i:nil=\"true\"></a:versionField>").append("</a:msgRqHdrField>");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return xmlInput;
	}

	public static StringBuilder buildPropertyChanged(StringBuilder xmlInput) {
		xmlInput.append("<a:PropertyChanged i:nil=\"true\"")
				.append(" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.ComponentModel\">")
				.append("</a:PropertyChanged>");

		return xmlInput;
	}
	
	public static String getStatusCode(String xmlRecords) {
		System.out.println("Inside getStatusCode: "+xmlRecords);
		String statusCode = "";
		
		try{
	    MessageFactory factory = MessageFactory.newInstance();
	    SOAPMessage message = factory.createMessage(new MimeHeaders(),
	            new ByteArrayInputStream(xmlRecords.toString().getBytes(Charset.forName("UTF-8"))));

	    SOAPBody body = message.getSOAPBody();

	    // SADAD response update from "tah:" to "a:"
	    NodeList returnList = body.getElementsByTagName("a:statusField");

	    for (int k = 0; k < returnList.getLength(); k++) {
	        NodeList innerResultList = returnList.item(k).getChildNodes();
	        for (int l = 0; l < innerResultList.getLength(); l++) {
	        	// SADAD response update from "tah:" to "a:"
	            if (innerResultList.item(l).getNodeName()
	                    .equalsIgnoreCase("a:statusCodeField")) {
	            	statusCode = innerResultList.item(l).getTextContent().trim();
	            	System.out.println("StatusCode: "+statusCode);
	            }
	        }
	    }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return statusCode;
	}

}
