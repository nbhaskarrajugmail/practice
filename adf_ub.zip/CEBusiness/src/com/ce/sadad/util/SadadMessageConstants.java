package com.ce.sadad.util;

public class SadadMessageConstants {

	public static final String PARTNER_ID = "041006000000000000";
	public static final String PARTNER_TYPE = "GOVT";
	public static final String AGENCY_ID = "041006000000000000";
	public static final String REG_ACCT_FUN_ID = "15000000";
	public static final String F_BILL_INVOICE_FUN_ID = "15030000";
	public static final String RP_BILL_INVOICE_FUN_ID = "15031000";
	public static final String CATEGORY_CIP = "CIP";
	public static final String INITIAL = "I";
	public static final String FEE = "FEES";
	public static final String INVOICE = "INV";
	public static final String REG_ACCT = "REG_ACCT";
	public static final String EXPIRE = "E";
	public static final String UPDATE = "U";
	public static final String REPAY = "INSTALLMENT";
	public static final String SRC_ID = "G2G";
	public static final String C_INV = "CANCLE_INVOICE";
	public static final String U_INV = "UPDATE_INVOICE";
	public static final String SIMAH_PERSONAL_REGULAR = "SIMAH_PER_REG";
	public static final String SIMAH_PERSONAL_DEFAULT = "SIMAH_PER_DEF";
	public static final String SIMAH_ENTERPRISE = "SIMAH_ENT";

	public static final String DAYS_BEFORE_INVGEN = "INVGEN_DAYS_BEFORE_DUEDATE";
	public static final String DAYS_SUBSIDY_GRACE = "SUBSIDY_GRACE_PERIOD";
	public static final String DAYS_INVOICE_EXPIRY = "INVOICE_EXPIRY_PERIOD";

	public static final String ACCT_NAMESPACE = "ACCT_NAMESPACE";
	public static final String BILL_NAMESPACE = "BILL_NAMESPACE";

	public static final String MANAGEACCOUNTURL = "REGISTER_ACCOUNT_URL";
	public static final String BILL_INVOICE_URL = "BILL_INVOICE_URL";
	public static final String SADAD_BG_DR_ACCT = "SADADBGDRACCTNO";

	public static final String SADADSUCCESSCODE = "I000000";
	public static final String SADAD_BG_CR_TXNCODE = "SADADBGCRTXNCODE";
	public static final String SADAD_BG_DR_TXNCODE = "SADADBGDRTXNCODE";

	// Batch Process
	public static final String CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME = "CECancelBillInvoice";
	public static final String UPDATE_BILL_INVOICE_BATCH_PROCESS_NAME = "CEUpdateBillInvoice";
	public static final String REPAY_BILL_INVOICE_BATCH_PROCESS_NAME = "CEBillInvoiceforInstalment";
	public static final String SIMAH_PERSONAL_PARTY_REGULAR_BATCH_PROCESS_NAME = "CESimahPersonalPartyRegular";
	public static final String SIMAH_PERSONAL_PARTY_DEFAULT_BATCH_PROCESS_NAME = "CESimahPersonalPartyDefault";

	// Batch Process - Stages
	// -- Cancel
	public static final Integer CANCEL_BILL_INVOICE_STAGE_NEW = 1;
	public static final Integer CANCEL_BILL_INVOICE_STAGE_INPROGRESS = 2;
	public static final Integer CANCEL_BILL_INVOICE_STAGE_COMPLETED = 3;
	public static final String CANCEL_BILL_INVOICE_POST_PROCESS_PAGESIZE = "CECancelBillInvoice.PostProcess.PageSize";
	// -- Update
	public static final Integer UPDATE_BILL_INVOICE_STAGE_NEW = 1;
	public static final Integer UPDATE_BILL_INVOICE_STAGE_INPROGRESS = 2;
	public static final Integer UPDATE_BILL_INVOICE_STAGE_COMPLETED = 3;

	public static final String SADAD_BANK_ID_NOT_FOUND = "NA";
	public static final String SADAD_PAYMENT_ID_NOT_FOUND = "NA";
	public static final String SADAD_ACCOUNT_ID_NOT_FOUND = "NA";
	public static final String SADAD_BILL_INVOICE_NO_NOT_APPLICABLE = "NA";

}