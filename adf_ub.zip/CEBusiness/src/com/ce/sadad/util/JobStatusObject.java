package com.ce.sadad.util;

import java.sql.Date;
import java.sql.Timestamp;

public class JobStatusObject {
	
	private String jobExecId;
	private String jobId;
	private String jobStatus;
	private String statusDesc;
	private Integer recordCount;
	private Timestamp execTime;
	private Date execDate;
	/**
	 * @return the jobExecId
	 */
	public String getJobExecId() {
		return jobExecId;
	}
	/**
	 * @param jobExecId the jobExecId to set
	 */
	public void setJobExecId(String jobExecId) {
		this.jobExecId = jobExecId;
	}
	/**
	 * @return the jobId
	 */
	public String getJobId() {
		return jobId;
	}
	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	/**
	 * @return the jobStatus
	 */
	public String getJobStatus() {
		return jobStatus;
	}
	/**
	 * @param jobStatus the jobStatus to set
	 */
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}
	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	/**
	 * @return the recordCount
	 */
	public Integer getRecordCount() {
		return recordCount;
	}
	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}
	/**
	 * @return the execTime
	 */
	public Timestamp getExecTime() {
		return execTime;
	}
	/**
	 * @param execTime the execTime to set
	 */
	public void setExecTime(Timestamp execTime) {
		this.execTime = execTime;
	}
	/**
	 * @return the execDate
	 */
	public Date getExecDate() {
		return execDate;
	}
	/**
	 * @param execDate the execDate to set
	 */
	public void setExecDate(Date execDate) {
		this.execDate = execDate;
	}
	
	

}
