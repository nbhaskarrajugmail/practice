package com.ce.sadad.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import com.ce.sadad.invoice.InvoiceData;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_JOBSTATUS;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.utils.GUIDGen;

public class ManageJobStatus {

	private static String LAST_SUCCESS_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Success' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " DESC ";
	private static String FIRST_FAIL_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Failed' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " ASC ";

	public static void insertJobStatus(JobStatusObject jobStatus) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_JOBSTATUS jobStatusBO = (IBOCE_JOBSTATUS) factory.getStatelessNewInstance(IBOCE_JOBSTATUS.BONAME);
		jobStatusBO.setBoID(jobStatus.getJobExecId());
		jobStatusBO.setF_JOBID(jobStatus.getJobId());
		jobStatusBO.setF_JOBEXECDATE(jobStatus.getExecDate());
		jobStatusBO.setF_JOBEXECTIME(jobStatus.getExecTime());
		jobStatusBO.setF_JOBSTATUS(jobStatus.getJobStatus());
		jobStatusBO.setF_PRCRECCOUNT(jobStatus.getRecordCount());
		jobStatusBO.setF_STATUSDESC(jobStatus.getStatusDesc());
		jobStatusBO.setF_USERID(BankFusionThreadLocal.getUserId());
		jobStatusBO.setF_USERDATE(SystemInformationManager.getInstance().getBFSystemDate());

		factory.create(IBOCE_JOBSTATUS.BONAME, jobStatusBO);
	}

	public static void updateJobStatusCode(String successFail, String code, String pKey, Integer recordCount) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_JOBSTATUS jobStatusBO = (IBOCE_JOBSTATUS) factory.findByPrimaryKey(IBOCE_JOBSTATUS.BONAME, pKey, true);
		jobStatusBO.setF_JOBSTATUS(successFail);
		jobStatusBO.setF_STATUSDESC(code);
		jobStatusBO.setF_PRCRECCOUNT(recordCount);
	}

	public static void updateJobStatusCode(String successFail, String code, String pKey) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		IBOCE_JOBSTATUS jobStatusBO = (IBOCE_JOBSTATUS) factory.findByPrimaryKey(IBOCE_JOBSTATUS.BONAME, pKey, true);
		jobStatusBO.setF_JOBSTATUS(successFail);
		jobStatusBO.setF_STATUSDESC(code);
	}

	public static IBOCE_JOBSTATUS getJobStatus(String pKey) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		return (IBOCE_JOBSTATUS) factory.findByPrimaryKey(IBOCE_JOBSTATUS.BONAME, pKey, true);
	}

	public static String storeRequest(InvoiceData data) {
		CB_CMN_PrivateSession pvtSession = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory pvtFactory = pvtSession.createSession();
		pvtSession.beginTransaction();
		IBOCE_BILLINVOICE billInvoice = (IBOCE_BILLINVOICE) pvtFactory
				.getStatelessNewInstance(IBOCE_BILLINVOICE.BONAME);
		String idPk = GUIDGen.getNewGUID();
		billInvoice.setBoID(idPk);
		billInvoice.setF_REQUESTKEY(data.getRequestId());
		billInvoice.setF_BILLACCT(data.getBillAccount());
		billInvoice.setF_BILLAMT(data.getBillAmount());
		billInvoice.setF_BILLVATAMT(data.getVatAmount());
		billInvoice.setF_BILLCATEGORY(data.getBillCategory());
		billInvoice.setF_BILLINVOICENO(data.getInvoiceId());
		billInvoice.setF_BILLDUEDATE(data.getDueDate());
		if (data.getExpiryDate() == null)
			data.setExpiryDate(data.getDueDate());
		billInvoice.setF_BILLEXPDATE(data.getExpiryDate());
		billInvoice.setF_BILLGENDATE(SystemInformationManager.getInstance().getBFBusinessDate());
		billInvoice.setF_BILLACTION(data.getBillAction());
		billInvoice.setF_BILLCYCLE(data.getBillCycle());
		pvtFactory.create(IBOCE_BILLINVOICE.BONAME, billInvoice);
		pvtFactory.commitTransaction();
		return idPk;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Date getLastSuccessDate(String jobId) {
		ArrayList params = new ArrayList();
		params.add(jobId);
		IBOCE_JOBSTATUS jobStatus = (IBOCE_JOBSTATUS) BankFusionThreadLocal.getPersistanceFactory()
				.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, LAST_SUCCESS_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			return jobStatus.getF_JOBEXECDATE();
		}
		jobStatus = (IBOCE_JOBSTATUS) BankFusionThreadLocal.getPersistanceFactory()
				.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, FIRST_FAIL_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			Date date = jobStatus.getF_JOBEXECDATE();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, -1);
			date = new Date(cal.getTime().getTime());
			return date;
		}
		return null;
	}

}