package com.ce.sadad.invoice;

import static com.ce.adf.CEConstants.CE_SADAD_INTERFACE;
import static com.ce.adf.CEConstants.F;
import static com.ce.sadad.util.SadadMessageConstants.BILL_INVOICE_URL;
import static com.ce.sadad.util.SadadMessageConstants.BILL_NAMESPACE;
import static com.ce.sadad.util.SadadMessageConstants.EXPIRE;
import static com.ce.sadad.util.SadadMessageConstants.FEE;
import static com.ce.sadad.util.SadadMessageConstants.INITIAL;
import static com.ce.sadad.util.SadadMessageConstants.INVOICE;
import static com.ce.sadad.util.SadadMessageConstants.SADADSUCCESSCODE;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.utils.GUIDGen;

public class BillInvoice {
	private transient final static Log logger = LogFactory.getLog(BillInvoice.class.getName());

	private static String FETCH_BILLINVOICE = "WHERE " + IBOCE_BILLINVOICE.BILLINVOICENO + " = ?";

	private CEUtil util = new CEUtil();
	IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();

	/***
	 * Generate Invoice message of Study Fee and send message to Sadad
	 * 
	 * @param billAccount
	 * @param billAmount
	 * @return
	 */
	public Map<String, Object> genBillInvoiceforFee(FeeInvoiceData feeData) {
		Map<String, Object> result = new HashMap<>();
		logger.info("Inside genBillInvoiceforFee");
		InvoiceData data = new InvoiceData();
		data.setBillAccount(feeData.getBillAccount());
		data.setBillAmount(feeData.getBillAmount());
		data.setVatAmount(feeData.getVatAmount());
		data.setDueDate(feeData.getDueDate());
		data.setExpiryDate(feeData.getExpiryDate());
		String invoiceId = GUIDGen.getNewGUID();
		while (!new InvoiceCheckGenerator().isInvoiceIdNotPresent(invoiceId)) {
			invoiceId = GUIDGen.getNewGUID();
		}
		String requestId = GUIDGen.getNewGUID();
		logger.info("Invoice ID:" + invoiceId);
		int billCycle = BillInvoiceHelper.billInvoiceCounter(feeData.getBillAccount());
		CEUtil ceUtil = new CEUtil();
		int offsetValue = Integer.parseInt(ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "FEE_INV_OFFSET"));
		billCycle = billCycle + offsetValue;
		billCycle = billCycle == 0 ? 1 : billCycle + 1;
		data.setBillCycle(billCycle);
		data.setBillCategory(FEE);
		data.setInvoiceId(invoiceId);
		data.setRequestId(requestId);
		data.setBillAction(INITIAL);
		// Stored Initial details

		String billInvoiceIdPk = ManageJobStatus.storeRequest(data);
		String statusCode = "";
		String status = CEConstants.F;

		if (billInvoiceIdPk != null) {
			List<InvoiceData> billDetails = new ArrayList<InvoiceData>();
			// bill cycle element shouldn't be sent to FEE bill invoice
			data.setBillCycle(0);
			billDetails.add(data);
			String nationalId = data.getBillAccount();
			// NationalId + txn count of NationalId so far
			String billAcctUnique = nationalId + BillInvoiceHelper.addPrecedingZeros(
					BillInvoiceHelper.MAX_PRECEDING_DIGIT_BILL_INVOICE_CYCLE, String.valueOf(billCycle), billCycle);
			data.setBillAccount(billAcctUnique);
			// String message = XMLMessageGenerator.generateInvoiceSOAPMsg(data);
			String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billDetails, FEE, requestId);
			logger.info("message: " + message);

			String response = sendInvoiceMessage(message);
			logger.info("Response: " + response);
			if (null != response && !response.isEmpty()) {
				logger.info("RESPONSE\n" + response);
			} else {
				logger.error("No response from Sadad WS");
			}
			statusCode = GenSADADReq.getStatusCode(response);
			status = updateRequest(statusCode);
			logger.info("statusCode: " + statusCode + "invoiceId: " + invoiceId);

			IBOCE_BILLINVOICE billInvoice = (IBOCE_BILLINVOICE) BankFusionThreadLocal.getPersistanceFactory()
					.findByPrimaryKey(IBOCE_BILLINVOICE.BONAME, billInvoiceIdPk, false);
			billInvoice.setF_BILLSTATUS(status);
		}

		result.put("status", status);
		result.put("invoiceId", invoiceId);
		result.put("statusCode", statusCode);

		return result;
	}

	/**
	 * Delete Invoice. Will call Sadad API for deleting Invoice
	 * 
	 * @param invoiceId
	 * @return
	 */
	public String deleteBillInvoice(String invoiceId) {
		logger.info("Inside deleteBillInvoice: " + invoiceId);
		InvoiceCheckGenerator invCheck = new InvoiceCheckGenerator();
		// Check if Invoice exists
		if (invCheck.isInvoiceIdNotPresent(invoiceId)) {
			logger.error("Invoice No does not exist");
			return F;
		}
		if (invCheck.isInvoiceAlreadyDeleted(invoiceId)) {
			logger.error("Invoice Already Deleted");
			return F;
		}
		ArrayList<String> params = new ArrayList<String>();
		List<InvoiceData> billDetails = new ArrayList<InvoiceData>();
		params.add(invoiceId);
		@SuppressWarnings("unchecked")
		List<IBOCE_BILLINVOICE> invoiceList = (List<IBOCE_BILLINVOICE>) factory.findByQuery(IBOCE_BILLINVOICE.BONAME,
				FETCH_BILLINVOICE, params, null, true);

		InvoiceData data = new InvoiceData();
		for (IBOCE_BILLINVOICE billInvoice : invoiceList) {
			billInvoice.setF_BILLACTION(EXPIRE);
			String acctId = billInvoice.getF_BILLACCT();
			String counter = "";
			if (billInvoice.getBoID().contains("_")) {
				int count = Integer.parseInt(billInvoice.getBoID().split("_")[1]);
				counter = BillInvoiceHelper.addPrecedingZeros(BillInvoiceHelper.MAX_PRECEDING_DIGIT_BILL_INVOICE_CYCLE,
						String.valueOf(count), count);
			} else {
				counter = BillInvoiceHelper.feeBillInvoiceCounterStr(acctId);
			}
			String billNationalIDUnique = acctId + counter;
			data.setBillAccount(billNationalIDUnique);
			data.setBillAction(billInvoice.getF_BILLACTION());
			data.setBillAmount(billInvoice.getF_BILLAMT());
			data.setBillCategory(billInvoice.getF_BILLCATEGORY());
			billDetails.add(data);
		}
		String requestId = GUIDGen.getNewGUID();
		String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billDetails, FEE, requestId);
		logger.info(message);

		String response = sendInvoiceMessage(message);
		if (null != response && !response.isEmpty()) {
			logger.info("RESPONSE\n" + response);
		} else {
			logger.error("No response from Sadad WS");
		}
		String statusCode = GenSADADReq.getStatusCode(response);
		logger.info("statusCode from SADAD for Delete Fee: " + statusCode);
		return updateRequest(statusCode);
	}

	/**
	 * Web Service Call to Sadad for Bill Invoice
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 * @throws SOAPException
	 */
	public String sendInvoiceMessage(String request) {
		SadadWebService ws = new SadadWebService();
		ws.setSOAPAction(util.getModuleConfigurationValue(CE_SADAD_INTERFACE, BILL_NAMESPACE));
		ws.setWsURL(util.getModuleConfigurationValue(CE_SADAD_INTERFACE, BILL_INVOICE_URL));
		try {
			return ws.callSADAD(request, INVOICE);
		} catch (IOException | SOAPException e) {
			if (e instanceof SOAPException)
				logger.error("Error Calling Webservice");
			e.printStackTrace();
		}
		return null;

	}

	private String updateRequest(String statusCode) {
		logger.info("Inside updateRequest: " + statusCode);
		String status = CEConstants.F;
		if (statusCode.equals(SADADSUCCESSCODE)) {
			status = CEConstants.S;
		}
		logger.info("updateRequest: " + status);
		return status;
	}

}