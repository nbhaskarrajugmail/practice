package com.ce.sadad.invoice.fatoms.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_REPAYINVOICEGENTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanArrears;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

import static com.ce.adf.CEConstants.*;
import static com.ce.sadad.util.SadadMessageConstants.*;

public class SubsidyInvoiceGenProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(SubsidyInvoiceGenProcess.class
			.getName());
	private static String GENERIC_QUERY = "SELECT " + IBOCE_REPAYINVOICEGENTAG.ACCOUNTID
			+ " AS ACCOUNTID, " + IBOCE_REPAYINVOICEGENTAG.AMOUNTDUE + " AS REPAYAMOUNT, "
			+ IBOCE_REPAYINVOICEGENTAG.DUEDATE + " AS DUEDATE FROM " + IBOCE_REPAYINVOICEGENTAG.BONAME
			+ " WHERE " + IBOCE_REPAYINVOICEGENTAG.ROWSEQID + " BETWEEN ? AND ? ";

	private static String QUERY_LOANREPAY = " WHERE " + IBOLoanRepayments.ACCOUNTID + " = ? AND "
			+ IBOLoanRepayments.DUEDATE + " = ? ";
	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static String QUERY_SUBSIDY = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? ";
	private static String REPAY_FULL = "F";
	private static String QUERY_LOANARREAS = " WHERE " + IBOLoanArrears.ACCOUNTID + " = ? ";
	private static final String QUERY_INVOICENO = " WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
			+ IBOCE_BILLINVOICE.BILLDUEDATE + " = ? ";
	private static String LOANSTATUS_ARREARS = "2411";

	private IPersistenceObjectsFactory factory;
	private AbstractProcessAccumulator accumulator;

	public SubsidyInvoiceGenProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = ((SubsidyInvoiceGenContext) context);
	}

	@Override
	public void init() {
		initialiseAccumulator();

	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		if (logger.isInfoEnabled())
			logger.info("Inside SubsidyInvoiceGenProcess -- process method");
		
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> elements = new ArrayList<String>();

		int pageSize = this.context.getPageSize();
		int fromValue = (pageToProcess - 1) * pageSize + 1;
		int toValue = pageToProcess * pageSize;
		ArrayList params1 = new ArrayList();
		params1.add(Integer.valueOf(fromValue));
		params1.add(Integer.valueOf(toValue));

		List<SimplePersistentObject> records = this.factory.executeGenericQuery(GENERIC_QUERY, params1,
				null, true);
		
		StringBuilder xmlInput = GenSADADReq.buildBillInvoiceHeader();
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = (String) context.getInputTagDataMap().get("REQUESTID");

		for (SimplePersistentObject record : records) {
			String loanAccount = (String) record.getDataMap().get("ACCOUNTID");
			BigDecimal invoiceAmount = BigDecimal.ZERO;
			Date dueDate = (Date) record.getDataMap().get("DUEDATE");

			IBOLoanRepayments loanRepay = null;
			ArrayList params = new ArrayList();
			params.add(loanAccount);
			params.add(dueDate);
			ArrayList<IBOLoanRepayments> loanRepays = (ArrayList<IBOLoanRepayments>) factory
					.findByQuery(IBOLoanRepayments.BONAME, QUERY_LOANREPAY, params, null, true);
			if (null != loanRepays && !loanRepays.isEmpty()) {
				loanRepay = loanRepays.get(0);
				if (loanRepay.getF_STATUS().equals(REPAY_FULL)) {
					continue;
				}
			}
			// Check if loan is in Arrears
			String loanReference = EMPTY;
			params.clear();
			
			params = new ArrayList();
			params.add(loanAccount);
			IBOLendingFeature loanDetail = null;
			ArrayList<IBOLendingFeature> loanDetails = (ArrayList<IBOLendingFeature>) factory
					.findByQuery(IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, null, true);
			if (null != loanDetails && !loanDetails.isEmpty()) {
				loanDetail = loanDetails.get(0);
				if (loanDetail.getF_LOANSTATUS().equals(LOANSTATUS_ARREARS)) {
					loanReference = loanDetail.getF_LOANREFERENCE();
				} else {
					continue;
				}
			}
			
			if(getSubsidyAmount(loanReference, dueDate).compareTo(BigDecimal.ZERO) == 0){
				//No subsidy, return
				continue;
			}

			String invoiceId = getInvoiceId(loanAccount, dueDate);
			if (invoiceId == null) {
				logger.error("No Invoice Id Found for Account " + loanAccount + " whith Due Date "
						+ dueDate.toString());
				continue;
			}

			InvoiceData data = new InvoiceData();
			data.setBillAccount(loanAccount);
			data.setBillAmount(invoiceAmount.add(getArrearsAmount(loanAccount)));
			data.setVatAmount(BigDecimal.ZERO);
			data.setDueDate(dueDate);
			
			data.setExpiryDate(getExpiryDate(dueDate));
			data.setBillCategory(REPAY);
			data.setInvoiceId(invoiceId);
			data.setRequestId(reqID);
			data.setBillAction(UPDATE);
			ManageJobStatus.storeRequest(data);
			
			int billCycle = BillInvoiceHelper.billInvoiceCycle(loanAccount, dueDate);
			data.setBillCycle(billCycle);
			
			billInfoList.add(data);
			
			Integer count = (Integer)this.context.getInputTagDataMap().get("RECORDCOUNT");
			this.context.getInputTagDataMap().put("RECORDCOUNT", new Integer(count+1));
		}
		
		String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billInfoList, REPAY, reqID);
		String reqXML = message.toString();
		logger.info("Bill Invoice Request: "+reqXML);
		elements.add(reqXML);
		Object[] accumulatorArgs = new Object[2];
		accumulatorArgs[0] = elements;
		accumulatorArgs[1] = reqID;
		this.accumulator.accumulateTotals(accumulatorArgs);

		return this.accumulator;
	}

	private BigDecimal getArrearsAmount(String loanAccount) {
		BigDecimal arrAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList();
		params.add(loanAccount);
		ArrayList arrears = (ArrayList) factory.findByQuery(IBOLoanArrears.BONAME, QUERY_LOANARREAS,
				params, null, false);
		if (null != arrears && !arrears.isEmpty()) {
			for (int i = 0; i < arrears.size(); i++) {
				IBOLoanArrears arrear = (IBOLoanArrears) arrears.get(i);
				arrAmount = arrAmount.add(arrear.getF_REPAYMENTAMTINARREARS());
			}
		}
		return arrAmount;
	}

	private BigDecimal getSubsidyAmount(String loanReference, Date dueDate) {
		logger.info("Inside getSubsidyAmount: "+ loanReference + " / " + dueDate);
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList();
		params.add(loanReference);
		params.add(dueDate);
		logger.info("SPK "+ IBOCE_IB_PaymentSchBreakup.BONAME);
		//List payBreakUps = (List) factory.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, QUERY_SUBSIDY, params, null, false);
		List payBreakUps = (List) factory.findByQuery("CE_IB_PaymentSchBreakup", QUERY_SUBSIDY, params, null, false);
		if (null != payBreakUps && !payBreakUps.isEmpty()) {
			IBOCE_IB_PaymentSchBreakup payBreakup = (IBOCE_IB_PaymentSchBreakup) payBreakUps.get(0);
			logger.info("Subsidy Amount:  "+ payBreakup.getF_IBSUBSIDYAMNT());
			if (null != payBreakup.getF_IBSUBSIDYAMNT() && payBreakup.getF_IBSUBSIDYAMNT().compareTo(BigDecimal.ZERO) == 1)
				subsidyAmount = payBreakup.getF_IBSUBSIDYAMNT();
		}
		logger.info("Subsidy Amount Out:  "+ subsidyAmount);
		return subsidyAmount;
	}

	private String getInvoiceId(String loanAccount, Date dueDate) {
		ArrayList params = new ArrayList();
		params.add(loanAccount);
		params.add(dueDate);
		IBOCE_BILLINVOICE billInvoice = (IBOCE_BILLINVOICE) factory.findFirstByQuery(
				IBOCE_BILLINVOICE.BONAME, QUERY_INVOICENO, params, true);
		if (null != billInvoice)
			return billInvoice.getF_BILLINVOICENO();

		return null;
	}

	private Date getExpiryDate(Date dueDate) {
		int days = Integer.parseInt(new CEUtil().getModuleConfigurationValue(CE_SADAD_INTERFACE,
				DAYS_INVOICE_EXPIRY));
		Calendar cal = Calendar.getInstance();
		cal.setTime(dueDate);
		cal.add(Calendar.DATE, days);
		return new Date(cal.getTime().getTime());
	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new RepaymentInvoiceGenAccumulator(accumulatorArgs);

	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return this.accumulator;
	}
}
