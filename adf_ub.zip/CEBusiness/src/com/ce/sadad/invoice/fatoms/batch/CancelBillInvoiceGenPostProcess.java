package com.ce.sadad.invoice.fatoms.batch;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.common.util.BankFusionPropertySupport;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_CANCELBILLINVOICEGENTAG;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class CancelBillInvoiceGenPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(CancelBillInvoiceGenPostProcess.class.getName());
	private IPersistenceObjectsFactory factory;
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus batchStatus;
	private String requestId;
	private Integer recordCount;

	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext context, IBatchStatus batchStatus) {
		this.context = context;
		this.batchStatus = batchStatus;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {

		this.factory = BankFusionThreadLocal.getPersistanceFactory();

		String statusCode = CEConstants.F;
		String statusMsg = CEConstants.F;
		try {
			List vsList = null;
			List<String> cancelBillInvoicePKList = null;

			requestId = (String) context.getInputTagDataMap().get("REQUESTID");
			recordCount = (Integer) context.getInputTagDataMap().get("RECORDCOUNT");

			logger.info("Inside CancelBillInvoiceGenPostProcess #RequestId: " + requestId);

			if (recordCount == 0) {
				batchStatus.setStatus(true);
				return batchStatus;
			}
			if (null == acc) {
				batchStatus.setStatus(false);
				batchStatus.setBatchFailureMessage("Accumulator is null");
				return batchStatus;
			} else {
				this.accumulator = acc;
				Object[] obj = accumulator.getMergedTotals();
				if (obj != null && obj.length > 1) {
					if (obj[0] != null) {
						Map vsMap = (Map) obj[0];
						vsList = (List<String>) vsMap.get(requestId);
					}

					if (obj[1] != null) {
						cancelBillInvoicePKList = (List<String>) obj[1];
					}
				}
			}

			SadadWebService wsCall = new SadadWebService();
			Boolean isExceptionOccured = Boolean.FALSE;
			if (vsList != null && !vsList.isEmpty()) {
				for (Object cancelBillInvoiceRqXML : vsList) {
					String cancelBillInvoiceRqMsg = cancelBillInvoiceRqXML.toString().replace("[", CEConstants.EMPTY)
							.replace("]", CEConstants.EMPTY);
					try {
						logger.info("Before calling SADAD Cancel");
						String response = wsCall.callSADAD(cancelBillInvoiceRqMsg, SadadMessageConstants.INVOICE);
						statusCode = GenSADADReq.getStatusCode(response);
						if (logger.isInfoEnabled()) {
							logger.info("CancelBillInvoiceReqMsg: " + cancelBillInvoiceRqMsg);
							logger.info("After calling SADAD Cancel: " + response);
							logger.info("CancelBillInvoiceGenPostProcess - statusCode: " + statusCode);
						}
						statusMsg = statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE) ? CEConstants.S
								: CEConstants.F;
					} catch (IOException | SOAPException e) {
						statusMsg = CEConstants.F;
						logger.error(e);
						if (e instanceof SOAPException)
							statusCode = "Webservice Connection Error";
						if (e instanceof IOException)
							statusCode = "Input Output Error";
						if (logger.isErrorEnabled()) {
							logger.error("Failure due to " + statusCode);
							logger.error(e.getMessage());
						}
						logger.info("CancelBillInvoiceGenPostProcess - Exception - statusCode: " + statusCode);
						isExceptionOccured = Boolean.TRUE;
					}
				}
			}

			logger.info("Updating Action size [" + cancelBillInvoicePKList.size() + "]");
			if (cancelBillInvoicePKList != null & !cancelBillInvoicePKList.isEmpty()) {
				String pageSizeStr = BankFusionPropertySupport.getProperty("conf/adf/custom.properties",
						SadadMessageConstants.CANCEL_BILL_INVOICE_POST_PROCESS_PAGESIZE, "200");
				int pageSize = Integer.parseInt(pageSizeStr);
				for (int fromIndex = 0; fromIndex < cancelBillInvoicePKList.size(); fromIndex += pageSize) {
					int toIndex = fromIndex + pageSize;
					if (toIndex > cancelBillInvoicePKList.size())
						toIndex = cancelBillInvoicePKList.size();

					this.updateBillInvoiceDtls(SadadMessageConstants.EXPIRE,
							new ArrayList(cancelBillInvoicePKList.subList(fromIndex, toIndex)));
				}
			}

			// update status to COMPLETE from INPROGRESS in Tag Table
			if (!isExceptionOccured)
				this.updateTagTable();

			if (null != statusCode && !statusCode.isEmpty()
					&& statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
				batchStatus.setStatus(Boolean.TRUE);
			} else {
				batchStatus.setStatus(Boolean.TRUE);
			}

		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
			batchStatus.setStatus(Boolean.FALSE);
		}
		logger.info("JobStatus [" + statusCode + "] [" + statusMsg + "]");
		ManageJobStatus.updateJobStatusCode(statusMsg, statusCode, requestId);
		return batchStatus;
	}

	private void updateBillInvoiceDtls(String billAction, ArrayList<String> params) {

		try {
			StringBuilder inQuery = new StringBuilder();
			inQuery.append(" UPDATE CUSTOMEXTN.CETB_BILLINVOICE SET CEBILLACTION = ? WHERE CEIDPK IN (");
			for (int i = 0; i < params.size(); i++) {
				inQuery.append("?,");
			}
			// remove last COMMA
			inQuery.replace(inQuery.length() - 1, inQuery.length(), ")");

			@SuppressWarnings("deprecation")
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(inQuery.toString());
			int index = 1;

			ps.setString(index++, billAction);
			for (String idpk : params) {
				ps.setString(index++, idpk);
			}

			ps.executeUpdate();
		} catch (SQLException e) {
			logger.info("updateBillInvoiceDtls" + e.getMessage());
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateTagTable() {
		String completedStatusUpdateQuery = " WHERE " + IBOCE_CANCELBILLINVOICEGENTAG.TAGSTATUS + " = ?";

		ArrayList params = new ArrayList<>();
		params.add(SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_INPROGRESS);

		ArrayList columns = new ArrayList();
		columns.add(IBOCE_CANCELBILLINVOICEGENTAG.TAGSTATUS);

		ArrayList paramValues = new ArrayList();
		paramValues.add(SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_COMPLETED);

		this.factory.bulkUpdate(IBOCE_CANCELBILLINVOICEGENTAG.BONAME, completedStatusUpdateQuery, params, columns,
				paramValues);
	}

}