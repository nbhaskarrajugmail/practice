package com.ce.sadad.invoice.fatoms.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class RepaymentInvoiceGenPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(RepaymentInvoiceGenPostProcess.class.getName());
	@SuppressWarnings("unused")
	private BankFusionEnvironment environment;
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus status;
	private String requestId;
	private Integer recordCount;
	private static String UPDATE_QUERY = " WHERE " + IBOCE_BILLINVOICE.REQUESTKEY + " = ?";

	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext ctx, IBatchStatus batchStatus) {
		this.environment = env;
		this.context = ctx;
		this.status = batchStatus;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {
		String statusCode = CEConstants.F;
		String statusMsg = CEConstants.F;

		int processedRecordCount = 0;
		try {
			logger.info("Inside RepaymentInvoiceGenPostProcess");
			List vsList = null;
			SadadWebService wsCall = new SadadWebService();
			requestId = (String) context.getInputTagDataMap().get("REQUESTID");
			logger.info("RequestId: " + requestId);
			recordCount = (Integer) context.getInputTagDataMap().get("RECORDCOUNT");
			if (recordCount == 0) {
				logger.info("No record found : " + recordCount);
				ManageJobStatus.updateJobStatusCode(CEConstants.F, "NO RECORDS FOUND", requestId,
						(Integer) recordCount);
				status.setStatus(true);
				return status;
			}
			if (null == acc) {
				logger.info("Accumulator is null");
				status.setStatus(false);
				ManageJobStatus.updateJobStatusCode(CEConstants.F, "NO RECORDS FOUND Acc", requestId,
						(Integer) recordCount);
				status.setBatchFailureMessage("Accumulator is null");
				return status;
			} else {
				this.accumulator = acc;
				Object[] obj = accumulator.getMergedTotals();
				if (obj != null && obj.length > 0 && obj[0] != null) {
					Map vsMap = (Map) obj[0];
					vsList = (List<String>) vsMap.get(requestId);
				}
			}
			if (vsList != null && vsList.size() > 0) {
				logger.info("RepaymentInvoiceGenPostProcess - BillInvoice Rq size [" + vsList.size() + "]");
				for (Object billInvoiceRqXML : vsList) {
					String requestId = "";
					try {
						String billInvoiceReqMsg = billInvoiceRqXML.toString().replace("[", CEConstants.EMPTY)
								.replace("]", CEConstants.EMPTY);
						requestId = GenSADADFeeBillInvoiceReq.getRequestId(billInvoiceReqMsg);
						logger.info("Before calling SADAD requestId : " + requestId + " # statusCode : " + statusCode
								+ " # statusMsg : " + statusMsg);
						// logger.info("BillInvoiceReqMsg: " + billInvoiceReqMsg);
						String response = wsCall.callSADAD(billInvoiceReqMsg, SadadMessageConstants.INVOICE);
						statusCode = GenSADADReq.getStatusCode(response);
						logger.info("Before updating BillInvoiceRecord requestId : " + requestId + " # statusCode : "
								+ statusCode + " # statusMsg : " + statusMsg);
						statusMsg = updateRequest(statusCode, requestId);
						logger.info("After updating BillInvoiceRecord requestId : " + requestId + " # statusCode : "
								+ statusCode + " # statusMsg : " + statusMsg);
						logger.info("StatusCode: " + statusCode);

						if (statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
							processedRecordCount += (Integer) context.getInputTagDataMap().get(requestId);
						}
					} catch (Exception e) {
						logger.error(
								"Exception during SADAD API Invoke #requestId [" + requestId + "]" + e.getMessage());
					}
				}
			} else {
				logger.info("No SADAD Rq found");
				statusMsg = CEConstants.F;
			}
			if (statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
				status.setStatus(true);
				statusMsg = CEConstants.S;
			} else {
				status.setStatus(false);
				statusMsg = CEConstants.F;
			}
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
			e.printStackTrace();
			status.setStatus(false);
			statusMsg = CEConstants.F;
		}
		if (processedRecordCount == 0) {
			statusMsg = CEConstants.F;
		} else if (processedRecordCount < recordCount) {
			statusMsg = CEConstants.PARTIAL;
			processedRecordCount = recordCount - processedRecordCount;
		}
		ManageJobStatus.updateJobStatusCode(statusMsg, statusCode, requestId, (Integer) processedRecordCount);
		return status;
	}

	private String updateRequest(String statusCode, String requestId) {
		if (null == statusCode || statusCode.isEmpty()) {
			statusCode = "SOAP_ERR";
		}
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String status = statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE) ? CEConstants.S : CEConstants.F;
		ArrayList<String> params = new ArrayList<String>();
		params.add(requestId);
		@SuppressWarnings("unchecked")
		List<IBOCE_BILLINVOICE> invoices = (List<IBOCE_BILLINVOICE>) factory.findByQuery(IBOCE_BILLINVOICE.BONAME,
				UPDATE_QUERY, params, null, true);
		for (int i = 0; i < invoices.size(); i++) {
			IBOCE_BILLINVOICE invoiceUpdate = (IBOCE_BILLINVOICE) invoices.get(i);
			invoiceUpdate.setF_BILLSTATUS(status);
		}
		return status;
	}

}