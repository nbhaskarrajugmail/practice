package com.ce.sadad.invoice.fatoms.batch;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.soap.SOAPException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_UPDATEBILLINVOICEGENTAG;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class UpdateBillInvoiceGenPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(UpdateBillInvoiceGenPostProcess.class.getName());
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus batchStatus;
	private String requestId;
	private Integer recordCount;

	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext context, IBatchStatus batchStatus) {
		this.context = context;
		this.batchStatus = batchStatus;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {
		String statusCode = CEConstants.F;
		String statusMsg = CEConstants.F;
		try {
			List vsList = new ArrayList();
			List<String> updateBillInvoicePKList = new ArrayList();
			ArrayList<InvoiceData> updateBillInvoiceList = new ArrayList<>();
			Map<String, Boolean> invoiceMap = new HashMap<String, Boolean>();

			requestId = (String) context.getInputTagDataMap().get("REQUESTID");
			recordCount = (Integer) context.getInputTagDataMap().get("RECORDCOUNT");

			logger.info("Inside UpdateBillInvoiceGenPostProcess #RequestId: " + requestId);

			if (null != acc) {
				this.accumulator = acc;
				Object[] obj = accumulator.getMergedTotals();
				if (obj != null && obj.length > 1) {
					if (obj[0] != null) {
						if (obj[0] != null) {
							Map vsMap = (Map) obj[0];
							List list = (List<String>) vsMap.get(requestId);
							if (list != null && !list.isEmpty()) {
								vsList.addAll(list);
							}
						}
						if (obj[1] != null) {
							List list = (List<String>) obj[1];
							if (list != null && !list.isEmpty()) {
								updateBillInvoicePKList.addAll(list);
							}
						}
						for (String billInvoicePK : updateBillInvoicePKList) {
							invoiceMap.put(billInvoicePK, Boolean.TRUE);
						}
					}
				}
			} else {
				logger.info("Inside UpdateBillInvoiceGenPostProcess - ##Accumulator is null##");
			}

			if (UpdateBillInvoiceGenContext.lastSuccessDate != null) {
				updateBillInvoiceList = this.subsidyExpireCheck(invoiceMap);
				if (updateBillInvoiceList != null && !updateBillInvoiceList.isEmpty()) {
					logger.info("Invoice - Subsidy Expire Check details" + updateBillInvoiceList.size());
					String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(updateBillInvoiceList,
							SadadMessageConstants.REPAY, requestId);
					String reqXML = message.toString();
					ArrayList<String> elements = new ArrayList<String>();
					elements.add(reqXML);
					vsList.add(elements);
					recordCount = updateBillInvoiceList.size();
					statusCode = SadadMessageConstants.SADADSUCCESSCODE;
					statusMsg = CEConstants.S;
				}
			}

			Boolean isExceptionOccured = Boolean.FALSE;
			if (vsList != null && !vsList.isEmpty()) {
				for (Object updateBillInvoiceRqXML : vsList) {
					logger.info("Before calling build Update - " + requestId);
					String updateBillInvoiceRqMsg = updateBillInvoiceRqXML.toString().replace("[", CEConstants.EMPTY)
							.replace("]", CEConstants.EMPTY);
					logger.info("After calling build Update: " + updateBillInvoiceRqMsg);
					String response = null;
					try {
						logger.info("Before calling SADAD Update");
						SadadWebService wsCall = new SadadWebService();
						response = wsCall.callSADAD(updateBillInvoiceRqMsg, SadadMessageConstants.INVOICE);
						logger.info("After calling SADAD Update: " + response);
						statusCode = GenSADADReq.getStatusCode(response);
						logger.info("statusCode: " + statusCode);
					} catch (IOException | SOAPException e) {
						logger.error(e);
						if (e instanceof SOAPException)
							statusCode = "Webservice Connection Error";
						if (e instanceof IOException)
							statusCode = "I/O Error";
						e.printStackTrace();
						isExceptionOccured = Boolean.TRUE;
					}
					if (null != statusCode && !statusCode.isEmpty()
							&& statusCode.equals(SadadMessageConstants.SADADSUCCESSCODE)) {
						statusMsg = CEConstants.S;
					}
				}
				// update status to COMPLETE from INPROGRESS in Tag Table
				if (!isExceptionOccured)
					this.updateTagTable();
			} else {
				statusCode = "No records";
				recordCount = 0;
			}
			batchStatus.setStatus(Boolean.TRUE);
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
			batchStatus.setStatus(Boolean.FALSE);
		}
		logger.info("JobStatus [" + statusCode + "] [" + statusMsg + "]");
		ManageJobStatus.updateJobStatusCode(statusMsg, statusCode, requestId, recordCount);
		return this.batchStatus;
	}

	// Subsidy expire check on all bill invoice
	@SuppressWarnings("unchecked")
	private ArrayList<InvoiceData> subsidyExpireCheck(Map<String, Boolean> invoiceMap) {
		ArrayList<InvoiceData> subsidyEpiredBillInfoList = new ArrayList<InvoiceData>();
		try {
			int gracePeriod = BillInvoiceHelper.getGracePeriod();
			java.sql.Date today = this.getTodaySqlDatewithTimeZero();
			java.sql.Date subsidyExpireDate = CEDateHelper
					.utilDateToSqlDate(UpdateBillInvoiceGenContext.lastSuccessDate);
			subsidyExpireDate = AddDaysToDate.run(1,
					CEDateHelper.utilDateToSqlDate(UpdateBillInvoiceGenContext.lastSuccessDate));

			while (subsidyExpireDate.compareTo(today) <= 0) {
				ArrayList<Object> params2 = new ArrayList<>();
				params2.add(subsidyExpireDate);
				params2.add(SadadMessageConstants.EXPIRE);
				String billInvoiceSubsidyExpiryCheckSQL = "WHERE (" + IBOCE_BILLINVOICE.BILLDUEDATE + " + "
						+ gracePeriod + ") = ? AND " + IBOCE_BILLINVOICE.BILLACTION + " <> ?";
				List<IBOCE_BILLINVOICE> billinvoices = (List<IBOCE_BILLINVOICE>) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceSubsidyExpiryCheckSQL, params2, null, true);
				for (IBOCE_BILLINVOICE billInvoice : billinvoices) {
					// skip if already calculated
					if (!invoiceMap.containsKey(billInvoice.getBoID())) {
						BigDecimal subsidyAmount = this.calculateSubsidy(billInvoice);
						logger.info("Update Bill Invoice - PostProcess - [" + billInvoice.getF_BILLACCT()
								+ "] ExistingBillInvoiceAmt: " + billInvoice.getF_BILLAMT());
						logger.info("Update Bill Invoice - PostProcess - [" + billInvoice.getF_BILLACCT()
								+ "] subsidyAmount: " + subsidyAmount);
						// prepare bill invoice update data
						if (subsidyAmount.compareTo(BigDecimal.ZERO) > 0) {
							BigDecimal finalBillAmount = billInvoice.getF_BILLAMT().add(subsidyAmount);
							logger.info("Update Bill Invoice - PostProcess - [" + billInvoice.getF_BILLACCT() + "]["
									+ billInvoice.getF_BILLACCT() + "] FinalBillAmount: " + finalBillAmount);
							billInvoice.setF_BILLAMT(finalBillAmount);
							InvoiceData data = new InvoiceData();
							data.setBillAccount(billInvoice.getF_BILLACCT());
							data.setBillAction(SadadMessageConstants.UPDATE);
							data.setBillCategory(billInvoice.getF_BILLCATEGORY());
							data.setBillAmount(finalBillAmount);
							data.setBillCycle(billInvoice.getF_BILLCYCLE());
							data.setInvoiceId(billInvoice.getF_BILLINVOICENO());
							data.setDueDate(billInvoice.getF_BILLDUEDATE());
							billInvoice.setF_BILLACTION(SadadMessageConstants.UPDATE);
							subsidyEpiredBillInfoList.add(data);
						}
						invoiceMap.put(billInvoice.getBoID(), Boolean.TRUE);
					}
				}
				subsidyExpireDate = AddDaysToDate.run(1, subsidyExpireDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		logger.info("Update Bill Invoice - PostProcess - UpdateBillInvoice Rq size [" + invoiceMap.size() + "]");
		return subsidyEpiredBillInfoList;
	}

	private java.sql.Date getTodaySqlDatewithTimeZero() {
		Date datetime = SystemInformationManager.getInstance().getBFBusinessDate();
		return CEDateHelper.utilDateToSqlDate(datetime);
	}

	private BigDecimal calculateSubsidy(IBOCE_BILLINVOICE billInvoice) throws Exception {
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		int gracePeriod = BillInvoiceHelper.getGracePeriod();
		java.sql.Date today = this.getTodaySqlDatewithTimeZero();
		java.sql.Date gracePeriodDate = AddDaysToDate.run(gracePeriod, billInvoice.getF_BILLDUEDATE());

		// if grace period is expired then deduct subsidy
		List<IBOCE_IB_PaymentSchBreakup> schBreakDtlList = null;
		if (today.compareTo(gracePeriodDate) == 0) {
			schBreakDtlList = BillInvoiceHelper.getSchBreakUp(billInvoice.getF_BILLACCT(),
					billInvoice.getF_BILLDUEDATE());
			if (schBreakDtlList != null && !schBreakDtlList.isEmpty()) {
				for (IBOCE_IB_PaymentSchBreakup payBreakup : schBreakDtlList) {
					if (payBreakup.getF_IBSUBSIDYAMNT() != null
							&& payBreakup.getF_IBSUBSIDYAMNT().compareTo(BigDecimal.ZERO) > 0) {
						subsidyAmount = subsidyAmount.add(payBreakup.getF_IBSUBSIDYAMNT());
					}
				}
			}
		}
		return subsidyAmount;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateTagTable() {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String completedStatusUpdateQuery = " WHERE " + IBOCE_UPDATEBILLINVOICEGENTAG.TAGSTATUS + " = ?";

		ArrayList params = new ArrayList<>();
		params.add(SadadMessageConstants.UPDATE_BILL_INVOICE_STAGE_INPROGRESS);

		ArrayList columns = new ArrayList();
		columns.add(IBOCE_UPDATEBILLINVOICEGENTAG.TAGSTATUS);

		ArrayList paramValues = new ArrayList();
		paramValues.add(SadadMessageConstants.UPDATE_BILL_INVOICE_STAGE_COMPLETED);

		factory.bulkUpdate(IBOCE_UPDATEBILLINVOICEGENTAG.BONAME, completedStatusUpdateQuery, params, columns,
				paramValues);
	}

}