package com.ce.sadad.invoice.fatoms.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.sadad.util.GenSADADReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadWebService;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

import static com.ce.adf.CEConstants.*;
import static com.ce.sadad.util.SadadMessageConstants.*;

public class SubsidyInvoiceGenPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(SubsidyInvoiceGenPostProcess.class
			.getName());
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus status;
	private String requestId;
	private Integer recordCount;
	private static String UPDATE_QUERY = " WHERE " + IBOCE_BILLINVOICE.REQUESTKEY + " = ?";

	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext ctx, IBatchStatus batchStatus) {
		this.context = ctx;
		this.status = batchStatus;

	}

	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {
		try{
		logger.info("Inside SubsidyInvoiceGenPostProcess");
		
		List vsList = null;
		SadadWebService wsCall = new SadadWebService();
		
		requestId = (String) context.getInputTagDataMap().get("REQUESTID");
		recordCount = (Integer) context.getInputTagDataMap().get("RECORDCOUNT");
		if (recordCount == 0) {
			ManageJobStatus.updateJobStatusCode(S, "NO RECORDS FOUND", requestId,
					(Integer) recordCount);
			status.setStatus(true);
			return status;
		}
		if (null == acc) {
			status.setStatus(false);
			status.setBatchFailureMessage("Accumulator is null");
			return status;
		} else {
			this.accumulator = acc;
			Object[] obj = accumulator.getMergedTotals();
			if (obj != null && obj.length > 0 && obj[0] != null) {
				Map vsMap = (Map) obj[0];
				vsList = (ArrayList) vsMap.get(requestId);
			}
		}
		
		String billInvoiceReqMsg = vsList.get(0).toString().replace("[", EMPTY).replace("]", EMPTY);
		logger.info("BillInvoiceReqMsg: "+billInvoiceReqMsg);

		String response = wsCall.callSADAD(billInvoiceReqMsg, INVOICE);
		String statusCode = GenSADADReq.getStatusCode(response);
		logger.info("StatusCode: "+statusCode);
		if (updateRequest(statusCode).equals(S))
			status.setStatus(true);
		else
			status.setStatus(false);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}

	private String updateRequest(String statusCode) {
		if (null == statusCode || statusCode.isEmpty()) {
			statusCode = "SOAP_ERR";
		}
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		String status = EMPTY;
		ArrayList params = new ArrayList();
		params.add(requestId);
		List invoices = (List) factory.findByQuery(IBOCE_BILLINVOICE.BONAME, UPDATE_QUERY, params,
				null, true);

		for (int i = 0; i < invoices.size(); i++) {
			IBOCE_BILLINVOICE invoiceUpdate = (IBOCE_BILLINVOICE) invoices.get(i);
			if (statusCode.equals(SADADSUCCESSCODE)) {
				invoiceUpdate.setF_BILLSTATUS(S);
				status = S;
			} else {
				invoiceUpdate.setF_BILLSTATUS(F);
				status = F;
			}
		}
		ManageJobStatus.updateJobStatusCode(status, statusCode, requestId, (Integer) recordCount);
		return status;
	}
}
