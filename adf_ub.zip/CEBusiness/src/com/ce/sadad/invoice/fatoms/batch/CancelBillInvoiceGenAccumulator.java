package com.ce.sadad.invoice.fatoms.batch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class CancelBillInvoiceGenAccumulator extends AbstractProcessAccumulator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private transient final static Log logger = LogFactory.getLog(CancelBillInvoiceGenAccumulator.class.getName());

	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap collectionTable = null;
	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap mergedCollectionTable = null;
	@SuppressWarnings("rawtypes")
	private List merged = null;

	private List<String> cancelBillInvoicePKList = null;
	private List<String> mergedCancelBillInvoicePKList = null;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public CancelBillInvoiceGenAccumulator(Object[] args) {
		super(args);
		this.merged = new ArrayList();
		this.cancelBillInvoicePKList = Collections.synchronizedList(new ArrayList());
		this.mergedCancelBillInvoicePKList = Collections.synchronizedList(new ArrayList());
		this.collectionTable = new ConcurrentHashMap();
		this.mergedCollectionTable = new ConcurrentHashMap();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		if (this.merged == null) {
			this.merged = new ArrayList();
		}
		this.merged.add(acc);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void accumulateTotals(Object[] data) {
		ArrayList invoices = (ArrayList) data[0];
		String requestIdKey = (String) data[1];
		List<String> cancelBillInvoicePKList = (List) data[2];
		// accumulating request
		if (this.collectionTable.containsKey(requestIdKey.toString())) {
			List list = (ArrayList) collectionTable.get(requestIdKey.toString());
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);
		} else {
			List list = new ArrayList();
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);
		}
		// accumulating cancel bill list
		this.cancelBillInvoicePKList.addAll(cancelBillInvoicePKList);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object[] getMergedTotals() {
		Object[] processWorkerTotals = (Object[]) null;
		Object[] ret = new Object[2];
		logger.info("in getMergedTotals()-> merged list size:" + merged.size());
		Iterator iterator = this.merged.iterator();
		// accumulating request
		this.mergedCollectionTable.clear();
		// accumulating cancel bill list
		this.mergedCancelBillInvoicePKList.clear();
		while (iterator.hasNext()) {
			AbstractProcessAccumulator accumulator = (AbstractProcessAccumulator) iterator.next();
			processWorkerTotals = accumulator.getProcessWorkerTotals();
			this.mergeAccumulatedTotals(processWorkerTotals);
		}
		this.mergeAccumulatedTotals(getProcessWorkerTotals());
		// accumulating request
		ret[0] = this.mergedCollectionTable;
		// accumulating cancel bill list
		ret[1] = this.mergedCancelBillInvoicePKList;
		return ret;
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] processWorkerTotals = new Object[2];
		// accumulating request
		processWorkerTotals[0] = this.collectionTable;
		// accumulating cancel bill list
		processWorkerTotals[1] = this.cancelBillInvoicePKList;
		return processWorkerTotals;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void mergeAccumulatedTotals(Object[] accumulatedTotals) {
		logger.info("mergeAccumulatedTotals() Start");
		Map tempMap = (Map) accumulatedTotals[0];
		Iterator it = tempMap.keySet().iterator();
		// accumulating request
		while (it.hasNext()) {
			String key = (String) it.next();
			if (tempMap.containsKey(key)) {
				if (this.mergedCollectionTable.containsKey(key.toString())) {
					List list = (ArrayList) tempMap.get(key.toString());
					List mList = (ArrayList) this.mergedCollectionTable.get(key.toString());
					mList.addAll(list);
					this.mergedCollectionTable.put(key.toString(), mList);
				} else {
					List list = (ArrayList) tempMap.get(key.toString());
					this.mergedCollectionTable.put(key.toString(), list);
				}
			}
		}
		// accumulating cancel bill list
		List<String> cancelBillInvoicePKList = (List<String>) accumulatedTotals[1];
		if (cancelBillInvoicePKList != null && !cancelBillInvoicePKList.isEmpty()) {
			this.mergedCancelBillInvoicePKList.addAll(cancelBillInvoicePKList);
		}
	}

	@Override
	public void restoreState() {
	}

	@Override
	public void acceptChanges() {
	}

	@Override
	public void storeState() {
	}

}