package com.ce.sadad.invoice.fatoms.batch;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

public class RepaymentInvoiceGenContext extends AbstractPersistableFatomContext {

	private static final long serialVersionUID = 1L;
	private static final String PROCESS_CLASSNAME = loadProcessClassName("CEBillInvoiceforInstalment",
			"com.ce.sadad.invoice.fatoms.batch.RepaymentInvoiceGenProcess");
	private Map inputTagDataMap;
	private Map outputTagDataMap;
	private String batchProcessName;
	private String serviceName;
	private Object[] additionalParams;
	
	public RepaymentInvoiceGenContext(String batchProcessName) {
		this.batchProcessName = batchProcessName;
		this.additionalParams = new Object[2];
		this.inputTagDataMap = new HashMap();
		this.outputTagDataMap = new HashMap();
	}

	@Override
	public boolean isMultiNodeSupported() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setOutputTagDataMap(Map paramMap) {
		outputTagDataMap = paramMap;
		
	}

	@Override
	public Map getOutputTagDataMap() {
		
		return outputTagDataMap;
	}

	@Override
	public void setInputTagDataMap(Map paramMap) {
		inputTagDataMap = paramMap;
		
	}

	@Override
	public Map getInputTagDataMap() {
		
		return inputTagDataMap;
	}

	@Override
	public String getBatchProcessName() {
		
		return batchProcessName;
	}

	@Override
	public void setBatchProcessName(String batchProcessName) {
		
		this.batchProcessName = batchProcessName;
	}

	@Override
	public void setAdditionalProcessParams(Object[] paramArrayOfObject) {
		additionalParams = paramArrayOfObject;
		
	}

	@Override
	public Object[] getAdditionalProcessParams() {
		
		return Arrays.copyOf(this.additionalParams, this.additionalParams.length);
	}

	/**
	 * @return the serviceName
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * @param serviceName the serviceName to set
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the additionalParams
	 */
	public Object[] getAdditionalParams() {
		return additionalParams;
	}

	/**
	 * @param additionalParams the additionalParams to set
	 */
	public void setAdditionalParams(Object[] additionalParams) {
		this.additionalParams = additionalParams;
	}

	/**
	 * @return the processClassname
	 */
	@Override
	public String getProcessClassName() {
		return PROCESS_CLASSNAME;
	}



}
