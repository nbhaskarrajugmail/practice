package com.ce.sadad.invoice.fatoms.batch;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_UPDATEBILLINVOICEGENTAG;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class UpdateBillInvoiceGenProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(UpdateBillInvoiceGenProcess.class.getName());
	private AbstractProcessAccumulator accumulator;
	private IPersistenceObjectsFactory factory;

	public UpdateBillInvoiceGenProcess(AbstractPersistableFatomContext context) {
		super(context);
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return this.accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();
	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new UpdateBillInvoiceGenAccumulator(accumulatorArgs);
	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		logger.info("UpdateBillInvoiceGenProcess -- process method");

		String requestId = (String) context.getInputTagDataMap().get("REQUESTID");
		ArrayList<String> elements = new ArrayList<String>();

		int pageSize = this.context.getPageSize();
		int fromValue = (pageToProcess - 1) * pageSize + 1;
		int toValue = pageToProcess * pageSize;

		this.factory = BankFusionThreadLocal.getPersistanceFactory();

		ArrayList<Object> queryParams = new ArrayList<Object>();
		queryParams.add(fromValue);
		queryParams.add(toValue);
		queryParams.add(SadadMessageConstants.UPDATE_BILL_INVOICE_STAGE_NEW);
		String fetchFromTagRecords = " WHERE " + IBOCE_UPDATEBILLINVOICEGENTAG.ROWSEQID + " BETWEEN ? AND ? AND "
				+ IBOCE_UPDATEBILLINVOICEGENTAG.TAGSTATUS + " = ? ";
		@SuppressWarnings("unchecked")
		List<IBOCE_UPDATEBILLINVOICEGENTAG> cancelBillInvoiceGenTags = factory
				.findByQuery(IBOCE_UPDATEBILLINVOICEGENTAG.BONAME, fetchFromTagRecords, queryParams, null, true);

		ArrayList<InvoiceData> updateBillInvoiceList = new ArrayList<>();
		ArrayList<String> updateBillInvoicePKList = new ArrayList<>();

		for (IBOCE_UPDATEBILLINVOICEGENTAG updateBillInvoice : cancelBillInvoiceGenTags) {
			updateBillInvoice.setF_TAGSTATUS(SadadMessageConstants.UPDATE_BILL_INVOICE_STAGE_INPROGRESS);
			String billAccount = updateBillInvoice.getF_BILLACCT();
			String billAction = updateBillInvoice.getF_BILLACTION();
			String billCategory = updateBillInvoice.getF_BILLCATEGORY();
			String billInvoiceIDPK = updateBillInvoice.getF_BILLINVOICEPKEY();
			BigDecimal existingBillInvoiceAmt = updateBillInvoice.getF_BILLAMT();
			BigDecimal repaymentAmt = updateBillInvoice.getF_REPAYMENTPAID();
			BigDecimal finalBillAmount = existingBillInvoiceAmt;
			logger.info("Update Bill Invoice - Process - [" + billAccount + "] ExistingBillInvoiceAmt: "
					+ existingBillInvoiceAmt);

			String billInvoiceByIDPKSql = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";
			ArrayList<Object> paramsInner = new ArrayList<>();
			paramsInner.add(billInvoiceIDPK);
			IBOCE_BILLINVOICE billInvoiceRecord = (IBOCE_BILLINVOICE) BankFusionThreadLocal.getPersistanceFactory()
					.findFirstByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceByIDPKSql, paramsInner, true);

			InvoiceData data = new InvoiceData();
			if (!this.isProcessedAlready(billInvoiceRecord)) {
				// if grace period expired then customer will loose the subsidy
				try {
					BigDecimal subsidyAmount = this.calculateSubsidy(billInvoiceRecord);
					finalBillAmount = finalBillAmount.add(subsidyAmount);
					logger.info(
							"Update Bill Invoice - Process - [" + billAccount + "] SubsidyAmount: " + subsidyAmount);
				} catch (Exception e) {
					ManageJobStatus.updateJobStatusCode(CEConstants.S, "SUBSIDY_GRACE_PERIOD - MISSING", requestId);
					logger.error(e.getMessage());
					break;
				}

				billAction = SadadMessageConstants.UPDATE;

				if (repaymentAmt.compareTo(BigDecimal.ZERO) > 0) {
					logger.info("Update Bill Invoice - Process - [" + billAccount + "] RepaymentAmt: " + repaymentAmt);
					// skip this bill invoice since there's no update
					finalBillAmount = finalBillAmount.subtract(repaymentAmt);
				}

				// avoid raising an update when there's no diff in amount
				if ((finalBillAmount.subtract(existingBillInvoiceAmt)).compareTo(BigDecimal.ZERO) != 0) {
					// amount can be negative on only when the amount is fully paid on or before
					// subsidy expire date
					if (finalBillAmount.compareTo(BigDecimal.ZERO) <= 0) {
						// billAction = SadadMessageConstants.EXPIRE;
						finalBillAmount = BigDecimal.ZERO;
					}

					data.setBillAccount(billAccount);
					data.setBillAction(billAction);
					data.setBillCategory(billCategory);
					logger.info("Update Bill Invoice - Process - [" + billAccount + "] FinalBillAmount: "
							+ finalBillAmount);
					data.setBillAmount(finalBillAmount);
					data.setBillCycle(billInvoiceRecord.getF_BILLCYCLE());
					data.setInvoiceId(billInvoiceRecord.getF_BILLINVOICENO());
					data.setDueDate(billInvoiceRecord.getF_BILLDUEDATE());

					// Bill Update
					billInvoiceRecord.setF_BILLAMT(finalBillAmount);
					billInvoiceRecord.setF_BILLACTION(billAction);

					updateBillInvoicePKList.add(billInvoiceRecord.getBoID());
					// Invoice Data
					updateBillInvoiceList.add(data);
				} else {
					// processed on the same day in the previous execution
					// still add to raise the update bill only if failed
					if (billInvoiceRecord.getF_BILLSTATUS().equals(CEConstants.F)) {
						// Invoice Data
						updateBillInvoiceList.add(data);
						updateBillInvoicePKList.add(billInvoiceRecord.getBoID());
					}
				}
				// when the bill is updated
				java.sql.Date today = SystemInformationManager.getInstance().getBFBusinessDate();
				billInvoiceRecord.setF_BILLLASTUPDATEDATE(today);
			}

			if (updateBillInvoiceList != null && updateBillInvoiceList.size() > 0) {
				String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(updateBillInvoiceList,
						SadadMessageConstants.REPAY, requestId);
				String reqXML = message.toString();
				logger.info("Update Bill Invoice Request: " + reqXML);
				elements.add(reqXML);
				Object[] accumulatorArgs = new Object[3];
				accumulatorArgs[0] = elements;
				accumulatorArgs[1] = requestId;
				accumulatorArgs[2] = updateBillInvoicePKList;
				this.accumulator.accumulateTotals(accumulatorArgs);
			}
		}
		return this.accumulator;
	}

	private BigDecimal calculateSubsidy(IBOCE_BILLINVOICE billInvoice) throws Exception {
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		int gracePeriod = BillInvoiceHelper.getGracePeriod();
		java.sql.Date today = this.getTodaySqlDatewithTimeZero();
		java.sql.Date gracePeriodDate = AddDaysToDate.run(gracePeriod, billInvoice.getF_BILLDUEDATE());

		// if grace period is expired then deduct subsidy
		List<IBOCE_IB_PaymentSchBreakup> schBreakDtlList = null;
		if (today.compareTo(gracePeriodDate) == 0) {
			schBreakDtlList = BillInvoiceHelper.getSchBreakUp(billInvoice.getF_BILLACCT(),
					billInvoice.getF_BILLDUEDATE());
			if (schBreakDtlList != null && !schBreakDtlList.isEmpty()) {
				for (IBOCE_IB_PaymentSchBreakup payBreakup : schBreakDtlList) {
					if (payBreakup.getF_IBSUBSIDYAMNT() != null
							&& payBreakup.getF_IBSUBSIDYAMNT().compareTo(BigDecimal.ZERO) > 0) {
						subsidyAmount = subsidyAmount.add(payBreakup.getF_IBSUBSIDYAMNT());
					}
				}
			}
		}
		return subsidyAmount;
	}

	private java.sql.Date getTodaySqlDatewithTimeZero() {
		Date datetime = SystemInformationManager.getInstance().getBFBusinessDate();
		return CEDateHelper.utilDateToSqlDate(datetime);
	}

	private Boolean isProcessedAlready(IBOCE_BILLINVOICE billInvoice) {
		java.sql.Date today = this.getTodaySqlDatewithTimeZero();
		java.sql.Date billLastUpdateDate = billInvoice.getF_BILLLASTUPDATEDATE();
		if (billLastUpdateDate != null && today.compareTo(billLastUpdateDate) == 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

}