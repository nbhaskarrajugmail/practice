package com.ce.sadad.invoice.fatoms.batch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class RepaymentInvoiceGenAccumulator extends AbstractProcessAccumulator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CLASS_NAME = RepaymentInvoiceGenAccumulator.class.getName();
	private transient final static Log logger = LogFactory.getLog(CLASS_NAME);
	private Map collectionTable = Collections.synchronizedMap(new HashMap());
	private Map mergedCollectionTable = Collections.synchronizedMap(new HashMap());
	private List merged = new ArrayList();

	public RepaymentInvoiceGenAccumulator(Object[] args) {
		super(args);
	}

	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		if (this.merged == null) {
			this.merged = new ArrayList();
		}
		this.merged.add(acc);
	}

	@Override
	public void accumulateTotals(Object[] data) {
		ArrayList invoices = (ArrayList) data[0];
		String requestIdKey = (String) data[1];
		if (this.collectionTable.containsKey(requestIdKey.toString())) {
			List list = (ArrayList) collectionTable.get(requestIdKey.toString());
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);

		} else {
			List list = new ArrayList();
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);
		}
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] processWorkerTotals = new Object[1];
		processWorkerTotals[0] = this.collectionTable;
		return processWorkerTotals;
	}

	@Override
	public Object[] getMergedTotals() {
		Object[] processWorkerTotals = (Object[]) null;
		Object[] ret = new Object[1];
		logger.info("in getMergedTotals()-> merged list size:" + merged.size());
		Iterator iterator = this.merged.iterator();
		this.mergedCollectionTable.clear();
		while (iterator.hasNext()) {
			AbstractProcessAccumulator accumulator = (AbstractProcessAccumulator) iterator.next();
			processWorkerTotals = accumulator.getProcessWorkerTotals();
			mergeAccumulatedTotals(processWorkerTotals);
		}
		mergeAccumulatedTotals(getProcessWorkerTotals());
		ret[0] = this.mergedCollectionTable;
		return ret;
	}

	@Override
	public void mergeAccumulatedTotals(Object[] accumulatedTotals) {
		logger.info("mergeAccumulatedTotals() Start");
		Map tempMap = (Map) accumulatedTotals[0];
		Iterator it = tempMap.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			if (tempMap.containsKey(key)) {
				if (this.mergedCollectionTable.containsKey(key.toString())) {
					List list = (ArrayList) tempMap.get(key.toString());
					List mList = (ArrayList) this.mergedCollectionTable.get(key.toString());
					mList.addAll(list);
					this.mergedCollectionTable.put(key.toString(), mList);
				} else {
					List list = (ArrayList) tempMap.get(key.toString());
					this.mergedCollectionTable.put(key.toString(), list);
				}
			}

		}
	}

	@Override
	public void storeState() {
	}

	@Override
	public void restoreState() {
	}

	@Override
	public void acceptChanges() {
	}

}
