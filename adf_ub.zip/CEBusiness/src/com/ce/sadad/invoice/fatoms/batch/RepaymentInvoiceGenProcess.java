package com.ce.sadad.invoice.fatoms.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.invoice.InvoiceCheckGenerator;
import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.BillInvoiceHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_REPAYINVOICEGENTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_SurplusAccountDetails;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.utils.GUIDGen;

public class RepaymentInvoiceGenProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(RepaymentInvoiceGenProcess.class.getName());
	private static String GENERIC_QUERY = "SELECT " + IBOCE_REPAYINVOICEGENTAG.ACCOUNTID + " AS ACCOUNTID, "
			+ IBOCE_REPAYINVOICEGENTAG.AMOUNTDUE + " AS REPAYAMOUNT, " + IBOCE_REPAYINVOICEGENTAG.DUEDATE
			+ " AS DUEDATE FROM " + IBOCE_REPAYINVOICEGENTAG.BONAME + " WHERE " + IBOCE_REPAYINVOICEGENTAG.ROWSEQID
			+ " BETWEEN ? AND ? ";

	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static String QUERY_SUBSIDY = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
			+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ? ";
	private static String LOANSTATUS_ARREARS = "2411";
	private static String LOANSTATUS_NORMAL = "2410";
	private static String QUERY_LOANARREAS = " WHERE " + IBOLoanRepayments.ACCOUNTID + " = ? AND "
			+ IBOLoanRepayments.DUEDATE + " < ?";
	private static String QUERY_SURPLUSACCOUNT = " WHERE " + IBOUB_CNF_SurplusAccountDetails.UBACCOUNTID + " = ? ";
	private static String QUERY_ACCOUNTDETAIL = " WHERE " + IBOAttributeCollectionFeature.ACCOUNTID + " = ? ";
	private static final String LOANSTATUS_FUNDREL = "FUNDREL";

	private IPersistenceObjectsFactory factory;
	private AbstractProcessAccumulator accumulator;

	public RepaymentInvoiceGenProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = ((RepaymentInvoiceGenContext) context);
	}

	@Override
	public void init() {
		initialiseAccumulator();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		logger.info("RepaymentInvoiceGenProcess -- process method");
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList<String> elements = new ArrayList<String>();
		int pageSize = this.context.getPageSize();
		int fromValue = (pageToProcess - 1) * pageSize + 1;
		int toValue = pageToProcess * pageSize;
		ArrayList params1 = new ArrayList();
		params1.add(Integer.valueOf(fromValue));
		params1.add(Integer.valueOf(toValue));
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(GENERIC_QUERY, params1, null, true);
		List<InvoiceData> billInfoList = new ArrayList<InvoiceData>();
		String reqID = (String) context.getInputTagDataMap().get("REQUESTID");

		String batchReqID = reqID + "_" + pageToProcess;
		Integer processedCount = 0;
		for (SimplePersistentObject record : records) {
			String loanAccount = "";
			try {
				loanAccount = (String) record.getDataMap().get("ACCOUNTID");
				BigDecimal invoiceAmount = (BigDecimal) record.getDataMap().get("REPAYAMOUNT");
				logger.info("Repyament Bill Invoice - Process - [" + loanAccount + "] InvoiceAmount: " + invoiceAmount);
				Date dueDate = (Date) record.getDataMap().get("DUEDATE");
				BigDecimal arrearAmount = BigDecimal.ZERO;

				// Check if loan is in Arrears
				ArrayList params = new ArrayList();
				params.add(loanAccount);
				IBOLendingFeature loanDetail = null;
				ArrayList<IBOLendingFeature> loanDetails = (ArrayList<IBOLendingFeature>) factory
						.findByQuery(IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, null, true);
				if (null != loanDetails && !loanDetails.isEmpty()) {
					loanDetail = loanDetails.get(0);
					String loanStatus = loanDetail.getF_LOANSTATUS();
					if (loanStatus.equals(LOANSTATUS_ARREARS) || loanStatus.equals(LOANSTATUS_NORMAL)
							|| loanStatus.equals(LOANSTATUS_FUNDREL)) {
						// Carry on Processing. Else will skip the processing.
					} else {
						logger.info(
								"Loan Account " + loanDetail.getF_ACCOUNTID() + " is neither NORMAL nor in ARREARS");
						continue;
					}
					if (loanDetail.getF_REDUCINGPRINCIPAL().compareTo(BigDecimal.ZERO) == 0) {
						// Loan Not Disbursed all fully paid
						continue;
					}
					if (loanDetail.getF_LOANSTATUS().equals(LOANSTATUS_ARREARS)) {
						arrearAmount = getArrearsAmount(loanAccount, dueDate);
					}
				} else {
					continue;
				}
				// Check for subsidy and deduct the amount
				BigDecimal subsidy = getSubsidyAmount(loanDetail.getF_LOANREFERENCE(), dueDate);
				logger.info("Repyament Bill Invoice - Process - [" + loanAccount + "] SubsidyAmount: " + subsidy);
				invoiceAmount = invoiceAmount.subtract(subsidy);
				BigDecimal surplusAmount = getSurplusAmount(loanAccount);
				logger.info("Repyament Bill Invoice - Process - [" + loanAccount + "] ArrearAmount: " + arrearAmount);
				invoiceAmount = invoiceAmount.add(arrearAmount);
				logger.info("Repyament Bill Invoice - Process - [" + loanAccount + "] SurplusAmount: " + surplusAmount);
				invoiceAmount = invoiceAmount.subtract(surplusAmount);
				String invoiceId = GUIDGen.getNewGUID();
				while (!new InvoiceCheckGenerator().isInvoiceIdNotPresent(invoiceId)) {
					invoiceId = GUIDGen.getNewGUID();
				}
				logger.info("Repyament Bill Invoice - Process - [" + loanAccount + "] InvoiceAmount: " + invoiceAmount);
				// to avoid raising bill in case of surplus amount matches the bill invoice
				// amount
				if (invoiceAmount.compareTo(BigDecimal.ZERO) > 0) {
					InvoiceData data = new InvoiceData();
					data.setBillAccount(loanAccount);
					data.setBillAmount(invoiceAmount);
					data.setVatAmount(BigDecimal.ZERO);
					data.setDueDate(dueDate);
					try {
						data.setExpiryDate(getExpiryDate(dueDate));
					} catch (Exception e) {
						e.printStackTrace();
						billInfoList.clear();
						break;
					}
					data.setBillCategory(SadadMessageConstants.REPAY);
					data.setInvoiceId(invoiceId);
					data.setRequestId(batchReqID);
					data.setBillAction(SadadMessageConstants.INITIAL);
					// int billCycle = BillInvoiceHelper.billInvoiceCycle(loanAccount, dueDate);
					int billCycle = BillInvoiceHelper.indetifyNewBillCycleByAccount(loanAccount,
							SadadMessageConstants.REPAY);
					data.setBillCycle(billCycle);
					ManageJobStatus.storeRequest(data);
					billInfoList.add(data);
					int count = (Integer) this.context.getInputTagDataMap().get("RECORDCOUNT");
					this.context.getInputTagDataMap().put("RECORDCOUNT", new Integer(count + 1));
					processedCount++;
				}
				this.context.getInputTagDataMap().put(batchReqID, processedCount);
			} catch (Exception e) {
				logger.error("Error while prepareing Bill Invoice on loan account [" + loanAccount + "]");
			}
		}

		if (billInfoList.size() > 0) {
			String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(billInfoList, SadadMessageConstants.REPAY,
					batchReqID);
			String reqXML = message.toString();
			logger.info("Bill Invoice Request: " + reqXML);
			elements.add(reqXML);
			Object[] accumulatorArgs = new Object[2];
			accumulatorArgs[0] = elements;
			accumulatorArgs[1] = reqID;
			this.accumulator.accumulateTotals(accumulatorArgs);
		}
		return this.accumulator;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private BigDecimal getArrearsAmount(String loanAccount, Date dueDate) {
		BigDecimal arrAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList();
		params.add(loanAccount);
		params.add(dueDate);
		ArrayList arrears = (ArrayList) factory.findByQuery(IBOLoanRepayments.BONAME, QUERY_LOANARREAS, params, null,
				false);
		if (null != arrears && !arrears.isEmpty()) {
			for (int i = 0; i < arrears.size(); i++) {
				IBOLoanRepayments arrear = (IBOLoanRepayments) arrears.get(i);
				arrAmount = arrAmount.add(arrear.getF_REPAYMENTUNPAID());
			}
		}
		return arrAmount;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private BigDecimal getSurplusAmount(String loanAccount) {
		BigDecimal surplusAmount = BigDecimal.ZERO;
		String surplusAccount = null;

		ArrayList params = new ArrayList();
		params.add(loanAccount);
		ArrayList SurplusDtls = (ArrayList) factory.findByQuery(IBOUB_CNF_SurplusAccountDetails.BONAME,
				QUERY_SURPLUSACCOUNT, params, null, false);
		if (null != SurplusDtls && !SurplusDtls.isEmpty()) {
			for (int i = 0; i < SurplusDtls.size(); i++) {
				IBOUB_CNF_SurplusAccountDetails surplus = (IBOUB_CNF_SurplusAccountDetails) SurplusDtls.get(i);
				surplusAccount = surplus.getF_UBSURPLUSACCOUNT();
				ArrayList params1 = new ArrayList();
				params1.add(surplusAccount);
				List accountDetails = (List) factory.findByQuery(IBOAttributeCollectionFeature.BONAME,
						QUERY_ACCOUNTDETAIL, params1, null, false);
				if (null != accountDetails && !accountDetails.isEmpty()) {
					// for (int j = 0; j < accountDetails.size(); j++) {
					IBOAttributeCollectionFeature accountDtl = (IBOAttributeCollectionFeature) accountDetails.get(0);
					if (null != accountDtl.getF_CLEAREDBALANCE()
							&& accountDtl.getF_CLEAREDBALANCE().compareTo(BigDecimal.ZERO) == 1)
						surplusAmount = accountDtl.getF_CLEAREDBALANCE();

					// }
				}
			}
		}
		return surplusAmount;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private BigDecimal getSubsidyAmount(String loanReference, Date dueDate) {
		logger.info("Inside getSubsidyAmount:" + IBOCE_IB_PaymentSchBreakup.BONAME);
		BigDecimal subsidyAmount = BigDecimal.ZERO;
		ArrayList params = new ArrayList();
		params.add(loanReference);
		params.add(dueDate);
		List<IBOCE_IB_PaymentSchBreakup> payBreakUps = (List<IBOCE_IB_PaymentSchBreakup>) factory
				.findByQuery("CE_IB_PaymentSchBreakup", QUERY_SUBSIDY, params, null, false);
		if (null != payBreakUps && !payBreakUps.isEmpty()) {
			for (IBOCE_IB_PaymentSchBreakup payBreakup : payBreakUps) {
				if (payBreakup.getF_IBSUBSIDYAMNT() != null
						&& payBreakup.getF_IBSUBSIDYAMNT().compareTo(BigDecimal.ZERO) > 0) {
					subsidyAmount = subsidyAmount.add(payBreakup.getF_IBSUBSIDYAMNT());
				}
			}
		}
		return subsidyAmount;
	}

	private Date getExpiryDate(Date dueDate) throws Exception {
		String expiryDays = "";
		try {
			expiryDays = new CEUtil().getModuleConfigurationValue(CEConstants.CE_SADAD_INTERFACE,
					SadadMessageConstants.DAYS_INVOICE_EXPIRY);
		} catch (Exception e) {
			throw new Exception("INVOICE_EXPIRY_PERIOD - Module configuration is missing ");
		}
		int days = Integer.parseInt(expiryDays);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dueDate);
		cal.add(Calendar.DATE, days);
		return new Date(cal.getTime().getTime());
	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new RepaymentInvoiceGenAccumulator(accumulatorArgs);

	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return this.accumulator;
	}

}