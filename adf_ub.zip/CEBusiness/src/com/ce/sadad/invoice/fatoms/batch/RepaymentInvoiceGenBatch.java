package com.ce.sadad.invoice.fatoms.batch;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.calendar.functions.NextWorkingDateForDate;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.workingday.runtime.toolkit.expression.function.IsWorkingDay;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_JOBSTATUS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_REPAYINVOICEGENTAG;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_RepaymentInvoiceGenBatch;
import com.trapedza.bankfusion.utils.GUIDGen;

/** @author Subhajit */
public class RepaymentInvoiceGenBatch extends AbstractCE_RepaymentInvoiceGenBatch {

	private transient final static Log logger = LogFactory.getLog(RepaymentInvoiceGenBatch.class.getName());
	private static final String BATCH_PROCESS_NAME = "CEBillInvoiceforInstalment";
	private static final String SELECT_MAX_QUERY = "SELECT MAX(" + IBOCE_REPAYINVOICEGENTAG.ROWSEQID
			+ ") AS TOTAL FROM " + IBOCE_REPAYINVOICEGENTAG.BONAME;

	private static final String NEW_TAG_TABLE_INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_REPAYINVOICEGENTAG ( CEROWSEQIDPK,CEACCOUNTID,CEAMOUNTDUE,CEDUEDATE,VERSIONNUM) "
			+ " SELECT ((ROW_NUMBER() OVER (ORDER BY LNLOANACCOUNTID)) +  (SELECT COALESCE(MAX(CAST (CEROWSEQIDPK AS INTEGER) ), 0) FROM CUSTOMEXTN.CETB_REPAYINVOICEGENTAG)) CEROWSEQPK,"
			+ " LNLOANACCOUNTID,LNPAYMENTAMT,LNPAYMENTDT,0 VERSIONNUM "
			+ " FROM LENDING.LNTB_LOANSCHEDULE WHERE TRUNC(LNPAYMENTDT) = TRUNC(?) AND LNLOANACCOUNTID NOT IN "
			+ " (SELECT CEBILLACCT FROM CUSTOMEXTN.CETB_BILLINVOICE WHERE CEBILLDUEDATE = LNPAYMENTDT AND CEBILLACCT = LNLOANACCOUNTID AND CEBILLACTION IN (?,?) AND CEBILLSTATUS = ?)";

	private static String LAST_SUCCESS_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Success' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " DESC ";

	private static String FIRST_FAIL_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND " + IBOCE_JOBSTATUS.JOBSTATUS
			+ " = 'Failed' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE + " ASC ";

	private static final String MARK_FAILED_STATUS_INVOICE_ON_SAME_DAY_ON_REEXECUTION_AS_EXPIRED = " WHERE  "
			+ IBOCE_BILLINVOICE.BILLSTATUS + "<> ? AND " + IBOCE_BILLINVOICE.BILLGENDATE + " =?";

	private IPersistenceObjectsFactory factory;
	private String jobId = "REPAY_INV_GEN";
	private int invGenDaysBefore = 1; // From Module Configuration

	/**
	 * 
	 */
	public RepaymentInvoiceGenBatch() {

	}

	/**
	 * @param context
	 */
	@SuppressWarnings("deprecation")
	public RepaymentInvoiceGenBatch(BankFusionEnvironment env) {
		super(env);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#getFatomContext()
	 */
	@Override
	protected AbstractFatomContext getFatomContext() {
		return new RepaymentInvoiceGenContext("CEBillInvoiceforInstalment");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#processBatch(com.
	 * trapedza.bankfusion.servercommon.commands.BankFusionEnvironment,
	 * com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {

		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		Date lastSuccessDate = getLastSuccessDate();
		if (lastSuccessDate != null && today.compareTo(lastSuccessDate) <= 0) {
			logger.info("[" + BATCH_PROCESS_NAME + "] Date Later than today has been processed already");
			setF_OUT_Status(true);
			return;
		}
		if (CEDateHelper.areDatesSame(today, lastSuccessDate)) {
			logger.info("[" + BATCH_PROCESS_NAME + "]Today's record has been processed already");
			setF_OUT_Status(true);
			return;
		}
		invGenDaysBefore = Integer.parseInt(new CEUtil().getModuleConfigurationValue(CEConstants.CE_SADAD_INTERFACE,
				SadadMessageConstants.DAYS_BEFORE_INVGEN));
		// Clear tag table on beginning
		this.factory.bulkDeleteAll(IBOCE_REPAYINVOICEGENTAG.BONAME);

		// Mark failed execution on same day as EXPIRE [Re-Execution on same day]
		this.updateBillInvoiceDtls(today);

		// populateTagTable(today);
		this.insertTagTable(today);

		boolean lookForward = true;
		Date tempDate = today;
		while (lookForward) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(tempDate);
			cal.add(Calendar.DATE, 1);
			Date nextDay = new Date(cal.getTime().getTime());
			if (IsWorkingDay.run("BANK", "", Integer.valueOf(0), nextDay).booleanValue()) {
				lookForward = false;
				break;
			}
			this.insertTagTable(nextDay);
			tempDate = nextDay;
			lookForward = true;
		}
		// Look Behind Last Success Date

		if (lastSuccessDate != null) {
			processPreviousRecords(lastSuccessDate);
		}

		int recCount = maxOfTagTable();
		// Log on JobStatus Table
		String requestId = GUIDGen.getNewGUID();
		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", new Integer(0));
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(jobId);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());

		jobStatus.setRecordCount(recCount);
		ManageJobStatus.insertJobStatus(jobStatus);

		this.factory.commitTransaction();
		this.factory.beginTransaction();

		logger.info("Call Batch Service");
		if (recCount > 0) {
			BatchService service = (BatchService) ServiceManager.getService("BatchService");
			boolean status = service.runBatch(env, context);
			setF_OUT_Status(status);
		} else {
			ManageJobStatus.updateJobStatusCode(CEConstants.S, "No Records to Process", requestId);
			setF_OUT_Status(true);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#setOutputTags(com.
	 * trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	protected void setOutputTags(AbstractFatomContext context) {

	}

	private Date getRepaymentDate(Date runDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(runDate);
		cal.add(Calendar.DATE, invGenDaysBefore);
		Date repayDate = new Date(cal.getTime().getTime());
		return repayDate;
	}

	private int maxOfTagTable() {
		Integer count = 0;
		@SuppressWarnings("unchecked")
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(SELECT_MAX_QUERY, null, null, true);
		if (null != records && !records.isEmpty()) {
			SimplePersistentObject record = records.get(0);
			count = Integer.parseInt((String) record.getDataMap().get("TOTAL"));
		}
		return count;
	}

	@SuppressWarnings("unchecked")
	private Date getLastSuccessDate() {

		@SuppressWarnings("rawtypes")
		ArrayList params = new ArrayList();
		params.add(jobId);
		IBOCE_JOBSTATUS jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME,
				LAST_SUCCESS_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			return jobStatus.getF_JOBEXECDATE();
		}

		jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, FIRST_FAIL_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			Date date = jobStatus.getF_JOBEXECDATE();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, -1);
			date = new Date(cal.getTime().getTime());
			return date;
		}
		return null;
	}

	private void processPreviousRecords(Date lastSuccessDate) {
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();

		Date nextWorkingDate = NextWorkingDateForDate.run("BANK", "", Integer.valueOf(0), lastSuccessDate);
		while (true) {
			if (CEDateHelper.areDatesSame(nextWorkingDate, today)) {
				return;
			}
			this.insertTagTable(nextWorkingDate);
			boolean lookForward = true;
			Date tempDate = nextWorkingDate;
			while (lookForward) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(tempDate);
				cal.add(Calendar.DATE, 1);
				Date nextDay = new Date(cal.getTime().getTime());
				if (IsWorkingDay.run("BANK", "", Integer.valueOf(0), nextDay).booleanValue()) {
					lookForward = false;
					break;
				}
				this.insertTagTable(nextDay);
				tempDate = nextDay;
				lookForward = true;
			}
			nextWorkingDate = NextWorkingDateForDate.run("BANK", "", Integer.valueOf(0), nextWorkingDate);
		}
	}

	@SuppressWarnings("deprecation")
	private void insertTagTable(Date date) {
		try {
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = null;
			ps = con.prepareStatement(NEW_TAG_TABLE_INSERT_QUERY);
			ps.setDate(1, getRepaymentDate(date));
			ps.setString(2, SadadMessageConstants.INITIAL);
			ps.setString(3, SadadMessageConstants.UPDATE);
			ps.setString(4, CEConstants.S);
			int result = ps.executeUpdate();
			logger.info("result:" + result);
			logger.info("Statement:" + ps.toString());
			logger.info("Data inserted into tag");
		} catch (SQLException e) {
			logger.warn("No Accoutns are avaialble for processing");
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateBillInvoiceDtls(Date today) {
		ArrayList columns = new ArrayList();
		columns.add(IBOCE_BILLINVOICE.BILLACTION);

		ArrayList updateValues = new ArrayList();
		updateValues.add(SadadMessageConstants.EXPIRE);

		ArrayList params = new ArrayList();
		params.add(CEConstants.S);
		params.add(today);
		this.factory.bulkUpdate(IBOCE_BILLINVOICE.BONAME,
				MARK_FAILED_STATUS_INVOICE_ON_SAME_DAY_ON_REEXECUTION_AS_EXPIRED, params, columns, updateValues);
	}

}