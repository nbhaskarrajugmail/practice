package com.ce.sadad.invoice.fatoms.batch;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class UpdateBillInvoiceGenPreProcess implements IBatchPreProcess {

	@Override
	public void init(BankFusionEnvironment arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void process(AbstractFatomContext arg0) {
		// TODO Auto-generated method stub

	}

}