package com.ce.sadad.invoice.fatoms.batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_UPDATEBILLINVOICEGENTAG;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_UpdateBillInvoiceGenBatch;

public class UpdateBillInvoiceGenBatch extends AbstractCE_UpdateBillInvoiceGenBatch {

	private transient final static Log logger = LogFactory.getLog(UpdateBillInvoiceGenBatch.class.getName());
	private IPersistenceObjectsFactory factory;

	private static final String TAG_TABLE_INSERT_SQL = "INSERT INTO CUSTOMEXTN.CETB_UPDATEBILLINVOICEGENTAG "
			+ "  (CEROWSEQIDPK,CEBILLINVOICEPKEY,CEBILLACCT,CEBILLAMT,CEBILLACTION,CEBILLCATEGORY,CEREPAYMENTPAID,CETAGSTATUS,VERSIONNUM) "
			+ "SELECT ((ROW_NUMBER() OVER (ORDER BY CEIDPK)) + (SELECT COALESCE(MAX(CAST(CEROWSEQIDPK AS INTEGER)),0) FROM CUSTOMEXTN.CETB_UPDATEBILLINVOICEGENTAG)) CEROWSEQPK, "
			+ " CE.CEIDPK, CE.CEBILLACCT, CE.CEBILLAMT, CE.CEBILLACTION, CE.CEBILLCATEGORY, SUM(L.REPAYMENTPAID), "
			+ SadadMessageConstants.UPDATE_BILL_INVOICE_STAGE_NEW + " AS CETAGSTATUS, 0 AS VERSIONNUM "
			+ " FROM CUSTOMEXTN.CETB_BILLINVOICE CE, WASADMIN.LOANREPAYMENTS L "
			+ " WHERE L.ACCOUNTID = CE.CEBILLACCT AND L.PAIDDATE BETWEEN ? AND ? AND CE.CEBILLACTION <> ? "
			+ " GROUP BY L.ACCOUNTID, CE.CEBILLACCT, CE.CEIDPK, CE.CEBILLAMT, CE.CEBILLACTION, CE.CEBILLCATEGORY ";

	public UpdateBillInvoiceGenBatch() {
	}

	@SuppressWarnings("deprecation")
	public UpdateBillInvoiceGenBatch(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new UpdateBillInvoiceGenContext(SadadMessageConstants.UPDATE_BILL_INVOICE_BATCH_PROCESS_NAME);
	}

	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {
		logger.info("[" + SadadMessageConstants.UPDATE_BILL_INVOICE_BATCH_PROCESS_NAME + "] - Begin");
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		this.updateBillInvoiceProcess(env, context);
		logger.info("[" + SadadMessageConstants.UPDATE_BILL_INVOICE_BATCH_PROCESS_NAME + "] - End");
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
	}

	@SuppressWarnings("unchecked")
	private void updateBillInvoiceProcess(BankFusionEnvironment env, AbstractFatomContext context) {
		Date businessDate = SystemInformationManager.getInstance().getBFBusinessDate();
		Date runDateFrom = new Date();
		Date lastSuccessDate = ManageJobStatus.getLastSuccessDate(SadadMessageConstants.U_INV);
		if (lastSuccessDate != null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(lastSuccessDate);
			cal.add(Calendar.DATE, 1);
			runDateFrom = cal.getTime();
		} else {
			runDateFrom = businessDate;
		}
		// Clear tag table on beginning
		this.factory.bulkDeleteAll(IBOCE_UPDATEBILLINVOICEGENTAG.BONAME);

		// updating common context
		UpdateBillInvoiceGenContext.lastSuccessDate = runDateFrom;

		int isError = this.insertTagTable(TAG_TABLE_INSERT_SQL, runDateFrom, businessDate,
				SadadMessageConstants.EXPIRE);

		logger.info("Call Batch Service RECORDCOUNT [" + isError + "]");
		int recCount = isError;
		String requestId = GUIDGen.getNewGUID();
		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", recCount);

		logger.error("TAG_TABLE_INSERT_SQL [Record Count] - " + recCount);
		String statusMsg = "Begin";
		if (recCount <= 0) {
			statusMsg = "No records";
		}

		this.createJob(requestId, CEConstants.S, statusMsg, recCount);
		@SuppressWarnings("deprecation")
		BatchService service = (BatchService) ServiceManager.getService("BatchService");
		boolean status = service.runBatch(env, context);
		setF_OUT_Status(status);
		this.factory.commitTransaction();
		this.factory.beginTransaction();
	}

	@SuppressWarnings("deprecation")
	private int insertTagTable(String sql, Date runDateFrom, Date businessDate, String billAction) {
		int result = 0;
		try {
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(sql);

			if (billAction != null && runDateFrom != null && businessDate != null) {
				ps.setDate(1, CEDateHelper.utilDateToSqlDate(runDateFrom));
				ps.setDate(2, CEDateHelper.utilDateToSqlDate(businessDate));
				ps.setString(3, billAction);
				result = ps.executeUpdate();
			}

			logger.info("UpdateBillInvoiceGenBatch - result:" + result);
		} catch (SQLException e) {
			if (logger.isErrorEnabled()) {
				logger.error("No Accounts are avaialble for processing");
				logger.error(e.getMessage());
			}
			result = 0;
		}
		return result;
	}

	private void createJob(String reqID, String status, String desc, int recordCount) {
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(reqID);
		jobStatus.setJobId(SadadMessageConstants.U_INV);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		jobStatus.setJobStatus(status);
		jobStatus.setStatusDesc(desc);
		jobStatus.setRecordCount(recordCount);
		ManageJobStatus.insertJobStatus(jobStatus);
	}

}