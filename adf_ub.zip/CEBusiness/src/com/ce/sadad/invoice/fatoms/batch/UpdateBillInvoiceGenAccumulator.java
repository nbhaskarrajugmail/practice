package com.ce.sadad.invoice.fatoms.batch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class UpdateBillInvoiceGenAccumulator extends AbstractProcessAccumulator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private transient final static Log logger = LogFactory.getLog(UpdateBillInvoiceGenAccumulator.class.getName());

	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap collectionTable = null;
	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap mergedCollectionTable = null;
	@SuppressWarnings("rawtypes")
	private List merged = null;

	private List<String> updateBillInvoicePKList = null;
	private List<String> mergedUpdateBillInvoicePKList = null;

	public UpdateBillInvoiceGenAccumulator() {
		super();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public UpdateBillInvoiceGenAccumulator(Object[] args) {
		super(args);
		this.merged = new ArrayList();
		this.updateBillInvoicePKList = Collections.synchronizedList(new ArrayList());
		this.mergedUpdateBillInvoicePKList = Collections.synchronizedList(new ArrayList());
		this.collectionTable = new ConcurrentHashMap();
		this.mergedCollectionTable = new ConcurrentHashMap();
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		if (this.merged == null) {
			this.merged = new ArrayList();
		}
		this.merged.add(acc);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void accumulateTotals(Object[] data) {
		ArrayList invoices = (ArrayList) data[0];
		String requestIdKey = (String) data[1];
		List<String> updateBillInvoicePKList = (List) data[2];
		// accumulating request
		if (this.collectionTable.containsKey(requestIdKey.toString())) {
			List list = (ArrayList) collectionTable.get(requestIdKey.toString());
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);
		} else {
			List list = new ArrayList();
			list.add(invoices);
			this.collectionTable.put(requestIdKey.toString(), list);
		}
		// accumulating cancel bill list
		this.updateBillInvoicePKList.addAll(updateBillInvoicePKList);
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] processWorkerTotals = new Object[2];
		// accumulating request
		processWorkerTotals[0] = this.collectionTable;
		// accumulating cancel bill list
		processWorkerTotals[1] = this.updateBillInvoicePKList;
		return processWorkerTotals;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object[] getMergedTotals() {
		Object[] processWorkerTotals = (Object[]) null;
		Object[] ret = new Object[2];
		logger.info("in getMergedTotals()-> merged list size:" + merged.size());
		Iterator iterator = this.merged.iterator();
		// accumulating request
		this.mergedCollectionTable.clear();
		// accumulating cancel bill list
		this.mergedUpdateBillInvoicePKList.clear();
		while (iterator.hasNext()) {
			AbstractProcessAccumulator accumulator = (AbstractProcessAccumulator) iterator.next();
			processWorkerTotals = accumulator.getProcessWorkerTotals();
			this.mergeAccumulatedTotals(processWorkerTotals);
		}
		this.mergeAccumulatedTotals(getProcessWorkerTotals());
		// accumulating request
		ret[0] = this.mergedCollectionTable;
		// accumulating cancel bill list
		ret[1] = this.mergedUpdateBillInvoicePKList;
		return ret;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void mergeAccumulatedTotals(Object[] accumulatedTotals) {
		logger.info("mergeAccumulatedTotals() Start");
		Map tempMap = (Map) accumulatedTotals[0];
		Iterator it = tempMap.keySet().iterator();
		// accumulating request
		while (it.hasNext()) {
			String key = (String) it.next();
			if (tempMap.containsKey(key)) {
				if (this.mergedCollectionTable.containsKey(key.toString())) {
					List list = (ArrayList) tempMap.get(key.toString());
					List mList = (ArrayList) this.mergedCollectionTable.get(key.toString());
					mList.addAll(list);
					this.mergedCollectionTable.put(key.toString(), mList);
				} else {
					List list = (ArrayList) tempMap.get(key.toString());
					this.mergedCollectionTable.put(key.toString(), list);
				}
			}
		}
		// accumulating cancel bill list
		List<String> updateBillInvoicePKList = (List<String>) accumulatedTotals[1];
		if (updateBillInvoicePKList != null && !updateBillInvoicePKList.isEmpty()) {
			this.mergedUpdateBillInvoicePKList.addAll(updateBillInvoicePKList);
		}
	}

	@Override
	public void storeState() {
	}

	@Override
	public void restoreState() {
	}

	@Override
	public void acceptChanges() {
	}

}