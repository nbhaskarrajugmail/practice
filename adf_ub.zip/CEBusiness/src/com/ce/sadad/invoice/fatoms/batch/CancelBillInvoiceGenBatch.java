package com.ce.sadad.invoice.fatoms.batch;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_CANCELBILLINVOICEGENTAG;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_CancelBillInvoiceGenBatch;
import com.trapedza.bankfusion.utils.GUIDGen;

public class CancelBillInvoiceGenBatch extends AbstractCE_CancelBillInvoiceGenBatch {

	private transient final static Log logger = LogFactory.getLog(CancelBillInvoiceGenBatch.class.getName());

	private IPersistenceObjectsFactory factory;

	private static final String TAG_TABLE_INSERT_SQL_1 = "INSERT INTO CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG "
			+ " (CEROWSEQIDPK,CEBILLINVOICEPKEY,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLEXPDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,CETAGSTATUS,VERSIONNUM) "
			+ " SELECT ((ROW_NUMBER() OVER (ORDER BY CEIDPK)) +(SELECT COALESCE(MAX(CAST(CEROWSEQIDPK AS INTEGER)),0) FROM CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG)) CEROWSEQPK, "
			+ " CEIDPK,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLDUEDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,"
			+ SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_NEW
			+ " AS CETAGSTATUS,0 AS VERSIONNUM FROM CUSTOMEXTN.CETB_BILLINVOICE "
			+ " WHERE CEBILLACTION <> ? AND CEBILLCATEGORY = ? AND CEBILLAMT > ? AND CEBILLGENDATE <> ?";

	private static final String TAG_TABLE_INSERT_SQL_2 = "INSERT INTO CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG "
			+ " (CEROWSEQIDPK,CEBILLINVOICEPKEY,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLEXPDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,CETAGSTATUS,VERSIONNUM) "
			+ " SELECT ((ROW_NUMBER() OVER (ORDER BY CEIDPK)) +(SELECT COALESCE(MAX(CAST(CEROWSEQIDPK AS INTEGER)),0) FROM CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG)) CEROWSEQPK, "
			+ " CEIDPK,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLDUEDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,"
			+ SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_NEW
			+ " AS CETAGSTATUS,0 AS VERSIONNUM FROM CUSTOMEXTN.CETB_BILLINVOICE "
			+ " WHERE CEBILLACTION <> ? AND CEBILLCATEGORY = ? AND CEBILLAMT <= ? ";

	private static final String TAG_TABLE_INSERT_SQL_3 = "INSERT INTO CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG "
			+ " (CEROWSEQIDPK,CEBILLINVOICEPKEY,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLEXPDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,CETAGSTATUS,VERSIONNUM) "
			+ " SELECT ((ROW_NUMBER() OVER (ORDER BY CEIDPK)) +(SELECT COALESCE(MAX(CAST(CEROWSEQIDPK AS INTEGER)),0) FROM CUSTOMEXTN.CETB_CANCELBILLINVOICEGENTAG)) CEROWSEQPK, "
			+ " CEIDPK,CEBILLACCT,CEBILLAMT,CEBILLDUEDATE,CEBILLDUEDATE,CEREQUESTKEY,CEBILLINVOICENO,CEBILLACTION,CEBILLCATEGORY,"
			+ SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_NEW
			+ " AS CETAGSTATUS,0 AS VERSIONNUM FROM CUSTOMEXTN.CETB_BILLINVOICE "
			+ " WHERE CEBILLACTION <> ? AND CEBILLCATEGORY = ? AND CEBILLSTATUS <> ?";

	public CancelBillInvoiceGenBatch() {
	}

	@SuppressWarnings("deprecation")
	public CancelBillInvoiceGenBatch(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new CancelBillInvoiceGenContext(SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME);
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {

		logger.info("[" + SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME + "] - Begin");

		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		Date lastSuccessDate = (Date) ManageJobStatus.getLastSuccessDate(SadadMessageConstants.C_INV);
		if (lastSuccessDate != null && today.compareTo(lastSuccessDate) <= 0) {
			logger.info("[" + SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME
					+ "] Date Later than today has been processed already");
			setF_OUT_Status(true);
			return;
		}
		if (CEDateHelper.areDatesSame(today, lastSuccessDate)) {
			logger.info("[" + SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME
					+ "] Today's record has been processed already");
			setF_OUT_Status(true);
			return;
		}

		String requestId = GUIDGen.getNewGUID();
		this.factory = BankFusionThreadLocal.getPersistanceFactory();

		// Clear tag table on beginning
		this.factory.bulkDeleteAll(IBOCE_CANCELBILLINVOICEGENTAG.BONAME);

		int recCount = this.insertTagTable(TAG_TABLE_INSERT_SQL_1, SadadMessageConstants.EXPIRE,
				SadadMessageConstants.REPAY, 0, today);
		logger.info("TAG_TABLE_INSERT_SQL_1 [Record Count] - " + recCount);

		recCount += this.insertTagTable(TAG_TABLE_INSERT_SQL_2, SadadMessageConstants.EXPIRE,
				SadadMessageConstants.REPAY, 0, null);

		recCount += this.insertTagTable(TAG_TABLE_INSERT_SQL_3, SadadMessageConstants.EXPIRE,
				SadadMessageConstants.REPAY, null, null);

		logger.info("TAG_TABLE_INSERT_SQL_2 [Record Count] - " + recCount);

		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", recCount);

		if (recCount > 0) {
			logger.info("Call Batch Service");
			BatchService service = (BatchService) ServiceManager.getService("BatchService");
			boolean status = service.runBatch(env, context);
			this.createJob(requestId, CEConstants.S, "Begin", recCount);
			setF_OUT_Status(status);
		} else {
			logger.info("[" + SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME + "] - No records found");
			this.createJob(requestId, CEConstants.S, "No Records to Process", recCount);
			setF_OUT_Status(Boolean.TRUE);
		}
		this.factory.commitTransaction();
		this.factory.beginTransaction();
		logger.info("[" + SadadMessageConstants.CANCEL_BILL_INVOICE_BATCH_PROCESS_NAME + "] - End");
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
	}

	@SuppressWarnings("deprecation")
	private int insertTagTable(String sql, String billAction, String billCat, Integer billAmount, Date today) {
		int result = 0;
		try {
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(sql);
			if (billAmount != null) {
				// TAG_TABLE_INSERT_SQL_1
				ps.setString(1, billAction);
				ps.setString(2, billCat);
				ps.setInt(3, billAmount);
				if (today != null) {
					// TAG_TABLE_INSERT_SQL_2
					ps.setDate(4, today);
				}
			} else {
				// TAG_TABLE_INSERT_SQL_3
				ps.setString(1, billAction);
				ps.setString(2, billCat);
				ps.setString(3, CEConstants.S);
			}
			result = ps.executeUpdate();
			logger.info("result:" + result);
			logger.info("Data inserted into tag");
		} catch (SQLException e) {
			logger.error("No Accounts are avaialble for processing");
			e.printStackTrace();
			result = 0;
		}
		return result;
	}

	private void createJob(String requestId, String status, String statusDesc, int recordCount) {
		// Logging Job Status and output parameters
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(SadadMessageConstants.C_INV);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		jobStatus.setJobStatus(status);
		jobStatus.setStatusDesc(statusDesc);
		jobStatus.setRecordCount(recordCount);
		ManageJobStatus.insertJobStatus(jobStatus);
	}

}