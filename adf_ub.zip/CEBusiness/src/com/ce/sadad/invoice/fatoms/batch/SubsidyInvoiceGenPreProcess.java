package com.ce.sadad.invoice.fatoms.batch;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class SubsidyInvoiceGenPreProcess implements IBatchPreProcess{

	@Override
	public void init(BankFusionEnvironment paramBankFusionEnvironment) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void process(AbstractFatomContext paramAbstractFatomContext) {
		// TODO Auto-generated method stub
		
	}

}
