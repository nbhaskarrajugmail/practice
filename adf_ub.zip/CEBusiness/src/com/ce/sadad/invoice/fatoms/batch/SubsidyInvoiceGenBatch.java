/**
 * 
 */
package com.ce.sadad.invoice.fatoms.batch;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.calendar.functions.NextWorkingDateForDate;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.misys.bankfusion.subsystem.workingday.runtime.toolkit.expression.function.IsWorkingDay;
import com.misys.bankfusion.subsystem.workingday.runtime.toolkit.expression.function.NextWorkingDate;
import com.misys.fbe.workingday.dto.WorkingDayConfigDtls;
import com.misys.fbe.workingday.helper.WorkingDayUtil;
import com.misys.fbe.workingday.validator.WorkingDayValidator;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_JOBSTATUS;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_REPAYINVOICEGENTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_RepaymentInvoiceGenBatch;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SubsidyInvoiceGenBatch;
import com.trapedza.bankfusion.utils.GUIDGen;

/** @author Subhajit */
public class SubsidyInvoiceGenBatch extends AbstractCE_SubsidyInvoiceGenBatch {

	private transient final static Log logger = LogFactory.getLog(SubsidyInvoiceGenBatch.class
			.getName());
	private static final String BATCH_PROCESS_NAME = "CEBillInvoiceWithSubsidy";
	private static final String SELECT_MAX_QUERY = "SELECT MAX(" + IBOCE_REPAYINVOICEGENTAG.ROWSEQID
			+ ") AS TOTAL FROM " + IBOCE_REPAYINVOICEGENTAG.BONAME;

	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_REPAYINVOICEGENTAG "
			+ "(CEROWSEQIDPK,CEACCOUNTID,CEAMOUNTDUE,CEDUEDATE,VERSIONNUM) SELECT ROW_NUMBER() OVER "
			+ "(ORDER BY LNLOANACCOUNTID) CEROWSEQPK, LNLOANACCOUNTID, LNPAYMENTAMT, LNPAYMENTDT, 0 VERSIONNUM FROM "
			+ "LENDING.LNTB_LOANSCHEDULE  WHERE LNPAYMENTDT = ?";

	private static String SELECT_WHERE_QUERY = " WHERE LNPAYMENTDT = ?";
	private static String LAST_SUCCESS_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND "
			+ IBOCE_JOBSTATUS.JOBSTATUS + " = 'Success' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE
			+ " DESC ";
	private static String FIRST_FAIL_DATE = " WHERE " + IBOCE_JOBSTATUS.JOBID + " =? AND "
			+ IBOCE_JOBSTATUS.JOBSTATUS + " = 'Failed' ORDER BY " + IBOCE_JOBSTATUS.JOBEXECDATE
			+ " ASC ";

	private IPersistenceObjectsFactory factory;
	private Map dataMap;
	private String jobId = "SUBSIDY_INV_GEN";
	private int subsudyGraceDays = 1; // From Module Configuration

	/**
	 * 
	 */
	public SubsidyInvoiceGenBatch() {

	}

	/** @param context */
	public SubsidyInvoiceGenBatch(BankFusionEnvironment env) {
		super(env);
	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#getFatomContext()
	 */
	@Override
	protected AbstractFatomContext getFatomContext() {
		return new SubsidyInvoiceGenContext("CEBillInvoiceWithSubsidy");
	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#processBatch(com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment, com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {

		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		Date lastSuccessDate = getLastSuccessDate();
		if (lastSuccessDate != null && today.compareTo(lastSuccessDate) <= 0) {
			logger.info("Today or Date Later than today is already processed");
			setF_OUT_Status(true);
			return;
		}
		subsudyGraceDays = Integer.parseInt(new CEUtil().getModuleConfigurationValue(
				CEConstants.CE_SADAD_INTERFACE, SadadMessageConstants.DAYS_SUBSIDY_GRACE));
		// NextWorkingDateForDate.run(contextType, contextValue, opLevel, _date)
		populateTagTable(today);
		boolean lookForward = true;
		Date tempDate = today;
		while (lookForward) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(tempDate);
			cal.add(Calendar.DATE, 1);
			Date nextDay = new Date(cal.getTime().getTime());
			if (IsWorkingDay.run("BANK", "", Integer.valueOf(0), nextDay).booleanValue()) {
				lookForward = false;
				break;
			}

			addToTagTable(nextDay);
			tempDate = nextDay;
			lookForward = true;
		}

		// Look Behind Last Success Date
		if (lastSuccessDate != null) {
			processPreviousRecords(lastSuccessDate);
		}
		// Log on JobStatus Table
		String requestId = GUIDGen.getNewGUID();
		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", new Integer(0));
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(jobId);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());

		jobStatus.setRecordCount(maxOfTagTable());
		ManageJobStatus.insertJobStatus(jobStatus);
		factory.commitTransaction();
		factory.beginTransaction();

		logger.info("Call Batch Service");
		BatchService service = (BatchService) ServiceManager.getService("BatchService");
		boolean status = service.runBatch(env, context);
		setF_OUT_Status(status);

	}

	private void addToTagTable(Date runForNextDay) {

		int tagTableCount = maxOfTagTable();
		// This may not be performant. Find Insert into statement with Row_Number added
		ArrayList params = new ArrayList();
		params.add(getRepaymentDate(runForNextDay));
		ArrayList<IBOLN_LEN_LoanSchedule> schedules = (ArrayList) factory.findByQuery(
				IBOLN_LEN_LoanSchedule.BONAME, SELECT_WHERE_QUERY, params, null, true);

		if (schedules != null && !schedules.isEmpty()) {
			for (IBOLN_LEN_LoanSchedule schedule : schedules) {
				IBOCE_REPAYINVOICEGENTAG tagBO = (IBOCE_REPAYINVOICEGENTAG) factory
						.getStatelessNewInstance(IBOCE_REPAYINVOICEGENTAG.BONAME);
				tagBO.setBoID(new Integer(++tagTableCount).toString());
				tagBO.setF_ACCOUNTID(schedule.getF_LOANACCOUNTID());
				tagBO.setF_AMOUNTDUE(schedule.getF_PAYMENTAMT());
				tagBO.setF_DUEDATE(schedule.getF_PAYMENTDT());
				factory.create(IBOCE_REPAYINVOICEGENTAG.BONAME, tagBO);
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}
	}

	/* (non-Javadoc)
	 * @see com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom#setOutputTags(com.trapedza.bankfusion.batch.fatom.AbstractFatomContext)
	 */
	@Override
	protected void setOutputTags(AbstractFatomContext context) {

	}

	private void populateTagTable(Date date) {
		try {
			// Clear tag table

			this.factory.bulkDeleteAll("CE_REPAYINVOICEGENTAG");
			this.factory.commitTransaction();
			this.factory.beginTransaction();
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setDate(1, getRepaymentDate(date));

			logger.info("Statement:" + ps.toString());
			ps.execute();
			this.factory.commitTransaction();
			this.factory.beginTransaction();
			logger.info("Data inserted into tag");

		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// Should not come here as this is already
			// handled in handler
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
	}

	private Date getRepaymentDate(Date runDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(runDate);
		cal.add(Calendar.DATE, -subsudyGraceDays);
		Date repayDate = new Date(cal.getTime().getTime());
		return repayDate;
	}

	private int maxOfTagTable() {
		Integer count = 0;
		ArrayList params1 = new ArrayList();
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(SELECT_MAX_QUERY, null,
				null, true);
		if (null != records && !records.isEmpty()) {
			SimplePersistentObject record = records.get(0);
			count = Integer.parseInt((String) record.getDataMap().get("TOTAL"));
		}
		return count;
	}

	private Date getLastSuccessDate() {

		ArrayList params = new ArrayList();
		// params.add(getF_IN_JOBID().trim());
		params.add(jobId);
		IBOCE_JOBSTATUS jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME,
				LAST_SUCCESS_DATE, params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			return jobStatus.getF_JOBEXECDATE();
		}

		jobStatus = (IBOCE_JOBSTATUS) factory.findFirstByQuery(IBOCE_JOBSTATUS.BONAME, FIRST_FAIL_DATE,
				params, true);
		if (null != jobStatus && null != jobStatus.getF_JOBEXECDATE()) {
			Date date = jobStatus.getF_JOBEXECDATE();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.DATE, -1);
			date = new Date(cal.getTime().getTime());
			return date;
		}
		return null;
	}

	private void processPreviousRecords(Date lastSuccessDate) {
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();

		Date nextWorkingDate = NextWorkingDateForDate.run("BANK", CommonConstants.EMPTY_STRING,
				Integer.valueOf(0), lastSuccessDate);
		while (true) {
			if (nextWorkingDate.compareTo(today) >= 0) {
				return;
			}
			addToTagTable(nextWorkingDate);
			boolean lookForward = true;
			Date tempDate = nextWorkingDate;
			while (lookForward) {
				Calendar cal = Calendar.getInstance();
				cal.setTime(tempDate);
				cal.add(Calendar.DATE, 1);
				Date nextDay = new Date(cal.getTime().getTime());
				if (IsWorkingDay.run("BANK", CommonConstants.EMPTY_STRING, Integer.valueOf(0), nextDay)
						.booleanValue()) {
					lookForward = false;
					break;
				}
				addToTagTable(nextDay);
				tempDate = nextDay;
				lookForward = true;
			}
			nextWorkingDate = NextWorkingDateForDate.run("BANK", "", Integer.valueOf(0),
					nextWorkingDate);
		}
	}

}
