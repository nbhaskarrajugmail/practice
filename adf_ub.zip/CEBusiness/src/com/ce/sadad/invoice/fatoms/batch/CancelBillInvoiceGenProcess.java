package com.ce.sadad.invoice.fatoms.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.sadad.invoice.InvoiceData;
import com.ce.sadad.util.CEDateHelper;
import com.ce.sadad.util.GenSADADFeeBillInvoiceReq;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.calendar.functions.AddDaysToDate;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_CANCELBILLINVOICEGENTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class CancelBillInvoiceGenProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(CancelBillInvoiceGenProcess.class.getName());
	private AbstractProcessAccumulator accumulator;
	private IPersistenceObjectsFactory factory;

	private static String LOAN_NEXT_SCHEDULE_FETCH = "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " = ? AND "
			+ IBOLN_LEN_LoanSchedule.PAYMENTDT + " > ? ORDER BY " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " ASC";

	public CancelBillInvoiceGenProcess(AbstractPersistableFatomContext context) {
		super(context);
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return this.accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();
	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new CancelBillInvoiceGenAccumulator(accumulatorArgs);
	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		logger.info("CancelBillInvoiceGenProcess -- process method PageNo [" + pageToProcess + "]");

		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		String reqID = (String) context.getInputTagDataMap().get("REQUESTID");
		String batchReqID = reqID + "_" + pageToProcess;
		ArrayList<String> elements = new ArrayList<String>();

		int pageSize = this.context.getPageSize();
		int fromValue = (pageToProcess - 1) * pageSize + 1;
		int toValue = pageToProcess * pageSize;

		ArrayList<InvoiceData> cancelBillInvoiceList = new ArrayList<>();
		ArrayList<String> cancelBillInvoicePKList = new ArrayList<>();

		ArrayList<Object> queryParams = new ArrayList<Object>();
		queryParams.add(fromValue);
		queryParams.add(toValue);
		queryParams.add(SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_NEW);
		String fetchFromTagRecords = " WHERE " + IBOCE_CANCELBILLINVOICEGENTAG.ROWSEQID + " BETWEEN ? AND ? AND "
				+ IBOCE_CANCELBILLINVOICEGENTAG.TAGSTATUS + " = ? ";
		logger.info("[pageToProcess] " + pageToProcess + " [pageSize] " + pageSize + " [fromValue] " + fromValue
				+ " [toValue] " + toValue);
		@SuppressWarnings("unchecked")
		List<IBOCE_CANCELBILLINVOICEGENTAG> cancelBillInvoiceGenTags = factory
				.findByQuery(IBOCE_CANCELBILLINVOICEGENTAG.BONAME, fetchFromTagRecords, queryParams, null, true);
		BigDecimal zero = BigDecimal.ZERO;
		logger.info("CancelBillInvoiceGenProcess size : " + cancelBillInvoiceGenTags.size());
		for (IBOCE_CANCELBILLINVOICEGENTAG cancelBillInvoice : cancelBillInvoiceGenTags) {
			cancelBillInvoice.setF_TAGSTATUS(SadadMessageConstants.CANCEL_BILL_INVOICE_STAGE_INPROGRESS);
			BigDecimal billAmount = cancelBillInvoice.getF_BILLAMT();
			Date dueDate = cancelBillInvoice.getF_BILLDUEDATE();
			String loanAccount = cancelBillInvoice.getF_BILLACCT();
			logger.info(
					"CancelBillInvoiceGenProcess - Begin [" + loanAccount + "] [" + dueDate + "] [" + billAmount + "]");
			if (billAmount.compareTo(zero) > 0) {
				// when next installment is due
				if (this.isNextScheduleInDue(loanAccount, dueDate)) {
					cancelBillInvoicePKList.add(cancelBillInvoice.getF_BILLINVOICEPKEY());
					InvoiceData invoiceData = this.prepareInvoiceData(cancelBillInvoice);
					cancelBillInvoiceList.add(invoiceData);
				}

			} else {
				// only when amount is ZERO and this installment is the last scheduled bill
				if (this.isLastSchedule(loanAccount, dueDate)) {
					cancelBillInvoicePKList.add(cancelBillInvoice.getF_BILLINVOICEPKEY());
					InvoiceData invoiceData = this.prepareInvoiceData(cancelBillInvoice);
					cancelBillInvoiceList.add(invoiceData);
				}
			}
		}

		if (!cancelBillInvoiceList.isEmpty()) {
			String message = GenSADADFeeBillInvoiceReq.generateSOAPRequest(cancelBillInvoiceList,
					SadadMessageConstants.REPAY, batchReqID);
			String reqXML = message.toString();
			logger.info("Cancel Bill Invoice Request: " + reqXML);
			elements.add(reqXML);
			Object[] accumulatorArgs = new Object[3];
			accumulatorArgs[0] = elements;
			accumulatorArgs[1] = reqID;
			accumulatorArgs[2] = cancelBillInvoicePKList;
			this.accumulator.accumulateTotals(accumulatorArgs);
		}
		return this.accumulator;
	}

	private InvoiceData prepareInvoiceData(IBOCE_CANCELBILLINVOICEGENTAG cancelBillInvoice) {
		String billInvoiceByIDPKSql = "WHERE  " + IBOCE_BILLINVOICE.ID + "=?";
		ArrayList<Object> paramsInner = new ArrayList<>();
		paramsInner.add(cancelBillInvoice.getF_BILLINVOICEPKEY());
		IBOCE_BILLINVOICE billInvoiceRecord = (IBOCE_BILLINVOICE) BankFusionThreadLocal.getPersistanceFactory()
				.findFirstByQuery(IBOCE_BILLINVOICE.BONAME, billInvoiceByIDPKSql, paramsInner, true);
		InvoiceData invoiceData = new InvoiceData();
		invoiceData.setBillAccount(cancelBillInvoice.getF_BILLACCT());
		invoiceData.setBillAction(SadadMessageConstants.EXPIRE);
		invoiceData.setBillAmount(cancelBillInvoice.getF_BILLAMT());
		invoiceData.setBillCategory(cancelBillInvoice.getF_BILLCATEGORY());
		invoiceData.setBillCycle(billInvoiceRecord.getF_BILLCYCLE());
		invoiceData.setInvoiceId(cancelBillInvoice.getF_BILLINVOICENO());
		invoiceData.setDueDate(cancelBillInvoice.getF_BILLDUEDATE());
		return invoiceData;
	}

	private Boolean isNextScheduleInDue(String loanAcc, Date dueDate) {
		Date today = SystemInformationManager.getInstance().getBFBusinessDate();
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		params.add(dueDate);
		@SuppressWarnings("unchecked")
		List<IBOLN_LEN_LoanSchedule> loanSchedules = (List<IBOLN_LEN_LoanSchedule>) this.factory
				.findByQuery(IBOLN_LEN_LoanSchedule.BONAME, LOAN_NEXT_SCHEDULE_FETCH, params, null, true);

		if (loanSchedules != null && loanSchedules.size() > 0 && loanSchedules.get(0) != null) {
			IBOLN_LEN_LoanSchedule loanSchedule = loanSchedules.get(0);
			Date nextPaymentDate = loanSchedule.getF_PAYMENTDT();
			Date tomorrow = AddDaysToDate.run(1, today);
			if (CEDateHelper.areDatesSame(nextPaymentDate, tomorrow)) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	private Boolean isLastSchedule(String loanAccount, Date dueDate) {
		Date lastScheduleOfLoanAcc = this.getLastScheduleOfLoanAcc(loanAccount);
		if (lastScheduleOfLoanAcc != null && dueDate.compareTo(lastScheduleOfLoanAcc) == 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Date getLastScheduleOfLoanAcc(String loanAccount) {
		Date maxDate = null;
		ArrayList params = new ArrayList();
		params.add(loanAccount);
		String maxQuery = "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " = ? ORDER BY "
				+ IBOLN_LEN_LoanSchedule.PAYMENTDT + " DESC";
		try {
			List<IBOLN_LEN_LoanSchedule> loanSchedule = this.factory.findByQuery(IBOLN_LEN_LoanSchedule.BONAME,
					maxQuery, params, null, true);
			if (loanSchedule != null && !loanSchedule.isEmpty()) {
				maxDate = loanSchedule.get(0).getF_PAYMENTDT();
			}
		} catch (Exception e) {
			logger.error("validMaxDateOfScheduledLoanAcc error [" + loanAccount + "]:" + e.getMessage());
			e.printStackTrace();
		}
		return maxDate;
	}

}