package com.ce.sadad.invoice;

import java.math.BigDecimal;
import java.sql.Date;

public class InvoiceData {

	private String billAccount = "";
	private BigDecimal billAmount = BigDecimal.ZERO;
	private Date dueDate = null;
	private Date expiryDate = null;
	private BigDecimal vatAmount = BigDecimal.ZERO;

	private String requestId = "";
	private String invoiceId = "";
	private String billAction = "";
	private String billCategory = "";
	private Integer billCycle = 0;

	/**
	 * @return the billAccount
	 */
	public String getBillAccount() {
		return billAccount;
	}

	/**
	 * @param billAccount
	 *            the billAccount to set
	 */
	public void setBillAccount(String billAccount) {
		this.billAccount = billAccount;
	}

	/**
	 * @return the billAmount
	 */
	public BigDecimal getBillAmount() {
		return billAmount;
	}

	/**
	 * @param billAmount
	 *            the billAmount to set
	 */
	public void setBillAmount(BigDecimal billAmount) {
		this.billAmount = billAmount;
	}

	/**
	 * @return the dueDate
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate
	 *            the dueDate to set
	 */
	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return the expiryDate
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @param expiryDate
	 *            the expiryDate to set
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * @param requestId
	 *            the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	/**
	 * @return the invoiceId
	 */
	public String getInvoiceId() {
		return invoiceId;
	}

	/**
	 * @param invoiceId
	 *            the invoiceId to set
	 */
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	/**
	 * @return the billAction
	 */
	public String getBillAction() {
		return billAction;
	}

	/**
	 * @param billAction
	 *            the billAction to set
	 */
	public void setBillAction(String billAction) {
		this.billAction = billAction;
	}

	/**
	 * @return the billCategory
	 */
	public String getBillCategory() {
		return billCategory;
	}

	/**
	 * @param billCategory
	 *            the billCategory to set
	 */
	public void setBillCategory(String billCategory) {
		this.billCategory = billCategory;
	}

	/**
	 * @return the vatAmount
	 */
	public BigDecimal getVatAmount() {
		return vatAmount;
	}

	/**
	 * @param vatAmount
	 *            the vatAmount to set
	 */
	public void setVatAmount(BigDecimal vatAmount) {
		this.vatAmount = vatAmount;
	}

	/**
	 * @return the billCycle
	 */
	public Integer getBillCycle() {
		return billCycle;
	}

	/**
	 * @param billCycle
	 *            the billCycle to set
	 */
	public void setBillCycle(Integer billCycle) {
		this.billCycle = billCycle;
	}

}