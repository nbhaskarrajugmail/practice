package com.ce.sadad.invoice;

import static com.ce.sadad.util.SadadMessageConstants.*;

import java.sql.Timestamp;
import java.util.ArrayList;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import bf.com.misys.idgeneration.types.IdGenerationRq;
import bf.com.misys.idgeneration.types.IdGeneratorSet;

import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.common.runtime.service.ServiceManagerFactory;
import com.misys.bankfusion.idgeneration.service.IDGenerationService;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;

public class InvoiceCheckGenerator {
	private transient final static Log logger = LogFactory
			.getLog(InvoiceCheckGenerator.class.getName());
	private static final String QUERY = " WHERE " + IBOCE_BILLINVOICE.BILLINVOICENO + " = ? ";
	private static final String INITIAL_INVOICE_QUERY = " WHERE " + IBOCE_BILLINVOICE.BILLINVOICENO
			+ " = ? AND " + IBOCE_BILLINVOICE.BILLACTION + " = ? " ;

	public String getNextUniqueId() {
		String id = "";
		do {
			id = getNextId();
			logger.info("Generated Id:" + id);
		} while (!isInvoiceIdNotPresent(id));
		return id;
	}

	private String getNextId() {
		IDGenerationService idGenerationService = (IDGenerationService) ServiceManagerFactory
				.getInstance().getServiceManager().getServiceForName(IDGenerationService.SERVICE_NAME);

		IdGenerationRq idGenerationRq = new IdGenerationRq();

		IdGeneratorSet generatorSet = new IdGeneratorSet();
		generatorSet.setCustomerNumber(CommonConstants.EMPTY_STRING);
		generatorSet.setAccountNumber(CommonConstants.EMPTY_STRING);
		generatorSet.setAccountType(CommonConstants.EMPTY_STRING);
		generatorSet.setBfBranchSortCode(CommonConstants.EMPTY_STRING);
		generatorSet.setBicCode(CommonConstants.EMPTY_STRING);
		generatorSet.setCountryCode(CommonConstants.EMPTY_STRING);
		generatorSet.setDate(new java.sql.Date(0));
		generatorSet.setDateFormat(1);
		generatorSet.setDateTime(new Timestamp(0));
		generatorSet.setDefaultIdToUse(CommonConstants.EMPTY_STRING);
		generatorSet.setHost(CommonConstants.EMPTY_STRING);
		generatorSet.setHostBranchCode(CommonConstants.EMPTY_STRING);
		generatorSet.setIbanCheckDigits(CommonConstants.EMPTY_STRING);
		generatorSet.setIsoCurrencyCode(CommonConstants.EMPTY_STRING);
		generatorSet.setIsoCurrencyCodeNum(0);
		generatorSet.setLocale(CommonConstants.EMPTY_STRING);
		generatorSet.setNationalBankCode(CommonConstants.EMPTY_STRING);
		generatorSet.setNationalCheckDigits(CommonConstants.EMPTY_STRING);
		generatorSet.setPrefixSuffix1("INV");
		generatorSet.setPrefixSuffix2(CommonConstants.EMPTY_STRING);
		generatorSet.setProductType(CommonConstants.EMPTY_STRING);
		generatorSet.setSerialNumber(CommonConstants.EMPTY_STRING);
		generatorSet.setSubSequenceNumber(CommonConstants.EMPTY_STRING);
		// idGenerationRq.set

		idGenerationRq.setIdGenerationConfiguration("CE_INVOICENO");
		idGenerationRq.setIdGenerationComponents(generatorSet);
		String uniqueId = idGenerationService.generateUniqueId(idGenerationRq);

		return uniqueId;
	}

	public boolean isInvoiceIdNotPresent(String invoiceId) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList();
		params.add(invoiceId);

		IBOCE_BILLINVOICE invoice = (IBOCE_BILLINVOICE) factory.findFirstByQuery(
				IBOCE_BILLINVOICE.BONAME, QUERY, params, true);

		if (invoice == null)
			return true;
		else
			return false;

	}

	public boolean isInvoiceAlreadyDeleted(String invoiceId) {
		IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList();
		params.add(invoiceId);
		params.add(EXPIRE);

		IBOCE_BILLINVOICE invoice = (IBOCE_BILLINVOICE) factory.findFirstByQuery(
				IBOCE_BILLINVOICE.BONAME, INITIAL_INVOICE_QUERY, params, true);

		if (invoice == null)
			return false;
		else
			return true;

	}

}
