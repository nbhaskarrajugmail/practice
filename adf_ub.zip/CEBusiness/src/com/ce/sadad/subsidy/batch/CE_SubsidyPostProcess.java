package com.ce.sadad.subsidy.batch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class CE_SubsidyPostProcess implements IBatchPostProcess {

	private static final transient Log logger = LogFactory.getLog(CE_SubsidyPostProcess.class);
	private BankFusionEnvironment environment;
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus status;

	public void init(BankFusionEnvironment env, AbstractFatomContext ctx, IBatchStatus batchStatus) {
		this.environment = env;
		this.context = ctx;
		this.status = batchStatus;
	}

	public IBatchStatus process(AbstractProcessAccumulator arg0) {
		if (logger.isInfoEnabled()) {
			logger.info("Into PostProcess method---");
		}
		status.setStatus(true);
		return this.status;
	}

}
