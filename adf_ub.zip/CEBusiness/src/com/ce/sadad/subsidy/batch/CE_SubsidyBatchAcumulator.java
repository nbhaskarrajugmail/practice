package com.ce.sadad.subsidy.batch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class CE_SubsidyBatchAcumulator extends AbstractProcessAccumulator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final transient Log logger = LogFactory.getLog(CE_SubsidyBatchAcumulator.class);
	
	public CE_SubsidyBatchAcumulator(Object[] args){
		super(args);
		logger.info("In Accumulator.........");
	}

	public void addAccumulatorForMerging(AbstractProcessAccumulator arg0) {

	}

	public void acceptChanges() {

	}

	public void accumulateTotals(Object[] arg0) {

	}

	public Object[] getMergedTotals() {
		return null;
	}

	public Object[] getProcessWorkerTotals() {
		return null;
	}

	public void mergeAccumulatedTotals(Object[] arg0) {

	}

	public void restoreState() {

	}

	public void storeState() {

	}

}
