package com.ce.sadad.subsidy.batch;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.bankfusion.ib.bo.refimpl.IBOCE_IB_PaymentSchBreakup;
import com.ce.sadad.util.BillInvoiceHelper;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.microflow.runtime.impl.MFExecuter;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SubsisidyTag;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRepayments;
import com.trapedza.bankfusion.bo.refimpl.IBOpseudonyms;
import com.trapedza.bankfusion.core.FinderMethods;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.utils.GUIDGen;

import bf.com.misys.bf.attributes.ErrorResponse;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRq;
import bf.com.misys.financialposting.types.BackOfficeAccountPostingRs;
import bf.com.misys.financialposting.types.PostingLeg;
import bf.com.misys.financialposting.types.TxnDetails;

public class CE_SubsidyBatchProcess extends AbstractBatchProcess {

	private AbstractProcessAccumulator accumulator;
	private static final transient Log logger = LogFactory.getLog(CE_SubsidyBatchProcess.class);
	private String WHERE_CLAUSE = " WHERE " + IBOCE_SubsisidyTag.ROWSEQ + " BETWEEN ? AND ?";

	public CE_SubsidyBatchProcess(BankFusionEnvironment environment, AbstractFatomContext context, Integer priority) {
		super(environment, context, priority);
		logger.info("In Process Method...");
	}

	public CE_SubsidyBatchProcess(AbstractPersistableFatomContext context) {
		super(context);
		this.context = ((CE_SubsidyBatchContext) context);
		logger.info("In Process Method...");
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();

	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new CE_SubsidyBatchAcumulator(accumulatorArgs);
		logger.info("In Process Initialise Method...");
	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		logger.info("Into Process with page Number:" + pageToProcess);

		int pageSize = context.getPageSize();
		int fromNumber = (pageToProcess - 1) * pageSize + 1;
		int toNumber = pageToProcess * pageSize;
		ArrayList<Integer> params = new ArrayList<Integer>();
		params.add(fromNumber);
		params.add(toNumber);

		@SuppressWarnings("unchecked")
		List<IBOCE_SubsisidyTag> result = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOCE_SubsisidyTag.BONAME, WHERE_CLAUSE, params, null, true);
		if (result != null) {
			BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
			BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
			for (IBOCE_SubsisidyTag tagObj : result) {
				logger.info("RepaymentID : " + tagObj.getF_REPAYMENTID());
				try {
					IBOLoanRepayments repaymentDtls = (IBOLoanRepayments) BankFusionThreadLocal.getPersistanceFactory()
							.findByPrimaryKey(IBOLoanRepayments.BONAME, tagObj.getF_REPAYMENTID(), true);
					BigDecimal pendingAmt = repaymentDtls.getF_REPAYMENTUNPAID();
					logger.info("Loan Account:" + repaymentDtls.getF_ACCOUNTID());
					logger.info("Pending Amount:" + pendingAmt);

					String loanAcc = repaymentDtls.getF_ACCOUNTID();
					Date duedate = repaymentDtls.getF_DUEDATE();
					logger.info("duedate:" + duedate);
					IBOCE_BILLINVOICE billInvDtls = BillInvoiceHelper
							.getSuccessBillInvoiceDtlsByAccountAndDuedate(loanAcc, duedate);
					if (billInvDtls != null) {

						List<IBOCE_IB_PaymentSchBreakup> schBreakupList = getSchBreakUp(loanAcc, duedate);
						BigDecimal subsidyAmt = BigDecimal.ZERO;
						if (schBreakupList != null && !schBreakupList.isEmpty()) {
							for (IBOCE_IB_PaymentSchBreakup schBreakup : schBreakupList) {
								subsidyAmt = subsidyAmt.add(
										schBreakup.getF_IBSUBSIDYAMNT().subtract(schBreakup.getF_IBSUBSIDYAMTPAID()));
							}
						}

						logger.info("subsidyAmt:" + subsidyAmt);
						BigDecimal dueAmt = repaymentDtls.getF_REPAYMENTDUE();
						logger.info("dueAmt:" + dueAmt);
						BigDecimal paidAmt = repaymentDtls.getF_REPAYMENTPAID();
						logger.info("paidAmt:" + paidAmt);
						BigDecimal finalBillAmountWithSubsidy = paidAmt.add(subsidyAmt);
						logger.info("finalBillAmountWithSubsidy:" + finalBillAmountWithSubsidy);

						if (subsidyAmt.compareTo(BigDecimal.ZERO) > 0
								&& finalBillAmountWithSubsidy.compareTo(dueAmt) >= 0) {
							logger.info("Eligilbe for posting:" + subsidyAmt);
							logger.info("Subsidy Amount:" + subsidyAmt);
							String subsidyAcc = getSubsidyAcc();
							logger.info("subsidyAcc:" + subsidyAcc);
							populateAndCallBackOfficeRequest(loanAcc, subsidyAcc, subsidyAmt,
									billInvDtls.getF_BILLINVOICENO());
							updateSubsidyPaidAmounts(schBreakupList, subsidyAmt);
						} else {
							logger.info("### Not Eligilbe for posting:" + subsidyAmt);
						}
					}
				} catch (Exception e) {
					logger.error(e.getMessage());
				}
			}
			BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
			BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
		}

		return accumulator;
	}

	private void updateSubsidyPaidAmounts(List<IBOCE_IB_PaymentSchBreakup> schBreakupList, BigDecimal subsidyAmt) {
		for (IBOCE_IB_PaymentSchBreakup schBreakup : schBreakupList) {
			logger.info("SUBSIDYAMNT:" + schBreakup.getF_IBSUBSIDYAMNT() + " SUBSIDYAMTPAID:"
					+ schBreakup.getF_IBSUBSIDYAMTPAID());
			if (BigDecimal.ZERO.compareTo(subsidyAmt) < 0) {
				BigDecimal subsidyAtAssetLevel = schBreakup.getF_IBSUBSIDYAMNT()
						.subtract(schBreakup.getF_IBSUBSIDYAMTPAID());
				if (subsidyAmt.compareTo(subsidyAtAssetLevel) >= 0) {
					schBreakup.setF_IBSUBSIDYAMTPAID(schBreakup.getF_IBSUBSIDYAMTPAID().add(subsidyAtAssetLevel));
					subsidyAmt = subsidyAmt.subtract(subsidyAtAssetLevel);
				} else {
					schBreakup.setF_IBSUBSIDYAMTPAID(schBreakup.getF_IBSUBSIDYAMTPAID().add(subsidyAmt));
					subsidyAmt = BigDecimal.ZERO;
				}
			}
		}
		BankFusionThreadLocal.getPersistanceFactory().commitTransaction();
		BankFusionThreadLocal.getPersistanceFactory().beginTransaction();
	}

	@SuppressWarnings("deprecation")
	private String getSubsidyAcc() {
		String subsidyAcc = "";
		CEUtil ceUtil = new CEUtil();
		String subsidyAccPseudonym = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SUBSIDYACC");
		logger.info("subsidyAccPseudonym:" + subsidyAccPseudonym);
		IBOpseudonyms pseudDtls = (IBOpseudonyms) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOpseudonyms.BONAME, subsidyAccPseudonym, true);
		String contextValue = "SAR";
		if (pseudDtls.getF_FINDERALTERNATIVE1().equalsIgnoreCase("BRANCH")) {
			contextValue = BankFusionThreadLocal.getBankFusionEnvironment().getUserBranch();
		}
		logger.info("contextValue from pseudonym :" + contextValue);
		logger.info("context sent : BANK");
		logger.info("contextValue sent : ALLBANKSADAD");
		@SuppressWarnings("rawtypes")
		List finderResult = FinderMethods.findAccountByPseudoname(subsidyAccPseudonym, "SAR", "BANK", "ALLBANKSADAD",
				BankFusionThreadLocal.getBankFusionEnvironment(), null);
		if (finderResult != null && !finderResult.isEmpty()) {
			subsidyAcc = ((IBOAttributeCollectionFeature) finderResult.get(0)).getBoID();
		}
		logger.info("getSubsidyAcc() subsidyAcc:" + subsidyAcc);
		return subsidyAcc;
	}

	@SuppressWarnings("unchecked")
	private List<IBOCE_IB_PaymentSchBreakup> getSchBreakUp(String loanAcc, Date duedate) {
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(loanAcc);
		List<IBOCE_IB_PaymentSchBreakup> schBreakupList = null;
		@SuppressWarnings("rawtypes")
		List result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOLendingFeature.BONAME,
				" WHERE " + IBOLendingFeature.ACCOUNTID + " = ?", params, null, true);
		if (result != null && !result.isEmpty()) {
			String loanRef = ((IBOLendingFeature) result.get(0)).getF_LOANREFERENCE();
			params.clear();
			params.add(loanRef);
			params.add(duedate);
			String schBreakUpSQL = " WHERE " + IBOCE_IB_PaymentSchBreakup.IBDEALID + " = ? AND "
					+ IBOCE_IB_PaymentSchBreakup.IBBILLDATE + " = ?";
			schBreakupList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_IB_PaymentSchBreakup.BONAME, schBreakUpSQL, params, null, true);

		}
		return schBreakupList;
	}

	private Object populateAndCallBackOfficeRequest(String loanAcc, String subsidyAcc, BigDecimal amt,
			String billInvNumber) {
		logger.info("Core Payment Service is Starting...");
		BackOfficeAccountPostingRq request = new BackOfficeAccountPostingRq();
		PostingLeg[] postingLegs = new PostingLeg[2];
		PostingLeg crLeg = new PostingLeg();
		PostingLeg drLeg = new PostingLeg();
		CEUtil ceUtil = new CEUtil();
		String drTxnCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADSUBDRTXNCODE");
		String crTxnCode = ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SADADSUBCRTXNCODE");
		logger.info("loanAcc: " + loanAcc + " # billInvNumber:" + billInvNumber + " # drTxnCode:" + drTxnCode
				+ " # crTxnCode:" + crTxnCode);
		IBOAttributeCollectionFeature loanAccDtl = (IBOAttributeCollectionFeature) BankFusionThreadLocal
				.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loanAcc, true);
		crLeg = populatePostingLeg(loanAcc, amt, "C", "", crTxnCode, loanAccDtl.getF_ISOCURRENCYCODE());
		drLeg = populatePostingLeg(subsidyAcc, amt, "D", "", drTxnCode, loanAccDtl.getF_ISOCURRENCYCODE());
		postingLegs[0] = crLeg;
		postingLegs[1] = drLeg;
		request.setBackOfficePostingLegs(postingLegs);

		TxnDetails txnDetails = new TxnDetails();
		txnDetails.setChannelId("SADAD");
		txnDetails.setForcePost(false);
		txnDetails.setTransactionId(GUIDGen.getNewGUID());
		txnDetails.setTransactionReference(billInvNumber);
		txnDetails.setValueDate(SystemInformationManager.getInstance().getBFBusinessDateTime());
		request.setTxnDetails(txnDetails);

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("backOfficeAccountPostingRq", request);
		@SuppressWarnings("unchecked")
		HashMap<String, Object> result = MFExecuter.executeMF("UB_R_UB_TXN_BackOfficeAccountPosting_SRV",
				BankFusionThreadLocal.getBankFusionEnvironment(), params);

		BackOfficeAccountPostingRs response = (BackOfficeAccountPostingRs) result.get("backOfficeAccountPostingRs");
		@SuppressWarnings("unused")
		ErrorResponse errorResponse = (ErrorResponse) result.get("ErrorResponse");
		logger.info("Core Payment Service is Ending...");
		return response;
	}

	private PostingLeg populatePostingLeg(String accID, BigDecimal amt, String postingAction, String narrative,
			String txnCode, String txnCur) {
		PostingLeg postingLeg = new PostingLeg();
		postingLeg.setAccountId(accID);
		postingLeg.setAmount(amt);
		postingLeg.setCreditDebitIndicator(postingAction);
		postingLeg.setNarrative(narrative);
		postingLeg.setTransactionCode(txnCode);
		postingLeg.setTransactionCurrency(txnCur);
		return postingLeg;
	}

}