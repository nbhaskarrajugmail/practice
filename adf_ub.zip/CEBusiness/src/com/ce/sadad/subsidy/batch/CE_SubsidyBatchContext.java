package com.ce.sadad.subsidy.batch;

import java.util.Map;

//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;

public class CE_SubsidyBatchContext extends AbstractPersistableFatomContext {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final transient Log logger = LogFactory.getLog(CE_SubsidyBatchContext.class);
	private Map inputTagDataMap;
	  private Map outputTagDataMap;
	  private String batchProcessName;
	  private String serviceName;
	  private Object[] additionalParams;

	public CE_SubsidyBatchContext(String batchProcessName){
		logger.info("IN Context......");
		this.batchProcessName = batchProcessName;
	    this.additionalParams = new Object[2];
	    this.inputTagDataMap = new HashMap();
	    this.outputTagDataMap = new HashMap();
	}
	public boolean isMultiNodeSupported() {
		return false;
	}

	public Object[] getAdditionalProcessParams() {
		return this.additionalParams;
	}

	public String getBatchProcessName() {
		return this.batchProcessName;
	}

	public Map getInputTagDataMap() {
		return this.inputTagDataMap;
	}

	public Map getOutputTagDataMap() {
		return this.outputTagDataMap;
	}

	public void setAdditionalProcessParams(Object[] arg0) {

	}

	public void setBatchProcessName(String processName) {
		this.batchProcessName = processName;
	}

	public void setInputTagDataMap(Map dataMap) {
		this.inputTagDataMap = dataMap;
	}

	public void setOutputTagDataMap(Map datamap) {
		this.outputTagDataMap= datamap;
	}
	
	public String getProcessClassName(){
		return PROCESS_CLASSNAME;
	}
	
	private static String PROCESS_CLASSNAME = loadProcessClassName("CESubsidyBatchProcess",	"com.ce.sadad.subsidy.batch.CE_SubsidyBatchProcess");

}
