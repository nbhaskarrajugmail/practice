package com.ce.sadad.subsidy.batch;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.IBatchPreProcess;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class CE_SubsidyPreProcess implements IBatchPreProcess {
	private static final transient Log logger = LogFactory.getLog(CE_SubsidyPreProcess.class);
	
	public void init(BankFusionEnvironment arg0) {
		logger.info("Pre Process Init Method...");
	}

	public void process(AbstractFatomContext arg0) {
		logger.info("Pre Process Process Method");
	}

}
