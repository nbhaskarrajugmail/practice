package com.ce.sadad.subsidy;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.sadad.subsidy.batch.CE_SubsidyBatchContext;
import com.misys.bankfusion.calendar.functions.SubtractDaysFromDate;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SubsisidyTag;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SubsidyProcess;

public class CE_SubsidyProcess extends AbstractCE_SubsidyProcess {

	Log logger = LogFactory.getLog(CE_SubsidyProcess.class);
	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_SUBSISIDYTAG(CEROWSEQPK,CEREPAYMENTID,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY REPAYMENTID),REPAYMENTID,0 versionnum"
			+ " FROM WASADMIN.LOANREPAYMENTS WHERE TRUNC(DUEDATE)  <= TRUNC(?) AND TRUNC(DUEDATE)  > TRUNC(?) ORDER BY ACCOUNTID";
	private IPersistenceObjectsFactory factory;

	@SuppressWarnings("deprecation")
	public CE_SubsidyProcess(BankFusionEnvironment env) {
		super(env);
	}

	protected AbstractFatomContext getFatomContext() {
		return new CE_SubsidyBatchContext("CESubsidyBatchProcess");
	}

	@SuppressWarnings("deprecation")
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {
		logger.info("Subsidy Process Starting....");
		logger.info("At processBatch method");
		CEUtil ceUtil = new CEUtil();
		int gracePeriod = 0;
		try {
			gracePeriod = Integer
					.parseInt(ceUtil.getModuleConfigurationValue("CESADADINTERFACE", "SUBSIDY_GRACE_PERIOD"));
		} catch (NumberFormatException nfe) {
			nfe.printStackTrace();
		}

		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		this.factory.bulkDeleteAll(IBOCE_SubsisidyTag.BONAME);
		this.factory.commitTransaction();
		this.factory.beginTransaction();

		Date fromDate = SystemInformationManager.getInstance().getBFBusinessDate();
		Date toDate = SubtractDaysFromDate.run(fromDate, gracePeriod);

		try {
			logger.info(INSERT_QUERY);
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setDate(1, fromDate);
			ps.setDate(2, toDate);

			logger.info("Statement:" + ps.toString());
			ps.executeUpdate();
			this.factory.commitTransaction();
			this.factory.beginTransaction();
			logger.info("Data inserted into tag");
			logger.info("Call Batch Service");
			BatchService service = (BatchService) ServiceManager.getService("BatchService");
			@SuppressWarnings("unused")
			boolean status = service.runBatch(env, context);
		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}

		logger.info("Subsidy Process Finished.....");
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map getInDataMap() {
		return new HashMap();
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {

	}

}