package com.ce.sadad.notification;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.cbs.common.functions.CB_CMN_PrivateSession;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLACCT;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_BillAcctReqBuilder;

import bf.org.example.ce_billacct.BillAcctRq;
import bf.org.example.ce_billacct.BillAcctRs;
import bf.org.example.ce_billacct.SadadRequest;
import bf.org.example.ce_billacct.SadadResponse;

public class CE_BillAcctReqBuilder extends AbstractCE_BillAcctReqBuilder {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Log logger = LogFactory.getLog(CE_BillAcctReqBuilder.class);

	@SuppressWarnings("deprecation")
	public CE_BillAcctReqBuilder(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		if (logger.isInfoEnabled()) {
			logger.info("Inside BillAccount Process");
		}
		SadadRequest sadadRqList = getF_IN_billAcctRq();
		SadadResponse sadadRs = new SadadResponse();
		BillAcctRq[] sadadRqArray = sadadRqList.getTransactionDtl();
		BillAcctRs billAcctRs = new BillAcctRs();
		String batchID = sadadRqList.getBatchId();
		int successCount = sadadRqList.getSuccessCount();
		int errorCount = sadadRqList.getErrorCount();
		String status = "S";
		String desc = "Success";
		if (logger.isInfoEnabled()) {
			logger.info("Processing [batchID: " + batchID + ", successCount:" + successCount + ", errorCount:"
					+ errorCount + "]");
		}
		if (sadadRqList.getErrorCount() > 0) {
			if (sadadRqArray.length > 0) {
				for (BillAcctRq sadadRq : sadadRqArray) {
					if (logger.isInfoEnabled()) {
						logger.info("Request process starting for Bill Account:" + sadadRq.getBillAcctNo());
					}
					try {
						updateBillAcctStatus(sadadRq);
					} catch (BankFusionException be) {
						if (logger.isErrorEnabled()) {
							logger.error("BankFusionException " + be.getMessage());
						}
						be.printStackTrace();
						status = "E";
						desc = be.getMessage();
					} catch (Exception e) {
						if (logger.isErrorEnabled()) {
							logger.error("Exception occured " + e.getMessage());
						}
						status = "E";
						e.printStackTrace();
						desc = e.getMessage();
					}
				}
				if (logger.isInfoEnabled()) {
					logger.info("Sending Responce to FFC: -- Status Code: " + status + " Status Desc: " + desc);
				}
			} else {
				status = "E";
				desc = "Empty records";
				if (logger.isErrorEnabled()) {
					logger.error(desc);
				}
			}
		}

		billAcctRs.setStatusCode(status);
		billAcctRs.setStatusDesc(desc);
		sadadRs.addTransactionRs(billAcctRs);
		setF_OUT_billAcctRs(sadadRs);
	}

	private void updateBillAcctStatus(BillAcctRq billAcctRq) {
		if (logger.isInfoEnabled()) {
			logger.info("Persistance of Bill Account Request start.....");
		}
		CB_CMN_PrivateSession pvtSession = new CB_CMN_PrivateSession();
		IPersistenceObjectsFactory pvtFactory = pvtSession.createSession();
		String accountNo = billAcctRq.getBillAcctNo();
		String statusCode = billAcctRq.getStatusCode();
		String statusDesc = billAcctRq.getStatusDesc();
		statusDesc = (statusDesc != null && statusDesc.length() > 30) ? statusDesc.substring(0, 29) : statusDesc;
		try {
			if (logger.isInfoEnabled()) {
				logger.info("BillAcct: " + accountNo + "StatusCode: " + statusCode + "StatusDesc: " + statusDesc
						+ "ReqDate: " + getTimeStamp());
			}
			pvtFactory.beginTransaction();
			IBOCE_BILLACCT billAccount = (IBOCE_BILLACCT) pvtFactory.getStatelessNewInstance(IBOCE_BILLACCT.BONAME);
			billAccount.setBoID(accountNo);
			billAccount.setF_REGSTATUSCODE(statusCode);
			billAccount.setF_REGSTATUSDESC(statusDesc);
			billAccount.setF_REQDATE(getTimeStamp());
			pvtFactory.create(IBOCE_BILLACCT.BONAME, billAccount);
			pvtFactory.commitTransaction();
			if (logger.isInfoEnabled()) {
				logger.info("Persistance of Bill Account Request end.....");
			}
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				if (e instanceof SQLException) {
					logger.error(" Bill Account [" + accountNo + "] available already !");
				} else {
					logger.error("Exception during Persistance of Bill Account " + e);
				}
				e.printStackTrace();
			}
		}
	}

	private Timestamp getTimeStamp() {
		Date date = new Date();
		long time = date.getTime();
		Timestamp ts = new Timestamp(time);
		return ts;
	}

}