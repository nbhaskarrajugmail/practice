package com.ce.sadad.notification;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.adf.CEUtil;
import com.misys.bankfusion.common.exception.BankFusionException;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_BILLINVOICE;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_BillInvoiceReqBuilder;

import bf.com.misys.types.sadad.notification.BillInvoiceDtlRq;
import bf.com.misys.types.sadad.notification.BillInvoiceDtlRs;
import bf.com.misys.types.sadad.notification.BillInvoiceRq;
import bf.com.misys.types.sadad.notification.BillInvoiceRs;

public class CE_BillInvoiceReqBuilder extends AbstractCE_BillInvoiceReqBuilder {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static String SUCCESS = "S";
	private static String ERROR = "E";

	private Log logger = LogFactory.getLog(CE_BillInvoiceReqBuilder.class);

	@SuppressWarnings("deprecation")
	public CE_BillInvoiceReqBuilder(BankFusionEnvironment env) {
		super(env);
	}

	public void process(BankFusionEnvironment env) {
		if (logger.isInfoEnabled()) {
			logger.info("Inside Bill Invoice Process");
		}
		BillInvoiceDtlRq billInvoiceDtlRqList = getF_IN_BillInvoiceRq();
		BillInvoiceDtlRs billInvoicetDtlRs = new BillInvoiceDtlRs();
		BillInvoiceRs billInvoicetRs = new BillInvoiceRs();
		String status = SUCCESS;
		String desc = SUCCESS;
		String batchID = billInvoiceDtlRqList.getBatchId();
		if (billInvoiceDtlRqList.getErrorCount() == 0) {
			this.updateBillInvoiceStatusByBatch(batchID, CEConstants.S);
		} else {
			BillInvoiceRq[] billInvoiceRqArray = billInvoiceDtlRqList.getBillInvoiceDtlRq();
			if (logger.isInfoEnabled()) {
				logger.info("billInvoiceRqArray length: " + billInvoiceRqArray.length);
			}
			if (billInvoiceRqArray == null || billInvoiceRqArray.length == 0) {
				status = ERROR;
				desc = ERROR;
			} else {
				for (BillInvoiceRq sadadRq : billInvoiceRqArray) {
					if (logger.isInfoEnabled()) {
						logger.info("Request process starting for Bill Invoice:" + sadadRq.getBillInvoiceNo());
					}
					try {
						this.updateBillInvoiceStatus(batchID, sadadRq);
					} catch (BankFusionException be) {
						if (logger.isErrorEnabled()) {
							logger.error("BankFusionException " + be.getMessage());
						}
						be.printStackTrace();
						status = ERROR;
						desc = be.getMessage();
					} catch (Exception e) {
						if (logger.isErrorEnabled()) {
							logger.error("Exception occured " + e.getMessage());
						}
						status = ERROR;
						e.printStackTrace();
						desc = e.getMessage();
					}
				}
			}
			logger.info("Sending Responce to FFC: -- Status Code: " + status + " Status Desc: " + desc);
		}
		billInvoicetRs.setStatusCode(status);
		billInvoicetRs.setStatusDesc(desc);
		billInvoicetDtlRs.addBillInvoiceDtlRs(billInvoicetRs);
		setF_OUT_BillInvoiceRs(billInvoicetDtlRs);
	}

	private void updateBillInvoiceStatusByBatch(String batchID, String status) {
		logger.info("Bill Invoice Batch status update.....");

		// which column to update
		ArrayList<String> columns = new ArrayList<String>();
		columns.add(IBOCE_BILLINVOICE.BILLSTATUS);

		// what to update on above column
		ArrayList<String> paramValues = new ArrayList<String>();
		paramValues.add(status);

		// on what condition update has to take place
		ArrayList<String> params = new ArrayList<String>();
		params.add(batchID);

		String billInvoiceBatchUpdate = " WHERE  " + IBOCE_BILLINVOICE.REQUESTKEY + "=?";
		BankFusionThreadLocal.getPersistanceFactory().bulkUpdate(IBOCE_BILLINVOICE.BONAME, billInvoiceBatchUpdate,
				params, columns, paramValues);

	}

	private void updateBillInvoiceStatus(String batchID, BillInvoiceRq billInvoiceRq) {
		try {
			String billAcctNo = billInvoiceRq.getBillAcctNo();
			String billCycle = billInvoiceRq.getBillInvoiceNo();
			String statusCode = billInvoiceRq.getStatusCode();
			String statusDesc = billInvoiceRq.getStatusDesc();

			if (logger.isInfoEnabled()) {
				logger.info("Persistance of Bill Invoice Request start.....");
				logger.info("BillInvoice: " + billCycle + "BillAcct: " + billAcctNo + "StatusCode: " + statusCode
						+ "StatusDesc: " + statusDesc);
			}

			ArrayList<String> params = new ArrayList<String>();
			params.add(billAcctNo);
			params.add(batchID);
			params.add(ERROR);

			@SuppressWarnings("unchecked")
			List<IBOCE_BILLINVOICE> billInvoiceLst = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOCE_BILLINVOICE.BONAME, "WHERE " + IBOCE_BILLINVOICE.BILLACCT + " = ? AND "
							+ IBOCE_BILLINVOICE.REQUESTKEY + " = ? AND " + IBOCE_BILLINVOICE.BILLACTION + " <> ? ",
							params, null, true);

			for (IBOCE_BILLINVOICE billinvoice : billInvoiceLst) {
				if (billinvoice.getBoID().contains("_")) {
					String billCycleStr = billinvoice.getBoID().split("_")[1];
					if (Integer.parseInt(billCycle) == Integer.parseInt(billCycleStr)) {
						if (logger.isInfoEnabled()) {
							logger.info("BillInvoice: " + billinvoice.getF_BILLINVOICENO());
						}
						statusDesc = (statusDesc != null && statusDesc.length() > 30) ? statusDesc.substring(0, 29)
								: statusDesc;
						billinvoice.setF_NSTATUSCODE(statusCode);
						billinvoice.setF_NSTATUSDESC(statusDesc);
						billinvoice.setF_BILLSTATUS(CEConstants.F);
						billinvoice.setF_NDATE(CEUtil.getTimeStamp());
						break;
					}
				}
			}
			if (logger.isInfoEnabled()) {
				logger.info("Persistance of Bill Invoice Request end.....");
			}
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error("Exception during Persistance of Bill Invoice " + e);
			}
			e.printStackTrace();
		}
	}

}