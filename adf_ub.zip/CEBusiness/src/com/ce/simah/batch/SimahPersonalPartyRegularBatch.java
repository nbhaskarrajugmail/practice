package com.ce.simah.batch;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.ce.simah.regular.RegularFileGenerator;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHREGULARTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SimahPersonalPartyRegularGenBatch;
import com.trapedza.bankfusion.utils.GUIDGen;

public class SimahPersonalPartyRegularBatch extends AbstractCE_SimahPersonalPartyRegularGenBatch {

	private transient final static Log logger = LogFactory.getLog(SimahPersonalPartyRegularBatch.class.getName());
	private IPersistenceObjectsFactory factory;

	private static final String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_SIMAHREGULARTAG "
			+ "(CEROWSEQIDPK,CEACCOUNTID,CEEXISTSORNEW,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY CECRINSTRUMENTNO) CEROWSEQIDPK,"
			+ " CECRINSTRUMENTNO, 'E' CEEXISTSORNEW, 0 VERSIONNUM FROM CUSTOMEXTN.CETB_SIMAHLASTMSG WHERE CEPRODUCTSTATUS='A' ";
	private static final String LASTCYCLE_DATE_QUERY = "SELECT MAX(" + IBOCE_SIMAHLASTMSG.PROCESSEDDATE
			+ ") AS CYCLEDATE FROM " + IBOCE_SIMAHLASTMSG.BONAME;
	private static final String CLOSED_QUERY = " WHERE " + IBOCE_SIMAHLASTMSG.PRODUCTSTATUS + " =? AND "
			+ IBOCE_SIMAHLASTMSG.FILETYPE + " =?";
	private static final String NEW_ACC_QUERY = " WHERE " + IBOLendingFeature.FIRSTDRAWDOWNDATE + " > ?";

	private int max = 0;

	public SimahPersonalPartyRegularBatch() {
	}

	@SuppressWarnings("deprecation")
	public SimahPersonalPartyRegularBatch(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new SimahPersonalPartyRegularContext(
				SadadMessageConstants.SIMAH_PERSONAL_PARTY_REGULAR_BATCH_PROCESS_NAME);
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {
		logger.info("[" + SadadMessageConstants.SIMAH_PERSONAL_PARTY_REGULAR_BATCH_PROCESS_NAME + "] - Begin");

		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		this.insertTagTable();

		String requestId = GUIDGen.getNewGUID();
		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", max);
		if (max > 0) {
			BatchService service = (BatchService) ServiceManager.getService("BatchService");
			boolean status = service.runBatch(env, context);
			setF_OUT_Status(status);
			this.createJob(requestId, CEConstants.S, max, "Begin");
		} else {
			this.createJob(requestId, CEConstants.S, max, "No Records to Process");
			setF_OUT_Status(Boolean.TRUE);
		}

		logger.info("[" + SadadMessageConstants.SIMAH_PERSONAL_PARTY_REGULAR_BATCH_PROCESS_NAME + "] - End");
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
	}

	private void insertTagTable() {
		this.factory.bulkDeleteAll(IBOCE_SIMAHREGULARTAG.BONAME);
		this.factory.commitTransaction();
		this.factory.beginTransaction();
		archiveClosedAccounts();

		try {
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

			max = ps.executeUpdate();
			this.factory.commitTransaction();
			this.factory.beginTransaction();

			// set last cycle date
			this.setLastCycleDate();

			// load new loans
			this.getNewLoans();

		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// this shouldn't happen as it has handler already
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void archiveClosedAccounts() {
		ArrayList params = new ArrayList();
		params.add(SimahPersonalPartyRegularContext.SIMAH_LOAN_CLOSED);
		params.add(SimahPersonalPartyRegularContext.SIMAH_FILE_REGULAR);
		ArrayList list = (ArrayList) factory.findByQuery(IBOCE_SIMAHLASTMSG.BONAME, CLOSED_QUERY, params, null, true);
		if (null != list && !list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				IBOCE_SIMAHLASTMSG simahmsg = (IBOCE_SIMAHLASTMSG) list.get(i);
				new RegularFileGenerator().archiveExistingRecord(simahmsg);
				factory.remove(IBOCE_SIMAHLASTMSG.BONAME, simahmsg);
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}
	}

	private void setLastCycleDate() {
		@SuppressWarnings("unchecked")
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(LASTCYCLE_DATE_QUERY, null, null, true);
		if (null != records && !records.isEmpty()) {
			SimplePersistentObject record = records.get(0);
			SimahPersonalPartyRegularContext.LAST_EXECUTION_DATE = (Date) record.getDataMap().get("CYCLEDATE");
		}
		if (SimahPersonalPartyRegularContext.LAST_EXECUTION_DATE == null) {
			logger.error("Previous Cycle Data Not found");
			Calendar cal = Calendar.getInstance();
			cal.setTime(SystemInformationManager.getInstance().getBFBusinessDate());
			cal.add(Calendar.DATE, -365);
			SimahPersonalPartyRegularContext.LAST_EXECUTION_DATE = new Date(cal.getTime().getTime());
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void getNewLoans() {
		ArrayList params = new ArrayList();
		params.add(SimahPersonalPartyRegularContext.LAST_EXECUTION_DATE);
		ArrayList<IBOLendingFeature> loanDetails = (ArrayList<IBOLendingFeature>) factory
				.findByQuery(IBOLendingFeature.BONAME, NEW_ACC_QUERY, params, null, true);
		if (loanDetails != null && !loanDetails.isEmpty()) {
			for (int i = 0; i < loanDetails.size(); i++) {
				if (loanDetails.get(i).getF_REDUCINGPRINCIPAL().compareTo(BigDecimal.ZERO) == 0)
					continue;

				max = max + 1;
				IBOCE_SIMAHREGULARTAG newLoan = (IBOCE_SIMAHREGULARTAG) factory
						.getStatelessNewInstance(IBOCE_SIMAHREGULARTAG.BONAME);
				newLoan.setBoID(new Integer(max).toString());
				newLoan.setF_ACCOUNTID(loanDetails.get(i).getF_ACCOUNTID());
				newLoan.setF_EXISTSORNEW("N");
				factory.create(IBOCE_SIMAHREGULARTAG.BONAME, newLoan);
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}
	}

	private void createJob(String requestId, String status, int recCount, String statusDesc) {
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(SadadMessageConstants.SIMAH_PERSONAL_REGULAR);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		jobStatus.setJobStatus(status);
		jobStatus.setStatusDesc(statusDesc);
		jobStatus.setRecordCount(recCount);
		ManageJobStatus.insertJobStatus(jobStatus);
	}

}