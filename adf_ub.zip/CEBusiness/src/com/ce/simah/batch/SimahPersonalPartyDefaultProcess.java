package com.ce.simah.batch;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.simah.defaults.ProcessDefaultAccounts;
import com.trapedza.bankfusion.batch.fatom.AbstractPersistableFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractBatchProcess;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class SimahPersonalPartyDefaultProcess extends AbstractBatchProcess {

	private transient final static Log logger = LogFactory.getLog(SimahPersonalPartyDefaultProcess.class.getName());
	private AbstractProcessAccumulator accumulator;

	public SimahPersonalPartyDefaultProcess(AbstractPersistableFatomContext context) {
		super(context);
	}

	@Override
	public AbstractProcessAccumulator getAccumulator() {
		return this.accumulator;
	}

	@Override
	public void init() {
		initialiseAccumulator();
	}

	@Override
	protected void initialiseAccumulator() {
		Object[] accumulatorArgs = new Object[0];
		this.accumulator = new SimahPersonalPartyDefaultAccumulator(accumulatorArgs);
	}

	@Override
	public AbstractProcessAccumulator process(int pageToProcess) {
		logger.info("SimahPersonalPartyDefaultProcess -- process method");
		String reqID = (String) context.getInputTagDataMap().get("REQUESTID");
		int pageSize = this.context.getPageSize();

		ProcessDefaultAccounts defaultProcessor = new ProcessDefaultAccounts();
		@SuppressWarnings("rawtypes")
		List list = defaultProcessor.process(pageSize, pageToProcess);

		Object[] accumulatorArgs = new Object[2];
		accumulatorArgs[0] = list;
		accumulatorArgs[1] = reqID;
		this.accumulator.accumulateTotals(accumulatorArgs);
		return this.accumulator;
	}

}