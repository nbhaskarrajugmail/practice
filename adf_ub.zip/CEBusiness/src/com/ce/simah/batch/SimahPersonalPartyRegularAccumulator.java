package com.ce.simah.batch;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;

public class SimahPersonalPartyRegularAccumulator extends AbstractProcessAccumulator {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5839294471007394197L;
	private transient final static Log logger = LogFactory.getLog(SimahPersonalPartyRegularAccumulator.class.getName());
	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap collectionTable = null;
	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap mergedCollectionTable = null;
	@SuppressWarnings("rawtypes")
	private List merged = null;

	@SuppressWarnings("rawtypes")
	public SimahPersonalPartyRegularAccumulator(Object[] args) {
		super(args);
		this.merged = new LinkedList<>();
		this.collectionTable = new ConcurrentHashMap();
		this.mergedCollectionTable = new ConcurrentHashMap();
	}

	@SuppressWarnings("unchecked")
	@Override
	public void addAccumulatorForMerging(AbstractProcessAccumulator acc) {
		if (this.merged == null)
			this.merged = new LinkedList<>();
		this.merged.add(acc);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void accumulateTotals(Object[] data) {
		List personalPartyRegDtls = (List) data[0];
		if (personalPartyRegDtls != null && !personalPartyRegDtls.isEmpty()) {
			String requestIdKey = (String) data[1];
			// accumulating request
			if (this.collectionTable.containsKey(requestIdKey)) {
				List list = (List) collectionTable.get(requestIdKey);
				list.addAll(personalPartyRegDtls);
				this.collectionTable.put(requestIdKey, list);
			} else {
				List list = new LinkedList();
				list.add(personalPartyRegDtls);
				this.collectionTable.put(requestIdKey, list);
			}
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object[] getMergedTotals() {
		Object[] processWorkerTotals = null;
		Object[] ret = new Object[1];
		logger.info("in getMergedTotals()-> merged list size:" + merged.size());
		Iterator iterator = this.merged.iterator();
		this.mergedCollectionTable.clear();
		while (iterator.hasNext()) {
			AbstractProcessAccumulator accumulator = (AbstractProcessAccumulator) iterator.next();
			processWorkerTotals = accumulator.getProcessWorkerTotals();
			mergeAccumulatedTotals(processWorkerTotals);
		}
		mergeAccumulatedTotals(getProcessWorkerTotals());
		ret[0] = this.mergedCollectionTable;
		return ret;
	}

	@Override
	public Object[] getProcessWorkerTotals() {
		Object[] processWorkerTotals = new Object[1];
		processWorkerTotals[0] = this.collectionTable;
		return processWorkerTotals;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void mergeAccumulatedTotals(Object[] accumulatedTotals) {
		logger.info("mergeAccumulatedTotals() Start");
		Map tempMap = (Map) accumulatedTotals[0];
		Iterator it = tempMap.keySet().iterator();
		while (it.hasNext()) {
			String key = (String) it.next();
			if (tempMap.containsKey(key)) {
				if (this.mergedCollectionTable.containsKey(key.toString())) {
					List list = (List) tempMap.get(key.toString());
					List mList = (List) this.mergedCollectionTable.get(key.toString());
					mList.addAll(list);
					this.mergedCollectionTable.put(key.toString(), mList);
				} else {
					List list = (List) tempMap.get(key.toString());
					this.mergedCollectionTable.put(key.toString(), list);
				}
			}
		}
	}

	@Override
	public void storeState() {
	}

	@Override
	public void restoreState() {
	}

	@Override
	public void acceptChanges() {
	}

}