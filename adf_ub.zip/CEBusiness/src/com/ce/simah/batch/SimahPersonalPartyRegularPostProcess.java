package com.ce.simah.batch;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.simah.regular.RegularFileGenerator;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.process.AbstractProcessAccumulator;
import com.trapedza.bankfusion.batch.process.IBatchPostProcess;
import com.trapedza.bankfusion.batch.process.engine.IBatchStatus;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

public class SimahPersonalPartyRegularPostProcess implements IBatchPostProcess {

	private transient final static Log logger = LogFactory.getLog(SimahPersonalPartyRegularPostProcess.class.getName());
	private AbstractFatomContext context;
	private AbstractProcessAccumulator accumulator;
	private IBatchStatus batchStatus;
	private String requestId;
	private Integer recordCount;

	@Override
	public void init(BankFusionEnvironment env, AbstractFatomContext context, IBatchStatus batchStatus) {
		this.context = context;
		this.batchStatus = batchStatus;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public IBatchStatus process(AbstractProcessAccumulator acc) {
		String statusCode = CEConstants.F;
		String statusMsg = CEConstants.F;

		try {
			requestId = (String) context.getInputTagDataMap().get("REQUESTID");
			recordCount = (Integer) context.getInputTagDataMap().get("RECORDCOUNT");
			logger.info("Inside SimahPersonalPartyRegularPostProcess #RequestId: " + requestId);
			if (recordCount == 0) {
				batchStatus.setStatus(true);
				return batchStatus;
			}
			if (null == acc) {
				batchStatus.setStatus(false);
				batchStatus.setBatchFailureMessage("Accumulator is null");
				return batchStatus;
			} else {
				this.accumulator = acc;
				Object[] obj = accumulator.getMergedTotals();
				if (obj != null && obj.length > 0) {
					if (obj[0] != null) {
						Map accMap = (Map) obj[0];
						List accumulatedList = (List) accMap.get(requestId);
						List<Object> regularDataObjects = new LinkedList<>();
						for (Object listObj : accumulatedList) {
							regularDataObjects.addAll((List) listObj);
						}
						RegularFileGenerator fileGenerator = new RegularFileGenerator();
						fileGenerator.generateFile(regularDataObjects);
						statusMsg = CEConstants.S;
						statusCode = CEConstants.S;
					}
				}
			}
			batchStatus.setStatus(true);
		} catch (Exception e) {
			if (logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
			batchStatus.setStatus(Boolean.FALSE);
		}
		ManageJobStatus.updateJobStatusCode(statusCode, statusMsg, requestId);
		return batchStatus;
	}

}