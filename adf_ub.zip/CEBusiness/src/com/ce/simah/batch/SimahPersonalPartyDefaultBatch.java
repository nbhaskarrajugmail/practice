package com.ce.simah.batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEConstants;
import com.ce.sadad.util.JobStatusObject;
import com.ce.sadad.util.ManageJobStatus;
import com.ce.sadad.util.SadadMessageConstants;
import com.misys.bankfusion.subsystem.persistence.IPersistenceObjectsFactory;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.batch.fatom.AbstractFatomContext;
import com.trapedza.bankfusion.batch.services.BatchService;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHDEFAULTTAG;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_SimahPersonalPartyDefaultGenBatch;
import com.trapedza.bankfusion.utils.GUIDGen;

public class SimahPersonalPartyDefaultBatch extends AbstractCE_SimahPersonalPartyDefaultGenBatch {

	private transient final static Log logger = LogFactory.getLog(SimahPersonalPartyDefaultBatch.class.getName());
	private IPersistenceObjectsFactory factory;
	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_SIMAHDEFAULTTAG "
			+ "(CEROWSEQIDPK,CEACCOUNTID,CEEXISTSORNEW,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY CECRINSTRUMENTNO) CEROWSEQIDPK,"
			+ " CECRINSTRUMENTNO, 'E' CEEXISTSORNEW, 0 VERSIONNUM FROM CUSTOMEXTN.CETB_SIMAHLASTMSG WHERE CEPRODUCTSTATUS = 'W' ";

	public SimahPersonalPartyDefaultBatch() {
	}

	@SuppressWarnings("deprecation")
	public SimahPersonalPartyDefaultBatch(BankFusionEnvironment env) {
		super(env);
	}

	@Override
	protected AbstractFatomContext getFatomContext() {
		return new SimahPersonalPartyDefaultContext(
				SadadMessageConstants.SIMAH_PERSONAL_PARTY_DEFAULT_BATCH_PROCESS_NAME);
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@Override
	protected void processBatch(BankFusionEnvironment env, AbstractFatomContext context) {
		logger.info("[" + SadadMessageConstants.SIMAH_PERSONAL_PARTY_DEFAULT_BATCH_PROCESS_NAME + "] - Begin");

		int insertedRowsCount = this.insertTagTable();
		String requestId = GUIDGen.getNewGUID();
		context.getInputTagDataMap().put("REQUESTID", requestId);
		context.getInputTagDataMap().put("JOBID", requestId);
		context.getInputTagDataMap().put("RECORDCOUNT", insertedRowsCount);

		if (insertedRowsCount > 0) {
			BatchService service = (BatchService) ServiceManager.getService("BatchService");
			boolean status = service.runBatch(env, context);
			setF_OUT_Status(status);
			this.createJob(requestId, CEConstants.S, insertedRowsCount, "Begin");
		} else {
			this.createJob(requestId, CEConstants.S, insertedRowsCount, "No Records to Process");
			setF_OUT_Status(Boolean.TRUE);
		}

		logger.info("[" + SadadMessageConstants.SIMAH_PERSONAL_PARTY_DEFAULT_BATCH_PROCESS_NAME + "] - End");
	}

	@Override
	protected void setOutputTags(AbstractFatomContext arg0) {
	}

	private int insertTagTable() {
		int count = 0;
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		this.factory.bulkDeleteAll(IBOCE_SIMAHDEFAULTTAG.BONAME);
		this.factory.commitTransaction();
		this.factory.beginTransaction();
		try {
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = this.factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

			count = ps.executeUpdate();
			this.factory.commitTransaction();
			this.factory.beginTransaction();
		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// handler is available already
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
		return count;
	}

	private void createJob(String requestId, String status, int recCount, String statusDesc) {
		JobStatusObject jobStatus = new JobStatusObject();
		jobStatus.setJobExecId(requestId);
		jobStatus.setJobId(SadadMessageConstants.SIMAH_PERSONAL_DEFAULT);
		jobStatus.setExecDate(SystemInformationManager.getInstance().getBFBusinessDate());
		jobStatus.setExecTime(SystemInformationManager.getInstance().getBFBusinessDateTime());
		jobStatus.setJobStatus(status);
		jobStatus.setStatusDesc(statusDesc);
		jobStatus.setRecordCount(recCount);
		ManageJobStatus.insertJobStatus(jobStatus);
	}
}