package com.ce.simah.util;

import java.util.HashMap;

public interface IFileData {

	HashMap getDataMap();
	
}
