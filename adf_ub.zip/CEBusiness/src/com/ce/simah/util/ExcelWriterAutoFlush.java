package com.ce.simah.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class ExcelWriterAutoFlush {

	SXSSFWorkbook wb = null;
	Sheet sheet = null;
	private String fileName;
	int rownum = 1;
	FileOutputStream fos = null;

	public ExcelWriterAutoFlush(String fileName) {
		this.fileName = fileName;
		wb = new SXSSFWorkbook(SXSSFWorkbook.DEFAULT_WINDOW_SIZE/* 100 */);
		sheet = wb.createSheet();
		try {
			fos = new FileOutputStream(this.fileName);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
	}

	public void writeHeader(IFileHeader header) {
		int rownum = 0;
		Row row = sheet.createRow(rownum);
		int rowCol = 0;
		ArrayList headers = header.getHeaders();
		for (int i = 0; i < headers.size(); i++) {
			Cell cell = row.createCell(i);
			cell.setCellValue((String) headers.get(i));
		}

	}

	public void writeToExcelAutoFlush(IFileData dataObject) {

		try {
			HashMap dataMap = dataObject.getDataMap();
			int noOfFields = dataMap.size();

			Row row = sheet.createRow(rownum);
			for (int key = 0; key < noOfFields; key++) {
				Cell cell = row.createCell(key);
				cell.setCellValue((String) dataMap.get(key));
			}
			rownum++;

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void writeToFile() {
		try {
			wb.write(fos);
			if (fos != null) {
				fos.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
