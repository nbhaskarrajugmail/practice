package com.ce.simah.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.cbs.config.ModuleConfiguration;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHACCOUNTMAP;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_JOINTACCOUNT;
import com.misys.bankfusion.subsystem.persistence.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class SimahUtil {
	private transient final static Log logger = LogFactory.getLog(SimahUtil.class.getName());
	private static String DATE_PATTERN = "dd/MM/yyyy";
	//private static String simahAccount = null;
	private static SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN);
	
	
	public static String getStringFromAmount(BigDecimal amount){
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		df.setMinimumFractionDigits(0);
		df.setGroupingUsed(false);
		return df.format(amount);
	}
	
	public static String getDateAsString(Date date){
		return formatter.format(date);
	}
	public static Date getDateFromString(String dateString){
		Date d = null;
		try {
			d = new Date (formatter.parse(dateString).getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
	}

	
	
	public static BigDecimal getAmountFromString(String string){
		BigDecimal amount = null;
		try{
			amount = new BigDecimal(string);
		}catch(NumberFormatException e){
			logger.error("Cannot convert String to Amount:"+e);
			e.printStackTrace();
		}
		
		return amount;
	}
	
	public static BigDecimal getAmountFromString(String string, boolean returnZero){
		BigDecimal amount = BigDecimal.ZERO;
		try{
			amount = new BigDecimal(string);
		}catch(NumberFormatException e){
			logger.error("Cannot convert String to Amount:"+e);
			e.printStackTrace();
		}
		
		return amount;
	}
	
}
