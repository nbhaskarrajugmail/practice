package com.ce.simah.util;

import java.util.ArrayList;

public interface IFileHeader {
	
	ArrayList getHeaders();

}
