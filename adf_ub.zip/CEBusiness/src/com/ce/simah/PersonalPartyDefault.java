package com.ce.simah;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.simah.defaults.ProcessDefaultAccounts;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHDEFAULTTAG;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_SimahDefault_PPExtract;

public class PersonalPartyDefault extends AbstractCE_PTY_SimahDefault_PPExtract {
	
	// TODO : this file is not used anymore, need to be deleted soon

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private transient final static Log logger = LogFactory.getLog(PersonalPartyDefault.class.getName());

	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_SIMAHDEFAULTTAG "
			+ "(CEROWSEQIDPK,CEACCOUNTID,CEEXISTSORNEW,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY CECRINSTRUMENTNO) CEROWSEQIDPK,"
			+ " CECRINSTRUMENTNO, 'E' CEEXISTSORNEW, 0 VERSIONNUM FROM CUSTOMEXTN.CETB_SIMAHLASTMSG WHERE CEPRODUCTSTATUS = 'W' ";

	private IPersistenceObjectsFactory factory;

	public PersonalPartyDefault(BankFusionEnvironment env) {
	}

	@Override
	public void process(BankFusionEnvironment env) {
		factory = BankFusionThreadLocal.getPersistanceFactory();
		factory.bulkDeleteAll(IBOCE_SIMAHDEFAULTTAG.BONAME);
		factory.commitTransaction();
		factory.beginTransaction();
		try {
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

			ps.execute();
			this.factory.commitTransaction();
			this.factory.beginTransaction();
		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// handler is available already
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
		ProcessDefaultAccounts defaultProcessor = new ProcessDefaultAccounts();
		defaultProcessor.process(-1,-1);
	}

}