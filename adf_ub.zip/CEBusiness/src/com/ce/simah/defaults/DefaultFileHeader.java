package com.ce.simah.defaults;

import java.util.ArrayList;

import com.ce.simah.util.IFileHeader;


public class DefaultFileHeader implements IFileHeader{
	
	private ArrayList headers = new ArrayList();
	
	
	public DefaultFileHeader() {
		headers.add("Outstanding Balance");
		headers.add("Credit Instrument Number");
		headers.add("Product Type");
		headers.add("Payment Status");
		headers.add("Date of status change");
	}


	/**
	 * @return the headers
	 */
	public ArrayList getHeaders() {
		return headers;
	}
	

}
