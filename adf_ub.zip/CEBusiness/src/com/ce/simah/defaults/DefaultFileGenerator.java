package com.ce.simah.defaults;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.simah.util.ExcelWriterAutoFlush;
import com.ce.simah.util.SimahUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHACCOUNTMAP;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSGHIST;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.utils.GUIDGen;

public class DefaultFileGenerator {

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();;
	private transient final static Log logger = LogFactory.getLog(DefaultFileGenerator.class.getName());

	@SuppressWarnings("rawtypes")
	public void generateFile(List list) {
		if (null == list || list.isEmpty())
			return;

		CEUtil util = new CEUtil();
		String path = util.getModuleConfigurationValue("CESIMAHINTERFACE", "SIMAH_DEFAULT_FILE_PATH");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmm");
		String fileName = formatter.format(SystemInformationManager.getInstance().getBFBusinessDateTime());
		ExcelWriterAutoFlush writer = new ExcelWriterAutoFlush(path + "DEF_" + fileName + ".xls");
		writer.writeHeader(new DefaultFileHeader());
		try {
			for (int i = 0; i < list.size(); i++) {
				DefaultFileData data = (DefaultFileData) list.get(i);
				try {
					DefaultFileData data1 = new DefaultFileData();
					data1 = data;
					String simahAccount = null;
					String simahAccountOpenDate = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
							"SIMAH_ACCOUNT_OPEN_DATE");
					Date simahDate = new SimpleDateFormat("yyyy-MM-dd").parse(simahAccountOpenDate);
					IBOAttributeCollectionFeature accountDetails = (IBOAttributeCollectionFeature) BankFusionThreadLocal
							.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME,
									data.getCreditInstrumentNumber(), false);
					Date accountOpenDate = accountDetails.getF_OPENDATE();
					if (accountOpenDate.compareTo(simahDate) < 0) {

						ArrayList<String> mapAccountParam = new ArrayList<String>();
						mapAccountParam.add(accountDetails.getBoID());
						IBOCE_SIMAHACCOUNTMAP acctMapDetails = (IBOCE_SIMAHACCOUNTMAP) BankFusionThreadLocal
								.getPersistanceFactory()
								.findByPrimaryKey(IBOCE_SIMAHACCOUNTMAP.BONAME, accountDetails.getBoID(), true);
						if (!(acctMapDetails == null)) {
							simahAccount = acctMapDetails.getF_SRCACCTNO();
						}
						else {
							simahAccount = accountDetails.getBoID();
						}
					}
					else {
						simahAccount = accountDetails.getBoID();
					}

					data1.setCreditInstrumentNumber(simahAccount);
					writer.writeToExcelAutoFlush(data1);
				} catch (Exception e) {
					// TODO: handle exception
				}

				updateOutStandingDetails(data);
			}
			writer.writeToFile();
		} catch (Exception e) {
			logger.error("Error While generating or storing data file\n" + e);
			e.printStackTrace();
			writer.writeToFile();
		}
	}

	private void updateOutStandingDetails(DefaultFileData data) {
		IBOCE_SIMAHLASTMSG simah = (IBOCE_SIMAHLASTMSG) factory.findByPrimaryKey(IBOCE_SIMAHLASTMSG.BONAME,
				data.getIdPkey(), true);
		archiveExistingRecord(simah);

		simah.setF_PRODUCTSTATUS(data.getProductStatus());
		simah.setF_PAYMENTSTATUS(data.getPaymentStatus());
		simah.setF_OUTSTANDINGBAL(new BigDecimal(data.getOutstandingbalance()));
		simah.setF_PASTDUE(new BigDecimal(data.getPastDuebalance()));
		simah.setF_LASTPAYDATE(SimahUtil.getDateFromString(data.getLastPaymentDate()));
		simah.setF_DEFAULTSTATUS(data.getDefaultStatus());
		simah.setF_FILETYPE(data.getFileType());
		simah.setF_PROCESSEDDATE(SystemInformationManager.getInstance().getBFBusinessDate());

	}

	private void archiveExistingRecord(IBOCE_SIMAHLASTMSG oldSimahRec) {

		IBOCE_SIMAHLASTMSGHIST simah = (IBOCE_SIMAHLASTMSGHIST) factory
				.getStatelessNewInstance(IBOCE_SIMAHLASTMSGHIST.BONAME);

		simah.setBoID(GUIDGen.getNewGUID());
		simah.setF_APPTYPE(oldSimahRec.getF_APPTYPE());
		simah.setF_ASOFDATE(oldSimahRec.getF_ASOFDATE());
		simah.setF_CRINSTRUMENTNO(oldSimahRec.getF_CRINSTRUMENTNO());
		simah.setF_CYCLEID(oldSimahRec.getF_CYCLEID());
		simah.setF_FILETYPE(oldSimahRec.getF_FILETYPE());
		simah.setF_IDTYPE(oldSimahRec.getF_IDTYPE());
		simah.setF_LASTAMTPAID(oldSimahRec.getF_LASTAMTPAID());
		simah.setF_LASTPAYDATE(oldSimahRec.getF_LASTPAYDATE());
		simah.setF_LOANISSUEDATE(oldSimahRec.getF_LOANISSUEDATE());
		simah.setF_NEXTREPAYDATE(oldSimahRec.getF_NEXTREPAYDATE());
		simah.setF_OUTSTANDINGBAL(oldSimahRec.getF_OUTSTANDINGBAL());
		simah.setF_PASTDUE(oldSimahRec.getF_PASTDUE());
		simah.setF_PAYFREQUENCY(oldSimahRec.getF_PAYFREQUENCY());
		simah.setF_PAYMENTSTATUS(oldSimahRec.getF_PAYMENTSTATUS());
		simah.setF_PRODUCTLIMIT(oldSimahRec.getF_PRODUCTLIMIT());
		simah.setF_PRODUCTSTATUS(oldSimahRec.getF_PRODUCTSTATUS());
		simah.setF_PRODUCTTYPE(oldSimahRec.getF_PRODUCTTYPE());
		simah.setF_REPAYMENTAMT(oldSimahRec.getF_REPAYMENTAMT());
		simah.setF_SECURITYTYPE(oldSimahRec.getF_SECURITYTYPE());

		simah.setF_MSGID(oldSimahRec.getBoID());

		factory.create(IBOCE_SIMAHLASTMSGHIST.BONAME, simah);

	}

}