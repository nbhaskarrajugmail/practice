package com.ce.simah.defaults;

import java.util.HashMap;

import com.ce.simah.util.IFileData;

public class DefaultFileData implements IFileData {

	//This is specific for default files
	private String defaultStatus = "";
	
	private String creditInstrumentNumber = "";
	private String simahacctMap = "";
	private String productType = "ADFL";
	private String paymentStatus = "";
	private String pastDuebalance = "";
	private String lastPaymentDate = "";
	private String productStatus = "";

	private String idPkey = "";
	private String outstandingbalance = "";
	private String fileType = "";


	public DefaultFileData() {

	}

	public HashMap getDataMap() {
		HashMap map = new HashMap();
		
		map.put(0, pastDuebalance);
		map.put(1, creditInstrumentNumber);
		map.put(2, productType);
		map.put(3, defaultStatus);
		map.put(4, lastPaymentDate);
		
		return map;
	}

	/** @return the creditInstrumentNumber */
	public String getCreditInstrumentNumber() {
		return creditInstrumentNumber;
	}

	/** @param creditInstrumentNumber
	 *            the creditInstrumentNumber to set */
	public void setCreditInstrumentNumber(String creditInstrumentNumber) {
		this.creditInstrumentNumber = creditInstrumentNumber;
	}

	/** @return the productType */
	public String getProductType() {
		return productType;
	}

	/** @param productType
	 *            the productType to set */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/** @return the productStatus */
	public String getProductStatus() {
		return productStatus;
	}

	/** @param productStatus
	 *            the productStatus to set */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	/** @return the lastPaymentDate */
	public String getLastPaymentDate() {
		return lastPaymentDate;
	}

	/** @param lastPaymentDate
	 *            the lastPaymentDate to set */
	public void setLastPaymentDate(String lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	/** @return the paymentStatus */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/** @param paymentStatus
	 *            the paymentStatus to set */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/** @return the pastDuebalance */
	public String getPastDuebalance() {
		return pastDuebalance;
	}

	/** @param pastDuebalance
	 *            the pastDuebalance to set */
	public void setPastDuebalance(String pastDuebalance) {
		this.pastDuebalance = pastDuebalance;
	}


	/**
	 * @return the defaultStatus
	 */
	public String getDefaultStatus() {
		return defaultStatus;
	}

	/**
	 * @param defaultStatus the defaultStatus to set
	 */
	public void setDefaultStatus(String defaultStatus) {
		this.defaultStatus = defaultStatus;
	}

	/**
	 * @return the idPkey
	 */
	public String getIdPkey() {
		return idPkey;
	}

	/**
	 * @param idPkey the idPkey to set
	 */
	public void setIdPkey(String idPkey) {
		this.idPkey = idPkey;
	}

	/**
	 * @return the outstandingBalance
	 */
	public String getOutstandingbalance() {
		return outstandingbalance;
	}

	/**
	 * @param outstandingBalance the outstandingBalance to set
	 */
	public void setOutstandingbalance(String outstandingbalance) {
		this.outstandingbalance = outstandingbalance;
	}

	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}

	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
/**
 * @return the simah account number
 */
	public String getsimahacctMap() {
		return simahacctMap;
		
	}
	
	/**
	 * @param simahacctMap 
	 * @param simah account number to set simah account number
	 */
	
	public void setsimahacctMap(String simahacctMap) {
		this.simahacctMap = simahacctMap;
	}

}
