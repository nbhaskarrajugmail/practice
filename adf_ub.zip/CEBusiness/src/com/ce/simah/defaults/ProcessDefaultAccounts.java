package com.ce.simah.defaults;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.ce.simah.util.SimahUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHDEFAULTTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanArrears;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class ProcessDefaultAccounts {

	private static String SIMAH_QUERY = " WHERE " + IBOCE_SIMAHLASTMSG.PRODUCTSTATUS + "=? AND "
			+ IBOCE_SIMAHLASTMSG.CRINSTRUMENTNO + "=?";
	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static String QUERY_LOANARREAS = " WHERE " + IBOLoanArrears.ACCOUNTID + " = ? ";
	private static String LOANSTATUS_ARREARS = "2411";
	private static String LOANSTATUS_NORMAL = "2410";
	private static String LOANSTATUS_SETTLED = "2412";
	private static String LOANSTATUS_COMPLETED = "2413";

	private static final String SIMAH_LOAN_CLOSED = "C";
	private static final String SIMAH_LOAN_DEFAULT = "W";
	private static final String SIMAH_LOAN_ACTIVE = "A";

	private IPersistenceObjectsFactory factory;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List process(int pageSize, int pageToProcess) {
		List defaultDataObjects = new LinkedList();
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList();

		String GENERIC_QUERY = "SELECT " + IBOCE_SIMAHDEFAULTTAG.ACCOUNTID + " AS ACCOUNTID, "
				+ IBOCE_SIMAHDEFAULTTAG.EXISTSORNEW + " AS EXISTSORNEW, " + IBOCE_SIMAHDEFAULTTAG.ROWSEQID
				+ " AS ROWSEQ FROM " + IBOCE_SIMAHDEFAULTTAG.BONAME;

		if (pageSize > 0) {
			int fromPage = (pageToProcess - 1) * pageSize + 1;
			int toPage = pageToProcess * pageSize;
			GENERIC_QUERY = GENERIC_QUERY + " WHERE " + IBOCE_SIMAHDEFAULTTAG.ROWSEQID + " BETWEEN ? AND ? ";
			params.add(fromPage);
			params.add(toPage);
		}

		List<SimplePersistentObject> records = this.factory.executeGenericQuery(GENERIC_QUERY, params, null, true);
		for (SimplePersistentObject record : records) {
			DefaultFileData data = new DefaultFileData();
			String instrumentId = (String) record.getDataMap().get("ACCOUNTID");
			params.clear();
			params.add(SIMAH_LOAN_DEFAULT);
			params.add(instrumentId);
			IBOCE_SIMAHLASTMSG simaDetails = (IBOCE_SIMAHLASTMSG) factory.findFirstByQuery(IBOCE_SIMAHLASTMSG.BONAME,
					SIMAH_QUERY, params, true);
			data.setCreditInstrumentNumber(instrumentId);
			data.setIdPkey(simaDetails.getBoID());
			data = applyRules(data, simaDetails);
			if (data == null) {
				simaDetails.setF_PROCESSEDDATE(SystemInformationManager.getInstance().getBFBusinessDate());
				factory.commitTransaction();
				factory.beginTransaction();
				continue;
			}
			defaultDataObjects.add(data);
		}

		// TODO : used on single thread application (to be removed)
		if (pageSize < 0) {
			DefaultFileGenerator fileGenerator = new DefaultFileGenerator();
			fileGenerator.generateFile(defaultDataObjects);
		}
		return defaultDataObjects;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private DefaultFileData applyRules(DefaultFileData data, IBOCE_SIMAHLASTMSG simaDetails) {

		ArrayList params = new ArrayList<>();
		params.add(data.getCreditInstrumentNumber());
		IBOLendingFeature loanDetails = (IBOLendingFeature) factory.findFirstByQuery(IBOLendingFeature.BONAME,
				QUERY_LOANDETAIL, params, true);

		if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_NORMAL)) {
			data.setProductStatus(SIMAH_LOAN_ACTIVE);
			data.setPaymentStatus("0");

			data.setOutstandingbalance(SimahUtil.getStringFromAmount(loanDetails.getF_REDUCINGPRINCIPAL()));
			data.setPastDuebalance(SimahUtil.getStringFromAmount(BigDecimal.ZERO));
			data.setLastPaymentDate(SimahUtil.getDateAsString(loanDetails.getF_LASTPAYMENTDATE()));
			data.setDefaultStatus("RS");
			data.setFileType("R");
		} else if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_ARREARS)) {
			params.clear();
			params.add(data.getCreditInstrumentNumber());
			BigDecimal outstandingDue = simaDetails.getF_PASTDUE();
			IBOLoanArrears loanArrears = (IBOLoanArrears) factory.findFirstByQuery(IBOLoanArrears.BONAME,
					QUERY_LOANARREAS, params, true);
			if (outstandingDue.compareTo(loanArrears.getF_REPAYMENTAMTINARREARS()) > 0) {
				data.setProductStatus(SIMAH_LOAN_DEFAULT);
				data.setPaymentStatus("6");

				data.setOutstandingbalance(SimahUtil.getStringFromAmount(loanDetails.getF_REDUCINGPRINCIPAL()));
				data.setPastDuebalance(SimahUtil.getStringFromAmount(loanArrears.getF_REPAYMENTAMTINARREARS()));
				data.setLastPaymentDate(SimahUtil.getDateAsString(loanDetails.getF_LASTPAYMENTDATE()));
				data.setDefaultStatus("PP");
				data.setFileType("D");
			} else {
				data = null;
			}

		} else if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_SETTLED)
				|| loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_COMPLETED)) {
			data.setProductStatus(SIMAH_LOAN_CLOSED);
			data.setPaymentStatus("0");

			data.setOutstandingbalance(SimahUtil.getStringFromAmount(loanDetails.getF_REDUCINGPRINCIPAL()));
			data.setPastDuebalance(SimahUtil.getStringFromAmount(BigDecimal.ZERO));
			data.setLastPaymentDate(SimahUtil.getDateAsString(loanDetails.getF_LASTPAYMENTDATE()));
			data.setDefaultStatus("FS");
			data.setFileType("D");

		} else {
			data = null;
		}
		return data;
	}

}