package com.ce.simah.regular;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.simah.util.SimahUtil;
import com.ibm.icu.text.SimpleDateFormat;
import com.misys.bankfusion.common.constant.CommonConstants;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanApplicantMap;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanApplication;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanRequest;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_Address;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_AddressLink;
import com.trapedza.bankfusion.bo.refimpl.IBOPT_PFN_PartyContactDetails;
import com.trapedza.bankfusion.bo.refimpl.IBOUB_CNF_JOINTACCOUNT;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;

public class ManageRegularObject {

	private static final String PRODUCT_TYPE = "ADFL";
	private static final String QUERY_LOANSCHDATE = " WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID
			+ " =? AND " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " < ? ORDER BY "
			+ IBOLN_LEN_LoanSchedule.PAYMENTDT + " DESC ";

	private static final String QUERY_LOANSCHNEXTDATE = " WHERE "
			+ IBOLN_LEN_LoanSchedule.LOANACCOUNTID + " =? AND " + IBOLN_LEN_LoanSchedule.PAYMENTDT
			+ " > ? ORDER BY " + IBOLN_LEN_LoanSchedule.PAYMENTDT + " ASC ";

	private static final String QUERY_ACC_HOLDERS = " SELECT COUNT(" + IBOUB_CNF_JOINTACCOUNT.ACCOUNTID
			+ ") AS CUSTCOUNT FROM " + IBOUB_CNF_JOINTACCOUNT.BONAME + " WHERE "
			+ IBOUB_CNF_JOINTACCOUNT.ACCOUNTID + " = ?";

	private static final String QUERY_LOAN_HOLDERS = " WHERE " + IBOLoanApplicantMap.LOANREQUESTCODE
			+ " = ?";

	private static final String QUERY_ADDLINK = " WHERE " + IBOPT_PFN_AddressLink.ENTITYID + "=? AND "
			+ IBOPT_PFN_AddressLink.ISDEAFULTADDRESS + " = ? ";
	private static final String QUERY_CONTACT = " WHERE "
			+ IBOPT_PFN_PartyContactDetails.INTERNALPARTYID + "=? AND "
			+ IBOPT_PFN_PartyContactDetails.CONTACTMETHOD + "=? AND "
			+ IBOPT_PFN_PartyContactDetails.ISCONTACTACTIVE + "=?";

	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static final String CONTACT_MODE = "SMS";
	private static final String YES = "Y";
	private static final String DEFAULT_ADDRESSTYPE = "RESID";
	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
	Log logger = LogFactory.getLog(ManageRegularObject.class);
	public void populateObject(RegularFileData data) {
		logger.info("populateObject method start here data.getCreditInstrumentNumber()-->"+data.getCreditInstrumentNumber());
		SimahUtil util = new SimahUtil();

		ArrayList params = new ArrayList();
		params.add(data.getCreditInstrumentNumber());
		IBOLendingFeature loanDetails = (IBOLendingFeature) factory.findFirstByQuery(
				IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, true);

		data.setIssueDate(SimahUtil.getDateAsString(loanDetails.getF_LOANSTARTDATE()));

		data.setProductType(PRODUCT_TYPE);
		data.setProductLimitOriginalAmount("");// TODO from Loan Application table
		data.setSalaryAssignmentFlag("N");

		data.setProductExpiryDate(SimahUtil.getDateAsString(loanDetails.getF_FINALMATURITYDATE()));
		data.setInstalmentAmount("");// TODO From Schedule table

		Date cycleDate = SystemInformationManager.getInstance().getBFBusinessDate();
		SimpleDateFormat cycleDateFormatter = new SimpleDateFormat("yyyyMMdd");
		data.setCycleID(cycleDateFormatter.format(cycleDate));

		BigDecimal lastPayAmount = loanDetails.getF_LASTPAYMENTAMOUNT();
		lastPayAmount.setScale(2, BigDecimal.ROUND_DOWN);
		data.setLastAmountPaid(SimahUtil.getStringFromAmount(lastPayAmount));

		if (lastPayAmount.compareTo(BigDecimal.ZERO) > 0)
			data.setLastPaymentDate(SimahUtil.getDateAsString(loanDetails.getF_LASTPAYMENTDATE()));
		else
			data.setLastPaymentDate(CommonConstants.EMPTY_STRING);

		// Set Outstanding Balance
		data.setOutstandingbalance(SimahUtil.getStringFromAmount(loanDetails.getF_REDUCINGPRINCIPAL()));

		// Past Due :- Set up while checking arrears in ProcessRegularAccount class

		// As of Date or Previous Repayment Date from present cycle date
		params.clear();
		params.add(data.getCreditInstrumentNumber());
		params.add(SystemInformationManager.getInstance().getBFBusinessDate());
		IBOLN_LEN_LoanSchedule loanSchedule = (IBOLN_LEN_LoanSchedule) factory.findFirstByQuery(
				IBOLN_LEN_LoanSchedule.BONAME, QUERY_LOANSCHDATE, params, true);
		if (null != loanSchedule) {
			data.setAsofDate(SimahUtil.getDateAsString(loanSchedule.getF_PAYMENTDT()));
			// set the installment amount
			data.setInstalmentAmount(SimahUtil.getStringFromAmount(loanSchedule.getF_PAYMENTAMT()));
		} else
			data.setAsofDate(CommonConstants.EMPTY_STRING);

		// Get The Next repayment date from Schedule
		loanSchedule = null;
		params.clear();
		params.add(data.getCreditInstrumentNumber());
		params.add(SystemInformationManager.getInstance().getBFBusinessDate());
		loanSchedule = (IBOLN_LEN_LoanSchedule) factory.findFirstByQuery(IBOLN_LEN_LoanSchedule.BONAME,
				QUERY_LOANSCHNEXTDATE, params, true);
		if (null != loanSchedule) {
			data.setNextpaymentDate(SimahUtil.getDateAsString(loanSchedule.getF_PAYMENTDT()));
			if (null == data.getInstalmentAmount() || data.getInstalmentAmount().isEmpty())
				data.setInstalmentAmount(SimahUtil.getStringFromAmount(loanSchedule.getF_PAYMENTAMT()));
		} else
			data.setNextpaymentDate(CommonConstants.EMPTY_STRING);

		data.setiDtype("T");

		// Get the frequency & tenure from LoanRequest
		params.clear();
		// params.add(loanDetails.getF_LOANREFERENCE());
		IBOLoanRequest loanRequest = (IBOLoanRequest) factory.findByPrimaryKey(IBOLoanRequest.BONAME,
				loanDetails.getF_LOANREFERENCE(), true);
		data.setPaymentFrequency(getFrequency(loanRequest.getF_PREFERREDREPAYMENTFREQ()));
		data.setTenure(getTerm(loanRequest.getF_LOANTERMINMONTHS(), data.getPaymentFrequency()));

		// Set Approved Amount
		IBOLoanApplication loanApp = (IBOLoanApplication) factory.findByPrimaryKey(
				IBOLoanApplication.BONAME, loanDetails.getF_LOANREFERENCE(), true);
		data.setProductLimitOriginalAmount(SimahUtil.getStringFromAmount(loanApp
				.getF_PRINCIPALAPPROVED()));
		// Set Address
		String customerId = loanApp.getF_LEADAPPLICANTCUSTOMERID();
		String loanRef = loanApp.getF_LOANREQUESTCODE();
		params.clear();
		params.add(customerId);
		params.add(YES);
		IBOPT_PFN_AddressLink addLinks = (IBOPT_PFN_AddressLink) factory.findFirstByQuery(
				IBOPT_PFN_AddressLink.BONAME, QUERY_ADDLINK, params, true);
		if (null != addLinks) {
			IBOPT_PFN_Address address = (IBOPT_PFN_Address) factory.findByPrimaryKey(
					IBOPT_PFN_Address.BONAME, addLinks.getF_ADDRESSID(), true);
			StringBuffer sb = new StringBuffer();
			sb.append(address.getF_ADDRESSLINE1()).append(CommonConstants.SPACE)
					.append(address.getF_ADDRESSLINE2()).append(CommonConstants.SPACE)
					.append(address.getF_ADDRESSLINE3());
			data.setAddress1Arabic(sb.toString());
			data.setAddressType(DEFAULT_ADDRESSTYPE);
		}

		// Set Number of account holders
		params.clear();
		params.add(loanRef);

		// List<SimplePersistentObject> records = factory.executeGenericQuery(QUERY_ACC_HOLDERS, params,
		// null, true);
		List<IBOLoanApplicantMap> records = factory.findByQuery(IBOLoanApplicantMap.BONAME,
				QUERY_LOAN_HOLDERS, params, null, true);
		if (null != records && !records.isEmpty()) {
			data.setNumberofcreditinstrumentholders(new Integer(records.size()).toString());
			data.setApplicantType("P");
			if (records.size() > 1) {
				for (int i = 0; i < records.size(); i++) {
					IBOLoanApplicantMap record = records.get(i);
					if (record.getF_CUSTOMERCODE().equals(customerId))
						continue;
					data.getGuarantors().add(getGuarantor(customerId));
				}
			}
		} else
			data.setNumberofcreditinstrumentholders("1");
		// Set Security as OT for now
		data.setSecurityType("OT");

		// Contact Type Defaulted to "M", Countrycode to 966
		data.setContacttype("M");
		data.setContactcountrycode("966");

		// Set Contact Number
		params.clear();
		params.add(customerId);
		params.add(CONTACT_MODE);
		params.add(YES);
		IBOPT_PFN_PartyContactDetails contact = (IBOPT_PFN_PartyContactDetails) factory
				.findFirstByQuery(IBOPT_PFN_PartyContactDetails.BONAME, QUERY_CONTACT, params, true);
		if (null != contact) {
			data.setContactNumber(contact.getF_CONTACTVALUE());
		}
		logger.info("populateObject method Ends here data.getCreditInstrumentNumber()-->"+data.getCreditInstrumentNumber());
	}

	private String getFrequency(String fbeFreq) {
		if (fbeFreq.trim().equals("M12"))
			return "Y";
		if (fbeFreq.trim().equals("M1"))
			return "M";
		if (fbeFreq.trim().equals("M3"))
			return "Q";
		if (fbeFreq.trim().equals("M6"))
			return "H";

		return fbeFreq;
	}

	private String getTerm(int termInMonths, String freq) {
		String term = "";
		if (freq.equals("Y")) {
			term = new Integer(termInMonths / 12).toString();
			return term;
		}
		if (freq.equals("M")) {
			term = new Integer(termInMonths).toString();
			return term;
		}
		if (freq.equals("Q")) {
			term = new Integer(termInMonths / 4).toString();
			return term;
		}
		if (freq.equals("H")) {
			term = new Integer(termInMonths / 6).toString();
			return term;
		}
		term = new Integer(termInMonths).toString();

		return term;
	}

	private GuarantorDetails getGuarantor(String customerId) {
		GuarantorDetails g = new GuarantorDetails();
		g.setCustomerId(customerId);
		g.setApplicantType("G");
		g.setContactcountrycode("966");
		g.setContacttype("M");
		ArrayList params = new ArrayList();
		params.add(customerId);
		params.add(CONTACT_MODE);
		params.add(YES);
		IBOPT_PFN_PartyContactDetails contact = (IBOPT_PFN_PartyContactDetails) factory
				.findFirstByQuery(IBOPT_PFN_PartyContactDetails.BONAME, QUERY_CONTACT, params, true);
		if (null != contact) {
			g.setContactNumber(contact.getF_CONTACTVALUE());
		}
		params.clear();
		params.add(customerId);
		params.add(YES);
		IBOPT_PFN_AddressLink addLinks = (IBOPT_PFN_AddressLink) factory.findFirstByQuery(
				IBOPT_PFN_AddressLink.BONAME, QUERY_ADDLINK, params, true);
		if (null != addLinks) {
			IBOPT_PFN_Address address = (IBOPT_PFN_Address) factory.findByPrimaryKey(
					IBOPT_PFN_Address.BONAME, addLinks.getF_ADDRESSID(), true);
			StringBuffer sb = new StringBuffer();
			sb.append(address.getF_ADDRESSLINE1()).append(CommonConstants.SPACE)
					.append(address.getF_ADDRESSLINE2()).append(CommonConstants.SPACE)
					.append(address.getF_ADDRESSLINE3());
			g.setAddress1Arabic(sb.toString());
			g.setAddressType(DEFAULT_ADDRESSTYPE);
		}
		return g;

	}
}