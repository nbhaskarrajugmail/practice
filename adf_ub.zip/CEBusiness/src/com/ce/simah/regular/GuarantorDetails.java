package com.ce.simah.regular;

public class GuarantorDetails {
	
	private String customerId = "";
	private String applicantType = "";
	private String addressType = "";
	private String address1Arabic = "";
	private String contacttype = "";
	private String contactcountrycode = "";
	private String contactNumber = "";
	/**
	 * @return the applicantType
	 */
	public String getApplicantType() {
		return applicantType;
	}
	/**
	 * @param applicantType the applicantType to set
	 */
	public void setApplicantType(String applicantType) {
		this.applicantType = applicantType;
	}
	/**
	 * @return the addressType
	 */
	public String getAddressType() {
		return addressType;
	}
	/**
	 * @param addressType the addressType to set
	 */
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	/**
	 * @return the address1Arabic
	 */
	public String getAddress1Arabic() {
		return address1Arabic;
	}
	/**
	 * @param address1Arabic the address1Arabic to set
	 */
	public void setAddress1Arabic(String address1Arabic) {
		this.address1Arabic = address1Arabic;
	}
	/**
	 * @return the contacttype
	 */
	public String getContacttype() {
		return contacttype;
	}
	/**
	 * @param contacttype the contacttype to set
	 */
	public void setContacttype(String contacttype) {
		this.contacttype = contacttype;
	}
	/**
	 * @return the contactcountrycode
	 */
	public String getContactcountrycode() {
		return contactcountrycode;
	}
	/**
	 * @param contactcountrycode the contactcountrycode to set
	 */
	public void setContactcountrycode(String contactcountrycode) {
		this.contactcountrycode = contactcountrycode;
	}
	/**
	 * @return the contactNumber
	 */
	public String getContactNumber() {
		return contactNumber;
	}
	/**
	 * @param contactNumber the contactNumber to set
	 */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	

}
