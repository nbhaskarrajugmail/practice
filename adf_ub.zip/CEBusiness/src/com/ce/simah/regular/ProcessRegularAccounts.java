package com.ce.simah.regular;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.simah.util.SimahUtil;
import com.trapedza.bankfusion.bo.refimpl.IBOAccount;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHREGULARTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOCustomer;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanArrears;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanSettlement;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;

public class ProcessRegularAccounts {

	private static String SIMAH_QUERY = " WHERE " + IBOCE_SIMAHLASTMSG.PRODUCTSTATUS + "=? AND "
			+ IBOCE_SIMAHLASTMSG.CRINSTRUMENTNO + "=?";
	private static String QUERY_LOANDETAIL = " WHERE " + IBOLendingFeature.ACCOUNTID + " = ? ";
	private static String QUERY_LOANARREAS = " WHERE " + IBOLoanArrears.ACCOUNTID + " = ? ";
	private static String LOANSTATUS_ARREARS = "2411";
	private static String LOANSTATUS_NORMAL = "2410";
	private static String LOANSTATUS_COMPLETED = "2413";
	private static String LOANSTATUS_SETTLED = "2412";

	private static final String SIMAH_LOAN_CLOSED = "C";
	private static final String SIMAH_LOAN_DEFAULT = "W";
	private static final String SIMAH_LOAN_ACTIVE = "A";
	private static final String SETTLED_QUERY = " WHERE "+IBOLoanSettlement.ACCOUNTID+" =?";
	private Date lastExecDate = null;

	private IPersistenceObjectsFactory factory;
	Log logger = LogFactory.getLog(ProcessRegularAccounts.class);
	public List process(int pageSize, int pageToProcess) {
		logger.info("Preparing of SIMHA Regular Accounts Start");
		List regularDataObjects = new LinkedList();
		this.factory = BankFusionThreadLocal.getPersistanceFactory();
		ArrayList params = new ArrayList();

		String GENERIC_QUERY = "SELECT " + IBOCE_SIMAHREGULARTAG.ACCOUNTID
				+ " AS ACCOUNTID, " + IBOCE_SIMAHREGULARTAG.EXISTSORNEW + " AS EXISTSORNEW, "
				+ IBOCE_SIMAHREGULARTAG.ROWSEQID + " AS ROWSEQ FROM " + IBOCE_SIMAHREGULARTAG.BONAME;
		if (pageSize > 0) {
			int fromPage = (pageToProcess - 1) * pageSize + 1;
			int toPage = pageToProcess * pageSize;
			GENERIC_QUERY = GENERIC_QUERY + " WHERE " + IBOCE_SIMAHREGULARTAG.ROWSEQID + " BETWEEN ? AND ? ";
			params.add(fromPage);
			params.add(toPage);
		}

		List<SimplePersistentObject> records = this.factory.executeGenericQuery(GENERIC_QUERY, params,
				null, true);
		for (SimplePersistentObject record : records) {
			RegularFileData data = new RegularFileData();
			String instrumentId = (String) record.getDataMap().get("ACCOUNTID");
			String existsOrNew = (String) record.getDataMap().get("EXISTSORNEW");

			IBOAccount account = (IBOAccount) factory.findByPrimaryKey(IBOAccount.BONAME, instrumentId,
					true);
			if (null == account) {
				continue;
			}
			IBOCustomer customer = (IBOCustomer) factory.findByPrimaryKey(IBOCustomer.BONAME,
					account.getF_CUSTOMERCODE(), true);
			if (!customer.getF_CUSTOMERTYPE().equals("1062")) {
				continue;
			}
			logger.info("Preparing of SIMHA Regular Accounts Data preparation customer--> " + customer.getBoID()
					+ " LoanAccount Id --> " + instrumentId);
			// Date dueDate = (Date) record.getDataMap().get("DUEDATE");
			if (existsOrNew.equals("E")) {
				params.clear();
				params.add("A");
				params.add(instrumentId);
				IBOCE_SIMAHLASTMSG simaDetails = (IBOCE_SIMAHLASTMSG) factory.findFirstByQuery(
						IBOCE_SIMAHLASTMSG.BONAME, SIMAH_QUERY, params, true);
				if (null == simaDetails)
					continue;
				data.setCreditInstrumentNumber(instrumentId);//here account id needs to be fetched from new custom table
				data.setIdPkey(simaDetails.getBoID());
				applyRules(data, simaDetails);
				if (data == null) {
					continue;
				}
			} else if (existsOrNew.equals("N")) {
				// Insert record in SIMAH and generate object for file
				data.setCreditInstrumentNumber(instrumentId);
				data.setProductStatus(SIMAH_LOAN_ACTIVE);
				data.setPaymentStatus("0");
				data.setPastDuebalance(SimahUtil.getStringFromAmount(BigDecimal.ZERO));
			}
			ManageRegularObject manager = new ManageRegularObject();
			manager.populateObject(data);
			regularDataObjects.add(data);
			logger.info("Completed Preparing of SIMHA Regular Accounts Data preparation customer --> "
					+ customer.getBoID() + " LoanAccount Id --> " + instrumentId);
		}
		// TODO : used on single thread application (to be reomved)
		if (pageSize < 0) {
			RegularFileGenerator fileGenerator = new RegularFileGenerator();
			fileGenerator.generateFile(regularDataObjects);
		}
		logger.info("Preparing of SIMHA Regular Accounts Ends Here");
		return regularDataObjects;
	}

	private void applyRules(RegularFileData data, IBOCE_SIMAHLASTMSG simaDetails) {

		if (simaDetails.getF_PRODUCTSTATUS().equals(SIMAH_LOAN_DEFAULT)) {
			// SHOULD NOT COME HERE **** @TODO - Check Default records ****//
			setStatusForDefault(data, simaDetails);
			return;
		}

		ArrayList params = new ArrayList<>();
		params.add(data.getCreditInstrumentNumber());
		IBOLendingFeature loanDetails = (IBOLendingFeature) factory.findFirstByQuery(
				IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, true);

		if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_COMPLETED)
				|| loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_SETTLED)) {
			// Check settled Date
			if(!isLoanSettledAfterLastCycle(data.getCreditInstrumentNumber())){
				data = null;
				return;
			}
				
			data.setOutstandingbalance(SimahUtil.getStringFromAmount(loanDetails
					.getF_REDUCINGPRINCIPAL()));
			data.setProductStatus(SIMAH_LOAN_CLOSED);
			data.setPaymentStatus("0");
			return;
		}
		if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_NORMAL)) {
			data.setProductStatus(SIMAH_LOAN_ACTIVE);
			data.setPaymentStatus("0");

			data.setPastDuebalance(SimahUtil.getStringFromAmount(BigDecimal.ZERO));
		}

		if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_ARREARS)) {
			params.clear();
			params.add(data.getCreditInstrumentNumber());
			IBOLoanArrears loanArrears = (IBOLoanArrears) factory.findFirstByQuery(
					IBOLoanArrears.BONAME, QUERY_LOANARREAS, params, true);
			setPaymentStatus(data, loanArrears.getF_DAYSPASTDUE());
			if (data.getPaymentStatus().equals("0"))
				data.setPastDuebalance(SimahUtil.getStringFromAmount(BigDecimal.ZERO));
			else
				data.setPastDuebalance(SimahUtil.getStringFromAmount(loanArrears
						.getF_REPAYMENTAMTINARREARS()));
		}
	}

	private void setPaymentStatus(RegularFileData data, int overdueDays) {
		String cycleDaysString = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
				"DELAY_CYCLE_PERIOD");
		String defaultDaysString = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
				"TOTAL_DAYS_TO_DEFAULT");
		String cycleTime = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
				"CYCLE_BEFORE_AFTER");

		Integer cycleDays = new Integer(cycleDaysString);
		Integer defaultDays = new Integer(defaultDaysString);
		Integer daysAfter = 0;
		if (cycleTime.equals("E")) {
			daysAfter = defaultDays - (cycleDays * 6);
			if (overdueDays <= daysAfter) {
				data.setProductStatus(SIMAH_LOAN_ACTIVE);
				data.setPaymentStatus("0");
				return;
			}
		}

		data.setProductStatus(SIMAH_LOAN_ACTIVE);
		if (daysAfter + 1 <= overdueDays && overdueDays <= daysAfter + cycleDays) {
			data.setPaymentStatus("1");
			return;
		}
		if ((daysAfter + cycleDays + 1) <= overdueDays && overdueDays <= daysAfter + (2 * cycleDays)) {
			data.setPaymentStatus("2");
			return;
		}
		if (daysAfter + (2 * cycleDays) + 1 <= overdueDays
				&& overdueDays <= daysAfter + (3 * cycleDays)) {
			data.setPaymentStatus("3");
			return;
		}
		if (daysAfter + (3 * cycleDays) + 1 <= overdueDays
				&& overdueDays <= daysAfter + (4 * cycleDays)) {
			data.setPaymentStatus("4");
			return;
		}
		if (daysAfter + (4 * cycleDays) + 1 <= overdueDays
				&& overdueDays <= daysAfter + (5 * cycleDays)) {
			data.setPaymentStatus("5");
			return;
		}
		if (daysAfter + (5 * cycleDays) + 1 <= overdueDays
				&& overdueDays <= daysAfter + (6 * cycleDays)) {
			data.setPaymentStatus("6");
			return;
		}

		if (overdueDays > daysAfter + (6 * cycleDays) && overdueDays <= defaultDays) {
			data.setPaymentStatus("6");
			data.setProductStatus(SIMAH_LOAN_ACTIVE);
			return;
		}
		if (overdueDays > defaultDays) {
			data.setPaymentStatus("6");
			data.setProductStatus(SIMAH_LOAN_DEFAULT);
			return;
		}
	}

	private IBOLendingFeature setStatusForDefault(RegularFileData data, IBOCE_SIMAHLASTMSG simaDetails) {
		ArrayList params = new ArrayList<>();
		params.add(data.getCreditInstrumentNumber());
		IBOLendingFeature loanDetails = (IBOLendingFeature) factory.findFirstByQuery(
				IBOLendingFeature.BONAME, QUERY_LOANDETAIL, params, true);
		if (loanDetails.getF_LOANSTATUS().equals(LOANSTATUS_NORMAL)) {
			data.setProductStatus(SIMAH_LOAN_ACTIVE);
			data.setPaymentStatus("0");
		} else {
			data = null;
		}
		return loanDetails;

	}

	private boolean isLoanSettledAfterLastCycle(String account) {
		ArrayList params = new ArrayList<>();
		Date settled = null;
		params.add(account);
		IBOLoanSettlement loanSettle = (IBOLoanSettlement) factory.findFirstByQuery(
				IBOLoanSettlement.BONAME, SETTLED_QUERY, params, true);
		if(null != loanSettle)
			settled = loanSettle.getF_SETTLEMENTDATE();
		Calendar calSettled = Calendar.getInstance();
		calSettled.setTime(settled);
		Calendar calLastCycle = Calendar.getInstance();
		calLastCycle.setTime(lastExecDate);
		if(calSettled.compareTo(calLastCycle)>0)
			return true;
		
		return false;
	}

	/** @return the lastExecDate */
	public Date getLastExecDate() {
		return lastExecDate;
	}

	/** @param lastExecDate
	 *            the lastExecDate to set */
	public void setLastExecDate(Date lastExecDate) {
		this.lastExecDate = lastExecDate;
	}

}
