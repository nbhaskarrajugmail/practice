package com.ce.simah.regular;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.ce.simah.util.ExcelWriterAutoFlush;
import com.ce.simah.util.SimahUtil;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHACCOUNTMAP;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSGHIST;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.utils.GUIDGen;

public class RegularFileGenerator {

	private IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();;
	private transient final static Log logger = LogFactory.getLog(RegularFileGenerator.class.getName());
	private static final String QUERY_ACC_OPEN_DATE = " SELECT IBOAttributeCollectionFeature.ACCOUNTID" + "FROM "
			+ IBOAttributeCollectionFeature.BONAME + " WHERE " + IBOAttributeCollectionFeature.OPENDATE + " < ?";
	private static final String WHERE_CETB_ACCTMAP = " WHERE " + IBOCE_SIMAHACCOUNTMAP.TARACCTNO + " LIKE ? ";

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ExcelWriterAutoFlush writer = new ExcelWriterAutoFlush("C:/Files/new.xls");
		writer.writeHeader(new RegularFileHeader());
		for (int i = 0; i < 10; i++) {
			RegularFileData data = new RegularFileData();
			data.setCreditInstrumentNumber("ABCDE12345");
			data.setApplicantType("B" + i);
			data.setPaymentStatus("R" + i);
			writer.writeToExcelAutoFlush(data);
		}
		writer.writeToFile();

	}

	public void generateFile(List list) {
		if (null == list || list.isEmpty())
			return;

		CEUtil util = new CEUtil();
		String path = util.getModuleConfigurationValue("CESIMAHINTERFACE", "SIMAH_REGULAR_FILE_PATH");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmm");
		String fileName = formatter.format(SystemInformationManager.getInstance().getBFBusinessDateTime());
		ExcelWriterAutoFlush writer = new ExcelWriterAutoFlush(path + "REG_" + fileName + ".xls");
		writer.writeHeader(new RegularFileHeader());
		try {
			for (int i = 0; i < list.size(); i++) {
				RegularFileData data = (RegularFileData) list.get(i);
				try {
					RegularFileData data1 = new RegularFileData();
					data1 = data;
					String simahAccount = null;
					IPersistenceObjectsFactory factory = BankFusionThreadLocal.getPersistanceFactory();
					String simahAccountOpenDate = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
							"SIMAH_ACCOUNT_OPEN_DATE");
					Date simahDate = new SimpleDateFormat("dd-MM-yyyy").parse(simahAccountOpenDate);
					IBOAttributeCollectionFeature accountDetails = (IBOAttributeCollectionFeature) BankFusionThreadLocal
							.getPersistanceFactory().findByPrimaryKey(IBOAttributeCollectionFeature.BONAME,
									data.getCreditInstrumentNumber(), false);
					Date accountOpenDate = accountDetails.getF_OPENDATE();
					if (accountOpenDate.compareTo(simahDate) < 0) {

						ArrayList<String> mapAccountParam = new ArrayList<String>();
						mapAccountParam.add(accountDetails.getBoID());
						IBOCE_SIMAHACCOUNTMAP acctMapDetails = (IBOCE_SIMAHACCOUNTMAP) BankFusionThreadLocal
								.getPersistanceFactory()
								.findByPrimaryKey(IBOCE_SIMAHACCOUNTMAP.BONAME, accountDetails.getBoID(), true);
						if (!(acctMapDetails == null)) {
							simahAccount = acctMapDetails.getF_SRCACCTNO();
						} else {
							simahAccount = accountDetails.getBoID();
						}
					} else {
						simahAccount = accountDetails.getBoID();
					}
					data1.setCreditInstrumentNumber(simahAccount);
					writer.writeToExcelAutoFlush(data1);
				} catch (Exception e) {
					logger.error("Error While generating or storing data file\n" + e);
					e.printStackTrace();
				}
				storeDetails(data);
				// For Gurantors
				if (null != data.getGuarantors() && !data.getGuarantors().isEmpty()) {
					for (int j = 0; j < data.getGuarantors().size(); j++) {
						data = setGuarantorsData(data, data.getGuarantors().get(j));
						writer.writeToExcelAutoFlush(data);
					}
				}
			}
			writer.writeToFile();
		} catch (Exception e) {
			logger.error("Error While generating or storing data file\n" + e);
			e.printStackTrace();
			writer.writeToFile();
		}
	}

	private void storeDetails(RegularFileData data) throws Exception {
		IBOCE_SIMAHLASTMSG simah = (IBOCE_SIMAHLASTMSG) factory.getStatelessNewInstance(IBOCE_SIMAHLASTMSG.BONAME);
		simah.setBoID(GUIDGen.getNewGUID());
		simah.setF_APPTYPE(data.getApplicantType());
		simah.setF_ASOFDATE(SimahUtil.getDateFromString(data.getAsofDate()));
		simah.setF_CRINSTRUMENTNO(data.getCreditInstrumentNumber());
		simah.setF_CYCLEID(data.getCycleID());
		simah.setF_FILETYPE("R");
		simah.setF_IDTYPE(data.getiDtype());
		simah.setF_LASTAMTPAID(SimahUtil.getAmountFromString(data.getLastAmountPaid()));
		simah.setF_LASTPAYDATE(SimahUtil.getDateFromString(data.getLastPaymentDate()));
		simah.setF_LOANISSUEDATE(SimahUtil.getDateFromString(data.getIssueDate()));
		simah.setF_NEXTREPAYDATE(SimahUtil.getDateFromString(data.getNextpaymentDate()));

		simah.setF_OUTSTANDINGBAL(SimahUtil.getAmountFromString(data.getOutstandingbalance()));
		simah.setF_PASTDUE(SimahUtil.getAmountFromString(data.getPastDuebalance()));
		simah.setF_PAYFREQUENCY(data.getPaymentFrequency());
		simah.setF_PAYMENTSTATUS(data.getPaymentStatus());
		simah.setF_PRODUCTLIMIT(SimahUtil.getAmountFromString(data.getProductLimitOriginalAmount()));
		simah.setF_PRODUCTSTATUS(data.getProductStatus());
		simah.setF_PRODUCTTYPE(data.getProductType());
		simah.setF_REPAYMENTAMT(SimahUtil.getAmountFromString(data.getInstalmentAmount(), true));
		simah.setF_SECURITYTYPE(data.getSecurityType());
		simah.setF_PROCESSEDDATE(SystemInformationManager.getInstance().getBFBusinessDate());

		factory.create(IBOCE_SIMAHLASTMSG.BONAME, simah);
		IBOCE_SIMAHLASTMSG oldSimahRec = (IBOCE_SIMAHLASTMSG) factory.findByPrimaryKey(IBOCE_SIMAHLASTMSG.BONAME,
				data.getIdPkey(), true);
		if (null == oldSimahRec)
			return;
		if (null != oldSimahRec && oldSimahRec.getF_PRODUCTSTATUS().equals("W")) {
			// Need not archive. Default will take care
			return;
		}
		if (null != data.getIdPkey() && !data.getIdPkey().isEmpty()) {
			archiveExistingRecord(oldSimahRec);
			factory.remove(IBOCE_SIMAHLASTMSG.BONAME, oldSimahRec);
		}
	}

	public void archiveExistingRecord(IBOCE_SIMAHLASTMSG oldSimahRec) {

		IBOCE_SIMAHLASTMSGHIST simah = (IBOCE_SIMAHLASTMSGHIST) factory
				.getStatelessNewInstance(IBOCE_SIMAHLASTMSGHIST.BONAME);

		simah.setBoID(GUIDGen.getNewGUID());
		simah.setF_APPTYPE(oldSimahRec.getF_APPTYPE());
		simah.setF_ASOFDATE(oldSimahRec.getF_ASOFDATE());
		simah.setF_CRINSTRUMENTNO(oldSimahRec.getF_CRINSTRUMENTNO());
		simah.setF_CYCLEID(oldSimahRec.getF_CYCLEID());
		simah.setF_FILETYPE(oldSimahRec.getF_FILETYPE());
		simah.setF_IDTYPE(oldSimahRec.getF_IDTYPE());
		simah.setF_LASTAMTPAID(oldSimahRec.getF_LASTAMTPAID());
		simah.setF_LASTPAYDATE(oldSimahRec.getF_LASTPAYDATE());
		simah.setF_LOANISSUEDATE(oldSimahRec.getF_LOANISSUEDATE());
		simah.setF_NEXTREPAYDATE(oldSimahRec.getF_NEXTREPAYDATE());
		simah.setF_OUTSTANDINGBAL(oldSimahRec.getF_OUTSTANDINGBAL());
		simah.setF_PASTDUE(oldSimahRec.getF_PASTDUE());
		simah.setF_PAYFREQUENCY(oldSimahRec.getF_PAYFREQUENCY());
		simah.setF_PAYMENTSTATUS(oldSimahRec.getF_PAYMENTSTATUS());
		simah.setF_PRODUCTLIMIT(oldSimahRec.getF_PRODUCTLIMIT());
		simah.setF_PRODUCTSTATUS(oldSimahRec.getF_PRODUCTSTATUS());
		simah.setF_PRODUCTTYPE(oldSimahRec.getF_PRODUCTTYPE());
		simah.setF_REPAYMENTAMT(oldSimahRec.getF_REPAYMENTAMT());
		simah.setF_SECURITYTYPE(oldSimahRec.getF_SECURITYTYPE());

		simah.setF_MSGID(oldSimahRec.getBoID());

		factory.create(IBOCE_SIMAHLASTMSGHIST.BONAME, simah);

	}

	private RegularFileData setGuarantorsData(RegularFileData data, GuarantorDetails g) {
		data.setAddressType(g.getAddressType());
		data.setAddress1Arabic(g.getAddress1Arabic());
		data.setApplicantType(g.getApplicantType());
		data.setContacttype(g.getContacttype());
		data.setContactNumber(g.getContactNumber());
		data.setContactcountrycode(g.getContactcountrycode());
		return data;
	}

}
