package com.ce.simah.regular;

import java.util.ArrayList;

import com.ce.simah.util.IFileHeader;


public class RegularFileHeader implements IFileHeader {
	
	private ArrayList headers = new ArrayList();
	
	
	public RegularFileHeader() {
		headers.add("Credit Instrument Number");
		headers.add("Issue Date");
		headers.add("Product Type");
		headers.add("Product Limit / Original Amount");
		headers.add("Salary Assignment Flag");
		headers.add("Product Expiry Date");
		headers.add("Product Status");
		headers.add("Instalment Amount");
		headers.add("Payment Frequency");
		headers.add("Tenure");
		headers.add("Security Type.");
		headers.add("Number of credit instrument holders");
		headers.add("Cycle ID");
		headers.add("Last Payment Date");
		headers.add("Last Amount Paid");
		headers.add("Payment Status");
		headers.add("Outstanding balance.");
		headers.add("Past Due balance.");
		headers.add("As of Date");
		headers.add("Next payment Date");
		headers.add("ID type");
		headers.add("Consumer ID");
		headers.add("Marital status");
		headers.add("Nationality code");
		headers.add("Family Name (Arabic)");
		headers.add("First Name (Arabic)");
		headers.add("Second Name (Arabic)");
		headers.add("Third Name (Arabic)");
		headers.add("Unformatted Name ?Full Name? (Arabic)");
		headers.add("Family Name (English)");
		headers.add("First Name (English)");
		headers.add("Second Name (English)");
		headers.add("Third Name (English)");
		headers.add("Unformatted Name ?Full Name? (English)");
		headers.add("Date Of Birth");
		headers.add("Gender");
		headers.add("Applicant Type");
		headers.add("email address");
		headers.add("Address Type");
		headers.add("Address 1 Arabic");
		headers.add("Address 2 Arabic");
		headers.add("Address Field 1 (English)");
		headers.add("Address Field 2 (English)");
		headers.add("P.O Box");
		headers.add("Postal code");
		headers.add("City (English)");
		headers.add("City (Arabic)");
		headers.add("Country Code");
		headers.add("Contact type");
		headers.add("contact country code");
		headers.add("Contact Area Code");
		headers.add("contact Number");
		headers.add("Contact extension");
		headers.add("Employer Type");
		headers.add("Employer Self");
		headers.add("Employer Name (Arabic)");
		headers.add("Employer Name (English)");
		headers.add("economic sector");
		headers.add("business type");
		headers.add("Unformatted Employer Address");
		headers.add("Employer address 1 (Arabic)");
		headers.add("Employer address 2 (Arabic)");
		headers.add("Employer address 1 (English)");
		headers.add("Employer address 2 (English)");
		headers.add("PO Box");
		headers.add("Postal Code");
		headers.add("City in English");
		headers.add("City in Arabic");
		headers.add("Country Code");
		headers.add("Certificate of Registration");
		headers.add("Occupation (Arabic)");
		headers.add("occupation (English)");
		headers.add("Date of employment");
		headers.add("length of service");
		headers.add("contract expiry date");
		headers.add("Monthly Basic Salary/Income");
		headers.add("Total Monthly Salary/Income");
		headers.add("col78");
		headers.add("col79");

	}


	/**
	 * @return the headers
	 */
	public ArrayList getHeaders() {
		return headers;
	}
	

}
