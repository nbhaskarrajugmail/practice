package com.ce.simah.regular;

import java.util.ArrayList;
import java.util.HashMap;

import com.ce.simah.util.IFileData;

public class RegularFileData implements IFileData {

	private String creditInstrumentNumber = "";
	private String issueDate = "";
	private String productType = "";
	private String productLimitOriginalAmount = "";
	private String salaryAssignmentFlag = "";
	private String productExpiryDate = "";
	private String productStatus = "";
	private String instalmentAmount = "";
	private String paymentFrequency = "";
	private String tenure = "";
	private String securityType = "";
	private String numberofcreditinstrumentholders = "";
	private String cycleID = "";
	private String lastPaymentDate = "";
	private String lastAmountPaid = "";
	private String paymentStatus = "";
	private String outstandingbalance = "";
	private String pastDuebalance = "";
	private String asofDate = "";
	private String nextpaymentDate = "";
	private String iDtype = "";
	private String consumerID = "";
	private String maritalstatus = "";
	private String nationalitycode = "";
	private String familyNameArabic = "";
	private String firstNameArabic = "";
	private String secondNameArabic = "";
	private String thirdNameArabic = "";
	private String unformattedNameFullNameArabic = "";
	private String familyNameEnglish = "";
	private String firstNameEnglish = "";
	private String secondNameEnglish = "";
	private String thirdNameEnglish = "";
	private String unformattedNameFullNameEnglish = "";
	private String dateOfBirth = "";
	private String gender = "";
	private String applicantType = "";
	private String emailaddress = "";
	private String addressType = "";
	private String address1Arabic = "";
	private String address2Arabic = "";
	private String addressField1English = "";
	private String addressField2English = "";
	private String pOBox = "";
	private String postalcode = "";
	private String cityEnglish = "";
	private String cityArabic = "";
	private String countryCode = "";
	private String contacttype = "";
	private String contactcountrycode = "";
	private String contactAreaCode = "";
	private String contactNumber = "";
	private String contactextension = "";
	private String employerType = "";
	private String employerSelf = "";
	private String employerNameArabic = "";
	private String employerNameEnglish = "";
	private String economicsector = "";
	private String businesstype = "";
	private String unformattedEmployerAddress = "";
	private String employeraddress1Arabic = "";
	private String employeraddress2Arabic = "";
	private String employeraddress1English = "";
	private String employeraddress2English = "";
	private String pOBox_B = "";
	private String postalCode = "";
	private String cityinEnglish = "";
	private String cityinArabic = "";
	private String countryCode_B = "";
	private String certificateofRegistration = "";
	private String occupationArabic = "";
	private String occupationEnglish = "";
	private String dateofemployment = "";
	private String lengthofservice = "";
	private String contractexpirydate = "";
	private String monthlyBasicSalaryIncome = "";
	private String totalMonthlySalaryIncome = "";
	private String col78 = "";
	private String col79 = "";

	private String newOrExisting = "";
	private String idPkey = "";
	private String simahaccount = "";
	private ArrayList<GuarantorDetails> guarantors = new ArrayList<GuarantorDetails>();

	public RegularFileData() {

	}

	public HashMap getDataMap() {
		HashMap map = new HashMap();
		map.put(0, creditInstrumentNumber);
		map.put(1, issueDate);
		map.put(2, productType);
		map.put(3, productLimitOriginalAmount);
		map.put(4, salaryAssignmentFlag);
		map.put(5, productExpiryDate);
		map.put(6, productStatus);
		map.put(7, instalmentAmount);
		map.put(8, paymentFrequency);
		map.put(9, tenure);
		map.put(10, securityType);
		map.put(11, numberofcreditinstrumentholders);
		map.put(12, cycleID);
		map.put(13, lastPaymentDate);
		map.put(14, lastAmountPaid);
		map.put(15, paymentStatus);
		map.put(16, outstandingbalance);
		map.put(17, pastDuebalance);
		map.put(18, asofDate);
		map.put(19, nextpaymentDate);
		map.put(20, iDtype);
		map.put(21, consumerID);
		map.put(22, maritalstatus);
		map.put(23, nationalitycode);
		map.put(24, familyNameArabic);
		map.put(25, firstNameArabic);
		map.put(26, secondNameArabic);
		map.put(27, thirdNameArabic);
		map.put(28, unformattedNameFullNameArabic);
		map.put(29, familyNameEnglish);
		map.put(30, firstNameEnglish);
		map.put(31, secondNameEnglish);
		map.put(32, thirdNameEnglish);
		map.put(33, unformattedNameFullNameEnglish);
		map.put(34, dateOfBirth);
		map.put(35, gender);
		map.put(36, applicantType);
		map.put(37, emailaddress);
		map.put(38, addressType);
		map.put(39, address1Arabic);
		map.put(40, address2Arabic);
		map.put(41, addressField1English);
		map.put(42, addressField2English);
		map.put(43, pOBox);
		map.put(44, postalcode);
		map.put(45, cityEnglish);
		map.put(46, cityArabic);
		map.put(47, countryCode);
		map.put(48, contacttype);
		map.put(49, contactcountrycode);
		map.put(50, contactAreaCode);
		map.put(51, contactNumber);
		map.put(52, contactextension);
		map.put(53, employerType);
		map.put(54, employerSelf);
		map.put(55, employerNameArabic);
		map.put(56, employerNameEnglish);
		map.put(57, economicsector);
		map.put(58, businesstype);
		map.put(59, unformattedEmployerAddress);
		map.put(60, employeraddress1Arabic);
		map.put(61, employeraddress2Arabic);
		map.put(62, employeraddress1English);
		map.put(63, employeraddress2English);
		map.put(64, pOBox_B);
		map.put(65, postalCode);
		map.put(66, cityinEnglish);
		map.put(67, cityinArabic);
		map.put(68, countryCode_B);
		map.put(69, certificateofRegistration);
		map.put(70, occupationArabic);
		map.put(71, occupationEnglish);
		map.put(72, dateofemployment);
		map.put(73, lengthofservice);
		map.put(74, contractexpirydate);
		map.put(75, monthlyBasicSalaryIncome);
		map.put(76, totalMonthlySalaryIncome);
		map.put(77, col78);
		map.put(78, col79);

		return map;
	}

	/** @return the creditInstrumentNumber */
	public String getCreditInstrumentNumber() {
		return creditInstrumentNumber;
	}

	/** @param creditInstrumentNumber
	 *            the creditInstrumentNumber to set */
	public void setCreditInstrumentNumber(String creditInstrumentNumber) {
		this.creditInstrumentNumber = creditInstrumentNumber;
	}

	/** @return the issueDate */
	public String getIssueDate() {
		return issueDate;
	}

	/** @param issueDate
	 *            the issueDate to set */
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	/** @return the productType */
	public String getProductType() {
		return productType;
	}

	/** @param productType
	 *            the productType to set */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/** @return the productLimitOriginalAmount */
	public String getProductLimitOriginalAmount() {
		return productLimitOriginalAmount;
	}

	/** @param productLimitOriginalAmount
	 *            the productLimitOriginalAmount to set */
	public void setProductLimitOriginalAmount(String productLimitOriginalAmount) {
		this.productLimitOriginalAmount = productLimitOriginalAmount;
	}

	/** @return the salaryAssignmentFlag */
	public String getSalaryAssignmentFlag() {
		return salaryAssignmentFlag;
	}

	/** @param salaryAssignmentFlag
	 *            the salaryAssignmentFlag to set */
	public void setSalaryAssignmentFlag(String salaryAssignmentFlag) {
		this.salaryAssignmentFlag = salaryAssignmentFlag;
	}

	/** @return the productExpiryDate */
	public String getProductExpiryDate() {
		return productExpiryDate;
	}

	/** @param productExpiryDate
	 *            the productExpiryDate to set */
	public void setProductExpiryDate(String productExpiryDate) {
		this.productExpiryDate = productExpiryDate;
	}

	/** @return the productStatus */
	public String getProductStatus() {
		return productStatus;
	}

	/** @param productStatus
	 *            the productStatus to set */
	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}

	/** @return the instalmentAmount */
	public String getInstalmentAmount() {
		return instalmentAmount;
	}

	/** @param instalmentAmount
	 *            the instalmentAmount to set */
	public void setInstalmentAmount(String instalmentAmount) {
		this.instalmentAmount = instalmentAmount;
	}

	/** @return the paymentFrequency */
	public String getPaymentFrequency() {
		return paymentFrequency;
	}

	/** @param paymentFrequency
	 *            the paymentFrequency to set */
	public void setPaymentFrequency(String paymentFrequency) {
		this.paymentFrequency = paymentFrequency;
	}

	/** @return the tenure */
	public String getTenure() {
		return tenure;
	}

	/** @param tenure
	 *            the tenure to set */
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	/** @return the securityType */
	public String getSecurityType() {
		return securityType;
	}

	/** @param securityType
	 *            the securityType to set */
	public void setSecurityType(String securityType) {
		this.securityType = securityType;
	}

	/** @return the numberofcreditinstrumentholders */
	public String getNumberofcreditinstrumentholders() {
		return numberofcreditinstrumentholders;
	}

	/** @param numberofcreditinstrumentholders
	 *            the numberofcreditinstrumentholders to set */
	public void setNumberofcreditinstrumentholders(String numberofcreditinstrumentholders) {
		this.numberofcreditinstrumentholders = numberofcreditinstrumentholders;
	}

	/** @return the cycleID */
	public String getCycleID() {
		return cycleID;
	}

	/** @param cycleID
	 *            the cycleID to set */
	public void setCycleID(String cycleID) {
		this.cycleID = cycleID;
	}

	/** @return the lastPaymentDate */
	public String getLastPaymentDate() {
		return lastPaymentDate;
	}

	/** @param lastPaymentDate
	 *            the lastPaymentDate to set */
	public void setLastPaymentDate(String lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	/** @return the lastAmountPaid */
	public String getLastAmountPaid() {
		return lastAmountPaid;
	}

	/** @param lastAmountPaid
	 *            the lastAmountPaid to set */
	public void setLastAmountPaid(String lastAmountPaid) {
		this.lastAmountPaid = lastAmountPaid;
	}

	/** @return the paymentStatus */
	public String getPaymentStatus() {
		return paymentStatus;
	}

	/** @param paymentStatus
	 *            the paymentStatus to set */
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	/** @return the outstandingbalance */
	public String getOutstandingbalance() {
		return outstandingbalance;
	}

	/** @param outstandingbalance
	 *            the outstandingbalance to set */
	public void setOutstandingbalance(String outstandingbalance) {
		this.outstandingbalance = outstandingbalance;
	}

	/** @return the pastDuebalance */
	public String getPastDuebalance() {
		return pastDuebalance;
	}

	/** @param pastDuebalance
	 *            the pastDuebalance to set */
	public void setPastDuebalance(String pastDuebalance) {
		this.pastDuebalance = pastDuebalance;
	}

	/** @return the asofDate */
	public String getAsofDate() {
		return asofDate;
	}

	/** @param asofDate
	 *            the asofDate to set */
	public void setAsofDate(String asofDate) {
		this.asofDate = asofDate;
	}

	/** @return the nextpaymentDate */
	public String getNextpaymentDate() {
		return nextpaymentDate;
	}

	/** @param nextpaymentDate
	 *            the nextpaymentDate to set */
	public void setNextpaymentDate(String nextpaymentDate) {
		this.nextpaymentDate = nextpaymentDate;
	}

	/** @return the iDtype */
	public String getiDtype() {
		return iDtype;
	}

	/** @param iDtype
	 *            the iDtype to set */
	public void setiDtype(String iDtype) {
		this.iDtype = iDtype;
	}

	/** @return the consumerID */
	public String getConsumerID() {
		return consumerID;
	}

	/** @param consumerID
	 *            the consumerID to set */
	public void setConsumerID(String consumerID) {
		this.consumerID = consumerID;
	}

	/** @return the maritalstatus */
	public String getMaritalstatus() {
		return maritalstatus;
	}

	/** @param maritalstatus
	 *            the maritalstatus to set */
	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}

	/** @return the nationalitycode */
	public String getNationalitycode() {
		return nationalitycode;
	}

	/** @param nationalitycode
	 *            the nationalitycode to set */
	public void setNationalitycode(String nationalitycode) {
		this.nationalitycode = nationalitycode;
	}

	/** @return the familyNameArabic */
	public String getFamilyNameArabic() {
		return familyNameArabic;
	}

	/** @param familyNameArabic
	 *            the familyNameArabic to set */
	public void setFamilyNameArabic(String familyNameArabic) {
		this.familyNameArabic = familyNameArabic;
	}

	/** @return the firstNameArabic */
	public String getFirstNameArabic() {
		return firstNameArabic;
	}

	/** @param firstNameArabic
	 *            the firstNameArabic to set */
	public void setFirstNameArabic(String firstNameArabic) {
		this.firstNameArabic = firstNameArabic;
	}

	/** @return the secondNameArabic */
	public String getSecondNameArabic() {
		return secondNameArabic;
	}

	/** @param secondNameArabic
	 *            the secondNameArabic to set */
	public void setSecondNameArabic(String secondNameArabic) {
		this.secondNameArabic = secondNameArabic;
	}

	/** @return the thirdNameArabic */
	public String getThirdNameArabic() {
		return thirdNameArabic;
	}

	/** @param thirdNameArabic
	 *            the thirdNameArabic to set */
	public void setThirdNameArabic(String thirdNameArabic) {
		this.thirdNameArabic = thirdNameArabic;
	}

	/** @return the unformattedNameFullNameArabic */
	public String getUnformattedNameFullNameArabic() {
		return unformattedNameFullNameArabic;
	}

	/** @param unformattedNameFullNameArabic
	 *            the unformattedNameFullNameArabic to set */
	public void setUnformattedNameFullNameArabic(String unformattedNameFullNameArabic) {
		this.unformattedNameFullNameArabic = unformattedNameFullNameArabic;
	}

	/** @return the familyNameEnglish */
	public String getFamilyNameEnglish() {
		return familyNameEnglish;
	}

	/** @param familyNameEnglish
	 *            the familyNameEnglish to set */
	public void setFamilyNameEnglish(String familyNameEnglish) {
		this.familyNameEnglish = familyNameEnglish;
	}

	/** @return the firstNameEnglish */
	public String getFirstNameEnglish() {
		return firstNameEnglish;
	}

	/** @param firstNameEnglish
	 *            the firstNameEnglish to set */
	public void setFirstNameEnglish(String firstNameEnglish) {
		this.firstNameEnglish = firstNameEnglish;
	}

	/** @return the secondNameEnglish */
	public String getSecondNameEnglish() {
		return secondNameEnglish;
	}

	/** @param secondNameEnglish
	 *            the secondNameEnglish to set */
	public void setSecondNameEnglish(String secondNameEnglish) {
		this.secondNameEnglish = secondNameEnglish;
	}

	/** @return the thirdNameEnglish */
	public String getThirdNameEnglish() {
		return thirdNameEnglish;
	}

	/** @param thirdNameEnglish
	 *            the thirdNameEnglish to set */
	public void setThirdNameEnglish(String thirdNameEnglish) {
		this.thirdNameEnglish = thirdNameEnglish;
	}

	/** @return the unformattedNameFullNameEnglish */
	public String getUnformattedNameFullNameEnglish() {
		return unformattedNameFullNameEnglish;
	}

	/** @param unformattedNameFullNameEnglish
	 *            the unformattedNameFullNameEnglish to set */
	public void setUnformattedNameFullNameEnglish(String unformattedNameFullNameEnglish) {
		this.unformattedNameFullNameEnglish = unformattedNameFullNameEnglish;
	}

	/** @return the dateOfBirth */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/** @param dateOfBirth
	 *            the dateOfBirth to set */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/** @return the gender */
	public String getGender() {
		return gender;
	}

	/** @param gender
	 *            the gender to set */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/** @return the applicantType */
	public String getApplicantType() {
		return applicantType;
	}

	/** @param applicantType
	 *            the applicantType to set */
	public void setApplicantType(String applicantType) {
		this.applicantType = applicantType;
	}

	/** @return the emailaddress */
	public String getEmailaddress() {
		return emailaddress;
	}

	/** @param emailaddress
	 *            the emailaddress to set */
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	/** @return the addressType */
	public String getAddressType() {
		return addressType;
	}

	/** @param addressType
	 *            the addressType to set */
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	/** @return the address1Arabic */
	public String getAddress1Arabic() {
		return address1Arabic;
	}

	/** @param address1Arabic
	 *            the address1Arabic to set */
	public void setAddress1Arabic(String address1Arabic) {
		this.address1Arabic = address1Arabic;
	}

	/** @return the address2Arabic */
	public String getAddress2Arabic() {
		return address2Arabic;
	}

	/** @param address2Arabic
	 *            the address2Arabic to set */
	public void setAddress2Arabic(String address2Arabic) {
		this.address2Arabic = address2Arabic;
	}

	/** @return the addressField1English */
	public String getAddressField1English() {
		return addressField1English;
	}

	/** @param addressField1English
	 *            the addressField1English to set */
	public void setAddressField1English(String addressField1English) {
		this.addressField1English = addressField1English;
	}

	/** @return the addressField2English */
	public String getAddressField2English() {
		return addressField2English;
	}

	/** @param addressField2English
	 *            the addressField2English to set */
	public void setAddressField2English(String addressField2English) {
		this.addressField2English = addressField2English;
	}

	/** @return the pOBox */
	public String getpOBox() {
		return pOBox;
	}

	/** @param pOBox
	 *            the pOBox to set */
	public void setpOBox(String pOBox) {
		this.pOBox = pOBox;
	}

	/** @return the postalcode */
	public String getPostalcode() {
		return postalcode;
	}

	/** @param postalcode
	 *            the postalcode to set */
	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}

	/** @return the cityEnglish */
	public String getCityEnglish() {
		return cityEnglish;
	}

	/** @param cityEnglish
	 *            the cityEnglish to set */
	public void setCityEnglish(String cityEnglish) {
		this.cityEnglish = cityEnglish;
	}

	/** @return the cityArabic */
	public String getCityArabic() {
		return cityArabic;
	}

	/** @param cityArabic
	 *            the cityArabic to set */
	public void setCityArabic(String cityArabic) {
		this.cityArabic = cityArabic;
	}

	/** @return the countryCode */
	public String getCountryCode() {
		return countryCode;
	}

	/** @param countryCode
	 *            the countryCode to set */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/** @return the contacttype */
	public String getContacttype() {
		return contacttype;
	}

	/** @param contacttype
	 *            the contacttype to set */
	public void setContacttype(String contacttype) {
		this.contacttype = contacttype;
	}

	/** @return the contactcountrycode */
	public String getContactcountrycode() {
		return contactcountrycode;
	}

	/** @param contactcountrycode
	 *            the contactcountrycode to set */
	public void setContactcountrycode(String contactcountrycode) {
		this.contactcountrycode = contactcountrycode;
	}

	/** @return the contactAreaCode */
	public String getContactAreaCode() {
		return contactAreaCode;
	}

	/** @param contactAreaCode
	 *            the contactAreaCode to set */
	public void setContactAreaCode(String contactAreaCode) {
		this.contactAreaCode = contactAreaCode;
	}

	/** @return the contactNumber */
	public String getContactNumber() {
		return contactNumber;
	}

	/** @param contactNumber
	 *            the contactNumber to set */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/** @return the contactextension */
	public String getContactextension() {
		return contactextension;
	}

	/** @param contactextension
	 *            the contactextension to set */
	public void setContactextension(String contactextension) {
		this.contactextension = contactextension;
	}

	/** @return the employerType */
	public String getEmployerType() {
		return employerType;
	}

	/** @param employerType
	 *            the employerType to set */
	public void setEmployerType(String employerType) {
		this.employerType = employerType;
	}

	/** @return the employerSelf */
	public String getEmployerSelf() {
		return employerSelf;
	}

	/** @param employerSelf
	 *            the employerSelf to set */
	public void setEmployerSelf(String employerSelf) {
		this.employerSelf = employerSelf;
	}

	/** @return the employerNameArabic */
	public String getEmployerNameArabic() {
		return employerNameArabic;
	}

	/** @param employerNameArabic
	 *            the employerNameArabic to set */
	public void setEmployerNameArabic(String employerNameArabic) {
		this.employerNameArabic = employerNameArabic;
	}

	/** @return the employerNameEnglish */
	public String getEmployerNameEnglish() {
		return employerNameEnglish;
	}

	/** @param employerNameEnglish
	 *            the employerNameEnglish to set */
	public void setEmployerNameEnglish(String employerNameEnglish) {
		this.employerNameEnglish = employerNameEnglish;
	}

	/** @return the economicsector */
	public String getEconomicsector() {
		return economicsector;
	}

	/** @param economicsector
	 *            the economicsector to set */
	public void setEconomicsector(String economicsector) {
		this.economicsector = economicsector;
	}

	/** @return the businesstype */
	public String getBusinesstype() {
		return businesstype;
	}

	/** @param businesstype
	 *            the businesstype to set */
	public void setBusinesstype(String businesstype) {
		this.businesstype = businesstype;
	}

	/** @return the unformattedEmployerAddress */
	public String getUnformattedEmployerAddress() {
		return unformattedEmployerAddress;
	}

	/** @param unformattedEmployerAddress
	 *            the unformattedEmployerAddress to set */
	public void setUnformattedEmployerAddress(String unformattedEmployerAddress) {
		this.unformattedEmployerAddress = unformattedEmployerAddress;
	}

	/** @return the employeraddress1Arabic */
	public String getEmployeraddress1Arabic() {
		return employeraddress1Arabic;
	}

	/** @param employeraddress1Arabic
	 *            the employeraddress1Arabic to set */
	public void setEmployeraddress1Arabic(String employeraddress1Arabic) {
		this.employeraddress1Arabic = employeraddress1Arabic;
	}

	/** @return the employeraddress2Arabic */
	public String getEmployeraddress2Arabic() {
		return employeraddress2Arabic;
	}

	/** @param employeraddress2Arabic
	 *            the employeraddress2Arabic to set */
	public void setEmployeraddress2Arabic(String employeraddress2Arabic) {
		this.employeraddress2Arabic = employeraddress2Arabic;
	}

	/** @return the employeraddress1English */
	public String getEmployeraddress1English() {
		return employeraddress1English;
	}

	/** @param employeraddress1English
	 *            the employeraddress1English to set */
	public void setEmployeraddress1English(String employeraddress1English) {
		this.employeraddress1English = employeraddress1English;
	}

	/** @return the employeraddress2English */
	public String getEmployeraddress2English() {
		return employeraddress2English;
	}

	/** @param employeraddress2English
	 *            the employeraddress2English to set */
	public void setEmployeraddress2English(String employeraddress2English) {
		this.employeraddress2English = employeraddress2English;
	}

	/** @return the pOBox_B */
	public String getpOBox_B() {
		return pOBox_B;
	}

	/** @param pOBox_B
	 *            the pOBox_B to set */
	public void setpOBox_B(String pOBox_B) {
		this.pOBox_B = pOBox_B;
	}

	/** @return the postalCode */
	public String getPostalCode() {
		return postalCode;
	}

	/** @param postalCode
	 *            the postalCode to set */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/** @return the cityinEnglish */
	public String getCityinEnglish() {
		return cityinEnglish;
	}

	/** @param cityinEnglish
	 *            the cityinEnglish to set */
	public void setCityinEnglish(String cityinEnglish) {
		this.cityinEnglish = cityinEnglish;
	}

	/** @return the cityinArabic */
	public String getCityinArabic() {
		return cityinArabic;
	}

	/** @param cityinArabic
	 *            the cityinArabic to set */
	public void setCityinArabic(String cityinArabic) {
		this.cityinArabic = cityinArabic;
	}

	/** @return the countryCode_B */
	public String getCountryCode_B() {
		return countryCode_B;
	}

	/** @param countryCode_B
	 *            the countryCode_B to set */
	public void setCountryCode_B(String countryCode_B) {
		this.countryCode_B = countryCode_B;
	}

	/** @return the certificateofRegistration */
	public String getCertificateofRegistration() {
		return certificateofRegistration;
	}

	/** @param certificateofRegistration
	 *            the certificateofRegistration to set */
	public void setCertificateofRegistration(String certificateofRegistration) {
		this.certificateofRegistration = certificateofRegistration;
	}

	/** @return the occupationArabic */
	public String getOccupationArabic() {
		return occupationArabic;
	}

	/** @param occupationArabic
	 *            the occupationArabic to set */
	public void setOccupationArabic(String occupationArabic) {
		this.occupationArabic = occupationArabic;
	}

	/** @return the occupationEnglish */
	public String getOccupationEnglish() {
		return occupationEnglish;
	}

	/** @param occupationEnglish
	 *            the occupationEnglish to set */
	public void setOccupationEnglish(String occupationEnglish) {
		this.occupationEnglish = occupationEnglish;
	}

	/** @return the dateofemployment */
	public String getDateofemployment() {
		return dateofemployment;
	}

	/** @param dateofemployment
	 *            the dateofemployment to set */
	public void setDateofemployment(String dateofemployment) {
		this.dateofemployment = dateofemployment;
	}

	/** @return the lengthofservice */
	public String getLengthofservice() {
		return lengthofservice;
	}

	/** @param lengthofservice
	 *            the lengthofservice to set */
	public void setLengthofservice(String lengthofservice) {
		this.lengthofservice = lengthofservice;
	}

	/** @return the contractexpirydate */
	public String getContractexpirydate() {
		return contractexpirydate;
	}

	/** @param contractexpirydate
	 *            the contractexpirydate to set */
	public void setContractexpirydate(String contractexpirydate) {
		this.contractexpirydate = contractexpirydate;
	}

	/** @return the monthlyBasicSalaryIncome */
	public String getMonthlyBasicSalaryIncome() {
		return monthlyBasicSalaryIncome;
	}

	/** @param monthlyBasicSalaryIncome
	 *            the monthlyBasicSalaryIncome to set */
	public void setMonthlyBasicSalaryIncome(String monthlyBasicSalaryIncome) {
		this.monthlyBasicSalaryIncome = monthlyBasicSalaryIncome;
	}

	/** @return the totalMonthlySalaryIncome */
	public String getTotalMonthlySalaryIncome() {
		return totalMonthlySalaryIncome;
	}

	/** @param totalMonthlySalaryIncome
	 *            the totalMonthlySalaryIncome to set */
	public void setTotalMonthlySalaryIncome(String totalMonthlySalaryIncome) {
		this.totalMonthlySalaryIncome = totalMonthlySalaryIncome;
	}

	/** @return the col78 */
	public String getCol78() {
		return col78;
	}

	/** @param col78
	 *            the col78 to set */
	public void setCol78(String col78) {
		this.col78 = col78;
	}

	/** @return the col79 */
	public String getCol79() {
		return col79;
	}

	/** @param col79
	 *            the col79 to set */
	public void setCol79(String col79) {
		this.col79 = col79;
	}

	/** @return the newOrExisting */
	public String getNewOrExisting() {
		return newOrExisting;
	}

	/** @param newOrExisting
	 *            the newOrExisting to set */
	public void setNewOrExisting(String newOrExisting) {
		this.newOrExisting = newOrExisting;
	}

	/** @return the idPkey */
	public String getIdPkey() {
		return idPkey;
	}

	/** @param idPkey
	 *            the idPkey to set */
	public void setIdPkey(String idPkey) {
		this.idPkey = idPkey;
	}

	/**
	 * @return the guarantors
	 */
	public ArrayList<GuarantorDetails> getGuarantors() {
		return guarantors;
	}

	/**
	 * @param guarantors the guarantors to set
	 */
	public void setGuarantors(ArrayList<GuarantorDetails> guarantors) {
		this.guarantors = guarantors;
	}
	
	public String getsimahaccount() {
		return simahaccount;
	}
	
	public void setsimahaccount(String simahaccount) {
		this.simahaccount = simahaccount;
	}

}
