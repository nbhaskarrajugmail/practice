/**
 * 
 */
package com.ce.simah;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.simah.regular.ProcessRegularAccounts;
import com.ce.simah.regular.RegularFileGenerator;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHLASTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHREGULARTAG;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.core.SimplePersistentObject;
import com.trapedza.bankfusion.core.SystemInformationManager;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_SimahRegular_PPExtract;

/** @author Subhajit */
public class PersonalPartyRegular extends AbstractCE_PTY_SimahRegular_PPExtract {
	
	// TODO : this file is not used anymore, need to be deleted soon

	private transient final static Log logger = LogFactory.getLog(PersonalPartyRegular.class.getName());

	private static String INSERT_QUERY = "INSERT INTO CUSTOMEXTN.CETB_SIMAHREGULARTAG "
			+ "(CEROWSEQIDPK,CEACCOUNTID,CEEXISTSORNEW,VERSIONNUM) SELECT ROW_NUMBER() OVER (ORDER BY CECRINSTRUMENTNO) CEROWSEQIDPK,"
			+ " CECRINSTRUMENTNO, 'E' CEEXISTSORNEW, 0 VERSIONNUM FROM CUSTOMEXTN.CETB_SIMAHLASTMSG WHERE CEPRODUCTSTATUS='A' ";
	private static final String SELECT_MAX_QUERY = "SELECT MAX(" + IBOCE_SIMAHREGULARTAG.ROWSEQID
			+ ") AS TOTAL FROM " + IBOCE_SIMAHREGULARTAG.BONAME;
	private static String LASTCYCLE_DATE_QUERY = "SELECT MAX(" + IBOCE_SIMAHLASTMSG.PROCESSEDDATE
			+ ") AS CYCLEDATE FROM " + IBOCE_SIMAHLASTMSG.BONAME;

	private static final String NEW_ACC_QUERY = " WHERE " + IBOLendingFeature.FIRSTDRAWDOWNDATE
			+ " > ?";

	private IPersistenceObjectsFactory factory;

	private Date lastExecDate = null;

	/**
	 * 
	 */
	public PersonalPartyRegular(BankFusionEnvironment env) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void process(BankFusionEnvironment env) {

		factory = BankFusionThreadLocal.getPersistanceFactory();
		factory.bulkDeleteAll("CE_SIMAHREGULARTAG");
		factory.commitTransaction();
		factory.beginTransaction();
		archiveClosedAccounts();

		try {
			// Write to tag table
			@SuppressWarnings("deprecation")
			Connection con = factory.getJDBCConnection();
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);

			ps.execute();
			this.factory.commitTransaction();
			this.factory.beginTransaction();

			setLastCycleDate();

		} catch (SQLException sqlException) {
			logger.error("processBatch() SQL Exception message:" + sqlException.getLocalizedMessage());
			sqlException.printStackTrace();
		} catch (Exception e) {
			// Should not come here as this is already
			// handled in handler
			logger.error("processBatch() Generic Exception message:");
			e.printStackTrace();
		}
		// Get new Loans
		ArrayList params = new ArrayList();
		params.add(lastExecDate);
		ArrayList list = (ArrayList) factory.findByQuery(IBOLendingFeature.BONAME, NEW_ACC_QUERY,
				params, null, true);
		if (list != null && !list.isEmpty()) {
			int count = maxOfTagTable();
			for (int i = 0; i < list.size(); i++) {
				IBOLendingFeature loanDetails = (IBOLendingFeature) list.get(i);

				if (loanDetails.getF_REDUCINGPRINCIPAL().compareTo(BigDecimal.ZERO) == 0)
					continue;

				count = count + 1;
				IBOCE_SIMAHREGULARTAG newLoan = (IBOCE_SIMAHREGULARTAG) factory
						.getStatelessNewInstance(IBOCE_SIMAHREGULARTAG.BONAME);
				newLoan.setBoID(new Integer(count).toString());
				newLoan.setF_ACCOUNTID(loanDetails.getF_ACCOUNTID());
				newLoan.setF_EXISTSORNEW("N");
				factory.create(IBOCE_SIMAHREGULARTAG.BONAME, newLoan);
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}

		ProcessRegularAccounts processRegular = new ProcessRegularAccounts();
		processRegular.setLastExecDate(lastExecDate);
		processRegular.process(-1,-1);
	}

	private int maxOfTagTable() {
		Integer count = 0;
		ArrayList params1 = new ArrayList();
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(SELECT_MAX_QUERY, null,
				null, true);
		if (null != records && !records.isEmpty()) {
			SimplePersistentObject record = records.get(0);
			count = Integer.parseInt((String) record.getDataMap().get("TOTAL"));
		}
		return count;
	}

	private void setLastCycleDate() {
		ArrayList params1 = new ArrayList();
		List<SimplePersistentObject> records = this.factory.executeGenericQuery(LASTCYCLE_DATE_QUERY,
				null, null, true);
		if (null != records && !records.isEmpty()) {
			SimplePersistentObject record = records.get(0);
			lastExecDate = (Date) record.getDataMap().get("CYCLEDATE");
		}
		if (lastExecDate == null) {
			logger.error("Previous Cycle Data Not found");
			Calendar cal = Calendar.getInstance();
			cal.setTime(SystemInformationManager.getInstance().getBFBusinessDate());
			cal.add(Calendar.DATE, -365);
			lastExecDate = new Date(cal.getTime().getTime());
		}
	}

	private void archiveClosedAccounts() {
		ArrayList params = new ArrayList();
		params.add(SIMAH_LOAN_CLOSED);
		params.add(SIMAH_FILE_REGULAR);
		ArrayList list = (ArrayList) factory.findByQuery(IBOCE_SIMAHLASTMSG.BONAME, CLOSED_QUERY, params,
				null, true);
		if (null != list && !list.isEmpty()) {
			for (int i = 0; i < list.size(); i++) {
				IBOCE_SIMAHLASTMSG simahmsg = (IBOCE_SIMAHLASTMSG)list.get(i);
				new RegularFileGenerator().archiveExistingRecord(simahmsg);
				factory.remove(IBOCE_SIMAHLASTMSG.BONAME, simahmsg);
			}
			factory.commitTransaction();
			factory.beginTransaction();
		}

	}

	private static String CLOSED_QUERY = " WHERE " + IBOCE_SIMAHLASTMSG.PRODUCTSTATUS + " =? AND "
			+ IBOCE_SIMAHLASTMSG.FILETYPE + " =?";
	private static final String SIMAH_LOAN_CLOSED = "C";
	private static final String SIMAH_FILE_REGULAR = "R";
}
