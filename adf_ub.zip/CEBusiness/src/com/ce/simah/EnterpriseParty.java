package com.ce.simah;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ce.adf.CEUtil;
import com.misys.bankfusion.common.GUIDGen;
import com.misys.bankfusion.subsystem.infrastructure.common.impl.SystemInformationManager;
import com.misys.bankfusion.subsystem.persistence.runtime.impl.BankFusionThreadLocal;
import com.trapedza.bankfusion.bo.refimpl.IBOAddress;
import com.trapedza.bankfusion.bo.refimpl.IBOAddressLinks;
import com.trapedza.bankfusion.bo.refimpl.IBOAttributeCollectionFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOBranch;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMAHACCOUNTMAP;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMHAENTMSG;
import com.trapedza.bankfusion.bo.refimpl.IBOCE_SIMHAENTMSGHST;
import com.trapedza.bankfusion.bo.refimpl.IBOCountry;
import com.trapedza.bankfusion.bo.refimpl.IBOCustomer;
import com.trapedza.bankfusion.bo.refimpl.IBOCustomerContacts;
import com.trapedza.bankfusion.bo.refimpl.IBOLN_LEN_LoanSchedule;
import com.trapedza.bankfusion.bo.refimpl.IBOLendingFeature;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanApplicantMap;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanArrears;
import com.trapedza.bankfusion.bo.refimpl.IBOLoanSettlement;
import com.trapedza.bankfusion.bo.refimpl.IBOOrgDetails;
import com.trapedza.bankfusion.persistence.core.IPersistenceObjectsFactory;
import com.trapedza.bankfusion.persistence.services.IPersistenceService;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.servercommon.services.IServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManager;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;
import com.trapedza.bankfusion.steps.refimpl.AbstractCE_PTY_SimahEnterprise_PartyExtract;

public class EnterpriseParty extends AbstractCE_PTY_SimahEnterprise_PartyExtract {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String BLANK = " ";
	private static final String SIMAH_LOAN_CLOSED = "C";
	private static final String SIMAH_LOAN_DEFAULT = "D";
	private static final String SIMAH_LOAN_ACTIVE = "A";
	private static final String SIMAH_LOAN_PREAPPROVED = "p";
	private static String LOANSTATUS_COMPLETED = "2413";
	private static String LOANSTATUS_SETTLED = "2412";
	private static String LOANSTATUS_NORMAL = "2410";
	Log logger = LogFactory.getLog(EnterpriseParty.class);

	@SuppressWarnings("deprecation")
	public EnterpriseParty(BankFusionEnvironment env) {
		super(env);
	}

	private String ENT_CUS_WHERE = " WHERE " + IBOCustomer.CUSTOMERTYPE + " = ?";
	private String ENT_ACC_WHERE = " WHERE " + IBOLoanApplicantMap.CUSTOMERCODE + " = ? ";
	private FileOutputStream file;
	private String versionNum = "0101";
	private String branchCountry = "";
	IServiceManager servicemanager = ServiceManagerFactory.getInstance().getServiceManager();
	IPersistenceService persistenceService = (IPersistenceService) servicemanager
			.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
	IPersistenceObjectsFactory factory = persistenceService.getPrivatePersistenceFactory(true);
	private static final String SETTLED_QUERY = " WHERE " + IBOLoanSettlement.ACCOUNTID + " =?";
	int count;

	public void process(BankFusionEnvironment env) {
		logger.info("Preparing of SIMHA Enterprise Start");
		count = 1;
		List<IBOCustomer> customerList = getEnterPriseCustomer();
		createFile();
		prepareHeader();
		count = prepareData(customerList);
		prepareFooter(count);
		logger.info("Preparing of SIMHA Enterprise End");
	}

	private void createFile() {
		CEUtil ceutil = new CEUtil();
		String filePath = ceutil.getModuleConfigurationValue("CESADADINTERFACE", "SIMHAENTFILELOC");
		if (!(filePath.endsWith("\\") || filePath.endsWith("//"))) {
			filePath = filePath + "//";
		}
		String date = new SimpleDateFormat("yyyyMMddHHmm'.txt'")
				.format(SystemInformationManager.getInstance().getBFBusinessDate());
		filePath = filePath + "SIMHA_Enterprise_" + date;

		try {
			file = new FileOutputStream(new File(filePath));
		} catch (FileNotFoundException fne) {
			fne.printStackTrace();
			file = null;
		}
	}

	private void prepareFooter(int count) {
		count++;
		String footer = "999" + validateInt(count, 10);
		try {
			file.write(footer.getBytes());
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private String validateInt(int count, int length) {
		String value = count + "";
		if (value.length() > length)
			value = value.substring(0, length);
		else {
			String zeroConst = "";
			for (int i = 0; i < length - value.length(); i++) {
				zeroConst = zeroConst + BLANK;
			}
			value = value + zeroConst;
		}
		return value;
	}

	@SuppressWarnings("unchecked")
	private int prepareData(List<IBOCustomer> customerList) {
		ArrayList<String> params = new ArrayList<String>();
		boolean is501;
		for (IBOCustomer cust : customerList) {
			is501 = false;
			try {
				logger.info("Starting Preparation of SIMHA Enterprise Data for Customer -->" + cust.getBoID());
				// Preparing all Types of messages
				params.clear();
				params.add(cust.getBoID());

				List<IBOLoanApplicantMap> accList = BankFusionThreadLocal.getPersistanceFactory()
						.findByQuery(IBOLoanApplicantMap.BONAME, ENT_ACC_WHERE, params, null, true);
				if (accList != null && !accList.isEmpty()) {
					prepareDetailRecord("105", cust);
					prepare105(cust);
					prepareDetailRecord("120", cust);
					prepare120(cust);
					prepareDetailRecord("125", cust);
					prepare125(cust);
					is501 = preare501(cust);

					for (IBOLoanApplicantMap accDtl : accList) {
						params.clear();
						params.add(accDtl.getF_LOANREQUESTCODE());
						List<IBOLendingFeature> loanList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
								IBOLendingFeature.BONAME, "WHERE " + IBOLendingFeature.LOANREFERENCE + " = ?", params,
								null, true);
						if (loanList != null && !loanList.isEmpty()) {
							// prepareDetailRecord("600", cust);
							prepare600(accDtl, cust, is501);
						}
					}
				}
				logger.info("Completed Preparation of SIMHA Enterprise Data for Customer -->" + cust.getBoID());
			} catch (IOException ioe) {
				logger.error("Error in Preparation of SIMHA Enterprise Data for Customer -->" + cust.getBoID());
				ioe.printStackTrace();
			}
		}
		return count;
	}

	private boolean preare501(IBOCustomer cust) {
		// TODO: Place Holder to prepare 501
		return false;
	}

	/**
	 * To get the Simah account number
	 */
	@SuppressWarnings("unchecked")
	private void prepare600(IBOLoanApplicantMap accDtl, IBOCustomer cust, boolean is501) throws IOException {
		String simahAccount = null;
		logger.info("Inside 600 detail record start");
		ArrayList<String> params = new ArrayList<String>();
		params.add(accDtl.getF_LOANREQUESTCODE());
		List<IBOLendingFeature> loanList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(
				IBOLendingFeature.BONAME, "WHERE " + IBOLendingFeature.LOANREFERENCE + " = ?", params, null, true);
		if (loanList != null && !loanList.isEmpty()) {
			IBOLendingFeature loandtls = loanList.get(0);
			String gaurantor = "N";
			StringBuilder builder = new StringBuilder();
			// builder.append(validateLength(loandtls.getF_ACCOUNTID(),25));
			try {
				String simahAccountOpenDate = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
						"SIMAH_ACCOUNT_OPEN_DATE");
				java.util.Date simahDate = new SimpleDateFormat("yyyy-MM-dd").parse(simahAccountOpenDate);
				IBOAttributeCollectionFeature accountDetails = (IBOAttributeCollectionFeature) BankFusionThreadLocal
						.getPersistanceFactory()
						.findByPrimaryKey(IBOAttributeCollectionFeature.BONAME, loandtls.getF_ACCOUNTID(), false);
				Date accountOpenDate = accountDetails.getF_OPENDATE();
				if (accountOpenDate.compareTo(simahDate) < 0) {
					IBOCE_SIMAHACCOUNTMAP acctMapDetails = (IBOCE_SIMAHACCOUNTMAP) BankFusionThreadLocal
							.getPersistanceFactory()
							.findByPrimaryKey(IBOCE_SIMAHACCOUNTMAP.BONAME, accountDetails.getBoID(), true);
					if (!(acctMapDetails == null)) {
						simahAccount = acctMapDetails.getF_SRCACCTNO();
					} else {
						simahAccount = accountDetails.getBoID();
					}
				} else {
					simahAccount = accountDetails.getBoID();
				}
			} catch (Exception e) {
				logger.error("Error in Preparation of SIMHA Enterprise Data for Customer for account Id -->"
						+ loandtls.getF_ACCOUNTID());
				e.printStackTrace();
			}
			if (null != simahAccount)
				builder.append(validateLength(simahAccount, 25));
			if (is501)
				gaurantor = "Y";
			builder.append(gaurantor);
			String date = new SimpleDateFormat("yyyyMMdd").format(loandtls.getF_LOANSTARTDATE());
			// String startDate = new
			// SimpleDateFormat("yyyyMMdd").format(loandtls.getF_LOANSTARTDATE());

			builder.append("OB6").append(date);

			// TODO:need to append close date
			// BigDecimal amtPaid =
			// loandtls.getF_ORIGINALPRINCIPAL().subtract(loandtls.getF_REDUCINGPRINCIPAL());
			// builder.append(validateLength(amtPaid.toString(), 18));
			// String closeDate = new
			// SimpleDateFormat("yyyyMMdd").format(loandtls.getF_FINALMATURITYDATE());
			BigDecimal installmentAmt = getInstallmentAmount(loandtls.getF_ACCOUNTID());
			int repaymentPeriod = getRepaymentPeriod(loandtls);
			int arrearDays = 0;
			List<IBOLoanArrears> arrearsList = BankFusionThreadLocal.getPersistanceFactory()
					.findByQuery(IBOLoanArrears.BONAME, "WHERE " + IBOLoanArrears.ACCOUNTID + "=?", params, null, true);
			if (arrearsList != null && !arrearsList.isEmpty()) {
				IBOLoanArrears arrearObj = arrearsList.get(0);
				arrearDays = arrearObj.getF_DAYSPASTDUE();
			}

			HashMap<String, Object> status = getPaymentStatus(arrearDays);
			String securityType = "OT";
			String paymentStatus = "";
			String productStatus = "";
			String closeDate = "0       ";
			String CreditBalanceIndicator = " ";
			if (status.get("PaymentStatus") != null)
				paymentStatus = status.get("PaymentStatus").toString();
			if (status.get("ProductStatus") != null) {
				productStatus = status.get("ProductStatus").toString();
				// if(productStatus.equalsIgnoreCase(SIMAH_LOAN_CLOSED)){
				// closeDate = new
				// SimpleDateFormat("yyyyMMdd").format(loandtls.getF_FINALMATURITYDATE());
				// }
				if (loandtls.getF_LOANSTATUS().equals(LOANSTATUS_COMPLETED)
						|| loandtls.getF_LOANSTATUS().equals(LOANSTATUS_SETTLED)) {
					productStatus = SIMAH_LOAN_CLOSED;
				}
				if (loandtls.getF_REDUCINGPRINCIPAL().equals(BigDecimal.ZERO)
						&& loandtls.getF_LOANSTATUS().equals(LOANSTATUS_NORMAL)) {
					productStatus = SIMAH_LOAN_PREAPPROVED;
				}
				if (loandtls.getF_LOANSTATUS().equals(LOANSTATUS_COMPLETED)) {
					closeDate = new SimpleDateFormat("yyyyMMdd").format(loandtls.getF_FINALMATURITYDATE());
				}
				if (loandtls.getF_LOANSTATUS().equals(LOANSTATUS_SETTLED)) {
					@SuppressWarnings("rawtypes")
					ArrayList params1 = new ArrayList<>();
					params1.add(loandtls.getF_ACCOUNTID());
					IBOLoanSettlement loanSettle = (IBOLoanSettlement) factory
							.findFirstByQuery(IBOLoanSettlement.BONAME, SETTLED_QUERY, params1, true);
					closeDate = new SimpleDateFormat("yyyyMMdd").format(loanSettle.getF_SETTLEMENTDATE());
				}
				if (productStatus.equalsIgnoreCase(SIMAH_LOAN_DEFAULT)) {
					closeDate = new SimpleDateFormat("yyyyMMdd")
							.format(SystemInformationManager.getInstance().getBFBusinessDate());
				}
			}

			IBOCE_SIMHAENTMSG entMsgdetail = (IBOCE_SIMHAENTMSG) factory.findByPrimaryKey(IBOCE_SIMHAENTMSG.BONAME,
					loandtls.getF_ACCOUNTID(), true);
			if (entMsgdetail == null || entMsgdetail.getF_PRODUCTSTATUS() != SIMAH_LOAN_CLOSED) {

				prepareDetailRecord("600", cust);
				builder.append(closeDate).append(validateLenght(installmentAmt, 16))
						.append(validateInt(repaymentPeriod, 3));
				builder.append(validateLenght(loandtls.getF_REDUCINGPRINCIPAL(), 16)).append(CreditBalanceIndicator)
						.append(paymentStatus);
				builder.append(validateLength("", 1)).append(validateLength("", 16)).append(validateLength("", 16))
						.append(validateLength("", 1)).append(validateLength("", 1)).append(validateLength("", 16));
				builder.append(validateLength("", 1)).append(validateLength("", 1)).append(validateLength("", 8))
						.append(validateLength("", 16)).append(validateLength("", 1)).append(validateLength("", 25));
				builder.append(validateLength(securityType, 2)).append(validateLength("", 16))
						.append(validateLength("", 8)).append(validateLength("", 8)).append(validateLength("", 8));
				builder.append(productStatus).append(validateLength("", 1));
				builder.append("\n");
				file.write(builder.toString().getBytes());
				count++;
				logger.info("Count in 600:" + count);
			}
			persist600Data(loandtls.getF_ACCOUNTID(), gaurantor, loandtls.getF_LOANSTARTDATE(),
					loandtls.getF_FINALMATURITYDATE(), installmentAmt, repaymentPeriod,
					loandtls.getF_REDUCINGPRINCIPAL(), paymentStatus, securityType, productStatus);
		}
		logger.info("600 detail record start");

	}

	private String validateLenght(BigDecimal installmentAmt, int length) {
		installmentAmt.setScale(0, BigDecimal.ROUND_DOWN);
		String value = installmentAmt.toString();
		if (value.length() > length)
			value = value.substring(0, length);
		else {
			String zeroConst = "";
			for (int i = 0; i < length - value.length(); i++) {
				zeroConst = zeroConst + BLANK;
			}
			value = value + zeroConst;
		}
		return value;
	}

	private void persist600Data(String ACCOUNTID, String gaurantor, Date LOANSTARTDATE, Date closeDate,
			BigDecimal installmentAmt, int repaymentPeriod, BigDecimal REDUCINGPRINCIPAL, String PAYMENTSTATUS,
			String securityType, String PRODUCTSTATUS) {
		IServiceManager servicemanager = ServiceManagerFactory.getInstance().getServiceManager();
		IPersistenceService persistenceService = (IPersistenceService) servicemanager
				.getServiceForName(ServiceManager.PERSISTENCE_SERVICE);
		IPersistenceObjectsFactory factory = persistenceService.getPrivatePersistenceFactory(true);
		factory.beginTransaction();
		IBOCE_SIMHAENTMSG entMsg = (IBOCE_SIMHAENTMSG) factory.findByPrimaryKey(IBOCE_SIMHAENTMSG.BONAME, ACCOUNTID,
				true);
		if (entMsg != null) {
			persistHistory(entMsg, factory);
			entMsg.setF_closeDate(closeDate);
			entMsg.setF_GAURANTOR(gaurantor);
			entMsg.setF_installmentAmt(installmentAmt);
			entMsg.setF_LOANSTARTDATE(LOANSTARTDATE);
			entMsg.setF_PAYMENTSTATUS(PAYMENTSTATUS);
			entMsg.setF_PRODUCTSTATUS(PRODUCTSTATUS);
			entMsg.setF_REDUCINGPRINCIPAL(REDUCINGPRINCIPAL);
			entMsg.setF_repaymentPeriod(repaymentPeriod);
			entMsg.setF_securityType(securityType);
		} else {
			entMsg = (IBOCE_SIMHAENTMSG) factory.getStatelessNewInstance(IBOCE_SIMHAENTMSG.BONAME);
			entMsg.setBoID(ACCOUNTID);
			entMsg.setF_closeDate(closeDate);
			entMsg.setF_GAURANTOR(gaurantor);
			entMsg.setF_installmentAmt(installmentAmt);
			entMsg.setF_LOANSTARTDATE(LOANSTARTDATE);
			entMsg.setF_PAYMENTSTATUS(PAYMENTSTATUS);
			entMsg.setF_PRODUCTSTATUS(PRODUCTSTATUS);
			entMsg.setF_REDUCINGPRINCIPAL(REDUCINGPRINCIPAL);
			entMsg.setF_repaymentPeriod(repaymentPeriod);
			entMsg.setF_securityType(securityType);
			entMsg.setF_PRODUCTTYPE("OB6");
			factory.create(IBOCE_SIMHAENTMSG.BONAME, entMsg);
		}
	}

	private void persistHistory(IBOCE_SIMHAENTMSG entMsg, IPersistenceObjectsFactory factory) {
		IBOCE_SIMHAENTMSGHST msgHst = (IBOCE_SIMHAENTMSGHST) factory
				.getStatelessNewInstance(IBOCE_SIMHAENTMSGHST.BONAME);
		msgHst.setBoID(GUIDGen.getNewGUID());
		msgHst.setF_LOANACCNO(entMsg.getBoID());
		msgHst.setF_GAURANTOR(entMsg.getF_GAURANTOR());
		msgHst.setF_installmentAmt(entMsg.getF_installmentAmt());
		msgHst.setF_LOANSTARTDATE(entMsg.getF_LOANSTARTDATE());
		msgHst.setF_PAYMENTSTATUS(entMsg.getF_PAYMENTSTATUS());
		msgHst.setF_PRODUCTSTATUS(entMsg.getF_PRODUCTSTATUS());
		msgHst.setF_REDUCINGPRINCIPAL(entMsg.getF_REDUCINGPRINCIPAL());
		msgHst.setF_repaymentPeriod(entMsg.getF_repaymentPeriod());
		msgHst.setF_securityType(entMsg.getF_securityType());
		msgHst.setF_PRODUCTTYPE(entMsg.getF_PRODUCTTYPE());
		factory.create(IBOCE_SIMHAENTMSGHST.BONAME, msgHst);
	}

	private int getRepaymentPeriod(IBOLendingFeature loandtls) {
		Calendar startCalendar = new GregorianCalendar();
		startCalendar.setTime(loandtls.getF_LOANSTARTDATE());
		Calendar endCalendar = new GregorianCalendar();
		endCalendar.setTime(loandtls.getF_FINALMATURITYDATE());
		int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
		int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
		return diffMonth;
	}

	@SuppressWarnings("unchecked")
	private BigDecimal getInstallmentAmount(String accountid) {
		BigDecimal installmentAmt = BigDecimal.ZERO;
		ArrayList<Object> params = new ArrayList<Object>();
		params.add(accountid);
		params.add(1);
		List<IBOLN_LEN_LoanSchedule> schList = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOLN_LEN_LoanSchedule.BONAME, "WHERE " + IBOLN_LEN_LoanSchedule.LOANACCOUNTID + "=? AND "
						+ IBOLN_LEN_LoanSchedule.REPAYMENTNUMBER + "=?", params, null, true);
		if (schList != null && !schList.isEmpty()) {
			IBOLN_LEN_LoanSchedule loanSch = schList.get(0);
			installmentAmt = loanSch.getF_PAYMENTAMT();
		}
		return installmentAmt;
	}

	@SuppressWarnings("rawtypes")
	private void prepare125(IBOCustomer cust) throws IOException {
		logger.info("Preparing of 125 Detail Record Start: " + cust.getBoID());
		String WHERE_CUST_CONT = " WHERE " + IBOCustomerContacts.CUSTOMERCODE + " = ? AND "
				+ IBOCustomerContacts.CONTACTMEDIUMTYPE + " = ?";
		ArrayList<String> params = new ArrayList<String>();
		params.add(cust.getBoID());
		params.add("TELEPHONE");
		List contactList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCustomerContacts.BONAME,
				WHERE_CUST_CONT, params, null, true);
		StringBuilder contactString = new StringBuilder();
		String contactValue = "";
		if (contactList != null && !contactList.isEmpty()) {
			logger.info("SPK contactList: " + contactList.size());
			IBOCustomerContacts custContact = (IBOCustomerContacts) contactList.get(0);

			contactValue = custContact.getF_CONTACTMEDIUMDETAIL();
			contactString.append(contactValue);
			logger.info("SPK contactList: " + contactString);
		} else {
			params.clear();
			params.add(cust.getBoID());
			params.add("SMS");
			contactList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCustomerContacts.BONAME,
					WHERE_CUST_CONT, params, null, true);
			if (contactList != null && !contactList.isEmpty()) {
				IBOCustomerContacts custContact = (IBOCustomerContacts) contactList.get(0);
				contactValue = custContact.getF_CONTACTMEDIUMDETAIL();
				contactString.append(contactValue);
			}
		}
		contactString.append(validateLength("", 1));
		contactString.append(validateLength("", 3));
		contactString.append(validateLength("", 3));
		contactString.append(validateLength("", 10));
		contactString.append(validateLength("", 5));
		contactString.append(validateLength(contactValue, 25));
		contactString.append("\n");
		file.write(contactString.toString().getBytes());
		count++;
		logger.info("Preparing of 125 Detail Record End:Count:" + count);
	}

	private void prepareDetailRecord(String identifier, IBOCustomer cust) throws IOException {
		StringBuilder dataRec = new StringBuilder();
		dataRec.append(identifier);
		// String address = "";
		branchCountry = "";
		IBOOrgDetails orgDtls = (IBOOrgDetails) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOOrgDetails.BONAME, cust.getBoID(), true);
		dataRec.append(validateLength(orgDtls.getF_ORGANISATIONREGISTRATION(), 15));
		dataRec.append("MC");
		IBOBranch branch = (IBOBranch) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOBranch.BONAME,
				cust.getF_BRANCHSORTCODE(), true);
		if (branch != null) {
			// address = branch.getF_ADDRESSLINE2();
			branchCountry = branch.getF_ISOCOUNTRYCODE();
			logger.info("Branch: " + branchCountry);
		} else {
			logger.info("Branch NULL");
			// TODO : Should it be changed to KSA ?
			branchCountry = "SAK";
		}
		dataRec.append(branchCountry);
		// dataRec = dataRec+validateLength(address,3);
		dataRec.append(validateLength("", 20));// English Name
		dataRec.append(validateLength(cust.getF_SHORTNAME(), 20));
		dataRec.append(validateLength("", 5));// Zip Code
		dataRec.append(validateLength("", 25));// Cust No
		logger.info(dataRec.toString());
		file.write(dataRec.toString().getBytes());
	}

	@SuppressWarnings("rawtypes")
	private void prepare120(IBOCustomer cust) throws IOException {
		logger.info("Preparing of 120 Detail Record Start::: " + cust.getBoID());
		StringBuilder dataRec = new StringBuilder();
		try {
			ArrayList<String> params = new ArrayList<String>();
			params.add(cust.getBoID());
			logger.info("SPK2");
			List ListAddressLink = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOAddressLinks.BONAME,
					"WHERE " + IBOAddressLinks.CUSTACC_KEY + "=?", params, null, true);
			if (ListAddressLink != null && !ListAddressLink.isEmpty()) {
				logger.info("ListAddressLink Size: " + ListAddressLink.size());
				IBOAddressLinks addLink = (IBOAddressLinks) ListAddressLink.get(0);
				logger.info("getF_ADDRESSID: " + addLink.getF_ADDRESSID());
				IBOAddress address = (IBOAddress) BankFusionThreadLocal.getPersistanceFactory()
						.findByPrimaryKey(IBOAddress.BONAME, addLink.getF_ADDRESSID(), true);
				dataRec.append(validateLength("", 100));
				dataRec.append(validateLength("", 100));
				dataRec.append(validateLength(address.getF_ADDRESSLINE1(), 100));
				dataRec.append(validateLength(address.getF_ADDRESSLINE2(), 100));
				dataRec.append(validateLength("", 10));
				dataRec.append(validateLength(address.getF_POSTZIPCODE(), 5));
				dataRec.append(validateLength("", 4));
				dataRec.append(validateLength("", 3));
				dataRec.append(validateLength("", 3));
				dataRec.append(validateLength("", 50));
				dataRec.append(validateLength("", 50));
				dataRec.append(validateLength("", 50));
				dataRec.append(validateLength("", 50));
				dataRec.append(validateLength(address.getF_ADDRESSLINE3(), 50));
				dataRec.append(validateLength(address.getF_ADDRESSLINE4(), 50));
				dataRec.append(validateLength(address.getF_ADDRESSLINE5(), 50));
				dataRec.append(validateLength(address.getF_ADDRESSLINE6(), 50));
				dataRec.append("\n");
			}
			file.write(dataRec.toString().getBytes());
			count++;
			logger.info(dataRec);
			logger.info("count in 120:" + count);
			logger.info("Preparing of 120 Detail Record End");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Inside prepare120 Exception: " + e);
		}
	}

	@SuppressWarnings("rawtypes")
	private void prepare105(IBOCustomer cust) throws IOException {
		logger.info("Preparing of 105 Detail Record Start");
		// 105 Part Detailed Record
		StringBuilder dataRec = new StringBuilder();
		// String address = "";
		String country = "";
		String idNumberExpiryDate = "";
		String legalForm = "";
		String sicCode = "";
		String incorporationDate = "";
		String noOfEmployees = "";
		String webSite = "";
		String internalRateCode = "";
		String lastDayInternalRating = "";
		IBOOrgDetails orgDtls = (IBOOrgDetails) BankFusionThreadLocal.getPersistanceFactory()
				.findByPrimaryKey(IBOOrgDetails.BONAME, cust.getBoID(), true);
		IBOBranch branch = (IBOBranch) BankFusionThreadLocal.getPersistanceFactory().findByPrimaryKey(IBOBranch.BONAME,
				cust.getF_BRANCHSORTCODE(), true);
		if (branch != null) {
			// address = branch.getF_ADDRESSLINE2();
			branchCountry = branch.getF_ISOCOUNTRYCODE();
			logger.info("Branch: " + branchCountry);
		} else {
			logger.info("Branch NULL");
			branchCountry = "SAK";
		}
		// 105 Identity of the Records
		dataRec.append("MC");
		dataRec.append(validateLength(orgDtls.getF_ORGANISATIONREGISTRATION(), 15));
		dataRec.append(validateLength(idNumberExpiryDate, 8));
		dataRec.append(validateLength(branchCountry, 3));
		dataRec.append(validateLength("", 75));
		dataRec.append(validateLength(cust.getF_SHORTNAME(), 75));
		ArrayList<String> params = new ArrayList<String>();
		params.add(branchCountry);
		List countryList = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCountry.BONAME,
				" WHERE " + IBOCountry.ISOCOUNTRYCODE + "=?", params, null, true);
		if (countryList != null && !countryList.isEmpty()) {
			IBOCountry countryObj = (IBOCountry) countryList.get(0);
			country = countryObj.getBoID();
		}
		dataRec.append(validateLength(country, 3));
		dataRec.append(validateLength(legalForm, 3));
		dataRec.append(validateLength(sicCode, 5));
		dataRec.append(validateLength(incorporationDate, 8));
		dataRec.append(validateLength(noOfEmployees, 2));
		dataRec.append(validateLength(webSite, 60));
		dataRec.append("N");
		dataRec.append(validateLength(internalRateCode, 1));
		dataRec.append(validateLength(lastDayInternalRating, 8));
		dataRec.append("\\n");
		file.write(dataRec.toString().getBytes());
		count++;
		logger.info("Count in 105" + count);
		logger.info("Preparing of 105 Detail Record End");
	}

	private String validateLength(String value, int tlen) {
		StringBuilder finalValue = new StringBuilder();
		int remainingLength = tlen - value.length();
		if (remainingLength <= 0) {
			return value.substring(0, tlen);
		} else {
			finalValue.append(value);
			for (int len = 0; len < remainingLength; len++) {
				finalValue.append(BLANK);
			}
		}
		return finalValue.toString();
	}

	private void prepareHeader() {
		logger.info("Preparing of File Header Start:");
		String dateSnap = new SimpleDateFormat("yyyyMMddHHmm")
				.format(SystemInformationManager.getInstance().getBFBusinessDate());
		String header = "000AGDF" + dateSnap + versionNum + "N" + "\n";
		try {
			file.write(header.getBytes());
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		logger.info("Preparing of File Header End");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<IBOCustomer> getEnterPriseCustomer() {
		logger.info("Preparing of Customer List Start");
		List result = null;
		ArrayList<String> params = new ArrayList<String>();
		params.add("1063");
		result = BankFusionThreadLocal.getPersistanceFactory().findByQuery(IBOCustomer.BONAME, ENT_CUS_WHERE, params,
				null, true);
		logger.info("Preparing of Customer List End:" + result.size());
		return result;
	}

	private HashMap<String, Object> getPaymentStatus(int overdueDays) {
		HashMap<String, Object> data = new HashMap<String, Object>();
		String cycleDaysString = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE", "DELAY_CYCLE_PERIOD");
		String defaultDaysString = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE",
				"TOTAL_DAYS_TO_DEFAULT");
		String cycleTime = new CEUtil().getModuleConfigurationValue("CESIMAHINTERFACE", "CYCLE_BEFORE_AFTER");
		data.put("ProductStatus", "");
		data.put("PaymentStatus", "");
		Integer cycleDays = new Integer(cycleDaysString);
		Integer defaultDays = new Integer(defaultDaysString);
		Integer daysAfter = 0;
		if (cycleTime.equals("A")) {
			daysAfter = defaultDays - (cycleDays * 6);
			if (overdueDays <= daysAfter) {
				data.put("ProductStatus", SIMAH_LOAN_ACTIVE);
				data.put("PaymentStatus", "0");
				return data;
			}
		}
		data.put("ProductStatus", SIMAH_LOAN_ACTIVE);
		if (daysAfter + 1 <= overdueDays && overdueDays <= daysAfter + cycleDays) {
			data.put("PaymentStatus", "1");
			return data;
		}
		if ((daysAfter + cycleDays + 1) <= overdueDays && overdueDays <= daysAfter + (2 * cycleDays)) {
			data.put("PaymentStatus", "2");
			return data;
		}
		if (daysAfter + (2 * cycleDays) + 1 <= overdueDays && overdueDays <= daysAfter + (3 * cycleDays)) {
			data.put("PaymentStatus", "3");
			return data;
		}
		if (daysAfter + (3 * cycleDays) + 1 <= overdueDays && overdueDays <= daysAfter + (4 * cycleDays)) {
			data.put("PaymentStatus", "4");
			return data;
		}
		if (daysAfter + (4 * cycleDays) + 1 <= overdueDays && overdueDays <= daysAfter + (5 * cycleDays)) {
			data.put("PaymentStatus", "5");
			return data;
		}
		if (daysAfter + (5 * cycleDays) + 1 <= overdueDays && overdueDays <= daysAfter + (6 * cycleDays)) {
			data.put("PaymentStatus", "6");
			return data;
		}
		if (overdueDays > daysAfter + (6 * cycleDays) && overdueDays <= defaultDays) {
			data.put("ProductStatus", SIMAH_LOAN_ACTIVE);
			data.put("PaymentStatus", "6");
			return data;
		}
		if (overdueDays > defaultDays) {
			data.put("ProductStatus", SIMAH_LOAN_DEFAULT);
			data.put("PaymentStatus", "8");
			return data;
		}
		if (overdueDays == 0 && data.get("PaymentStatus").equals("")) {
			data.put("ProductStatus", SIMAH_LOAN_ACTIVE);
			data.put("PaymentStatus", "0");
			return data;
		}
		return data;
	}

}