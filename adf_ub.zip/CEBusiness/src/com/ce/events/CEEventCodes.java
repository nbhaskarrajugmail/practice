package com.ce.events;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.utils.AbstractEventCodes;

public class CEEventCodes extends AbstractEventCodes {

	/**
	 * <code>svnRevision</code> = $Revision: 1.0 $
	 */
	public static final String svnRevision = "$Revision: 1.0 $";
	static {
		com.trapedza.bankfusion.utils.Tracer.register(svnRevision);
	}

	/**
	 */
	transient final static Log logger = LogFactory.getLog(CEEventCodes.class.getName());

	private static final int SUB_SYSTEM_ID = 440;

	/**
	 * Private constructor
	 */
	public CEEventCodes() {
		subsystemId = SUB_SYSTEM_ID;
		baseName = CommonConstants.EMPTY_STRING;
	}

	/**
	 * Please include your event message name and event code below with below format
	 * <code>Event Message Variable Name</code> = Event Code.
	 */
}
