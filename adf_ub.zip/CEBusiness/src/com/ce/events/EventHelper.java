package com.ce.events;

import java.util.ArrayList;
import java.util.List;

import com.misys.bankfusion.events.IBusinessEventsService;
import com.trapedza.bankfusion.bo.refimpl.IBOEventCodeMessage;
import com.trapedza.bankfusion.servercommon.core.BankFusionThreadLocal;
import com.trapedza.bankfusion.servercommon.services.ServiceManagerFactory;

import bf.com.misys.cbs.types.events.Event;

/**
 * @author Prasanna Kumar S
 *
 */

public class EventHelper {

	private static final String EVENTMESSAGE = " where " + IBOEventCodeMessage.EVENTCODEID + " = ?";

	/**
	 * 
	 * @param eventNumber
	 */
	public void raiseBusinessEvent(int eventNumber) {
		Event event = new Event();
		event.setEventNumber(eventNumber);
		IBusinessEventsService businessEventsService = (IBusinessEventsService) ServiceManagerFactory.getInstance()
				.getServiceManager().getServiceForName(IBusinessEventsService.SERVICE_NAME);
		businessEventsService.handleEvent(event);
	}

	/**
	 * 
	 * @param eventCodeID
	 * @return
	 */
	public String getEventCodeMessage(String eventCodeID) {

		ArrayList params = new ArrayList();
		params.add(eventCodeID);
		List<IBOEventCodeMessage> eventCodeMessages = BankFusionThreadLocal.getPersistanceFactory()
				.findByQuery(IBOEventCodeMessage.BONAME, EVENTMESSAGE, params, null, false);
		String eventMessage = eventCodeMessages.get(0).getF_RUNTIMEMESSAGE();

		return eventMessage;
	}
}