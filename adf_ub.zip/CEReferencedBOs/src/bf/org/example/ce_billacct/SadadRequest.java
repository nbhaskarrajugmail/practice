/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.org.example.ce_billacct;

/**
 * Class SadadRequest.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SadadRequest implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _batchId.
     */
    private java.lang.String _batchId;

    /**
     * Field _successCount.
     */
    private java.lang.Integer _successCount;

    /**
     * Field _errorCount.
     */
    private java.lang.Integer _errorCount;

    /**
     * Field _transactionDtlList.
     */
    private java.util.Vector<bf.org.example.ce_billacct.BillAcctRq> _transactionDtlList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SadadRequest() {
        super();
        this._transactionDtlList = new java.util.Vector<bf.org.example.ce_billacct.BillAcctRq>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTransactionDtl
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTransactionDtl(
            final bf.org.example.ce_billacct.BillAcctRq vTransactionDtl)
    throws java.lang.IndexOutOfBoundsException {
        this._transactionDtlList.addElement(vTransactionDtl);
    }

    /**
     * 
     * 
     * @param index
     * @param vTransactionDtl
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTransactionDtl(
            final int index,
            final bf.org.example.ce_billacct.BillAcctRq vTransactionDtl)
    throws java.lang.IndexOutOfBoundsException {
        this._transactionDtlList.add(index, vTransactionDtl);
    }

    /**
     * Method enumerateTransactionDtl.
     * 
     * @return an Enumeration over all
     * bf.org.example.ce_billacct.BillAcctRq elements
     */
    public java.util.Enumeration<? extends bf.org.example.ce_billacct.BillAcctRq> enumerateTransactionDtl(
    ) {
        return this._transactionDtlList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SadadRequest) {

            SadadRequest temp = (SadadRequest)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._batchId != null) {
                if (temp._batchId == null) return false;
                if (this._batchId != temp._batchId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchId.equals(temp._batchId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId);
                    }
                }
            } else if (temp._batchId != null)
                return false;
            if (this._successCount != null) {
                if (temp._successCount == null) return false;
                if (this._successCount != temp._successCount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._successCount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._successCount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._successCount.equals(temp._successCount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount);
                    }
                }
            } else if (temp._successCount != null)
                return false;
            if (this._errorCount != null) {
                if (temp._errorCount == null) return false;
                if (this._errorCount != temp._errorCount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._errorCount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._errorCount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._errorCount.equals(temp._errorCount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount);
                    }
                }
            } else if (temp._errorCount != null)
                return false;
            if (this._transactionDtlList != null) {
                if (temp._transactionDtlList == null) return false;
                if (this._transactionDtlList != temp._transactionDtlList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionDtlList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionDtlList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDtlList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDtlList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionDtlList.equals(temp._transactionDtlList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDtlList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDtlList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDtlList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDtlList);
                    }
                }
            } else if (temp._transactionDtlList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'batchId'.
     * 
     * @return the value of field 'BatchId'.
     */
    public java.lang.String getBatchId(
    ) {
        return this._batchId;
    }

    /**
     * Returns the value of field 'errorCount'.
     * 
     * @return the value of field 'ErrorCount'.
     */
    public java.lang.Integer getErrorCount(
    ) {
        return this._errorCount;
    }

    /**
     * Returns the value of field 'successCount'.
     * 
     * @return the value of field 'SuccessCount'.
     */
    public java.lang.Integer getSuccessCount(
    ) {
        return this._successCount;
    }

    /**
     * Method getTransactionDtl.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.org.example.ce_billacct.BillAcctRq at the given index
     */
    public bf.org.example.ce_billacct.BillAcctRq getTransactionDtl(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._transactionDtlList.size()) {
            throw new IndexOutOfBoundsException("getTransactionDtl: Index value '" + index + "' not in range [0.." + (this._transactionDtlList.size() - 1) + "]");
        }

        return (bf.org.example.ce_billacct.BillAcctRq) _transactionDtlList.get(index);
    }

    /**
     * Method getTransactionDtl.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.org.example.ce_billacct.BillAcctRq[] getTransactionDtl(
    ) {
        bf.org.example.ce_billacct.BillAcctRq[] array = new bf.org.example.ce_billacct.BillAcctRq[0];
        return (bf.org.example.ce_billacct.BillAcctRq[]) this._transactionDtlList.toArray(array);
    }

    /**
     * Method getTransactionDtlCount.
     * 
     * @return the size of this collection
     */
    public int getTransactionDtlCount(
    ) {
        return this._transactionDtlList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_batchId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchId)) {
           result = 37 * result + _batchId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchId);
        }
        if (_successCount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_successCount)) {
           result = 37 * result + _successCount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_successCount);
        }
        if (_errorCount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_errorCount)) {
           result = 37 * result + _errorCount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_errorCount);
        }
        if (_transactionDtlList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionDtlList)) {
           result = 37 * result + _transactionDtlList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionDtlList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTransactionDtl(
    ) {
        this._transactionDtlList.clear();
    }

    /**
     * Method removeTransactionDtl.
     * 
     * @param vTransactionDtl
     * @return true if the object was removed from the collection.
     */
    public boolean removeTransactionDtl(
            final bf.org.example.ce_billacct.BillAcctRq vTransactionDtl) {
        boolean removed = _transactionDtlList.remove(vTransactionDtl);
        return removed;
    }

    /**
     * Method removeTransactionDtlAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.org.example.ce_billacct.BillAcctRq removeTransactionDtlAt(
            final int index) {
        java.lang.Object obj = this._transactionDtlList.remove(index);
        return (bf.org.example.ce_billacct.BillAcctRq) obj;
    }

    /**
     * Sets the value of field 'batchId'.
     * 
     * @param batchId the value of field 'batchId'.
     */
    public void setBatchId(
            final java.lang.String batchId) {
        this._batchId = batchId;
    }

    /**
     * Sets the value of field 'errorCount'.
     * 
     * @param errorCount the value of field 'errorCount'.
     */
    public void setErrorCount(
            final java.lang.Integer errorCount) {
        this._errorCount = errorCount;
    }

    /**
     * Sets the value of field 'successCount'.
     * 
     * @param successCount the value of field 'successCount'.
     */
    public void setSuccessCount(
            final java.lang.Integer successCount) {
        this._successCount = successCount;
    }

    /**
     * 
     * 
     * @param index
     * @param vTransactionDtl
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTransactionDtl(
            final int index,
            final bf.org.example.ce_billacct.BillAcctRq vTransactionDtl)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._transactionDtlList.size()) {
            throw new IndexOutOfBoundsException("setTransactionDtl: Index value '" + index + "' not in range [0.." + (this._transactionDtlList.size() - 1) + "]");
        }

        this._transactionDtlList.set(index, vTransactionDtl);
    }

    /**
     * 
     * 
     * @param vTransactionDtlArray
     */
    public void setTransactionDtl(
            final bf.org.example.ce_billacct.BillAcctRq[] vTransactionDtlArray) {
        //-- copy array
        _transactionDtlList.clear();

        for (int i = 0; i < vTransactionDtlArray.length; i++) {
                this._transactionDtlList.add(vTransactionDtlArray[i]);
        }
    }

    /**
     * Method unmarshalSadadRequest.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.org.example.ce_billacct.SadadRequest
     */
    public static bf.org.example.ce_billacct.SadadRequest unmarshalSadadRequest(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.org.example.ce_billacct.SadadRequest) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.org.example.ce_billacct.SadadRequest.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
