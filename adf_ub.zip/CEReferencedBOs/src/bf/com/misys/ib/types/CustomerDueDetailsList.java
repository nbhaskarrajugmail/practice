/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.ib.types;

/**
 * Customer dues for NationalID
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class CustomerDueDetailsList implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _customerDueDetailsList.
     */
    private java.util.Vector<bf.com.misys.ib.types.CustomerDueDetail> _customerDueDetailsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public CustomerDueDetailsList() {
        super();
        this._customerDueDetailsList = new java.util.Vector<bf.com.misys.ib.types.CustomerDueDetail>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vCustomerDueDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCustomerDueDetails(
            final bf.com.misys.ib.types.CustomerDueDetail vCustomerDueDetails)
    throws java.lang.IndexOutOfBoundsException {
        this._customerDueDetailsList.addElement(vCustomerDueDetails);
    }

    /**
     * 
     * 
     * @param index
     * @param vCustomerDueDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addCustomerDueDetails(
            final int index,
            final bf.com.misys.ib.types.CustomerDueDetail vCustomerDueDetails)
    throws java.lang.IndexOutOfBoundsException {
        this._customerDueDetailsList.add(index, vCustomerDueDetails);
    }

    /**
     * Method enumerateCustomerDueDetails.
     * 
     * @return an Enumeration over all
     * bf.com.misys.ib.types.CustomerDueDetail elements
     */
    public java.util.Enumeration<? extends bf.com.misys.ib.types.CustomerDueDetail> enumerateCustomerDueDetails(
    ) {
        return this._customerDueDetailsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof CustomerDueDetailsList) {

            CustomerDueDetailsList temp = (CustomerDueDetailsList)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._customerDueDetailsList != null) {
                if (temp._customerDueDetailsList == null) return false;
                if (this._customerDueDetailsList != temp._customerDueDetailsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._customerDueDetailsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._customerDueDetailsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._customerDueDetailsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._customerDueDetailsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._customerDueDetailsList.equals(temp._customerDueDetailsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._customerDueDetailsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._customerDueDetailsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._customerDueDetailsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._customerDueDetailsList);
                    }
                }
            } else if (temp._customerDueDetailsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getCustomerDueDetails.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.com.misys.ib.types.CustomerDueDetail at the given index
     */
    public bf.com.misys.ib.types.CustomerDueDetail getCustomerDueDetails(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._customerDueDetailsList.size()) {
            throw new IndexOutOfBoundsException("getCustomerDueDetails: Index value '" + index + "' not in range [0.." + (this._customerDueDetailsList.size() - 1) + "]");
        }

        return (bf.com.misys.ib.types.CustomerDueDetail) _customerDueDetailsList.get(index);
    }

    /**
     * Method getCustomerDueDetails.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.com.misys.ib.types.CustomerDueDetail[] getCustomerDueDetails(
    ) {
        bf.com.misys.ib.types.CustomerDueDetail[] array = new bf.com.misys.ib.types.CustomerDueDetail[0];
        return (bf.com.misys.ib.types.CustomerDueDetail[]) this._customerDueDetailsList.toArray(array);
    }

    /**
     * Method getCustomerDueDetailsCount.
     * 
     * @return the size of this collection
     */
    public int getCustomerDueDetailsCount(
    ) {
        return this._customerDueDetailsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_customerDueDetailsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_customerDueDetailsList)) {
           result = 37 * result + _customerDueDetailsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_customerDueDetailsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllCustomerDueDetails(
    ) {
        this._customerDueDetailsList.clear();
    }

    /**
     * Method removeCustomerDueDetails.
     * 
     * @param vCustomerDueDetails
     * @return true if the object was removed from the collection.
     */
    public boolean removeCustomerDueDetails(
            final bf.com.misys.ib.types.CustomerDueDetail vCustomerDueDetails) {
        boolean removed = _customerDueDetailsList.remove(vCustomerDueDetails);
        return removed;
    }

    /**
     * Method removeCustomerDueDetailsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.com.misys.ib.types.CustomerDueDetail removeCustomerDueDetailsAt(
            final int index) {
        java.lang.Object obj = this._customerDueDetailsList.remove(index);
        return (bf.com.misys.ib.types.CustomerDueDetail) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vCustomerDueDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setCustomerDueDetails(
            final int index,
            final bf.com.misys.ib.types.CustomerDueDetail vCustomerDueDetails)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._customerDueDetailsList.size()) {
            throw new IndexOutOfBoundsException("setCustomerDueDetails: Index value '" + index + "' not in range [0.." + (this._customerDueDetailsList.size() - 1) + "]");
        }

        this._customerDueDetailsList.set(index, vCustomerDueDetails);
    }

    /**
     * 
     * 
     * @param vCustomerDueDetailsArray
     */
    public void setCustomerDueDetails(
            final bf.com.misys.ib.types.CustomerDueDetail[] vCustomerDueDetailsArray) {
        //-- copy array
        _customerDueDetailsList.clear();

        for (int i = 0; i < vCustomerDueDetailsArray.length; i++) {
                this._customerDueDetailsList.add(vCustomerDueDetailsArray[i]);
        }
    }

    /**
     * Method unmarshalCustomerDueDetailsList.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.ib.types.CustomerDueDetailsList
     */
    public static bf.com.misys.ib.types.CustomerDueDetailsList unmarshalCustomerDueDetailsList(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.ib.types.CustomerDueDetailsList) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.ib.types.CustomerDueDetailsList.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
