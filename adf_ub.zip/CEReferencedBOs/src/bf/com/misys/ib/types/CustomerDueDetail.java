/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.ib.types;

/**
 * Customer Liabilities
 *  
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class CustomerDueDetail implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _batchID.
     */
    private java.lang.String _batchID;

    /**
     * Field _dueDate.
     */
    private java.sql.Date _dueDate;

    /**
     * Field _userRole.
     */
    private java.lang.String _userRole;

    /**
     * Field _dueAmount.
     */
    private bf.com.misys.bankfusion.attributes.BFCurrencyAmount _dueAmount;

    /**
     * Field _dueAmountPaid.
     */
    private bf.com.misys.bankfusion.attributes.BFCurrencyAmount _dueAmountPaid;

    /**
     * Field _dealAccountID.
     */
    private java.lang.String _dealAccountID;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;

    /**
     * Field _process.
     */
    private java.lang.Boolean _process;

    /**
     * Field _transactionID.
     */
    private java.lang.String _transactionID;


      //----------------/
     //- Constructors -/
    //----------------/

    public CustomerDueDetail() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof CustomerDueDetail) {

            CustomerDueDetail temp = (CustomerDueDetail)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._batchID != null) {
                if (temp._batchID == null) return false;
                if (this._batchID != temp._batchID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchID.equals(temp._batchID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchID);
                    }
                }
            } else if (temp._batchID != null)
                return false;
            if (this._dueDate != null) {
                if (temp._dueDate == null) return false;
                if (this._dueDate != temp._dueDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._dueDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._dueDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._dueDate.equals(temp._dueDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueDate);
                    }
                }
            } else if (temp._dueDate != null)
                return false;
            if (this._userRole != null) {
                if (temp._userRole == null) return false;
                if (this._userRole != temp._userRole) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._userRole);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._userRole);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._userRole); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._userRole); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._userRole.equals(temp._userRole)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._userRole);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._userRole);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._userRole);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._userRole);
                    }
                }
            } else if (temp._userRole != null)
                return false;
            if (this._dueAmount != null) {
                if (temp._dueAmount == null) return false;
                if (this._dueAmount != temp._dueAmount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._dueAmount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._dueAmount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._dueAmount.equals(temp._dueAmount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmount);
                    }
                }
            } else if (temp._dueAmount != null)
                return false;
            if (this._dueAmountPaid != null) {
                if (temp._dueAmountPaid == null) return false;
                if (this._dueAmountPaid != temp._dueAmountPaid) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._dueAmountPaid);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._dueAmountPaid);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmountPaid); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmountPaid); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._dueAmountPaid.equals(temp._dueAmountPaid)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmountPaid);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmountPaid);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dueAmountPaid);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dueAmountPaid);
                    }
                }
            } else if (temp._dueAmountPaid != null)
                return false;
            if (this._dealAccountID != null) {
                if (temp._dealAccountID == null) return false;
                if (this._dealAccountID != temp._dealAccountID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._dealAccountID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._dealAccountID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dealAccountID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dealAccountID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._dealAccountID.equals(temp._dealAccountID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dealAccountID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dealAccountID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dealAccountID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dealAccountID);
                    }
                }
            } else if (temp._dealAccountID != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            if (this._process != null) {
                if (temp._process == null) return false;
                if (this._process != temp._process) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._process);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._process);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._process); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._process); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._process.equals(temp._process)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._process);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._process);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._process);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._process);
                    }
                }
            } else if (temp._process != null)
                return false;
            if (this._transactionID != null) {
                if (temp._transactionID == null) return false;
                if (this._transactionID != temp._transactionID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionID.equals(temp._transactionID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID);
                    }
                }
            } else if (temp._transactionID != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'batchID'.
     * 
     * @return the value of field 'BatchID'.
     */
    public java.lang.String getBatchID(
    ) {
        return this._batchID;
    }

    /**
     * Returns the value of field 'dealAccountID'.
     * 
     * @return the value of field 'DealAccountID'.
     */
    public java.lang.String getDealAccountID(
    ) {
        return this._dealAccountID;
    }

    /**
     * Returns the value of field 'dueAmount'.
     * 
     * @return the value of field 'DueAmount'.
     */
    public bf.com.misys.bankfusion.attributes.BFCurrencyAmount getDueAmount(
    ) {
        return this._dueAmount;
    }

    /**
     * Returns the value of field 'dueAmountPaid'.
     * 
     * @return the value of field 'DueAmountPaid'.
     */
    public bf.com.misys.bankfusion.attributes.BFCurrencyAmount getDueAmountPaid(
    ) {
        return this._dueAmountPaid;
    }

    /**
     * Returns the value of field 'dueDate'.
     * 
     * @return the value of field 'DueDate'.
     */
    public java.sql.Date getDueDate(
    ) {
        return this._dueDate;
    }

    /**
     * Returns the value of field 'process'.
     * 
     * @return the value of field 'Process'.
     */
    public java.lang.Boolean getProcess(
    ) {
        return this._process;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'transactionID'.
     * 
     * @return the value of field 'TransactionID'.
     */
    public java.lang.String getTransactionID(
    ) {
        return this._transactionID;
    }

    /**
     * Returns the value of field 'userRole'.
     * 
     * @return the value of field 'UserRole'.
     */
    public java.lang.String getUserRole(
    ) {
        return this._userRole;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_batchID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchID)) {
           result = 37 * result + _batchID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchID);
        }
        if (_dueDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_dueDate)) {
           result = 37 * result + _dueDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_dueDate);
        }
        if (_userRole != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_userRole)) {
           result = 37 * result + _userRole.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_userRole);
        }
        if (_dueAmount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_dueAmount)) {
           result = 37 * result + _dueAmount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_dueAmount);
        }
        if (_dueAmountPaid != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_dueAmountPaid)) {
           result = 37 * result + _dueAmountPaid.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_dueAmountPaid);
        }
        if (_dealAccountID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_dealAccountID)) {
           result = 37 * result + _dealAccountID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_dealAccountID);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }
        if (_process != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_process)) {
           result = 37 * result + _process.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_process);
        }
        if (_transactionID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionID)) {
           result = 37 * result + _transactionID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionID);
        }

        return result;
    }

    /**
     * Returns the value of field 'process'.
     * 
     * @return the value of field 'Process'.
     */
    public java.lang.Boolean isProcess(
    ) {
        return this._process;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'batchID'.
     * 
     * @param batchID the value of field 'batchID'.
     */
    public void setBatchID(
            final java.lang.String batchID) {
        this._batchID = batchID;
    }

    /**
     * Sets the value of field 'dealAccountID'.
     * 
     * @param dealAccountID the value of field 'dealAccountID'.
     */
    public void setDealAccountID(
            final java.lang.String dealAccountID) {
        this._dealAccountID = dealAccountID;
    }

    /**
     * Sets the value of field 'dueAmount'.
     * 
     * @param dueAmount the value of field 'dueAmount'.
     */
    public void setDueAmount(
            final bf.com.misys.bankfusion.attributes.BFCurrencyAmount dueAmount) {
        this._dueAmount = dueAmount;
    }

    /**
     * Sets the value of field 'dueAmountPaid'.
     * 
     * @param dueAmountPaid the value of field 'dueAmountPaid'.
     */
    public void setDueAmountPaid(
            final bf.com.misys.bankfusion.attributes.BFCurrencyAmount dueAmountPaid) {
        this._dueAmountPaid = dueAmountPaid;
    }

    /**
     * Sets the value of field 'dueDate'.
     * 
     * @param dueDate the value of field 'dueDate'.
     */
    public void setDueDate(
            final java.sql.Date dueDate) {
        this._dueDate = dueDate;
    }

    /**
     * Sets the value of field 'process'.
     * 
     * @param process the value of field 'process'.
     */
    public void setProcess(
            final java.lang.Boolean process) {
        this._process = process;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'transactionID'.
     * 
     * @param transactionID the value of field 'transactionID'.
     */
    public void setTransactionID(
            final java.lang.String transactionID) {
        this._transactionID = transactionID;
    }

    /**
     * Sets the value of field 'userRole'.
     * 
     * @param userRole the value of field 'userRole'.
     */
    public void setUserRole(
            final java.lang.String userRole) {
        this._userRole = userRole;
    }

    /**
     * Method unmarshalCustomerDueDetail.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.ib.types.CustomerDueDetail
     */
    public static bf.com.misys.ib.types.CustomerDueDetail unmarshalCustomerDueDetail(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.ib.types.CustomerDueDetail) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.ib.types.CustomerDueDetail.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
