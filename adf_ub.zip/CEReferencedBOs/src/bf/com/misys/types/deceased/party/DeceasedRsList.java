/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.deceased.party;

/**
 * Class DeceasedRsList.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class DeceasedRsList implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _deceasedResList.
     */
    private java.util.Vector<bf.com.misys.types.deceased.party.DeceasedRs> _deceasedResList;


      //----------------/
     //- Constructors -/
    //----------------/

    public DeceasedRsList() {
        super();
        this._deceasedResList = new java.util.Vector<bf.com.misys.types.deceased.party.DeceasedRs>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vDeceasedRes
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDeceasedRes(
            final bf.com.misys.types.deceased.party.DeceasedRs vDeceasedRes)
    throws java.lang.IndexOutOfBoundsException {
        this._deceasedResList.addElement(vDeceasedRes);
    }

    /**
     * 
     * 
     * @param index
     * @param vDeceasedRes
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addDeceasedRes(
            final int index,
            final bf.com.misys.types.deceased.party.DeceasedRs vDeceasedRes)
    throws java.lang.IndexOutOfBoundsException {
        this._deceasedResList.add(index, vDeceasedRes);
    }

    /**
     * Method enumerateDeceasedRes.
     * 
     * @return an Enumeration over all
     * bf.com.misys.types.deceased.party.DeceasedRs elements
     */
    public java.util.Enumeration<? extends bf.com.misys.types.deceased.party.DeceasedRs> enumerateDeceasedRes(
    ) {
        return this._deceasedResList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof DeceasedRsList) {

            DeceasedRsList temp = (DeceasedRsList)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._deceasedResList != null) {
                if (temp._deceasedResList == null) return false;
                if (this._deceasedResList != temp._deceasedResList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._deceasedResList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._deceasedResList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._deceasedResList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._deceasedResList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._deceasedResList.equals(temp._deceasedResList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._deceasedResList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._deceasedResList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._deceasedResList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._deceasedResList);
                    }
                }
            } else if (temp._deceasedResList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getDeceasedRes.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.com.misys.types.deceased.party.DeceasedRs at the given
     * index
     */
    public bf.com.misys.types.deceased.party.DeceasedRs getDeceasedRes(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._deceasedResList.size()) {
            throw new IndexOutOfBoundsException("getDeceasedRes: Index value '" + index + "' not in range [0.." + (this._deceasedResList.size() - 1) + "]");
        }

        return (bf.com.misys.types.deceased.party.DeceasedRs) _deceasedResList.get(index);
    }

    /**
     * Method getDeceasedRes.Returns the contents of the collection
     * in an Array.  <p>Note:  Just in case the collection contents
     * are changing in another thread, we pass a 0-length Array of
     * the correct type into the API call.  This way we <i>know</i>
     * that the Array returned is of exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.com.misys.types.deceased.party.DeceasedRs[] getDeceasedRes(
    ) {
        bf.com.misys.types.deceased.party.DeceasedRs[] array = new bf.com.misys.types.deceased.party.DeceasedRs[0];
        return (bf.com.misys.types.deceased.party.DeceasedRs[]) this._deceasedResList.toArray(array);
    }

    /**
     * Method getDeceasedResCount.
     * 
     * @return the size of this collection
     */
    public int getDeceasedResCount(
    ) {
        return this._deceasedResList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_deceasedResList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_deceasedResList)) {
           result = 37 * result + _deceasedResList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_deceasedResList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllDeceasedRes(
    ) {
        this._deceasedResList.clear();
    }

    /**
     * Method removeDeceasedRes.
     * 
     * @param vDeceasedRes
     * @return true if the object was removed from the collection.
     */
    public boolean removeDeceasedRes(
            final bf.com.misys.types.deceased.party.DeceasedRs vDeceasedRes) {
        boolean removed = _deceasedResList.remove(vDeceasedRes);
        return removed;
    }

    /**
     * Method removeDeceasedResAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.com.misys.types.deceased.party.DeceasedRs removeDeceasedResAt(
            final int index) {
        java.lang.Object obj = this._deceasedResList.remove(index);
        return (bf.com.misys.types.deceased.party.DeceasedRs) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vDeceasedRes
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setDeceasedRes(
            final int index,
            final bf.com.misys.types.deceased.party.DeceasedRs vDeceasedRes)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._deceasedResList.size()) {
            throw new IndexOutOfBoundsException("setDeceasedRes: Index value '" + index + "' not in range [0.." + (this._deceasedResList.size() - 1) + "]");
        }

        this._deceasedResList.set(index, vDeceasedRes);
    }

    /**
     * 
     * 
     * @param vDeceasedResArray
     */
    public void setDeceasedRes(
            final bf.com.misys.types.deceased.party.DeceasedRs[] vDeceasedResArray) {
        //-- copy array
        _deceasedResList.clear();

        for (int i = 0; i < vDeceasedResArray.length; i++) {
                this._deceasedResList.add(vDeceasedResArray[i]);
        }
    }

    /**
     * Method unmarshalDeceasedRsList.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.deceased.party.DeceasedRsList
     */
    public static bf.com.misys.types.deceased.party.DeceasedRsList unmarshalDeceasedRsList(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.deceased.party.DeceasedRsList) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.deceased.party.DeceasedRsList.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
