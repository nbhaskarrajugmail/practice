/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.deceased.party;

/**
 * Class DeceasedRs.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class DeceasedRs implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _ALHAFIZADT.
     */
    private java.lang.String _ALHAFIZADT;

    /**
     * Field _ALHAFIZANO.
     */
    private java.lang.String _ALHAFIZANO;

    /**
     * Field _ALHAFIZASRC.
     */
    private java.lang.String _ALHAFIZASRC;

    /**
     * Field _APPROVED.
     */
    private java.lang.String _APPROVED;

    /**
     * Field _APPROVEDDT.
     */
    private java.lang.String _APPROVEDDT;

    /**
     * Field _APPROVERID.
     */
    private java.lang.String _APPROVERID;

    /**
     * Field _BORROWERNAME.
     */
    private java.lang.String _BORROWERNAME;

    /**
     * Field _BORROWERNATID.
     */
    private java.lang.String _BORROWERNATID;

    /**
     * Field _DAETHDATE.
     */
    private java.lang.String _DAETHDATE;

    /**
     * Field _DLBATCHDT.
     */
    private java.lang.String _DLBATCHDT;

    /**
     * Field _DLBATCHNO.
     */
    private java.lang.String _DLBATCHNO;

    /**
     * Field _boID.
     */
    private java.lang.String _boID;

    /**
     * Field _LOANBR.
     */
    private java.lang.String _LOANBR;

    /**
     * Field _LOANPLACE.
     */
    private java.lang.String _LOANPLACE;

    /**
     * Field _OUTSTANDINGAMT.
     */
    private java.lang.String _OUTSTANDINGAMT;

    /**
     * Field _REFENDDT.
     */
    private java.lang.String _REFENDDT;

    /**
     * Field _REFNO.
     */
    private java.lang.String _REFNO;

    /**
     * Field _REFSTARTDT.
     */
    private java.lang.String _REFSTARTDT;

    /**
     * Field _REGDATE.
     */
    private java.lang.String _REGDATE;

    /**
     * Field _REJREASON.
     */
    private java.lang.String _REJREASON;

    /**
     * Field _REMARKS.
     */
    private java.lang.String _REMARKS;

    /**
     * Field _REPCONTACNO.
     */
    private java.lang.String _REPCONTACNO;

    /**
     * Field _REPFULLNAME.
     */
    private java.lang.String _REPFULLNAME;

    /**
     * Field _REPNATID.
     */
    private java.lang.String _REPNATID;

    /**
     * Field _ULDT.
     */
    private java.lang.String _ULDT;

    /**
     * Field _ULSTATUS.
     */
    private java.lang.String _ULSTATUS;

    /**
     * Field _UPUSERID.
     */
    private java.lang.String _UPUSERID;

    /**
     * Field _VERSIONNUM.
     */
    private java.lang.String _VERSIONNUM;


      //----------------/
     //- Constructors -/
    //----------------/

    public DeceasedRs() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof DeceasedRs) {

            DeceasedRs temp = (DeceasedRs)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._ALHAFIZADT != null) {
                if (temp._ALHAFIZADT == null) return false;
                if (this._ALHAFIZADT != temp._ALHAFIZADT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ALHAFIZADT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ALHAFIZADT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZADT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZADT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ALHAFIZADT.equals(temp._ALHAFIZADT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZADT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZADT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZADT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZADT);
                    }
                }
            } else if (temp._ALHAFIZADT != null)
                return false;
            if (this._ALHAFIZANO != null) {
                if (temp._ALHAFIZANO == null) return false;
                if (this._ALHAFIZANO != temp._ALHAFIZANO) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ALHAFIZANO);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ALHAFIZANO);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZANO); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZANO); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ALHAFIZANO.equals(temp._ALHAFIZANO)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZANO);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZANO);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZANO);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZANO);
                    }
                }
            } else if (temp._ALHAFIZANO != null)
                return false;
            if (this._ALHAFIZASRC != null) {
                if (temp._ALHAFIZASRC == null) return false;
                if (this._ALHAFIZASRC != temp._ALHAFIZASRC) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ALHAFIZASRC);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ALHAFIZASRC);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZASRC); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZASRC); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ALHAFIZASRC.equals(temp._ALHAFIZASRC)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZASRC);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZASRC);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ALHAFIZASRC);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ALHAFIZASRC);
                    }
                }
            } else if (temp._ALHAFIZASRC != null)
                return false;
            if (this._APPROVED != null) {
                if (temp._APPROVED == null) return false;
                if (this._APPROVED != temp._APPROVED) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._APPROVED);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._APPROVED);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVED); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVED); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._APPROVED.equals(temp._APPROVED)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVED);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVED);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVED);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVED);
                    }
                }
            } else if (temp._APPROVED != null)
                return false;
            if (this._APPROVEDDT != null) {
                if (temp._APPROVEDDT == null) return false;
                if (this._APPROVEDDT != temp._APPROVEDDT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._APPROVEDDT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._APPROVEDDT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVEDDT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVEDDT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._APPROVEDDT.equals(temp._APPROVEDDT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVEDDT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVEDDT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVEDDT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVEDDT);
                    }
                }
            } else if (temp._APPROVEDDT != null)
                return false;
            if (this._APPROVERID != null) {
                if (temp._APPROVERID == null) return false;
                if (this._APPROVERID != temp._APPROVERID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._APPROVERID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._APPROVERID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVERID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVERID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._APPROVERID.equals(temp._APPROVERID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVERID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVERID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._APPROVERID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._APPROVERID);
                    }
                }
            } else if (temp._APPROVERID != null)
                return false;
            if (this._BORROWERNAME != null) {
                if (temp._BORROWERNAME == null) return false;
                if (this._BORROWERNAME != temp._BORROWERNAME) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._BORROWERNAME);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._BORROWERNAME);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNAME); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNAME); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._BORROWERNAME.equals(temp._BORROWERNAME)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNAME);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNAME);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNAME);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNAME);
                    }
                }
            } else if (temp._BORROWERNAME != null)
                return false;
            if (this._BORROWERNATID != null) {
                if (temp._BORROWERNATID == null) return false;
                if (this._BORROWERNATID != temp._BORROWERNATID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._BORROWERNATID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._BORROWERNATID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNATID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNATID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._BORROWERNATID.equals(temp._BORROWERNATID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNATID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNATID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._BORROWERNATID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._BORROWERNATID);
                    }
                }
            } else if (temp._BORROWERNATID != null)
                return false;
            if (this._DAETHDATE != null) {
                if (temp._DAETHDATE == null) return false;
                if (this._DAETHDATE != temp._DAETHDATE) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._DAETHDATE);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._DAETHDATE);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DAETHDATE); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DAETHDATE); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._DAETHDATE.equals(temp._DAETHDATE)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DAETHDATE);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DAETHDATE);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DAETHDATE);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DAETHDATE);
                    }
                }
            } else if (temp._DAETHDATE != null)
                return false;
            if (this._DLBATCHDT != null) {
                if (temp._DLBATCHDT == null) return false;
                if (this._DLBATCHDT != temp._DLBATCHDT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._DLBATCHDT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._DLBATCHDT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHDT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHDT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._DLBATCHDT.equals(temp._DLBATCHDT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHDT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHDT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHDT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHDT);
                    }
                }
            } else if (temp._DLBATCHDT != null)
                return false;
            if (this._DLBATCHNO != null) {
                if (temp._DLBATCHNO == null) return false;
                if (this._DLBATCHNO != temp._DLBATCHNO) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._DLBATCHNO);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._DLBATCHNO);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHNO); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHNO); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._DLBATCHNO.equals(temp._DLBATCHNO)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHNO);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHNO);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._DLBATCHNO);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._DLBATCHNO);
                    }
                }
            } else if (temp._DLBATCHNO != null)
                return false;
            if (this._boID != null) {
                if (temp._boID == null) return false;
                if (this._boID != temp._boID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._boID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._boID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._boID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._boID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._boID.equals(temp._boID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._boID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._boID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._boID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._boID);
                    }
                }
            } else if (temp._boID != null)
                return false;
            if (this._LOANBR != null) {
                if (temp._LOANBR == null) return false;
                if (this._LOANBR != temp._LOANBR) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._LOANBR);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._LOANBR);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANBR); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANBR); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._LOANBR.equals(temp._LOANBR)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANBR);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANBR);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANBR);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANBR);
                    }
                }
            } else if (temp._LOANBR != null)
                return false;
            if (this._LOANPLACE != null) {
                if (temp._LOANPLACE == null) return false;
                if (this._LOANPLACE != temp._LOANPLACE) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._LOANPLACE);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._LOANPLACE);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANPLACE); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANPLACE); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._LOANPLACE.equals(temp._LOANPLACE)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANPLACE);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANPLACE);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._LOANPLACE);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._LOANPLACE);
                    }
                }
            } else if (temp._LOANPLACE != null)
                return false;
            if (this._OUTSTANDINGAMT != null) {
                if (temp._OUTSTANDINGAMT == null) return false;
                if (this._OUTSTANDINGAMT != temp._OUTSTANDINGAMT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._OUTSTANDINGAMT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._OUTSTANDINGAMT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._OUTSTANDINGAMT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._OUTSTANDINGAMT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._OUTSTANDINGAMT.equals(temp._OUTSTANDINGAMT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._OUTSTANDINGAMT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._OUTSTANDINGAMT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._OUTSTANDINGAMT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._OUTSTANDINGAMT);
                    }
                }
            } else if (temp._OUTSTANDINGAMT != null)
                return false;
            if (this._REFENDDT != null) {
                if (temp._REFENDDT == null) return false;
                if (this._REFENDDT != temp._REFENDDT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REFENDDT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REFENDDT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFENDDT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFENDDT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REFENDDT.equals(temp._REFENDDT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFENDDT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFENDDT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFENDDT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFENDDT);
                    }
                }
            } else if (temp._REFENDDT != null)
                return false;
            if (this._REFNO != null) {
                if (temp._REFNO == null) return false;
                if (this._REFNO != temp._REFNO) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REFNO);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REFNO);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFNO); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFNO); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REFNO.equals(temp._REFNO)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFNO);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFNO);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFNO);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFNO);
                    }
                }
            } else if (temp._REFNO != null)
                return false;
            if (this._REFSTARTDT != null) {
                if (temp._REFSTARTDT == null) return false;
                if (this._REFSTARTDT != temp._REFSTARTDT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REFSTARTDT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REFSTARTDT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFSTARTDT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFSTARTDT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REFSTARTDT.equals(temp._REFSTARTDT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFSTARTDT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFSTARTDT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REFSTARTDT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REFSTARTDT);
                    }
                }
            } else if (temp._REFSTARTDT != null)
                return false;
            if (this._REGDATE != null) {
                if (temp._REGDATE == null) return false;
                if (this._REGDATE != temp._REGDATE) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REGDATE);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REGDATE);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REGDATE); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REGDATE); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REGDATE.equals(temp._REGDATE)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REGDATE);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REGDATE);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REGDATE);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REGDATE);
                    }
                }
            } else if (temp._REGDATE != null)
                return false;
            if (this._REJREASON != null) {
                if (temp._REJREASON == null) return false;
                if (this._REJREASON != temp._REJREASON) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REJREASON);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REJREASON);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REJREASON); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REJREASON); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REJREASON.equals(temp._REJREASON)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REJREASON);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REJREASON);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REJREASON);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REJREASON);
                    }
                }
            } else if (temp._REJREASON != null)
                return false;
            if (this._REMARKS != null) {
                if (temp._REMARKS == null) return false;
                if (this._REMARKS != temp._REMARKS) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REMARKS);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REMARKS);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REMARKS); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REMARKS); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REMARKS.equals(temp._REMARKS)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REMARKS);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REMARKS);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REMARKS);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REMARKS);
                    }
                }
            } else if (temp._REMARKS != null)
                return false;
            if (this._REPCONTACNO != null) {
                if (temp._REPCONTACNO == null) return false;
                if (this._REPCONTACNO != temp._REPCONTACNO) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REPCONTACNO);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REPCONTACNO);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPCONTACNO); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPCONTACNO); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REPCONTACNO.equals(temp._REPCONTACNO)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPCONTACNO);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPCONTACNO);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPCONTACNO);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPCONTACNO);
                    }
                }
            } else if (temp._REPCONTACNO != null)
                return false;
            if (this._REPFULLNAME != null) {
                if (temp._REPFULLNAME == null) return false;
                if (this._REPFULLNAME != temp._REPFULLNAME) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REPFULLNAME);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REPFULLNAME);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPFULLNAME); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPFULLNAME); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REPFULLNAME.equals(temp._REPFULLNAME)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPFULLNAME);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPFULLNAME);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPFULLNAME);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPFULLNAME);
                    }
                }
            } else if (temp._REPFULLNAME != null)
                return false;
            if (this._REPNATID != null) {
                if (temp._REPNATID == null) return false;
                if (this._REPNATID != temp._REPNATID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._REPNATID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._REPNATID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPNATID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPNATID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._REPNATID.equals(temp._REPNATID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPNATID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPNATID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._REPNATID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._REPNATID);
                    }
                }
            } else if (temp._REPNATID != null)
                return false;
            if (this._ULDT != null) {
                if (temp._ULDT == null) return false;
                if (this._ULDT != temp._ULDT) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ULDT);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ULDT);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULDT); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULDT); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ULDT.equals(temp._ULDT)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULDT);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULDT);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULDT);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULDT);
                    }
                }
            } else if (temp._ULDT != null)
                return false;
            if (this._ULSTATUS != null) {
                if (temp._ULSTATUS == null) return false;
                if (this._ULSTATUS != temp._ULSTATUS) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ULSTATUS);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ULSTATUS);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULSTATUS); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULSTATUS); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ULSTATUS.equals(temp._ULSTATUS)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULSTATUS);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULSTATUS);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ULSTATUS);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ULSTATUS);
                    }
                }
            } else if (temp._ULSTATUS != null)
                return false;
            if (this._UPUSERID != null) {
                if (temp._UPUSERID == null) return false;
                if (this._UPUSERID != temp._UPUSERID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._UPUSERID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._UPUSERID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._UPUSERID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._UPUSERID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._UPUSERID.equals(temp._UPUSERID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._UPUSERID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._UPUSERID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._UPUSERID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._UPUSERID);
                    }
                }
            } else if (temp._UPUSERID != null)
                return false;
            if (this._VERSIONNUM != null) {
                if (temp._VERSIONNUM == null) return false;
                if (this._VERSIONNUM != temp._VERSIONNUM) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._VERSIONNUM);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._VERSIONNUM);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._VERSIONNUM); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._VERSIONNUM); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._VERSIONNUM.equals(temp._VERSIONNUM)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._VERSIONNUM);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._VERSIONNUM);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._VERSIONNUM);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._VERSIONNUM);
                    }
                }
            } else if (temp._VERSIONNUM != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'ALHAFIZADT'.
     * 
     * @return the value of field 'ALHAFIZADT'.
     */
    public java.lang.String getALHAFIZADT(
    ) {
        return this._ALHAFIZADT;
    }

    /**
     * Returns the value of field 'ALHAFIZANO'.
     * 
     * @return the value of field 'ALHAFIZANO'.
     */
    public java.lang.String getALHAFIZANO(
    ) {
        return this._ALHAFIZANO;
    }

    /**
     * Returns the value of field 'ALHAFIZASRC'.
     * 
     * @return the value of field 'ALHAFIZASRC'.
     */
    public java.lang.String getALHAFIZASRC(
    ) {
        return this._ALHAFIZASRC;
    }

    /**
     * Returns the value of field 'APPROVED'.
     * 
     * @return the value of field 'APPROVED'.
     */
    public java.lang.String getAPPROVED(
    ) {
        return this._APPROVED;
    }

    /**
     * Returns the value of field 'APPROVEDDT'.
     * 
     * @return the value of field 'APPROVEDDT'.
     */
    public java.lang.String getAPPROVEDDT(
    ) {
        return this._APPROVEDDT;
    }

    /**
     * Returns the value of field 'APPROVERID'.
     * 
     * @return the value of field 'APPROVERID'.
     */
    public java.lang.String getAPPROVERID(
    ) {
        return this._APPROVERID;
    }

    /**
     * Returns the value of field 'BORROWERNAME'.
     * 
     * @return the value of field 'BORROWERNAME'.
     */
    public java.lang.String getBORROWERNAME(
    ) {
        return this._BORROWERNAME;
    }

    /**
     * Returns the value of field 'BORROWERNATID'.
     * 
     * @return the value of field 'BORROWERNATID'.
     */
    public java.lang.String getBORROWERNATID(
    ) {
        return this._BORROWERNATID;
    }

    /**
     * Returns the value of field 'boID'.
     * 
     * @return the value of field 'BoID'.
     */
    public java.lang.String getBoID(
    ) {
        return this._boID;
    }

    /**
     * Returns the value of field 'DAETHDATE'.
     * 
     * @return the value of field 'DAETHDATE'.
     */
    public java.lang.String getDAETHDATE(
    ) {
        return this._DAETHDATE;
    }

    /**
     * Returns the value of field 'DLBATCHDT'.
     * 
     * @return the value of field 'DLBATCHDT'.
     */
    public java.lang.String getDLBATCHDT(
    ) {
        return this._DLBATCHDT;
    }

    /**
     * Returns the value of field 'DLBATCHNO'.
     * 
     * @return the value of field 'DLBATCHNO'.
     */
    public java.lang.String getDLBATCHNO(
    ) {
        return this._DLBATCHNO;
    }

    /**
     * Returns the value of field 'LOANBR'.
     * 
     * @return the value of field 'LOANBR'.
     */
    public java.lang.String getLOANBR(
    ) {
        return this._LOANBR;
    }

    /**
     * Returns the value of field 'LOANPLACE'.
     * 
     * @return the value of field 'LOANPLACE'.
     */
    public java.lang.String getLOANPLACE(
    ) {
        return this._LOANPLACE;
    }

    /**
     * Returns the value of field 'OUTSTANDINGAMT'.
     * 
     * @return the value of field 'OUTSTANDINGAMT'.
     */
    public java.lang.String getOUTSTANDINGAMT(
    ) {
        return this._OUTSTANDINGAMT;
    }

    /**
     * Returns the value of field 'REFENDDT'.
     * 
     * @return the value of field 'REFENDDT'.
     */
    public java.lang.String getREFENDDT(
    ) {
        return this._REFENDDT;
    }

    /**
     * Returns the value of field 'REFNO'.
     * 
     * @return the value of field 'REFNO'.
     */
    public java.lang.String getREFNO(
    ) {
        return this._REFNO;
    }

    /**
     * Returns the value of field 'REFSTARTDT'.
     * 
     * @return the value of field 'REFSTARTDT'.
     */
    public java.lang.String getREFSTARTDT(
    ) {
        return this._REFSTARTDT;
    }

    /**
     * Returns the value of field 'REGDATE'.
     * 
     * @return the value of field 'REGDATE'.
     */
    public java.lang.String getREGDATE(
    ) {
        return this._REGDATE;
    }

    /**
     * Returns the value of field 'REJREASON'.
     * 
     * @return the value of field 'REJREASON'.
     */
    public java.lang.String getREJREASON(
    ) {
        return this._REJREASON;
    }

    /**
     * Returns the value of field 'REMARKS'.
     * 
     * @return the value of field 'REMARKS'.
     */
    public java.lang.String getREMARKS(
    ) {
        return this._REMARKS;
    }

    /**
     * Returns the value of field 'REPCONTACNO'.
     * 
     * @return the value of field 'REPCONTACNO'.
     */
    public java.lang.String getREPCONTACNO(
    ) {
        return this._REPCONTACNO;
    }

    /**
     * Returns the value of field 'REPFULLNAME'.
     * 
     * @return the value of field 'REPFULLNAME'.
     */
    public java.lang.String getREPFULLNAME(
    ) {
        return this._REPFULLNAME;
    }

    /**
     * Returns the value of field 'REPNATID'.
     * 
     * @return the value of field 'REPNATID'.
     */
    public java.lang.String getREPNATID(
    ) {
        return this._REPNATID;
    }

    /**
     * Returns the value of field 'ULDT'.
     * 
     * @return the value of field 'ULDT'.
     */
    public java.lang.String getULDT(
    ) {
        return this._ULDT;
    }

    /**
     * Returns the value of field 'ULSTATUS'.
     * 
     * @return the value of field 'ULSTATUS'.
     */
    public java.lang.String getULSTATUS(
    ) {
        return this._ULSTATUS;
    }

    /**
     * Returns the value of field 'UPUSERID'.
     * 
     * @return the value of field 'UPUSERID'.
     */
    public java.lang.String getUPUSERID(
    ) {
        return this._UPUSERID;
    }

    /**
     * Returns the value of field 'VERSIONNUM'.
     * 
     * @return the value of field 'VERSIONNUM'.
     */
    public java.lang.String getVERSIONNUM(
    ) {
        return this._VERSIONNUM;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_ALHAFIZADT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ALHAFIZADT)) {
           result = 37 * result + _ALHAFIZADT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ALHAFIZADT);
        }
        if (_ALHAFIZANO != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ALHAFIZANO)) {
           result = 37 * result + _ALHAFIZANO.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ALHAFIZANO);
        }
        if (_ALHAFIZASRC != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ALHAFIZASRC)) {
           result = 37 * result + _ALHAFIZASRC.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ALHAFIZASRC);
        }
        if (_APPROVED != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_APPROVED)) {
           result = 37 * result + _APPROVED.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_APPROVED);
        }
        if (_APPROVEDDT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_APPROVEDDT)) {
           result = 37 * result + _APPROVEDDT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_APPROVEDDT);
        }
        if (_APPROVERID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_APPROVERID)) {
           result = 37 * result + _APPROVERID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_APPROVERID);
        }
        if (_BORROWERNAME != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_BORROWERNAME)) {
           result = 37 * result + _BORROWERNAME.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_BORROWERNAME);
        }
        if (_BORROWERNATID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_BORROWERNATID)) {
           result = 37 * result + _BORROWERNATID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_BORROWERNATID);
        }
        if (_DAETHDATE != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_DAETHDATE)) {
           result = 37 * result + _DAETHDATE.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_DAETHDATE);
        }
        if (_DLBATCHDT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_DLBATCHDT)) {
           result = 37 * result + _DLBATCHDT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_DLBATCHDT);
        }
        if (_DLBATCHNO != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_DLBATCHNO)) {
           result = 37 * result + _DLBATCHNO.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_DLBATCHNO);
        }
        if (_boID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_boID)) {
           result = 37 * result + _boID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_boID);
        }
        if (_LOANBR != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_LOANBR)) {
           result = 37 * result + _LOANBR.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_LOANBR);
        }
        if (_LOANPLACE != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_LOANPLACE)) {
           result = 37 * result + _LOANPLACE.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_LOANPLACE);
        }
        if (_OUTSTANDINGAMT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_OUTSTANDINGAMT)) {
           result = 37 * result + _OUTSTANDINGAMT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_OUTSTANDINGAMT);
        }
        if (_REFENDDT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REFENDDT)) {
           result = 37 * result + _REFENDDT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REFENDDT);
        }
        if (_REFNO != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REFNO)) {
           result = 37 * result + _REFNO.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REFNO);
        }
        if (_REFSTARTDT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REFSTARTDT)) {
           result = 37 * result + _REFSTARTDT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REFSTARTDT);
        }
        if (_REGDATE != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REGDATE)) {
           result = 37 * result + _REGDATE.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REGDATE);
        }
        if (_REJREASON != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REJREASON)) {
           result = 37 * result + _REJREASON.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REJREASON);
        }
        if (_REMARKS != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REMARKS)) {
           result = 37 * result + _REMARKS.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REMARKS);
        }
        if (_REPCONTACNO != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REPCONTACNO)) {
           result = 37 * result + _REPCONTACNO.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REPCONTACNO);
        }
        if (_REPFULLNAME != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REPFULLNAME)) {
           result = 37 * result + _REPFULLNAME.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REPFULLNAME);
        }
        if (_REPNATID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_REPNATID)) {
           result = 37 * result + _REPNATID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_REPNATID);
        }
        if (_ULDT != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ULDT)) {
           result = 37 * result + _ULDT.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ULDT);
        }
        if (_ULSTATUS != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ULSTATUS)) {
           result = 37 * result + _ULSTATUS.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ULSTATUS);
        }
        if (_UPUSERID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_UPUSERID)) {
           result = 37 * result + _UPUSERID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_UPUSERID);
        }
        if (_VERSIONNUM != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_VERSIONNUM)) {
           result = 37 * result + _VERSIONNUM.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_VERSIONNUM);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'ALHAFIZADT'.
     * 
     * @param ALHAFIZADT the value of field 'ALHAFIZADT'.
     */
    public void setALHAFIZADT(
            final java.lang.String ALHAFIZADT) {
        this._ALHAFIZADT = ALHAFIZADT;
    }

    /**
     * Sets the value of field 'ALHAFIZANO'.
     * 
     * @param ALHAFIZANO the value of field 'ALHAFIZANO'.
     */
    public void setALHAFIZANO(
            final java.lang.String ALHAFIZANO) {
        this._ALHAFIZANO = ALHAFIZANO;
    }

    /**
     * Sets the value of field 'ALHAFIZASRC'.
     * 
     * @param ALHAFIZASRC the value of field 'ALHAFIZASRC'.
     */
    public void setALHAFIZASRC(
            final java.lang.String ALHAFIZASRC) {
        this._ALHAFIZASRC = ALHAFIZASRC;
    }

    /**
     * Sets the value of field 'APPROVED'.
     * 
     * @param APPROVED the value of field 'APPROVED'.
     */
    public void setAPPROVED(
            final java.lang.String APPROVED) {
        this._APPROVED = APPROVED;
    }

    /**
     * Sets the value of field 'APPROVEDDT'.
     * 
     * @param APPROVEDDT the value of field 'APPROVEDDT'.
     */
    public void setAPPROVEDDT(
            final java.lang.String APPROVEDDT) {
        this._APPROVEDDT = APPROVEDDT;
    }

    /**
     * Sets the value of field 'APPROVERID'.
     * 
     * @param APPROVERID the value of field 'APPROVERID'.
     */
    public void setAPPROVERID(
            final java.lang.String APPROVERID) {
        this._APPROVERID = APPROVERID;
    }

    /**
     * Sets the value of field 'BORROWERNAME'.
     * 
     * @param BORROWERNAME the value of field 'BORROWERNAME'.
     */
    public void setBORROWERNAME(
            final java.lang.String BORROWERNAME) {
        this._BORROWERNAME = BORROWERNAME;
    }

    /**
     * Sets the value of field 'BORROWERNATID'.
     * 
     * @param BORROWERNATID the value of field 'BORROWERNATID'.
     */
    public void setBORROWERNATID(
            final java.lang.String BORROWERNATID) {
        this._BORROWERNATID = BORROWERNATID;
    }

    /**
     * Sets the value of field 'boID'.
     * 
     * @param boID the value of field 'boID'.
     */
    public void setBoID(
            final java.lang.String boID) {
        this._boID = boID;
    }

    /**
     * Sets the value of field 'DAETHDATE'.
     * 
     * @param DAETHDATE the value of field 'DAETHDATE'.
     */
    public void setDAETHDATE(
            final java.lang.String DAETHDATE) {
        this._DAETHDATE = DAETHDATE;
    }

    /**
     * Sets the value of field 'DLBATCHDT'.
     * 
     * @param DLBATCHDT the value of field 'DLBATCHDT'.
     */
    public void setDLBATCHDT(
            final java.lang.String DLBATCHDT) {
        this._DLBATCHDT = DLBATCHDT;
    }

    /**
     * Sets the value of field 'DLBATCHNO'.
     * 
     * @param DLBATCHNO the value of field 'DLBATCHNO'.
     */
    public void setDLBATCHNO(
            final java.lang.String DLBATCHNO) {
        this._DLBATCHNO = DLBATCHNO;
    }

    /**
     * Sets the value of field 'LOANBR'.
     * 
     * @param LOANBR the value of field 'LOANBR'.
     */
    public void setLOANBR(
            final java.lang.String LOANBR) {
        this._LOANBR = LOANBR;
    }

    /**
     * Sets the value of field 'LOANPLACE'.
     * 
     * @param LOANPLACE the value of field 'LOANPLACE'.
     */
    public void setLOANPLACE(
            final java.lang.String LOANPLACE) {
        this._LOANPLACE = LOANPLACE;
    }

    /**
     * Sets the value of field 'OUTSTANDINGAMT'.
     * 
     * @param OUTSTANDINGAMT the value of field 'OUTSTANDINGAMT'.
     */
    public void setOUTSTANDINGAMT(
            final java.lang.String OUTSTANDINGAMT) {
        this._OUTSTANDINGAMT = OUTSTANDINGAMT;
    }

    /**
     * Sets the value of field 'REFENDDT'.
     * 
     * @param REFENDDT the value of field 'REFENDDT'.
     */
    public void setREFENDDT(
            final java.lang.String REFENDDT) {
        this._REFENDDT = REFENDDT;
    }

    /**
     * Sets the value of field 'REFNO'.
     * 
     * @param REFNO the value of field 'REFNO'.
     */
    public void setREFNO(
            final java.lang.String REFNO) {
        this._REFNO = REFNO;
    }

    /**
     * Sets the value of field 'REFSTARTDT'.
     * 
     * @param REFSTARTDT the value of field 'REFSTARTDT'.
     */
    public void setREFSTARTDT(
            final java.lang.String REFSTARTDT) {
        this._REFSTARTDT = REFSTARTDT;
    }

    /**
     * Sets the value of field 'REGDATE'.
     * 
     * @param REGDATE the value of field 'REGDATE'.
     */
    public void setREGDATE(
            final java.lang.String REGDATE) {
        this._REGDATE = REGDATE;
    }

    /**
     * Sets the value of field 'REJREASON'.
     * 
     * @param REJREASON the value of field 'REJREASON'.
     */
    public void setREJREASON(
            final java.lang.String REJREASON) {
        this._REJREASON = REJREASON;
    }

    /**
     * Sets the value of field 'REMARKS'.
     * 
     * @param REMARKS the value of field 'REMARKS'.
     */
    public void setREMARKS(
            final java.lang.String REMARKS) {
        this._REMARKS = REMARKS;
    }

    /**
     * Sets the value of field 'REPCONTACNO'.
     * 
     * @param REPCONTACNO the value of field 'REPCONTACNO'.
     */
    public void setREPCONTACNO(
            final java.lang.String REPCONTACNO) {
        this._REPCONTACNO = REPCONTACNO;
    }

    /**
     * Sets the value of field 'REPFULLNAME'.
     * 
     * @param REPFULLNAME the value of field 'REPFULLNAME'.
     */
    public void setREPFULLNAME(
            final java.lang.String REPFULLNAME) {
        this._REPFULLNAME = REPFULLNAME;
    }

    /**
     * Sets the value of field 'REPNATID'.
     * 
     * @param REPNATID the value of field 'REPNATID'.
     */
    public void setREPNATID(
            final java.lang.String REPNATID) {
        this._REPNATID = REPNATID;
    }

    /**
     * Sets the value of field 'ULDT'.
     * 
     * @param ULDT the value of field 'ULDT'.
     */
    public void setULDT(
            final java.lang.String ULDT) {
        this._ULDT = ULDT;
    }

    /**
     * Sets the value of field 'ULSTATUS'.
     * 
     * @param ULSTATUS the value of field 'ULSTATUS'.
     */
    public void setULSTATUS(
            final java.lang.String ULSTATUS) {
        this._ULSTATUS = ULSTATUS;
    }

    /**
     * Sets the value of field 'UPUSERID'.
     * 
     * @param UPUSERID the value of field 'UPUSERID'.
     */
    public void setUPUSERID(
            final java.lang.String UPUSERID) {
        this._UPUSERID = UPUSERID;
    }

    /**
     * Sets the value of field 'VERSIONNUM'.
     * 
     * @param VERSIONNUM the value of field 'VERSIONNUM'.
     */
    public void setVERSIONNUM(
            final java.lang.String VERSIONNUM) {
        this._VERSIONNUM = VERSIONNUM;
    }

    /**
     * Method unmarshalDeceasedRs.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.deceased.party.DeceasedRs
     */
    public static bf.com.misys.types.deceased.party.DeceasedRs unmarshalDeceasedRs(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.deceased.party.DeceasedRs) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.deceased.party.DeceasedRs.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
