/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.notification;

/**
 * Class BillInvoiceDtlRs.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class BillInvoiceDtlRs implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _billInvoiceDtlRsList.
     */
    private java.util.Vector<bf.com.misys.types.sadad.notification.BillInvoiceRs> _billInvoiceDtlRsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BillInvoiceDtlRs() {
        super();
        this._billInvoiceDtlRsList = new java.util.Vector<bf.com.misys.types.sadad.notification.BillInvoiceRs>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vBillInvoiceDtlRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addBillInvoiceDtlRs(
            final bf.com.misys.types.sadad.notification.BillInvoiceRs vBillInvoiceDtlRs)
    throws java.lang.IndexOutOfBoundsException {
        this._billInvoiceDtlRsList.addElement(vBillInvoiceDtlRs);
    }

    /**
     * 
     * 
     * @param index
     * @param vBillInvoiceDtlRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addBillInvoiceDtlRs(
            final int index,
            final bf.com.misys.types.sadad.notification.BillInvoiceRs vBillInvoiceDtlRs)
    throws java.lang.IndexOutOfBoundsException {
        this._billInvoiceDtlRsList.add(index, vBillInvoiceDtlRs);
    }

    /**
     * Method enumerateBillInvoiceDtlRs.
     * 
     * @return an Enumeration over all
     * bf.com.misys.types.sadad.notification.BillInvoiceRs elements
     */
    public java.util.Enumeration<? extends bf.com.misys.types.sadad.notification.BillInvoiceRs> enumerateBillInvoiceDtlRs(
    ) {
        return this._billInvoiceDtlRsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof BillInvoiceDtlRs) {

            BillInvoiceDtlRs temp = (BillInvoiceDtlRs)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._billInvoiceDtlRsList != null) {
                if (temp._billInvoiceDtlRsList == null) return false;
                if (this._billInvoiceDtlRsList != temp._billInvoiceDtlRsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billInvoiceDtlRsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billInvoiceDtlRsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billInvoiceDtlRsList.equals(temp._billInvoiceDtlRsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRsList);
                    }
                }
            } else if (temp._billInvoiceDtlRsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getBillInvoiceDtlRs.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.com.misys.types.sadad.notification.BillInvoiceRs at the
     * given index
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRs getBillInvoiceDtlRs(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._billInvoiceDtlRsList.size()) {
            throw new IndexOutOfBoundsException("getBillInvoiceDtlRs: Index value '" + index + "' not in range [0.." + (this._billInvoiceDtlRsList.size() - 1) + "]");
        }

        return (bf.com.misys.types.sadad.notification.BillInvoiceRs) _billInvoiceDtlRsList.get(index);
    }

    /**
     * Method getBillInvoiceDtlRs.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRs[] getBillInvoiceDtlRs(
    ) {
        bf.com.misys.types.sadad.notification.BillInvoiceRs[] array = new bf.com.misys.types.sadad.notification.BillInvoiceRs[0];
        return (bf.com.misys.types.sadad.notification.BillInvoiceRs[]) this._billInvoiceDtlRsList.toArray(array);
    }

    /**
     * Method getBillInvoiceDtlRsCount.
     * 
     * @return the size of this collection
     */
    public int getBillInvoiceDtlRsCount(
    ) {
        return this._billInvoiceDtlRsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_billInvoiceDtlRsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billInvoiceDtlRsList)) {
           result = 37 * result + _billInvoiceDtlRsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billInvoiceDtlRsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllBillInvoiceDtlRs(
    ) {
        this._billInvoiceDtlRsList.clear();
    }

    /**
     * Method removeBillInvoiceDtlRs.
     * 
     * @param vBillInvoiceDtlRs
     * @return true if the object was removed from the collection.
     */
    public boolean removeBillInvoiceDtlRs(
            final bf.com.misys.types.sadad.notification.BillInvoiceRs vBillInvoiceDtlRs) {
        boolean removed = _billInvoiceDtlRsList.remove(vBillInvoiceDtlRs);
        return removed;
    }

    /**
     * Method removeBillInvoiceDtlRsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRs removeBillInvoiceDtlRsAt(
            final int index) {
        java.lang.Object obj = this._billInvoiceDtlRsList.remove(index);
        return (bf.com.misys.types.sadad.notification.BillInvoiceRs) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vBillInvoiceDtlRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setBillInvoiceDtlRs(
            final int index,
            final bf.com.misys.types.sadad.notification.BillInvoiceRs vBillInvoiceDtlRs)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._billInvoiceDtlRsList.size()) {
            throw new IndexOutOfBoundsException("setBillInvoiceDtlRs: Index value '" + index + "' not in range [0.." + (this._billInvoiceDtlRsList.size() - 1) + "]");
        }

        this._billInvoiceDtlRsList.set(index, vBillInvoiceDtlRs);
    }

    /**
     * 
     * 
     * @param vBillInvoiceDtlRsArray
     */
    public void setBillInvoiceDtlRs(
            final bf.com.misys.types.sadad.notification.BillInvoiceRs[] vBillInvoiceDtlRsArray) {
        //-- copy array
        _billInvoiceDtlRsList.clear();

        for (int i = 0; i < vBillInvoiceDtlRsArray.length; i++) {
                this._billInvoiceDtlRsList.add(vBillInvoiceDtlRsArray[i]);
        }
    }

    /**
     * Method unmarshalBillInvoiceDtlRs.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.notification.BillInvoiceDtlRs
     */
    public static bf.com.misys.types.sadad.notification.BillInvoiceDtlRs unmarshalBillInvoiceDtlRs(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.notification.BillInvoiceDtlRs) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.notification.BillInvoiceDtlRs.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
