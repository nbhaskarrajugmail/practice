/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.notification;

/**
 * Class BillInvoiceDtlRq.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class BillInvoiceDtlRq implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _batchId.
     */
    private java.lang.String _batchId;

    /**
     * Field _successCount.
     */
    private java.lang.Integer _successCount;

    /**
     * Field _errorCount.
     */
    private java.lang.Integer _errorCount;

    /**
     * Field _billInvoiceDtlRqList.
     */
    private java.util.Vector<bf.com.misys.types.sadad.notification.BillInvoiceRq> _billInvoiceDtlRqList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BillInvoiceDtlRq() {
        super();
        this._billInvoiceDtlRqList = new java.util.Vector<bf.com.misys.types.sadad.notification.BillInvoiceRq>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vBillInvoiceDtlRq
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addBillInvoiceDtlRq(
            final bf.com.misys.types.sadad.notification.BillInvoiceRq vBillInvoiceDtlRq)
    throws java.lang.IndexOutOfBoundsException {
        this._billInvoiceDtlRqList.addElement(vBillInvoiceDtlRq);
    }

    /**
     * 
     * 
     * @param index
     * @param vBillInvoiceDtlRq
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addBillInvoiceDtlRq(
            final int index,
            final bf.com.misys.types.sadad.notification.BillInvoiceRq vBillInvoiceDtlRq)
    throws java.lang.IndexOutOfBoundsException {
        this._billInvoiceDtlRqList.add(index, vBillInvoiceDtlRq);
    }

    /**
     * Method enumerateBillInvoiceDtlRq.
     * 
     * @return an Enumeration over all
     * bf.com.misys.types.sadad.notification.BillInvoiceRq elements
     */
    public java.util.Enumeration<? extends bf.com.misys.types.sadad.notification.BillInvoiceRq> enumerateBillInvoiceDtlRq(
    ) {
        return this._billInvoiceDtlRqList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof BillInvoiceDtlRq) {

            BillInvoiceDtlRq temp = (BillInvoiceDtlRq)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._batchId != null) {
                if (temp._batchId == null) return false;
                if (this._batchId != temp._batchId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchId.equals(temp._batchId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchId);
                    }
                }
            } else if (temp._batchId != null)
                return false;
            if (this._successCount != null) {
                if (temp._successCount == null) return false;
                if (this._successCount != temp._successCount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._successCount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._successCount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._successCount.equals(temp._successCount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._successCount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._successCount);
                    }
                }
            } else if (temp._successCount != null)
                return false;
            if (this._errorCount != null) {
                if (temp._errorCount == null) return false;
                if (this._errorCount != temp._errorCount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._errorCount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._errorCount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._errorCount.equals(temp._errorCount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorCount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorCount);
                    }
                }
            } else if (temp._errorCount != null)
                return false;
            if (this._billInvoiceDtlRqList != null) {
                if (temp._billInvoiceDtlRqList == null) return false;
                if (this._billInvoiceDtlRqList != temp._billInvoiceDtlRqList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billInvoiceDtlRqList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billInvoiceDtlRqList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRqList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRqList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billInvoiceDtlRqList.equals(temp._billInvoiceDtlRqList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRqList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRqList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceDtlRqList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceDtlRqList);
                    }
                }
            } else if (temp._billInvoiceDtlRqList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'batchId'.
     * 
     * @return the value of field 'BatchId'.
     */
    public java.lang.String getBatchId(
    ) {
        return this._batchId;
    }

    /**
     * Method getBillInvoiceDtlRq.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.com.misys.types.sadad.notification.BillInvoiceRq at the
     * given index
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRq getBillInvoiceDtlRq(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._billInvoiceDtlRqList.size()) {
            throw new IndexOutOfBoundsException("getBillInvoiceDtlRq: Index value '" + index + "' not in range [0.." + (this._billInvoiceDtlRqList.size() - 1) + "]");
        }

        return (bf.com.misys.types.sadad.notification.BillInvoiceRq) _billInvoiceDtlRqList.get(index);
    }

    /**
     * Method getBillInvoiceDtlRq.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRq[] getBillInvoiceDtlRq(
    ) {
        bf.com.misys.types.sadad.notification.BillInvoiceRq[] array = new bf.com.misys.types.sadad.notification.BillInvoiceRq[0];
        return (bf.com.misys.types.sadad.notification.BillInvoiceRq[]) this._billInvoiceDtlRqList.toArray(array);
    }

    /**
     * Method getBillInvoiceDtlRqCount.
     * 
     * @return the size of this collection
     */
    public int getBillInvoiceDtlRqCount(
    ) {
        return this._billInvoiceDtlRqList.size();
    }

    /**
     * Returns the value of field 'errorCount'.
     * 
     * @return the value of field 'ErrorCount'.
     */
    public java.lang.Integer getErrorCount(
    ) {
        return this._errorCount;
    }

    /**
     * Returns the value of field 'successCount'.
     * 
     * @return the value of field 'SuccessCount'.
     */
    public java.lang.Integer getSuccessCount(
    ) {
        return this._successCount;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_batchId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchId)) {
           result = 37 * result + _batchId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchId);
        }
        if (_successCount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_successCount)) {
           result = 37 * result + _successCount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_successCount);
        }
        if (_errorCount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_errorCount)) {
           result = 37 * result + _errorCount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_errorCount);
        }
        if (_billInvoiceDtlRqList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billInvoiceDtlRqList)) {
           result = 37 * result + _billInvoiceDtlRqList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billInvoiceDtlRqList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllBillInvoiceDtlRq(
    ) {
        this._billInvoiceDtlRqList.clear();
    }

    /**
     * Method removeBillInvoiceDtlRq.
     * 
     * @param vBillInvoiceDtlRq
     * @return true if the object was removed from the collection.
     */
    public boolean removeBillInvoiceDtlRq(
            final bf.com.misys.types.sadad.notification.BillInvoiceRq vBillInvoiceDtlRq) {
        boolean removed = _billInvoiceDtlRqList.remove(vBillInvoiceDtlRq);
        return removed;
    }

    /**
     * Method removeBillInvoiceDtlRqAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.com.misys.types.sadad.notification.BillInvoiceRq removeBillInvoiceDtlRqAt(
            final int index) {
        java.lang.Object obj = this._billInvoiceDtlRqList.remove(index);
        return (bf.com.misys.types.sadad.notification.BillInvoiceRq) obj;
    }

    /**
     * Sets the value of field 'batchId'.
     * 
     * @param batchId the value of field 'batchId'.
     */
    public void setBatchId(
            final java.lang.String batchId) {
        this._batchId = batchId;
    }

    /**
     * 
     * 
     * @param index
     * @param vBillInvoiceDtlRq
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setBillInvoiceDtlRq(
            final int index,
            final bf.com.misys.types.sadad.notification.BillInvoiceRq vBillInvoiceDtlRq)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._billInvoiceDtlRqList.size()) {
            throw new IndexOutOfBoundsException("setBillInvoiceDtlRq: Index value '" + index + "' not in range [0.." + (this._billInvoiceDtlRqList.size() - 1) + "]");
        }

        this._billInvoiceDtlRqList.set(index, vBillInvoiceDtlRq);
    }

    /**
     * 
     * 
     * @param vBillInvoiceDtlRqArray
     */
    public void setBillInvoiceDtlRq(
            final bf.com.misys.types.sadad.notification.BillInvoiceRq[] vBillInvoiceDtlRqArray) {
        //-- copy array
        _billInvoiceDtlRqList.clear();

        for (int i = 0; i < vBillInvoiceDtlRqArray.length; i++) {
                this._billInvoiceDtlRqList.add(vBillInvoiceDtlRqArray[i]);
        }
    }

    /**
     * Sets the value of field 'errorCount'.
     * 
     * @param errorCount the value of field 'errorCount'.
     */
    public void setErrorCount(
            final java.lang.Integer errorCount) {
        this._errorCount = errorCount;
    }

    /**
     * Sets the value of field 'successCount'.
     * 
     * @param successCount the value of field 'successCount'.
     */
    public void setSuccessCount(
            final java.lang.Integer successCount) {
        this._successCount = successCount;
    }

    /**
     * Method unmarshalBillInvoiceDtlRq.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.notification.BillInvoiceDtlRq
     */
    public static bf.com.misys.types.sadad.notification.BillInvoiceDtlRq unmarshalBillInvoiceDtlRq(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.notification.BillInvoiceDtlRq) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.notification.BillInvoiceDtlRq.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
