/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.payment;

/**
 * Class POI_Type.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class POI_Type implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _POINum.
     */
    private java.lang.String _POINum;

    /**
     * Field _POIType.
     */
    private java.lang.String _POIType;


      //----------------/
     //- Constructors -/
    //----------------/

    public POI_Type() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof POI_Type) {

            POI_Type temp = (POI_Type)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._POINum != null) {
                if (temp._POINum == null) return false;
                if (this._POINum != temp._POINum) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._POINum);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._POINum);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POINum); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POINum); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._POINum.equals(temp._POINum)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POINum);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POINum);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POINum);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POINum);
                    }
                }
            } else if (temp._POINum != null)
                return false;
            if (this._POIType != null) {
                if (temp._POIType == null) return false;
                if (this._POIType != temp._POIType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._POIType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._POIType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POIType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POIType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._POIType.equals(temp._POIType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POIType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POIType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._POIType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._POIType);
                    }
                }
            } else if (temp._POIType != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'POINum'.
     * 
     * @return the value of field 'POINum'.
     */
    public java.lang.String getPOINum(
    ) {
        return this._POINum;
    }

    /**
     * Returns the value of field 'POIType'.
     * 
     * @return the value of field 'POIType'.
     */
    public java.lang.String getPOIType(
    ) {
        return this._POIType;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_POINum != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_POINum)) {
           result = 37 * result + _POINum.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_POINum);
        }
        if (_POIType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_POIType)) {
           result = 37 * result + _POIType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_POIType);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'POINum'.
     * 
     * @param POINum the value of field 'POINum'.
     */
    public void setPOINum(
            final java.lang.String POINum) {
        this._POINum = POINum;
    }

    /**
     * Sets the value of field 'POIType'.
     * 
     * @param POIType the value of field 'POIType'.
     */
    public void setPOIType(
            final java.lang.String POIType) {
        this._POIType = POIType;
    }

    /**
     * Method unmarshalPOI_Type.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.payment.POI_Type
     */
    public static bf.com.misys.types.sadad.payment.POI_Type unmarshalPOI_Type(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.payment.POI_Type) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.payment.POI_Type.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
