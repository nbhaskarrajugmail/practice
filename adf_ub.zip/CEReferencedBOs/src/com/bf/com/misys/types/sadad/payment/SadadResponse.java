/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.payment;

/**
 * Class SadadResponse.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SadadResponse implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _transactionRsList.
     */
    private java.util.Vector<bf.com.misys.types.sadad.payment.SadadPmtDtlsRs> _transactionRsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SadadResponse() {
        super();
        this._transactionRsList = new java.util.Vector<bf.com.misys.types.sadad.payment.SadadPmtDtlsRs>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTransactionRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTransactionRs(
            final bf.com.misys.types.sadad.payment.SadadPmtDtlsRs vTransactionRs)
    throws java.lang.IndexOutOfBoundsException {
        this._transactionRsList.addElement(vTransactionRs);
    }

    /**
     * 
     * 
     * @param index
     * @param vTransactionRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTransactionRs(
            final int index,
            final bf.com.misys.types.sadad.payment.SadadPmtDtlsRs vTransactionRs)
    throws java.lang.IndexOutOfBoundsException {
        this._transactionRsList.add(index, vTransactionRs);
    }

    /**
     * Method enumerateTransactionRs.
     * 
     * @return an Enumeration over all
     * bf.com.misys.types.sadad.payment.SadadPmtDtlsRs elements
     */
    public java.util.Enumeration<? extends bf.com.misys.types.sadad.payment.SadadPmtDtlsRs> enumerateTransactionRs(
    ) {
        return this._transactionRsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SadadResponse) {

            SadadResponse temp = (SadadResponse)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._transactionRsList != null) {
                if (temp._transactionRsList == null) return false;
                if (this._transactionRsList != temp._transactionRsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionRsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionRsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionRsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionRsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionRsList.equals(temp._transactionRsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionRsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionRsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionRsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionRsList);
                    }
                }
            } else if (temp._transactionRsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getTransactionRs.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * bf.com.misys.types.sadad.payment.SadadPmtDtlsRs at the given
     * index
     */
    public bf.com.misys.types.sadad.payment.SadadPmtDtlsRs getTransactionRs(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._transactionRsList.size()) {
            throw new IndexOutOfBoundsException("getTransactionRs: Index value '" + index + "' not in range [0.." + (this._transactionRsList.size() - 1) + "]");
        }

        return (bf.com.misys.types.sadad.payment.SadadPmtDtlsRs) _transactionRsList.get(index);
    }

    /**
     * Method getTransactionRs.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public bf.com.misys.types.sadad.payment.SadadPmtDtlsRs[] getTransactionRs(
    ) {
        bf.com.misys.types.sadad.payment.SadadPmtDtlsRs[] array = new bf.com.misys.types.sadad.payment.SadadPmtDtlsRs[0];
        return (bf.com.misys.types.sadad.payment.SadadPmtDtlsRs[]) this._transactionRsList.toArray(array);
    }

    /**
     * Method getTransactionRsCount.
     * 
     * @return the size of this collection
     */
    public int getTransactionRsCount(
    ) {
        return this._transactionRsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_transactionRsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionRsList)) {
           result = 37 * result + _transactionRsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionRsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTransactionRs(
    ) {
        this._transactionRsList.clear();
    }

    /**
     * Method removeTransactionRs.
     * 
     * @param vTransactionRs
     * @return true if the object was removed from the collection.
     */
    public boolean removeTransactionRs(
            final bf.com.misys.types.sadad.payment.SadadPmtDtlsRs vTransactionRs) {
        boolean removed = _transactionRsList.remove(vTransactionRs);
        return removed;
    }

    /**
     * Method removeTransactionRsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public bf.com.misys.types.sadad.payment.SadadPmtDtlsRs removeTransactionRsAt(
            final int index) {
        java.lang.Object obj = this._transactionRsList.remove(index);
        return (bf.com.misys.types.sadad.payment.SadadPmtDtlsRs) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vTransactionRs
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTransactionRs(
            final int index,
            final bf.com.misys.types.sadad.payment.SadadPmtDtlsRs vTransactionRs)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._transactionRsList.size()) {
            throw new IndexOutOfBoundsException("setTransactionRs: Index value '" + index + "' not in range [0.." + (this._transactionRsList.size() - 1) + "]");
        }

        this._transactionRsList.set(index, vTransactionRs);
    }

    /**
     * 
     * 
     * @param vTransactionRsArray
     */
    public void setTransactionRs(
            final bf.com.misys.types.sadad.payment.SadadPmtDtlsRs[] vTransactionRsArray) {
        //-- copy array
        _transactionRsList.clear();

        for (int i = 0; i < vTransactionRsArray.length; i++) {
                this._transactionRsList.add(vTransactionRsArray[i]);
        }
    }

    /**
     * Method unmarshalSadadResponse.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.payment.SadadResponse
     */
    public static bf.com.misys.types.sadad.payment.SadadResponse unmarshalSadadResponse(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.payment.SadadResponse) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.payment.SadadResponse.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
