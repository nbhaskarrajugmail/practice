/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.payment;

/**
 * Class SadadPmtDtlsRs.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SadadPmtDtlsRs implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _billInviceNumber.
     */
    private java.lang.String _billInviceNumber;

    /**
     * Field _status.
     */
    private java.lang.String _status;

    /**
     * Field _errorDescription.
     */
    private java.lang.String _errorDescription;

    /**
     * Field _transactionID.
     */
    private java.lang.String _transactionID;

    /**
     * Field _msgRecDt.
     */
    private java.sql.Date _msgRecDt;


      //----------------/
     //- Constructors -/
    //----------------/

    public SadadPmtDtlsRs() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SadadPmtDtlsRs) {

            SadadPmtDtlsRs temp = (SadadPmtDtlsRs)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._billInviceNumber != null) {
                if (temp._billInviceNumber == null) return false;
                if (this._billInviceNumber != temp._billInviceNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billInviceNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billInviceNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInviceNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInviceNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billInviceNumber.equals(temp._billInviceNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInviceNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInviceNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInviceNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInviceNumber);
                    }
                }
            } else if (temp._billInviceNumber != null)
                return false;
            if (this._status != null) {
                if (temp._status == null) return false;
                if (this._status != temp._status) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._status);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._status);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._status.equals(temp._status)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                    }
                }
            } else if (temp._status != null)
                return false;
            if (this._errorDescription != null) {
                if (temp._errorDescription == null) return false;
                if (this._errorDescription != temp._errorDescription) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._errorDescription);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._errorDescription);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorDescription); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorDescription); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._errorDescription.equals(temp._errorDescription)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorDescription);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorDescription);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._errorDescription);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._errorDescription);
                    }
                }
            } else if (temp._errorDescription != null)
                return false;
            if (this._transactionID != null) {
                if (temp._transactionID == null) return false;
                if (this._transactionID != temp._transactionID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionID.equals(temp._transactionID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionID);
                    }
                }
            } else if (temp._transactionID != null)
                return false;
            if (this._msgRecDt != null) {
                if (temp._msgRecDt == null) return false;
                if (this._msgRecDt != temp._msgRecDt) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._msgRecDt);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._msgRecDt);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._msgRecDt); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._msgRecDt); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._msgRecDt.equals(temp._msgRecDt)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._msgRecDt);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._msgRecDt);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._msgRecDt);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._msgRecDt);
                    }
                }
            } else if (temp._msgRecDt != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'billInviceNumber'.
     * 
     * @return the value of field 'BillInviceNumber'.
     */
    public java.lang.String getBillInviceNumber(
    ) {
        return this._billInviceNumber;
    }

    /**
     * Returns the value of field 'errorDescription'.
     * 
     * @return the value of field 'ErrorDescription'.
     */
    public java.lang.String getErrorDescription(
    ) {
        return this._errorDescription;
    }

    /**
     * Returns the value of field 'msgRecDt'.
     * 
     * @return the value of field 'MsgRecDt'.
     */
    public java.sql.Date getMsgRecDt(
    ) {
        return this._msgRecDt;
    }

    /**
     * Returns the value of field 'status'.
     * 
     * @return the value of field 'Status'.
     */
    public java.lang.String getStatus(
    ) {
        return this._status;
    }

    /**
     * Returns the value of field 'transactionID'.
     * 
     * @return the value of field 'TransactionID'.
     */
    public java.lang.String getTransactionID(
    ) {
        return this._transactionID;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_billInviceNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billInviceNumber)) {
           result = 37 * result + _billInviceNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billInviceNumber);
        }
        if (_status != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_status)) {
           result = 37 * result + _status.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_status);
        }
        if (_errorDescription != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_errorDescription)) {
           result = 37 * result + _errorDescription.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_errorDescription);
        }
        if (_transactionID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionID)) {
           result = 37 * result + _transactionID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionID);
        }
        if (_msgRecDt != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_msgRecDt)) {
           result = 37 * result + _msgRecDt.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_msgRecDt);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'billInviceNumber'.
     * 
     * @param billInviceNumber the value of field 'billInviceNumber'
     */
    public void setBillInviceNumber(
            final java.lang.String billInviceNumber) {
        this._billInviceNumber = billInviceNumber;
    }

    /**
     * Sets the value of field 'errorDescription'.
     * 
     * @param errorDescription the value of field 'errorDescription'
     */
    public void setErrorDescription(
            final java.lang.String errorDescription) {
        this._errorDescription = errorDescription;
    }

    /**
     * Sets the value of field 'msgRecDt'.
     * 
     * @param msgRecDt the value of field 'msgRecDt'.
     */
    public void setMsgRecDt(
            final java.sql.Date msgRecDt) {
        this._msgRecDt = msgRecDt;
    }

    /**
     * Sets the value of field 'status'.
     * 
     * @param status the value of field 'status'.
     */
    public void setStatus(
            final java.lang.String status) {
        this._status = status;
    }

    /**
     * Sets the value of field 'transactionID'.
     * 
     * @param transactionID the value of field 'transactionID'.
     */
    public void setTransactionID(
            final java.lang.String transactionID) {
        this._transactionID = transactionID;
    }

    /**
     * Method unmarshalSadadPmtDtlsRs.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.payment.SadadPmtDtlsRs
     */
    public static bf.com.misys.types.sadad.payment.SadadPmtDtlsRs unmarshalSadadPmtDtlsRs(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.payment.SadadPmtDtlsRs) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.payment.SadadPmtDtlsRs.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
