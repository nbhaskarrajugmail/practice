/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.payment;

/**
 * Class SadadPmtDtlsRq.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SadadPmtDtlsRq implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _agencyId.
     */
    private java.lang.String _agencyId;

    /**
     * Field _billInvoiceNo.
     */
    private java.lang.String _billInvoiceNo;

    /**
     * Field _billAcct.
     */
    private java.lang.String _billAcct;

    /**
     * Field _billCategory.
     */
    private java.lang.String _billCategory;

    /**
     * Field _billCycle.
     */
    private java.lang.String _billCycle;

    /**
     * Field _pmtAmt.
     */
    private java.math.BigDecimal _pmtAmt;

    /**
     * Field _pmtDt.
     */
    private java.sql.Date _pmtDt;

    /**
     * Field _eCollectionPmtMethod.
     */
    private java.lang.String _eCollectionPmtMethod;

    /**
     * Field _eCollectionPmtMethodDtls.
     */
    private bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls _eCollectionPmtMethodDtls;

    /**
     * Field _pmtStatusCode.
     */
    private java.lang.String _pmtStatusCode;

    /**
     * Field _pmtRefInfo.
     */
    private java.lang.String _pmtRefInfo;

    /**
     * Field _payorPOI.
     */
    private bf.com.misys.types.sadad.payment.POI_Type _payorPOI;


      //----------------/
     //- Constructors -/
    //----------------/

    public SadadPmtDtlsRq() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SadadPmtDtlsRq) {

            SadadPmtDtlsRq temp = (SadadPmtDtlsRq)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._agencyId != null) {
                if (temp._agencyId == null) return false;
                if (this._agencyId != temp._agencyId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._agencyId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._agencyId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._agencyId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._agencyId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._agencyId.equals(temp._agencyId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._agencyId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._agencyId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._agencyId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._agencyId);
                    }
                }
            } else if (temp._agencyId != null)
                return false;
            if (this._billInvoiceNo != null) {
                if (temp._billInvoiceNo == null) return false;
                if (this._billInvoiceNo != temp._billInvoiceNo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billInvoiceNo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billInvoiceNo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceNo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceNo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billInvoiceNo.equals(temp._billInvoiceNo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceNo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceNo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billInvoiceNo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billInvoiceNo);
                    }
                }
            } else if (temp._billInvoiceNo != null)
                return false;
            if (this._billAcct != null) {
                if (temp._billAcct == null) return false;
                if (this._billAcct != temp._billAcct) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billAcct);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billAcct);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billAcct); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billAcct); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billAcct.equals(temp._billAcct)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billAcct);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billAcct);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billAcct);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billAcct);
                    }
                }
            } else if (temp._billAcct != null)
                return false;
            if (this._billCategory != null) {
                if (temp._billCategory == null) return false;
                if (this._billCategory != temp._billCategory) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billCategory);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billCategory);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCategory); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCategory); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billCategory.equals(temp._billCategory)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCategory);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCategory);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCategory);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCategory);
                    }
                }
            } else if (temp._billCategory != null)
                return false;
            if (this._billCycle != null) {
                if (temp._billCycle == null) return false;
                if (this._billCycle != temp._billCycle) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._billCycle);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._billCycle);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCycle); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCycle); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._billCycle.equals(temp._billCycle)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCycle);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCycle);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._billCycle);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._billCycle);
                    }
                }
            } else if (temp._billCycle != null)
                return false;
            if (this._pmtAmt != null) {
                if (temp._pmtAmt == null) return false;
                if (this._pmtAmt != temp._pmtAmt) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtAmt);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtAmt);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtAmt); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtAmt); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtAmt.equals(temp._pmtAmt)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtAmt);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtAmt);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtAmt);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtAmt);
                    }
                }
            } else if (temp._pmtAmt != null)
                return false;
            if (this._pmtDt != null) {
                if (temp._pmtDt == null) return false;
                if (this._pmtDt != temp._pmtDt) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtDt);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtDt);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtDt); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtDt); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtDt.equals(temp._pmtDt)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtDt);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtDt);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtDt);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtDt);
                    }
                }
            } else if (temp._pmtDt != null)
                return false;
            if (this._eCollectionPmtMethod != null) {
                if (temp._eCollectionPmtMethod == null) return false;
                if (this._eCollectionPmtMethod != temp._eCollectionPmtMethod) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._eCollectionPmtMethod);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._eCollectionPmtMethod);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethod); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethod); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._eCollectionPmtMethod.equals(temp._eCollectionPmtMethod)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethod);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethod);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethod);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethod);
                    }
                }
            } else if (temp._eCollectionPmtMethod != null)
                return false;
            if (this._eCollectionPmtMethodDtls != null) {
                if (temp._eCollectionPmtMethodDtls == null) return false;
                if (this._eCollectionPmtMethodDtls != temp._eCollectionPmtMethodDtls) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._eCollectionPmtMethodDtls);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._eCollectionPmtMethodDtls);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethodDtls); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethodDtls); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._eCollectionPmtMethodDtls.equals(temp._eCollectionPmtMethodDtls)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethodDtls);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethodDtls);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._eCollectionPmtMethodDtls);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._eCollectionPmtMethodDtls);
                    }
                }
            } else if (temp._eCollectionPmtMethodDtls != null)
                return false;
            if (this._pmtStatusCode != null) {
                if (temp._pmtStatusCode == null) return false;
                if (this._pmtStatusCode != temp._pmtStatusCode) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtStatusCode);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtStatusCode);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtStatusCode); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtStatusCode); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtStatusCode.equals(temp._pmtStatusCode)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtStatusCode);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtStatusCode);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtStatusCode);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtStatusCode);
                    }
                }
            } else if (temp._pmtStatusCode != null)
                return false;
            if (this._pmtRefInfo != null) {
                if (temp._pmtRefInfo == null) return false;
                if (this._pmtRefInfo != temp._pmtRefInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtRefInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtRefInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtRefInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtRefInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtRefInfo.equals(temp._pmtRefInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtRefInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtRefInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtRefInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtRefInfo);
                    }
                }
            } else if (temp._pmtRefInfo != null)
                return false;
            if (this._payorPOI != null) {
                if (temp._payorPOI == null) return false;
                if (this._payorPOI != temp._payorPOI) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._payorPOI);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._payorPOI);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._payorPOI); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._payorPOI); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._payorPOI.equals(temp._payorPOI)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._payorPOI);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._payorPOI);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._payorPOI);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._payorPOI);
                    }
                }
            } else if (temp._payorPOI != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'agencyId'.
     * 
     * @return the value of field 'AgencyId'.
     */
    public java.lang.String getAgencyId(
    ) {
        return this._agencyId;
    }

    /**
     * Returns the value of field 'billAcct'.
     * 
     * @return the value of field 'BillAcct'.
     */
    public java.lang.String getBillAcct(
    ) {
        return this._billAcct;
    }

    /**
     * Returns the value of field 'billCategory'.
     * 
     * @return the value of field 'BillCategory'.
     */
    public java.lang.String getBillCategory(
    ) {
        return this._billCategory;
    }

    /**
     * Returns the value of field 'billCycle'.
     * 
     * @return the value of field 'BillCycle'.
     */
    public java.lang.String getBillCycle(
    ) {
        return this._billCycle;
    }

    /**
     * Returns the value of field 'billInvoiceNo'.
     * 
     * @return the value of field 'BillInvoiceNo'.
     */
    public java.lang.String getBillInvoiceNo(
    ) {
        return this._billInvoiceNo;
    }

    /**
     * Returns the value of field 'eCollectionPmtMethod'.
     * 
     * @return the value of field 'ECollectionPmtMethod'.
     */
    public java.lang.String getECollectionPmtMethod(
    ) {
        return this._eCollectionPmtMethod;
    }

    /**
     * Returns the value of field 'eCollectionPmtMethodDtls'.
     * 
     * @return the value of field 'ECollectionPmtMethodDtls'.
     */
    public bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls getECollectionPmtMethodDtls(
    ) {
        return this._eCollectionPmtMethodDtls;
    }

    /**
     * Returns the value of field 'payorPOI'.
     * 
     * @return the value of field 'PayorPOI'.
     */
    public bf.com.misys.types.sadad.payment.POI_Type getPayorPOI(
    ) {
        return this._payorPOI;
    }

    /**
     * Returns the value of field 'pmtAmt'.
     * 
     * @return the value of field 'PmtAmt'.
     */
    public java.math.BigDecimal getPmtAmt(
    ) {
        return this._pmtAmt;
    }

    /**
     * Returns the value of field 'pmtDt'.
     * 
     * @return the value of field 'PmtDt'.
     */
    public java.sql.Date getPmtDt(
    ) {
        return this._pmtDt;
    }

    /**
     * Returns the value of field 'pmtRefInfo'.
     * 
     * @return the value of field 'PmtRefInfo'.
     */
    public java.lang.String getPmtRefInfo(
    ) {
        return this._pmtRefInfo;
    }

    /**
     * Returns the value of field 'pmtStatusCode'.
     * 
     * @return the value of field 'PmtStatusCode'.
     */
    public java.lang.String getPmtStatusCode(
    ) {
        return this._pmtStatusCode;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_agencyId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_agencyId)) {
           result = 37 * result + _agencyId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_agencyId);
        }
        if (_billInvoiceNo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billInvoiceNo)) {
           result = 37 * result + _billInvoiceNo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billInvoiceNo);
        }
        if (_billAcct != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billAcct)) {
           result = 37 * result + _billAcct.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billAcct);
        }
        if (_billCategory != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billCategory)) {
           result = 37 * result + _billCategory.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billCategory);
        }
        if (_billCycle != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_billCycle)) {
           result = 37 * result + _billCycle.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_billCycle);
        }
        if (_pmtAmt != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtAmt)) {
           result = 37 * result + _pmtAmt.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtAmt);
        }
        if (_pmtDt != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtDt)) {
           result = 37 * result + _pmtDt.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtDt);
        }
        if (_eCollectionPmtMethod != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_eCollectionPmtMethod)) {
           result = 37 * result + _eCollectionPmtMethod.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_eCollectionPmtMethod);
        }
        if (_eCollectionPmtMethodDtls != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_eCollectionPmtMethodDtls)) {
           result = 37 * result + _eCollectionPmtMethodDtls.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_eCollectionPmtMethodDtls);
        }
        if (_pmtStatusCode != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtStatusCode)) {
           result = 37 * result + _pmtStatusCode.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtStatusCode);
        }
        if (_pmtRefInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtRefInfo)) {
           result = 37 * result + _pmtRefInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtRefInfo);
        }
        if (_payorPOI != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_payorPOI)) {
           result = 37 * result + _payorPOI.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_payorPOI);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'agencyId'.
     * 
     * @param agencyId the value of field 'agencyId'.
     */
    public void setAgencyId(
            final java.lang.String agencyId) {
        this._agencyId = agencyId;
    }

    /**
     * Sets the value of field 'billAcct'.
     * 
     * @param billAcct the value of field 'billAcct'.
     */
    public void setBillAcct(
            final java.lang.String billAcct) {
        this._billAcct = billAcct;
    }

    /**
     * Sets the value of field 'billCategory'.
     * 
     * @param billCategory the value of field 'billCategory'.
     */
    public void setBillCategory(
            final java.lang.String billCategory) {
        this._billCategory = billCategory;
    }

    /**
     * Sets the value of field 'billCycle'.
     * 
     * @param billCycle the value of field 'billCycle'.
     */
    public void setBillCycle(
            final java.lang.String billCycle) {
        this._billCycle = billCycle;
    }

    /**
     * Sets the value of field 'billInvoiceNo'.
     * 
     * @param billInvoiceNo the value of field 'billInvoiceNo'.
     */
    public void setBillInvoiceNo(
            final java.lang.String billInvoiceNo) {
        this._billInvoiceNo = billInvoiceNo;
    }

    /**
     * Sets the value of field 'eCollectionPmtMethod'.
     * 
     * @param eCollectionPmtMethod the value of field
     * 'eCollectionPmtMethod'.
     */
    public void setECollectionPmtMethod(
            final java.lang.String eCollectionPmtMethod) {
        this._eCollectionPmtMethod = eCollectionPmtMethod;
    }

    /**
     * Sets the value of field 'eCollectionPmtMethodDtls'.
     * 
     * @param eCollectionPmtMethodDtls the value of field
     * 'eCollectionPmtMethodDtls'.
     */
    public void setECollectionPmtMethodDtls(
            final bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls eCollectionPmtMethodDtls) {
        this._eCollectionPmtMethodDtls = eCollectionPmtMethodDtls;
    }

    /**
     * Sets the value of field 'payorPOI'.
     * 
     * @param payorPOI the value of field 'payorPOI'.
     */
    public void setPayorPOI(
            final bf.com.misys.types.sadad.payment.POI_Type payorPOI) {
        this._payorPOI = payorPOI;
    }

    /**
     * Sets the value of field 'pmtAmt'.
     * 
     * @param pmtAmt the value of field 'pmtAmt'.
     */
    public void setPmtAmt(
            final java.math.BigDecimal pmtAmt) {
        this._pmtAmt = pmtAmt;
    }

    /**
     * Sets the value of field 'pmtDt'.
     * 
     * @param pmtDt the value of field 'pmtDt'.
     */
    public void setPmtDt(
            final java.sql.Date pmtDt) {
        this._pmtDt = pmtDt;
    }

    /**
     * Sets the value of field 'pmtRefInfo'.
     * 
     * @param pmtRefInfo the value of field 'pmtRefInfo'.
     */
    public void setPmtRefInfo(
            final java.lang.String pmtRefInfo) {
        this._pmtRefInfo = pmtRefInfo;
    }

    /**
     * Sets the value of field 'pmtStatusCode'.
     * 
     * @param pmtStatusCode the value of field 'pmtStatusCode'.
     */
    public void setPmtStatusCode(
            final java.lang.String pmtStatusCode) {
        this._pmtStatusCode = pmtStatusCode;
    }

    /**
     * Method unmarshalSadadPmtDtlsRq.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.payment.SadadPmtDtlsRq
     */
    public static bf.com.misys.types.sadad.payment.SadadPmtDtlsRq unmarshalSadadPmtDtlsRq(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.payment.SadadPmtDtlsRq) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.payment.SadadPmtDtlsRq.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
