/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package bf.com.misys.types.sadad.payment;

/**
 * Class ECollectionPmtMethodDtls.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ECollectionPmtMethodDtls implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _pmtId.
     */
    private java.lang.String _pmtId;

    /**
     * Field _bankId.
     */
    private java.lang.String _bankId;

    /**
     * Field _bankPmtId.
     */
    private java.lang.String _bankPmtId;

    /**
     * Field _pmtChannel.
     */
    private java.lang.String _pmtChannel;


      //----------------/
     //- Constructors -/
    //----------------/

    public ECollectionPmtMethodDtls() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ECollectionPmtMethodDtls) {

            ECollectionPmtMethodDtls temp = (ECollectionPmtMethodDtls)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._pmtId != null) {
                if (temp._pmtId == null) return false;
                if (this._pmtId != temp._pmtId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtId.equals(temp._pmtId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtId);
                    }
                }
            } else if (temp._pmtId != null)
                return false;
            if (this._bankId != null) {
                if (temp._bankId == null) return false;
                if (this._bankId != temp._bankId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._bankId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._bankId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._bankId.equals(temp._bankId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankId);
                    }
                }
            } else if (temp._bankId != null)
                return false;
            if (this._bankPmtId != null) {
                if (temp._bankPmtId == null) return false;
                if (this._bankPmtId != temp._bankPmtId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._bankPmtId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._bankPmtId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankPmtId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankPmtId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._bankPmtId.equals(temp._bankPmtId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankPmtId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankPmtId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankPmtId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankPmtId);
                    }
                }
            } else if (temp._bankPmtId != null)
                return false;
            if (this._pmtChannel != null) {
                if (temp._pmtChannel == null) return false;
                if (this._pmtChannel != temp._pmtChannel) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pmtChannel);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pmtChannel);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtChannel); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtChannel); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pmtChannel.equals(temp._pmtChannel)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtChannel);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtChannel);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pmtChannel);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pmtChannel);
                    }
                }
            } else if (temp._pmtChannel != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'bankId'.
     * 
     * @return the value of field 'BankId'.
     */
    public java.lang.String getBankId(
    ) {
        return this._bankId;
    }

    /**
     * Returns the value of field 'bankPmtId'.
     * 
     * @return the value of field 'BankPmtId'.
     */
    public java.lang.String getBankPmtId(
    ) {
        return this._bankPmtId;
    }

    /**
     * Returns the value of field 'pmtChannel'.
     * 
     * @return the value of field 'PmtChannel'.
     */
    public java.lang.String getPmtChannel(
    ) {
        return this._pmtChannel;
    }

    /**
     * Returns the value of field 'pmtId'.
     * 
     * @return the value of field 'PmtId'.
     */
    public java.lang.String getPmtId(
    ) {
        return this._pmtId;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_pmtId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtId)) {
           result = 37 * result + _pmtId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtId);
        }
        if (_bankId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_bankId)) {
           result = 37 * result + _bankId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_bankId);
        }
        if (_bankPmtId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_bankPmtId)) {
           result = 37 * result + _bankPmtId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_bankPmtId);
        }
        if (_pmtChannel != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pmtChannel)) {
           result = 37 * result + _pmtChannel.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pmtChannel);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'bankId'.
     * 
     * @param bankId the value of field 'bankId'.
     */
    public void setBankId(
            final java.lang.String bankId) {
        this._bankId = bankId;
    }

    /**
     * Sets the value of field 'bankPmtId'.
     * 
     * @param bankPmtId the value of field 'bankPmtId'.
     */
    public void setBankPmtId(
            final java.lang.String bankPmtId) {
        this._bankPmtId = bankPmtId;
    }

    /**
     * Sets the value of field 'pmtChannel'.
     * 
     * @param pmtChannel the value of field 'pmtChannel'.
     */
    public void setPmtChannel(
            final java.lang.String pmtChannel) {
        this._pmtChannel = pmtChannel;
    }

    /**
     * Sets the value of field 'pmtId'.
     * 
     * @param pmtId the value of field 'pmtId'.
     */
    public void setPmtId(
            final java.lang.String pmtId) {
        this._pmtId = pmtId;
    }

    /**
     * Method unmarshalECollectionPmtMethodDtls.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls
     */
    public static bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls unmarshalECollectionPmtMethodDtls(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls) org.exolab.castor.xml.Unmarshaller.unmarshal(bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
