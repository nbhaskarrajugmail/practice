/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchSplitTitleDeedDtlsRsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchSplitTitleDeedDtlsRsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _listSplitTitleDeedDtls.
     */
    private com.misys.ce.types.ListSplitTitleDeedDtlsType _listSplitTitleDeedDtls;

    /**
     * Field _pagingInfo.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagingInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchSplitTitleDeedDtlsRsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchSplitTitleDeedDtlsRsType) {

            SearchSplitTitleDeedDtlsRsType temp = (SearchSplitTitleDeedDtlsRsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._listSplitTitleDeedDtls != null) {
                if (temp._listSplitTitleDeedDtls == null) return false;
                if (this._listSplitTitleDeedDtls != temp._listSplitTitleDeedDtls) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._listSplitTitleDeedDtls);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._listSplitTitleDeedDtls);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listSplitTitleDeedDtls); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listSplitTitleDeedDtls); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._listSplitTitleDeedDtls.equals(temp._listSplitTitleDeedDtls)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listSplitTitleDeedDtls);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listSplitTitleDeedDtls);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listSplitTitleDeedDtls);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listSplitTitleDeedDtls);
                    }
                }
            } else if (temp._listSplitTitleDeedDtls != null)
                return false;
            if (this._pagingInfo != null) {
                if (temp._pagingInfo == null) return false;
                if (this._pagingInfo != temp._pagingInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagingInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagingInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagingInfo.equals(temp._pagingInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                    }
                }
            } else if (temp._pagingInfo != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'listSplitTitleDeedDtls'.
     * 
     * @return the value of field 'ListSplitTitleDeedDtls'.
     */
    public com.misys.ce.types.ListSplitTitleDeedDtlsType getListSplitTitleDeedDtls(
    ) {
        return this._listSplitTitleDeedDtls;
    }

    /**
     * Returns the value of field 'pagingInfo'.
     * 
     * @return the value of field 'PagingInfo'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagingInfo(
    ) {
        return this._pagingInfo;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_listSplitTitleDeedDtls != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_listSplitTitleDeedDtls)) {
           result = 37 * result + _listSplitTitleDeedDtls.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_listSplitTitleDeedDtls);
        }
        if (_pagingInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagingInfo)) {
           result = 37 * result + _pagingInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagingInfo);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'listSplitTitleDeedDtls'.
     * 
     * @param listSplitTitleDeedDtls the value of field
     * 'listSplitTitleDeedDtls'.
     */
    public void setListSplitTitleDeedDtls(
            final com.misys.ce.types.ListSplitTitleDeedDtlsType listSplitTitleDeedDtls) {
        this._listSplitTitleDeedDtls = listSplitTitleDeedDtls;
    }

    /**
     * Sets the value of field 'pagingInfo'.
     * 
     * @param pagingInfo the value of field 'pagingInfo'.
     */
    public void setPagingInfo(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagingInfo) {
        this._pagingInfo = pagingInfo;
    }

    /**
     * Method unmarshalSearchSplitTitleDeedDtlsRsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchSplitTitleDeedDtlsRsType
     */
    public static com.misys.ce.types.SearchSplitTitleDeedDtlsRsType unmarshalSearchSplitTitleDeedDtlsRsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchSplitTitleDeedDtlsRsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchSplitTitleDeedDtlsRsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
