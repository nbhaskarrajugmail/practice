/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchTitleDeedDtlsRqType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchTitleDeedDtlsRqType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _partyId.
     */
    private java.lang.String _partyId;

    /**
     * Field _pagingInfo.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagingInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchTitleDeedDtlsRqType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchTitleDeedDtlsRqType) {

            SearchTitleDeedDtlsRqType temp = (SearchTitleDeedDtlsRqType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._partyId != null) {
                if (temp._partyId == null) return false;
                if (this._partyId != temp._partyId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partyId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partyId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partyId.equals(temp._partyId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId);
                    }
                }
            } else if (temp._partyId != null)
                return false;
            if (this._pagingInfo != null) {
                if (temp._pagingInfo == null) return false;
                if (this._pagingInfo != temp._pagingInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagingInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagingInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagingInfo.equals(temp._pagingInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                    }
                }
            } else if (temp._pagingInfo != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'pagingInfo'.
     * 
     * @return the value of field 'PagingInfo'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagingInfo(
    ) {
        return this._pagingInfo;
    }

    /**
     * Returns the value of field 'partyId'.
     * 
     * @return the value of field 'PartyId'.
     */
    public java.lang.String getPartyId(
    ) {
        return this._partyId;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_partyId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partyId)) {
           result = 37 * result + _partyId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partyId);
        }
        if (_pagingInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagingInfo)) {
           result = 37 * result + _pagingInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagingInfo);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'pagingInfo'.
     * 
     * @param pagingInfo the value of field 'pagingInfo'.
     */
    public void setPagingInfo(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagingInfo) {
        this._pagingInfo = pagingInfo;
    }

    /**
     * Sets the value of field 'partyId'.
     * 
     * @param partyId the value of field 'partyId'.
     */
    public void setPartyId(
            final java.lang.String partyId) {
        this._partyId = partyId;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Method unmarshalSearchTitleDeedDtlsRqType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchTitleDeedDtlsRqType
     */
    public static com.misys.ce.types.SearchTitleDeedDtlsRqType unmarshalSearchTitleDeedDtlsRqType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchTitleDeedDtlsRqType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchTitleDeedDtlsRqType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
