/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class TitleDeedNumSearch.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TitleDeedNumSearch implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedNumber.
     */
    private java.lang.String _titleDeedNumber;

    /**
     * Field _screenName.
     */
    private java.lang.String _screenName;

    /**
     * Field _partyID.
     */
    private java.lang.String _partyID;


      //----------------/
     //- Constructors -/
    //----------------/

    public TitleDeedNumSearch() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof TitleDeedNumSearch) {

            TitleDeedNumSearch temp = (TitleDeedNumSearch)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedNumber != null) {
                if (temp._titleDeedNumber == null) return false;
                if (this._titleDeedNumber != temp._titleDeedNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedNumber.equals(temp._titleDeedNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                    }
                }
            } else if (temp._titleDeedNumber != null)
                return false;
            if (this._screenName != null) {
                if (temp._screenName == null) return false;
                if (this._screenName != temp._screenName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._screenName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._screenName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._screenName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._screenName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._screenName.equals(temp._screenName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._screenName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._screenName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._screenName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._screenName);
                    }
                }
            } else if (temp._screenName != null)
                return false;
            if (this._partyID != null) {
                if (temp._partyID == null) return false;
                if (this._partyID != temp._partyID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partyID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partyID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partyID.equals(temp._partyID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyID);
                    }
                }
            } else if (temp._partyID != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'partyID'.
     * 
     * @return the value of field 'PartyID'.
     */
    public java.lang.String getPartyID(
    ) {
        return this._partyID;
    }

    /**
     * Returns the value of field 'screenName'.
     * 
     * @return the value of field 'ScreenName'.
     */
    public java.lang.String getScreenName(
    ) {
        return this._screenName;
    }

    /**
     * Returns the value of field 'titleDeedNumber'.
     * 
     * @return the value of field 'TitleDeedNumber'.
     */
    public java.lang.String getTitleDeedNumber(
    ) {
        return this._titleDeedNumber;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedNumber)) {
           result = 37 * result + _titleDeedNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedNumber);
        }
        if (_screenName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_screenName)) {
           result = 37 * result + _screenName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_screenName);
        }
        if (_partyID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partyID)) {
           result = 37 * result + _partyID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partyID);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'partyID'.
     * 
     * @param partyID the value of field 'partyID'.
     */
    public void setPartyID(
            final java.lang.String partyID) {
        this._partyID = partyID;
    }

    /**
     * Sets the value of field 'screenName'.
     * 
     * @param screenName the value of field 'screenName'.
     */
    public void setScreenName(
            final java.lang.String screenName) {
        this._screenName = screenName;
    }

    /**
     * Sets the value of field 'titleDeedNumber'.
     * 
     * @param titleDeedNumber the value of field 'titleDeedNumber'.
     */
    public void setTitleDeedNumber(
            final java.lang.String titleDeedNumber) {
        this._titleDeedNumber = titleDeedNumber;
    }

    /**
     * Method unmarshalTitleDeedNumSearch.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled com.misys.ce.types.TitleDeedNumSearch
     */
    public static com.misys.ce.types.TitleDeedNumSearch unmarshalTitleDeedNumSearch(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.TitleDeedNumSearch) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.TitleDeedNumSearch.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
