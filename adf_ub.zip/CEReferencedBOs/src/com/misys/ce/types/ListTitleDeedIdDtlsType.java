/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListTitleDeedIdDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListTitleDeedIdDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedDetailsList.
     */
    private java.util.Vector<com.misys.ce.types.TitleDeedDetailsType> _titleDeedDetailsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListTitleDeedIdDtlsType() {
        super();
        this._titleDeedDetailsList = new java.util.Vector<com.misys.ce.types.TitleDeedDetailsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTitleDeedDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitleDeedDetails(
            final com.misys.ce.types.TitleDeedDetailsType vTitleDeedDetails)
    throws java.lang.IndexOutOfBoundsException {
        this._titleDeedDetailsList.addElement(vTitleDeedDetails);
    }

    /**
     * 
     * 
     * @param index
     * @param vTitleDeedDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitleDeedDetails(
            final int index,
            final com.misys.ce.types.TitleDeedDetailsType vTitleDeedDetails)
    throws java.lang.IndexOutOfBoundsException {
        this._titleDeedDetailsList.add(index, vTitleDeedDetails);
    }

    /**
     * Method enumerateTitleDeedDetails.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.TitleDeedDetailsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.TitleDeedDetailsType> enumerateTitleDeedDetails(
    ) {
        return this._titleDeedDetailsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListTitleDeedIdDtlsType) {

            ListTitleDeedIdDtlsType temp = (ListTitleDeedIdDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedDetailsList != null) {
                if (temp._titleDeedDetailsList == null) return false;
                if (this._titleDeedDetailsList != temp._titleDeedDetailsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedDetailsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedDetailsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedDetailsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedDetailsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedDetailsList.equals(temp._titleDeedDetailsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedDetailsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedDetailsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedDetailsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedDetailsList);
                    }
                }
            } else if (temp._titleDeedDetailsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getTitleDeedDetails.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.TitleDeedDetailsType at the given index
     */
    public com.misys.ce.types.TitleDeedDetailsType getTitleDeedDetails(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleDeedDetailsList.size()) {
            throw new IndexOutOfBoundsException("getTitleDeedDetails: Index value '" + index + "' not in range [0.." + (this._titleDeedDetailsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.TitleDeedDetailsType) _titleDeedDetailsList.get(index);
    }

    /**
     * Method getTitleDeedDetails.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.TitleDeedDetailsType[] getTitleDeedDetails(
    ) {
        com.misys.ce.types.TitleDeedDetailsType[] array = new com.misys.ce.types.TitleDeedDetailsType[0];
        return (com.misys.ce.types.TitleDeedDetailsType[]) this._titleDeedDetailsList.toArray(array);
    }

    /**
     * Method getTitleDeedDetailsCount.
     * 
     * @return the size of this collection
     */
    public int getTitleDeedDetailsCount(
    ) {
        return this._titleDeedDetailsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedDetailsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedDetailsList)) {
           result = 37 * result + _titleDeedDetailsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedDetailsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTitleDeedDetails(
    ) {
        this._titleDeedDetailsList.clear();
    }

    /**
     * Method removeTitleDeedDetails.
     * 
     * @param vTitleDeedDetails
     * @return true if the object was removed from the collection.
     */
    public boolean removeTitleDeedDetails(
            final com.misys.ce.types.TitleDeedDetailsType vTitleDeedDetails) {
        boolean removed = _titleDeedDetailsList.remove(vTitleDeedDetails);
        return removed;
    }

    /**
     * Method removeTitleDeedDetailsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.TitleDeedDetailsType removeTitleDeedDetailsAt(
            final int index) {
        java.lang.Object obj = this._titleDeedDetailsList.remove(index);
        return (com.misys.ce.types.TitleDeedDetailsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vTitleDeedDetails
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTitleDeedDetails(
            final int index,
            final com.misys.ce.types.TitleDeedDetailsType vTitleDeedDetails)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleDeedDetailsList.size()) {
            throw new IndexOutOfBoundsException("setTitleDeedDetails: Index value '" + index + "' not in range [0.." + (this._titleDeedDetailsList.size() - 1) + "]");
        }

        this._titleDeedDetailsList.set(index, vTitleDeedDetails);
    }

    /**
     * 
     * 
     * @param vTitleDeedDetailsArray
     */
    public void setTitleDeedDetails(
            final com.misys.ce.types.TitleDeedDetailsType[] vTitleDeedDetailsArray) {
        //-- copy array
        _titleDeedDetailsList.clear();

        for (int i = 0; i < vTitleDeedDetailsArray.length; i++) {
                this._titleDeedDetailsList.add(vTitleDeedDetailsArray[i]);
        }
    }

    /**
     * Method unmarshalListTitleDeedIdDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListTitleDeedIdDtlsType
     */
    public static com.misys.ce.types.ListTitleDeedIdDtlsType unmarshalListTitleDeedIdDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListTitleDeedIdDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListTitleDeedIdDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
