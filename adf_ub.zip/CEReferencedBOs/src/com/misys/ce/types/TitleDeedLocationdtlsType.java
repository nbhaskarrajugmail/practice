/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class TitleDeedLocationdtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TitleDeedLocationdtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedLocIdpk.
     */
    private java.lang.String _titleDeedLocIdpk;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _serial.
     */
    private java.lang.Integer _serial;

    /**
     * Field _locationEastSection.
     */
    private java.math.BigDecimal _locationEastSection;

    /**
     * Field _locationEastDegree.
     */
    private java.math.BigDecimal _locationEastDegree;

    /**
     * Field _locationNorthSection.
     */
    private java.math.BigDecimal _locationNorthSection;

    /**
     * Field _locationNorthDegree.
     */
    private java.math.BigDecimal _locationNorthDegree;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public TitleDeedLocationdtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof TitleDeedLocationdtlsType) {

            TitleDeedLocationdtlsType temp = (TitleDeedLocationdtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedLocIdpk != null) {
                if (temp._titleDeedLocIdpk == null) return false;
                if (this._titleDeedLocIdpk != temp._titleDeedLocIdpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedLocIdpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedLocIdpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocIdpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocIdpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedLocIdpk.equals(temp._titleDeedLocIdpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocIdpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocIdpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocIdpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocIdpk);
                    }
                }
            } else if (temp._titleDeedLocIdpk != null)
                return false;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._serial != null) {
                if (temp._serial == null) return false;
                if (this._serial != temp._serial) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._serial);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._serial);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._serial); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._serial); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._serial.equals(temp._serial)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._serial);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._serial);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._serial);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._serial);
                    }
                }
            } else if (temp._serial != null)
                return false;
            if (this._locationEastSection != null) {
                if (temp._locationEastSection == null) return false;
                if (this._locationEastSection != temp._locationEastSection) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._locationEastSection);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._locationEastSection);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastSection); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastSection); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._locationEastSection.equals(temp._locationEastSection)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastSection);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastSection);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastSection);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastSection);
                    }
                }
            } else if (temp._locationEastSection != null)
                return false;
            if (this._locationEastDegree != null) {
                if (temp._locationEastDegree == null) return false;
                if (this._locationEastDegree != temp._locationEastDegree) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._locationEastDegree);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._locationEastDegree);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastDegree); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastDegree); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._locationEastDegree.equals(temp._locationEastDegree)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastDegree);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastDegree);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationEastDegree);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationEastDegree);
                    }
                }
            } else if (temp._locationEastDegree != null)
                return false;
            if (this._locationNorthSection != null) {
                if (temp._locationNorthSection == null) return false;
                if (this._locationNorthSection != temp._locationNorthSection) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._locationNorthSection);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._locationNorthSection);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthSection); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthSection); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._locationNorthSection.equals(temp._locationNorthSection)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthSection);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthSection);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthSection);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthSection);
                    }
                }
            } else if (temp._locationNorthSection != null)
                return false;
            if (this._locationNorthDegree != null) {
                if (temp._locationNorthDegree == null) return false;
                if (this._locationNorthDegree != temp._locationNorthDegree) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._locationNorthDegree);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._locationNorthDegree);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthDegree); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthDegree); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._locationNorthDegree.equals(temp._locationNorthDegree)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthDegree);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthDegree);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._locationNorthDegree);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._locationNorthDegree);
                    }
                }
            } else if (temp._locationNorthDegree != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'locationEastDegree'.
     * 
     * @return the value of field 'LocationEastDegree'.
     */
    public java.math.BigDecimal getLocationEastDegree(
    ) {
        return this._locationEastDegree;
    }

    /**
     * Returns the value of field 'locationEastSection'.
     * 
     * @return the value of field 'LocationEastSection'.
     */
    public java.math.BigDecimal getLocationEastSection(
    ) {
        return this._locationEastSection;
    }

    /**
     * Returns the value of field 'locationNorthDegree'.
     * 
     * @return the value of field 'LocationNorthDegree'.
     */
    public java.math.BigDecimal getLocationNorthDegree(
    ) {
        return this._locationNorthDegree;
    }

    /**
     * Returns the value of field 'locationNorthSection'.
     * 
     * @return the value of field 'LocationNorthSection'.
     */
    public java.math.BigDecimal getLocationNorthSection(
    ) {
        return this._locationNorthSection;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'serial'.
     * 
     * @return the value of field 'Serial'.
     */
    public java.lang.Integer getSerial(
    ) {
        return this._serial;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Returns the value of field 'titleDeedLocIdpk'.
     * 
     * @return the value of field 'TitleDeedLocIdpk'.
     */
    public java.lang.String getTitleDeedLocIdpk(
    ) {
        return this._titleDeedLocIdpk;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedLocIdpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedLocIdpk)) {
           result = 37 * result + _titleDeedLocIdpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedLocIdpk);
        }
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_serial != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_serial)) {
           result = 37 * result + _serial.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_serial);
        }
        if (_locationEastSection != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_locationEastSection)) {
           result = 37 * result + _locationEastSection.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_locationEastSection);
        }
        if (_locationEastDegree != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_locationEastDegree)) {
           result = 37 * result + _locationEastDegree.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_locationEastDegree);
        }
        if (_locationNorthSection != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_locationNorthSection)) {
           result = 37 * result + _locationNorthSection.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_locationNorthSection);
        }
        if (_locationNorthDegree != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_locationNorthDegree)) {
           result = 37 * result + _locationNorthDegree.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_locationNorthDegree);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'locationEastDegree'.
     * 
     * @param locationEastDegree the value of field
     * 'locationEastDegree'.
     */
    public void setLocationEastDegree(
            final java.math.BigDecimal locationEastDegree) {
        this._locationEastDegree = locationEastDegree;
    }

    /**
     * Sets the value of field 'locationEastSection'.
     * 
     * @param locationEastSection the value of field
     * 'locationEastSection'.
     */
    public void setLocationEastSection(
            final java.math.BigDecimal locationEastSection) {
        this._locationEastSection = locationEastSection;
    }

    /**
     * Sets the value of field 'locationNorthDegree'.
     * 
     * @param locationNorthDegree the value of field
     * 'locationNorthDegree'.
     */
    public void setLocationNorthDegree(
            final java.math.BigDecimal locationNorthDegree) {
        this._locationNorthDegree = locationNorthDegree;
    }

    /**
     * Sets the value of field 'locationNorthSection'.
     * 
     * @param locationNorthSection the value of field
     * 'locationNorthSection'.
     */
    public void setLocationNorthSection(
            final java.math.BigDecimal locationNorthSection) {
        this._locationNorthSection = locationNorthSection;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'serial'.
     * 
     * @param serial the value of field 'serial'.
     */
    public void setSerial(
            final java.lang.Integer serial) {
        this._serial = serial;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Sets the value of field 'titleDeedLocIdpk'.
     * 
     * @param titleDeedLocIdpk the value of field 'titleDeedLocIdpk'
     */
    public void setTitleDeedLocIdpk(
            final java.lang.String titleDeedLocIdpk) {
        this._titleDeedLocIdpk = titleDeedLocIdpk;
    }

    /**
     * Method unmarshalTitleDeedLocationdtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.TitleDeedLocationdtlsType
     */
    public static com.misys.ce.types.TitleDeedLocationdtlsType unmarshalTitleDeedLocationdtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.TitleDeedLocationdtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.TitleDeedLocationdtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
