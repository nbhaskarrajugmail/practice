/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListParentTitleDeedDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListParentTitleDeedDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _parentTitleDeedDtlsList.
     */
    private java.util.Vector<com.misys.ce.types.ParentTitleDeeddtlsType> _parentTitleDeedDtlsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListParentTitleDeedDtlsType() {
        super();
        this._parentTitleDeedDtlsList = new java.util.Vector<com.misys.ce.types.ParentTitleDeeddtlsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vParentTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addParentTitleDeedDtls(
            final com.misys.ce.types.ParentTitleDeeddtlsType vParentTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._parentTitleDeedDtlsList.addElement(vParentTitleDeedDtls);
    }

    /**
     * 
     * 
     * @param index
     * @param vParentTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addParentTitleDeedDtls(
            final int index,
            final com.misys.ce.types.ParentTitleDeeddtlsType vParentTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._parentTitleDeedDtlsList.add(index, vParentTitleDeedDtls);
    }

    /**
     * Method enumerateParentTitleDeedDtls.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.ParentTitleDeeddtlsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.ParentTitleDeeddtlsType> enumerateParentTitleDeedDtls(
    ) {
        return this._parentTitleDeedDtlsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListParentTitleDeedDtlsType) {

            ListParentTitleDeedDtlsType temp = (ListParentTitleDeedDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._parentTitleDeedDtlsList != null) {
                if (temp._parentTitleDeedDtlsList == null) return false;
                if (this._parentTitleDeedDtlsList != temp._parentTitleDeedDtlsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._parentTitleDeedDtlsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._parentTitleDeedDtlsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedDtlsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedDtlsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._parentTitleDeedDtlsList.equals(temp._parentTitleDeedDtlsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedDtlsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedDtlsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedDtlsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedDtlsList);
                    }
                }
            } else if (temp._parentTitleDeedDtlsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getParentTitleDeedDtls.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.ParentTitleDeeddtlsType at the given index
     */
    public com.misys.ce.types.ParentTitleDeeddtlsType getParentTitleDeedDtls(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._parentTitleDeedDtlsList.size()) {
            throw new IndexOutOfBoundsException("getParentTitleDeedDtls: Index value '" + index + "' not in range [0.." + (this._parentTitleDeedDtlsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.ParentTitleDeeddtlsType) _parentTitleDeedDtlsList.get(index);
    }

    /**
     * Method getParentTitleDeedDtls.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.ParentTitleDeeddtlsType[] getParentTitleDeedDtls(
    ) {
        com.misys.ce.types.ParentTitleDeeddtlsType[] array = new com.misys.ce.types.ParentTitleDeeddtlsType[0];
        return (com.misys.ce.types.ParentTitleDeeddtlsType[]) this._parentTitleDeedDtlsList.toArray(array);
    }

    /**
     * Method getParentTitleDeedDtlsCount.
     * 
     * @return the size of this collection
     */
    public int getParentTitleDeedDtlsCount(
    ) {
        return this._parentTitleDeedDtlsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_parentTitleDeedDtlsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_parentTitleDeedDtlsList)) {
           result = 37 * result + _parentTitleDeedDtlsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_parentTitleDeedDtlsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllParentTitleDeedDtls(
    ) {
        this._parentTitleDeedDtlsList.clear();
    }

    /**
     * Method removeParentTitleDeedDtls.
     * 
     * @param vParentTitleDeedDtls
     * @return true if the object was removed from the collection.
     */
    public boolean removeParentTitleDeedDtls(
            final com.misys.ce.types.ParentTitleDeeddtlsType vParentTitleDeedDtls) {
        boolean removed = _parentTitleDeedDtlsList.remove(vParentTitleDeedDtls);
        return removed;
    }

    /**
     * Method removeParentTitleDeedDtlsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.ParentTitleDeeddtlsType removeParentTitleDeedDtlsAt(
            final int index) {
        java.lang.Object obj = this._parentTitleDeedDtlsList.remove(index);
        return (com.misys.ce.types.ParentTitleDeeddtlsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vParentTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setParentTitleDeedDtls(
            final int index,
            final com.misys.ce.types.ParentTitleDeeddtlsType vParentTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._parentTitleDeedDtlsList.size()) {
            throw new IndexOutOfBoundsException("setParentTitleDeedDtls: Index value '" + index + "' not in range [0.." + (this._parentTitleDeedDtlsList.size() - 1) + "]");
        }

        this._parentTitleDeedDtlsList.set(index, vParentTitleDeedDtls);
    }

    /**
     * 
     * 
     * @param vParentTitleDeedDtlsArray
     */
    public void setParentTitleDeedDtls(
            final com.misys.ce.types.ParentTitleDeeddtlsType[] vParentTitleDeedDtlsArray) {
        //-- copy array
        _parentTitleDeedDtlsList.clear();

        for (int i = 0; i < vParentTitleDeedDtlsArray.length; i++) {
                this._parentTitleDeedDtlsList.add(vParentTitleDeedDtlsArray[i]);
        }
    }

    /**
     * Method unmarshalListParentTitleDeedDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListParentTitleDeedDtlsType
     */
    public static com.misys.ce.types.ListParentTitleDeedDtlsType unmarshalListParentTitleDeedDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListParentTitleDeedDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListParentTitleDeedDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
