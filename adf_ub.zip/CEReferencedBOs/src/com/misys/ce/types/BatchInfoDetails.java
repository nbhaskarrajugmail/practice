/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class BatchInfoDetails.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class BatchInfoDetails implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _processInThisBatch.
     */
    private java.lang.String _processInThisBatch;

    /**
     * Field _internalAccount.
     */
    private java.lang.String _internalAccount;

    /**
     * Field _branchCd.
     */
    private java.lang.String _branchCd;

    /**
     * Field _nationalId.
     */
    private java.lang.String _nationalId;

    /**
     * Field _loanAccount.
     */
    private java.lang.String _loanAccount;

    /**
     * Field _amount.
     */
    private java.math.BigDecimal _amount;

    /**
     * Field _txnDate.
     */
    private java.sql.Date _txnDate;

    /**
     * Field _txnDateHijri.
     */
    private java.lang.String _txnDateHijri;

    /**
     * Field _narrative.
     */
    private java.lang.String _narrative;

    /**
     * Field _recId.
     */
    private java.lang.String _recId;

    /**
     * Field _status.
     */
    private java.lang.String _status;

    /**
     * Field _gatewayRef.
     */
    private java.lang.String _gatewayRef;

    /**
     * Field _placeholder.
     */
    private java.lang.String _placeholder;

    /**
     * Field _placeholder2.
     */
    private java.lang.String _placeholder2;

    /**
     * Field _placeholder3.
     */
    private java.lang.String _placeholder3;

    /**
     * Field _chequeNumber.
     */
    private java.lang.String _chequeNumber;

    /**
     * Field _chequeDate.
     */
    private java.sql.Date _chequeDate;

    /**
     * Field _MOFDocDate.
     */
    private java.sql.Date _MOFDocDate;

    /**
     * Field _MOFDocNumber.
     */
    private java.lang.String _MOFDocNumber;


      //----------------/
     //- Constructors -/
    //----------------/

    public BatchInfoDetails() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof BatchInfoDetails) {

            BatchInfoDetails temp = (BatchInfoDetails)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._processInThisBatch != null) {
                if (temp._processInThisBatch == null) return false;
                if (this._processInThisBatch != temp._processInThisBatch) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._processInThisBatch);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._processInThisBatch);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processInThisBatch); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processInThisBatch); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._processInThisBatch.equals(temp._processInThisBatch)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processInThisBatch);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processInThisBatch);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processInThisBatch);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processInThisBatch);
                    }
                }
            } else if (temp._processInThisBatch != null)
                return false;
            if (this._internalAccount != null) {
                if (temp._internalAccount == null) return false;
                if (this._internalAccount != temp._internalAccount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._internalAccount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._internalAccount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAccount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAccount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._internalAccount.equals(temp._internalAccount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAccount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAccount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAccount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAccount);
                    }
                }
            } else if (temp._internalAccount != null)
                return false;
            if (this._branchCd != null) {
                if (temp._branchCd == null) return false;
                if (this._branchCd != temp._branchCd) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._branchCd);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._branchCd);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchCd); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchCd); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._branchCd.equals(temp._branchCd)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchCd);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchCd);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchCd);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchCd);
                    }
                }
            } else if (temp._branchCd != null)
                return false;
            if (this._nationalId != null) {
                if (temp._nationalId == null) return false;
                if (this._nationalId != temp._nationalId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._nationalId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._nationalId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._nationalId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._nationalId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._nationalId.equals(temp._nationalId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._nationalId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._nationalId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._nationalId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._nationalId);
                    }
                }
            } else if (temp._nationalId != null)
                return false;
            if (this._loanAccount != null) {
                if (temp._loanAccount == null) return false;
                if (this._loanAccount != temp._loanAccount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._loanAccount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._loanAccount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._loanAccount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._loanAccount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._loanAccount.equals(temp._loanAccount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._loanAccount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._loanAccount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._loanAccount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._loanAccount);
                    }
                }
            } else if (temp._loanAccount != null)
                return false;
            if (this._amount != null) {
                if (temp._amount == null) return false;
                if (this._amount != temp._amount) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._amount);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._amount);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amount); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amount); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._amount.equals(temp._amount)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amount);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amount);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amount);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amount);
                    }
                }
            } else if (temp._amount != null)
                return false;
            if (this._txnDate != null) {
                if (temp._txnDate == null) return false;
                if (this._txnDate != temp._txnDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._txnDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._txnDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._txnDate.equals(temp._txnDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate);
                    }
                }
            } else if (temp._txnDate != null)
                return false;
            if (this._txnDateHijri != null) {
                if (temp._txnDateHijri == null) return false;
                if (this._txnDateHijri != temp._txnDateHijri) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._txnDateHijri);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._txnDateHijri);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDateHijri); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDateHijri); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._txnDateHijri.equals(temp._txnDateHijri)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDateHijri);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDateHijri);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDateHijri);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDateHijri);
                    }
                }
            } else if (temp._txnDateHijri != null)
                return false;
            if (this._narrative != null) {
                if (temp._narrative == null) return false;
                if (this._narrative != temp._narrative) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._narrative);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._narrative);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._narrative); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._narrative); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._narrative.equals(temp._narrative)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._narrative);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._narrative);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._narrative);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._narrative);
                    }
                }
            } else if (temp._narrative != null)
                return false;
            if (this._recId != null) {
                if (temp._recId == null) return false;
                if (this._recId != temp._recId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._recId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._recId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._recId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._recId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._recId.equals(temp._recId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._recId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._recId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._recId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._recId);
                    }
                }
            } else if (temp._recId != null)
                return false;
            if (this._status != null) {
                if (temp._status == null) return false;
                if (this._status != temp._status) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._status);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._status);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._status.equals(temp._status)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                    }
                }
            } else if (temp._status != null)
                return false;
            if (this._gatewayRef != null) {
                if (temp._gatewayRef == null) return false;
                if (this._gatewayRef != temp._gatewayRef) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._gatewayRef);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._gatewayRef);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._gatewayRef); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._gatewayRef); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._gatewayRef.equals(temp._gatewayRef)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._gatewayRef);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._gatewayRef);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._gatewayRef);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._gatewayRef);
                    }
                }
            } else if (temp._gatewayRef != null)
                return false;
            if (this._placeholder != null) {
                if (temp._placeholder == null) return false;
                if (this._placeholder != temp._placeholder) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._placeholder);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._placeholder);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._placeholder.equals(temp._placeholder)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder);
                    }
                }
            } else if (temp._placeholder != null)
                return false;
            if (this._placeholder2 != null) {
                if (temp._placeholder2 == null) return false;
                if (this._placeholder2 != temp._placeholder2) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._placeholder2);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._placeholder2);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder2); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder2); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._placeholder2.equals(temp._placeholder2)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder2);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder2);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder2);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder2);
                    }
                }
            } else if (temp._placeholder2 != null)
                return false;
            if (this._placeholder3 != null) {
                if (temp._placeholder3 == null) return false;
                if (this._placeholder3 != temp._placeholder3) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._placeholder3);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._placeholder3);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder3); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder3); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._placeholder3.equals(temp._placeholder3)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder3);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder3);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder3);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder3);
                    }
                }
            } else if (temp._placeholder3 != null)
                return false;
            if (this._chequeNumber != null) {
                if (temp._chequeNumber == null) return false;
                if (this._chequeNumber != temp._chequeNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._chequeNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._chequeNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._chequeNumber.equals(temp._chequeNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeNumber);
                    }
                }
            } else if (temp._chequeNumber != null)
                return false;
            if (this._chequeDate != null) {
                if (temp._chequeDate == null) return false;
                if (this._chequeDate != temp._chequeDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._chequeDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._chequeDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._chequeDate.equals(temp._chequeDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._chequeDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._chequeDate);
                    }
                }
            } else if (temp._chequeDate != null)
                return false;
            if (this._MOFDocDate != null) {
                if (temp._MOFDocDate == null) return false;
                if (this._MOFDocDate != temp._MOFDocDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._MOFDocDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._MOFDocDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._MOFDocDate.equals(temp._MOFDocDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocDate);
                    }
                }
            } else if (temp._MOFDocDate != null)
                return false;
            if (this._MOFDocNumber != null) {
                if (temp._MOFDocNumber == null) return false;
                if (this._MOFDocNumber != temp._MOFDocNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._MOFDocNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._MOFDocNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._MOFDocNumber.equals(temp._MOFDocNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._MOFDocNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._MOFDocNumber);
                    }
                }
            } else if (temp._MOFDocNumber != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'amount'.
     * 
     * @return the value of field 'Amount'.
     */
    public java.math.BigDecimal getAmount(
    ) {
        return this._amount;
    }

    /**
     * Returns the value of field 'branchCd'.
     * 
     * @return the value of field 'BranchCd'.
     */
    public java.lang.String getBranchCd(
    ) {
        return this._branchCd;
    }

    /**
     * Returns the value of field 'chequeDate'.
     * 
     * @return the value of field 'ChequeDate'.
     */
    public java.sql.Date getChequeDate(
    ) {
        return this._chequeDate;
    }

    /**
     * Returns the value of field 'chequeNumber'.
     * 
     * @return the value of field 'ChequeNumber'.
     */
    public java.lang.String getChequeNumber(
    ) {
        return this._chequeNumber;
    }

    /**
     * Returns the value of field 'gatewayRef'.
     * 
     * @return the value of field 'GatewayRef'.
     */
    public java.lang.String getGatewayRef(
    ) {
        return this._gatewayRef;
    }

    /**
     * Returns the value of field 'internalAccount'.
     * 
     * @return the value of field 'InternalAccount'.
     */
    public java.lang.String getInternalAccount(
    ) {
        return this._internalAccount;
    }

    /**
     * Returns the value of field 'loanAccount'.
     * 
     * @return the value of field 'LoanAccount'.
     */
    public java.lang.String getLoanAccount(
    ) {
        return this._loanAccount;
    }

    /**
     * Returns the value of field 'MOFDocDate'.
     * 
     * @return the value of field 'MOFDocDate'.
     */
    public java.sql.Date getMOFDocDate(
    ) {
        return this._MOFDocDate;
    }

    /**
     * Returns the value of field 'MOFDocNumber'.
     * 
     * @return the value of field 'MOFDocNumber'.
     */
    public java.lang.String getMOFDocNumber(
    ) {
        return this._MOFDocNumber;
    }

    /**
     * Returns the value of field 'narrative'.
     * 
     * @return the value of field 'Narrative'.
     */
    public java.lang.String getNarrative(
    ) {
        return this._narrative;
    }

    /**
     * Returns the value of field 'nationalId'.
     * 
     * @return the value of field 'NationalId'.
     */
    public java.lang.String getNationalId(
    ) {
        return this._nationalId;
    }

    /**
     * Returns the value of field 'placeholder'.
     * 
     * @return the value of field 'Placeholder'.
     */
    public java.lang.String getPlaceholder(
    ) {
        return this._placeholder;
    }

    /**
     * Returns the value of field 'placeholder2'.
     * 
     * @return the value of field 'Placeholder2'.
     */
    public java.lang.String getPlaceholder2(
    ) {
        return this._placeholder2;
    }

    /**
     * Returns the value of field 'placeholder3'.
     * 
     * @return the value of field 'Placeholder3'.
     */
    public java.lang.String getPlaceholder3(
    ) {
        return this._placeholder3;
    }

    /**
     * Returns the value of field 'processInThisBatch'.
     * 
     * @return the value of field 'ProcessInThisBatch'.
     */
    public java.lang.String getProcessInThisBatch(
    ) {
        return this._processInThisBatch;
    }

    /**
     * Returns the value of field 'recId'.
     * 
     * @return the value of field 'RecId'.
     */
    public java.lang.String getRecId(
    ) {
        return this._recId;
    }

    /**
     * Returns the value of field 'status'.
     * 
     * @return the value of field 'Status'.
     */
    public java.lang.String getStatus(
    ) {
        return this._status;
    }

    /**
     * Returns the value of field 'txnDate'.
     * 
     * @return the value of field 'TxnDate'.
     */
    public java.sql.Date getTxnDate(
    ) {
        return this._txnDate;
    }

    /**
     * Returns the value of field 'txnDateHijri'.
     * 
     * @return the value of field 'TxnDateHijri'.
     */
    public java.lang.String getTxnDateHijri(
    ) {
        return this._txnDateHijri;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_processInThisBatch != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_processInThisBatch)) {
           result = 37 * result + _processInThisBatch.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_processInThisBatch);
        }
        if (_internalAccount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_internalAccount)) {
           result = 37 * result + _internalAccount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_internalAccount);
        }
        if (_branchCd != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_branchCd)) {
           result = 37 * result + _branchCd.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_branchCd);
        }
        if (_nationalId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_nationalId)) {
           result = 37 * result + _nationalId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_nationalId);
        }
        if (_loanAccount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_loanAccount)) {
           result = 37 * result + _loanAccount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_loanAccount);
        }
        if (_amount != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_amount)) {
           result = 37 * result + _amount.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_amount);
        }
        if (_txnDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_txnDate)) {
           result = 37 * result + _txnDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_txnDate);
        }
        if (_txnDateHijri != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_txnDateHijri)) {
           result = 37 * result + _txnDateHijri.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_txnDateHijri);
        }
        if (_narrative != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_narrative)) {
           result = 37 * result + _narrative.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_narrative);
        }
        if (_recId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_recId)) {
           result = 37 * result + _recId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_recId);
        }
        if (_status != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_status)) {
           result = 37 * result + _status.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_status);
        }
        if (_gatewayRef != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_gatewayRef)) {
           result = 37 * result + _gatewayRef.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_gatewayRef);
        }
        if (_placeholder != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_placeholder)) {
           result = 37 * result + _placeholder.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_placeholder);
        }
        if (_placeholder2 != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_placeholder2)) {
           result = 37 * result + _placeholder2.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_placeholder2);
        }
        if (_placeholder3 != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_placeholder3)) {
           result = 37 * result + _placeholder3.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_placeholder3);
        }
        if (_chequeNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_chequeNumber)) {
           result = 37 * result + _chequeNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_chequeNumber);
        }
        if (_chequeDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_chequeDate)) {
           result = 37 * result + _chequeDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_chequeDate);
        }
        if (_MOFDocDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_MOFDocDate)) {
           result = 37 * result + _MOFDocDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_MOFDocDate);
        }
        if (_MOFDocNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_MOFDocNumber)) {
           result = 37 * result + _MOFDocNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_MOFDocNumber);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'amount'.
     * 
     * @param amount the value of field 'amount'.
     */
    public void setAmount(
            final java.math.BigDecimal amount) {
        this._amount = amount;
    }

    /**
     * Sets the value of field 'branchCd'.
     * 
     * @param branchCd the value of field 'branchCd'.
     */
    public void setBranchCd(
            final java.lang.String branchCd) {
        this._branchCd = branchCd;
    }

    /**
     * Sets the value of field 'chequeDate'.
     * 
     * @param chequeDate the value of field 'chequeDate'.
     */
    public void setChequeDate(
            final java.sql.Date chequeDate) {
        this._chequeDate = chequeDate;
    }

    /**
     * Sets the value of field 'chequeNumber'.
     * 
     * @param chequeNumber the value of field 'chequeNumber'.
     */
    public void setChequeNumber(
            final java.lang.String chequeNumber) {
        this._chequeNumber = chequeNumber;
    }

    /**
     * Sets the value of field 'gatewayRef'.
     * 
     * @param gatewayRef the value of field 'gatewayRef'.
     */
    public void setGatewayRef(
            final java.lang.String gatewayRef) {
        this._gatewayRef = gatewayRef;
    }

    /**
     * Sets the value of field 'internalAccount'.
     * 
     * @param internalAccount the value of field 'internalAccount'.
     */
    public void setInternalAccount(
            final java.lang.String internalAccount) {
        this._internalAccount = internalAccount;
    }

    /**
     * Sets the value of field 'loanAccount'.
     * 
     * @param loanAccount the value of field 'loanAccount'.
     */
    public void setLoanAccount(
            final java.lang.String loanAccount) {
        this._loanAccount = loanAccount;
    }

    /**
     * Sets the value of field 'MOFDocDate'.
     * 
     * @param MOFDocDate the value of field 'MOFDocDate'.
     */
    public void setMOFDocDate(
            final java.sql.Date MOFDocDate) {
        this._MOFDocDate = MOFDocDate;
    }

    /**
     * Sets the value of field 'MOFDocNumber'.
     * 
     * @param MOFDocNumber the value of field 'MOFDocNumber'.
     */
    public void setMOFDocNumber(
            final java.lang.String MOFDocNumber) {
        this._MOFDocNumber = MOFDocNumber;
    }

    /**
     * Sets the value of field 'narrative'.
     * 
     * @param narrative the value of field 'narrative'.
     */
    public void setNarrative(
            final java.lang.String narrative) {
        this._narrative = narrative;
    }

    /**
     * Sets the value of field 'nationalId'.
     * 
     * @param nationalId the value of field 'nationalId'.
     */
    public void setNationalId(
            final java.lang.String nationalId) {
        this._nationalId = nationalId;
    }

    /**
     * Sets the value of field 'placeholder'.
     * 
     * @param placeholder the value of field 'placeholder'.
     */
    public void setPlaceholder(
            final java.lang.String placeholder) {
        this._placeholder = placeholder;
    }

    /**
     * Sets the value of field 'placeholder2'.
     * 
     * @param placeholder2 the value of field 'placeholder2'.
     */
    public void setPlaceholder2(
            final java.lang.String placeholder2) {
        this._placeholder2 = placeholder2;
    }

    /**
     * Sets the value of field 'placeholder3'.
     * 
     * @param placeholder3 the value of field 'placeholder3'.
     */
    public void setPlaceholder3(
            final java.lang.String placeholder3) {
        this._placeholder3 = placeholder3;
    }

    /**
     * Sets the value of field 'processInThisBatch'.
     * 
     * @param processInThisBatch the value of field
     * 'processInThisBatch'.
     */
    public void setProcessInThisBatch(
            final java.lang.String processInThisBatch) {
        this._processInThisBatch = processInThisBatch;
    }

    /**
     * Sets the value of field 'recId'.
     * 
     * @param recId the value of field 'recId'.
     */
    public void setRecId(
            final java.lang.String recId) {
        this._recId = recId;
    }

    /**
     * Sets the value of field 'status'.
     * 
     * @param status the value of field 'status'.
     */
    public void setStatus(
            final java.lang.String status) {
        this._status = status;
    }

    /**
     * Sets the value of field 'txnDate'.
     * 
     * @param txnDate the value of field 'txnDate'.
     */
    public void setTxnDate(
            final java.sql.Date txnDate) {
        this._txnDate = txnDate;
    }

    /**
     * Sets the value of field 'txnDateHijri'.
     * 
     * @param txnDateHijri the value of field 'txnDateHijri'.
     */
    public void setTxnDateHijri(
            final java.lang.String txnDateHijri) {
        this._txnDateHijri = txnDateHijri;
    }

    /**
     * Method unmarshalBatchInfoDetails.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled com.misys.ce.types.BatchInfoDetails
     */
    public static com.misys.ce.types.BatchInfoDetails unmarshalBatchInfoDetails(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.BatchInfoDetails) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.BatchInfoDetails.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
