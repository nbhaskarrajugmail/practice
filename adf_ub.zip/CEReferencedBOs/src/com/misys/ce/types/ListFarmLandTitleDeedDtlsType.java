/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListFarmLandTitleDeedDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListFarmLandTitleDeedDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _farmLandTitleDeedDtlsList.
     */
    private java.util.Vector<com.misys.ce.types.FarmLandTitleDeeddtlsType> _farmLandTitleDeedDtlsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListFarmLandTitleDeedDtlsType() {
        super();
        this._farmLandTitleDeedDtlsList = new java.util.Vector<com.misys.ce.types.FarmLandTitleDeeddtlsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vFarmLandTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandTitleDeedDtls(
            final com.misys.ce.types.FarmLandTitleDeeddtlsType vFarmLandTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandTitleDeedDtlsList.addElement(vFarmLandTitleDeedDtls);
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandTitleDeedDtls(
            final int index,
            final com.misys.ce.types.FarmLandTitleDeeddtlsType vFarmLandTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandTitleDeedDtlsList.add(index, vFarmLandTitleDeedDtls);
    }

    /**
     * Method enumerateFarmLandTitleDeedDtls.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.FarmLandTitleDeeddtlsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.FarmLandTitleDeeddtlsType> enumerateFarmLandTitleDeedDtls(
    ) {
        return this._farmLandTitleDeedDtlsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListFarmLandTitleDeedDtlsType) {

            ListFarmLandTitleDeedDtlsType temp = (ListFarmLandTitleDeedDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._farmLandTitleDeedDtlsList != null) {
                if (temp._farmLandTitleDeedDtlsList == null) return false;
                if (this._farmLandTitleDeedDtlsList != temp._farmLandTitleDeedDtlsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLandTitleDeedDtlsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLandTitleDeedDtlsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandTitleDeedDtlsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandTitleDeedDtlsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLandTitleDeedDtlsList.equals(temp._farmLandTitleDeedDtlsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandTitleDeedDtlsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandTitleDeedDtlsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandTitleDeedDtlsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandTitleDeedDtlsList);
                    }
                }
            } else if (temp._farmLandTitleDeedDtlsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getFarmLandTitleDeedDtls.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.FarmLandTitleDeeddtlsType at the given
     * index
     */
    public com.misys.ce.types.FarmLandTitleDeeddtlsType getFarmLandTitleDeedDtls(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandTitleDeedDtlsList.size()) {
            throw new IndexOutOfBoundsException("getFarmLandTitleDeedDtls: Index value '" + index + "' not in range [0.." + (this._farmLandTitleDeedDtlsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.FarmLandTitleDeeddtlsType) _farmLandTitleDeedDtlsList.get(index);
    }

    /**
     * Method getFarmLandTitleDeedDtls.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.FarmLandTitleDeeddtlsType[] getFarmLandTitleDeedDtls(
    ) {
        com.misys.ce.types.FarmLandTitleDeeddtlsType[] array = new com.misys.ce.types.FarmLandTitleDeeddtlsType[0];
        return (com.misys.ce.types.FarmLandTitleDeeddtlsType[]) this._farmLandTitleDeedDtlsList.toArray(array);
    }

    /**
     * Method getFarmLandTitleDeedDtlsCount.
     * 
     * @return the size of this collection
     */
    public int getFarmLandTitleDeedDtlsCount(
    ) {
        return this._farmLandTitleDeedDtlsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_farmLandTitleDeedDtlsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLandTitleDeedDtlsList)) {
           result = 37 * result + _farmLandTitleDeedDtlsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLandTitleDeedDtlsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllFarmLandTitleDeedDtls(
    ) {
        this._farmLandTitleDeedDtlsList.clear();
    }

    /**
     * Method removeFarmLandTitleDeedDtls.
     * 
     * @param vFarmLandTitleDeedDtls
     * @return true if the object was removed from the collection.
     */
    public boolean removeFarmLandTitleDeedDtls(
            final com.misys.ce.types.FarmLandTitleDeeddtlsType vFarmLandTitleDeedDtls) {
        boolean removed = _farmLandTitleDeedDtlsList.remove(vFarmLandTitleDeedDtls);
        return removed;
    }

    /**
     * Method removeFarmLandTitleDeedDtlsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.FarmLandTitleDeeddtlsType removeFarmLandTitleDeedDtlsAt(
            final int index) {
        java.lang.Object obj = this._farmLandTitleDeedDtlsList.remove(index);
        return (com.misys.ce.types.FarmLandTitleDeeddtlsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandTitleDeedDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setFarmLandTitleDeedDtls(
            final int index,
            final com.misys.ce.types.FarmLandTitleDeeddtlsType vFarmLandTitleDeedDtls)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandTitleDeedDtlsList.size()) {
            throw new IndexOutOfBoundsException("setFarmLandTitleDeedDtls: Index value '" + index + "' not in range [0.." + (this._farmLandTitleDeedDtlsList.size() - 1) + "]");
        }

        this._farmLandTitleDeedDtlsList.set(index, vFarmLandTitleDeedDtls);
    }

    /**
     * 
     * 
     * @param vFarmLandTitleDeedDtlsArray
     */
    public void setFarmLandTitleDeedDtls(
            final com.misys.ce.types.FarmLandTitleDeeddtlsType[] vFarmLandTitleDeedDtlsArray) {
        //-- copy array
        _farmLandTitleDeedDtlsList.clear();

        for (int i = 0; i < vFarmLandTitleDeedDtlsArray.length; i++) {
                this._farmLandTitleDeedDtlsList.add(vFarmLandTitleDeedDtlsArray[i]);
        }
    }

    /**
     * Method unmarshalListFarmLandTitleDeedDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListFarmLandTitleDeedDtlsType
     */
    public static com.misys.ce.types.ListFarmLandTitleDeedDtlsType unmarshalListFarmLandTitleDeedDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListFarmLandTitleDeedDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListFarmLandTitleDeedDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
