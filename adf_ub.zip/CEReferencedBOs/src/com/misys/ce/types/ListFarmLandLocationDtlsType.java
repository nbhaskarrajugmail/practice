/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListFarmLandLocationDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListFarmLandLocationDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _farmLandLocationDtlsList.
     */
    private java.util.Vector<com.misys.ce.types.FarmLandLocationdtlsType> _farmLandLocationDtlsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListFarmLandLocationDtlsType() {
        super();
        this._farmLandLocationDtlsList = new java.util.Vector<com.misys.ce.types.FarmLandLocationdtlsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vFarmLandLocationDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandLocationDtls(
            final com.misys.ce.types.FarmLandLocationdtlsType vFarmLandLocationDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandLocationDtlsList.addElement(vFarmLandLocationDtls);
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandLocationDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandLocationDtls(
            final int index,
            final com.misys.ce.types.FarmLandLocationdtlsType vFarmLandLocationDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandLocationDtlsList.add(index, vFarmLandLocationDtls);
    }

    /**
     * Method enumerateFarmLandLocationDtls.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.FarmLandLocationdtlsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.FarmLandLocationdtlsType> enumerateFarmLandLocationDtls(
    ) {
        return this._farmLandLocationDtlsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListFarmLandLocationDtlsType) {

            ListFarmLandLocationDtlsType temp = (ListFarmLandLocationDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._farmLandLocationDtlsList != null) {
                if (temp._farmLandLocationDtlsList == null) return false;
                if (this._farmLandLocationDtlsList != temp._farmLandLocationDtlsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLandLocationDtlsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLandLocationDtlsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationDtlsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationDtlsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLandLocationDtlsList.equals(temp._farmLandLocationDtlsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationDtlsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationDtlsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationDtlsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationDtlsList);
                    }
                }
            } else if (temp._farmLandLocationDtlsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getFarmLandLocationDtls.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.FarmLandLocationdtlsType at the given inde
     */
    public com.misys.ce.types.FarmLandLocationdtlsType getFarmLandLocationDtls(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandLocationDtlsList.size()) {
            throw new IndexOutOfBoundsException("getFarmLandLocationDtls: Index value '" + index + "' not in range [0.." + (this._farmLandLocationDtlsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.FarmLandLocationdtlsType) _farmLandLocationDtlsList.get(index);
    }

    /**
     * Method getFarmLandLocationDtls.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.FarmLandLocationdtlsType[] getFarmLandLocationDtls(
    ) {
        com.misys.ce.types.FarmLandLocationdtlsType[] array = new com.misys.ce.types.FarmLandLocationdtlsType[0];
        return (com.misys.ce.types.FarmLandLocationdtlsType[]) this._farmLandLocationDtlsList.toArray(array);
    }

    /**
     * Method getFarmLandLocationDtlsCount.
     * 
     * @return the size of this collection
     */
    public int getFarmLandLocationDtlsCount(
    ) {
        return this._farmLandLocationDtlsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_farmLandLocationDtlsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLandLocationDtlsList)) {
           result = 37 * result + _farmLandLocationDtlsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLandLocationDtlsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllFarmLandLocationDtls(
    ) {
        this._farmLandLocationDtlsList.clear();
    }

    /**
     * Method removeFarmLandLocationDtls.
     * 
     * @param vFarmLandLocationDtls
     * @return true if the object was removed from the collection.
     */
    public boolean removeFarmLandLocationDtls(
            final com.misys.ce.types.FarmLandLocationdtlsType vFarmLandLocationDtls) {
        boolean removed = _farmLandLocationDtlsList.remove(vFarmLandLocationDtls);
        return removed;
    }

    /**
     * Method removeFarmLandLocationDtlsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.FarmLandLocationdtlsType removeFarmLandLocationDtlsAt(
            final int index) {
        java.lang.Object obj = this._farmLandLocationDtlsList.remove(index);
        return (com.misys.ce.types.FarmLandLocationdtlsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandLocationDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setFarmLandLocationDtls(
            final int index,
            final com.misys.ce.types.FarmLandLocationdtlsType vFarmLandLocationDtls)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandLocationDtlsList.size()) {
            throw new IndexOutOfBoundsException("setFarmLandLocationDtls: Index value '" + index + "' not in range [0.." + (this._farmLandLocationDtlsList.size() - 1) + "]");
        }

        this._farmLandLocationDtlsList.set(index, vFarmLandLocationDtls);
    }

    /**
     * 
     * 
     * @param vFarmLandLocationDtlsArray
     */
    public void setFarmLandLocationDtls(
            final com.misys.ce.types.FarmLandLocationdtlsType[] vFarmLandLocationDtlsArray) {
        //-- copy array
        _farmLandLocationDtlsList.clear();

        for (int i = 0; i < vFarmLandLocationDtlsArray.length; i++) {
                this._farmLandLocationDtlsList.add(vFarmLandLocationDtlsArray[i]);
        }
    }

    /**
     * Method unmarshalListFarmLandLocationDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListFarmLandLocationDtlsType
     */
    public static com.misys.ce.types.ListFarmLandLocationDtlsType unmarshalListFarmLandLocationDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListFarmLandLocationDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListFarmLandLocationDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
