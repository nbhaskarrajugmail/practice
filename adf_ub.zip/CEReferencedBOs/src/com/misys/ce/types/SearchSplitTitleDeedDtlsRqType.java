/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchSplitTitleDeedDtlsRqType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchSplitTitleDeedDtlsRqType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _searchSplitTitleDeedDtls.
     */
    private com.misys.ce.types.TitleDeedDetailsType _searchSplitTitleDeedDtls;

    /**
     * Field _pagingInfo.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagingInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchSplitTitleDeedDtlsRqType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchSplitTitleDeedDtlsRqType) {

            SearchSplitTitleDeedDtlsRqType temp = (SearchSplitTitleDeedDtlsRqType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._searchSplitTitleDeedDtls != null) {
                if (temp._searchSplitTitleDeedDtls == null) return false;
                if (this._searchSplitTitleDeedDtls != temp._searchSplitTitleDeedDtls) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._searchSplitTitleDeedDtls);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._searchSplitTitleDeedDtls);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchSplitTitleDeedDtls); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchSplitTitleDeedDtls); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._searchSplitTitleDeedDtls.equals(temp._searchSplitTitleDeedDtls)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchSplitTitleDeedDtls);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchSplitTitleDeedDtls);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchSplitTitleDeedDtls);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchSplitTitleDeedDtls);
                    }
                }
            } else if (temp._searchSplitTitleDeedDtls != null)
                return false;
            if (this._pagingInfo != null) {
                if (temp._pagingInfo == null) return false;
                if (this._pagingInfo != temp._pagingInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagingInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagingInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagingInfo.equals(temp._pagingInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                    }
                }
            } else if (temp._pagingInfo != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'pagingInfo'.
     * 
     * @return the value of field 'PagingInfo'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagingInfo(
    ) {
        return this._pagingInfo;
    }

    /**
     * Returns the value of field 'searchSplitTitleDeedDtls'.
     * 
     * @return the value of field 'SearchSplitTitleDeedDtls'.
     */
    public com.misys.ce.types.TitleDeedDetailsType getSearchSplitTitleDeedDtls(
    ) {
        return this._searchSplitTitleDeedDtls;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_searchSplitTitleDeedDtls != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_searchSplitTitleDeedDtls)) {
           result = 37 * result + _searchSplitTitleDeedDtls.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_searchSplitTitleDeedDtls);
        }
        if (_pagingInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagingInfo)) {
           result = 37 * result + _pagingInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagingInfo);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'pagingInfo'.
     * 
     * @param pagingInfo the value of field 'pagingInfo'.
     */
    public void setPagingInfo(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagingInfo) {
        this._pagingInfo = pagingInfo;
    }

    /**
     * Sets the value of field 'searchSplitTitleDeedDtls'.
     * 
     * @param searchSplitTitleDeedDtls the value of field
     * 'searchSplitTitleDeedDtls'.
     */
    public void setSearchSplitTitleDeedDtls(
            final com.misys.ce.types.TitleDeedDetailsType searchSplitTitleDeedDtls) {
        this._searchSplitTitleDeedDtls = searchSplitTitleDeedDtls;
    }

    /**
     * Method unmarshalSearchSplitTitleDeedDtlsRqType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchSplitTitleDeedDtlsRqType
     */
    public static com.misys.ce.types.SearchSplitTitleDeedDtlsRqType unmarshalSearchSplitTitleDeedDtlsRqType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchSplitTitleDeedDtlsRqType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchSplitTitleDeedDtlsRqType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
