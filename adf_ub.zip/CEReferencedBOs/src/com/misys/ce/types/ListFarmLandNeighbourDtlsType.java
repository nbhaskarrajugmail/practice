/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListFarmLandNeighbourDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListFarmLandNeighbourDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _farmLandNeighbourDtlsList.
     */
    private java.util.Vector<com.misys.ce.types.FarmLandNeighbourdtlsType> _farmLandNeighbourDtlsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListFarmLandNeighbourDtlsType() {
        super();
        this._farmLandNeighbourDtlsList = new java.util.Vector<com.misys.ce.types.FarmLandNeighbourdtlsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vFarmLandNeighbourDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandNeighbourDtls(
            final com.misys.ce.types.FarmLandNeighbourdtlsType vFarmLandNeighbourDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandNeighbourDtlsList.addElement(vFarmLandNeighbourDtls);
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandNeighbourDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addFarmLandNeighbourDtls(
            final int index,
            final com.misys.ce.types.FarmLandNeighbourdtlsType vFarmLandNeighbourDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._farmLandNeighbourDtlsList.add(index, vFarmLandNeighbourDtls);
    }

    /**
     * Method enumerateFarmLandNeighbourDtls.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.FarmLandNeighbourdtlsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.FarmLandNeighbourdtlsType> enumerateFarmLandNeighbourDtls(
    ) {
        return this._farmLandNeighbourDtlsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListFarmLandNeighbourDtlsType) {

            ListFarmLandNeighbourDtlsType temp = (ListFarmLandNeighbourDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._farmLandNeighbourDtlsList != null) {
                if (temp._farmLandNeighbourDtlsList == null) return false;
                if (this._farmLandNeighbourDtlsList != temp._farmLandNeighbourDtlsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLandNeighbourDtlsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLandNeighbourDtlsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbourDtlsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbourDtlsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLandNeighbourDtlsList.equals(temp._farmLandNeighbourDtlsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbourDtlsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbourDtlsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbourDtlsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbourDtlsList);
                    }
                }
            } else if (temp._farmLandNeighbourDtlsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getFarmLandNeighbourDtls.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.FarmLandNeighbourdtlsType at the given
     * index
     */
    public com.misys.ce.types.FarmLandNeighbourdtlsType getFarmLandNeighbourDtls(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandNeighbourDtlsList.size()) {
            throw new IndexOutOfBoundsException("getFarmLandNeighbourDtls: Index value '" + index + "' not in range [0.." + (this._farmLandNeighbourDtlsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.FarmLandNeighbourdtlsType) _farmLandNeighbourDtlsList.get(index);
    }

    /**
     * Method getFarmLandNeighbourDtls.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.FarmLandNeighbourdtlsType[] getFarmLandNeighbourDtls(
    ) {
        com.misys.ce.types.FarmLandNeighbourdtlsType[] array = new com.misys.ce.types.FarmLandNeighbourdtlsType[0];
        return (com.misys.ce.types.FarmLandNeighbourdtlsType[]) this._farmLandNeighbourDtlsList.toArray(array);
    }

    /**
     * Method getFarmLandNeighbourDtlsCount.
     * 
     * @return the size of this collection
     */
    public int getFarmLandNeighbourDtlsCount(
    ) {
        return this._farmLandNeighbourDtlsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_farmLandNeighbourDtlsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLandNeighbourDtlsList)) {
           result = 37 * result + _farmLandNeighbourDtlsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLandNeighbourDtlsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllFarmLandNeighbourDtls(
    ) {
        this._farmLandNeighbourDtlsList.clear();
    }

    /**
     * Method removeFarmLandNeighbourDtls.
     * 
     * @param vFarmLandNeighbourDtls
     * @return true if the object was removed from the collection.
     */
    public boolean removeFarmLandNeighbourDtls(
            final com.misys.ce.types.FarmLandNeighbourdtlsType vFarmLandNeighbourDtls) {
        boolean removed = _farmLandNeighbourDtlsList.remove(vFarmLandNeighbourDtls);
        return removed;
    }

    /**
     * Method removeFarmLandNeighbourDtlsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.FarmLandNeighbourdtlsType removeFarmLandNeighbourDtlsAt(
            final int index) {
        java.lang.Object obj = this._farmLandNeighbourDtlsList.remove(index);
        return (com.misys.ce.types.FarmLandNeighbourdtlsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vFarmLandNeighbourDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setFarmLandNeighbourDtls(
            final int index,
            final com.misys.ce.types.FarmLandNeighbourdtlsType vFarmLandNeighbourDtls)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._farmLandNeighbourDtlsList.size()) {
            throw new IndexOutOfBoundsException("setFarmLandNeighbourDtls: Index value '" + index + "' not in range [0.." + (this._farmLandNeighbourDtlsList.size() - 1) + "]");
        }

        this._farmLandNeighbourDtlsList.set(index, vFarmLandNeighbourDtls);
    }

    /**
     * 
     * 
     * @param vFarmLandNeighbourDtlsArray
     */
    public void setFarmLandNeighbourDtls(
            final com.misys.ce.types.FarmLandNeighbourdtlsType[] vFarmLandNeighbourDtlsArray) {
        //-- copy array
        _farmLandNeighbourDtlsList.clear();

        for (int i = 0; i < vFarmLandNeighbourDtlsArray.length; i++) {
                this._farmLandNeighbourDtlsList.add(vFarmLandNeighbourDtlsArray[i]);
        }
    }

    /**
     * Method unmarshalListFarmLandNeighbourDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListFarmLandNeighbourDtlsType
     */
    public static com.misys.ce.types.ListFarmLandNeighbourDtlsType unmarshalListFarmLandNeighbourDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListFarmLandNeighbourDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListFarmLandNeighbourDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
