/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchTitleDeedDtlsByNumberRqType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchTitleDeedDtlsByNumberRqType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedNumber.
     */
    private com.misys.ce.types.TitleDeedNumSearch _titleDeedNumber;

    /**
     * Field _pagedQuery.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagedQuery;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchTitleDeedDtlsByNumberRqType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchTitleDeedDtlsByNumberRqType) {

            SearchTitleDeedDtlsByNumberRqType temp = (SearchTitleDeedDtlsByNumberRqType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedNumber != null) {
                if (temp._titleDeedNumber == null) return false;
                if (this._titleDeedNumber != temp._titleDeedNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedNumber.equals(temp._titleDeedNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                    }
                }
            } else if (temp._titleDeedNumber != null)
                return false;
            if (this._pagedQuery != null) {
                if (temp._pagedQuery == null) return false;
                if (this._pagedQuery != temp._pagedQuery) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagedQuery);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagedQuery);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagedQuery); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagedQuery); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagedQuery.equals(temp._pagedQuery)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagedQuery);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagedQuery);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagedQuery);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagedQuery);
                    }
                }
            } else if (temp._pagedQuery != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'pagedQuery'.
     * 
     * @return the value of field 'PagedQuery'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagedQuery(
    ) {
        return this._pagedQuery;
    }

    /**
     * Returns the value of field 'titleDeedNumber'.
     * 
     * @return the value of field 'TitleDeedNumber'.
     */
    public com.misys.ce.types.TitleDeedNumSearch getTitleDeedNumber(
    ) {
        return this._titleDeedNumber;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedNumber)) {
           result = 37 * result + _titleDeedNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedNumber);
        }
        if (_pagedQuery != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagedQuery)) {
           result = 37 * result + _pagedQuery.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagedQuery);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'pagedQuery'.
     * 
     * @param pagedQuery the value of field 'pagedQuery'.
     */
    public void setPagedQuery(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagedQuery) {
        this._pagedQuery = pagedQuery;
    }

    /**
     * Sets the value of field 'titleDeedNumber'.
     * 
     * @param titleDeedNumber the value of field 'titleDeedNumber'.
     */
    public void setTitleDeedNumber(
            final com.misys.ce.types.TitleDeedNumSearch titleDeedNumber) {
        this._titleDeedNumber = titleDeedNumber;
    }

    /**
     * Method unmarshalSearchTitleDeedDtlsByNumberRqType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchTitleDeedDtlsByNumberRqType
     */
    public static com.misys.ce.types.SearchTitleDeedDtlsByNumberRqType unmarshalSearchTitleDeedDtlsByNumberRqType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchTitleDeedDtlsByNumberRqType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchTitleDeedDtlsByNumberRqType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
