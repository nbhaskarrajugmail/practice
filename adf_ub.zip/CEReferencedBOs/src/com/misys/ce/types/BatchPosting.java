/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class BatchPosting.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class BatchPosting implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _actionOnBatchError.
     */
    private java.lang.String _actionOnBatchError;

    /**
     * Field _batchGatewayPhases.
     */
    private java.lang.String _batchGatewayPhases;

    /**
     * Field _txnDate.
     */
    private java.sql.Date _txnDate;

    /**
     * Field _placeholder.
     */
    private java.lang.String _placeholder;


      //----------------/
     //- Constructors -/
    //----------------/

    public BatchPosting() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof BatchPosting) {

            BatchPosting temp = (BatchPosting)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._actionOnBatchError != null) {
                if (temp._actionOnBatchError == null) return false;
                if (this._actionOnBatchError != temp._actionOnBatchError) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._actionOnBatchError);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._actionOnBatchError);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._actionOnBatchError); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._actionOnBatchError); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._actionOnBatchError.equals(temp._actionOnBatchError)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._actionOnBatchError);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._actionOnBatchError);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._actionOnBatchError);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._actionOnBatchError);
                    }
                }
            } else if (temp._actionOnBatchError != null)
                return false;
            if (this._batchGatewayPhases != null) {
                if (temp._batchGatewayPhases == null) return false;
                if (this._batchGatewayPhases != temp._batchGatewayPhases) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchGatewayPhases);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchGatewayPhases);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchGatewayPhases); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchGatewayPhases); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchGatewayPhases.equals(temp._batchGatewayPhases)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchGatewayPhases);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchGatewayPhases);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchGatewayPhases);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchGatewayPhases);
                    }
                }
            } else if (temp._batchGatewayPhases != null)
                return false;
            if (this._txnDate != null) {
                if (temp._txnDate == null) return false;
                if (this._txnDate != temp._txnDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._txnDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._txnDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._txnDate.equals(temp._txnDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnDate);
                    }
                }
            } else if (temp._txnDate != null)
                return false;
            if (this._placeholder != null) {
                if (temp._placeholder == null) return false;
                if (this._placeholder != temp._placeholder) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._placeholder);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._placeholder);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._placeholder.equals(temp._placeholder)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._placeholder);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._placeholder);
                    }
                }
            } else if (temp._placeholder != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'actionOnBatchError'.
     * 
     * @return the value of field 'ActionOnBatchError'.
     */
    public java.lang.String getActionOnBatchError(
    ) {
        return this._actionOnBatchError;
    }

    /**
     * Returns the value of field 'batchGatewayPhases'.
     * 
     * @return the value of field 'BatchGatewayPhases'.
     */
    public java.lang.String getBatchGatewayPhases(
    ) {
        return this._batchGatewayPhases;
    }

    /**
     * Returns the value of field 'placeholder'.
     * 
     * @return the value of field 'Placeholder'.
     */
    public java.lang.String getPlaceholder(
    ) {
        return this._placeholder;
    }

    /**
     * Returns the value of field 'txnDate'.
     * 
     * @return the value of field 'TxnDate'.
     */
    public java.sql.Date getTxnDate(
    ) {
        return this._txnDate;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_actionOnBatchError != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_actionOnBatchError)) {
           result = 37 * result + _actionOnBatchError.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_actionOnBatchError);
        }
        if (_batchGatewayPhases != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchGatewayPhases)) {
           result = 37 * result + _batchGatewayPhases.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchGatewayPhases);
        }
        if (_txnDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_txnDate)) {
           result = 37 * result + _txnDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_txnDate);
        }
        if (_placeholder != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_placeholder)) {
           result = 37 * result + _placeholder.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_placeholder);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'actionOnBatchError'.
     * 
     * @param actionOnBatchError the value of field
     * 'actionOnBatchError'.
     */
    public void setActionOnBatchError(
            final java.lang.String actionOnBatchError) {
        this._actionOnBatchError = actionOnBatchError;
    }

    /**
     * Sets the value of field 'batchGatewayPhases'.
     * 
     * @param batchGatewayPhases the value of field
     * 'batchGatewayPhases'.
     */
    public void setBatchGatewayPhases(
            final java.lang.String batchGatewayPhases) {
        this._batchGatewayPhases = batchGatewayPhases;
    }

    /**
     * Sets the value of field 'placeholder'.
     * 
     * @param placeholder the value of field 'placeholder'.
     */
    public void setPlaceholder(
            final java.lang.String placeholder) {
        this._placeholder = placeholder;
    }

    /**
     * Sets the value of field 'txnDate'.
     * 
     * @param txnDate the value of field 'txnDate'.
     */
    public void setTxnDate(
            final java.sql.Date txnDate) {
        this._txnDate = txnDate;
    }

    /**
     * Method unmarshalBatchPosting.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled com.misys.ce.types.BatchPosting
     */
    public static com.misys.ce.types.BatchPosting unmarshalBatchPosting(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.BatchPosting) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.BatchPosting.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
