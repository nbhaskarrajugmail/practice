/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class FarmLandNeighbourdtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class FarmLandNeighbourdtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _farmLandNeighbouridpk.
     */
    private java.lang.String _farmLandNeighbouridpk;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _partyId.
     */
    private java.lang.String _partyId;

    /**
     * Field _partyName.
     */
    private java.lang.String _partyName;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public FarmLandNeighbourdtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof FarmLandNeighbourdtlsType) {

            FarmLandNeighbourdtlsType temp = (FarmLandNeighbourdtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._farmLandNeighbouridpk != null) {
                if (temp._farmLandNeighbouridpk == null) return false;
                if (this._farmLandNeighbouridpk != temp._farmLandNeighbouridpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLandNeighbouridpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLandNeighbouridpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbouridpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbouridpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLandNeighbouridpk.equals(temp._farmLandNeighbouridpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbouridpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbouridpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandNeighbouridpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandNeighbouridpk);
                    }
                }
            } else if (temp._farmLandNeighbouridpk != null)
                return false;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._partyId != null) {
                if (temp._partyId == null) return false;
                if (this._partyId != temp._partyId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partyId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partyId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partyId.equals(temp._partyId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyId);
                    }
                }
            } else if (temp._partyId != null)
                return false;
            if (this._partyName != null) {
                if (temp._partyName == null) return false;
                if (this._partyName != temp._partyName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partyName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partyName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partyName.equals(temp._partyName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName);
                    }
                }
            } else if (temp._partyName != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'farmLandNeighbouridpk'.
     * 
     * @return the value of field 'FarmLandNeighbouridpk'.
     */
    public java.lang.String getFarmLandNeighbouridpk(
    ) {
        return this._farmLandNeighbouridpk;
    }

    /**
     * Returns the value of field 'partyId'.
     * 
     * @return the value of field 'PartyId'.
     */
    public java.lang.String getPartyId(
    ) {
        return this._partyId;
    }

    /**
     * Returns the value of field 'partyName'.
     * 
     * @return the value of field 'PartyName'.
     */
    public java.lang.String getPartyName(
    ) {
        return this._partyName;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_farmLandNeighbouridpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLandNeighbouridpk)) {
           result = 37 * result + _farmLandNeighbouridpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLandNeighbouridpk);
        }
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_partyId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partyId)) {
           result = 37 * result + _partyId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partyId);
        }
        if (_partyName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partyName)) {
           result = 37 * result + _partyName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partyName);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'farmLandNeighbouridpk'.
     * 
     * @param farmLandNeighbouridpk the value of field
     * 'farmLandNeighbouridpk'.
     */
    public void setFarmLandNeighbouridpk(
            final java.lang.String farmLandNeighbouridpk) {
        this._farmLandNeighbouridpk = farmLandNeighbouridpk;
    }

    /**
     * Sets the value of field 'partyId'.
     * 
     * @param partyId the value of field 'partyId'.
     */
    public void setPartyId(
            final java.lang.String partyId) {
        this._partyId = partyId;
    }

    /**
     * Sets the value of field 'partyName'.
     * 
     * @param partyName the value of field 'partyName'.
     */
    public void setPartyName(
            final java.lang.String partyName) {
        this._partyName = partyName;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Method unmarshalFarmLandNeighbourdtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.FarmLandNeighbourdtlsType
     */
    public static com.misys.ce.types.FarmLandNeighbourdtlsType unmarshalFarmLandNeighbourdtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.FarmLandNeighbourdtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.FarmLandNeighbourdtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
