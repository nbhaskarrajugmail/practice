/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class BatchHeaderDetails.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class BatchHeaderDetails implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _batchRef.
     */
    private java.lang.String _batchRef;

    /**
     * Field _batchFileName.
     */
    private java.lang.String _batchFileName;

    /**
     * Field _batchDesc.
     */
    private java.lang.String _batchDesc;

    /**
     * Field _txnType.
     */
    private java.lang.String _txnType;

    /**
     * Field _bankID.
     */
    private java.lang.String _bankID;

    /**
     * Field _internalAcc.
     */
    private java.lang.String _internalAcc;

    /**
     * Field _amountToBeProcessed.
     */
    private java.math.BigDecimal _amountToBeProcessed;

    /**
     * Field _batchRefSearch.
     */
    private java.lang.String _batchRefSearch;

    /**
     * Field _processingStatus.
     */
    private java.lang.String _processingStatus;

    /**
     * Field _showBankId.
     */
    private java.lang.Boolean _showBankId;

    /**
     * Field _showInternalAcc.
     */
    private java.lang.Boolean _showInternalAcc;

    /**
     * Field _batchUploadDate.
     */
    private java.sql.Date _batchUploadDate;

    /**
     * Field _sector.
     */
    private java.lang.String _sector;


      //----------------/
     //- Constructors -/
    //----------------/

    public BatchHeaderDetails() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof BatchHeaderDetails) {

            BatchHeaderDetails temp = (BatchHeaderDetails)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._batchRef != null) {
                if (temp._batchRef == null) return false;
                if (this._batchRef != temp._batchRef) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchRef);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchRef);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRef); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRef); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchRef.equals(temp._batchRef)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRef);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRef);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRef);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRef);
                    }
                }
            } else if (temp._batchRef != null)
                return false;
            if (this._batchFileName != null) {
                if (temp._batchFileName == null) return false;
                if (this._batchFileName != temp._batchFileName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchFileName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchFileName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchFileName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchFileName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchFileName.equals(temp._batchFileName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchFileName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchFileName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchFileName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchFileName);
                    }
                }
            } else if (temp._batchFileName != null)
                return false;
            if (this._batchDesc != null) {
                if (temp._batchDesc == null) return false;
                if (this._batchDesc != temp._batchDesc) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchDesc);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchDesc);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchDesc); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchDesc); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchDesc.equals(temp._batchDesc)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchDesc);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchDesc);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchDesc);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchDesc);
                    }
                }
            } else if (temp._batchDesc != null)
                return false;
            if (this._txnType != null) {
                if (temp._txnType == null) return false;
                if (this._txnType != temp._txnType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._txnType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._txnType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._txnType.equals(temp._txnType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._txnType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._txnType);
                    }
                }
            } else if (temp._txnType != null)
                return false;
            if (this._bankID != null) {
                if (temp._bankID == null) return false;
                if (this._bankID != temp._bankID) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._bankID);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._bankID);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankID); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankID); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._bankID.equals(temp._bankID)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankID);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankID);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bankID);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bankID);
                    }
                }
            } else if (temp._bankID != null)
                return false;
            if (this._internalAcc != null) {
                if (temp._internalAcc == null) return false;
                if (this._internalAcc != temp._internalAcc) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._internalAcc);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._internalAcc);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAcc); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAcc); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._internalAcc.equals(temp._internalAcc)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAcc);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAcc);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._internalAcc);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._internalAcc);
                    }
                }
            } else if (temp._internalAcc != null)
                return false;
            if (this._amountToBeProcessed != null) {
                if (temp._amountToBeProcessed == null) return false;
                if (this._amountToBeProcessed != temp._amountToBeProcessed) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._amountToBeProcessed);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._amountToBeProcessed);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amountToBeProcessed); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amountToBeProcessed); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._amountToBeProcessed.equals(temp._amountToBeProcessed)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amountToBeProcessed);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amountToBeProcessed);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._amountToBeProcessed);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._amountToBeProcessed);
                    }
                }
            } else if (temp._amountToBeProcessed != null)
                return false;
            if (this._batchRefSearch != null) {
                if (temp._batchRefSearch == null) return false;
                if (this._batchRefSearch != temp._batchRefSearch) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchRefSearch);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchRefSearch);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRefSearch); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRefSearch); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchRefSearch.equals(temp._batchRefSearch)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRefSearch);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRefSearch);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchRefSearch);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchRefSearch);
                    }
                }
            } else if (temp._batchRefSearch != null)
                return false;
            if (this._processingStatus != null) {
                if (temp._processingStatus == null) return false;
                if (this._processingStatus != temp._processingStatus) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._processingStatus);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._processingStatus);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processingStatus); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processingStatus); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._processingStatus.equals(temp._processingStatus)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processingStatus);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processingStatus);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._processingStatus);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._processingStatus);
                    }
                }
            } else if (temp._processingStatus != null)
                return false;
            if (this._showBankId != null) {
                if (temp._showBankId == null) return false;
                if (this._showBankId != temp._showBankId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._showBankId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._showBankId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showBankId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showBankId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._showBankId.equals(temp._showBankId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showBankId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showBankId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showBankId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showBankId);
                    }
                }
            } else if (temp._showBankId != null)
                return false;
            if (this._showInternalAcc != null) {
                if (temp._showInternalAcc == null) return false;
                if (this._showInternalAcc != temp._showInternalAcc) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._showInternalAcc);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._showInternalAcc);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showInternalAcc); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showInternalAcc); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._showInternalAcc.equals(temp._showInternalAcc)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showInternalAcc);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showInternalAcc);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._showInternalAcc);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._showInternalAcc);
                    }
                }
            } else if (temp._showInternalAcc != null)
                return false;
            if (this._batchUploadDate != null) {
                if (temp._batchUploadDate == null) return false;
                if (this._batchUploadDate != temp._batchUploadDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._batchUploadDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._batchUploadDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchUploadDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchUploadDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._batchUploadDate.equals(temp._batchUploadDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchUploadDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchUploadDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._batchUploadDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._batchUploadDate);
                    }
                }
            } else if (temp._batchUploadDate != null)
                return false;
            if (this._sector != null) {
                if (temp._sector == null) return false;
                if (this._sector != temp._sector) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._sector);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._sector);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sector); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sector); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._sector.equals(temp._sector)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sector);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sector);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sector);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sector);
                    }
                }
            } else if (temp._sector != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'amountToBeProcessed'.
     * 
     * @return the value of field 'AmountToBeProcessed'.
     */
    public java.math.BigDecimal getAmountToBeProcessed(
    ) {
        return this._amountToBeProcessed;
    }

    /**
     * Returns the value of field 'bankID'.
     * 
     * @return the value of field 'BankID'.
     */
    public java.lang.String getBankID(
    ) {
        return this._bankID;
    }

    /**
     * Returns the value of field 'batchDesc'.
     * 
     * @return the value of field 'BatchDesc'.
     */
    public java.lang.String getBatchDesc(
    ) {
        return this._batchDesc;
    }

    /**
     * Returns the value of field 'batchFileName'.
     * 
     * @return the value of field 'BatchFileName'.
     */
    public java.lang.String getBatchFileName(
    ) {
        return this._batchFileName;
    }

    /**
     * Returns the value of field 'batchRef'.
     * 
     * @return the value of field 'BatchRef'.
     */
    public java.lang.String getBatchRef(
    ) {
        return this._batchRef;
    }

    /**
     * Returns the value of field 'batchRefSearch'.
     * 
     * @return the value of field 'BatchRefSearch'.
     */
    public java.lang.String getBatchRefSearch(
    ) {
        return this._batchRefSearch;
    }

    /**
     * Returns the value of field 'batchUploadDate'.
     * 
     * @return the value of field 'BatchUploadDate'.
     */
    public java.sql.Date getBatchUploadDate(
    ) {
        return this._batchUploadDate;
    }

    /**
     * Returns the value of field 'internalAcc'.
     * 
     * @return the value of field 'InternalAcc'.
     */
    public java.lang.String getInternalAcc(
    ) {
        return this._internalAcc;
    }

    /**
     * Returns the value of field 'processingStatus'.
     * 
     * @return the value of field 'ProcessingStatus'.
     */
    public java.lang.String getProcessingStatus(
    ) {
        return this._processingStatus;
    }

    /**
     * Returns the value of field 'sector'.
     * 
     * @return the value of field 'Sector'.
     */
    public java.lang.String getSector(
    ) {
        return this._sector;
    }

    /**
     * Returns the value of field 'showBankId'.
     * 
     * @return the value of field 'ShowBankId'.
     */
    public java.lang.Boolean getShowBankId(
    ) {
        return this._showBankId;
    }

    /**
     * Returns the value of field 'showInternalAcc'.
     * 
     * @return the value of field 'ShowInternalAcc'.
     */
    public java.lang.Boolean getShowInternalAcc(
    ) {
        return this._showInternalAcc;
    }

    /**
     * Returns the value of field 'txnType'.
     * 
     * @return the value of field 'TxnType'.
     */
    public java.lang.String getTxnType(
    ) {
        return this._txnType;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_batchRef != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchRef)) {
           result = 37 * result + _batchRef.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchRef);
        }
        if (_batchFileName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchFileName)) {
           result = 37 * result + _batchFileName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchFileName);
        }
        if (_batchDesc != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchDesc)) {
           result = 37 * result + _batchDesc.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchDesc);
        }
        if (_txnType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_txnType)) {
           result = 37 * result + _txnType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_txnType);
        }
        if (_bankID != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_bankID)) {
           result = 37 * result + _bankID.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_bankID);
        }
        if (_internalAcc != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_internalAcc)) {
           result = 37 * result + _internalAcc.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_internalAcc);
        }
        if (_amountToBeProcessed != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_amountToBeProcessed)) {
           result = 37 * result + _amountToBeProcessed.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_amountToBeProcessed);
        }
        if (_batchRefSearch != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchRefSearch)) {
           result = 37 * result + _batchRefSearch.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchRefSearch);
        }
        if (_processingStatus != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_processingStatus)) {
           result = 37 * result + _processingStatus.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_processingStatus);
        }
        if (_showBankId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_showBankId)) {
           result = 37 * result + _showBankId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_showBankId);
        }
        if (_showInternalAcc != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_showInternalAcc)) {
           result = 37 * result + _showInternalAcc.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_showInternalAcc);
        }
        if (_batchUploadDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_batchUploadDate)) {
           result = 37 * result + _batchUploadDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_batchUploadDate);
        }
        if (_sector != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_sector)) {
           result = 37 * result + _sector.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_sector);
        }

        return result;
    }

    /**
     * Returns the value of field 'showBankId'.
     * 
     * @return the value of field 'ShowBankId'.
     */
    public java.lang.Boolean isShowBankId(
    ) {
        return this._showBankId;
    }

    /**
     * Returns the value of field 'showInternalAcc'.
     * 
     * @return the value of field 'ShowInternalAcc'.
     */
    public java.lang.Boolean isShowInternalAcc(
    ) {
        return this._showInternalAcc;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'amountToBeProcessed'.
     * 
     * @param amountToBeProcessed the value of field
     * 'amountToBeProcessed'.
     */
    public void setAmountToBeProcessed(
            final java.math.BigDecimal amountToBeProcessed) {
        this._amountToBeProcessed = amountToBeProcessed;
    }

    /**
     * Sets the value of field 'bankID'.
     * 
     * @param bankID the value of field 'bankID'.
     */
    public void setBankID(
            final java.lang.String bankID) {
        this._bankID = bankID;
    }

    /**
     * Sets the value of field 'batchDesc'.
     * 
     * @param batchDesc the value of field 'batchDesc'.
     */
    public void setBatchDesc(
            final java.lang.String batchDesc) {
        this._batchDesc = batchDesc;
    }

    /**
     * Sets the value of field 'batchFileName'.
     * 
     * @param batchFileName the value of field 'batchFileName'.
     */
    public void setBatchFileName(
            final java.lang.String batchFileName) {
        this._batchFileName = batchFileName;
    }

    /**
     * Sets the value of field 'batchRef'.
     * 
     * @param batchRef the value of field 'batchRef'.
     */
    public void setBatchRef(
            final java.lang.String batchRef) {
        this._batchRef = batchRef;
    }

    /**
     * Sets the value of field 'batchRefSearch'.
     * 
     * @param batchRefSearch the value of field 'batchRefSearch'.
     */
    public void setBatchRefSearch(
            final java.lang.String batchRefSearch) {
        this._batchRefSearch = batchRefSearch;
    }

    /**
     * Sets the value of field 'batchUploadDate'.
     * 
     * @param batchUploadDate the value of field 'batchUploadDate'.
     */
    public void setBatchUploadDate(
            final java.sql.Date batchUploadDate) {
        this._batchUploadDate = batchUploadDate;
    }

    /**
     * Sets the value of field 'internalAcc'.
     * 
     * @param internalAcc the value of field 'internalAcc'.
     */
    public void setInternalAcc(
            final java.lang.String internalAcc) {
        this._internalAcc = internalAcc;
    }

    /**
     * Sets the value of field 'processingStatus'.
     * 
     * @param processingStatus the value of field 'processingStatus'
     */
    public void setProcessingStatus(
            final java.lang.String processingStatus) {
        this._processingStatus = processingStatus;
    }

    /**
     * Sets the value of field 'sector'.
     * 
     * @param sector the value of field 'sector'.
     */
    public void setSector(
            final java.lang.String sector) {
        this._sector = sector;
    }

    /**
     * Sets the value of field 'showBankId'.
     * 
     * @param showBankId the value of field 'showBankId'.
     */
    public void setShowBankId(
            final java.lang.Boolean showBankId) {
        this._showBankId = showBankId;
    }

    /**
     * Sets the value of field 'showInternalAcc'.
     * 
     * @param showInternalAcc the value of field 'showInternalAcc'.
     */
    public void setShowInternalAcc(
            final java.lang.Boolean showInternalAcc) {
        this._showInternalAcc = showInternalAcc;
    }

    /**
     * Sets the value of field 'txnType'.
     * 
     * @param txnType the value of field 'txnType'.
     */
    public void setTxnType(
            final java.lang.String txnType) {
        this._txnType = txnType;
    }

    /**
     * Method unmarshalBatchHeaderDetails.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled com.misys.ce.types.BatchHeaderDetails
     */
    public static com.misys.ce.types.BatchHeaderDetails unmarshalBatchHeaderDetails(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.BatchHeaderDetails) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.BatchHeaderDetails.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
