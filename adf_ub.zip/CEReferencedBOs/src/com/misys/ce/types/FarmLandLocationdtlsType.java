/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class FarmLandLocationdtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class FarmLandLocationdtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _farmLandLocationidpk.
     */
    private java.lang.String _farmLandLocationidpk;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _contractNumber.
     */
    private java.lang.String _contractNumber;

    /**
     * Field _direction.
     */
    private java.lang.String _direction;

    /**
     * Field _bordering.
     */
    private java.lang.String _bordering;

    /**
     * Field _length.
     */
    private java.math.BigDecimal _length;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public FarmLandLocationdtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof FarmLandLocationdtlsType) {

            FarmLandLocationdtlsType temp = (FarmLandLocationdtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._farmLandLocationidpk != null) {
                if (temp._farmLandLocationidpk == null) return false;
                if (this._farmLandLocationidpk != temp._farmLandLocationidpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLandLocationidpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLandLocationidpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationidpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationidpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLandLocationidpk.equals(temp._farmLandLocationidpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationidpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationidpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLandLocationidpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLandLocationidpk);
                    }
                }
            } else if (temp._farmLandLocationidpk != null)
                return false;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._contractNumber != null) {
                if (temp._contractNumber == null) return false;
                if (this._contractNumber != temp._contractNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._contractNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._contractNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._contractNumber.equals(temp._contractNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber);
                    }
                }
            } else if (temp._contractNumber != null)
                return false;
            if (this._direction != null) {
                if (temp._direction == null) return false;
                if (this._direction != temp._direction) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._direction);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._direction);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._direction); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._direction); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._direction.equals(temp._direction)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._direction);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._direction);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._direction);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._direction);
                    }
                }
            } else if (temp._direction != null)
                return false;
            if (this._bordering != null) {
                if (temp._bordering == null) return false;
                if (this._bordering != temp._bordering) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._bordering);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._bordering);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bordering); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bordering); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._bordering.equals(temp._bordering)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bordering);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bordering);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._bordering);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._bordering);
                    }
                }
            } else if (temp._bordering != null)
                return false;
            if (this._length != null) {
                if (temp._length == null) return false;
                if (this._length != temp._length) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._length);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._length);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._length); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._length); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._length.equals(temp._length)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._length);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._length);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._length);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._length);
                    }
                }
            } else if (temp._length != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'bordering'.
     * 
     * @return the value of field 'Bordering'.
     */
    public java.lang.String getBordering(
    ) {
        return this._bordering;
    }

    /**
     * Returns the value of field 'contractNumber'.
     * 
     * @return the value of field 'ContractNumber'.
     */
    public java.lang.String getContractNumber(
    ) {
        return this._contractNumber;
    }

    /**
     * Returns the value of field 'direction'.
     * 
     * @return the value of field 'Direction'.
     */
    public java.lang.String getDirection(
    ) {
        return this._direction;
    }

    /**
     * Returns the value of field 'farmLandLocationidpk'.
     * 
     * @return the value of field 'FarmLandLocationidpk'.
     */
    public java.lang.String getFarmLandLocationidpk(
    ) {
        return this._farmLandLocationidpk;
    }

    /**
     * Returns the value of field 'length'.
     * 
     * @return the value of field 'Length'.
     */
    public java.math.BigDecimal getLength(
    ) {
        return this._length;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_farmLandLocationidpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLandLocationidpk)) {
           result = 37 * result + _farmLandLocationidpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLandLocationidpk);
        }
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_contractNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_contractNumber)) {
           result = 37 * result + _contractNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_contractNumber);
        }
        if (_direction != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_direction)) {
           result = 37 * result + _direction.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_direction);
        }
        if (_bordering != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_bordering)) {
           result = 37 * result + _bordering.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_bordering);
        }
        if (_length != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_length)) {
           result = 37 * result + _length.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_length);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'bordering'.
     * 
     * @param bordering the value of field 'bordering'.
     */
    public void setBordering(
            final java.lang.String bordering) {
        this._bordering = bordering;
    }

    /**
     * Sets the value of field 'contractNumber'.
     * 
     * @param contractNumber the value of field 'contractNumber'.
     */
    public void setContractNumber(
            final java.lang.String contractNumber) {
        this._contractNumber = contractNumber;
    }

    /**
     * Sets the value of field 'direction'.
     * 
     * @param direction the value of field 'direction'.
     */
    public void setDirection(
            final java.lang.String direction) {
        this._direction = direction;
    }

    /**
     * Sets the value of field 'farmLandLocationidpk'.
     * 
     * @param farmLandLocationidpk the value of field
     * 'farmLandLocationidpk'.
     */
    public void setFarmLandLocationidpk(
            final java.lang.String farmLandLocationidpk) {
        this._farmLandLocationidpk = farmLandLocationidpk;
    }

    /**
     * Sets the value of field 'length'.
     * 
     * @param length the value of field 'length'.
     */
    public void setLength(
            final java.math.BigDecimal length) {
        this._length = length;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Method unmarshalFarmLandLocationdtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.FarmLandLocationdtlsType
     */
    public static com.misys.ce.types.FarmLandLocationdtlsType unmarshalFarmLandLocationdtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.FarmLandLocationdtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.FarmLandLocationdtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
