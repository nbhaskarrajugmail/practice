/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ParentTitleDeeddtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ParentTitleDeeddtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _parentTitleDeedIdpk.
     */
    private java.lang.String _parentTitleDeedIdpk;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _titleDeedNumber.
     */
    private java.lang.String _titleDeedNumber;

    /**
     * Field _titleDeedSource.
     */
    private java.lang.String _titleDeedSource;

    /**
     * Field _titleDeedYear.
     */
    private java.lang.Integer _titleDeedYear;

    /**
     * Field _titleDeedType.
     */
    private java.lang.String _titleDeedType;

    /**
     * Field _titleDeedPlotNo.
     */
    private java.lang.String _titleDeedPlotNo;

    /**
     * Field _titleDeedPlanNo.
     */
    private java.lang.String _titleDeedPlanNo;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public ParentTitleDeeddtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ParentTitleDeeddtlsType) {

            ParentTitleDeeddtlsType temp = (ParentTitleDeeddtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._parentTitleDeedIdpk != null) {
                if (temp._parentTitleDeedIdpk == null) return false;
                if (this._parentTitleDeedIdpk != temp._parentTitleDeedIdpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._parentTitleDeedIdpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._parentTitleDeedIdpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedIdpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedIdpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._parentTitleDeedIdpk.equals(temp._parentTitleDeedIdpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedIdpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedIdpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._parentTitleDeedIdpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._parentTitleDeedIdpk);
                    }
                }
            } else if (temp._parentTitleDeedIdpk != null)
                return false;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._titleDeedNumber != null) {
                if (temp._titleDeedNumber == null) return false;
                if (this._titleDeedNumber != temp._titleDeedNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedNumber.equals(temp._titleDeedNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                    }
                }
            } else if (temp._titleDeedNumber != null)
                return false;
            if (this._titleDeedSource != null) {
                if (temp._titleDeedSource == null) return false;
                if (this._titleDeedSource != temp._titleDeedSource) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedSource);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedSource);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedSource.equals(temp._titleDeedSource)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource);
                    }
                }
            } else if (temp._titleDeedSource != null)
                return false;
            if (this._titleDeedYear != null) {
                if (temp._titleDeedYear == null) return false;
                if (this._titleDeedYear != temp._titleDeedYear) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedYear);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedYear);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedYear.equals(temp._titleDeedYear)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear);
                    }
                }
            } else if (temp._titleDeedYear != null)
                return false;
            if (this._titleDeedType != null) {
                if (temp._titleDeedType == null) return false;
                if (this._titleDeedType != temp._titleDeedType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedType.equals(temp._titleDeedType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType);
                    }
                }
            } else if (temp._titleDeedType != null)
                return false;
            if (this._titleDeedPlotNo != null) {
                if (temp._titleDeedPlotNo == null) return false;
                if (this._titleDeedPlotNo != temp._titleDeedPlotNo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedPlotNo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedPlotNo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlotNo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlotNo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedPlotNo.equals(temp._titleDeedPlotNo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlotNo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlotNo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlotNo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlotNo);
                    }
                }
            } else if (temp._titleDeedPlotNo != null)
                return false;
            if (this._titleDeedPlanNo != null) {
                if (temp._titleDeedPlanNo == null) return false;
                if (this._titleDeedPlanNo != temp._titleDeedPlanNo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedPlanNo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedPlanNo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlanNo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlanNo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedPlanNo.equals(temp._titleDeedPlanNo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlanNo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlanNo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedPlanNo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedPlanNo);
                    }
                }
            } else if (temp._titleDeedPlanNo != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'parentTitleDeedIdpk'.
     * 
     * @return the value of field 'ParentTitleDeedIdpk'.
     */
    public java.lang.String getParentTitleDeedIdpk(
    ) {
        return this._parentTitleDeedIdpk;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Returns the value of field 'titleDeedNumber'.
     * 
     * @return the value of field 'TitleDeedNumber'.
     */
    public java.lang.String getTitleDeedNumber(
    ) {
        return this._titleDeedNumber;
    }

    /**
     * Returns the value of field 'titleDeedPlanNo'.
     * 
     * @return the value of field 'TitleDeedPlanNo'.
     */
    public java.lang.String getTitleDeedPlanNo(
    ) {
        return this._titleDeedPlanNo;
    }

    /**
     * Returns the value of field 'titleDeedPlotNo'.
     * 
     * @return the value of field 'TitleDeedPlotNo'.
     */
    public java.lang.String getTitleDeedPlotNo(
    ) {
        return this._titleDeedPlotNo;
    }

    /**
     * Returns the value of field 'titleDeedSource'.
     * 
     * @return the value of field 'TitleDeedSource'.
     */
    public java.lang.String getTitleDeedSource(
    ) {
        return this._titleDeedSource;
    }

    /**
     * Returns the value of field 'titleDeedType'.
     * 
     * @return the value of field 'TitleDeedType'.
     */
    public java.lang.String getTitleDeedType(
    ) {
        return this._titleDeedType;
    }

    /**
     * Returns the value of field 'titleDeedYear'.
     * 
     * @return the value of field 'TitleDeedYear'.
     */
    public java.lang.Integer getTitleDeedYear(
    ) {
        return this._titleDeedYear;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_parentTitleDeedIdpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_parentTitleDeedIdpk)) {
           result = 37 * result + _parentTitleDeedIdpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_parentTitleDeedIdpk);
        }
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_titleDeedNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedNumber)) {
           result = 37 * result + _titleDeedNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedNumber);
        }
        if (_titleDeedSource != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedSource)) {
           result = 37 * result + _titleDeedSource.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedSource);
        }
        if (_titleDeedYear != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedYear)) {
           result = 37 * result + _titleDeedYear.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedYear);
        }
        if (_titleDeedType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedType)) {
           result = 37 * result + _titleDeedType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedType);
        }
        if (_titleDeedPlotNo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedPlotNo)) {
           result = 37 * result + _titleDeedPlotNo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedPlotNo);
        }
        if (_titleDeedPlanNo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedPlanNo)) {
           result = 37 * result + _titleDeedPlanNo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedPlanNo);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'parentTitleDeedIdpk'.
     * 
     * @param parentTitleDeedIdpk the value of field
     * 'parentTitleDeedIdpk'.
     */
    public void setParentTitleDeedIdpk(
            final java.lang.String parentTitleDeedIdpk) {
        this._parentTitleDeedIdpk = parentTitleDeedIdpk;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Sets the value of field 'titleDeedNumber'.
     * 
     * @param titleDeedNumber the value of field 'titleDeedNumber'.
     */
    public void setTitleDeedNumber(
            final java.lang.String titleDeedNumber) {
        this._titleDeedNumber = titleDeedNumber;
    }

    /**
     * Sets the value of field 'titleDeedPlanNo'.
     * 
     * @param titleDeedPlanNo the value of field 'titleDeedPlanNo'.
     */
    public void setTitleDeedPlanNo(
            final java.lang.String titleDeedPlanNo) {
        this._titleDeedPlanNo = titleDeedPlanNo;
    }

    /**
     * Sets the value of field 'titleDeedPlotNo'.
     * 
     * @param titleDeedPlotNo the value of field 'titleDeedPlotNo'.
     */
    public void setTitleDeedPlotNo(
            final java.lang.String titleDeedPlotNo) {
        this._titleDeedPlotNo = titleDeedPlotNo;
    }

    /**
     * Sets the value of field 'titleDeedSource'.
     * 
     * @param titleDeedSource the value of field 'titleDeedSource'.
     */
    public void setTitleDeedSource(
            final java.lang.String titleDeedSource) {
        this._titleDeedSource = titleDeedSource;
    }

    /**
     * Sets the value of field 'titleDeedType'.
     * 
     * @param titleDeedType the value of field 'titleDeedType'.
     */
    public void setTitleDeedType(
            final java.lang.String titleDeedType) {
        this._titleDeedType = titleDeedType;
    }

    /**
     * Sets the value of field 'titleDeedYear'.
     * 
     * @param titleDeedYear the value of field 'titleDeedYear'.
     */
    public void setTitleDeedYear(
            final java.lang.Integer titleDeedYear) {
        this._titleDeedYear = titleDeedYear;
    }

    /**
     * Method unmarshalParentTitleDeeddtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ParentTitleDeeddtlsType
     */
    public static com.misys.ce.types.ParentTitleDeeddtlsType unmarshalParentTitleDeeddtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ParentTitleDeeddtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ParentTitleDeeddtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
