/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ListTitleDeedLocDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ListTitleDeedLocDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedLocDtlsList.
     */
    private java.util.Vector<com.misys.ce.types.TitleDeedLocationdtlsType> _titleDeedLocDtlsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ListTitleDeedLocDtlsType() {
        super();
        this._titleDeedLocDtlsList = new java.util.Vector<com.misys.ce.types.TitleDeedLocationdtlsType>();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * 
     * 
     * @param vTitleDeedLocDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitleDeedLocDtls(
            final com.misys.ce.types.TitleDeedLocationdtlsType vTitleDeedLocDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._titleDeedLocDtlsList.addElement(vTitleDeedLocDtls);
    }

    /**
     * 
     * 
     * @param index
     * @param vTitleDeedLocDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void addTitleDeedLocDtls(
            final int index,
            final com.misys.ce.types.TitleDeedLocationdtlsType vTitleDeedLocDtls)
    throws java.lang.IndexOutOfBoundsException {
        this._titleDeedLocDtlsList.add(index, vTitleDeedLocDtls);
    }

    /**
     * Method enumerateTitleDeedLocDtls.
     * 
     * @return an Enumeration over all
     * com.misys.ce.types.TitleDeedLocationdtlsType elements
     */
    public java.util.Enumeration<? extends com.misys.ce.types.TitleDeedLocationdtlsType> enumerateTitleDeedLocDtls(
    ) {
        return this._titleDeedLocDtlsList.elements();
    }

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ListTitleDeedLocDtlsType) {

            ListTitleDeedLocDtlsType temp = (ListTitleDeedLocDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedLocDtlsList != null) {
                if (temp._titleDeedLocDtlsList == null) return false;
                if (this._titleDeedLocDtlsList != temp._titleDeedLocDtlsList) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedLocDtlsList);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedLocDtlsList);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocDtlsList); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocDtlsList); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedLocDtlsList.equals(temp._titleDeedLocDtlsList)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocDtlsList);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocDtlsList);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedLocDtlsList);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedLocDtlsList);
                    }
                }
            } else if (temp._titleDeedLocDtlsList != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Method getTitleDeedLocDtls.
     * 
     * @param index
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     * @return the value of the
     * com.misys.ce.types.TitleDeedLocationdtlsType at the given
     * index
     */
    public com.misys.ce.types.TitleDeedLocationdtlsType getTitleDeedLocDtls(
            final int index)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleDeedLocDtlsList.size()) {
            throw new IndexOutOfBoundsException("getTitleDeedLocDtls: Index value '" + index + "' not in range [0.." + (this._titleDeedLocDtlsList.size() - 1) + "]");
        }

        return (com.misys.ce.types.TitleDeedLocationdtlsType) _titleDeedLocDtlsList.get(index);
    }

    /**
     * Method getTitleDeedLocDtls.Returns the contents of the
     * collection in an Array.  <p>Note:  Just in case the
     * collection contents are changing in another thread, we pass
     * a 0-length Array of the correct type into the API call. 
     * This way we <i>know</i> that the Array returned is of
     * exactly the correct length.
     * 
     * @return this collection as an Array
     */
    public com.misys.ce.types.TitleDeedLocationdtlsType[] getTitleDeedLocDtls(
    ) {
        com.misys.ce.types.TitleDeedLocationdtlsType[] array = new com.misys.ce.types.TitleDeedLocationdtlsType[0];
        return (com.misys.ce.types.TitleDeedLocationdtlsType[]) this._titleDeedLocDtlsList.toArray(array);
    }

    /**
     * Method getTitleDeedLocDtlsCount.
     * 
     * @return the size of this collection
     */
    public int getTitleDeedLocDtlsCount(
    ) {
        return this._titleDeedLocDtlsList.size();
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedLocDtlsList != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedLocDtlsList)) {
           result = 37 * result + _titleDeedLocDtlsList.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedLocDtlsList);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     */
    public void removeAllTitleDeedLocDtls(
    ) {
        this._titleDeedLocDtlsList.clear();
    }

    /**
     * Method removeTitleDeedLocDtls.
     * 
     * @param vTitleDeedLocDtls
     * @return true if the object was removed from the collection.
     */
    public boolean removeTitleDeedLocDtls(
            final com.misys.ce.types.TitleDeedLocationdtlsType vTitleDeedLocDtls) {
        boolean removed = _titleDeedLocDtlsList.remove(vTitleDeedLocDtls);
        return removed;
    }

    /**
     * Method removeTitleDeedLocDtlsAt.
     * 
     * @param index
     * @return the element removed from the collection
     */
    public com.misys.ce.types.TitleDeedLocationdtlsType removeTitleDeedLocDtlsAt(
            final int index) {
        java.lang.Object obj = this._titleDeedLocDtlsList.remove(index);
        return (com.misys.ce.types.TitleDeedLocationdtlsType) obj;
    }

    /**
     * 
     * 
     * @param index
     * @param vTitleDeedLocDtls
     * @throws java.lang.IndexOutOfBoundsException if the index
     * given is outside the bounds of the collection
     */
    public void setTitleDeedLocDtls(
            final int index,
            final com.misys.ce.types.TitleDeedLocationdtlsType vTitleDeedLocDtls)
    throws java.lang.IndexOutOfBoundsException {
        // check bounds for index
        if (index < 0 || index >= this._titleDeedLocDtlsList.size()) {
            throw new IndexOutOfBoundsException("setTitleDeedLocDtls: Index value '" + index + "' not in range [0.." + (this._titleDeedLocDtlsList.size() - 1) + "]");
        }

        this._titleDeedLocDtlsList.set(index, vTitleDeedLocDtls);
    }

    /**
     * 
     * 
     * @param vTitleDeedLocDtlsArray
     */
    public void setTitleDeedLocDtls(
            final com.misys.ce.types.TitleDeedLocationdtlsType[] vTitleDeedLocDtlsArray) {
        //-- copy array
        _titleDeedLocDtlsList.clear();

        for (int i = 0; i < vTitleDeedLocDtlsArray.length; i++) {
                this._titleDeedLocDtlsList.add(vTitleDeedLocDtlsArray[i]);
        }
    }

    /**
     * Method unmarshalListTitleDeedLocDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.ListTitleDeedLocDtlsType
     */
    public static com.misys.ce.types.ListTitleDeedLocDtlsType unmarshalListTitleDeedLocDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ListTitleDeedLocDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ListTitleDeedLocDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
