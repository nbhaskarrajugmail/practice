/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class FarmLandTitleDeeddtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class FarmLandTitleDeeddtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedIdpk.
     */
    private java.lang.String _titleDeedIdpk;

    /**
     * Field _contractNumber.
     */
    private java.lang.String _contractNumber;

    /**
     * Field _contractDate.
     */
    private java.sql.Date _contractDate;

    /**
     * Field _contractSource.
     */
    private java.lang.String _contractSource;

    /**
     * Field _ownerName.
     */
    private java.lang.String _ownerName;

    /**
     * Field _farmName.
     */
    private java.lang.String _farmName;

    /**
     * Field _engineerOfficeName.
     */
    private java.lang.String _engineerOfficeName;

    /**
     * Field _engineerOfficeDate.
     */
    private java.sql.Date _engineerOfficeDate;

    /**
     * Field _irrigationSource.
     */
    private java.lang.String _irrigationSource;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public FarmLandTitleDeeddtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof FarmLandTitleDeeddtlsType) {

            FarmLandTitleDeeddtlsType temp = (FarmLandTitleDeeddtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedIdpk != null) {
                if (temp._titleDeedIdpk == null) return false;
                if (this._titleDeedIdpk != temp._titleDeedIdpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedIdpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedIdpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedIdpk.equals(temp._titleDeedIdpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk);
                    }
                }
            } else if (temp._titleDeedIdpk != null)
                return false;
            if (this._contractNumber != null) {
                if (temp._contractNumber == null) return false;
                if (this._contractNumber != temp._contractNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._contractNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._contractNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._contractNumber.equals(temp._contractNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractNumber);
                    }
                }
            } else if (temp._contractNumber != null)
                return false;
            if (this._contractDate != null) {
                if (temp._contractDate == null) return false;
                if (this._contractDate != temp._contractDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._contractDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._contractDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._contractDate.equals(temp._contractDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractDate);
                    }
                }
            } else if (temp._contractDate != null)
                return false;
            if (this._contractSource != null) {
                if (temp._contractSource == null) return false;
                if (this._contractSource != temp._contractSource) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._contractSource);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._contractSource);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractSource); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractSource); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._contractSource.equals(temp._contractSource)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractSource);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractSource);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._contractSource);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._contractSource);
                    }
                }
            } else if (temp._contractSource != null)
                return false;
            if (this._ownerName != null) {
                if (temp._ownerName == null) return false;
                if (this._ownerName != temp._ownerName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ownerName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ownerName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownerName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownerName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ownerName.equals(temp._ownerName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownerName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownerName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownerName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownerName);
                    }
                }
            } else if (temp._ownerName != null)
                return false;
            if (this._farmName != null) {
                if (temp._farmName == null) return false;
                if (this._farmName != temp._farmName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmName.equals(temp._farmName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmName);
                    }
                }
            } else if (temp._farmName != null)
                return false;
            if (this._engineerOfficeName != null) {
                if (temp._engineerOfficeName == null) return false;
                if (this._engineerOfficeName != temp._engineerOfficeName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._engineerOfficeName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._engineerOfficeName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._engineerOfficeName.equals(temp._engineerOfficeName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeName);
                    }
                }
            } else if (temp._engineerOfficeName != null)
                return false;
            if (this._engineerOfficeDate != null) {
                if (temp._engineerOfficeDate == null) return false;
                if (this._engineerOfficeDate != temp._engineerOfficeDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._engineerOfficeDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._engineerOfficeDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._engineerOfficeDate.equals(temp._engineerOfficeDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._engineerOfficeDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._engineerOfficeDate);
                    }
                }
            } else if (temp._engineerOfficeDate != null)
                return false;
            if (this._irrigationSource != null) {
                if (temp._irrigationSource == null) return false;
                if (this._irrigationSource != temp._irrigationSource) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._irrigationSource);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._irrigationSource);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._irrigationSource); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._irrigationSource); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._irrigationSource.equals(temp._irrigationSource)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._irrigationSource);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._irrigationSource);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._irrigationSource);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._irrigationSource);
                    }
                }
            } else if (temp._irrigationSource != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'contractDate'.
     * 
     * @return the value of field 'ContractDate'.
     */
    public java.sql.Date getContractDate(
    ) {
        return this._contractDate;
    }

    /**
     * Returns the value of field 'contractNumber'.
     * 
     * @return the value of field 'ContractNumber'.
     */
    public java.lang.String getContractNumber(
    ) {
        return this._contractNumber;
    }

    /**
     * Returns the value of field 'contractSource'.
     * 
     * @return the value of field 'ContractSource'.
     */
    public java.lang.String getContractSource(
    ) {
        return this._contractSource;
    }

    /**
     * Returns the value of field 'engineerOfficeDate'.
     * 
     * @return the value of field 'EngineerOfficeDate'.
     */
    public java.sql.Date getEngineerOfficeDate(
    ) {
        return this._engineerOfficeDate;
    }

    /**
     * Returns the value of field 'engineerOfficeName'.
     * 
     * @return the value of field 'EngineerOfficeName'.
     */
    public java.lang.String getEngineerOfficeName(
    ) {
        return this._engineerOfficeName;
    }

    /**
     * Returns the value of field 'farmName'.
     * 
     * @return the value of field 'FarmName'.
     */
    public java.lang.String getFarmName(
    ) {
        return this._farmName;
    }

    /**
     * Returns the value of field 'irrigationSource'.
     * 
     * @return the value of field 'IrrigationSource'.
     */
    public java.lang.String getIrrigationSource(
    ) {
        return this._irrigationSource;
    }

    /**
     * Returns the value of field 'ownerName'.
     * 
     * @return the value of field 'OwnerName'.
     */
    public java.lang.String getOwnerName(
    ) {
        return this._ownerName;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'titleDeedIdpk'.
     * 
     * @return the value of field 'TitleDeedIdpk'.
     */
    public java.lang.String getTitleDeedIdpk(
    ) {
        return this._titleDeedIdpk;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedIdpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedIdpk)) {
           result = 37 * result + _titleDeedIdpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedIdpk);
        }
        if (_contractNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_contractNumber)) {
           result = 37 * result + _contractNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_contractNumber);
        }
        if (_contractDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_contractDate)) {
           result = 37 * result + _contractDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_contractDate);
        }
        if (_contractSource != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_contractSource)) {
           result = 37 * result + _contractSource.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_contractSource);
        }
        if (_ownerName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ownerName)) {
           result = 37 * result + _ownerName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ownerName);
        }
        if (_farmName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmName)) {
           result = 37 * result + _farmName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmName);
        }
        if (_engineerOfficeName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_engineerOfficeName)) {
           result = 37 * result + _engineerOfficeName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_engineerOfficeName);
        }
        if (_engineerOfficeDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_engineerOfficeDate)) {
           result = 37 * result + _engineerOfficeDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_engineerOfficeDate);
        }
        if (_irrigationSource != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_irrigationSource)) {
           result = 37 * result + _irrigationSource.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_irrigationSource);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'contractDate'.
     * 
     * @param contractDate the value of field 'contractDate'.
     */
    public void setContractDate(
            final java.sql.Date contractDate) {
        this._contractDate = contractDate;
    }

    /**
     * Sets the value of field 'contractNumber'.
     * 
     * @param contractNumber the value of field 'contractNumber'.
     */
    public void setContractNumber(
            final java.lang.String contractNumber) {
        this._contractNumber = contractNumber;
    }

    /**
     * Sets the value of field 'contractSource'.
     * 
     * @param contractSource the value of field 'contractSource'.
     */
    public void setContractSource(
            final java.lang.String contractSource) {
        this._contractSource = contractSource;
    }

    /**
     * Sets the value of field 'engineerOfficeDate'.
     * 
     * @param engineerOfficeDate the value of field
     * 'engineerOfficeDate'.
     */
    public void setEngineerOfficeDate(
            final java.sql.Date engineerOfficeDate) {
        this._engineerOfficeDate = engineerOfficeDate;
    }

    /**
     * Sets the value of field 'engineerOfficeName'.
     * 
     * @param engineerOfficeName the value of field
     * 'engineerOfficeName'.
     */
    public void setEngineerOfficeName(
            final java.lang.String engineerOfficeName) {
        this._engineerOfficeName = engineerOfficeName;
    }

    /**
     * Sets the value of field 'farmName'.
     * 
     * @param farmName the value of field 'farmName'.
     */
    public void setFarmName(
            final java.lang.String farmName) {
        this._farmName = farmName;
    }

    /**
     * Sets the value of field 'irrigationSource'.
     * 
     * @param irrigationSource the value of field 'irrigationSource'
     */
    public void setIrrigationSource(
            final java.lang.String irrigationSource) {
        this._irrigationSource = irrigationSource;
    }

    /**
     * Sets the value of field 'ownerName'.
     * 
     * @param ownerName the value of field 'ownerName'.
     */
    public void setOwnerName(
            final java.lang.String ownerName) {
        this._ownerName = ownerName;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'titleDeedIdpk'.
     * 
     * @param titleDeedIdpk the value of field 'titleDeedIdpk'.
     */
    public void setTitleDeedIdpk(
            final java.lang.String titleDeedIdpk) {
        this._titleDeedIdpk = titleDeedIdpk;
    }

    /**
     * Method unmarshalFarmLandTitleDeeddtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.FarmLandTitleDeeddtlsType
     */
    public static com.misys.ce.types.FarmLandTitleDeeddtlsType unmarshalFarmLandTitleDeeddtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.FarmLandTitleDeeddtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.FarmLandTitleDeeddtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
