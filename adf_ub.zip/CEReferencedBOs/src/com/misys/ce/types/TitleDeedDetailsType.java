/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class TitleDeedDetailsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class TitleDeedDetailsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _titleDeedIdpk.
     */
    private java.lang.String _titleDeedIdpk;

    /**
     * Field _titleDeedNumber.
     */
    private java.lang.String _titleDeedNumber;

    /**
     * Field _titleDeedYear.
     */
    private java.lang.Integer _titleDeedYear;

    /**
     * Field _titleDeedStatus.
     */
    private java.lang.String _titleDeedStatus;

    /**
     * Field _titleDeedType.
     */
    private java.lang.String _titleDeedType;

    /**
     * Field _farmLocation.
     */
    private java.lang.String _farmLocation;

    /**
     * Field _farmLocationDescription.
     */
    private java.lang.String _farmLocationDescription;

    /**
     * Field _dicissionStatus.
     */
    private java.lang.String _dicissionStatus;

    /**
     * Field _areaSize.
     */
    private java.math.BigDecimal _areaSize;

    /**
     * Field _retailIndex.
     */
    private java.lang.String _retailIndex;

    /**
     * Field _validFrom.
     */
    private java.sql.Date _validFrom;

    /**
     * Field _validTo.
     */
    private java.sql.Date _validTo;

    /**
     * Field _validFromHijri.
     */
    private java.lang.String _validFromHijri;

    /**
     * Field _validToHijri.
     */
    private java.lang.String _validToHijri;

    /**
     * Field _landPlotNumber.
     */
    private java.lang.String _landPlotNumber;

    /**
     * Field _landPlanNumber.
     */
    private java.lang.String _landPlanNumber;

    /**
     * Field _titleDeedSource.
     */
    private java.lang.String _titleDeedSource;

    /**
     * Field _linkedToCollateral.
     */
    private java.lang.String _linkedToCollateral;

    /**
     * Field _splitIndicator.
     */
    private java.lang.String _splitIndicator;

    /**
     * Field _reasonForChange.
     */
    private java.lang.String _reasonForChange;

    /**
     * Field _notes.
     */
    private java.lang.String _notes;

    /**
     * Field _versionNumber.
     */
    private java.lang.Integer _versionNumber;

    /**
     * Field _status.
     */
    private java.lang.String _status;

    /**
     * Field _transactionType.
     */
    private java.lang.String _transactionType;

    /**
     * Field _transactionDate.
     */
    private java.sql.Date _transactionDate;

    /**
     * Field _transactionNotes.
     */
    private java.lang.String _transactionNotes;

    /**
     * Field _branchShortCode.
     */
    private java.lang.String _branchShortCode;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public TitleDeedDetailsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof TitleDeedDetailsType) {

            TitleDeedDetailsType temp = (TitleDeedDetailsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._titleDeedIdpk != null) {
                if (temp._titleDeedIdpk == null) return false;
                if (this._titleDeedIdpk != temp._titleDeedIdpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedIdpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedIdpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedIdpk.equals(temp._titleDeedIdpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedIdpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedIdpk);
                    }
                }
            } else if (temp._titleDeedIdpk != null)
                return false;
            if (this._titleDeedNumber != null) {
                if (temp._titleDeedNumber == null) return false;
                if (this._titleDeedNumber != temp._titleDeedNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedNumber.equals(temp._titleDeedNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedNumber);
                    }
                }
            } else if (temp._titleDeedNumber != null)
                return false;
            if (this._titleDeedYear != null) {
                if (temp._titleDeedYear == null) return false;
                if (this._titleDeedYear != temp._titleDeedYear) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedYear);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedYear);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedYear.equals(temp._titleDeedYear)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedYear);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedYear);
                    }
                }
            } else if (temp._titleDeedYear != null)
                return false;
            if (this._titleDeedStatus != null) {
                if (temp._titleDeedStatus == null) return false;
                if (this._titleDeedStatus != temp._titleDeedStatus) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedStatus);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedStatus);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedStatus); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedStatus); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedStatus.equals(temp._titleDeedStatus)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedStatus);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedStatus);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedStatus);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedStatus);
                    }
                }
            } else if (temp._titleDeedStatus != null)
                return false;
            if (this._titleDeedType != null) {
                if (temp._titleDeedType == null) return false;
                if (this._titleDeedType != temp._titleDeedType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedType.equals(temp._titleDeedType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedType);
                    }
                }
            } else if (temp._titleDeedType != null)
                return false;
            if (this._farmLocation != null) {
                if (temp._farmLocation == null) return false;
                if (this._farmLocation != temp._farmLocation) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLocation);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLocation);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocation); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocation); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLocation.equals(temp._farmLocation)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocation);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocation);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocation);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocation);
                    }
                }
            } else if (temp._farmLocation != null)
                return false;
            if (this._farmLocationDescription != null) {
                if (temp._farmLocationDescription == null) return false;
                if (this._farmLocationDescription != temp._farmLocationDescription) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._farmLocationDescription);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._farmLocationDescription);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocationDescription); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocationDescription); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._farmLocationDescription.equals(temp._farmLocationDescription)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocationDescription);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocationDescription);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._farmLocationDescription);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._farmLocationDescription);
                    }
                }
            } else if (temp._farmLocationDescription != null)
                return false;
            if (this._dicissionStatus != null) {
                if (temp._dicissionStatus == null) return false;
                if (this._dicissionStatus != temp._dicissionStatus) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._dicissionStatus);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._dicissionStatus);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dicissionStatus); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dicissionStatus); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._dicissionStatus.equals(temp._dicissionStatus)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dicissionStatus);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dicissionStatus);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._dicissionStatus);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._dicissionStatus);
                    }
                }
            } else if (temp._dicissionStatus != null)
                return false;
            if (this._areaSize != null) {
                if (temp._areaSize == null) return false;
                if (this._areaSize != temp._areaSize) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._areaSize);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._areaSize);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._areaSize); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._areaSize); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._areaSize.equals(temp._areaSize)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._areaSize);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._areaSize);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._areaSize);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._areaSize);
                    }
                }
            } else if (temp._areaSize != null)
                return false;
            if (this._retailIndex != null) {
                if (temp._retailIndex == null) return false;
                if (this._retailIndex != temp._retailIndex) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._retailIndex);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._retailIndex);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._retailIndex); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._retailIndex); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._retailIndex.equals(temp._retailIndex)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._retailIndex);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._retailIndex);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._retailIndex);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._retailIndex);
                    }
                }
            } else if (temp._retailIndex != null)
                return false;
            if (this._validFrom != null) {
                if (temp._validFrom == null) return false;
                if (this._validFrom != temp._validFrom) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._validFrom);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._validFrom);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFrom); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFrom); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._validFrom.equals(temp._validFrom)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFrom);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFrom);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFrom);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFrom);
                    }
                }
            } else if (temp._validFrom != null)
                return false;
            if (this._validTo != null) {
                if (temp._validTo == null) return false;
                if (this._validTo != temp._validTo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._validTo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._validTo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validTo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validTo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._validTo.equals(temp._validTo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validTo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validTo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validTo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validTo);
                    }
                }
            } else if (temp._validTo != null)
                return false;
            if (this._validFromHijri != null) {
                if (temp._validFromHijri == null) return false;
                if (this._validFromHijri != temp._validFromHijri) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._validFromHijri);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._validFromHijri);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFromHijri); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFromHijri); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._validFromHijri.equals(temp._validFromHijri)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFromHijri);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFromHijri);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validFromHijri);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validFromHijri);
                    }
                }
            } else if (temp._validFromHijri != null)
                return false;
            if (this._validToHijri != null) {
                if (temp._validToHijri == null) return false;
                if (this._validToHijri != temp._validToHijri) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._validToHijri);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._validToHijri);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validToHijri); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validToHijri); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._validToHijri.equals(temp._validToHijri)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validToHijri);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validToHijri);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._validToHijri);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._validToHijri);
                    }
                }
            } else if (temp._validToHijri != null)
                return false;
            if (this._landPlotNumber != null) {
                if (temp._landPlotNumber == null) return false;
                if (this._landPlotNumber != temp._landPlotNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._landPlotNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._landPlotNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlotNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlotNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._landPlotNumber.equals(temp._landPlotNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlotNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlotNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlotNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlotNumber);
                    }
                }
            } else if (temp._landPlotNumber != null)
                return false;
            if (this._landPlanNumber != null) {
                if (temp._landPlanNumber == null) return false;
                if (this._landPlanNumber != temp._landPlanNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._landPlanNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._landPlanNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlanNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlanNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._landPlanNumber.equals(temp._landPlanNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlanNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlanNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._landPlanNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._landPlanNumber);
                    }
                }
            } else if (temp._landPlanNumber != null)
                return false;
            if (this._titleDeedSource != null) {
                if (temp._titleDeedSource == null) return false;
                if (this._titleDeedSource != temp._titleDeedSource) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedSource);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedSource);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedSource.equals(temp._titleDeedSource)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedSource);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedSource);
                    }
                }
            } else if (temp._titleDeedSource != null)
                return false;
            if (this._linkedToCollateral != null) {
                if (temp._linkedToCollateral == null) return false;
                if (this._linkedToCollateral != temp._linkedToCollateral) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._linkedToCollateral);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._linkedToCollateral);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._linkedToCollateral); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._linkedToCollateral); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._linkedToCollateral.equals(temp._linkedToCollateral)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._linkedToCollateral);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._linkedToCollateral);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._linkedToCollateral);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._linkedToCollateral);
                    }
                }
            } else if (temp._linkedToCollateral != null)
                return false;
            if (this._splitIndicator != null) {
                if (temp._splitIndicator == null) return false;
                if (this._splitIndicator != temp._splitIndicator) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._splitIndicator);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._splitIndicator);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._splitIndicator); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._splitIndicator); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._splitIndicator.equals(temp._splitIndicator)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._splitIndicator);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._splitIndicator);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._splitIndicator);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._splitIndicator);
                    }
                }
            } else if (temp._splitIndicator != null)
                return false;
            if (this._reasonForChange != null) {
                if (temp._reasonForChange == null) return false;
                if (this._reasonForChange != temp._reasonForChange) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._reasonForChange);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._reasonForChange);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._reasonForChange); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._reasonForChange); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._reasonForChange.equals(temp._reasonForChange)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._reasonForChange);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._reasonForChange);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._reasonForChange);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._reasonForChange);
                    }
                }
            } else if (temp._reasonForChange != null)
                return false;
            if (this._notes != null) {
                if (temp._notes == null) return false;
                if (this._notes != temp._notes) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._notes);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._notes);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._notes.equals(temp._notes)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes);
                    }
                }
            } else if (temp._notes != null)
                return false;
            if (this._versionNumber != null) {
                if (temp._versionNumber == null) return false;
                if (this._versionNumber != temp._versionNumber) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._versionNumber);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._versionNumber);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._versionNumber); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._versionNumber); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._versionNumber.equals(temp._versionNumber)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._versionNumber);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._versionNumber);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._versionNumber);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._versionNumber);
                    }
                }
            } else if (temp._versionNumber != null)
                return false;
            if (this._status != null) {
                if (temp._status == null) return false;
                if (this._status != temp._status) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._status);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._status);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._status.equals(temp._status)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._status);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._status);
                    }
                }
            } else if (temp._status != null)
                return false;
            if (this._transactionType != null) {
                if (temp._transactionType == null) return false;
                if (this._transactionType != temp._transactionType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionType.equals(temp._transactionType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionType);
                    }
                }
            } else if (temp._transactionType != null)
                return false;
            if (this._transactionDate != null) {
                if (temp._transactionDate == null) return false;
                if (this._transactionDate != temp._transactionDate) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionDate);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionDate);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDate); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDate); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionDate.equals(temp._transactionDate)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDate);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDate);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionDate);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionDate);
                    }
                }
            } else if (temp._transactionDate != null)
                return false;
            if (this._transactionNotes != null) {
                if (temp._transactionNotes == null) return false;
                if (this._transactionNotes != temp._transactionNotes) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._transactionNotes);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._transactionNotes);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionNotes); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionNotes); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._transactionNotes.equals(temp._transactionNotes)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionNotes);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionNotes);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._transactionNotes);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._transactionNotes);
                    }
                }
            } else if (temp._transactionNotes != null)
                return false;
            if (this._branchShortCode != null) {
                if (temp._branchShortCode == null) return false;
                if (this._branchShortCode != temp._branchShortCode) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._branchShortCode);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._branchShortCode);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchShortCode); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchShortCode); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._branchShortCode.equals(temp._branchShortCode)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchShortCode);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchShortCode);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._branchShortCode);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._branchShortCode);
                    }
                }
            } else if (temp._branchShortCode != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'areaSize'.
     * 
     * @return the value of field 'AreaSize'.
     */
    public java.math.BigDecimal getAreaSize(
    ) {
        return this._areaSize;
    }

    /**
     * Returns the value of field 'branchShortCode'.
     * 
     * @return the value of field 'BranchShortCode'.
     */
    public java.lang.String getBranchShortCode(
    ) {
        return this._branchShortCode;
    }

    /**
     * Returns the value of field 'dicissionStatus'.
     * 
     * @return the value of field 'DicissionStatus'.
     */
    public java.lang.String getDicissionStatus(
    ) {
        return this._dicissionStatus;
    }

    /**
     * Returns the value of field 'farmLocation'.
     * 
     * @return the value of field 'FarmLocation'.
     */
    public java.lang.String getFarmLocation(
    ) {
        return this._farmLocation;
    }

    /**
     * Returns the value of field 'farmLocationDescription'.
     * 
     * @return the value of field 'FarmLocationDescription'.
     */
    public java.lang.String getFarmLocationDescription(
    ) {
        return this._farmLocationDescription;
    }

    /**
     * Returns the value of field 'landPlanNumber'.
     * 
     * @return the value of field 'LandPlanNumber'.
     */
    public java.lang.String getLandPlanNumber(
    ) {
        return this._landPlanNumber;
    }

    /**
     * Returns the value of field 'landPlotNumber'.
     * 
     * @return the value of field 'LandPlotNumber'.
     */
    public java.lang.String getLandPlotNumber(
    ) {
        return this._landPlotNumber;
    }

    /**
     * Returns the value of field 'linkedToCollateral'.
     * 
     * @return the value of field 'LinkedToCollateral'.
     */
    public java.lang.String getLinkedToCollateral(
    ) {
        return this._linkedToCollateral;
    }

    /**
     * Returns the value of field 'notes'.
     * 
     * @return the value of field 'Notes'.
     */
    public java.lang.String getNotes(
    ) {
        return this._notes;
    }

    /**
     * Returns the value of field 'reasonForChange'.
     * 
     * @return the value of field 'ReasonForChange'.
     */
    public java.lang.String getReasonForChange(
    ) {
        return this._reasonForChange;
    }

    /**
     * Returns the value of field 'retailIndex'.
     * 
     * @return the value of field 'RetailIndex'.
     */
    public java.lang.String getRetailIndex(
    ) {
        return this._retailIndex;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'splitIndicator'.
     * 
     * @return the value of field 'SplitIndicator'.
     */
    public java.lang.String getSplitIndicator(
    ) {
        return this._splitIndicator;
    }

    /**
     * Returns the value of field 'status'.
     * 
     * @return the value of field 'Status'.
     */
    public java.lang.String getStatus(
    ) {
        return this._status;
    }

    /**
     * Returns the value of field 'titleDeedIdpk'.
     * 
     * @return the value of field 'TitleDeedIdpk'.
     */
    public java.lang.String getTitleDeedIdpk(
    ) {
        return this._titleDeedIdpk;
    }

    /**
     * Returns the value of field 'titleDeedNumber'.
     * 
     * @return the value of field 'TitleDeedNumber'.
     */
    public java.lang.String getTitleDeedNumber(
    ) {
        return this._titleDeedNumber;
    }

    /**
     * Returns the value of field 'titleDeedSource'.
     * 
     * @return the value of field 'TitleDeedSource'.
     */
    public java.lang.String getTitleDeedSource(
    ) {
        return this._titleDeedSource;
    }

    /**
     * Returns the value of field 'titleDeedStatus'.
     * 
     * @return the value of field 'TitleDeedStatus'.
     */
    public java.lang.String getTitleDeedStatus(
    ) {
        return this._titleDeedStatus;
    }

    /**
     * Returns the value of field 'titleDeedType'.
     * 
     * @return the value of field 'TitleDeedType'.
     */
    public java.lang.String getTitleDeedType(
    ) {
        return this._titleDeedType;
    }

    /**
     * Returns the value of field 'titleDeedYear'.
     * 
     * @return the value of field 'TitleDeedYear'.
     */
    public java.lang.Integer getTitleDeedYear(
    ) {
        return this._titleDeedYear;
    }

    /**
     * Returns the value of field 'transactionDate'.
     * 
     * @return the value of field 'TransactionDate'.
     */
    public java.sql.Date getTransactionDate(
    ) {
        return this._transactionDate;
    }

    /**
     * Returns the value of field 'transactionNotes'.
     * 
     * @return the value of field 'TransactionNotes'.
     */
    public java.lang.String getTransactionNotes(
    ) {
        return this._transactionNotes;
    }

    /**
     * Returns the value of field 'transactionType'.
     * 
     * @return the value of field 'TransactionType'.
     */
    public java.lang.String getTransactionType(
    ) {
        return this._transactionType;
    }

    /**
     * Returns the value of field 'validFrom'.
     * 
     * @return the value of field 'ValidFrom'.
     */
    public java.sql.Date getValidFrom(
    ) {
        return this._validFrom;
    }

    /**
     * Returns the value of field 'validFromHijri'.
     * 
     * @return the value of field 'ValidFromHijri'.
     */
    public java.lang.String getValidFromHijri(
    ) {
        return this._validFromHijri;
    }

    /**
     * Returns the value of field 'validTo'.
     * 
     * @return the value of field 'ValidTo'.
     */
    public java.sql.Date getValidTo(
    ) {
        return this._validTo;
    }

    /**
     * Returns the value of field 'validToHijri'.
     * 
     * @return the value of field 'ValidToHijri'.
     */
    public java.lang.String getValidToHijri(
    ) {
        return this._validToHijri;
    }

    /**
     * Returns the value of field 'versionNumber'.
     * 
     * @return the value of field 'VersionNumber'.
     */
    public java.lang.Integer getVersionNumber(
    ) {
        return this._versionNumber;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_titleDeedIdpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedIdpk)) {
           result = 37 * result + _titleDeedIdpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedIdpk);
        }
        if (_titleDeedNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedNumber)) {
           result = 37 * result + _titleDeedNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedNumber);
        }
        if (_titleDeedYear != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedYear)) {
           result = 37 * result + _titleDeedYear.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedYear);
        }
        if (_titleDeedStatus != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedStatus)) {
           result = 37 * result + _titleDeedStatus.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedStatus);
        }
        if (_titleDeedType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedType)) {
           result = 37 * result + _titleDeedType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedType);
        }
        if (_farmLocation != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLocation)) {
           result = 37 * result + _farmLocation.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLocation);
        }
        if (_farmLocationDescription != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_farmLocationDescription)) {
           result = 37 * result + _farmLocationDescription.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_farmLocationDescription);
        }
        if (_dicissionStatus != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_dicissionStatus)) {
           result = 37 * result + _dicissionStatus.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_dicissionStatus);
        }
        if (_areaSize != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_areaSize)) {
           result = 37 * result + _areaSize.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_areaSize);
        }
        if (_retailIndex != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_retailIndex)) {
           result = 37 * result + _retailIndex.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_retailIndex);
        }
        if (_validFrom != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_validFrom)) {
           result = 37 * result + _validFrom.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_validFrom);
        }
        if (_validTo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_validTo)) {
           result = 37 * result + _validTo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_validTo);
        }
        if (_validFromHijri != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_validFromHijri)) {
           result = 37 * result + _validFromHijri.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_validFromHijri);
        }
        if (_validToHijri != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_validToHijri)) {
           result = 37 * result + _validToHijri.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_validToHijri);
        }
        if (_landPlotNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_landPlotNumber)) {
           result = 37 * result + _landPlotNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_landPlotNumber);
        }
        if (_landPlanNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_landPlanNumber)) {
           result = 37 * result + _landPlanNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_landPlanNumber);
        }
        if (_titleDeedSource != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedSource)) {
           result = 37 * result + _titleDeedSource.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedSource);
        }
        if (_linkedToCollateral != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_linkedToCollateral)) {
           result = 37 * result + _linkedToCollateral.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_linkedToCollateral);
        }
        if (_splitIndicator != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_splitIndicator)) {
           result = 37 * result + _splitIndicator.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_splitIndicator);
        }
        if (_reasonForChange != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_reasonForChange)) {
           result = 37 * result + _reasonForChange.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_reasonForChange);
        }
        if (_notes != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_notes)) {
           result = 37 * result + _notes.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_notes);
        }
        if (_versionNumber != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_versionNumber)) {
           result = 37 * result + _versionNumber.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_versionNumber);
        }
        if (_status != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_status)) {
           result = 37 * result + _status.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_status);
        }
        if (_transactionType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionType)) {
           result = 37 * result + _transactionType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionType);
        }
        if (_transactionDate != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionDate)) {
           result = 37 * result + _transactionDate.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionDate);
        }
        if (_transactionNotes != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_transactionNotes)) {
           result = 37 * result + _transactionNotes.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_transactionNotes);
        }
        if (_branchShortCode != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_branchShortCode)) {
           result = 37 * result + _branchShortCode.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_branchShortCode);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'areaSize'.
     * 
     * @param areaSize the value of field 'areaSize'.
     */
    public void setAreaSize(
            final java.math.BigDecimal areaSize) {
        this._areaSize = areaSize;
    }

    /**
     * Sets the value of field 'branchShortCode'.
     * 
     * @param branchShortCode the value of field 'branchShortCode'.
     */
    public void setBranchShortCode(
            final java.lang.String branchShortCode) {
        this._branchShortCode = branchShortCode;
    }

    /**
     * Sets the value of field 'dicissionStatus'.
     * 
     * @param dicissionStatus the value of field 'dicissionStatus'.
     */
    public void setDicissionStatus(
            final java.lang.String dicissionStatus) {
        this._dicissionStatus = dicissionStatus;
    }

    /**
     * Sets the value of field 'farmLocation'.
     * 
     * @param farmLocation the value of field 'farmLocation'.
     */
    public void setFarmLocation(
            final java.lang.String farmLocation) {
        this._farmLocation = farmLocation;
    }

    /**
     * Sets the value of field 'farmLocationDescription'.
     * 
     * @param farmLocationDescription the value of field
     * 'farmLocationDescription'.
     */
    public void setFarmLocationDescription(
            final java.lang.String farmLocationDescription) {
        this._farmLocationDescription = farmLocationDescription;
    }

    /**
     * Sets the value of field 'landPlanNumber'.
     * 
     * @param landPlanNumber the value of field 'landPlanNumber'.
     */
    public void setLandPlanNumber(
            final java.lang.String landPlanNumber) {
        this._landPlanNumber = landPlanNumber;
    }

    /**
     * Sets the value of field 'landPlotNumber'.
     * 
     * @param landPlotNumber the value of field 'landPlotNumber'.
     */
    public void setLandPlotNumber(
            final java.lang.String landPlotNumber) {
        this._landPlotNumber = landPlotNumber;
    }

    /**
     * Sets the value of field 'linkedToCollateral'.
     * 
     * @param linkedToCollateral the value of field
     * 'linkedToCollateral'.
     */
    public void setLinkedToCollateral(
            final java.lang.String linkedToCollateral) {
        this._linkedToCollateral = linkedToCollateral;
    }

    /**
     * Sets the value of field 'notes'.
     * 
     * @param notes the value of field 'notes'.
     */
    public void setNotes(
            final java.lang.String notes) {
        this._notes = notes;
    }

    /**
     * Sets the value of field 'reasonForChange'.
     * 
     * @param reasonForChange the value of field 'reasonForChange'.
     */
    public void setReasonForChange(
            final java.lang.String reasonForChange) {
        this._reasonForChange = reasonForChange;
    }

    /**
     * Sets the value of field 'retailIndex'.
     * 
     * @param retailIndex the value of field 'retailIndex'.
     */
    public void setRetailIndex(
            final java.lang.String retailIndex) {
        this._retailIndex = retailIndex;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'splitIndicator'.
     * 
     * @param splitIndicator the value of field 'splitIndicator'.
     */
    public void setSplitIndicator(
            final java.lang.String splitIndicator) {
        this._splitIndicator = splitIndicator;
    }

    /**
     * Sets the value of field 'status'.
     * 
     * @param status the value of field 'status'.
     */
    public void setStatus(
            final java.lang.String status) {
        this._status = status;
    }

    /**
     * Sets the value of field 'titleDeedIdpk'.
     * 
     * @param titleDeedIdpk the value of field 'titleDeedIdpk'.
     */
    public void setTitleDeedIdpk(
            final java.lang.String titleDeedIdpk) {
        this._titleDeedIdpk = titleDeedIdpk;
    }

    /**
     * Sets the value of field 'titleDeedNumber'.
     * 
     * @param titleDeedNumber the value of field 'titleDeedNumber'.
     */
    public void setTitleDeedNumber(
            final java.lang.String titleDeedNumber) {
        this._titleDeedNumber = titleDeedNumber;
    }

    /**
     * Sets the value of field 'titleDeedSource'.
     * 
     * @param titleDeedSource the value of field 'titleDeedSource'.
     */
    public void setTitleDeedSource(
            final java.lang.String titleDeedSource) {
        this._titleDeedSource = titleDeedSource;
    }

    /**
     * Sets the value of field 'titleDeedStatus'.
     * 
     * @param titleDeedStatus the value of field 'titleDeedStatus'.
     */
    public void setTitleDeedStatus(
            final java.lang.String titleDeedStatus) {
        this._titleDeedStatus = titleDeedStatus;
    }

    /**
     * Sets the value of field 'titleDeedType'.
     * 
     * @param titleDeedType the value of field 'titleDeedType'.
     */
    public void setTitleDeedType(
            final java.lang.String titleDeedType) {
        this._titleDeedType = titleDeedType;
    }

    /**
     * Sets the value of field 'titleDeedYear'.
     * 
     * @param titleDeedYear the value of field 'titleDeedYear'.
     */
    public void setTitleDeedYear(
            final java.lang.Integer titleDeedYear) {
        this._titleDeedYear = titleDeedYear;
    }

    /**
     * Sets the value of field 'transactionDate'.
     * 
     * @param transactionDate the value of field 'transactionDate'.
     */
    public void setTransactionDate(
            final java.sql.Date transactionDate) {
        this._transactionDate = transactionDate;
    }

    /**
     * Sets the value of field 'transactionNotes'.
     * 
     * @param transactionNotes the value of field 'transactionNotes'
     */
    public void setTransactionNotes(
            final java.lang.String transactionNotes) {
        this._transactionNotes = transactionNotes;
    }

    /**
     * Sets the value of field 'transactionType'.
     * 
     * @param transactionType the value of field 'transactionType'.
     */
    public void setTransactionType(
            final java.lang.String transactionType) {
        this._transactionType = transactionType;
    }

    /**
     * Sets the value of field 'validFrom'.
     * 
     * @param validFrom the value of field 'validFrom'.
     */
    public void setValidFrom(
            final java.sql.Date validFrom) {
        this._validFrom = validFrom;
    }

    /**
     * Sets the value of field 'validFromHijri'.
     * 
     * @param validFromHijri the value of field 'validFromHijri'.
     */
    public void setValidFromHijri(
            final java.lang.String validFromHijri) {
        this._validFromHijri = validFromHijri;
    }

    /**
     * Sets the value of field 'validTo'.
     * 
     * @param validTo the value of field 'validTo'.
     */
    public void setValidTo(
            final java.sql.Date validTo) {
        this._validTo = validTo;
    }

    /**
     * Sets the value of field 'validToHijri'.
     * 
     * @param validToHijri the value of field 'validToHijri'.
     */
    public void setValidToHijri(
            final java.lang.String validToHijri) {
        this._validToHijri = validToHijri;
    }

    /**
     * Sets the value of field 'versionNumber'.
     * 
     * @param versionNumber the value of field 'versionNumber'.
     */
    public void setVersionNumber(
            final java.lang.Integer versionNumber) {
        this._versionNumber = versionNumber;
    }

    /**
     * Method unmarshalTitleDeedDetailsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.TitleDeedDetailsType
     */
    public static com.misys.ce.types.TitleDeedDetailsType unmarshalTitleDeedDetailsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.TitleDeedDetailsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.TitleDeedDetailsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
