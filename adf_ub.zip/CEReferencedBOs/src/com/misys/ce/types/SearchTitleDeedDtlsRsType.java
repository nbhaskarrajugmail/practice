/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchTitleDeedDtlsRsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchTitleDeedDtlsRsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _listTitleDeedIdDtls.
     */
    private com.misys.ce.types.ListTitleDeedIdDtlsType _listTitleDeedIdDtls;

    /**
     * Field _pagingInfo.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagingInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchTitleDeedDtlsRsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchTitleDeedDtlsRsType) {

            SearchTitleDeedDtlsRsType temp = (SearchTitleDeedDtlsRsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._listTitleDeedIdDtls != null) {
                if (temp._listTitleDeedIdDtls == null) return false;
                if (this._listTitleDeedIdDtls != temp._listTitleDeedIdDtls) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._listTitleDeedIdDtls);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._listTitleDeedIdDtls);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listTitleDeedIdDtls); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listTitleDeedIdDtls); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._listTitleDeedIdDtls.equals(temp._listTitleDeedIdDtls)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listTitleDeedIdDtls);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listTitleDeedIdDtls);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._listTitleDeedIdDtls);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._listTitleDeedIdDtls);
                    }
                }
            } else if (temp._listTitleDeedIdDtls != null)
                return false;
            if (this._pagingInfo != null) {
                if (temp._pagingInfo == null) return false;
                if (this._pagingInfo != temp._pagingInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagingInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagingInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagingInfo.equals(temp._pagingInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                    }
                }
            } else if (temp._pagingInfo != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'listTitleDeedIdDtls'.
     * 
     * @return the value of field 'ListTitleDeedIdDtls'.
     */
    public com.misys.ce.types.ListTitleDeedIdDtlsType getListTitleDeedIdDtls(
    ) {
        return this._listTitleDeedIdDtls;
    }

    /**
     * Returns the value of field 'pagingInfo'.
     * 
     * @return the value of field 'PagingInfo'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagingInfo(
    ) {
        return this._pagingInfo;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_listTitleDeedIdDtls != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_listTitleDeedIdDtls)) {
           result = 37 * result + _listTitleDeedIdDtls.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_listTitleDeedIdDtls);
        }
        if (_pagingInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagingInfo)) {
           result = 37 * result + _pagingInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagingInfo);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'listTitleDeedIdDtls'.
     * 
     * @param listTitleDeedIdDtls the value of field
     * 'listTitleDeedIdDtls'.
     */
    public void setListTitleDeedIdDtls(
            final com.misys.ce.types.ListTitleDeedIdDtlsType listTitleDeedIdDtls) {
        this._listTitleDeedIdDtls = listTitleDeedIdDtls;
    }

    /**
     * Sets the value of field 'pagingInfo'.
     * 
     * @param pagingInfo the value of field 'pagingInfo'.
     */
    public void setPagingInfo(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagingInfo) {
        this._pagingInfo = pagingInfo;
    }

    /**
     * Method unmarshalSearchTitleDeedDtlsRsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchTitleDeedDtlsRsType
     */
    public static com.misys.ce.types.SearchTitleDeedDtlsRsType unmarshalSearchTitleDeedDtlsRsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchTitleDeedDtlsRsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchTitleDeedDtlsRsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
