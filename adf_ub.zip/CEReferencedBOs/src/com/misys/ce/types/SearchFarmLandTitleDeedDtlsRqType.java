/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class SearchFarmLandTitleDeedDtlsRqType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class SearchFarmLandTitleDeedDtlsRqType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _searchFarmLandTitleDeedDtls.
     */
    private com.misys.ce.types.TitleDeedDetailsType _searchFarmLandTitleDeedDtls;

    /**
     * Field _pagingInfo.
     */
    private bf.com.misys.bankfusion.attributes.PagedQuery _pagingInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public SearchFarmLandTitleDeedDtlsRqType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof SearchFarmLandTitleDeedDtlsRqType) {

            SearchFarmLandTitleDeedDtlsRqType temp = (SearchFarmLandTitleDeedDtlsRqType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._searchFarmLandTitleDeedDtls != null) {
                if (temp._searchFarmLandTitleDeedDtls == null) return false;
                if (this._searchFarmLandTitleDeedDtls != temp._searchFarmLandTitleDeedDtls) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._searchFarmLandTitleDeedDtls);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._searchFarmLandTitleDeedDtls);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchFarmLandTitleDeedDtls); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchFarmLandTitleDeedDtls); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._searchFarmLandTitleDeedDtls.equals(temp._searchFarmLandTitleDeedDtls)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchFarmLandTitleDeedDtls);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchFarmLandTitleDeedDtls);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._searchFarmLandTitleDeedDtls);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._searchFarmLandTitleDeedDtls);
                    }
                }
            } else if (temp._searchFarmLandTitleDeedDtls != null)
                return false;
            if (this._pagingInfo != null) {
                if (temp._pagingInfo == null) return false;
                if (this._pagingInfo != temp._pagingInfo) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._pagingInfo);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._pagingInfo);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._pagingInfo.equals(temp._pagingInfo)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._pagingInfo);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._pagingInfo);
                    }
                }
            } else if (temp._pagingInfo != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'pagingInfo'.
     * 
     * @return the value of field 'PagingInfo'.
     */
    public bf.com.misys.bankfusion.attributes.PagedQuery getPagingInfo(
    ) {
        return this._pagingInfo;
    }

    /**
     * Returns the value of field 'searchFarmLandTitleDeedDtls'.
     * 
     * @return the value of field 'SearchFarmLandTitleDeedDtls'.
     */
    public com.misys.ce.types.TitleDeedDetailsType getSearchFarmLandTitleDeedDtls(
    ) {
        return this._searchFarmLandTitleDeedDtls;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_searchFarmLandTitleDeedDtls != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_searchFarmLandTitleDeedDtls)) {
           result = 37 * result + _searchFarmLandTitleDeedDtls.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_searchFarmLandTitleDeedDtls);
        }
        if (_pagingInfo != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_pagingInfo)) {
           result = 37 * result + _pagingInfo.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_pagingInfo);
        }

        return result;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'pagingInfo'.
     * 
     * @param pagingInfo the value of field 'pagingInfo'.
     */
    public void setPagingInfo(
            final bf.com.misys.bankfusion.attributes.PagedQuery pagingInfo) {
        this._pagingInfo = pagingInfo;
    }

    /**
     * Sets the value of field 'searchFarmLandTitleDeedDtls'.
     * 
     * @param searchFarmLandTitleDeedDtls the value of field
     * 'searchFarmLandTitleDeedDtls'.
     */
    public void setSearchFarmLandTitleDeedDtls(
            final com.misys.ce.types.TitleDeedDetailsType searchFarmLandTitleDeedDtls) {
        this._searchFarmLandTitleDeedDtls = searchFarmLandTitleDeedDtls;
    }

    /**
     * Method unmarshalSearchFarmLandTitleDeedDtlsRqType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled
     * com.misys.ce.types.SearchFarmLandTitleDeedDtlsRqType
     */
    public static com.misys.ce.types.SearchFarmLandTitleDeedDtlsRqType unmarshalSearchFarmLandTitleDeedDtlsRqType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.SearchFarmLandTitleDeedDtlsRqType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.SearchFarmLandTitleDeedDtlsRqType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
