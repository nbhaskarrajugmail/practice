/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 1.3.1</a>, using an XML
 * Schema.
 * $Id$
 */

package com.misys.ce.types;

/**
 * Class ShareHolderDtlsType.
 * 
 * @version $Revision$ $Date$
 */
@SuppressWarnings("serial")
public class ShareHolderDtlsType implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field serialVersionUID.
     */
    public static final long serialVersionUID = 1L;

    /**
     * Field _shareHolderIdpk.
     */
    private java.lang.String _shareHolderIdpk;

    /**
     * Field _titleDeedId.
     */
    private java.lang.String _titleDeedId;

    /**
     * Field _partId.
     */
    private java.lang.String _partId;

    /**
     * Field _ownershipStatus.
     */
    private java.lang.String _ownershipStatus;

    /**
     * Field _ownershipType.
     */
    private java.lang.String _ownershipType;

    /**
     * Field _partyName.
     */
    private java.lang.String _partyName;

    /**
     * Field _sharePercentage.
     */
    private java.math.BigDecimal _sharePercentage;

    /**
     * Field _notes.
     */
    private java.lang.String _notes;

    /**
     * Field _select.
     */
    private java.lang.Boolean _select;


      //----------------/
     //- Constructors -/
    //----------------/

    public ShareHolderDtlsType() {
        super();
    }


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Overrides the java.lang.Object.equals method.
     * 
     * @param obj
     * @return true if the objects are equal.
     */
    @Override()
    public boolean equals(
            final java.lang.Object obj) {
        if ( this == obj )
            return true;

        if (obj instanceof ShareHolderDtlsType) {

            ShareHolderDtlsType temp = (ShareHolderDtlsType)obj;
            boolean thcycle;
            boolean tmcycle;
            if (this._shareHolderIdpk != null) {
                if (temp._shareHolderIdpk == null) return false;
                if (this._shareHolderIdpk != temp._shareHolderIdpk) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._shareHolderIdpk);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._shareHolderIdpk);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._shareHolderIdpk); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._shareHolderIdpk); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._shareHolderIdpk.equals(temp._shareHolderIdpk)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._shareHolderIdpk);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._shareHolderIdpk);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._shareHolderIdpk);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._shareHolderIdpk);
                    }
                }
            } else if (temp._shareHolderIdpk != null)
                return false;
            if (this._titleDeedId != null) {
                if (temp._titleDeedId == null) return false;
                if (this._titleDeedId != temp._titleDeedId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._titleDeedId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._titleDeedId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._titleDeedId.equals(temp._titleDeedId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._titleDeedId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._titleDeedId);
                    }
                }
            } else if (temp._titleDeedId != null)
                return false;
            if (this._partId != null) {
                if (temp._partId == null) return false;
                if (this._partId != temp._partId) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partId);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partId);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partId); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partId); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partId.equals(temp._partId)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partId);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partId);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partId);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partId);
                    }
                }
            } else if (temp._partId != null)
                return false;
            if (this._ownershipStatus != null) {
                if (temp._ownershipStatus == null) return false;
                if (this._ownershipStatus != temp._ownershipStatus) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ownershipStatus);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ownershipStatus);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipStatus); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipStatus); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ownershipStatus.equals(temp._ownershipStatus)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipStatus);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipStatus);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipStatus);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipStatus);
                    }
                }
            } else if (temp._ownershipStatus != null)
                return false;
            if (this._ownershipType != null) {
                if (temp._ownershipType == null) return false;
                if (this._ownershipType != temp._ownershipType) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._ownershipType);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._ownershipType);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipType); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipType); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._ownershipType.equals(temp._ownershipType)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipType);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipType);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._ownershipType);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._ownershipType);
                    }
                }
            } else if (temp._ownershipType != null)
                return false;
            if (this._partyName != null) {
                if (temp._partyName == null) return false;
                if (this._partyName != temp._partyName) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._partyName);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._partyName);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._partyName.equals(temp._partyName)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._partyName);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._partyName);
                    }
                }
            } else if (temp._partyName != null)
                return false;
            if (this._sharePercentage != null) {
                if (temp._sharePercentage == null) return false;
                if (this._sharePercentage != temp._sharePercentage) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._sharePercentage);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._sharePercentage);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sharePercentage); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sharePercentage); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._sharePercentage.equals(temp._sharePercentage)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sharePercentage);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sharePercentage);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._sharePercentage);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._sharePercentage);
                    }
                }
            } else if (temp._sharePercentage != null)
                return false;
            if (this._notes != null) {
                if (temp._notes == null) return false;
                if (this._notes != temp._notes) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._notes);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._notes);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._notes.equals(temp._notes)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._notes);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._notes);
                    }
                }
            } else if (temp._notes != null)
                return false;
            if (this._select != null) {
                if (temp._select == null) return false;
                if (this._select != temp._select) {
                    thcycle=org.castor.core.util.CycleBreaker.startingToCycle(this._select);
                    tmcycle=org.castor.core.util.CycleBreaker.startingToCycle(temp._select);
                    if (thcycle!=tmcycle) {
                        if (!thcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select); };
                        if (!tmcycle) { org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select); };
                        return false;
                    }
                    if (!thcycle) {
                        if (!this._select.equals(temp._select)) {
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                            org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                            return false;
                        }
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(this._select);
                        org.castor.core.util.CycleBreaker.releaseCycleHandle(temp._select);
                    }
                }
            } else if (temp._select != null)
                return false;
            return true;
        }
        return false;
    }

    /**
     * Returns the value of field 'notes'.
     * 
     * @return the value of field 'Notes'.
     */
    public java.lang.String getNotes(
    ) {
        return this._notes;
    }

    /**
     * Returns the value of field 'ownershipStatus'.
     * 
     * @return the value of field 'OwnershipStatus'.
     */
    public java.lang.String getOwnershipStatus(
    ) {
        return this._ownershipStatus;
    }

    /**
     * Returns the value of field 'ownershipType'.
     * 
     * @return the value of field 'OwnershipType'.
     */
    public java.lang.String getOwnershipType(
    ) {
        return this._ownershipType;
    }

    /**
     * Returns the value of field 'partId'.
     * 
     * @return the value of field 'PartId'.
     */
    public java.lang.String getPartId(
    ) {
        return this._partId;
    }

    /**
     * Returns the value of field 'partyName'.
     * 
     * @return the value of field 'PartyName'.
     */
    public java.lang.String getPartyName(
    ) {
        return this._partyName;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean getSelect(
    ) {
        return this._select;
    }

    /**
     * Returns the value of field 'shareHolderIdpk'.
     * 
     * @return the value of field 'ShareHolderIdpk'.
     */
    public java.lang.String getShareHolderIdpk(
    ) {
        return this._shareHolderIdpk;
    }

    /**
     * Returns the value of field 'sharePercentage'.
     * 
     * @return the value of field 'SharePercentage'.
     */
    public java.math.BigDecimal getSharePercentage(
    ) {
        return this._sharePercentage;
    }

    /**
     * Returns the value of field 'titleDeedId'.
     * 
     * @return the value of field 'TitleDeedId'.
     */
    public java.lang.String getTitleDeedId(
    ) {
        return this._titleDeedId;
    }

    /**
     * Overrides the java.lang.Object.hashCode method.
     * <p>
     * The following steps came from <b>Effective Java Programming
     * Language Guide</b> by Joshua Bloch, Chapter 3
     * 
     * @return a hash code value for the object.
     */
    public int hashCode(
    ) {
        int result = 17;

        long tmp;
        if (_shareHolderIdpk != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_shareHolderIdpk)) {
           result = 37 * result + _shareHolderIdpk.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_shareHolderIdpk);
        }
        if (_titleDeedId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_titleDeedId)) {
           result = 37 * result + _titleDeedId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_titleDeedId);
        }
        if (_partId != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partId)) {
           result = 37 * result + _partId.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partId);
        }
        if (_ownershipStatus != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ownershipStatus)) {
           result = 37 * result + _ownershipStatus.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ownershipStatus);
        }
        if (_ownershipType != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_ownershipType)) {
           result = 37 * result + _ownershipType.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_ownershipType);
        }
        if (_partyName != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_partyName)) {
           result = 37 * result + _partyName.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_partyName);
        }
        if (_sharePercentage != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_sharePercentage)) {
           result = 37 * result + _sharePercentage.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_sharePercentage);
        }
        if (_notes != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_notes)) {
           result = 37 * result + _notes.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_notes);
        }
        if (_select != null
               && !org.castor.core.util.CycleBreaker.startingToCycle(_select)) {
           result = 37 * result + _select.hashCode();
           org.castor.core.util.CycleBreaker.releaseCycleHandle(_select);
        }

        return result;
    }

    /**
     * Returns the value of field 'select'.
     * 
     * @return the value of field 'Select'.
     */
    public java.lang.Boolean isSelect(
    ) {
        return this._select;
    }

    /**
     * Method isValid.
     * 
     * @return true if this object is valid according to the schema
     */
    public boolean isValid(
    ) {
        try {
            validate();
        } catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    }

    /**
     * 
     * 
     * @param out
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void marshal(
            final java.io.Writer out)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, out);
    }

    /**
     * 
     * 
     * @param handler
     * @throws java.io.IOException if an IOException occurs during
     * marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     */
    public void marshal(
            final org.xml.sax.ContentHandler handler)
    throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Marshaller.marshal(this, handler);
    }

    /**
     * Sets the value of field 'notes'.
     * 
     * @param notes the value of field 'notes'.
     */
    public void setNotes(
            final java.lang.String notes) {
        this._notes = notes;
    }

    /**
     * Sets the value of field 'ownershipStatus'.
     * 
     * @param ownershipStatus the value of field 'ownershipStatus'.
     */
    public void setOwnershipStatus(
            final java.lang.String ownershipStatus) {
        this._ownershipStatus = ownershipStatus;
    }

    /**
     * Sets the value of field 'ownershipType'.
     * 
     * @param ownershipType the value of field 'ownershipType'.
     */
    public void setOwnershipType(
            final java.lang.String ownershipType) {
        this._ownershipType = ownershipType;
    }

    /**
     * Sets the value of field 'partId'.
     * 
     * @param partId the value of field 'partId'.
     */
    public void setPartId(
            final java.lang.String partId) {
        this._partId = partId;
    }

    /**
     * Sets the value of field 'partyName'.
     * 
     * @param partyName the value of field 'partyName'.
     */
    public void setPartyName(
            final java.lang.String partyName) {
        this._partyName = partyName;
    }

    /**
     * Sets the value of field 'select'.
     * 
     * @param select the value of field 'select'.
     */
    public void setSelect(
            final java.lang.Boolean select) {
        this._select = select;
    }

    /**
     * Sets the value of field 'shareHolderIdpk'.
     * 
     * @param shareHolderIdpk the value of field 'shareHolderIdpk'.
     */
    public void setShareHolderIdpk(
            final java.lang.String shareHolderIdpk) {
        this._shareHolderIdpk = shareHolderIdpk;
    }

    /**
     * Sets the value of field 'sharePercentage'.
     * 
     * @param sharePercentage the value of field 'sharePercentage'.
     */
    public void setSharePercentage(
            final java.math.BigDecimal sharePercentage) {
        this._sharePercentage = sharePercentage;
    }

    /**
     * Sets the value of field 'titleDeedId'.
     * 
     * @param titleDeedId the value of field 'titleDeedId'.
     */
    public void setTitleDeedId(
            final java.lang.String titleDeedId) {
        this._titleDeedId = titleDeedId;
    }

    /**
     * Method unmarshalShareHolderDtlsType.
     * 
     * @param reader
     * @throws org.exolab.castor.xml.MarshalException if object is
     * null or if any SAXException is thrown during marshaling
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     * @return the unmarshaled com.misys.ce.types.ShareHolderDtlsTyp
     */
    public static com.misys.ce.types.ShareHolderDtlsType unmarshalShareHolderDtlsType(
            final java.io.Reader reader)
    throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException {
        return (com.misys.ce.types.ShareHolderDtlsType) org.exolab.castor.xml.Unmarshaller.unmarshal(com.misys.ce.types.ShareHolderDtlsType.class, reader);
    }

    /**
     * 
     * 
     * @throws org.exolab.castor.xml.ValidationException if this
     * object is an invalid instance according to the schema
     */
    public void validate(
    )
    throws org.exolab.castor.xml.ValidationException {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    }

}
