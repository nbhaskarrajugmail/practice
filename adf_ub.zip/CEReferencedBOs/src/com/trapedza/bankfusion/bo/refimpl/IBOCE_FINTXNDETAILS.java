
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface IBOCE_FINTXNDETAILS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_FINTXNDETAILS";
	public static final String POSTINGDATE = "f_POSTINGDATE";
	public static final String VALUEDATE = "f_VALUEDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String GLDESC = "f_GLDESC";
	public static final String BRANCH = "f_BRANCH";
	public static final String CUSTNAME = "f_CUSTNAME";
	public static final String CUSTID = "f_CUSTID";
	public static final String GLCODE = "f_GLCODE";
	public static final String AMOUNT = "f_AMOUNT";
	public static final String ACCOUNTID = "f_ACCOUNTID";
	public static final String PRINTED = "f_PRINTED";
	public static final String TXNID = "f_TXNID";
	public static final String TXNSRID = "boID";
	public static final String TXNDATE = "f_TXNDATE";
	public static final String PROCESSED = "f_PROCESSED";
	public static final String TXNCODE = "f_TXNCODE";
	public static final String NARRATION = "f_NARRATION";
	public static final String LOANACCOUNTID = "f_LOANACCOUNTID";
	public static final String CURRENCY = "f_CURRENCY";
	public static final String DRCRFLAG = "f_DRCRFLAG";

	public Timestamp getF_POSTINGDATE();

	public void setF_POSTINGDATE(Timestamp param);

	public Timestamp getF_VALUEDATE();

	public void setF_VALUEDATE(Timestamp param);

	public String getF_GLDESC();

	public void setF_GLDESC(String param);

	public String getF_BRANCH();

	public void setF_BRANCH(String param);

	public String getF_CUSTNAME();

	public void setF_CUSTNAME(String param);

	public String getF_CUSTID();

	public void setF_CUSTID(String param);

	public String getF_GLCODE();

	public void setF_GLCODE(String param);

	public BigDecimal getF_AMOUNT();

	public void setF_AMOUNT(BigDecimal param);

	public String getF_ACCOUNTID();

	public void setF_ACCOUNTID(String param);

	public boolean isF_PRINTED();

	public void setF_PRINTED(boolean param);

	public String getF_TXNID();

	public void setF_TXNID(String param);

	public Timestamp getF_TXNDATE();

	public void setF_TXNDATE(Timestamp param);

	public String getF_PROCESSED();

	public void setF_PROCESSED(String param);

	public String getF_TXNCODE();

	public void setF_TXNCODE(String param);

	public String getF_NARRATION();

	public void setF_NARRATION(String param);

	public String getF_LOANACCOUNTID();

	public void setF_LOANACCOUNTID(String param);

	public String getF_CURRENCY();

	public void setF_CURRENCY(String param);

	public String getF_DRCRFLAG();

	public void setF_DRCRFLAG(String param);

}