
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Date;

public interface IBOCE_BATCHTXNDETAIL extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_BATCHTXNDETAIL";
	public static final String VALUEDATE = "f_VALUEDATE";
	public static final String BANKID = "f_BANKID";
	public static final String VERSIONNUM = "versionNum";
	public static final String CHEQUENUMBER = "f_CHEQUENUMBER";
	public static final String MOFDOCDATE = "f_MOFDOCDATE";
	public static final String STATUS = "f_STATUS";
	public static final String BRANCHCD = "f_BRANCHCD";
	public static final String CHEQUENO = "f_CHEQUENO";
	public static final String CREDITACC = "f_CREDITACC";
	public static final String AMOUNT = "f_AMOUNT";
	public static final String MOFDOCNUMBER = "f_MOFDOCNUMBER";
	public static final String BATCHREF = "f_BATCHREF";
	public static final String ID = "boID";
	public static final String NARRATIVE = "f_NARRATIVE";
	public static final String HOSTTXNREF = "f_HOSTTXNREF";
	public static final String TXNREF = "f_TXNREF";
	public static final String INTERNALACC = "f_INTERNALACC";
	public static final String PROCESSING = "f_PROCESSING";
	public static final String TXNDATE = "f_TXNDATE";
	public static final String BATCHGWREF = "f_BATCHGWREF";
	public static final String BATCHRUNNINGAMNT = "f_BATCHRUNNINGAMNT";
	public static final String NATIONALID = "f_NATIONALID";
	public static final String VALUEDATEHIJRI = "f_VALUEDATEHIJRI";
	public static final String DEBITACC = "f_DEBITACC";
	public static final String PAYEENAME = "f_PAYEENAME";
	public static final String CHEQUEDATE = "f_CHEQUEDATE";

	public Date getF_VALUEDATE();

	public void setF_VALUEDATE(Date param);

	public String getF_BANKID();

	public void setF_BANKID(String param);

	public String getF_CHEQUENUMBER();

	public void setF_CHEQUENUMBER(String param);

	public Date getF_MOFDOCDATE();

	public void setF_MOFDOCDATE(Date param);

	public String getF_STATUS();

	public void setF_STATUS(String param);

	public String getF_BRANCHCD();

	public void setF_BRANCHCD(String param);

	public String getF_CHEQUENO();

	public void setF_CHEQUENO(String param);

	public String getF_CREDITACC();

	public void setF_CREDITACC(String param);

	public BigDecimal getF_AMOUNT();

	public void setF_AMOUNT(BigDecimal param);

	public String getF_MOFDOCNUMBER();

	public void setF_MOFDOCNUMBER(String param);

	public String getF_BATCHREF();

	public void setF_BATCHREF(String param);

	public String getF_NARRATIVE();

	public void setF_NARRATIVE(String param);

	public String getF_HOSTTXNREF();

	public void setF_HOSTTXNREF(String param);

	public String getF_TXNREF();

	public void setF_TXNREF(String param);

	public String getF_INTERNALACC();

	public void setF_INTERNALACC(String param);

	public String getF_PROCESSING();

	public void setF_PROCESSING(String param);

	public Date getF_TXNDATE();

	public void setF_TXNDATE(Date param);

	public String getF_BATCHGWREF();

	public void setF_BATCHGWREF(String param);

	public BigDecimal getF_BATCHRUNNINGAMNT();

	public void setF_BATCHRUNNINGAMNT(BigDecimal param);

	public String getF_NATIONALID();

	public void setF_NATIONALID(String param);

	public String getF_VALUEDATEHIJRI();

	public void setF_VALUEDATEHIJRI(String param);

	public String getF_DEBITACC();

	public void setF_DEBITACC(String param);

	public String getF_PAYEENAME();

	public void setF_PAYEENAME(String param);

	public Date getF_CHEQUEDATE();

	public void setF_CHEQUEDATE(Date param);

}