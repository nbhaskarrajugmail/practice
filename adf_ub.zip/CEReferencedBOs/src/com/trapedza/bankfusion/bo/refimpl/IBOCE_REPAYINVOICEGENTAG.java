package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_REPAYINVOICEGENTAG extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_REPAYINVOICEGENTAG";
	public static final String AMOUNTDUE = "f_AMOUNTDUE";
	public static final String DUEDATE = "f_DUEDATE";
	public static final String ACCOUNTID = "f_ACCOUNTID";
	public static final String ROWSEQID = "boID";
	public static final String VERSIONNUM = "versionNum";

	public BigDecimal getF_AMOUNTDUE();

	public void setF_AMOUNTDUE(BigDecimal param);

	public Date getF_DUEDATE();

	public void setF_DUEDATE(Date param);

	public String getF_ACCOUNTID();

	public void setF_ACCOUNTID(String param);

}