
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;

public interface IBOCE_UPDATEBILLINVOICEGENTAG extends com.trapedza.bankfusion.core.SimplePersistentObject {

    public static final String BONAME = "CE_UPDATEBILLINVOICEGENTAG";

    public static final String BILLACTION = "f_BILLACTION";

    public static final String TAGSTATUS = "f_TAGSTATUS";

    public static final String BILLAMT = "f_BILLAMT";

    public static final String VERSIONNUM = "versionNum";

    public static final String BILLINVOICEPKEY = "f_BILLINVOICEPKEY";

    public static final String BILLCATEGORY = "f_BILLCATEGORY";

    public static final String REPAYMENTPAID = "f_REPAYMENTPAID";

    public static final String ROWSEQID = "boID";

    public static final String BILLACCT = "f_BILLACCT";

    public String getF_BILLACTION();

    public void setF_BILLACTION(String param);

    public int getF_TAGSTATUS();

    public void setF_TAGSTATUS(int param);

    public BigDecimal getF_BILLAMT();

    public void setF_BILLAMT(BigDecimal param);

    public String getF_BILLINVOICEPKEY();

    public void setF_BILLINVOICEPKEY(String param);

    public String getF_BILLCATEGORY();

    public void setF_BILLCATEGORY(String param);

    public BigDecimal getF_REPAYMENTPAID();

    public void setF_REPAYMENTPAID(BigDecimal param);

    public String getF_BILLACCT();

    public void setF_BILLACCT(String param);

}