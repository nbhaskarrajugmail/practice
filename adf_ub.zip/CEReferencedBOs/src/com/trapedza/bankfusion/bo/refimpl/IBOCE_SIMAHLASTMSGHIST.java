package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_SIMAHLASTMSGHIST extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SIMAHLASTMSGHIST";
	public static final String ASOFDATE = "f_ASOFDATE";
	public static final String REPAYMENTAMT = "f_REPAYMENTAMT";
	public static final String VERSIONNUM = "versionNum";
	public static final String LASTPAYDATE = "f_LASTPAYDATE";
	public static final String IDTYPE = "f_IDTYPE";
	public static final String PAYMENTSTATUS = "f_PAYMENTSTATUS";
	public static final String CYCLEID = "f_CYCLEID";
	public static final String PRODUCTSTATUS = "f_PRODUCTSTATUS";
	public static final String APPTYPE = "f_APPTYPE";
	public static final String PASTDUE = "f_PASTDUE";
	public static final String HISTID = "boID";
	public static final String MSGID = "f_MSGID";
	public static final String LASTAMTPAID = "f_LASTAMTPAID";
	public static final String SECURITYTYPE = "f_SECURITYTYPE";
	public static final String PRODUCTLIMIT = "f_PRODUCTLIMIT";
	public static final String OUTSTANDINGBAL = "f_OUTSTANDINGBAL";
	public static final String LOANISSUEDATE = "f_LOANISSUEDATE";
	public static final String CRINSTRUMENTNO = "f_CRINSTRUMENTNO";
	public static final String PAYFREQUENCY = "f_PAYFREQUENCY";
	public static final String NEXTREPAYDATE = "f_NEXTREPAYDATE";
	public static final String FILETYPE = "f_FILETYPE";
	public static final String PRODUCTTYPE = "f_PRODUCTTYPE";

	public Date getF_ASOFDATE();

	public void setF_ASOFDATE(Date param);

	public BigDecimal getF_REPAYMENTAMT();

	public void setF_REPAYMENTAMT(BigDecimal param);

	public Date getF_LASTPAYDATE();

	public void setF_LASTPAYDATE(Date param);

	public String getF_IDTYPE();

	public void setF_IDTYPE(String param);

	public String getF_PAYMENTSTATUS();

	public void setF_PAYMENTSTATUS(String param);

	public String getF_CYCLEID();

	public void setF_CYCLEID(String param);

	public String getF_PRODUCTSTATUS();

	public void setF_PRODUCTSTATUS(String param);

	public String getF_APPTYPE();

	public void setF_APPTYPE(String param);

	public BigDecimal getF_PASTDUE();

	public void setF_PASTDUE(BigDecimal param);

	public String getF_MSGID();

	public void setF_MSGID(String param);

	public BigDecimal getF_LASTAMTPAID();

	public void setF_LASTAMTPAID(BigDecimal param);

	public String getF_SECURITYTYPE();

	public void setF_SECURITYTYPE(String param);

	public BigDecimal getF_PRODUCTLIMIT();

	public void setF_PRODUCTLIMIT(BigDecimal param);

	public BigDecimal getF_OUTSTANDINGBAL();

	public void setF_OUTSTANDINGBAL(BigDecimal param);

	public Date getF_LOANISSUEDATE();

	public void setF_LOANISSUEDATE(Date param);

	public String getF_CRINSTRUMENTNO();

	public void setF_CRINSTRUMENTNO(String param);

	public String getF_PAYFREQUENCY();

	public void setF_PAYFREQUENCY(String param);

	public Date getF_NEXTREPAYDATE();

	public void setF_NEXTREPAYDATE(Date param);

	public String getF_FILETYPE();

	public void setF_FILETYPE(String param);

	public String getF_PRODUCTTYPE();

	public void setF_PRODUCTTYPE(String param);

}