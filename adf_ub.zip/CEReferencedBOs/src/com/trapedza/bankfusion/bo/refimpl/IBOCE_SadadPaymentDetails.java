package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_SadadPaymentDetails extends
		com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SadadPaymentDetails";
	public static final String SADADPAYMENTDTLSID = "boID";
	public static final String PmtAmt = "f_PmtAmt";
	public static final String PmtId = "f_PmtId";
	public static final String PmtDt = "f_PmtDt";
	public static final String AgencyId = "f_AgencyId";
	public static final String BillInvoiceNo = "f_BillInvoiceNo";
	public static final String STATUS = "f_STATUS";
	public static final String BankId = "f_BankId";
	public static final String VERSIONNUM = "versionNum";
	public static final String PmtStatusCode = "f_PmtStatusCode";
	public static final String BillCategory = "f_BillCategory";
	public static final String BillAcct = "f_BillAcct";
	public static final String STATUSDESCRIPTION = "f_STATUSDESCRIPTION";

	public BigDecimal getF_PmtAmt();

	public void setF_PmtAmt(BigDecimal param);

	public String getF_PmtId();

	public void setF_PmtId(String param);

	public Date getF_PmtDt();

	public void setF_PmtDt(Date param);

	public String getF_AgencyId();

	public void setF_AgencyId(String param);

	public String getF_BillInvoiceNo();

	public void setF_BillInvoiceNo(String param);

	public String getF_STATUS();

	public void setF_STATUS(String param);

	public String getF_BankId();

	public void setF_BankId(String param);

	public String getF_PmtStatusCode();

	public void setF_PmtStatusCode(String param);

	public String getF_BillCategory();

	public void setF_BillCategory(String param);

	public String getF_BillAcct();

	public void setF_BillAcct(String param);

	public String getF_STATUSDESCRIPTION();

	public void setF_STATUSDESCRIPTION(String param);

}