
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface IBOCE_FARMLANDLOCDTLS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_FARMLANDLOCDTLS";
	public static final String BORDER = "f_BORDER";
	public static final String DIRECTION = "f_DIRECTION";
	public static final String LENGTH = "f_LENGTH";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String TITLEDEEDID = "f_TITLEDEEDID";
	public static final String CONTRACTNUM = "f_CONTRACTNUM";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String FARMLANDLOCID = "boID";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";

	public String getF_BORDER();

	public void setF_BORDER(String param);

	public String getF_DIRECTION();

	public void setF_DIRECTION(String param);

	public BigDecimal getF_LENGTH();

	public void setF_LENGTH(BigDecimal param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public String getF_TITLEDEEDID();

	public void setF_TITLEDEEDID(String param);

	public String getF_CONTRACTNUM();

	public void setF_CONTRACTNUM(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

}