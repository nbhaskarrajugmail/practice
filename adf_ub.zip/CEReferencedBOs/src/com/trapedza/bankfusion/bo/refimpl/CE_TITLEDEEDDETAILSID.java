
package com.trapedza.bankfusion.bo.refimpl;

import com.trapedza.bankfusion.core.CommonConstants;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import java.io.Serializable;

public class CE_TITLEDEEDDETAILSID implements Serializable {
	private Integer f_TITLEDEEDVERSION = null;

	private String f_TITLEDEEDID = CommonConstants.EMPTY_STRING;

	public Integer getF_TITLEDEEDVERSION() {

		return f_TITLEDEEDVERSION;
	}

	public void setF_TITLEDEEDVERSION(Integer param) {
		f_TITLEDEEDVERSION = param;
	}

	public String getF_TITLEDEEDID() {

		return f_TITLEDEEDID;
	}

	public void setF_TITLEDEEDID(String param) {
		f_TITLEDEEDID = param;
	}

	public boolean equals(Object obj) {

		if (obj == null)
			return false;
		if (obj == this)
			return true;
		if (obj.getClass() != getClass())
			return false;
		CE_TITLEDEEDDETAILSID rhs = (CE_TITLEDEEDDETAILSID) obj;
		return new EqualsBuilder().append(f_TITLEDEEDVERSION, rhs.f_TITLEDEEDVERSION)
				.append(f_TITLEDEEDID, rhs.f_TITLEDEEDID).isEquals();
	}

	public int hashCode() {
		return new HashCodeBuilder(17, 31).append(f_TITLEDEEDVERSION).append(f_TITLEDEEDID).toHashCode();
	}

}