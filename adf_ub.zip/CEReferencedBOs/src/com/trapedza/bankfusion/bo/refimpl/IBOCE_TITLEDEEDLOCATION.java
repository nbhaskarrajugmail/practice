
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface IBOCE_TITLEDEEDLOCATION extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_TITLEDEEDLOCATION";
	public static final String LOCEASTSECTION = "f_LOCEASTSECTION";
	public static final String SERIAL = "f_SERIAL";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String LOCEASTDEGREE = "f_LOCEASTDEGREE";
	public static final String TITLEDEEDID = "f_TITLEDEEDID";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String LOCNORTHSECTION = "f_LOCNORTHSECTION";
	public static final String LOCNORTHDEGREE = "f_LOCNORTHDEGREE";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String TITLEDEEDLOCID = "boID";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";

	public BigDecimal getF_LOCEASTSECTION();

	public void setF_LOCEASTSECTION(BigDecimal param);

	public Integer getF_SERIAL();

	public void setF_SERIAL(Integer param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public BigDecimal getF_LOCEASTDEGREE();

	public void setF_LOCEASTDEGREE(BigDecimal param);

	public String getF_TITLEDEEDID();

	public void setF_TITLEDEEDID(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public BigDecimal getF_LOCNORTHSECTION();

	public void setF_LOCNORTHSECTION(BigDecimal param);

	public BigDecimal getF_LOCNORTHDEGREE();

	public void setF_LOCNORTHDEGREE(BigDecimal param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

}