
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Date;

public interface IBOCE_CANCELBILLINVOICEGENTAG extends com.trapedza.bankfusion.core.SimplePersistentObject {

    public static final String BONAME = "CE_CANCELBILLINVOICEGENTAG";

    public static final String BILLDUEDATE = "f_BILLDUEDATE";

    public static final String BILLINVOICENO = "f_BILLINVOICENO";

    public static final String TAGSTATUS = "f_TAGSTATUS";

    public static final String BILLACTION = "f_BILLACTION";

    public static final String BILLAMT = "f_BILLAMT";

    public static final String VERSIONNUM = "versionNum";

    public static final String BILLEXPDATE = "f_BILLEXPDATE";

    public static final String REQUESTKEY = "f_REQUESTKEY";

    public static final String BILLINVOICEPKEY = "f_BILLINVOICEPKEY";

    public static final String BILLCATEGORY = "f_BILLCATEGORY";

    public static final String ROWSEQID = "boID";

    public static final String BILLACCT = "f_BILLACCT";

    public Date getF_BILLDUEDATE();

    public void setF_BILLDUEDATE(Date param);

    public String getF_BILLINVOICENO();

    public void setF_BILLINVOICENO(String param);

    public int getF_TAGSTATUS();

    public void setF_TAGSTATUS(int param);

    public String getF_BILLACTION();

    public void setF_BILLACTION(String param);

    public BigDecimal getF_BILLAMT();

    public void setF_BILLAMT(BigDecimal param);

    public Date getF_BILLEXPDATE();

    public void setF_BILLEXPDATE(Date param);

    public String getF_REQUESTKEY();

    public void setF_REQUESTKEY(String param);

    public String getF_BILLINVOICEPKEY();

    public void setF_BILLINVOICEPKEY(String param);

    public String getF_BILLCATEGORY();

    public void setF_BILLCATEGORY(String param);

    public String getF_BILLACCT();

    public void setF_BILLACCT(String param);

}