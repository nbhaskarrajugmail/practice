
package com.trapedza.bankfusion.bo.refimpl;

import org.hibernate.mapping.Property;
import com.trapedza.bankfusion.persistence.hibernatesupport.MetaConfigurator;

public class BOCE_SIMAHACCOUNTMAPHBM extends MetaConfigurator {
	public String getClassName() {
		return "com.trapedza.bankfusion.bo.refimpl.BOCE_SIMAHACCOUNTMAPImpl";
	}

	public String getBOName() {
		return IBOCE_SIMAHACCOUNTMAP.BONAME;
	}

	public String getTableName() {
		return "CUSTOMEXTN.CETB_CE_SIMAHACCOUNTMAP";
	}

	public void addAllColumns() {

		Property prop = null;

		prop = addColumn("CESRCACCTNO", DATATYPE_STRING_JTYPE, false, IBOCE_SIMAHACCOUNTMAP.SRCACCTNO);
		prop = addColumn("CEPARTYTYPE", DATATYPE_STRING_JTYPE, false, IBOCE_SIMAHACCOUNTMAP.PARTYTYPE);
		prop = addColumn("VERSIONNUM", DATATYPE_INTEGER_JTYPE, false, IBOCE_SIMAHACCOUNTMAP.VERSIONNUM);
		versionNumSet = true;
		addVersionColumn(prop);
	}

	public String getBOID() {
		return "CETARACCTNOPK";
	}
}