
package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Timestamp;

public interface IBOCE_FARMLANDNEIGHBOURDTLS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_FARMLANDNEIGHBOURDTLS";
	public static final String PARTYID = "f_PARTYID";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String TITLEDEEDID = "f_TITLEDEEDID";
	public static final String PARTYNAME = "f_PARTYNAME";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String FARMLANDNGBID = "boID";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";

	public String getF_PARTYID();

	public void setF_PARTYID(String param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public String getF_TITLEDEEDID();

	public void setF_TITLEDEEDID(String param);

	public String getF_PARTYNAME();

	public void setF_PARTYNAME(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

}