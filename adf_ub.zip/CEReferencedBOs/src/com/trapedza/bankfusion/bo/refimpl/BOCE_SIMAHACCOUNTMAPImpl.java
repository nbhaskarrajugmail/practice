
package com.trapedza.bankfusion.bo.refimpl;

import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FieldChangeHelper;
import com.trapedza.bankfusion.core.MetaDataEnum;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.bo.config.RuntimeBOMethod;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.utils.Utils;

public class BOCE_SIMAHACCOUNTMAPImpl extends com.trapedza.bankfusion.core.SimplePersistentObjectImpl
		implements IBOCE_SIMAHACCOUNTMAP {
	private String f_SRCACCTNO = CommonConstants.EMPTY_STRING;

	private String f_PARTYTYPE = CommonConstants.EMPTY_STRING;

	public String getF_SRCACCTNO() {

		return f_SRCACCTNO;
	}

	public void setF_SRCACCTNO(String param) {
		FieldChangeHelper.setFieldValue(this, "f_SRCACCTNO", f_SRCACCTNO, param);
		f_SRCACCTNO = param;
	}

	public String getF_TARACCTNO() {
		return getBoID();
	}

	public void setF_TARACCTNO(String param) {
		setBoID(param);
	}

	public String getF_PARTYTYPE() {

		return f_PARTYTYPE;
	}

	public void setF_PARTYTYPE(String param) {
		FieldChangeHelper.setFieldValue(this, "f_PARTYTYPE", f_PARTYTYPE, param);
		f_PARTYTYPE = param;
	}

	public String getBOName() {
		return IBOCE_SIMAHACCOUNTMAP.BONAME;
	}

	public Map getFinderMethods() {
		Map finderMethods = super.getFinderMethods();
		return finderMethods;
	}

	public RuntimeBOMethod getFinderMethod(String methodName) {
		return (RuntimeBOMethod) super.getFinderMethods().get(methodName);
	}

	public Map getDataMap() {
		Map dataMap = super.getDataMap();
		dataMap.put(IBOCE_SIMAHACCOUNTMAP.SRCACCTNO, f_SRCACCTNO);
		dataMap.put(IBOCE_SIMAHACCOUNTMAP.TARACCTNO, getBoID());
		dataMap.put(IBOCE_SIMAHACCOUNTMAP.PARTYTYPE, f_PARTYTYPE);
		return dataMap;
	}

	public void updateFromMap(Map dataMap) throws BankFusionException {
		if (dataMap.containsKey(IBOCE_SIMAHACCOUNTMAP.SRCACCTNO))
			setF_SRCACCTNO(getSTRINGValue(dataMap.get(IBOCE_SIMAHACCOUNTMAP.SRCACCTNO)));

		if (dataMap.containsKey(IBOCE_SIMAHACCOUNTMAP.TARACCTNO)) {
			setBoID(getSTRINGValue(dataMap.get(IBOCE_SIMAHACCOUNTMAP.TARACCTNO)));
		} else if (dataMap.containsKey("f_TARACCTNO")) {
			setBoID(getSTRINGValue(dataMap.get("f_TARACCTNO")));
		}

		if (dataMap.containsKey(IBOCE_SIMAHACCOUNTMAP.PARTYTYPE))
			setF_PARTYTYPE(getSTRINGValue(dataMap.get(IBOCE_SIMAHACCOUNTMAP.PARTYTYPE)));

	}
}