package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_PTY_DeceasedPartyDtls extends
		com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_PTY_DeceasedPartyDtls";
	public static final String DAETHDATE = "f_DAETHDATE";
	public static final String BORROWERNATID = "f_BORROWERNATID";
	public static final String REPFULLNAME = "f_REPFULLNAME";
	public static final String ULDT = "f_ULDT";
	public static final String VERSIONNUM = "versionNum";
	public static final String ALHAFIZANO = "f_ALHAFIZANO";
	public static final String APPROVEDDT = "f_APPROVEDDT";
	public static final String LOANPLACE = "f_LOANPLACE";
	public static final String DLBATCHNO = "f_DLBATCHNO";
	public static final String ULSTATUS = "f_ULSTATUS";
	public static final String UPUSERID = "f_UPUSERID";
	public static final String REPNATID = "f_REPNATID";
	public static final String LOANBR = "f_LOANBR";
	public static final String REPCONTACNO = "f_REPCONTACNO";
	public static final String LOANACCTNO = "boID";
	public static final String REJREASON = "f_REJREASON";
	public static final String ALHAFIZASRC = "f_ALHAFIZASRC";
	public static final String REFNO = "f_REFNO";
	public static final String REGDATE = "f_REGDATE";
	public static final String REFENDDT = "f_REFENDDT";
	public static final String ALHAFIZADT = "f_ALHAFIZADT";
	public static final String DLBATCHDT = "f_DLBATCHDT";
	public static final String REFSTARTDT = "f_REFSTARTDT";
	public static final String REMARKS = "f_REMARKS";
	public static final String APPROVERID = "f_APPROVERID";
	public static final String APPROVED = "f_APPROVED";
	public static final String BORROWERNAME = "f_BORROWERNAME";
	public static final String OUTSTANDINGAMT = "f_OUTSTANDINGAMT";

	public Date getF_DAETHDATE();

	public void setF_DAETHDATE(Date param);

	public int getF_BORROWERNATID();

	public void setF_BORROWERNATID(int param);

	public String getF_REPFULLNAME();

	public void setF_REPFULLNAME(String param);

	public Date getF_ULDT();

	public void setF_ULDT(Date param);

	public String getF_ALHAFIZANO();

	public void setF_ALHAFIZANO(String param);

	public Date getF_APPROVEDDT();

	public void setF_APPROVEDDT(Date param);

	public String getF_LOANPLACE();

	public void setF_LOANPLACE(String param);

	public int getF_DLBATCHNO();

	public void setF_DLBATCHNO(int param);

	public String getF_ULSTATUS();

	public void setF_ULSTATUS(String param);

	public String getF_UPUSERID();

	public void setF_UPUSERID(String param);

	public int getF_REPNATID();

	public void setF_REPNATID(int param);

	public String getF_LOANBR();

	public void setF_LOANBR(String param);

	public String getF_REPCONTACNO();

	public void setF_REPCONTACNO(String param);

	public String getF_REJREASON();

	public void setF_REJREASON(String param);

	public String getF_ALHAFIZASRC();

	public void setF_ALHAFIZASRC(String param);

	public int getF_REFNO();

	public void setF_REFNO(int param);

	public Date getF_REGDATE();

	public void setF_REGDATE(Date param);

	public Date getF_REFENDDT();

	public void setF_REFENDDT(Date param);

	public int getF_ALHAFIZADT();

	public void setF_ALHAFIZADT(int param);

	public Date getF_DLBATCHDT();

	public void setF_DLBATCHDT(Date param);

	public Date getF_REFSTARTDT();

	public void setF_REFSTARTDT(Date param);

	public String getF_REMARKS();

	public void setF_REMARKS(String param);

	public String getF_APPROVERID();

	public void setF_APPROVERID(String param);

	public boolean isF_APPROVED();

	public void setF_APPROVED(boolean param);

	public String getF_BORROWERNAME();

	public void setF_BORROWERNAME(String param);

	public BigDecimal getF_OUTSTANDINGAMT();

	public void setF_OUTSTANDINGAMT(BigDecimal param);

}