package com.trapedza.bankfusion.bo.refimpl;

public interface IBOCE_SIMAHREGULARTAG extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SIMAHREGULARTAG";
	public static final String EXISTSORNEW = "f_EXISTSORNEW";
	public static final String ACCOUNTID = "f_ACCOUNTID";
	public static final String ROWSEQID = "boID";
	public static final String VERSIONNUM = "versionNum";

	public String getF_EXISTSORNEW();

	public void setF_EXISTSORNEW(String param);

	public String getF_ACCOUNTID();

	public void setF_ACCOUNTID(String param);

}