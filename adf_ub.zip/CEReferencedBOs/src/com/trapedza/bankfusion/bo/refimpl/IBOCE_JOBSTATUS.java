package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.sql.Timestamp;

public interface IBOCE_JOBSTATUS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_JOBSTATUS";
	public static final String PRCRECCOUNT = "f_PRCRECCOUNT";
	public static final String USERID = "f_USERID";
	public static final String JOBEXECTIME = "f_JOBEXECTIME";
	public static final String JOBEXECDATE = "f_JOBEXECDATE";
	public static final String JOBEXECID = "boID";
	public static final String VERSIONNUM = "versionNum";
	public static final String STATUSDESC = "f_STATUSDESC";
	public static final String JOBID = "f_JOBID";
	public static final String JOBSTATUS = "f_JOBSTATUS";
	public static final String USERDATE = "f_USERDATE";

	public Integer getF_PRCRECCOUNT();

	public void setF_PRCRECCOUNT(Integer param);

	public String getF_USERID();

	public void setF_USERID(String param);

	public Timestamp getF_JOBEXECTIME();

	public void setF_JOBEXECTIME(Timestamp param);

	public Date getF_JOBEXECDATE();

	public void setF_JOBEXECDATE(Date param);

	public String getF_STATUSDESC();

	public void setF_STATUSDESC(String param);

	public String getF_JOBID();

	public void setF_JOBID(String param);

	public String getF_JOBSTATUS();

	public void setF_JOBSTATUS(String param);

	public Date getF_USERDATE();

	public void setF_USERDATE(Date param);

}