package com.trapedza.bankfusion.bo.refimpl;

public interface IBOCE_SubsisidyTag extends
		com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SubsisidyTag";
	public static final String ROWSEQ = "boID";
	public static final String REPAYMENTID = "f_REPAYMENTID";
	public static final String VERSIONNUM = "versionNum";

	public String getF_REPAYMENTID();

	public void setF_REPAYMENTID(String param);

}