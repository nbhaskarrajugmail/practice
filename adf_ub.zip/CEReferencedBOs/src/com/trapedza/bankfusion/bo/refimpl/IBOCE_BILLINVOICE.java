
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Date;

public interface IBOCE_BILLINVOICE extends com.trapedza.bankfusion.core.SimplePersistentObject {

    public static final String BONAME = "CE_BILLINVOICE";

    public static final String NSTATUSCODE = "f_NSTATUSCODE";

    public static final String BILLLASTUPDATEDATE = "f_BILLLASTUPDATEDATE";

    public static final String FLAG = "f_FLAG";

    public static final String VERSIONNUM = "versionNum";

    public static final String BILLDUEDATE = "f_BILLDUEDATE";

    public static final String BILLEXPDATE = "f_BILLEXPDATE";

    public static final String REQUESTKEY = "f_REQUESTKEY";

    public static final String NDATE = "f_NDATE";

    public static final String BILLSTATUS = "f_BILLSTATUS";

    public static final String ID = "boID";

    public static final String BILLACTION = "f_BILLACTION";

    public static final String BILLINVOICENO = "f_BILLINVOICENO";

    public static final String BILLCYCLE = "f_BILLCYCLE";

    public static final String BILLACCT = "f_BILLACCT";

    public static final String BILLVATAMT = "f_BILLVATAMT";

    public static final String BILLAMT = "f_BILLAMT";

    public static final String NSTATUSDESC = "f_NSTATUSDESC";

    public static final String BILLCATEGORY = "f_BILLCATEGORY";

    public static final String BILLGENDATE = "f_BILLGENDATE";

    public String getF_NSTATUSCODE();

    public void setF_NSTATUSCODE(String param);

    public Date getF_BILLLASTUPDATEDATE();

    public void setF_BILLLASTUPDATEDATE(Date param);

    public String getF_FLAG();

    public void setF_FLAG(String param);

    public Date getF_BILLDUEDATE();

    public void setF_BILLDUEDATE(Date param);

    public Date getF_BILLEXPDATE();

    public void setF_BILLEXPDATE(Date param);

    public String getF_REQUESTKEY();

    public void setF_REQUESTKEY(String param);

    public Timestamp getF_NDATE();

    public void setF_NDATE(Timestamp param);

    public String getF_BILLSTATUS();

    public void setF_BILLSTATUS(String param);

    public String getF_BILLACTION();

    public void setF_BILLACTION(String param);

    public String getF_BILLINVOICENO();

    public void setF_BILLINVOICENO(String param);

    public Integer getF_BILLCYCLE();

    public void setF_BILLCYCLE(Integer param);

    public String getF_BILLACCT();

    public void setF_BILLACCT(String param);

    public BigDecimal getF_BILLVATAMT();

    public void setF_BILLVATAMT(BigDecimal param);

    public BigDecimal getF_BILLAMT();

    public void setF_BILLAMT(BigDecimal param);

    public String getF_NSTATUSDESC();

    public void setF_NSTATUSDESC(String param);

    public String getF_BILLCATEGORY();

    public void setF_BILLCATEGORY(String param);

    public Date getF_BILLGENDATE();

    public void setF_BILLGENDATE(Date param);

}