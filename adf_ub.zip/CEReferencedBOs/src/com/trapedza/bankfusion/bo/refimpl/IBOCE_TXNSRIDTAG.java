package com.trapedza.bankfusion.bo.refimpl;

public interface IBOCE_TXNSRIDTAG extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_TXNSRIDTAG";
	public static final String ROWSEQ = "boID";
	public static final String TRANSACTIONSRID = "f_TRANSACTIONSRID";
	public static final String VERSIONNUM = "versionNum";

	public String getF_TRANSACTIONSRID();

	public void setF_TRANSACTIONSRID(String param);

}