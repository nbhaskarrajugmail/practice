
package com.trapedza.bankfusion.bo.refimpl;

public interface IBOCE_SIMAHACCOUNTMAP extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SIMAHACCOUNTMAP";
	public static final String SRCACCTNO = "f_SRCACCTNO";
	public static final String TARACCTNO = "boID";
	public static final String PARTYTYPE = "f_PARTYTYPE";
	public static final String VERSIONNUM = "versionNum";

	public String getF_SRCACCTNO();

	public void setF_SRCACCTNO(String param);

	public String getF_PARTYTYPE();

	public void setF_PARTYTYPE(String param);

}