package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_IB_PaymentSchBreakup extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_IB_PaymentSchBreakup";
	public static final String SUBSIDYAMTPAID = "f_SUBSIDYAMTPAID";
	public static final String PRINCIPALAMT = "f_PRINCIPALAMT";
	public static final String SUBSIDYAMNT = "f_SUBSIDYAMNT";
	public static final String BILLDATE = "f_BILLDATE";
	public static final String ASSETID = "f_ASSETID";
	public static final String VERSIONNUM = "versionNum";
	public static final String PAYMENTSCHBREAKUPID = "boID";
	public static final String DEALID = "f_DEALID";
	public static final String PRINCIPALAMTPAID = "f_PRINCIPALAMTPAID";

	public BigDecimal getF_SUBSIDYAMTPAID();

	public void setF_SUBSIDYAMTPAID(BigDecimal param);

	public BigDecimal getF_PRINCIPALAMT();

	public void setF_PRINCIPALAMT(BigDecimal param);

	public BigDecimal getF_SUBSIDYAMNT();

	public void setF_SUBSIDYAMNT(BigDecimal param);

	public Date getF_BILLDATE();

	public void setF_BILLDATE(Date param);

	public String getF_ASSETID();

	public void setF_ASSETID(String param);

	public String getF_DEALID();

	public void setF_DEALID(String param);

	public BigDecimal getF_PRINCIPALAMTPAID();

	public void setF_PRINCIPALAMTPAID(BigDecimal param);

}