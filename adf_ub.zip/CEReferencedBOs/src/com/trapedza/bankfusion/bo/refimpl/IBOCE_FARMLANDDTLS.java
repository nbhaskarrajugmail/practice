
package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Timestamp;
import java.sql.Date;

public interface IBOCE_FARMLANDDTLS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_FARMLANDDTLS";
	public static final String FARMNAME = "f_FARMNAME";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String TITLEDEEDID = "boID";
	public static final String IRGSRC = "f_IRGSRC";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String ENGOFFNAME = "f_ENGOFFNAME";
	public static final String ENGOFFDATE = "f_ENGOFFDATE";
	public static final String CONTRACTNUMBER = "f_CONTRACTNUMBER";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String OWNERNAME = "f_OWNERNAME";
	public static final String CONTRACTSRC = "f_CONTRACTSRC";
	public static final String CONTRACTDATE = "f_CONTRACTDATE";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";

	public String getF_FARMNAME();

	public void setF_FARMNAME(String param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public String getF_IRGSRC();

	public void setF_IRGSRC(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public String getF_ENGOFFNAME();

	public void setF_ENGOFFNAME(String param);

	public Date getF_ENGOFFDATE();

	public void setF_ENGOFFDATE(Date param);

	public String getF_CONTRACTNUMBER();

	public void setF_CONTRACTNUMBER(String param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_OWNERNAME();

	public void setF_OWNERNAME(String param);

	public String getF_CONTRACTSRC();

	public void setF_CONTRACTSRC(String param);

	public Date getF_CONTRACTDATE();

	public void setF_CONTRACTDATE(Date param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

}