package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Timestamp;

public interface IBOCE_BILLACCT extends
		com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_BILLACCT";
	public static final String BILLACCTNO = "boID";
	public static final String REGSTATUSCODE = "f_REGSTATUSCODE";
	public static final String REGSTATUSDESC = "f_REGSTATUSDESC";
	public static final String REQDATE = "f_REQDATE";
	public static final String VERSIONNUM = "versionNum";

	public String getF_REGSTATUSCODE();

	public void setF_REGSTATUSCODE(String param);

	public String getF_REGSTATUSDESC();

	public void setF_REGSTATUSDESC(String param);

	public Timestamp getF_REQDATE();

	public void setF_REQDATE(Timestamp param);

}