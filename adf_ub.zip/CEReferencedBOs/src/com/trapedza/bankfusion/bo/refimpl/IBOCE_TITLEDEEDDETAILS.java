
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Date;

public interface IBOCE_TITLEDEEDDETAILS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_TITLEDEEDDETAILS";
	public static final String TITLEDEEDSTATUS = "f_TITLEDEEDSTATUS";
	public static final String TRANSACTIONTYPE = "f_TRANSACTIONTYPE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String VALIDTO = "f_VALIDTO";
	public static final String VERSIONNUM = "versionNum";
	public static final String NOTES = "f_NOTES";
	public static final String VALIDTOHIJRI = "f_VALIDTOHIJRI";
	public static final String NOTESFORAMEND = "f_NOTESFORAMEND";
	public static final String LINKEDTOCOLLATERAL = "f_LINKEDTOCOLLATERAL";
	public static final String STATUS = "f_STATUS";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";
	public static final String TITLEDEEDYEAR = "f_TITLEDEEDYEAR";
	public static final String BRANCHSORTCODE = "f_BRANCHSORTCODE";
	public static final String TITLEDEEDNUMBER = "f_TITLEDEEDNUMBER";
	public static final String RETAILINDEX = "f_RETAILINDEX";
	public static final String VALIDFROMHIJRI = "f_VALIDFROMHIJRI";
	public static final String REASONFORCHANGE = "f_REASONFORCHANGE";
	public static final String LANDPLOTNUMBER = "f_LANDPLOTNUMBER";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String DICISSIONSTATUS = "f_DICISSIONSTATUS";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String TRANSACTIONDATE = "f_TRANSACTIONDATE";
	public static final String VALIDFROM = "f_VALIDFROM";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String FARMLOCATION = "f_FARMLOCATION";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String SPLITINDICATOR = "f_SPLITINDICATOR";
	public static final String LANDPLANNUMBER = "f_LANDPLANNUMBER";
	public static final String TITLEDEEDSOURCE = "f_TITLEDEEDSOURCE";
	public static final String AREASIZE = "f_AREASIZE";
	public static final String TITLEDEEDTYPE = "f_TITLEDEEDTYPE";
	public static final String compositeCol = "CompositeBoid";
	public static final String TITLEDEEDVERSIONPK = "CE_TITLEDEEDDETAILSID.f_TITLEDEEDVERSION";
	public static final String TITLEDEEDIDPK = "CE_TITLEDEEDDETAILSID.f_TITLEDEEDID";

	public String getF_TITLEDEEDSTATUS();

	public void setF_TITLEDEEDSTATUS(String param);

	public String getF_TRANSACTIONTYPE();

	public void setF_TRANSACTIONTYPE(String param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public Date getF_VALIDTO();

	public void setF_VALIDTO(Date param);

	public String getF_NOTES();

	public void setF_NOTES(String param);

	public String getF_VALIDTOHIJRI();

	public void setF_VALIDTOHIJRI(String param);

	public String getF_NOTESFORAMEND();

	public void setF_NOTESFORAMEND(String param);

	public String getF_LINKEDTOCOLLATERAL();

	public void setF_LINKEDTOCOLLATERAL(String param);

	public String getF_STATUS();

	public void setF_STATUS(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

	public Integer getF_TITLEDEEDYEAR();

	public void setF_TITLEDEEDYEAR(Integer param);

	public String getF_BRANCHSORTCODE();

	public void setF_BRANCHSORTCODE(String param);

	public String getF_TITLEDEEDNUMBER();

	public void setF_TITLEDEEDNUMBER(String param);

	public String getF_RETAILINDEX();

	public void setF_RETAILINDEX(String param);

	public String getF_VALIDFROMHIJRI();

	public void setF_VALIDFROMHIJRI(String param);

	public String getF_REASONFORCHANGE();

	public void setF_REASONFORCHANGE(String param);

	public String getF_LANDPLOTNUMBER();

	public void setF_LANDPLOTNUMBER(String param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_DICISSIONSTATUS();

	public void setF_DICISSIONSTATUS(String param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Date getF_TRANSACTIONDATE();

	public void setF_TRANSACTIONDATE(Date param);

	public Date getF_VALIDFROM();

	public void setF_VALIDFROM(Date param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_FARMLOCATION();

	public void setF_FARMLOCATION(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public String getF_SPLITINDICATOR();

	public void setF_SPLITINDICATOR(String param);

	public String getF_LANDPLANNUMBER();

	public void setF_LANDPLANNUMBER(String param);

	public String getF_TITLEDEEDSOURCE();

	public void setF_TITLEDEEDSOURCE(String param);

	public BigDecimal getF_AREASIZE();

	public void setF_AREASIZE(BigDecimal param);

	public String getF_TITLEDEEDTYPE();

	public void setF_TITLEDEEDTYPE(String param);

	public Object getCE_TITLEDEEDDETAILSID();

	public void setCE_TITLEDEEDDETAILSID(Object param);

}