package com.trapedza.bankfusion.bo.refimpl;

import java.sql.Date;
import java.math.BigDecimal;

public interface IBOCE_SIMHAENTMSG extends
		com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_SIMHAENTMSG";
	public static final String REDUCINGPRINCIPAL = "f_REDUCINGPRINCIPAL";
	public static final String securityType = "f_securityType";
	public static final String installmentAmt = "f_installmentAmt";
	public static final String VERSIONNUM = "versionNum";
	public static final String GAURANTOR = "f_GAURANTOR";
	public static final String PRODUCTTYPE = "f_PRODUCTTYPE";
	public static final String closeDate = "f_closeDate";
	public static final String repaymentPeriod = "f_repaymentPeriod";
	public static final String LOANSTARTDATE = "f_LOANSTARTDATE";
	public static final String LOANACCNO = "boID";
	public static final String PRODUCTSTATUS = "f_PRODUCTSTATUS";
	public static final String PAYMENTSTATUS = "f_PAYMENTSTATUS";

	public BigDecimal getF_REDUCINGPRINCIPAL();

	public void setF_REDUCINGPRINCIPAL(BigDecimal param);

	public String getF_securityType();

	public void setF_securityType(String param);

	public BigDecimal getF_installmentAmt();

	public void setF_installmentAmt(BigDecimal param);

	public String getF_GAURANTOR();

	public void setF_GAURANTOR(String param);

	public String getF_PRODUCTTYPE();

	public void setF_PRODUCTTYPE(String param);

	public Date getF_closeDate();

	public void setF_closeDate(Date param);

	public int getF_repaymentPeriod();

	public void setF_repaymentPeriod(int param);

	public Date getF_LOANSTARTDATE();

	public void setF_LOANSTARTDATE(Date param);

	public String getF_PRODUCTSTATUS();

	public void setF_PRODUCTSTATUS(String param);

	public String getF_PAYMENTSTATUS();

	public void setF_PAYMENTSTATUS(String param);

}