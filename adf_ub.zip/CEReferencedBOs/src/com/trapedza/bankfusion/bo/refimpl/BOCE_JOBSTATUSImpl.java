
package com.trapedza.bankfusion.bo.refimpl;

import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.FieldChangeHelper;
import com.trapedza.bankfusion.core.MetaDataEnum;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;
import com.trapedza.bankfusion.bo.config.RuntimeBOMethod;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Timestamp;
import java.sql.Date;

public class BOCE_JOBSTATUSImpl extends com.trapedza.bankfusion.core.SimplePersistentObjectImpl
		implements IBOCE_JOBSTATUS {
	private String f_JOBSTATUS = CommonConstants.EMPTY_STRING;

	private String f_USERID = CommonConstants.EMPTY_STRING;

	private Integer f_PRCRECCOUNT = null;

	private String f_STATUSDESC = CommonConstants.EMPTY_STRING;

	private Timestamp f_JOBEXECTIME = new Timestamp(0L);

	private Date f_USERDATE = new Date(0L);

	private String f_JOBID = CommonConstants.EMPTY_STRING;

	private Date f_JOBEXECDATE = new Date(0L);

	public String getF_JOBSTATUS() {

		return f_JOBSTATUS;
	}

	public void setF_JOBSTATUS(String param) {
		FieldChangeHelper.setFieldValue(this, "f_JOBSTATUS", f_JOBSTATUS, param);
		f_JOBSTATUS = param;
	}

	public String getF_USERID() {

		return f_USERID;
	}

	public void setF_USERID(String param) {
		FieldChangeHelper.setFieldValue(this, "f_USERID", f_USERID, param);
		f_USERID = param;
	}

	public Integer getF_PRCRECCOUNT() {

		return f_PRCRECCOUNT;
	}

	public void setF_PRCRECCOUNT(Integer param) {
		FieldChangeHelper.setFieldValue(this, "f_PRCRECCOUNT", f_PRCRECCOUNT, param);
		f_PRCRECCOUNT = param;
	}

	public String getF_STATUSDESC() {

		return f_STATUSDESC;
	}

	public void setF_STATUSDESC(String param) {
		FieldChangeHelper.setFieldValue(this, "f_STATUSDESC", f_STATUSDESC, param);
		f_STATUSDESC = param;
	}

	public Timestamp getF_JOBEXECTIME() {

		return f_JOBEXECTIME;
	}

	public void setF_JOBEXECTIME(Timestamp param) {
		FieldChangeHelper.setFieldValue(this, "f_JOBEXECTIME", f_JOBEXECTIME, param);
		f_JOBEXECTIME = param;
	}

	public Date getF_USERDATE() {

		return f_USERDATE;
	}

	public void setF_USERDATE(Date param) {
		FieldChangeHelper.setFieldValue(this, "f_USERDATE", f_USERDATE, param);
		f_USERDATE = param;
	}

	public String getF_JOBID() {

		return f_JOBID;
	}

	public void setF_JOBID(String param) {
		FieldChangeHelper.setFieldValue(this, "f_JOBID", f_JOBID, param);
		f_JOBID = param;
	}

	public Date getF_JOBEXECDATE() {

		return f_JOBEXECDATE;
	}

	public void setF_JOBEXECDATE(Date param) {
		FieldChangeHelper.setFieldValue(this, "f_JOBEXECDATE", f_JOBEXECDATE, param);
		f_JOBEXECDATE = param;
	}

	public String getF_JOBEXECID() {
		return getBoID();
	}

	public void setF_JOBEXECID(String param) {
		setBoID(param);
	}

	public String getBOName() {
		return IBOCE_JOBSTATUS.BONAME;
	}

	public Map getFinderMethods() {
		Map finderMethods = super.getFinderMethods();
		return finderMethods;
	}

	public RuntimeBOMethod getFinderMethod(String methodName) {
		return (RuntimeBOMethod) super.getFinderMethods().get(methodName);
	}

	public Map getDataMap() {
		Map dataMap = super.getDataMap();
		dataMap.put(IBOCE_JOBSTATUS.JOBSTATUS, f_JOBSTATUS);
		dataMap.put(IBOCE_JOBSTATUS.USERID, f_USERID);
		dataMap.put(IBOCE_JOBSTATUS.PRCRECCOUNT, f_PRCRECCOUNT);
		dataMap.put(IBOCE_JOBSTATUS.STATUSDESC, f_STATUSDESC);
		dataMap.put(IBOCE_JOBSTATUS.JOBEXECTIME, f_JOBEXECTIME);
		dataMap.put(IBOCE_JOBSTATUS.USERDATE, f_USERDATE);
		dataMap.put(IBOCE_JOBSTATUS.JOBID, f_JOBID);
		dataMap.put(IBOCE_JOBSTATUS.JOBEXECDATE, f_JOBEXECDATE);
		dataMap.put(IBOCE_JOBSTATUS.JOBEXECID, getBoID());
		return dataMap;
	}

	public void updateFromMap(Map dataMap) throws BankFusionException {
		if (dataMap.containsKey(IBOCE_JOBSTATUS.JOBSTATUS))
			setF_JOBSTATUS(getSTRINGValue(dataMap.get(IBOCE_JOBSTATUS.JOBSTATUS)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.USERID))
			setF_USERID(getSTRINGValue(dataMap.get(IBOCE_JOBSTATUS.USERID)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.PRCRECCOUNT))
			setF_PRCRECCOUNT(getINTEGERWrapperValue(dataMap.get(IBOCE_JOBSTATUS.PRCRECCOUNT)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.STATUSDESC))
			setF_STATUSDESC(getSTRINGValue(dataMap.get(IBOCE_JOBSTATUS.STATUSDESC)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.JOBEXECTIME))
			setF_JOBEXECTIME(getTIMESTAMPValue(dataMap.get(IBOCE_JOBSTATUS.JOBEXECTIME)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.USERDATE))
			setF_USERDATE(getDATEValue(dataMap.get(IBOCE_JOBSTATUS.USERDATE)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.JOBID))
			setF_JOBID(getSTRINGValue(dataMap.get(IBOCE_JOBSTATUS.JOBID)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.JOBEXECDATE))
			setF_JOBEXECDATE(getDATEValue(dataMap.get(IBOCE_JOBSTATUS.JOBEXECDATE)));

		if (dataMap.containsKey(IBOCE_JOBSTATUS.JOBEXECID)) {
			setBoID(getSTRINGValue(dataMap.get(IBOCE_JOBSTATUS.JOBEXECID)));
		} else if (dataMap.containsKey("f_JOBEXECID")) {
			setBoID(getSTRINGValue(dataMap.get("f_JOBEXECID")));
		}

	}
}