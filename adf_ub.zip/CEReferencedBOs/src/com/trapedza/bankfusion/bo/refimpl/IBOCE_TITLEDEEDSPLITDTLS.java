
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface IBOCE_TITLEDEEDSPLITDTLS extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_TITLEDEEDSPLITDTLS";
	public static final String PERCENTAGE = "f_PERCENTAGE";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String SPLITTITLEDEEDID = "boID";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String TITLEDEEDSOURCE = "f_TITLEDEEDSOURCE";
	public static final String TITLEDEEDID = "f_TITLEDEEDID";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String VERSIONNUM = "versionNum";
	public static final String TITLEDEEDNUMBER = "f_TITLEDEEDNUMBER";
	public static final String TITLEDEEDPLOTNUMBER = "f_TITLEDEEDPLOTNUMBER";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String TITLEDEEDPLANNUMBER = "f_TITLEDEEDPLANNUMBER";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String TITLEDEEDTYPE = "f_TITLEDEEDTYPE";
	public static final String TITLEDEEDYEAR = "f_TITLEDEEDYEAR";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";

	public BigDecimal getF_PERCENTAGE();

	public void setF_PERCENTAGE(BigDecimal param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public String getF_TITLEDEEDSOURCE();

	public void setF_TITLEDEEDSOURCE(String param);

	public String getF_TITLEDEEDID();

	public void setF_TITLEDEEDID(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public String getF_TITLEDEEDNUMBER();

	public void setF_TITLEDEEDNUMBER(String param);

	public String getF_TITLEDEEDPLOTNUMBER();

	public void setF_TITLEDEEDPLOTNUMBER(String param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_TITLEDEEDPLANNUMBER();

	public void setF_TITLEDEEDPLANNUMBER(String param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public String getF_TITLEDEEDTYPE();

	public void setF_TITLEDEEDTYPE(String param);

	public Integer getF_TITLEDEEDYEAR();

	public void setF_TITLEDEEDYEAR(Integer param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

}