
package com.trapedza.bankfusion.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Timestamp;

public interface IBOCE_BATCHFILEDETAIL extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_BATCHFILEDETAIL";
	public static final String AMNTTOPROCESS = "f_AMNTTOPROCESS";
	public static final String RECCREATEDBY = "f_RECCREATEDBY";
	public static final String BANKID = "f_BANKID";
	public static final String VERSIONNUM = "versionNum";
	public static final String STATUS = "f_STATUS";
	public static final String RECLASTMODIFIEDBY = "f_RECLASTMODIFIEDBY";
	public static final String BATCHDES = "f_BATCHDES";
	public static final String ISLOADED = "f_ISLOADED";
	public static final String BATCHREF = "f_BATCHREF";
	public static final String INTERNALACC = "f_INTERNALACC";
	public static final String RECSYSDATE = "f_RECSYSDATE";
	public static final String RECAPPROVEDBY = "f_RECAPPROVEDBY";
	public static final String RECCREATEDON = "f_RECCREATEDON";
	public static final String RECLASTMODIFIEDDATE = "f_RECLASTMODIFIEDDATE";
	public static final String FILENAME = "f_FILENAME";
	public static final String RECAPPROVEDDATE = "f_RECAPPROVEDDATE";
	public static final String FILEID = "boID";
	public static final String TXNTYPE = "f_TXNTYPE";

	public BigDecimal getF_AMNTTOPROCESS();

	public void setF_AMNTTOPROCESS(BigDecimal param);

	public String getF_RECCREATEDBY();

	public void setF_RECCREATEDBY(String param);

	public String getF_BANKID();

	public void setF_BANKID(String param);

	public String getF_STATUS();

	public void setF_STATUS(String param);

	public String getF_RECLASTMODIFIEDBY();

	public void setF_RECLASTMODIFIEDBY(String param);

	public String getF_BATCHDES();

	public void setF_BATCHDES(String param);

	public boolean isF_ISLOADED();

	public void setF_ISLOADED(boolean param);

	public String getF_BATCHREF();

	public void setF_BATCHREF(String param);

	public String getF_INTERNALACC();

	public void setF_INTERNALACC(String param);

	public Timestamp getF_RECSYSDATE();

	public void setF_RECSYSDATE(Timestamp param);

	public String getF_RECAPPROVEDBY();

	public void setF_RECAPPROVEDBY(String param);

	public Timestamp getF_RECCREATEDON();

	public void setF_RECCREATEDON(Timestamp param);

	public Timestamp getF_RECLASTMODIFIEDDATE();

	public void setF_RECLASTMODIFIEDDATE(Timestamp param);

	public String getF_FILENAME();

	public void setF_FILENAME(String param);

	public Timestamp getF_RECAPPROVEDDATE();

	public void setF_RECAPPROVEDDATE(Timestamp param);

	public String getF_TXNTYPE();

	public void setF_TXNTYPE(String param);

}