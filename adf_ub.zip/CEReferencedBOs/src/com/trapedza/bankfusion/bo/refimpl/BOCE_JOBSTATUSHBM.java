
package com.trapedza.bankfusion.bo.refimpl;

import org.hibernate.mapping.Property;
import com.trapedza.bankfusion.persistence.hibernatesupport.MetaConfigurator;

public class BOCE_JOBSTATUSHBM extends MetaConfigurator {
	public String getClassName() {
		return "com.trapedza.bankfusion.bo.refimpl.BOCE_JOBSTATUSImpl";
	}

	public String getBOName() {
		return IBOCE_JOBSTATUS.BONAME;
	}

	public String getTableName() {
		return "CUSTOMEXTN.CETB_JOBSTATUS";
	}

	public void addAllColumns() {

		Property prop = null;

		prop = addColumn("CEPRCRECCOUNT", DATATYPE_INTEGER_JTYPE, false, IBOCE_JOBSTATUS.PRCRECCOUNT, true);
		prop = addColumn("CEUSERID", DATATYPE_STRING_JTYPE, false, IBOCE_JOBSTATUS.USERID, true);
		prop = addColumn("CEJOBEXECTIME", DATATYPE_TIMESTAMP_JTYPE, false, IBOCE_JOBSTATUS.JOBEXECTIME, true);
		prop = addColumn("CEJOBEXECDATE", DATATYPE_DATE_JTYPE, false, IBOCE_JOBSTATUS.JOBEXECDATE, true);
		prop = addColumn("VERSIONNUM", DATATYPE_INTEGER_JTYPE, false, IBOCE_JOBSTATUS.VERSIONNUM);
		versionNumSet = true;
		addVersionColumn(prop);
		prop = addColumn("CESTATUSDESC", DATATYPE_STRING_JTYPE, false, IBOCE_JOBSTATUS.STATUSDESC, true);
		prop = addColumn("CEJOBID", DATATYPE_STRING_JTYPE, false, IBOCE_JOBSTATUS.JOBID, true);
		prop = addColumn("CEJOBSTATUS", DATATYPE_STRING_JTYPE, false, IBOCE_JOBSTATUS.JOBSTATUS, true);
		prop = addColumn("CEUSERDATE", DATATYPE_DATE_JTYPE, false, IBOCE_JOBSTATUS.USERDATE, true);
	}

	public String getBOID() {
		return "CEJOBEXECIDPK";
	}
}