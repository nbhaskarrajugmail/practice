
package com.trapedza.bankfusion.steps.refimpl;

import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_PTY_ReadAllActiveTitleDeed implements ICE_PTY_ReadAllActiveTitleDeed,
		com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PTY_ReadAllActiveTitleDeed(BankFusionEnvironment env) {
	}

	public AbstractCE_PTY_ReadAllActiveTitleDeed() {
	}

	private Boolean f_IN_FetchAllTitleDeeds = Boolean.FALSE;

	private String f_IN_TitleDeedNumber = CommonConstants.EMPTY_STRING;

	private bf.com.misys.bankfusion.attributes.PagedQuery f_IN_PagedQuery = new bf.com.misys.bankfusion.attributes.PagedQuery();
	{
		bf.com.misys.bankfusion.attributes.PagingRequest var_019_PagedQuery_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_019_PagedQuery_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_019_PagedQuery_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_019_PagedQuery_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		f_IN_PagedQuery.setPagingRequest(var_019_PagedQuery_PagingRequest);

		f_IN_PagedQuery.setQueryData(CommonConstants.EMPTY_STRING);
	}
	private com.misys.ce.types.SearchTitleDeedDtlsRqType f_IN_SearchTitleDeedDtlsRq = new com.misys.ce.types.SearchTitleDeedDtlsRqType();
	{
		f_IN_SearchTitleDeedDtlsRq.setTitleDeedId(CommonConstants.EMPTY_STRING);
		bf.com.misys.bankfusion.attributes.PagedQuery var_019_SearchTitleDeedDtlsRq_pagingInfo = new bf.com.misys.bankfusion.attributes.PagedQuery();

		bf.com.misys.bankfusion.attributes.PagingRequest var_019_SearchTitleDeedDtlsRq_pagingInfo_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_019_SearchTitleDeedDtlsRq_pagingInfo_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_019_SearchTitleDeedDtlsRq_pagingInfo_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_019_SearchTitleDeedDtlsRq_pagingInfo_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		var_019_SearchTitleDeedDtlsRq_pagingInfo
				.setPagingRequest(var_019_SearchTitleDeedDtlsRq_pagingInfo_PagingRequest);

		var_019_SearchTitleDeedDtlsRq_pagingInfo.setQueryData(CommonConstants.EMPTY_STRING);
		f_IN_SearchTitleDeedDtlsRq.setPagingInfo(var_019_SearchTitleDeedDtlsRq_pagingInfo);

		f_IN_SearchTitleDeedDtlsRq.setPartyId(CommonConstants.EMPTY_STRING);
	}
	private String f_IN_PAGINGSUPPORT = "Y";
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.SearchTitleDeedDtlsRsType f_OUT_SearchTitleDeedDtlsRs = new com.misys.ce.types.SearchTitleDeedDtlsRsType();
	{
		com.misys.ce.types.ListTitleDeedIdDtlsType var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls = new com.misys.ce.types.ListTitleDeedIdDtlsType();

		com.misys.ce.types.TitleDeedDetailsType var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setBranchShortCode(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setFarmLocationDescription(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls.addTitleDeedDetails(0,
				var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails);

		f_OUT_SearchTitleDeedDtlsRs.setListTitleDeedIdDtls(var_020_SearchTitleDeedDtlsRs_listTitleDeedIdDtls);

		bf.com.misys.bankfusion.attributes.PagedQuery var_020_SearchTitleDeedDtlsRs_pagingInfo = new bf.com.misys.bankfusion.attributes.PagedQuery();

		bf.com.misys.bankfusion.attributes.PagingRequest var_020_SearchTitleDeedDtlsRs_pagingInfo_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_020_SearchTitleDeedDtlsRs_pagingInfo_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_020_SearchTitleDeedDtlsRs_pagingInfo_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_020_SearchTitleDeedDtlsRs_pagingInfo_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		var_020_SearchTitleDeedDtlsRs_pagingInfo
				.setPagingRequest(var_020_SearchTitleDeedDtlsRs_pagingInfo_PagingRequest);

		var_020_SearchTitleDeedDtlsRs_pagingInfo.setQueryData(CommonConstants.EMPTY_STRING);
		f_OUT_SearchTitleDeedDtlsRs.setPagingInfo(var_020_SearchTitleDeedDtlsRs_pagingInfo);
	}
	private Object f_OUT_PaginatedData = new String();

	private PagingHelper pagingHelper = new PagingHelper(this);

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Boolean isF_IN_FetchAllTitleDeeds() {
		return f_IN_FetchAllTitleDeeds;
	}

	public void setF_IN_FetchAllTitleDeeds(Boolean param) {
		f_IN_FetchAllTitleDeeds = param;
	}

	public String getF_IN_TitleDeedNumber() {
		return f_IN_TitleDeedNumber;
	}

	public void setF_IN_TitleDeedNumber(String param) {
		f_IN_TitleDeedNumber = param;
	}

	public bf.com.misys.bankfusion.attributes.PagedQuery getF_IN_PagedQuery() {
		return f_IN_PagedQuery;
	}

	public void setF_IN_PagedQuery(bf.com.misys.bankfusion.attributes.PagedQuery param) {
		f_IN_PagedQuery = param;
	}

	public com.misys.ce.types.SearchTitleDeedDtlsRqType getF_IN_SearchTitleDeedDtlsRq() {
		return f_IN_SearchTitleDeedDtlsRq;
	}

	public void setF_IN_SearchTitleDeedDtlsRq(com.misys.ce.types.SearchTitleDeedDtlsRqType param) {
		f_IN_SearchTitleDeedDtlsRq = param;
	}

	public String getF_IN_PAGINGSUPPORT() {
		return f_IN_PAGINGSUPPORT;
	}

	public void setF_IN_PAGINGSUPPORT(String param) {
		f_IN_PAGINGSUPPORT = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_FetchAllTitleDeeds, f_IN_FetchAllTitleDeeds);
		dataInMap.put(IN_TitleDeedNumber, f_IN_TitleDeedNumber);
		dataInMap.put(IN_PagedQuery, f_IN_PagedQuery);
		dataInMap.put(IN_SearchTitleDeedDtlsRq, f_IN_SearchTitleDeedDtlsRq);
		dataInMap.put(IN_PAGINGSUPPORT, f_IN_PAGINGSUPPORT);
		return dataInMap;
	}

	public com.misys.ce.types.SearchTitleDeedDtlsRsType getF_OUT_SearchTitleDeedDtlsRs() {
		return f_OUT_SearchTitleDeedDtlsRs;
	}

	public void setF_OUT_SearchTitleDeedDtlsRs(com.misys.ce.types.SearchTitleDeedDtlsRsType param) {
		f_OUT_SearchTitleDeedDtlsRs = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Object getF_OUT_PaginatedData() {
		return f_OUT_PaginatedData;
	}

	public void setF_OUT_PaginatedData(Object param) {
		f_OUT_PaginatedData = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_SearchTitleDeedDtlsRs, f_OUT_SearchTitleDeedDtlsRs);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_PaginatedData, f_OUT_PaginatedData);
		return dataOutMap;
	}

	public PagingHelper getPagingHelper() {
		return pagingHelper;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = new ActivityStepPagingState(this);
		return (pagingState);
	}

	public Object processPagingState(BankFusionEnvironment bankfusionenvironment,
			ActivityStepPagingState activitysteppagingstate, Map map) {
		return null;
	}

	public String getResourceID() {
		return "CE_PTY_ReadAllActiveTitleDeed";
	}

}