package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_BillInvoiceReqBuilder implements
		ICE_BillInvoiceReqBuilder {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_BillInvoiceReqBuilder(BankFusionEnvironment env) {
	}

	public AbstractCE_BillInvoiceReqBuilder() {
	}

	private bf.com.misys.types.sadad.notification.BillInvoiceDtlRq f_IN_BillInvoiceRq = new bf.com.misys.types.sadad.notification.BillInvoiceDtlRq();
	{
		bf.com.misys.types.sadad.notification.BillInvoiceRq var_019_BillInvoiceRq_billInvoiceDtlRq = new bf.com.misys.types.sadad.notification.BillInvoiceRq();

		var_019_BillInvoiceRq_billInvoiceDtlRq
				.setStatusCode(CommonConstants.EMPTY_STRING);
		var_019_BillInvoiceRq_billInvoiceDtlRq
				.setBillInvoiceNo(CommonConstants.EMPTY_STRING);
		var_019_BillInvoiceRq_billInvoiceDtlRq
				.setStatusDesc(CommonConstants.EMPTY_STRING);
		var_019_BillInvoiceRq_billInvoiceDtlRq
				.setBillAcctNo(CommonConstants.EMPTY_STRING);
		f_IN_BillInvoiceRq.addBillInvoiceDtlRq(0,
				var_019_BillInvoiceRq_billInvoiceDtlRq);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private bf.com.misys.types.sadad.notification.BillInvoiceDtlRs f_OUT_BillInvoiceRs = new bf.com.misys.types.sadad.notification.BillInvoiceDtlRs();
	{
		bf.com.misys.types.sadad.notification.BillInvoiceRs var_020_BillInvoiceRs_billInvoiceDtlRs = new bf.com.misys.types.sadad.notification.BillInvoiceRs();

		var_020_BillInvoiceRs_billInvoiceDtlRs
				.setStatusCode(CommonConstants.EMPTY_STRING);
		var_020_BillInvoiceRs_billInvoiceDtlRs
				.setStatusDesc(CommonConstants.EMPTY_STRING);
		f_OUT_BillInvoiceRs.addBillInvoiceDtlRs(0,
				var_020_BillInvoiceRs_billInvoiceDtlRs);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.com.misys.types.sadad.notification.BillInvoiceDtlRq getF_IN_BillInvoiceRq() {
		return f_IN_BillInvoiceRq;
	}

	public void setF_IN_BillInvoiceRq(
			bf.com.misys.types.sadad.notification.BillInvoiceDtlRq param) {
		f_IN_BillInvoiceRq = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_BillInvoiceRq, f_IN_BillInvoiceRq);
		return dataInMap;
	}

	public bf.com.misys.types.sadad.notification.BillInvoiceDtlRs getF_OUT_BillInvoiceRs() {
		return f_OUT_BillInvoiceRs;
	}

	public void setF_OUT_BillInvoiceRs(
			bf.com.misys.types.sadad.notification.BillInvoiceDtlRs param) {
		f_OUT_BillInvoiceRs = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_BillInvoiceRs, f_OUT_BillInvoiceRs);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		return dataOutMap;
	}
}