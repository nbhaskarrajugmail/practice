package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import com.trapedza.bankfusion.core.VectorTable;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import java.sql.Date;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public interface ICE_FilterDeceasedParty
		extends
		com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep,
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_startDate = "startDate";
	public static final String IN_batchNumber = "batchNumber";
	public static final String IN_loanAccNumber = "loanAccNumber";
	public static final String IN_endDate = "endDate";
	public static final String IN_result_PAGINGSUPPORT = "result_PAGINGSUPPORT";
	public static final String IN_result_PAGENUMBER = "result_PAGENUMBER";
	public static final String IN_branchCode = "branchCode";
	public static final String IN_nationalID = "nationalID";
	public static final String IN_eligibility = "eligibility";
	public static final String IN_loanRef = "loanRef";
	public static final String IN_result_NUMBEROFROWS = "result_NUMBEROFROWS";
	public static final String OUT_result_HASMOREPAGES = "result_HASMOREPAGES";
	public static final String OUT_startDate = "startDate";
	public static final String OUT_isEligibility = "isEligibility";
	public static final String OUT_result_NOOFROWS = "result_NOOFROWS";
	public static final String OUT_batchNumber = "batchNumber";
	public static final String OUT_loanAccNumber = "loanAccNumber";
	public static final String OUT_endDate = "endDate";
	public static final String OUT_branchCode = "branchCode";
	public static final String OUT_nationalID = "nationalID";
	public static final String OUT_result_TOTALPAGES = "result_TOTALPAGES";
	public static final String OUT_loanRef = "loanRef";
	public static final String OUT_result = "result";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public Date getF_IN_startDate();

	public void setF_IN_startDate(Date param);

	public Integer getF_IN_batchNumber();

	public void setF_IN_batchNumber(Integer param);

	public String getF_IN_loanAccNumber();

	public void setF_IN_loanAccNumber(String param);

	public Date getF_IN_endDate();

	public void setF_IN_endDate(Date param);

	public String getF_IN_result_PAGINGSUPPORT();

	public void setF_IN_result_PAGINGSUPPORT(String param);

	public Integer getF_IN_result_PAGENUMBER();

	public void setF_IN_result_PAGENUMBER(Integer param);

	public String getF_IN_branchCode();

	public void setF_IN_branchCode(String param);

	public Integer getF_IN_nationalID();

	public void setF_IN_nationalID(Integer param);

	public Boolean isF_IN_eligibility();

	public void setF_IN_eligibility(Boolean param);

	public Integer getF_IN_loanRef();

	public void setF_IN_loanRef(Integer param);

	public Integer getF_IN_result_NUMBEROFROWS();

	public void setF_IN_result_NUMBEROFROWS(Integer param);

	public Map getInDataMap();

	public Boolean isF_OUT_result_HASMOREPAGES();

	public void setF_OUT_result_HASMOREPAGES(Boolean param);

	public Date getF_OUT_startDate();

	public void setF_OUT_startDate(Date param);

	public Boolean isF_OUT_isEligibility();

	public void setF_OUT_isEligibility(Boolean param);

	public Integer getF_OUT_result_NOOFROWS();

	public void setF_OUT_result_NOOFROWS(Integer param);

	public Integer getF_OUT_batchNumber();

	public void setF_OUT_batchNumber(Integer param);

	public String getF_OUT_loanAccNumber();

	public void setF_OUT_loanAccNumber(String param);

	public Date getF_OUT_endDate();

	public void setF_OUT_endDate(Date param);

	public String getF_OUT_branchCode();

	public void setF_OUT_branchCode(String param);

	public Integer getF_OUT_nationalID();

	public void setF_OUT_nationalID(Integer param);

	public Integer getF_OUT_result_TOTALPAGES();

	public void setF_OUT_result_TOTALPAGES(Integer param);

	public Integer getF_OUT_loanRef();

	public void setF_OUT_loanRef(Integer param);

	public VectorTable getF_OUT_result();

	public void setF_OUT_result(VectorTable param);

	public Map getOutDataMap();
}