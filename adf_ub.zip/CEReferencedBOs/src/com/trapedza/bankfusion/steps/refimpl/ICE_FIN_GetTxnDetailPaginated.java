
package com.trapedza.bankfusion.steps.refimpl;

import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import java.util.Iterator;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_FIN_GetTxnDetailPaginated
		extends com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep,
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_PagedQuery = "PagedQuery";
	public static final String IN_batchRef = "batchRef";
	public static final String IN_filterAction = "filterAction";
	public static final String IN_result_PAGINGSUPPORT = "result_PAGINGSUPPORT";
	public static final String IN_result_PAGENUMBER = "result_PAGENUMBER";
	public static final String IN_PAGINGSUPPORT = "PAGINGSUPPORT";
	public static final String IN_getUnProcessedRecs = "getUnProcessedRecs";
	public static final String IN_batchInfo = "batchInfo";
	public static final String IN_result_NUMBEROFROWS = "result_NUMBEROFROWS";
	public static final String OUT_result = "result";
	public static final String OUT_result_HASMOREPAGES = "result_HASMOREPAGES";
	public static final String OUT_result_TOTALPAGES = "result_TOTALPAGES";
	public static final String OUT_PaginatedData = "PaginatedData";
	public static final String OUT_result_NOOFROWS = "result_NOOFROWS";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public bf.com.misys.bankfusion.attributes.PagedQuery getF_IN_PagedQuery();

	public void setF_IN_PagedQuery(bf.com.misys.bankfusion.attributes.PagedQuery param);

	public String getF_IN_batchRef();

	public void setF_IN_batchRef(String param);

	public String getF_IN_filterAction();

	public void setF_IN_filterAction(String param);

	public String getF_IN_result_PAGINGSUPPORT();

	public void setF_IN_result_PAGINGSUPPORT(String param);

	public Integer getF_IN_result_PAGENUMBER();

	public void setF_IN_result_PAGENUMBER(Integer param);

	public String getF_IN_PAGINGSUPPORT();

	public void setF_IN_PAGINGSUPPORT(String param);

	public String getF_IN_getUnProcessedRecs();

	public void setF_IN_getUnProcessedRecs(String param);

	public com.misys.ce.types.BatchInfoDetails getF_IN_batchInfo();

	public void setF_IN_batchInfo(com.misys.ce.types.BatchInfoDetails param);

	public Integer getF_IN_result_NUMBEROFROWS();

	public void setF_IN_result_NUMBEROFROWS(Integer param);

	public Map getInDataMap();

	public VectorTable getF_OUT_result();

	public void setF_OUT_result(VectorTable param);

	public Boolean isF_OUT_result_HASMOREPAGES();

	public void setF_OUT_result_HASMOREPAGES(Boolean param);

	public Integer getF_OUT_result_TOTALPAGES();

	public void setF_OUT_result_TOTALPAGES(Integer param);

	public Object getF_OUT_PaginatedData();

	public void setF_OUT_PaginatedData(Object param);

	public Integer getF_OUT_result_NOOFROWS();

	public void setF_OUT_result_NOOFROWS(Integer param);

	public Map getOutDataMap();
}