package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_ExtractFinanceDetailsBatch extends
		com.trapedza.bankfusion.batch.fatom.AbstractBatchFatom implements
		ICE_ExtractFinanceDetailsBatch {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_ExtractFinanceDetailsBatch(BankFusionEnvironment env) {
	}

	public AbstractCE_ExtractFinanceDetailsBatch() {
	}

	private Boolean f_IN_DO_NOT_PARK = Boolean.FALSE;

	private Boolean f_IN_SYNCHRONISED = Boolean.TRUE;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private Boolean f_OUT_Status = Boolean.FALSE;

	public void nullProcess() {
	}

	public Boolean isF_IN_DO_NOT_PARK() {
		return f_IN_DO_NOT_PARK;
	}

	public void setF_IN_DO_NOT_PARK(Boolean param) {
		f_IN_DO_NOT_PARK = param;
	}

	public Boolean isF_IN_SYNCHRONISED() {
		return f_IN_SYNCHRONISED;
	}

	public void setF_IN_SYNCHRONISED(Boolean param) {
		f_IN_SYNCHRONISED = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_DO_NOT_PARK, f_IN_DO_NOT_PARK);
		dataInMap.put(IN_SYNCHRONISED, f_IN_SYNCHRONISED);
		return dataInMap;
	}

	public Boolean isF_OUT_Status() {
		return f_OUT_Status;
	}

	public void setF_OUT_Status(Boolean param) {
		f_OUT_Status = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_Status, f_OUT_Status);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}