
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_FIN_FinancialGatewayHandler
		extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_inParam3 = "inParam3";
	public static final String IN_inParam2 = "inParam2";
	public static final String IN_inParam1 = "inParam1";
	public static final String IN_message = "message";
	public static final String IN_mode = "mode";
	public static final String IN_header = "header";
	public static final String OUT_status = "status";
	public static final String OUT_outParam4 = "outParam4";
	public static final String OUT_outParam3 = "outParam3";
	public static final String OUT_outParam2 = "outParam2";
	public static final String OUT_outParam1 = "outParam1";
	public static final String OUT_header = "header";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public Object getF_IN_inParam3();

	public void setF_IN_inParam3(Object param);

	public Object getF_IN_inParam2();

	public void setF_IN_inParam2(Object param);

	public Object getF_IN_inParam1();

	public void setF_IN_inParam1(Object param);

	public String getF_IN_message();

	public void setF_IN_message(String param);

	public String getF_IN_mode();

	public void setF_IN_mode(String param);

	public com.misys.ce.types.BatchHeaderDetails getF_IN_header();

	public void setF_IN_header(com.misys.ce.types.BatchHeaderDetails param);

	public Map getInDataMap();

	public Boolean isF_OUT_status();

	public void setF_OUT_status(Boolean param);

	public Object getF_OUT_outParam4();

	public void setF_OUT_outParam4(Object param);

	public Object getF_OUT_outParam3();

	public void setF_OUT_outParam3(Object param);

	public Object getF_OUT_outParam2();

	public void setF_OUT_outParam2(Object param);

	public Object getF_OUT_outParam1();

	public void setF_OUT_outParam1(Object param);

	public com.misys.ce.types.BatchHeaderDetails getF_OUT_header();

	public void setF_OUT_header(com.misys.ce.types.BatchHeaderDetails param);

	public Map getOutDataMap();
}