
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_FetchTitleDeedDtls implements ICE_FetchTitleDeedDtls {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_FetchTitleDeedDtls(BankFusionEnvironment env) {
	}

	public AbstractCE_FetchTitleDeedDtls() {
	}

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_IN_titleDeedDtlsList = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_019_titleDeedDtlsList_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setBranchShortCode(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setFarmLocationDescription(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_titleDeedDtlsList_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_019_titleDeedDtlsList_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_IN_titleDeedDtlsList.addTitleDeedDetails(0, var_019_titleDeedDtlsList_titleDeedDetails);
	}
	private String f_IN_viewMode = "VIEW";

	private String f_IN_titleID = CommonConstants.EMPTY_STRING;

	private String f_IN_partyID = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.ListShareHolderDtlsType f_OUT_ShareHolderDtlsList = new com.misys.ce.types.ListShareHolderDtlsType();
	{
		com.misys.ce.types.ShareHolderDtlsType var_020_ShareHolderDtlsList_shareHolderDetails = new com.misys.ce.types.ShareHolderDtlsType();

		var_020_ShareHolderDtlsList_shareHolderDetails.setShareHolderIdpk(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setSharePercentage(Utils.getBIGDECIMALValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setPartyName(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setOwnershipStatus(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setPartId(Utils.getSTRINGValue(""));
		var_020_ShareHolderDtlsList_shareHolderDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_ShareHolderDtlsList_shareHolderDetails.setOwnershipType(Utils.getSTRINGValue(""));
		f_OUT_ShareHolderDtlsList.addShareHolderDetails(0, var_020_ShareHolderDtlsList_shareHolderDetails);
	}
	private com.misys.ce.types.ListFarmLandLocationDtlsType f_OUT_farmLandLocationDtlsTypeList = new com.misys.ce.types.ListFarmLandLocationDtlsType();
	{
		com.misys.ce.types.FarmLandLocationdtlsType var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls = new com.misys.ce.types.FarmLandLocationdtlsType();

		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setContractNumber(Utils.getSTRINGValue(""));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setLength(Utils.getBIGDECIMALValue(""));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setFarmLandLocationidpk(Utils.getSTRINGValue(""));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setDirection(Utils.getSTRINGValue(""));
		var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls.setBordering(Utils.getSTRINGValue(""));
		f_OUT_farmLandLocationDtlsTypeList.addFarmLandLocationDtls(0,
				var_020_farmLandLocationDtlsTypeList_farmLandLocationDtls);
	}
	private com.misys.ce.types.ListFarmLandNeighbourDtlsType f_OUT_farmLandNeighbourDtlsTypeList = new com.misys.ce.types.ListFarmLandNeighbourDtlsType();
	{
		com.misys.ce.types.FarmLandNeighbourdtlsType var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls = new com.misys.ce.types.FarmLandNeighbourdtlsType();

		var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls.setFarmLandNeighbouridpk(Utils.getSTRINGValue(""));
		var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls.setPartyName(Utils.getSTRINGValue(""));
		var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls.setPartyId(Utils.getSTRINGValue(""));
		f_OUT_farmLandNeighbourDtlsTypeList.addFarmLandNeighbourDtls(0,
				var_020_farmLandNeighbourDtlsTypeList_farmLandNeighbourDtls);
	}
	private com.misys.ce.types.ListTitleDeedLocDtlsType f_OUT_TitleDeedLocDtlstypeList = new com.misys.ce.types.ListTitleDeedLocDtlsType();
	{
		com.misys.ce.types.TitleDeedLocationdtlsType var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls = new com.misys.ce.types.TitleDeedLocationdtlsType();

		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setLocationNorthDegree(Utils.getBIGDECIMALValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setLocationNorthSection(Utils.getBIGDECIMALValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setSerial(Utils.getINTEGERValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setLocationEastSection(Utils.getBIGDECIMALValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setTitleDeedLocIdpk(Utils.getSTRINGValue(""));
		var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls.setLocationEastDegree(Utils.getBIGDECIMALValue(""));
		f_OUT_TitleDeedLocDtlstypeList.addTitleDeedLocDtls(0, var_020_TitleDeedLocDtlstypeList_titleDeedLocDtls);
	}
	private com.misys.ce.types.ListParentTitleDeedDtlsType f_OUT_ParentTitleDeedDtlsList = new com.misys.ce.types.ListParentTitleDeedDtlsType();
	{
		com.misys.ce.types.ParentTitleDeeddtlsType var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls = new com.misys.ce.types.ParentTitleDeeddtlsType();

		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedPlanNo(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setParentTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedPlotNo(Utils.getSTRINGValue(""));
		f_OUT_ParentTitleDeedDtlsList.addParentTitleDeedDtls(0, var_020_ParentTitleDeedDtlsList_parentTitleDeedDtls);
	}
	private com.misys.ce.types.ListSplitTitleDeedDtlsType f_OUT_splitDetailsTypeList = new com.misys.ce.types.ListSplitTitleDeedDtlsType();
	{
		com.misys.ce.types.SplitTitleDeeddtlsType var_020_splitDetailsTypeList_splitTitleDeedDtls = new com.misys.ce.types.SplitTitleDeeddtlsType();

		var_020_splitDetailsTypeList_splitTitleDeedDtls.setSplitTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setSplitPercentage(Utils.getBIGDECIMALValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedPlanNo(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_splitDetailsTypeList_splitTitleDeedDtls.setTitleDeedPlotNo(Utils.getSTRINGValue(""));
		f_OUT_splitDetailsTypeList.addSplitTitleDeedDtls(0, var_020_splitDetailsTypeList_splitTitleDeedDtls);
	}
	private com.misys.ce.types.FarmLandTitleDeeddtlsType f_OUT_farmLandDtlsType = new com.misys.ce.types.FarmLandTitleDeeddtlsType();
	{
		f_OUT_farmLandDtlsType.setContractNumber(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setContractDate(Utils.getDATEDefaultValue());
		f_OUT_farmLandDtlsType.setFarmName(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setIrrigationSource(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setEngineerOfficeName(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setEngineerOfficeDate(Utils.getDATEDefaultValue());
		f_OUT_farmLandDtlsType.setContractSource(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setSelect(Utils.getBOOLEANValue("false"));
		f_OUT_farmLandDtlsType.setTitleDeedIdpk(CommonConstants.EMPTY_STRING);
		f_OUT_farmLandDtlsType.setOwnerName(CommonConstants.EMPTY_STRING);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_IN_titleDeedDtlsList() {
		return f_IN_titleDeedDtlsList;
	}

	public void setF_IN_titleDeedDtlsList(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_IN_titleDeedDtlsList = param;
	}

	public String getF_IN_viewMode() {
		return f_IN_viewMode;
	}

	public void setF_IN_viewMode(String param) {
		f_IN_viewMode = param;
	}

	public String getF_IN_titleID() {
		return f_IN_titleID;
	}

	public void setF_IN_titleID(String param) {
		f_IN_titleID = param;
	}

	public String getF_IN_partyID() {
		return f_IN_partyID;
	}

	public void setF_IN_partyID(String param) {
		f_IN_partyID = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_titleDeedDtlsList, f_IN_titleDeedDtlsList);
		dataInMap.put(IN_viewMode, f_IN_viewMode);
		dataInMap.put(IN_titleID, f_IN_titleID);
		dataInMap.put(IN_partyID, f_IN_partyID);
		return dataInMap;
	}

	public com.misys.ce.types.ListShareHolderDtlsType getF_OUT_ShareHolderDtlsList() {
		return f_OUT_ShareHolderDtlsList;
	}

	public void setF_OUT_ShareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param) {
		f_OUT_ShareHolderDtlsList = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public com.misys.ce.types.ListFarmLandLocationDtlsType getF_OUT_farmLandLocationDtlsTypeList() {
		return f_OUT_farmLandLocationDtlsTypeList;
	}

	public void setF_OUT_farmLandLocationDtlsTypeList(com.misys.ce.types.ListFarmLandLocationDtlsType param) {
		f_OUT_farmLandLocationDtlsTypeList = param;
	}

	public com.misys.ce.types.ListFarmLandNeighbourDtlsType getF_OUT_farmLandNeighbourDtlsTypeList() {
		return f_OUT_farmLandNeighbourDtlsTypeList;
	}

	public void setF_OUT_farmLandNeighbourDtlsTypeList(com.misys.ce.types.ListFarmLandNeighbourDtlsType param) {
		f_OUT_farmLandNeighbourDtlsTypeList = param;
	}

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_OUT_TitleDeedLocDtlstypeList() {
		return f_OUT_TitleDeedLocDtlstypeList;
	}

	public void setF_OUT_TitleDeedLocDtlstypeList(com.misys.ce.types.ListTitleDeedLocDtlsType param) {
		f_OUT_TitleDeedLocDtlstypeList = param;
	}

	public com.misys.ce.types.ListParentTitleDeedDtlsType getF_OUT_ParentTitleDeedDtlsList() {
		return f_OUT_ParentTitleDeedDtlsList;
	}

	public void setF_OUT_ParentTitleDeedDtlsList(com.misys.ce.types.ListParentTitleDeedDtlsType param) {
		f_OUT_ParentTitleDeedDtlsList = param;
	}

	public com.misys.ce.types.ListSplitTitleDeedDtlsType getF_OUT_splitDetailsTypeList() {
		return f_OUT_splitDetailsTypeList;
	}

	public void setF_OUT_splitDetailsTypeList(com.misys.ce.types.ListSplitTitleDeedDtlsType param) {
		f_OUT_splitDetailsTypeList = param;
	}

	public com.misys.ce.types.FarmLandTitleDeeddtlsType getF_OUT_farmLandDtlsType() {
		return f_OUT_farmLandDtlsType;
	}

	public void setF_OUT_farmLandDtlsType(com.misys.ce.types.FarmLandTitleDeeddtlsType param) {
		f_OUT_farmLandDtlsType = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_ShareHolderDtlsList, f_OUT_ShareHolderDtlsList);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_farmLandLocationDtlsTypeList, f_OUT_farmLandLocationDtlsTypeList);
		dataOutMap.put(OUT_farmLandNeighbourDtlsTypeList, f_OUT_farmLandNeighbourDtlsTypeList);
		dataOutMap.put(OUT_TitleDeedLocDtlstypeList, f_OUT_TitleDeedLocDtlstypeList);
		dataOutMap.put(OUT_ParentTitleDeedDtlsList, f_OUT_ParentTitleDeedDtlsList);
		dataOutMap.put(OUT_splitDetailsTypeList, f_OUT_splitDetailsTypeList);
		dataOutMap.put(OUT_farmLandDtlsType, f_OUT_farmLandDtlsType);
		return dataOutMap;
	}
}