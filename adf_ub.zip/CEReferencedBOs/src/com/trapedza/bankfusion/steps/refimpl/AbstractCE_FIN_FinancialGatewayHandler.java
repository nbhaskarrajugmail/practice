
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_FIN_FinancialGatewayHandler implements ICE_FIN_FinancialGatewayHandler {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_FIN_FinancialGatewayHandler(BankFusionEnvironment env) {
	}

	public AbstractCE_FIN_FinancialGatewayHandler() {
	}

	private Object f_IN_inParam3 = new String();

	private Object f_IN_inParam2 = new String();

	private Object f_IN_inParam1 = new String();

	private String f_IN_message = CommonConstants.EMPTY_STRING;

	private String f_IN_mode = CommonConstants.EMPTY_STRING;

	private com.misys.ce.types.BatchHeaderDetails f_IN_header = new com.misys.ce.types.BatchHeaderDetails();
	{
		f_IN_header.setBatchDesc(CommonConstants.EMPTY_STRING);
		f_IN_header.setShowInternalAcc(Utils.getBOOLEANValue("false"));
		f_IN_header.setTxnType(CommonConstants.EMPTY_STRING);
		f_IN_header.setBatchRef(CommonConstants.EMPTY_STRING);
		f_IN_header.setInternalAcc(CommonConstants.EMPTY_STRING);
		f_IN_header.setShowBankId(Utils.getBOOLEANValue("false"));
		f_IN_header.setAmountToBeProcessed(Utils.getBIGDECIMALValue("0"));
		f_IN_header.setBatchFileName(CommonConstants.EMPTY_STRING);
		f_IN_header.setProcessingStatus(CommonConstants.EMPTY_STRING);
		f_IN_header.setBankID(CommonConstants.EMPTY_STRING);
		f_IN_header.setBatchRefSearch(CommonConstants.EMPTY_STRING);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private Boolean f_OUT_status = Boolean.FALSE;

	private Object f_OUT_outParam4 = new String();

	private Object f_OUT_outParam3 = new String();

	private Object f_OUT_outParam2 = new String();

	private Object f_OUT_outParam1 = new String();

	private com.misys.ce.types.BatchHeaderDetails f_OUT_header = new com.misys.ce.types.BatchHeaderDetails();
	{
		f_OUT_header.setBatchDesc(CommonConstants.EMPTY_STRING);
		f_OUT_header.setShowInternalAcc(Utils.getBOOLEANValue("false"));
		f_OUT_header.setTxnType(CommonConstants.EMPTY_STRING);
		f_OUT_header.setBatchRef(CommonConstants.EMPTY_STRING);
		f_OUT_header.setInternalAcc(CommonConstants.EMPTY_STRING);
		f_OUT_header.setShowBankId(Utils.getBOOLEANValue("false"));
		f_OUT_header.setAmountToBeProcessed(Utils.getBIGDECIMALValue("0"));
		f_OUT_header.setBatchFileName(CommonConstants.EMPTY_STRING);
		f_OUT_header.setProcessingStatus(CommonConstants.EMPTY_STRING);
		f_OUT_header.setBankID(CommonConstants.EMPTY_STRING);
		f_OUT_header.setBatchRefSearch(CommonConstants.EMPTY_STRING);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Object getF_IN_inParam3() {
		return f_IN_inParam3;
	}

	public void setF_IN_inParam3(Object param) {
		f_IN_inParam3 = param;
	}

	public Object getF_IN_inParam2() {
		return f_IN_inParam2;
	}

	public void setF_IN_inParam2(Object param) {
		f_IN_inParam2 = param;
	}

	public Object getF_IN_inParam1() {
		return f_IN_inParam1;
	}

	public void setF_IN_inParam1(Object param) {
		f_IN_inParam1 = param;
	}

	public String getF_IN_message() {
		return f_IN_message;
	}

	public void setF_IN_message(String param) {
		f_IN_message = param;
	}

	public String getF_IN_mode() {
		return f_IN_mode;
	}

	public void setF_IN_mode(String param) {
		f_IN_mode = param;
	}

	public com.misys.ce.types.BatchHeaderDetails getF_IN_header() {
		return f_IN_header;
	}

	public void setF_IN_header(com.misys.ce.types.BatchHeaderDetails param) {
		f_IN_header = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_inParam3, f_IN_inParam3);
		dataInMap.put(IN_inParam2, f_IN_inParam2);
		dataInMap.put(IN_inParam1, f_IN_inParam1);
		dataInMap.put(IN_message, f_IN_message);
		dataInMap.put(IN_mode, f_IN_mode);
		dataInMap.put(IN_header, f_IN_header);
		return dataInMap;
	}

	public Boolean isF_OUT_status() {
		return f_OUT_status;
	}

	public void setF_OUT_status(Boolean param) {
		f_OUT_status = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Object getF_OUT_outParam4() {
		return f_OUT_outParam4;
	}

	public void setF_OUT_outParam4(Object param) {
		f_OUT_outParam4 = param;
	}

	public Object getF_OUT_outParam3() {
		return f_OUT_outParam3;
	}

	public void setF_OUT_outParam3(Object param) {
		f_OUT_outParam3 = param;
	}

	public Object getF_OUT_outParam2() {
		return f_OUT_outParam2;
	}

	public void setF_OUT_outParam2(Object param) {
		f_OUT_outParam2 = param;
	}

	public Object getF_OUT_outParam1() {
		return f_OUT_outParam1;
	}

	public void setF_OUT_outParam1(Object param) {
		f_OUT_outParam1 = param;
	}

	public com.misys.ce.types.BatchHeaderDetails getF_OUT_header() {
		return f_OUT_header;
	}

	public void setF_OUT_header(com.misys.ce.types.BatchHeaderDetails param) {
		f_OUT_header = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_status, f_OUT_status);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_outParam4, f_OUT_outParam4);
		dataOutMap.put(OUT_outParam3, f_OUT_outParam3);
		dataOutMap.put(OUT_outParam2, f_OUT_outParam2);
		dataOutMap.put(OUT_outParam1, f_OUT_outParam1);
		dataOutMap.put(OUT_header, f_OUT_header);
		return dataOutMap;
	}
}