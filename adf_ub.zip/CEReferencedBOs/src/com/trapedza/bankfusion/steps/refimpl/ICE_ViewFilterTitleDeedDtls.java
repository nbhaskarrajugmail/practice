
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_ViewFilterTitleDeedDtls extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_titleDeedId = "titleDeedId";
	public static final String IN_listTitleDeedDtlsType = "listTitleDeedDtlsType";
	public static final String IN_versionNumber = "versionNumber";
	public static final String OUT_listTitleDeedDtlsType = "listTitleDeedDtlsType";
	public static final String OUT_titleDeedLocList = "titleDeedLocList";
	public static final String OUT_shareHolderDtlsList = "shareHolderDtlsList";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public String getF_IN_titleDeedId();

	public void setF_IN_titleDeedId(String param);

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_IN_listTitleDeedDtlsType();

	public void setF_IN_listTitleDeedDtlsType(com.misys.ce.types.ListTitleDeedIdDtlsType param);

	public Integer getF_IN_versionNumber();

	public void setF_IN_versionNumber(Integer param);

	public Map getInDataMap();

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_listTitleDeedDtlsType();

	public void setF_OUT_listTitleDeedDtlsType(com.misys.ce.types.ListTitleDeedIdDtlsType param);

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_OUT_titleDeedLocList();

	public void setF_OUT_titleDeedLocList(com.misys.ce.types.ListTitleDeedLocDtlsType param);

	public com.misys.ce.types.ListShareHolderDtlsType getF_OUT_shareHolderDtlsList();

	public void setF_OUT_shareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param);

	public Map getOutDataMap();
}