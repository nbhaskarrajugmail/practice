
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_PTY_ElmYakeenChk extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_dateOfBirth = "dateOfBirth";
	public static final String IN_nationalId = "nationalId";
	public static final String IN_registeredId = "registeredId";
	public static final String IN_PartyBasicDtls = "PartyBasicDtls";
	public static final String OUT_lastName = "lastName";
	public static final String OUT_enterpriseName = "enterpriseName";
	public static final String OUT_dateOfBirthInString = "dateOfBirthInString";
	public static final String OUT_firstName = "firstName";
	public static final String OUT_gender = "gender";
	public static final String OUT_MiddleName = "MiddleName";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public String getF_IN_dateOfBirth();

	public void setF_IN_dateOfBirth(String param);

	public String getF_IN_nationalId();

	public void setF_IN_nationalId(String param);

	public String getF_IN_registeredId();

	public void setF_IN_registeredId(String param);

	public bf.com.misys.cbs.types.PartyBasicDtls getF_IN_PartyBasicDtls();

	public void setF_IN_PartyBasicDtls(bf.com.misys.cbs.types.PartyBasicDtls param);

	public Map getInDataMap();

	public String getF_OUT_lastName();

	public void setF_OUT_lastName(String param);

	public String getF_OUT_enterpriseName();

	public void setF_OUT_enterpriseName(String param);

	public String getF_OUT_dateOfBirthInString();

	public void setF_OUT_dateOfBirthInString(String param);

	public String getF_OUT_firstName();

	public void setF_OUT_firstName(String param);

	public String getF_OUT_gender();

	public void setF_OUT_gender(String param);

	public String getF_OUT_MiddleName();

	public void setF_OUT_MiddleName(String param);

	public Map getOutDataMap();
}