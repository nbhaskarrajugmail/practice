
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_FetchFarmLocationBkp extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {

    public static final String IN_branchCode = "branchCode";

    public static final String IN_farmLocation = "farmLocation";

    public static final String OUT_farmLocationDesc = "farmLocationDesc";

    public void process(BankFusionEnvironment env) throws BankFusionException;

    public String getF_IN_branchCode();

    public void setF_IN_branchCode(String param);

    public String getF_IN_farmLocation();

    public void setF_IN_farmLocation(String param);

    public Map getInDataMap();

    public String getF_OUT_farmLocationDesc();

    public void setF_OUT_farmLocationDesc(String param);

    public Map getOutDataMap();
}