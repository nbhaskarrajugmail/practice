
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_FilterTitleDeedDtls implements ICE_FilterTitleDeedDtls {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_FilterTitleDeedDtls(BankFusionEnvironment env) {
	}

	public AbstractCE_FilterTitleDeedDtls() {
	}

	private Boolean f_IN_isSplitTd = Boolean.FALSE;

	private com.misys.ce.types.SearchTitleDeedDtlsRqType f_IN_searchTitleDeedDtlsRqType = new com.misys.ce.types.SearchTitleDeedDtlsRqType();
	{
		f_IN_searchTitleDeedDtlsRqType.setTitleDeedId(CommonConstants.EMPTY_STRING);
		bf.com.misys.bankfusion.attributes.PagedQuery var_019_searchTitleDeedDtlsRqType_pagingInfo = new bf.com.misys.bankfusion.attributes.PagedQuery();

		bf.com.misys.bankfusion.attributes.PagingRequest var_019_searchTitleDeedDtlsRqType_pagingInfo_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_019_searchTitleDeedDtlsRqType_pagingInfo_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_019_searchTitleDeedDtlsRqType_pagingInfo_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_019_searchTitleDeedDtlsRqType_pagingInfo_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		var_019_searchTitleDeedDtlsRqType_pagingInfo
				.setPagingRequest(var_019_searchTitleDeedDtlsRqType_pagingInfo_PagingRequest);

		var_019_searchTitleDeedDtlsRqType_pagingInfo.setQueryData(CommonConstants.EMPTY_STRING);
		f_IN_searchTitleDeedDtlsRqType.setPagingInfo(var_019_searchTitleDeedDtlsRqType_pagingInfo);

		f_IN_searchTitleDeedDtlsRqType.setPartyId(CommonConstants.EMPTY_STRING);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.SearchTitleDeedDtlsRsType f_OUT_searchTitleDeedDtlsRs = new com.misys.ce.types.SearchTitleDeedDtlsRsType();
	{
		com.misys.ce.types.ListTitleDeedIdDtlsType var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls = new com.misys.ce.types.ListTitleDeedIdDtlsType();

		com.misys.ce.types.TitleDeedDetailsType var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setFarmLocationDescription(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails
				.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls.addTitleDeedDetails(0,
				var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls_titleDeedDetails);

		f_OUT_searchTitleDeedDtlsRs.setListTitleDeedIdDtls(var_020_searchTitleDeedDtlsRs_listTitleDeedIdDtls);

		bf.com.misys.bankfusion.attributes.PagedQuery var_020_searchTitleDeedDtlsRs_pagingInfo = new bf.com.misys.bankfusion.attributes.PagedQuery();

		bf.com.misys.bankfusion.attributes.PagingRequest var_020_searchTitleDeedDtlsRs_pagingInfo_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_020_searchTitleDeedDtlsRs_pagingInfo_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_020_searchTitleDeedDtlsRs_pagingInfo_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_020_searchTitleDeedDtlsRs_pagingInfo_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		var_020_searchTitleDeedDtlsRs_pagingInfo
				.setPagingRequest(var_020_searchTitleDeedDtlsRs_pagingInfo_PagingRequest);

		var_020_searchTitleDeedDtlsRs_pagingInfo.setQueryData(CommonConstants.EMPTY_STRING);
		f_OUT_searchTitleDeedDtlsRs.setPagingInfo(var_020_searchTitleDeedDtlsRs_pagingInfo);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Boolean isF_IN_isSplitTd() {
		return f_IN_isSplitTd;
	}

	public void setF_IN_isSplitTd(Boolean param) {
		f_IN_isSplitTd = param;
	}

	public com.misys.ce.types.SearchTitleDeedDtlsRqType getF_IN_searchTitleDeedDtlsRqType() {
		return f_IN_searchTitleDeedDtlsRqType;
	}

	public void setF_IN_searchTitleDeedDtlsRqType(com.misys.ce.types.SearchTitleDeedDtlsRqType param) {
		f_IN_searchTitleDeedDtlsRqType = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_isSplitTd, f_IN_isSplitTd);
		dataInMap.put(IN_searchTitleDeedDtlsRqType, f_IN_searchTitleDeedDtlsRqType);
		return dataInMap;
	}

	public com.misys.ce.types.SearchTitleDeedDtlsRsType getF_OUT_searchTitleDeedDtlsRs() {
		return f_OUT_searchTitleDeedDtlsRs;
	}

	public void setF_OUT_searchTitleDeedDtlsRs(com.misys.ce.types.SearchTitleDeedDtlsRsType param) {
		f_OUT_searchTitleDeedDtlsRs = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_searchTitleDeedDtlsRs, f_OUT_searchTitleDeedDtlsRs);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}