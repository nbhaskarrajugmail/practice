package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import com.trapedza.bankfusion.core.VectorTable;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import java.sql.Date;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_FilterDeceasedParty implements
		ICE_FilterDeceasedParty,
		com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_FilterDeceasedParty(BankFusionEnvironment env) {
	}

	public AbstractCE_FilterDeceasedParty() {
	}

	private Date f_IN_startDate = new Date(0L);

	private Integer f_IN_batchNumber = CommonConstants.INTEGER_ZERO;

	private String f_IN_loanAccNumber = CommonConstants.EMPTY_STRING;

	private Date f_IN_endDate = new Date(0L);

	private String f_IN_result_PAGINGSUPPORT = "N";

	private Integer f_IN_result_PAGENUMBER = new Integer(1);

	private String f_IN_branchCode = CommonConstants.EMPTY_STRING;

	private Integer f_IN_nationalID = CommonConstants.INTEGER_ZERO;

	private Boolean f_IN_eligibility = Boolean.FALSE;

	private Integer f_IN_loanRef = CommonConstants.INTEGER_ZERO;

	private Integer f_IN_result_NUMBEROFROWS = new Integer(10);
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private Boolean f_OUT_result_HASMOREPAGES = Boolean.FALSE;

	private Date f_OUT_startDate = new Date(0L);

	private Boolean f_OUT_isEligibility = Boolean.FALSE;

	private Integer f_OUT_result_NOOFROWS = CommonConstants.INTEGER_ZERO;

	private Integer f_OUT_batchNumber = CommonConstants.INTEGER_ZERO;

	private String f_OUT_loanAccNumber = CommonConstants.EMPTY_STRING;

	private Date f_OUT_endDate = new Date(0L);

	private String f_OUT_branchCode = CommonConstants.EMPTY_STRING;

	private Integer f_OUT_nationalID = CommonConstants.INTEGER_ZERO;

	private Integer f_OUT_result_TOTALPAGES = CommonConstants.INTEGER_ZERO;

	private Integer f_OUT_loanRef = CommonConstants.INTEGER_ZERO;

	private VectorTable f_OUT_result = new VectorTable();

	private PagingHelper pagingHelper = new PagingHelper(this);

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Date getF_IN_startDate() {
		return f_IN_startDate;
	}

	public void setF_IN_startDate(Date param) {
		f_IN_startDate = param;
	}

	public Integer getF_IN_batchNumber() {
		return f_IN_batchNumber;
	}

	public void setF_IN_batchNumber(Integer param) {
		f_IN_batchNumber = param;
	}

	public String getF_IN_loanAccNumber() {
		return f_IN_loanAccNumber;
	}

	public void setF_IN_loanAccNumber(String param) {
		f_IN_loanAccNumber = param;
	}

	public Date getF_IN_endDate() {
		return f_IN_endDate;
	}

	public void setF_IN_endDate(Date param) {
		f_IN_endDate = param;
	}

	public String getF_IN_result_PAGINGSUPPORT() {
		return f_IN_result_PAGINGSUPPORT;
	}

	public void setF_IN_result_PAGINGSUPPORT(String param) {
		f_IN_result_PAGINGSUPPORT = param;
	}

	public Integer getF_IN_result_PAGENUMBER() {
		return f_IN_result_PAGENUMBER;
	}

	public void setF_IN_result_PAGENUMBER(Integer param) {
		f_IN_result_PAGENUMBER = param;
	}

	public String getF_IN_branchCode() {
		return f_IN_branchCode;
	}

	public void setF_IN_branchCode(String param) {
		f_IN_branchCode = param;
	}

	public Integer getF_IN_nationalID() {
		return f_IN_nationalID;
	}

	public void setF_IN_nationalID(Integer param) {
		f_IN_nationalID = param;
	}

	public Boolean isF_IN_eligibility() {
		return f_IN_eligibility;
	}

	public void setF_IN_eligibility(Boolean param) {
		f_IN_eligibility = param;
	}

	public Integer getF_IN_loanRef() {
		return f_IN_loanRef;
	}

	public void setF_IN_loanRef(Integer param) {
		f_IN_loanRef = param;
	}

	public Integer getF_IN_result_NUMBEROFROWS() {
		return f_IN_result_NUMBEROFROWS;
	}

	public void setF_IN_result_NUMBEROFROWS(Integer param) {
		f_IN_result_NUMBEROFROWS = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_startDate, f_IN_startDate);
		dataInMap.put(IN_batchNumber, f_IN_batchNumber);
		dataInMap.put(IN_loanAccNumber, f_IN_loanAccNumber);
		dataInMap.put(IN_endDate, f_IN_endDate);
		dataInMap.put(IN_result_PAGINGSUPPORT, f_IN_result_PAGINGSUPPORT);
		dataInMap.put(IN_result_PAGENUMBER, f_IN_result_PAGENUMBER);
		dataInMap.put(IN_branchCode, f_IN_branchCode);
		dataInMap.put(IN_nationalID, f_IN_nationalID);
		dataInMap.put(IN_eligibility, f_IN_eligibility);
		dataInMap.put(IN_loanRef, f_IN_loanRef);
		dataInMap.put(IN_result_NUMBEROFROWS, f_IN_result_NUMBEROFROWS);
		return dataInMap;
	}

	public Boolean isF_OUT_result_HASMOREPAGES() {
		return f_OUT_result_HASMOREPAGES;
	}

	public void setF_OUT_result_HASMOREPAGES(Boolean param) {
		f_OUT_result_HASMOREPAGES = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Date getF_OUT_startDate() {
		return f_OUT_startDate;
	}

	public void setF_OUT_startDate(Date param) {
		f_OUT_startDate = param;
	}

	public Boolean isF_OUT_isEligibility() {
		return f_OUT_isEligibility;
	}

	public void setF_OUT_isEligibility(Boolean param) {
		f_OUT_isEligibility = param;
	}

	public Integer getF_OUT_result_NOOFROWS() {
		return f_OUT_result_NOOFROWS;
	}

	public void setF_OUT_result_NOOFROWS(Integer param) {
		f_OUT_result_NOOFROWS = param;
	}

	public Integer getF_OUT_batchNumber() {
		return f_OUT_batchNumber;
	}

	public void setF_OUT_batchNumber(Integer param) {
		f_OUT_batchNumber = param;
	}

	public String getF_OUT_loanAccNumber() {
		return f_OUT_loanAccNumber;
	}

	public void setF_OUT_loanAccNumber(String param) {
		f_OUT_loanAccNumber = param;
	}

	public Date getF_OUT_endDate() {
		return f_OUT_endDate;
	}

	public void setF_OUT_endDate(Date param) {
		f_OUT_endDate = param;
	}

	public String getF_OUT_branchCode() {
		return f_OUT_branchCode;
	}

	public void setF_OUT_branchCode(String param) {
		f_OUT_branchCode = param;
	}

	public Integer getF_OUT_nationalID() {
		return f_OUT_nationalID;
	}

	public void setF_OUT_nationalID(Integer param) {
		f_OUT_nationalID = param;
	}

	public Integer getF_OUT_result_TOTALPAGES() {
		return f_OUT_result_TOTALPAGES;
	}

	public void setF_OUT_result_TOTALPAGES(Integer param) {
		f_OUT_result_TOTALPAGES = param;
	}

	public Integer getF_OUT_loanRef() {
		return f_OUT_loanRef;
	}

	public void setF_OUT_loanRef(Integer param) {
		f_OUT_loanRef = param;
	}

	public VectorTable getF_OUT_result() {
		return f_OUT_result;
	}

	public void setF_OUT_result(VectorTable param) {
		f_OUT_result = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_result_HASMOREPAGES, f_OUT_result_HASMOREPAGES);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		dataOutMap.put(OUT_startDate, f_OUT_startDate);
		dataOutMap.put(OUT_isEligibility, f_OUT_isEligibility);
		dataOutMap.put(OUT_result_NOOFROWS, f_OUT_result_NOOFROWS);
		dataOutMap.put(OUT_batchNumber, f_OUT_batchNumber);
		dataOutMap.put(OUT_loanAccNumber, f_OUT_loanAccNumber);
		dataOutMap.put(OUT_endDate, f_OUT_endDate);
		dataOutMap.put(OUT_branchCode, f_OUT_branchCode);
		dataOutMap.put(OUT_nationalID, f_OUT_nationalID);
		dataOutMap.put(OUT_result_TOTALPAGES, f_OUT_result_TOTALPAGES);
		dataOutMap.put(OUT_loanRef, f_OUT_loanRef);
		dataOutMap.put(OUT_result, f_OUT_result);
		return dataOutMap;
	}

	public PagingHelper getPagingHelper() {
		return pagingHelper;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = new ActivityStepPagingState(this);
		return (pagingState);
	}

	public Object processPagingState(
			BankFusionEnvironment bankfusionenvironment,
			ActivityStepPagingState activitysteppagingstate, Map map) {
		return null;
	}

	public String getResourceID() {
		return "CE_FilterDeceasedParty";
	}

}