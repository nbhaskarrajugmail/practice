
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_PTY_PrepareDedupCheck extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_partyBasicDtls = "partyBasicDtls";
	public static final String IN_nationalId = "nationalId";
	public static final String IN_middleName = "middleName";
	public static final String IN_enterpriseName = "enterpriseName";
	public static final String IN_dateOfBirth = "dateOfBirth";
	public static final String IN_registeredID = "registeredID";
	public static final String IN_gender = "gender";
	public static final String IN_firstName = "firstName";
	public static final String IN_readPtyDedupConfigOp = "readPtyDedupConfigOp";
	public static final String IN_lastName = "lastName";
	public static final String OUT_readPtyDedupConfigOp = "readPtyDedupConfigOp";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public bf.com.misys.cbs.types.PartyBasicDtls getF_IN_partyBasicDtls();

	public void setF_IN_partyBasicDtls(bf.com.misys.cbs.types.PartyBasicDtls param);

	public String getF_IN_nationalId();

	public void setF_IN_nationalId(String param);

	public String getF_IN_middleName();

	public void setF_IN_middleName(String param);

	public String getF_IN_enterpriseName();

	public void setF_IN_enterpriseName(String param);

	public String getF_IN_dateOfBirth();

	public void setF_IN_dateOfBirth(String param);

	public String getF_IN_registeredID();

	public void setF_IN_registeredID(String param);

	public String getF_IN_gender();

	public void setF_IN_gender(String param);

	public String getF_IN_firstName();

	public void setF_IN_firstName(String param);

	public bf.com.misys.cbs.types.ReadPtyDedupConfigOp getF_IN_readPtyDedupConfigOp();

	public void setF_IN_readPtyDedupConfigOp(bf.com.misys.cbs.types.ReadPtyDedupConfigOp param);

	public String getF_IN_lastName();

	public void setF_IN_lastName(String param);

	public Map getInDataMap();

	public bf.com.misys.cbs.types.ReadPtyDedupConfigOp getF_OUT_readPtyDedupConfigOp();

	public void setF_OUT_readPtyDedupConfigOp(bf.com.misys.cbs.types.ReadPtyDedupConfigOp param);

	public Map getOutDataMap();
}