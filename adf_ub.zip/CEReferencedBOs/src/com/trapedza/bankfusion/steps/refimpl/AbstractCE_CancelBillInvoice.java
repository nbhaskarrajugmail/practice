package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.sql.Timestamp;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_CancelBillInvoice implements
		ICE_CancelBillInvoice {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_CancelBillInvoice(BankFusionEnvironment env) {
	}

	public AbstractCE_CancelBillInvoice() {
	}

	private Boolean f_IN_AdhocRun = Boolean.FALSE;

	private String f_IN_JobID = CommonConstants.EMPTY_STRING;

	private Timestamp f_IN_JobRunDate = new Timestamp(0L);
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private String f_OUT_ErrorDesc = CommonConstants.EMPTY_STRING;

	private Boolean f_OUT_Success = Boolean.FALSE;

	private String f_OUT_ErrorCode = CommonConstants.EMPTY_STRING;

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Boolean isF_IN_AdhocRun() {
		return f_IN_AdhocRun;
	}

	public void setF_IN_AdhocRun(Boolean param) {
		f_IN_AdhocRun = param;
	}

	public String getF_IN_JobID() {
		return f_IN_JobID;
	}

	public void setF_IN_JobID(String param) {
		f_IN_JobID = param;
	}

	public Timestamp getF_IN_JobRunDate() {
		return f_IN_JobRunDate;
	}

	public void setF_IN_JobRunDate(Timestamp param) {
		f_IN_JobRunDate = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_AdhocRun, f_IN_AdhocRun);
		dataInMap.put(IN_JobID, f_IN_JobID);
		dataInMap.put(IN_JobRunDate, f_IN_JobRunDate);
		return dataInMap;
	}

	public String getF_OUT_ErrorDesc() {
		return f_OUT_ErrorDesc;
	}

	public void setF_OUT_ErrorDesc(String param) {
		f_OUT_ErrorDesc = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Boolean isF_OUT_Success() {
		return f_OUT_Success;
	}

	public void setF_OUT_Success(Boolean param) {
		f_OUT_Success = param;
	}

	public String getF_OUT_ErrorCode() {
		return f_OUT_ErrorCode;
	}

	public void setF_OUT_ErrorCode(String param) {
		f_OUT_ErrorCode = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_ErrorDesc, f_OUT_ErrorDesc);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		dataOutMap.put(OUT_Success, f_OUT_Success);
		dataOutMap.put(OUT_ErrorCode, f_OUT_ErrorCode);
		return dataOutMap;
	}
}