
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_AmendTitleDeedDetails extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_splitTitleDeedDtlsList = "splitTitleDeedDtlsList";
	public static final String IN_titleDeedDtlsTypeDB = "titleDeedDtlsTypeDB";
	public static final String IN_farmLandTitleDeedDtlsType = "farmLandTitleDeedDtlsType";
	public static final String IN_titleDeedDtlsType = "titleDeedDtlsType";
	public static final String IN_shareHolderDtlsList = "shareHolderDtlsList";
	public static final String IN_farmLandNeighbourDtlsList = "farmLandNeighbourDtlsList";
	public static final String IN_farmLandLocationDtlsList = "farmLandLocationDtlsList";
	public static final String IN_titleDeedLocationDtlsList = "titleDeedLocationDtlsList";
	public static final String IN_parentTitleDeedDtlsList = "parentTitleDeedDtlsList";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public com.misys.ce.types.ListSplitTitleDeedDtlsType getF_IN_splitTitleDeedDtlsList();

	public void setF_IN_splitTitleDeedDtlsList(com.misys.ce.types.ListSplitTitleDeedDtlsType param);

	public com.misys.ce.types.TitleDeedDetailsType getF_IN_titleDeedDtlsTypeDB();

	public void setF_IN_titleDeedDtlsTypeDB(com.misys.ce.types.TitleDeedDetailsType param);

	public com.misys.ce.types.FarmLandTitleDeeddtlsType getF_IN_farmLandTitleDeedDtlsType();

	public void setF_IN_farmLandTitleDeedDtlsType(com.misys.ce.types.FarmLandTitleDeeddtlsType param);

	public com.misys.ce.types.TitleDeedDetailsType getF_IN_titleDeedDtlsType();

	public void setF_IN_titleDeedDtlsType(com.misys.ce.types.TitleDeedDetailsType param);

	public com.misys.ce.types.ListShareHolderDtlsType getF_IN_shareHolderDtlsList();

	public void setF_IN_shareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param);

	public com.misys.ce.types.ListFarmLandNeighbourDtlsType getF_IN_farmLandNeighbourDtlsList();

	public void setF_IN_farmLandNeighbourDtlsList(com.misys.ce.types.ListFarmLandNeighbourDtlsType param);

	public com.misys.ce.types.ListFarmLandLocationDtlsType getF_IN_farmLandLocationDtlsList();

	public void setF_IN_farmLandLocationDtlsList(com.misys.ce.types.ListFarmLandLocationDtlsType param);

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_IN_titleDeedLocationDtlsList();

	public void setF_IN_titleDeedLocationDtlsList(com.misys.ce.types.ListTitleDeedLocDtlsType param);

	public com.misys.ce.types.ListParentTitleDeedDtlsType getF_IN_parentTitleDeedDtlsList();

	public void setF_IN_parentTitleDeedDtlsList(com.misys.ce.types.ListParentTitleDeedDtlsType param);

	public Map getInDataMap();
}