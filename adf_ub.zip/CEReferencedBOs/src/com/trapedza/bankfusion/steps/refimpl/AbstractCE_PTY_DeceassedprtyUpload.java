package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_PTY_DeceassedprtyUpload implements
		ICE_PTY_DeceassedprtyUpload {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PTY_DeceassedprtyUpload(BankFusionEnvironment env) {
	}

	public AbstractCE_PTY_DeceassedprtyUpload() {
	}

	private String f_IN_str1 = CommonConstants.EMPTY_STRING;

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_str1() {
		return f_IN_str1;
	}

	public void setF_IN_str1(String param) {
		f_IN_str1 = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_str1, f_IN_str1);
		return dataInMap;
	}
}