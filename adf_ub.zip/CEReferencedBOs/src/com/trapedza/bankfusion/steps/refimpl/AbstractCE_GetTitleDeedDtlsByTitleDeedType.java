
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_GetTitleDeedDtlsByTitleDeedType implements ICE_GetTitleDeedDtlsByTitleDeedType {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_GetTitleDeedDtlsByTitleDeedType(BankFusionEnvironment env) {
	}

	public AbstractCE_GetTitleDeedDtlsByTitleDeedType() {
	}

	private String f_IN_titleDeedType = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.ListShareHolderDtlsType f_OUT_shareHolderDtlsList = new com.misys.ce.types.ListShareHolderDtlsType();
	{
		com.misys.ce.types.ShareHolderDtlsType var_020_shareHolderDtlsList_shareHolderDetails = new com.misys.ce.types.ShareHolderDtlsType();

		var_020_shareHolderDtlsList_shareHolderDetails.setShareHolderIdpk(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setSharePercentage(Utils.getBIGDECIMALValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setPartyName(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setOwnershipStatus(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setPartId(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_shareHolderDtlsList_shareHolderDetails.setOwnershipType(Utils.getSTRINGValue(""));
		f_OUT_shareHolderDtlsList.addShareHolderDetails(0, var_020_shareHolderDtlsList_shareHolderDetails);
	}
	private com.misys.ce.types.ListTitleDeedIdDtlsType f_OUT_titleDeedDtlsTypeList = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_020_titleDeedDtlsTypeList_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsTypeList_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_OUT_titleDeedDtlsTypeList.addTitleDeedDetails(0, var_020_titleDeedDtlsTypeList_titleDeedDetails);
	}
	private com.misys.ce.types.ListTitleDeedLocDtlsType f_OUT_titleDeedDtlsLocList = new com.misys.ce.types.ListTitleDeedLocDtlsType();
	{
		com.misys.ce.types.TitleDeedLocationdtlsType var_020_titleDeedDtlsLocList_titleDeedLocDtls = new com.misys.ce.types.TitleDeedLocationdtlsType();

		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setLocationNorthDegree(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setLocationNorthSection(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setSerial(Utils.getINTEGERValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setLocationEastSection(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setTitleDeedLocIdpk(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlsLocList_titleDeedLocDtls.setLocationEastDegree(Utils.getBIGDECIMALValue(""));
		f_OUT_titleDeedDtlsLocList.addTitleDeedLocDtls(0, var_020_titleDeedDtlsLocList_titleDeedLocDtls);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_titleDeedType() {
		return f_IN_titleDeedType;
	}

	public void setF_IN_titleDeedType(String param) {
		f_IN_titleDeedType = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_titleDeedType, f_IN_titleDeedType);
		return dataInMap;
	}

	public com.misys.ce.types.ListShareHolderDtlsType getF_OUT_shareHolderDtlsList() {
		return f_OUT_shareHolderDtlsList;
	}

	public void setF_OUT_shareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param) {
		f_OUT_shareHolderDtlsList = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_titleDeedDtlsTypeList() {
		return f_OUT_titleDeedDtlsTypeList;
	}

	public void setF_OUT_titleDeedDtlsTypeList(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_OUT_titleDeedDtlsTypeList = param;
	}

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_OUT_titleDeedDtlsLocList() {
		return f_OUT_titleDeedDtlsLocList;
	}

	public void setF_OUT_titleDeedDtlsLocList(com.misys.ce.types.ListTitleDeedLocDtlsType param) {
		f_OUT_titleDeedDtlsLocList = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_shareHolderDtlsList, f_OUT_shareHolderDtlsList);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_titleDeedDtlsTypeList, f_OUT_titleDeedDtlsTypeList);
		dataOutMap.put(OUT_titleDeedDtlsLocList, f_OUT_titleDeedDtlsLocList);
		return dataOutMap;
	}
}