
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_FilterTitleDeedDtls extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_isSplitTd = "isSplitTd";
	public static final String IN_searchTitleDeedDtlsRqType = "searchTitleDeedDtlsRqType";
	public static final String OUT_searchTitleDeedDtlsRs = "searchTitleDeedDtlsRs";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public Boolean isF_IN_isSplitTd();

	public void setF_IN_isSplitTd(Boolean param);

	public com.misys.ce.types.SearchTitleDeedDtlsRqType getF_IN_searchTitleDeedDtlsRqType();

	public void setF_IN_searchTitleDeedDtlsRqType(com.misys.ce.types.SearchTitleDeedDtlsRqType param);

	public Map getInDataMap();

	public com.misys.ce.types.SearchTitleDeedDtlsRsType getF_OUT_searchTitleDeedDtlsRs();

	public void setF_OUT_searchTitleDeedDtlsRs(com.misys.ce.types.SearchTitleDeedDtlsRsType param);

	public Map getOutDataMap();
}