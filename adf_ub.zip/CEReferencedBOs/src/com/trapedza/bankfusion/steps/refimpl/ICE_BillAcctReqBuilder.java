package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public interface ICE_BillAcctReqBuilder extends
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_billAcctRq = "billAcctRq";
	public static final String OUT_billAcctRs = "billAcctRs";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public bf.org.example.ce_billacct.SadadRequest getF_IN_billAcctRq();

	public void setF_IN_billAcctRq(bf.org.example.ce_billacct.SadadRequest param);

	public Map getInDataMap();

	public bf.org.example.ce_billacct.SadadResponse getF_OUT_billAcctRs();

	public void setF_OUT_billAcctRs(
			bf.org.example.ce_billacct.SadadResponse param);

	public Map getOutDataMap();
}