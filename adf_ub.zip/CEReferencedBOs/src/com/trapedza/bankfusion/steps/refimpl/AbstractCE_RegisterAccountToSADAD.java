package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import java.sql.Date;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_RegisterAccountToSADAD implements ICE_RegisterAccountToSADAD {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_RegisterAccountToSADAD(BankFusionEnvironment env) {
	}

	public AbstractCE_RegisterAccountToSADAD() {
	}

	private Boolean f_IN_AdhocRun = Boolean.FALSE;

	private Date f_IN_AccountOpenRunDate = new Date(0L);

	private String f_IN_JOBID = "REGISTERACCOUNT";
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private String f_OUT_ErrorDescription = CommonConstants.EMPTY_STRING;

	private Boolean f_OUT_Success = Boolean.FALSE;

	private String f_OUT_ErrorCode = CommonConstants.EMPTY_STRING;

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public Boolean isF_IN_AdhocRun() {
		return f_IN_AdhocRun;
	}

	public void setF_IN_AdhocRun(Boolean param) {
		f_IN_AdhocRun = param;
	}

	public Date getF_IN_AccountOpenRunDate() {
		return f_IN_AccountOpenRunDate;
	}

	public void setF_IN_AccountOpenRunDate(Date param) {
		f_IN_AccountOpenRunDate = param;
	}

	public String getF_IN_JOBID() {
		return f_IN_JOBID;
	}

	public void setF_IN_JOBID(String param) {
		f_IN_JOBID = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_AdhocRun, f_IN_AdhocRun);
		dataInMap.put(IN_AccountOpenRunDate, f_IN_AccountOpenRunDate);
		dataInMap.put(IN_JOBID, f_IN_JOBID);
		return dataInMap;
	}

	public String getF_OUT_ErrorDescription() {
		return f_OUT_ErrorDescription;
	}

	public void setF_OUT_ErrorDescription(String param) {
		f_OUT_ErrorDescription = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Boolean isF_OUT_Success() {
		return f_OUT_Success;
	}

	public void setF_OUT_Success(Boolean param) {
		f_OUT_Success = param;
	}

	public String getF_OUT_ErrorCode() {
		return f_OUT_ErrorCode;
	}

	public void setF_OUT_ErrorCode(String param) {
		f_OUT_ErrorCode = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_ErrorDescription, f_OUT_ErrorDescription);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_Success, f_OUT_Success);
		dataOutMap.put(OUT_ErrorCode, f_OUT_ErrorCode);
		return dataOutMap;
	}
}