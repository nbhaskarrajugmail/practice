
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_PTY_DeceasedPartyFileGen implements ICE_PTY_DeceasedPartyFileGen {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PTY_DeceasedPartyFileGen(BankFusionEnvironment env) {
	}

	public AbstractCE_PTY_DeceasedPartyFileGen() {
	}

	private VectorTable f_IN_deceasedPartyDtls = new VectorTable();

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public VectorTable getF_IN_deceasedPartyDtls() {
		return f_IN_deceasedPartyDtls;
	}

	public void setF_IN_deceasedPartyDtls(VectorTable param) {
		f_IN_deceasedPartyDtls = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_deceasedPartyDtls, f_IN_deceasedPartyDtls);
		return dataInMap;
	}
}