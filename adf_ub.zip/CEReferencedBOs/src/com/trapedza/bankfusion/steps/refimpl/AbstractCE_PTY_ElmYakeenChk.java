
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_PTY_ElmYakeenChk implements ICE_PTY_ElmYakeenChk {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PTY_ElmYakeenChk(BankFusionEnvironment env) {
	}

	public AbstractCE_PTY_ElmYakeenChk() {
	}

	private String f_IN_dateOfBirth = CommonConstants.EMPTY_STRING;

	private String f_IN_nationalId = CommonConstants.EMPTY_STRING;

	private String f_IN_registeredId = CommonConstants.EMPTY_STRING;

	private bf.com.misys.cbs.types.PartyBasicDtls f_IN_PartyBasicDtls = new bf.com.misys.cbs.types.PartyBasicDtls();
	{
		f_IN_PartyBasicDtls.setSigTxnReference(CommonConstants.EMPTY_STRING);
		bf.com.misys.cbs.types.PartyComplyStsDtls var_019_PartyBasicDtls_partyComplyStsDtls = new bf.com.misys.cbs.types.PartyComplyStsDtls();

		bf.com.misys.cbs.types.PartyComplyStsDtl var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl = new bf.com.misys.cbs.types.PartyComplyStsDtl();

		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyCheck(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl
				.setExtensionDetails(var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails);

		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyExpiry(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplySts(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyComplyStsDtls
				.setPartyComplyStsDtl(var_019_PartyBasicDtls_partyComplyStsDtls_partyComplyStsDtl);

		f_IN_PartyBasicDtls.addPartyComplyStsDtls(0, var_019_PartyBasicDtls_partyComplyStsDtls);

		f_IN_PartyBasicDtls.setPartyStatus(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setPartyAlternativeId(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setAssignedBranch(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyLocalityDtl var_019_PartyBasicDtls_partyLocalityDtl = new bf.com.misys.cbs.types.PartyLocalityDtl();

		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyLocalityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyLocalityDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl
				.setExtensionDetails(var_019_PartyBasicDtls_partyLocalityDtl_extensionDetails);

		var_019_PartyBasicDtls_partyLocalityDtl.setIsPrivate(Utils.getBOOLEANValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl.setIsInternational(Utils.getBOOLEANValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_PartyBasicDtls_partyLocalityDtl_localityDtls = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyLocalityDtl_localityDtls
				.setExtensionDetails(var_019_PartyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails);

		var_019_PartyBasicDtls_partyLocalityDtl.addLocalityDtls(0,
				var_019_PartyBasicDtls_partyLocalityDtl_localityDtls);

		f_IN_PartyBasicDtls.setPartyLocalityDtl(var_019_PartyBasicDtls_partyLocalityDtl);

		f_IN_PartyBasicDtls.setEquivPartyName(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setIsMultihost(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setRelationshipManager(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setPartyType(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setCountryOfDomicile(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyLineOfBusinessDtls var_019_PartyBasicDtls_PartyLineOfBusinessDtls = new bf.com.misys.cbs.types.PartyLineOfBusinessDtls();

		bf.com.misys.cbs.types.PartyLineOfBusinessDetail var_019_PartyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail = new bf.com.misys.cbs.types.PartyLineOfBusinessDetail();

		var_019_PartyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail
				.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail
				.setLineOfBusiness(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_PartyLineOfBusinessDtls.addPartyLineOfBusinessDetail(0,
				var_019_PartyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail);

		f_IN_PartyBasicDtls.setPartyLineOfBusinessDtls(var_019_PartyBasicDtls_PartyLineOfBusinessDtls);

		f_IN_PartyBasicDtls.setName(CommonConstants.EMPTY_STRING);
		f_IN_PartyBasicDtls.setIsTaxPayer(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setLocality(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setNameType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyIdDtls var_019_PartyBasicDtls_partyIdDtls = new bf.com.misys.cbs.types.PartyIdDtls();

		bf.com.misys.cbs.types.PartyIdDtl var_019_PartyBasicDtls_partyIdDtls_partyIdDtl = new bf.com.misys.cbs.types.PartyIdDtl();

		var_019_PartyBasicDtls_partyIdDtls_partyIdDtl.setIdReference(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyIdDtls_partyIdDtl
				.setExtensionDetails(var_019_PartyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails);

		var_019_PartyBasicDtls_partyIdDtls_partyIdDtl.setIdType(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyIdDtls.addPartyIdDtl(0, var_019_PartyBasicDtls_partyIdDtls_partyIdDtl);

		f_IN_PartyBasicDtls.setPartyIdDtls(var_019_PartyBasicDtls_partyIdDtls);

		f_IN_PartyBasicDtls.setCloseDate(Utils.getDATEValue(""));
		f_IN_PartyBasicDtls.setNationality(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setLanguage(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setDateTo(Utils.getDATEValue(""));
		f_IN_PartyBasicDtls.setOriginationDate(Utils.getDATEValue(""));
		f_IN_PartyBasicDtls.setDateFrom(Utils.getDATEValue(""));
		f_IN_PartyBasicDtls.setLastName(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setDeleteDate(Utils.getDATEValue(""));
		f_IN_PartyBasicDtls.setCountryOfRisk(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setSigStatus(CommonConstants.EMPTY_STRING);
		f_IN_PartyBasicDtls.setIsPreferred(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setDefaultBranchCode(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setIsMobile(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setTitle(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setAltRiskCountry(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setShortName(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setIsConsolidateStatement(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setMiddleName(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyRoles var_019_PartyBasicDtls_partyRoles = new bf.com.misys.cbs.types.PartyRoles();

		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyRoles_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyRoles_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyRoles_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyRoles.setExtensionDetails(var_019_PartyBasicDtls_partyRoles_extensionDetails);

		bf.com.misys.cbs.types.PartyRole var_019_PartyBasicDtls_partyRoles_partyRole = new bf.com.misys.cbs.types.PartyRole();

		var_019_PartyBasicDtls_partyRoles_partyRole.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_partyRoles_partyRole.setRoleReason(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyRoles_partyRole.setPartyRole(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl
				.setExtensionDetails(var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails);

		var_019_PartyBasicDtls_partyRoles_partyRole
				.setLocalityDtl(var_019_PartyBasicDtls_partyRoles_partyRole_localityDtl);

		var_019_PartyBasicDtls_partyRoles_partyRole.setEffectiveDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_partyRoles.setPartyRole(var_019_PartyBasicDtls_partyRoles_partyRole);

		f_IN_PartyBasicDtls.addPartyRoles(0, var_019_PartyBasicDtls_partyRoles);

		f_IN_PartyBasicDtls.setFirstName(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		f_IN_PartyBasicDtls.setExtensionDetails(var_019_PartyBasicDtls_extensionDetails);

		f_IN_PartyBasicDtls.setDepartment(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setPartyCategory(CommonConstants.EMPTY_STRING);
		f_IN_PartyBasicDtls.setDateOfBirth(Utils.getDATEValue(""));
		bf.com.misys.cbs.types.ContactDtls var_019_PartyBasicDtls_contactDtls = new bf.com.misys.cbs.types.ContactDtls();

		bf.com.misys.cbs.types.ContactDtl var_019_PartyBasicDtls_contactDtls_contactDtl = new bf.com.misys.cbs.types.ContactDtl();

		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactTelNum(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setAreaCode(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactDtlId(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactType(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setCountryCode(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setStartDate(Utils.getDATEDefaultValue());
		var_019_PartyBasicDtls_contactDtls_contactDtl.setIsApplicable(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactAddressId(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactEmailId(CommonConstants.EMPTY_STRING);
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_contactDtls_contactDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_contactDtls_contactDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_contactDtls_contactDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_contactDtls_contactDtl
				.setExtensionDetails(var_019_PartyBasicDtls_contactDtls_contactDtl_extensionDetails);

		var_019_PartyBasicDtls_contactDtls_contactDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_contactDtls_contactDtl.setPrefOrder(Utils.getINTEGERValue("0"));
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactDesc(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setEndDate(Utils.getDATEDefaultValue());
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactMethod(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactPosition(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactName(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls_contactDtl.setContactAltTel(CommonConstants.EMPTY_STRING);
		var_019_PartyBasicDtls_contactDtls.addContactDtl(0, var_019_PartyBasicDtls_contactDtls_contactDtl);

		f_IN_PartyBasicDtls.setContactDtls(var_019_PartyBasicDtls_contactDtls);

		f_IN_PartyBasicDtls.setSuffix(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyStatusDtls var_019_PartyBasicDtls_altStsDtls = new bf.com.misys.cbs.types.PartyStatusDtls();

		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_altStsDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_altStsDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_altStsDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_altStsDtls.setExtensionDetails(var_019_PartyBasicDtls_altStsDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyStatusDtl var_019_PartyBasicDtls_altStsDtls_partyStatusDtl = new bf.com.misys.cbs.types.PartyStatusDtl();

		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl
				.setExtensionDetails(var_019_PartyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails);

		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setStatusCode(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setDateTo(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setChangeReason(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setDateFrom(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_altStsDtls_partyStatusDtl.setStatusParent(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_altStsDtls.setPartyStatusDtl(var_019_PartyBasicDtls_altStsDtls_partyStatusDtl);

		f_IN_PartyBasicDtls.addAltStsDtls(0, var_019_PartyBasicDtls_altStsDtls);

		bf.com.misys.cbs.types.PartyPublicStsDtls var_019_PartyBasicDtls_publicStsDtls = new bf.com.misys.cbs.types.PartyPublicStsDtls();

		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_publicStsDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_publicStsDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls.setExtensionDetails(var_019_PartyBasicDtls_publicStsDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyPublicStsDtl var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl = new bf.com.misys.cbs.types.PartyPublicStsDtl();

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setStsChangeReason(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusStartDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusExpiryDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setIsCustodial(Utils.getBOOLEANValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl
				.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl
				.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl.setExtensionDetails(
				var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails);

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl
				.setLocalityDtl(var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl);

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setPartyPublicSts(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl
				.setExtensionDetails(var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails);

		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setCourtJudgeType(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusEndDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_publicStsDtls
				.setPartyPublicStsDtl(var_019_PartyBasicDtls_publicStsDtls_partyPublicStsDtl);

		f_IN_PartyBasicDtls.addPublicStsDtls(0, var_019_PartyBasicDtls_publicStsDtls);

		f_IN_PartyBasicDtls.setPartyId(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setIsInternet(Utils.getBOOLEANValue(""));
		f_IN_PartyBasicDtls.setPartySubType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyAddrDtls var_019_PartyBasicDtls_partyAddrDtls = new bf.com.misys.cbs.types.PartyAddrDtls();

		var_019_PartyBasicDtls_partyAddrDtls.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.PartyAddrSpecDtl var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail = new bf.com.misys.cbs.types.PartyAddrSpecDtl();

		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setFaoName(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setToDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setAddressType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail
				.setExtensionDetails(var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails);

		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setDunsNumber(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setFromDate(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setStatusAtTheAddress(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail.setDefaultAddress(Utils.getBOOLEANValue("true"));
		var_019_PartyBasicDtls_partyAddrDtls
				.setPartAddressSpecDetail(var_019_PartyBasicDtls_partyAddrDtls_partAddressSpecDetail);

		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyAddrDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyAddrDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls.setExtensionDetails(var_019_PartyBasicDtls_partyAddrDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyAddrDtl var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails = new bf.com.misys.cbs.types.PartyAddrDtl();

		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine9(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine8(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setTownOrCity(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine7(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine6(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setCountry(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine5(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine4(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine3(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine2(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine1(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails
				.setExtensionDetails(var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails);

		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setRegion(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setPostCode(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine10(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_partyAddrDtls
				.setPartyAddressDetails(var_019_PartyBasicDtls_partyAddrDtls_partyAddressDetails);

		f_IN_PartyBasicDtls.addPartyAddrDtls(0, var_019_PartyBasicDtls_partyAddrDtls);

		bf.com.misys.cbs.types.PartyStatusDtl var_019_PartyBasicDtls_bankStsDtl = new bf.com.misys.cbs.types.PartyStatusDtl();

		var_019_PartyBasicDtls_bankStsDtl.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.ExtensionDetails var_019_PartyBasicDtls_bankStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_PartyBasicDtls_bankStsDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_bankStsDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_PartyBasicDtls_bankStsDtl.setExtensionDetails(var_019_PartyBasicDtls_bankStsDtl_extensionDetails);

		var_019_PartyBasicDtls_bankStsDtl.setStatusCode(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_bankStsDtl.setDateTo(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_bankStsDtl.setChangeReason(Utils.getSTRINGValue(""));
		var_019_PartyBasicDtls_bankStsDtl.setDateFrom(Utils.getDATEValue(""));
		var_019_PartyBasicDtls_bankStsDtl.setStatusParent(Utils.getSTRINGValue(""));
		f_IN_PartyBasicDtls.setBankStsDtl(var_019_PartyBasicDtls_bankStsDtl);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private String f_OUT_lastName = CommonConstants.EMPTY_STRING;

	private String f_OUT_enterpriseName = CommonConstants.EMPTY_STRING;

	private String f_OUT_dateOfBirthInString = CommonConstants.EMPTY_STRING;

	private String f_OUT_firstName = CommonConstants.EMPTY_STRING;

	private String f_OUT_gender = CommonConstants.EMPTY_STRING;

	private String f_OUT_MiddleName = CommonConstants.EMPTY_STRING;

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_dateOfBirth() {
		return f_IN_dateOfBirth;
	}

	public void setF_IN_dateOfBirth(String param) {
		f_IN_dateOfBirth = param;
	}

	public String getF_IN_nationalId() {
		return f_IN_nationalId;
	}

	public void setF_IN_nationalId(String param) {
		f_IN_nationalId = param;
	}

	public String getF_IN_registeredId() {
		return f_IN_registeredId;
	}

	public void setF_IN_registeredId(String param) {
		f_IN_registeredId = param;
	}

	public bf.com.misys.cbs.types.PartyBasicDtls getF_IN_PartyBasicDtls() {
		return f_IN_PartyBasicDtls;
	}

	public void setF_IN_PartyBasicDtls(bf.com.misys.cbs.types.PartyBasicDtls param) {
		f_IN_PartyBasicDtls = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_dateOfBirth, f_IN_dateOfBirth);
		dataInMap.put(IN_nationalId, f_IN_nationalId);
		dataInMap.put(IN_registeredId, f_IN_registeredId);
		dataInMap.put(IN_PartyBasicDtls, f_IN_PartyBasicDtls);
		return dataInMap;
	}

	public String getF_OUT_lastName() {
		return f_OUT_lastName;
	}

	public void setF_OUT_lastName(String param) {
		f_OUT_lastName = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public String getF_OUT_enterpriseName() {
		return f_OUT_enterpriseName;
	}

	public void setF_OUT_enterpriseName(String param) {
		f_OUT_enterpriseName = param;
	}

	public String getF_OUT_dateOfBirthInString() {
		return f_OUT_dateOfBirthInString;
	}

	public void setF_OUT_dateOfBirthInString(String param) {
		f_OUT_dateOfBirthInString = param;
	}

	public String getF_OUT_firstName() {
		return f_OUT_firstName;
	}

	public void setF_OUT_firstName(String param) {
		f_OUT_firstName = param;
	}

	public String getF_OUT_gender() {
		return f_OUT_gender;
	}

	public void setF_OUT_gender(String param) {
		f_OUT_gender = param;
	}

	public String getF_OUT_MiddleName() {
		return f_OUT_MiddleName;
	}

	public void setF_OUT_MiddleName(String param) {
		f_OUT_MiddleName = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_lastName, f_OUT_lastName);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_enterpriseName, f_OUT_enterpriseName);
		dataOutMap.put(OUT_dateOfBirthInString, f_OUT_dateOfBirthInString);
		dataOutMap.put(OUT_firstName, f_OUT_firstName);
		dataOutMap.put(OUT_gender, f_OUT_gender);
		dataOutMap.put(OUT_MiddleName, f_OUT_MiddleName);
		return dataOutMap;
	}
}