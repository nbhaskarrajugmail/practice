
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_FetchTitleDeedDtls extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_titleDeedDtlsList = "titleDeedDtlsList";
	public static final String IN_viewMode = "viewMode";
	public static final String IN_titleID = "titleID";
	public static final String IN_partyID = "partyID";
	public static final String OUT_ShareHolderDtlsList = "ShareHolderDtlsList";
	public static final String OUT_farmLandLocationDtlsTypeList = "farmLandLocationDtlsTypeList";
	public static final String OUT_farmLandNeighbourDtlsTypeList = "farmLandNeighbourDtlsTypeList";
	public static final String OUT_TitleDeedLocDtlstypeList = "TitleDeedLocDtlstypeList";
	public static final String OUT_ParentTitleDeedDtlsList = "ParentTitleDeedDtlsList";
	public static final String OUT_splitDetailsTypeList = "splitDetailsTypeList";
	public static final String OUT_farmLandDtlsType = "farmLandDtlsType";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_IN_titleDeedDtlsList();

	public void setF_IN_titleDeedDtlsList(com.misys.ce.types.ListTitleDeedIdDtlsType param);

	public String getF_IN_viewMode();

	public void setF_IN_viewMode(String param);

	public String getF_IN_titleID();

	public void setF_IN_titleID(String param);

	public String getF_IN_partyID();

	public void setF_IN_partyID(String param);

	public Map getInDataMap();

	public com.misys.ce.types.ListShareHolderDtlsType getF_OUT_ShareHolderDtlsList();

	public void setF_OUT_ShareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param);

	public com.misys.ce.types.ListFarmLandLocationDtlsType getF_OUT_farmLandLocationDtlsTypeList();

	public void setF_OUT_farmLandLocationDtlsTypeList(com.misys.ce.types.ListFarmLandLocationDtlsType param);

	public com.misys.ce.types.ListFarmLandNeighbourDtlsType getF_OUT_farmLandNeighbourDtlsTypeList();

	public void setF_OUT_farmLandNeighbourDtlsTypeList(com.misys.ce.types.ListFarmLandNeighbourDtlsType param);

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_OUT_TitleDeedLocDtlstypeList();

	public void setF_OUT_TitleDeedLocDtlstypeList(com.misys.ce.types.ListTitleDeedLocDtlsType param);

	public com.misys.ce.types.ListParentTitleDeedDtlsType getF_OUT_ParentTitleDeedDtlsList();

	public void setF_OUT_ParentTitleDeedDtlsList(com.misys.ce.types.ListParentTitleDeedDtlsType param);

	public com.misys.ce.types.ListSplitTitleDeedDtlsType getF_OUT_splitDetailsTypeList();

	public void setF_OUT_splitDetailsTypeList(com.misys.ce.types.ListSplitTitleDeedDtlsType param);

	public com.misys.ce.types.FarmLandTitleDeeddtlsType getF_OUT_farmLandDtlsType();

	public void setF_OUT_farmLandDtlsType(com.misys.ce.types.FarmLandTitleDeeddtlsType param);

	public Map getOutDataMap();
}