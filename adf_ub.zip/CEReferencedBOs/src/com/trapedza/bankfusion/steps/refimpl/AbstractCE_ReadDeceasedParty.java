package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_ReadDeceasedParty implements
		ICE_ReadDeceasedParty {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_ReadDeceasedParty(BankFusionEnvironment env) {
	}

	public AbstractCE_ReadDeceasedParty() {
	}

	private bf.com.misys.types.deceased.party.DeceasedDtlsRq f_IN_request = new bf.com.misys.types.deceased.party.DeceasedDtlsRq();
	{
		f_IN_request.setNationalID(CommonConstants.EMPTY_STRING);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private bf.com.misys.types.deceased.party.DeceasedRsList f_OUT_response = new bf.com.misys.types.deceased.party.DeceasedRsList();
	{
		bf.com.misys.types.deceased.party.DeceasedRs var_020_response_deceasedRes = new bf.com.misys.types.deceased.party.DeceasedRs();

		var_020_response_deceasedRes.setDAETHDATE(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setBORROWERNATID(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setULDT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setREPFULLNAME(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setVERSIONNUM(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setALHAFIZANO(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setAPPROVEDDT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setLOANPLACE(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setDLBATCHNO(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setULSTATUS(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setUPUSERID(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREPNATID(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setBoID(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setREPCONTACNO(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setLOANBR(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREJREASON(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setALHAFIZASRC(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREFNO(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREGDATE(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREFENDDT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setALHAFIZADT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setREFSTARTDT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setDLBATCHDT(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setREMARKS(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setAPPROVERID(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setBORROWERNAME(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes.setAPPROVED(CommonConstants.EMPTY_STRING);
		var_020_response_deceasedRes
				.setOUTSTANDINGAMT(CommonConstants.EMPTY_STRING);
		f_OUT_response.addDeceasedRes(0, var_020_response_deceasedRes);
	}
	private bf.com.misys.types.deceased.party.StatusDetails f_OUT_statusDetails = new bf.com.misys.types.deceased.party.StatusDetails();
	{
		f_OUT_statusDetails.setStatus(CommonConstants.EMPTY_STRING);
		f_OUT_statusDetails.setReason(CommonConstants.EMPTY_STRING);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.com.misys.types.deceased.party.DeceasedDtlsRq getF_IN_request() {
		return f_IN_request;
	}

	public void setF_IN_request(
			bf.com.misys.types.deceased.party.DeceasedDtlsRq param) {
		f_IN_request = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_request, f_IN_request);
		return dataInMap;
	}

	public bf.com.misys.types.deceased.party.DeceasedRsList getF_OUT_response() {
		return f_OUT_response;
	}

	public void setF_OUT_response(
			bf.com.misys.types.deceased.party.DeceasedRsList param) {
		f_OUT_response = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public bf.com.misys.types.deceased.party.StatusDetails getF_OUT_statusDetails() {
		return f_OUT_statusDetails;
	}

	public void setF_OUT_statusDetails(
			bf.com.misys.types.deceased.party.StatusDetails param) {
		f_OUT_statusDetails = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_response, f_OUT_response);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		dataOutMap.put(OUT_statusDetails, f_OUT_statusDetails);
		return dataOutMap;
	}
}