
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_SearchTitleDeedByNumber implements ICE_SearchTitleDeedByNumber {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_SearchTitleDeedByNumber(BankFusionEnvironment env) {
	}

	public AbstractCE_SearchTitleDeedByNumber() {
	}

	private String f_IN_titleDeedNumber = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_OUT_titleDeeddtlsList = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_020_titleDeeddtlsList_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_titleDeeddtlsList_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_titleDeeddtlsList_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_OUT_titleDeeddtlsList.addTitleDeedDetails(0, var_020_titleDeeddtlsList_titleDeedDetails);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_titleDeedNumber() {
		return f_IN_titleDeedNumber;
	}

	public void setF_IN_titleDeedNumber(String param) {
		f_IN_titleDeedNumber = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_titleDeedNumber, f_IN_titleDeedNumber);
		return dataInMap;
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_titleDeeddtlsList() {
		return f_OUT_titleDeeddtlsList;
	}

	public void setF_OUT_titleDeeddtlsList(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_OUT_titleDeeddtlsList = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_titleDeeddtlsList, f_OUT_titleDeeddtlsList);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}