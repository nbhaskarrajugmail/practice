
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_AmendTitleDeedDetails implements ICE_AmendTitleDeedDetails {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_AmendTitleDeedDetails(BankFusionEnvironment env) {
	}

	public AbstractCE_AmendTitleDeedDetails() {
	}

	private com.misys.ce.types.ListSplitTitleDeedDtlsType f_IN_splitTitleDeedDtlsList = new com.misys.ce.types.ListSplitTitleDeedDtlsType();
	{
		com.misys.ce.types.SplitTitleDeeddtlsType var_019_splitTitleDeedDtlsList_splitTitleDeedDtls = new com.misys.ce.types.SplitTitleDeeddtlsType();

		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setSplitTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setSplitPercentage(Utils.getBIGDECIMALValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedPlanNo(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedType(Utils.getSTRINGValue(""));
		var_019_splitTitleDeedDtlsList_splitTitleDeedDtls.setTitleDeedPlotNo(Utils.getSTRINGValue(""));
		f_IN_splitTitleDeedDtlsList.addSplitTitleDeedDtls(0, var_019_splitTitleDeedDtlsList_splitTitleDeedDtls);
	}
	private com.misys.ce.types.TitleDeedDetailsType f_IN_titleDeedDtlsTypeDB = new com.misys.ce.types.TitleDeedDetailsType();
	{
		f_IN_titleDeedDtlsTypeDB.setTitleDeedType(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setVersionNumber(Utils.getINTEGERValue("0"));
		f_IN_titleDeedDtlsTypeDB.setTransactionNotes(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setValidFromHijri(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setTransactionDate(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsTypeDB.setLandPlotNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setBranchShortCode(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setValidFrom(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsTypeDB.setSplitIndicator(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setTitleDeedYear(Utils.getINTEGERValue("0"));
		f_IN_titleDeedDtlsTypeDB.setFarmLocationDescription(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setFarmLocation(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setLinkedToCollateral(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setTransactionType(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setTitleDeedNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setNotes(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setValidToHijri(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setTitleDeedSource(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setValidTo(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsTypeDB.setTitleDeedStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setLandPlanNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setAreaSize(Utils.getBIGDECIMALValue("0"));
		f_IN_titleDeedDtlsTypeDB.setSelect(Utils.getBOOLEANValue("false"));
		f_IN_titleDeedDtlsTypeDB.setTitleDeedIdpk(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setReasonForChange(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setDicissionStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsTypeDB.setRetailIndex(CommonConstants.EMPTY_STRING);
	}
	private com.misys.ce.types.FarmLandTitleDeeddtlsType f_IN_farmLandTitleDeedDtlsType = new com.misys.ce.types.FarmLandTitleDeeddtlsType();
	{
		f_IN_farmLandTitleDeedDtlsType.setContractNumber(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setContractDate(Utils.getDATEDefaultValue());
		f_IN_farmLandTitleDeedDtlsType.setFarmName(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setIrrigationSource(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setEngineerOfficeName(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setEngineerOfficeDate(Utils.getDATEDefaultValue());
		f_IN_farmLandTitleDeedDtlsType.setContractSource(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setSelect(Utils.getBOOLEANValue("false"));
		f_IN_farmLandTitleDeedDtlsType.setTitleDeedIdpk(CommonConstants.EMPTY_STRING);
		f_IN_farmLandTitleDeedDtlsType.setOwnerName(CommonConstants.EMPTY_STRING);
	}
	private com.misys.ce.types.TitleDeedDetailsType f_IN_titleDeedDtlsType = new com.misys.ce.types.TitleDeedDetailsType();
	{
		f_IN_titleDeedDtlsType.setTitleDeedType(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setVersionNumber(Utils.getINTEGERValue("0"));
		f_IN_titleDeedDtlsType.setTransactionNotes(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setValidFromHijri(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setTransactionDate(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsType.setLandPlotNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setValidFrom(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsType.setSplitIndicator(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setTitleDeedYear(Utils.getINTEGERValue("0"));
		f_IN_titleDeedDtlsType.setFarmLocation(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setLinkedToCollateral(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setTransactionType(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setTitleDeedNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setNotes(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setValidToHijri(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setTitleDeedSource(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setValidTo(Utils.getDATEDefaultValue());
		f_IN_titleDeedDtlsType.setTitleDeedStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setLandPlanNumber(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setAreaSize(Utils.getBIGDECIMALValue("0"));
		f_IN_titleDeedDtlsType.setSelect(Utils.getBOOLEANValue("false"));
		f_IN_titleDeedDtlsType.setTitleDeedIdpk(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setReasonForChange(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setDicissionStatus(CommonConstants.EMPTY_STRING);
		f_IN_titleDeedDtlsType.setRetailIndex(CommonConstants.EMPTY_STRING);
	}
	private com.misys.ce.types.ListShareHolderDtlsType f_IN_shareHolderDtlsList = new com.misys.ce.types.ListShareHolderDtlsType();
	{
		com.misys.ce.types.ShareHolderDtlsType var_019_shareHolderDtlsList_shareHolderDetails = new com.misys.ce.types.ShareHolderDtlsType();

		var_019_shareHolderDtlsList_shareHolderDetails.setShareHolderIdpk(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setTitleDeedId(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setSharePercentage(Utils.getBIGDECIMALValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setPartyName(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setOwnershipStatus(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setNotes(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setPartId(Utils.getSTRINGValue(""));
		var_019_shareHolderDtlsList_shareHolderDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_shareHolderDtlsList_shareHolderDetails.setOwnershipType(Utils.getSTRINGValue(""));
		f_IN_shareHolderDtlsList.addShareHolderDetails(0, var_019_shareHolderDtlsList_shareHolderDetails);
	}
	private com.misys.ce.types.ListFarmLandNeighbourDtlsType f_IN_farmLandNeighbourDtlsList = new com.misys.ce.types.ListFarmLandNeighbourDtlsType();
	{
		com.misys.ce.types.FarmLandNeighbourdtlsType var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls = new com.misys.ce.types.FarmLandNeighbourdtlsType();

		var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls.setFarmLandNeighbouridpk(Utils.getSTRINGValue(""));
		var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls.setPartyName(Utils.getSTRINGValue(""));
		var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls.setPartyId(Utils.getSTRINGValue(""));
		f_IN_farmLandNeighbourDtlsList.addFarmLandNeighbourDtls(0,
				var_019_farmLandNeighbourDtlsList_farmLandNeighbourDtls);
	}
	private com.misys.ce.types.ListFarmLandLocationDtlsType f_IN_farmLandLocationDtlsList = new com.misys.ce.types.ListFarmLandLocationDtlsType();
	{
		com.misys.ce.types.FarmLandLocationdtlsType var_019_farmLandLocationDtlsList_farmLandLocationDtls = new com.misys.ce.types.FarmLandLocationdtlsType();

		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setContractNumber(Utils.getSTRINGValue(""));
		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setLength(Utils.getBIGDECIMALValue(""));
		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setFarmLandLocationidpk(Utils.getSTRINGValue(""));
		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setDirection(Utils.getSTRINGValue(""));
		var_019_farmLandLocationDtlsList_farmLandLocationDtls.setBordering(Utils.getSTRINGValue(""));
		f_IN_farmLandLocationDtlsList.addFarmLandLocationDtls(0, var_019_farmLandLocationDtlsList_farmLandLocationDtls);
	}
	private com.misys.ce.types.ListTitleDeedLocDtlsType f_IN_titleDeedLocationDtlsList = new com.misys.ce.types.ListTitleDeedLocDtlsType();
	{
		com.misys.ce.types.TitleDeedLocationdtlsType var_019_titleDeedLocationDtlsList_titleDeedLocDtls = new com.misys.ce.types.TitleDeedLocationdtlsType();

		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setLocationNorthDegree(Utils.getBIGDECIMALValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setLocationNorthSection(Utils.getBIGDECIMALValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setSerial(Utils.getINTEGERValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setLocationEastSection(Utils.getBIGDECIMALValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setTitleDeedLocIdpk(Utils.getSTRINGValue(""));
		var_019_titleDeedLocationDtlsList_titleDeedLocDtls.setLocationEastDegree(Utils.getBIGDECIMALValue(""));
		f_IN_titleDeedLocationDtlsList.addTitleDeedLocDtls(0, var_019_titleDeedLocationDtlsList_titleDeedLocDtls);
	}
	private com.misys.ce.types.ListParentTitleDeedDtlsType f_IN_parentTitleDeedDtlsList = new com.misys.ce.types.ListParentTitleDeedDtlsType();
	{
		com.misys.ce.types.ParentTitleDeeddtlsType var_019_parentTitleDeedDtlsList_parentTitleDeedDtls = new com.misys.ce.types.ParentTitleDeeddtlsType();

		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedPlanNo(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setParentTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedType(Utils.getSTRINGValue(""));
		var_019_parentTitleDeedDtlsList_parentTitleDeedDtls.setTitleDeedPlotNo(Utils.getSTRINGValue(""));
		f_IN_parentTitleDeedDtlsList.addParentTitleDeedDtls(0, var_019_parentTitleDeedDtlsList_parentTitleDeedDtls);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public com.misys.ce.types.ListSplitTitleDeedDtlsType getF_IN_splitTitleDeedDtlsList() {
		return f_IN_splitTitleDeedDtlsList;
	}

	public void setF_IN_splitTitleDeedDtlsList(com.misys.ce.types.ListSplitTitleDeedDtlsType param) {
		f_IN_splitTitleDeedDtlsList = param;
	}

	public com.misys.ce.types.TitleDeedDetailsType getF_IN_titleDeedDtlsTypeDB() {
		return f_IN_titleDeedDtlsTypeDB;
	}

	public void setF_IN_titleDeedDtlsTypeDB(com.misys.ce.types.TitleDeedDetailsType param) {
		f_IN_titleDeedDtlsTypeDB = param;
	}

	public com.misys.ce.types.FarmLandTitleDeeddtlsType getF_IN_farmLandTitleDeedDtlsType() {
		return f_IN_farmLandTitleDeedDtlsType;
	}

	public void setF_IN_farmLandTitleDeedDtlsType(com.misys.ce.types.FarmLandTitleDeeddtlsType param) {
		f_IN_farmLandTitleDeedDtlsType = param;
	}

	public com.misys.ce.types.TitleDeedDetailsType getF_IN_titleDeedDtlsType() {
		return f_IN_titleDeedDtlsType;
	}

	public void setF_IN_titleDeedDtlsType(com.misys.ce.types.TitleDeedDetailsType param) {
		f_IN_titleDeedDtlsType = param;
	}

	public com.misys.ce.types.ListShareHolderDtlsType getF_IN_shareHolderDtlsList() {
		return f_IN_shareHolderDtlsList;
	}

	public void setF_IN_shareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param) {
		f_IN_shareHolderDtlsList = param;
	}

	public com.misys.ce.types.ListFarmLandNeighbourDtlsType getF_IN_farmLandNeighbourDtlsList() {
		return f_IN_farmLandNeighbourDtlsList;
	}

	public void setF_IN_farmLandNeighbourDtlsList(com.misys.ce.types.ListFarmLandNeighbourDtlsType param) {
		f_IN_farmLandNeighbourDtlsList = param;
	}

	public com.misys.ce.types.ListFarmLandLocationDtlsType getF_IN_farmLandLocationDtlsList() {
		return f_IN_farmLandLocationDtlsList;
	}

	public void setF_IN_farmLandLocationDtlsList(com.misys.ce.types.ListFarmLandLocationDtlsType param) {
		f_IN_farmLandLocationDtlsList = param;
	}

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_IN_titleDeedLocationDtlsList() {
		return f_IN_titleDeedLocationDtlsList;
	}

	public void setF_IN_titleDeedLocationDtlsList(com.misys.ce.types.ListTitleDeedLocDtlsType param) {
		f_IN_titleDeedLocationDtlsList = param;
	}

	public com.misys.ce.types.ListParentTitleDeedDtlsType getF_IN_parentTitleDeedDtlsList() {
		return f_IN_parentTitleDeedDtlsList;
	}

	public void setF_IN_parentTitleDeedDtlsList(com.misys.ce.types.ListParentTitleDeedDtlsType param) {
		f_IN_parentTitleDeedDtlsList = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_splitTitleDeedDtlsList, f_IN_splitTitleDeedDtlsList);
		dataInMap.put(IN_titleDeedDtlsTypeDB, f_IN_titleDeedDtlsTypeDB);
		dataInMap.put(IN_farmLandTitleDeedDtlsType, f_IN_farmLandTitleDeedDtlsType);
		dataInMap.put(IN_titleDeedDtlsType, f_IN_titleDeedDtlsType);
		dataInMap.put(IN_shareHolderDtlsList, f_IN_shareHolderDtlsList);
		dataInMap.put(IN_farmLandNeighbourDtlsList, f_IN_farmLandNeighbourDtlsList);
		dataInMap.put(IN_farmLandLocationDtlsList, f_IN_farmLandLocationDtlsList);
		dataInMap.put(IN_titleDeedLocationDtlsList, f_IN_titleDeedLocationDtlsList);
		dataInMap.put(IN_parentTitleDeedDtlsList, f_IN_parentTitleDeedDtlsList);
		return dataInMap;
	}
}