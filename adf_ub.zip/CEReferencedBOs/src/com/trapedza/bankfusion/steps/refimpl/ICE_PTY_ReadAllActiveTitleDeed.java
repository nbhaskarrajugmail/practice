
package com.trapedza.bankfusion.steps.refimpl;

import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_PTY_ReadAllActiveTitleDeed
		extends com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep,
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_FetchAllTitleDeeds = "FetchAllTitleDeeds";
	public static final String IN_TitleDeedNumber = "TitleDeedNumber";
	public static final String IN_PagedQuery = "PagedQuery";
	public static final String IN_SearchTitleDeedDtlsRq = "SearchTitleDeedDtlsRq";
	public static final String IN_PAGINGSUPPORT = "PAGINGSUPPORT";
	public static final String OUT_SearchTitleDeedDtlsRs = "SearchTitleDeedDtlsRs";
	public static final String OUT_PaginatedData = "PaginatedData";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public Boolean isF_IN_FetchAllTitleDeeds();

	public void setF_IN_FetchAllTitleDeeds(Boolean param);

	public String getF_IN_TitleDeedNumber();

	public void setF_IN_TitleDeedNumber(String param);

	public bf.com.misys.bankfusion.attributes.PagedQuery getF_IN_PagedQuery();

	public void setF_IN_PagedQuery(bf.com.misys.bankfusion.attributes.PagedQuery param);

	public com.misys.ce.types.SearchTitleDeedDtlsRqType getF_IN_SearchTitleDeedDtlsRq();

	public void setF_IN_SearchTitleDeedDtlsRq(com.misys.ce.types.SearchTitleDeedDtlsRqType param);

	public String getF_IN_PAGINGSUPPORT();

	public void setF_IN_PAGINGSUPPORT(String param);

	public Map getInDataMap();

	public com.misys.ce.types.SearchTitleDeedDtlsRsType getF_OUT_SearchTitleDeedDtlsRs();

	public void setF_OUT_SearchTitleDeedDtlsRs(com.misys.ce.types.SearchTitleDeedDtlsRsType param);

	public Object getF_OUT_PaginatedData();

	public void setF_OUT_PaginatedData(Object param);

	public Map getOutDataMap();
}