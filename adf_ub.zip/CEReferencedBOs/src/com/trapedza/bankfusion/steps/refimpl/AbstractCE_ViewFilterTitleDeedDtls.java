
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_ViewFilterTitleDeedDtls implements ICE_ViewFilterTitleDeedDtls {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_ViewFilterTitleDeedDtls(BankFusionEnvironment env) {
	}

	public AbstractCE_ViewFilterTitleDeedDtls() {
	}

	private String f_IN_titleDeedId = CommonConstants.EMPTY_STRING;

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_IN_listTitleDeedDtlsType = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_019_listTitleDeedDtlsType_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setBranchShortCode(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setFarmLocationDescription(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_IN_listTitleDeedDtlsType.addTitleDeedDetails(0, var_019_listTitleDeedDtlsType_titleDeedDetails);
	}
	private Integer f_IN_versionNumber = CommonConstants.INTEGER_ZERO;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_OUT_listTitleDeedDtlsType = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_020_listTitleDeedDtlsType_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setBranchShortCode(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setFarmLocationDescription(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_listTitleDeedDtlsType_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_OUT_listTitleDeedDtlsType.addTitleDeedDetails(0, var_020_listTitleDeedDtlsType_titleDeedDetails);
	}
	private com.misys.ce.types.ListTitleDeedLocDtlsType f_OUT_titleDeedLocList = new com.misys.ce.types.ListTitleDeedLocDtlsType();
	{
		com.misys.ce.types.TitleDeedLocationdtlsType var_020_titleDeedLocList_titleDeedLocDtls = new com.misys.ce.types.TitleDeedLocationdtlsType();

		var_020_titleDeedLocList_titleDeedLocDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_020_titleDeedLocList_titleDeedLocDtls.setLocationNorthDegree(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setLocationNorthSection(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setSerial(Utils.getINTEGERValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setLocationEastSection(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setTitleDeedLocIdpk(Utils.getSTRINGValue(""));
		var_020_titleDeedLocList_titleDeedLocDtls.setLocationEastDegree(Utils.getBIGDECIMALValue(""));
		f_OUT_titleDeedLocList.addTitleDeedLocDtls(0, var_020_titleDeedLocList_titleDeedLocDtls);
	}
	private com.misys.ce.types.ListShareHolderDtlsType f_OUT_shareHolderDtlsList = new com.misys.ce.types.ListShareHolderDtlsType();
	{
		com.misys.ce.types.ShareHolderDtlsType var_020_shareHolderDtlsList_shareHolderDetails = new com.misys.ce.types.ShareHolderDtlsType();

		var_020_shareHolderDtlsList_shareHolderDetails.setShareHolderIdpk(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setTitleDeedId(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setSharePercentage(Utils.getBIGDECIMALValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setPartyName(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setOwnershipStatus(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setPartId(Utils.getSTRINGValue(""));
		var_020_shareHolderDtlsList_shareHolderDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_shareHolderDtlsList_shareHolderDetails.setOwnershipType(Utils.getSTRINGValue(""));
		f_OUT_shareHolderDtlsList.addShareHolderDetails(0, var_020_shareHolderDtlsList_shareHolderDetails);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_titleDeedId() {
		return f_IN_titleDeedId;
	}

	public void setF_IN_titleDeedId(String param) {
		f_IN_titleDeedId = param;
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_IN_listTitleDeedDtlsType() {
		return f_IN_listTitleDeedDtlsType;
	}

	public void setF_IN_listTitleDeedDtlsType(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_IN_listTitleDeedDtlsType = param;
	}

	public Integer getF_IN_versionNumber() {
		return f_IN_versionNumber;
	}

	public void setF_IN_versionNumber(Integer param) {
		f_IN_versionNumber = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_titleDeedId, f_IN_titleDeedId);
		dataInMap.put(IN_listTitleDeedDtlsType, f_IN_listTitleDeedDtlsType);
		dataInMap.put(IN_versionNumber, f_IN_versionNumber);
		return dataInMap;
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_listTitleDeedDtlsType() {
		return f_OUT_listTitleDeedDtlsType;
	}

	public void setF_OUT_listTitleDeedDtlsType(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_OUT_listTitleDeedDtlsType = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public com.misys.ce.types.ListTitleDeedLocDtlsType getF_OUT_titleDeedLocList() {
		return f_OUT_titleDeedLocList;
	}

	public void setF_OUT_titleDeedLocList(com.misys.ce.types.ListTitleDeedLocDtlsType param) {
		f_OUT_titleDeedLocList = param;
	}

	public com.misys.ce.types.ListShareHolderDtlsType getF_OUT_shareHolderDtlsList() {
		return f_OUT_shareHolderDtlsList;
	}

	public void setF_OUT_shareHolderDtlsList(com.misys.ce.types.ListShareHolderDtlsType param) {
		f_OUT_shareHolderDtlsList = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_listTitleDeedDtlsType, f_OUT_listTitleDeedDtlsType);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_titleDeedLocList, f_OUT_titleDeedLocList);
		dataOutMap.put(OUT_shareHolderDtlsList, f_OUT_shareHolderDtlsList);
		return dataOutMap;
	}
}