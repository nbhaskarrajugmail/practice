
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_PTY_PrepareDedupCheck implements ICE_PTY_PrepareDedupCheck {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PTY_PrepareDedupCheck(BankFusionEnvironment env) {
	}

	public AbstractCE_PTY_PrepareDedupCheck() {
	}

	private bf.com.misys.cbs.types.PartyBasicDtls f_IN_partyBasicDtls = new bf.com.misys.cbs.types.PartyBasicDtls();
	{
		f_IN_partyBasicDtls.setSigTxnReference(CommonConstants.EMPTY_STRING);
		bf.com.misys.cbs.types.PartyComplyStsDtls var_019_partyBasicDtls_partyComplyStsDtls = new bf.com.misys.cbs.types.PartyComplyStsDtls();

		bf.com.misys.cbs.types.PartyComplyStsDtl var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl = new bf.com.misys.cbs.types.PartyComplyStsDtl();

		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyCheck(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl
				.setExtensionDetails(var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl_extensionDetails);

		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyExpiry(Utils.getDATEValue(""));
		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplyDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl.setPartyComplySts(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyComplyStsDtls
				.setPartyComplyStsDtl(var_019_partyBasicDtls_partyComplyStsDtls_partyComplyStsDtl);

		f_IN_partyBasicDtls.addPartyComplyStsDtls(0, var_019_partyBasicDtls_partyComplyStsDtls);

		f_IN_partyBasicDtls.setPartyStatus(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setPartyAlternativeId(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setAssignedBranch(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyLocalityDtl var_019_partyBasicDtls_partyLocalityDtl = new bf.com.misys.cbs.types.PartyLocalityDtl();

		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyLocalityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyLocalityDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyLocalityDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyLocalityDtl
				.setExtensionDetails(var_019_partyBasicDtls_partyLocalityDtl_extensionDetails);

		var_019_partyBasicDtls_partyLocalityDtl.setIsPrivate(Utils.getBOOLEANValue(""));
		var_019_partyBasicDtls_partyLocalityDtl.setIsInternational(Utils.getBOOLEANValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_partyBasicDtls_partyLocalityDtl_localityDtls = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_partyBasicDtls_partyLocalityDtl_localityDtls.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_partyLocalityDtl_localityDtls.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyLocalityDtl_localityDtls.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyLocalityDtl_localityDtls
				.setExtensionDetails(var_019_partyBasicDtls_partyLocalityDtl_localityDtls_extensionDetails);

		var_019_partyBasicDtls_partyLocalityDtl.addLocalityDtls(0,
				var_019_partyBasicDtls_partyLocalityDtl_localityDtls);

		f_IN_partyBasicDtls.setPartyLocalityDtl(var_019_partyBasicDtls_partyLocalityDtl);

		f_IN_partyBasicDtls.setEquivPartyName(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setIsMultihost(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setRelationshipManager(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setPartyType(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setCountryOfDomicile(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyLineOfBusinessDtls var_019_partyBasicDtls_PartyLineOfBusinessDtls = new bf.com.misys.cbs.types.PartyLineOfBusinessDtls();

		bf.com.misys.cbs.types.PartyLineOfBusinessDetail var_019_partyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail = new bf.com.misys.cbs.types.PartyLineOfBusinessDetail();

		var_019_partyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail
				.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail
				.setLineOfBusiness(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_PartyLineOfBusinessDtls.addPartyLineOfBusinessDetail(0,
				var_019_partyBasicDtls_PartyLineOfBusinessDtls_PartyLineOfBusinessDetail);

		f_IN_partyBasicDtls.setPartyLineOfBusinessDtls(var_019_partyBasicDtls_PartyLineOfBusinessDtls);

		f_IN_partyBasicDtls.setName(CommonConstants.EMPTY_STRING);
		f_IN_partyBasicDtls.setIsTaxPayer(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setLocality(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setNameType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyIdDtls var_019_partyBasicDtls_partyIdDtls = new bf.com.misys.cbs.types.PartyIdDtls();

		bf.com.misys.cbs.types.PartyIdDtl var_019_partyBasicDtls_partyIdDtls_partyIdDtl = new bf.com.misys.cbs.types.PartyIdDtl();

		var_019_partyBasicDtls_partyIdDtls_partyIdDtl.setIdReference(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyIdDtls_partyIdDtl
				.setExtensionDetails(var_019_partyBasicDtls_partyIdDtls_partyIdDtl_extensionDetails);

		var_019_partyBasicDtls_partyIdDtls_partyIdDtl.setIdType(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyIdDtls.addPartyIdDtl(0, var_019_partyBasicDtls_partyIdDtls_partyIdDtl);

		f_IN_partyBasicDtls.setPartyIdDtls(var_019_partyBasicDtls_partyIdDtls);

		f_IN_partyBasicDtls.setCloseDate(Utils.getDATEValue(""));
		f_IN_partyBasicDtls.setNationality(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setLanguage(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setDateTo(Utils.getDATEValue(""));
		f_IN_partyBasicDtls.setOriginationDate(Utils.getDATEValue(""));
		f_IN_partyBasicDtls.setDateFrom(Utils.getDATEValue(""));
		f_IN_partyBasicDtls.setLastName(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setDeleteDate(Utils.getDATEValue(""));
		f_IN_partyBasicDtls.setCountryOfRisk(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setSigStatus(CommonConstants.EMPTY_STRING);
		f_IN_partyBasicDtls.setIsPreferred(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setDefaultBranchCode(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setIsMobile(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setTitle(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setAltRiskCountry(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setShortName(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setIsConsolidateStatement(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setMiddleName(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyRoles var_019_partyBasicDtls_partyRoles = new bf.com.misys.cbs.types.PartyRoles();

		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyRoles_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyRoles_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyRoles_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyRoles.setExtensionDetails(var_019_partyBasicDtls_partyRoles_extensionDetails);

		bf.com.misys.cbs.types.PartyRole var_019_partyBasicDtls_partyRoles_partyRole = new bf.com.misys.cbs.types.PartyRole();

		var_019_partyBasicDtls_partyRoles_partyRole.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_partyRoles_partyRole.setRoleReason(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyRoles_partyRole.setPartyRole(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_partyBasicDtls_partyRoles_partyRole_localityDtl = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyRoles_partyRole_localityDtl
				.setExtensionDetails(var_019_partyBasicDtls_partyRoles_partyRole_localityDtl_extensionDetails);

		var_019_partyBasicDtls_partyRoles_partyRole
				.setLocalityDtl(var_019_partyBasicDtls_partyRoles_partyRole_localityDtl);

		var_019_partyBasicDtls_partyRoles_partyRole.setEffectiveDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_partyRoles.setPartyRole(var_019_partyBasicDtls_partyRoles_partyRole);

		f_IN_partyBasicDtls.addPartyRoles(0, var_019_partyBasicDtls_partyRoles);

		f_IN_partyBasicDtls.setFirstName(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		f_IN_partyBasicDtls.setExtensionDetails(var_019_partyBasicDtls_extensionDetails);

		f_IN_partyBasicDtls.setDepartment(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setPartyCategory(CommonConstants.EMPTY_STRING);
		f_IN_partyBasicDtls.setDateOfBirth(Utils.getDATEValue(""));
		bf.com.misys.cbs.types.ContactDtls var_019_partyBasicDtls_contactDtls = new bf.com.misys.cbs.types.ContactDtls();

		bf.com.misys.cbs.types.ContactDtl var_019_partyBasicDtls_contactDtls_contactDtl = new bf.com.misys.cbs.types.ContactDtl();

		var_019_partyBasicDtls_contactDtls_contactDtl.setContactTelNum(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setAreaCode(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactDtlId(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactType(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setCountryCode(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setStartDate(Utils.getDATEDefaultValue());
		var_019_partyBasicDtls_contactDtls_contactDtl.setIsApplicable(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactAddressId(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactEmailId(CommonConstants.EMPTY_STRING);
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_contactDtls_contactDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_contactDtls_contactDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_contactDtls_contactDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_contactDtls_contactDtl
				.setExtensionDetails(var_019_partyBasicDtls_contactDtls_contactDtl_extensionDetails);

		var_019_partyBasicDtls_contactDtls_contactDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_contactDtls_contactDtl.setPrefOrder(Utils.getINTEGERValue("0"));
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactDesc(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setEndDate(Utils.getDATEDefaultValue());
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactMethod(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactPosition(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactName(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls_contactDtl.setContactAltTel(CommonConstants.EMPTY_STRING);
		var_019_partyBasicDtls_contactDtls.addContactDtl(0, var_019_partyBasicDtls_contactDtls_contactDtl);

		f_IN_partyBasicDtls.setContactDtls(var_019_partyBasicDtls_contactDtls);

		f_IN_partyBasicDtls.setSuffix(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyStatusDtls var_019_partyBasicDtls_altStsDtls = new bf.com.misys.cbs.types.PartyStatusDtls();

		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_altStsDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_altStsDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_altStsDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_altStsDtls.setExtensionDetails(var_019_partyBasicDtls_altStsDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyStatusDtl var_019_partyBasicDtls_altStsDtls_partyStatusDtl = new bf.com.misys.cbs.types.PartyStatusDtl();

		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl
				.setExtensionDetails(var_019_partyBasicDtls_altStsDtls_partyStatusDtl_extensionDetails);

		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setStatusCode(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setDateTo(Utils.getDATEValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setChangeReason(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setDateFrom(Utils.getDATEValue(""));
		var_019_partyBasicDtls_altStsDtls_partyStatusDtl.setStatusParent(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_altStsDtls.setPartyStatusDtl(var_019_partyBasicDtls_altStsDtls_partyStatusDtl);

		f_IN_partyBasicDtls.addAltStsDtls(0, var_019_partyBasicDtls_altStsDtls);

		bf.com.misys.cbs.types.PartyPublicStsDtls var_019_partyBasicDtls_publicStsDtls = new bf.com.misys.cbs.types.PartyPublicStsDtls();

		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_publicStsDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_publicStsDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls.setExtensionDetails(var_019_partyBasicDtls_publicStsDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyPublicStsDtl var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl = new bf.com.misys.cbs.types.PartyPublicStsDtl();

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setStsChangeReason(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusStartDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusExpiryDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setIsCustodial(Utils.getBOOLEANValue(""));
		bf.com.misys.cbs.types.LocalityDtl var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl = new bf.com.misys.cbs.types.LocalityDtl();

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl
				.setRegionOfOperation(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl
				.setCountryOfOperation(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl.setExtensionDetails(
				var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl_extensionDetails);

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl
				.setLocalityDtl(var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_localityDtl);

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setPartyPublicSts(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl
				.setExtensionDetails(var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl_extensionDetails);

		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setCourtJudgeType(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl.setStatusEndDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_publicStsDtls
				.setPartyPublicStsDtl(var_019_partyBasicDtls_publicStsDtls_partyPublicStsDtl);

		f_IN_partyBasicDtls.addPublicStsDtls(0, var_019_partyBasicDtls_publicStsDtls);

		f_IN_partyBasicDtls.setPartyId(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setIsInternet(Utils.getBOOLEANValue(""));
		f_IN_partyBasicDtls.setPartySubType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.PartyAddrDtls var_019_partyBasicDtls_partyAddrDtls = new bf.com.misys.cbs.types.PartyAddrDtls();

		var_019_partyBasicDtls_partyAddrDtls.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.PartyAddrSpecDtl var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail = new bf.com.misys.cbs.types.PartyAddrSpecDtl();

		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setFaoName(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setToDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setAddressType(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail
				.setExtensionDetails(var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail_extensionDetails);

		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setDunsNumber(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setFromDate(Utils.getDATEValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setStatusAtTheAddress(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail.setDefaultAddress(Utils.getBOOLEANValue("true"));
		var_019_partyBasicDtls_partyAddrDtls
				.setPartAddressSpecDetail(var_019_partyBasicDtls_partyAddrDtls_partAddressSpecDetail);

		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyAddrDtls_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyAddrDtls_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls.setExtensionDetails(var_019_partyBasicDtls_partyAddrDtls_extensionDetails);

		bf.com.misys.cbs.types.PartyAddrDtl var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails = new bf.com.misys.cbs.types.PartyAddrDtl();

		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine9(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine8(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setTownOrCity(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine7(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine6(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setCountry(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine5(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine4(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine3(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine2(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine1(Utils.getSTRINGValue(""));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails
				.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails
				.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails
				.setExtensionDetails(var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails_extensionDetails);

		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setRegion(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setPostCode(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails.setAddressLine10(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_partyAddrDtls
				.setPartyAddressDetails(var_019_partyBasicDtls_partyAddrDtls_partyAddressDetails);

		f_IN_partyBasicDtls.addPartyAddrDtls(0, var_019_partyBasicDtls_partyAddrDtls);

		bf.com.misys.cbs.types.PartyStatusDtl var_019_partyBasicDtls_bankStsDtl = new bf.com.misys.cbs.types.PartyStatusDtl();

		var_019_partyBasicDtls_bankStsDtl.setSelect(Utils.getBOOLEANValue("false"));
		bf.com.misys.cbs.types.ExtensionDetails var_019_partyBasicDtls_bankStsDtl_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_partyBasicDtls_bankStsDtl_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_bankStsDtl_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_partyBasicDtls_bankStsDtl.setExtensionDetails(var_019_partyBasicDtls_bankStsDtl_extensionDetails);

		var_019_partyBasicDtls_bankStsDtl.setStatusCode(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_bankStsDtl.setDateTo(Utils.getDATEValue(""));
		var_019_partyBasicDtls_bankStsDtl.setChangeReason(Utils.getSTRINGValue(""));
		var_019_partyBasicDtls_bankStsDtl.setDateFrom(Utils.getDATEValue(""));
		var_019_partyBasicDtls_bankStsDtl.setStatusParent(Utils.getSTRINGValue(""));
		f_IN_partyBasicDtls.setBankStsDtl(var_019_partyBasicDtls_bankStsDtl);
	}
	private String f_IN_nationalId = CommonConstants.EMPTY_STRING;

	private String f_IN_middleName = CommonConstants.EMPTY_STRING;

	private String f_IN_enterpriseName = CommonConstants.EMPTY_STRING;

	private String f_IN_dateOfBirth = CommonConstants.EMPTY_STRING;

	private String f_IN_registeredID = CommonConstants.EMPTY_STRING;

	private String f_IN_gender = CommonConstants.EMPTY_STRING;

	private String f_IN_firstName = CommonConstants.EMPTY_STRING;

	private bf.com.misys.cbs.types.ReadPtyDedupConfigOp f_IN_readPtyDedupConfigOp = new bf.com.misys.cbs.types.ReadPtyDedupConfigOp();
	{
		bf.com.misys.cbs.types.DedupeKeys var_019_readPtyDedupConfigOp_perPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_019_readPtyDedupConfigOp_perPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_019_readPtyDedupConfigOp_perPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_019_readPtyDedupConfigOp_perPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_019_readPtyDedupConfigOp_perPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_IN_readPtyDedupConfigOp.addPerPtySearchKeys(0, var_019_readPtyDedupConfigOp_perPtySearchKeys);

		bf.com.misys.cbs.types.ExtensionDetails var_019_readPtyDedupConfigOp_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_019_readPtyDedupConfigOp_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_019_readPtyDedupConfigOp_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		f_IN_readPtyDedupConfigOp.setExtensionDetails(var_019_readPtyDedupConfigOp_extensionDetails);

		bf.com.misys.cbs.types.DedupeKeys var_019_readPtyDedupConfigOp_entPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_019_readPtyDedupConfigOp_entPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_019_readPtyDedupConfigOp_entPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_019_readPtyDedupConfigOp_entPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_019_readPtyDedupConfigOp_entPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_IN_readPtyDedupConfigOp.addEntPtySearchKeys(0, var_019_readPtyDedupConfigOp_entPtySearchKeys);

		bf.com.misys.cbs.types.ReferPtyStatus var_019_readPtyDedupConfigOp_referOnMatchStatus = new bf.com.misys.cbs.types.ReferPtyStatus();

		var_019_readPtyDedupConfigOp_referOnMatchStatus.setBankPtyStatus(Utils.getSTRINGValue(""));
		f_IN_readPtyDedupConfigOp.addReferOnMatchStatus(0, var_019_readPtyDedupConfigOp_referOnMatchStatus);

		bf.com.misys.cbs.types.DedupeRules var_019_readPtyDedupConfigOp_dedupeConfigRules = new bf.com.misys.cbs.types.DedupeRules();

		var_019_readPtyDedupConfigOp_dedupeConfigRules.setNotifyIndividualHits(Utils.getBOOLEANValue("false"));
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setRefDeclinedPty(Utils.getBOOLEANValue("false"));
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setForcedReviewPer(CommonConstants.EMPTY_STRING);
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setForcedReviewNum(Utils.getINTEGERValue("0"));
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setDecPtyAcceptPer(CommonConstants.EMPTY_STRING);
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setDecPtyAcceptNum(Utils.getINTEGERValue("0"));
		var_019_readPtyDedupConfigOp_dedupeConfigRules.setReferMatchReject(Utils.getBOOLEANValue("false"));
		f_IN_readPtyDedupConfigOp.setDedupeConfigRules(var_019_readPtyDedupConfigOp_dedupeConfigRules);

		bf.com.misys.cbs.types.DedupeKeys var_019_readPtyDedupConfigOp_repGrpPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_019_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_019_readPtyDedupConfigOp_repGrpPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_019_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_019_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_IN_readPtyDedupConfigOp.addRepGrpPtySearchKeys(0, var_019_readPtyDedupConfigOp_repGrpPtySearchKeys);
	}
	private String f_IN_lastName = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private bf.com.misys.cbs.types.ReadPtyDedupConfigOp f_OUT_readPtyDedupConfigOp = new bf.com.misys.cbs.types.ReadPtyDedupConfigOp();
	{
		bf.com.misys.cbs.types.DedupeKeys var_020_readPtyDedupConfigOp_perPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_020_readPtyDedupConfigOp_perPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_020_readPtyDedupConfigOp_perPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_020_readPtyDedupConfigOp_perPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_020_readPtyDedupConfigOp_perPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_OUT_readPtyDedupConfigOp.addPerPtySearchKeys(0, var_020_readPtyDedupConfigOp_perPtySearchKeys);

		bf.com.misys.cbs.types.ExtensionDetails var_020_readPtyDedupConfigOp_extensionDetails = new bf.com.misys.cbs.types.ExtensionDetails();

		var_020_readPtyDedupConfigOp_extensionDetails.setHostExtension(Utils.getJAVA_OBJECTValue(""));
		var_020_readPtyDedupConfigOp_extensionDetails.setUserExtension(Utils.getJAVA_OBJECTValue(""));
		f_OUT_readPtyDedupConfigOp.setExtensionDetails(var_020_readPtyDedupConfigOp_extensionDetails);

		bf.com.misys.cbs.types.DedupeKeys var_020_readPtyDedupConfigOp_entPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_020_readPtyDedupConfigOp_entPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_020_readPtyDedupConfigOp_entPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_020_readPtyDedupConfigOp_entPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_020_readPtyDedupConfigOp_entPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_OUT_readPtyDedupConfigOp.addEntPtySearchKeys(0, var_020_readPtyDedupConfigOp_entPtySearchKeys);

		bf.com.misys.cbs.types.ReferPtyStatus var_020_readPtyDedupConfigOp_referOnMatchStatus = new bf.com.misys.cbs.types.ReferPtyStatus();

		var_020_readPtyDedupConfigOp_referOnMatchStatus.setBankPtyStatus(Utils.getSTRINGValue(""));
		f_OUT_readPtyDedupConfigOp.addReferOnMatchStatus(0, var_020_readPtyDedupConfigOp_referOnMatchStatus);

		bf.com.misys.cbs.types.DedupeRules var_020_readPtyDedupConfigOp_dedupeConfigRules = new bf.com.misys.cbs.types.DedupeRules();

		var_020_readPtyDedupConfigOp_dedupeConfigRules.setNotifyIndividualHits(Utils.getBOOLEANValue("false"));
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setRefDeclinedPty(Utils.getBOOLEANValue("false"));
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setForcedReviewPer(CommonConstants.EMPTY_STRING);
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setForcedReviewNum(Utils.getINTEGERValue("0"));
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setDecPtyAcceptPer(CommonConstants.EMPTY_STRING);
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setDecPtyAcceptNum(Utils.getINTEGERValue("0"));
		var_020_readPtyDedupConfigOp_dedupeConfigRules.setReferMatchReject(Utils.getBOOLEANValue("false"));
		f_OUT_readPtyDedupConfigOp.setDedupeConfigRules(var_020_readPtyDedupConfigOp_dedupeConfigRules);

		bf.com.misys.cbs.types.DedupeKeys var_020_readPtyDedupConfigOp_repGrpPtySearchKeys = new bf.com.misys.cbs.types.DedupeKeys();

		var_020_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchPriority(Utils.getINTEGERValue(""));
		var_020_readPtyDedupConfigOp_repGrpPtySearchKeys.setSelect(Utils.getBOOLEANValue("true"));
		var_020_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchValue(Utils.getSTRINGValue(""));
		var_020_readPtyDedupConfigOp_repGrpPtySearchKeys.setSearchKey(Utils.getSTRINGValue(""));
		f_OUT_readPtyDedupConfigOp.addRepGrpPtySearchKeys(0, var_020_readPtyDedupConfigOp_repGrpPtySearchKeys);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.com.misys.cbs.types.PartyBasicDtls getF_IN_partyBasicDtls() {
		return f_IN_partyBasicDtls;
	}

	public void setF_IN_partyBasicDtls(bf.com.misys.cbs.types.PartyBasicDtls param) {
		f_IN_partyBasicDtls = param;
	}

	public String getF_IN_nationalId() {
		return f_IN_nationalId;
	}

	public void setF_IN_nationalId(String param) {
		f_IN_nationalId = param;
	}

	public String getF_IN_middleName() {
		return f_IN_middleName;
	}

	public void setF_IN_middleName(String param) {
		f_IN_middleName = param;
	}

	public String getF_IN_enterpriseName() {
		return f_IN_enterpriseName;
	}

	public void setF_IN_enterpriseName(String param) {
		f_IN_enterpriseName = param;
	}

	public String getF_IN_dateOfBirth() {
		return f_IN_dateOfBirth;
	}

	public void setF_IN_dateOfBirth(String param) {
		f_IN_dateOfBirth = param;
	}

	public String getF_IN_registeredID() {
		return f_IN_registeredID;
	}

	public void setF_IN_registeredID(String param) {
		f_IN_registeredID = param;
	}

	public String getF_IN_gender() {
		return f_IN_gender;
	}

	public void setF_IN_gender(String param) {
		f_IN_gender = param;
	}

	public String getF_IN_firstName() {
		return f_IN_firstName;
	}

	public void setF_IN_firstName(String param) {
		f_IN_firstName = param;
	}

	public bf.com.misys.cbs.types.ReadPtyDedupConfigOp getF_IN_readPtyDedupConfigOp() {
		return f_IN_readPtyDedupConfigOp;
	}

	public void setF_IN_readPtyDedupConfigOp(bf.com.misys.cbs.types.ReadPtyDedupConfigOp param) {
		f_IN_readPtyDedupConfigOp = param;
	}

	public String getF_IN_lastName() {
		return f_IN_lastName;
	}

	public void setF_IN_lastName(String param) {
		f_IN_lastName = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_partyBasicDtls, f_IN_partyBasicDtls);
		dataInMap.put(IN_nationalId, f_IN_nationalId);
		dataInMap.put(IN_middleName, f_IN_middleName);
		dataInMap.put(IN_enterpriseName, f_IN_enterpriseName);
		dataInMap.put(IN_dateOfBirth, f_IN_dateOfBirth);
		dataInMap.put(IN_registeredID, f_IN_registeredID);
		dataInMap.put(IN_gender, f_IN_gender);
		dataInMap.put(IN_firstName, f_IN_firstName);
		dataInMap.put(IN_readPtyDedupConfigOp, f_IN_readPtyDedupConfigOp);
		dataInMap.put(IN_lastName, f_IN_lastName);
		return dataInMap;
	}

	public bf.com.misys.cbs.types.ReadPtyDedupConfigOp getF_OUT_readPtyDedupConfigOp() {
		return f_OUT_readPtyDedupConfigOp;
	}

	public void setF_OUT_readPtyDedupConfigOp(bf.com.misys.cbs.types.ReadPtyDedupConfigOp param) {
		f_OUT_readPtyDedupConfigOp = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_readPtyDedupConfigOp, f_OUT_readPtyDedupConfigOp);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}