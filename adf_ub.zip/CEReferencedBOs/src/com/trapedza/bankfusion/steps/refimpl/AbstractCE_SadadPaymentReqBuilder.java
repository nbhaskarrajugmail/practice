package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.sql.Timestamp;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import java.sql.Date;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import java.math.BigDecimal;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_SadadPaymentReqBuilder implements
		ICE_SadadPaymentReqBuilder {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_SadadPaymentReqBuilder(BankFusionEnvironment env) {
	}

	public AbstractCE_SadadPaymentReqBuilder() {
	}

	private bf.com.misys.financialposting.types.BackOfficeAccountPostingRq f_IN_backOfficeRequest = new bf.com.misys.financialposting.types.BackOfficeAccountPostingRq();
	{
		bf.com.misys.financialposting.types.EventChargeDetail var_019_backOfficeRequest_eventCharges = new bf.com.misys.financialposting.types.EventChargeDetail();

		var_019_backOfficeRequest_eventCharges.setNoOfChgTaxAmtDetails(Utils
				.getINTEGERValue("0"));
		var_019_backOfficeRequest_eventCharges.setPartyCategory(Utils
				.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_totalChgAmt = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_totalChgAmt.setAmount(Utils
				.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_totalChgAmt
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges
				.setTotalChgAmt(var_019_backOfficeRequest_eventCharges_totalChgAmt);

		var_019_backOfficeRequest_eventCharges.setIsWaived(Utils
				.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges.setMainAccountId(Utils
				.getSTRINGValue(""));
		bf.com.misys.financialposting.types.EventChargeTaxDetail var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails = new bf.com.misys.financialposting.types.EventChargeTaxDetail();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setChgAmendReason(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails.setSelect(Utils
				.getBOOLEANValue("false"));
		bf.com.misys.financialposting.types.EventChargeCalculationDetail var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails = new bf.com.misys.financialposting.types.EventChargeCalculationDetail();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgRecAcct(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.ChargeKeyDtls var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls = new bf.com.misys.financialposting.types.ChargeKeyDtls();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setProductCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setProduct(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setAccount(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setChannelId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setPartySubType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setEventSubCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setWalkIn(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setPaymentSystem(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setChargeBasis(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChargeDesc(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setEventCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setChargeLevel(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setPaymentType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setIsApply(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setAccountStyle(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setInsufficientFundsInd(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChgId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setChargeType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setChargeCodeId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls
				.setTxnCurrency(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setOnlineChgKeyDtls(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_onlineChgKeyDtls);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgHostTxnCode(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chargeAmount = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chargeAmount
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chargeAmount
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChargeAmount(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chargeAmount);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgNarrative(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgAmtAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtAcctCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtTxnCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtTxnCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtTxnCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgAmtTxnCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtTxnCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtFundAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtFundAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtFundAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgAmtFundAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgAmtFundAcctCur);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChargeCalcCodeId(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.FxInfo var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgExchRateDetails = new bf.com.misys.financialposting.types.FxInfo();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgExchRateDetails
				.setExchangeRate(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgExchRateDetails
				.setMultiplyDivide(Utils.getSTRINGValue("M"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgExchRateDetails
				.setExchangeRateType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails
				.setChgExchRateDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails_chgExchRateDetails);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setTaxAmtCalcDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_taxAmtCalcDetails);

		bf.com.misys.financialposting.types.EventChargeCalculationDetail var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails = new bf.com.misys.financialposting.types.EventChargeCalculationDetail();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgRecAcct(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.ChargeKeyDtls var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls = new bf.com.misys.financialposting.types.ChargeKeyDtls();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setProductCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setProduct(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setAccount(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setChannelId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setPartySubType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setEventSubCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setWalkIn(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setPaymentSystem(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setChargeBasis(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChargeDesc(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setEventCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setChargeLevel(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setPaymentType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setIsApply(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setAccountStyle(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setInsufficientFundsInd(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChgId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setChargeType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setChargeCodeId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls
				.setTxnCurrency(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setOnlineChgKeyDtls(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_onlineChgKeyDtls);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgHostTxnCode(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chargeAmount = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chargeAmount
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chargeAmount
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChargeAmount(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chargeAmount);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgNarrative(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgAmtAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtAcctCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtTxnCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtTxnCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtTxnCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgAmtTxnCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtTxnCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtFundAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtFundAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtFundAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgAmtFundAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgAmtFundAcctCur);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChargeCalcCodeId(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.FxInfo var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgExchRateDetails = new bf.com.misys.financialposting.types.FxInfo();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgExchRateDetails
				.setExchangeRate(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgExchRateDetails
				.setMultiplyDivide(Utils.getSTRINGValue("M"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgExchRateDetails
				.setExchangeRateType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails
				.setChgExchRateDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails_chgExchRateDetails);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setOriginalTaxAmtCalcDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalTaxAmtCalcDetails);

		bf.com.misys.financialposting.types.EventChargeCalculationDetail var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails = new bf.com.misys.financialposting.types.EventChargeCalculationDetail();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgRecAcct(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.ChargeKeyDtls var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls = new bf.com.misys.financialposting.types.ChargeKeyDtls();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setProductCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setProduct(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setAccount(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setChannelId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setPartySubType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setEventSubCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setWalkIn(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setPaymentSystem(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setChargeBasis(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChargeDesc(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setEventCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setChargeLevel(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setPaymentType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setIsApply(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setAccountStyle(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setInsufficientFundsInd(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChgId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setChargeType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setChargeCodeId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls
				.setTxnCurrency(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setOnlineChgKeyDtls(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_onlineChgKeyDtls);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgHostTxnCode(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chargeAmount = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chargeAmount
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chargeAmount
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChargeAmount(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chargeAmount);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgNarrative(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgAmtAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtAcctCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtTxnCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtTxnCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtTxnCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgAmtTxnCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtTxnCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtFundAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtFundAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtFundAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgAmtFundAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgAmtFundAcctCur);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChargeCalcCodeId(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.FxInfo var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgExchRateDetails = new bf.com.misys.financialposting.types.FxInfo();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgExchRateDetails
				.setExchangeRate(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgExchRateDetails
				.setMultiplyDivide(Utils.getSTRINGValue("M"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgExchRateDetails
				.setExchangeRateType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails
				.setChgExchRateDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails_chgExchRateDetails);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setChgAmtCalcDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_chgAmtCalcDetails);

		bf.com.misys.financialposting.types.EventChargeCalculationDetail var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails = new bf.com.misys.financialposting.types.EventChargeCalculationDetail();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgRecAcct(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.ChargeKeyDtls var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls = new bf.com.misys.financialposting.types.ChargeKeyDtls();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setProductCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setProduct(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setAccount(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setChannelId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setPartySubType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setEventSubCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setWalkIn(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setPaymentSystem(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setChargeBasis(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChargeDesc(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setEventCategory(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setChargeLevel(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setPaymentType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setIsApply(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setAccountStyle(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setInsufficientFundsInd(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setOnlineChgId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setChargeType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setChargeCodeId(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls
				.setTxnCurrency(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setOnlineChgKeyDtls(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_onlineChgKeyDtls);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgHostTxnCode(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chargeAmount = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chargeAmount
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chargeAmount
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChargeAmount(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chargeAmount);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgNarrative(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgAmtAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtAcctCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtTxnCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtTxnCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtTxnCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgAmtTxnCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtTxnCur);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtFundAcctCur = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtFundAcctCur
				.setAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtFundAcctCur
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgAmtFundAcctCur(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgAmtFundAcctCur);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChargeCalcCodeId(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.FxInfo var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgExchRateDetails = new bf.com.misys.financialposting.types.FxInfo();

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgExchRateDetails
				.setExchangeRate(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgExchRateDetails
				.setMultiplyDivide(Utils.getSTRINGValue("M"));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgExchRateDetails
				.setExchangeRateType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails
				.setChgExchRateDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails_chgExchRateDetails);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setOriginalChgAmtCalcDetails(var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails_originalChgAmtCalcDetails);

		var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails
				.setIsWaived(Utils.getBOOLEANValue("false"));
		var_019_backOfficeRequest_eventCharges.addChgTaxAmtDetails(0,
				var_019_backOfficeRequest_eventCharges_chgTaxAmtDetails);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_totalTaxAmt = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_totalTaxAmt.setAmount(Utils
				.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_totalTaxAmt
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges
				.setTotalTaxAmt(var_019_backOfficeRequest_eventCharges_totalTaxAmt);

		bf.com.misys.financialposting.types.Amount var_019_backOfficeRequest_eventCharges_totalChgTaxAmt = new bf.com.misys.financialposting.types.Amount();

		var_019_backOfficeRequest_eventCharges_totalChgTaxAmt.setAmount(Utils
				.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_eventCharges_totalChgTaxAmt
				.setIsoCurrencyCode(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_eventCharges
				.setTotalChgTaxAmt(var_019_backOfficeRequest_eventCharges_totalChgTaxAmt);

		var_019_backOfficeRequest_eventCharges.setFundingAccount(Utils
				.getSTRINGValue(""));
		f_IN_backOfficeRequest.addEventCharges(0,
				var_019_backOfficeRequest_eventCharges);

		f_IN_backOfficeRequest.setSrvVersion(Utils.getSTRINGValue(""));
		bf.com.misys.financialposting.types.PostingLeg var_019_backOfficeRequest_backOfficePostingLegs = new bf.com.misys.financialposting.types.PostingLeg();

		var_019_backOfficeRequest_backOfficePostingLegs
				.setCreditDebitIndicator(CommonConstants.EMPTY_STRING);
		var_019_backOfficeRequest_backOfficePostingLegs.setAmount(Utils
				.getBIGDECIMALValue("0"));
		var_019_backOfficeRequest_backOfficePostingLegs
				.setTransactionCode(CommonConstants.EMPTY_STRING);
		var_019_backOfficeRequest_backOfficePostingLegs
				.setTransactionCurrency(CommonConstants.EMPTY_STRING);
		var_019_backOfficeRequest_backOfficePostingLegs
				.setBaseEquivalentAmount(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs.setNarrative(Utils
				.getSTRINGValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs.setAccountId(Utils
				.getSTRINGValue(""));
		bf.com.misys.financialposting.types.FxInfo var_019_backOfficeRequest_backOfficePostingLegs_amountToBaseEquivalentFxDetail = new bf.com.misys.financialposting.types.FxInfo();

		var_019_backOfficeRequest_backOfficePostingLegs_amountToBaseEquivalentFxDetail
				.setExchangeRate(Utils.getBIGDECIMALValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs_amountToBaseEquivalentFxDetail
				.setMultiplyDivide(Utils.getSTRINGValue("M"));
		var_019_backOfficeRequest_backOfficePostingLegs_amountToBaseEquivalentFxDetail
				.setExchangeRateType(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs
				.setAmountToBaseEquivalentFxDetail(var_019_backOfficeRequest_backOfficePostingLegs_amountToBaseEquivalentFxDetail);

		bf.com.misys.financialposting.types.AccountPseudonym var_019_backOfficeRequest_backOfficePostingLegs_accountPseudonym = new bf.com.misys.financialposting.types.AccountPseudonym();

		var_019_backOfficeRequest_backOfficePostingLegs_accountPseudonym
				.setContext(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs_accountPseudonym
				.setContextValue(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs_accountPseudonym
				.setPseudonym(Utils.getSTRINGValue(""));
		var_019_backOfficeRequest_backOfficePostingLegs
				.setAccountPseudonym(var_019_backOfficeRequest_backOfficePostingLegs_accountPseudonym);

		f_IN_backOfficeRequest.addBackOfficePostingLegs(0,
				var_019_backOfficeRequest_backOfficePostingLegs);

		bf.com.misys.financialposting.types.TxnDetails var_019_backOfficeRequest_txnDetails = new bf.com.misys.financialposting.types.TxnDetails();

		var_019_backOfficeRequest_txnDetails.setBranchSortCode(Utils
				.getSTRINGValue(""));
		var_019_backOfficeRequest_txnDetails.setForcePost(Utils
				.getBOOLEANValue("false"));
		var_019_backOfficeRequest_txnDetails.setChannelId(Utils
				.getSTRINGValue(""));
		var_019_backOfficeRequest_txnDetails
				.setTransactionReference(CommonConstants.EMPTY_STRING);
		var_019_backOfficeRequest_txnDetails.setValueDate(Utils
				.getTIMESTAMPValue(""));
		var_019_backOfficeRequest_txnDetails.setDoNotAutoClearIfFwdValued(Utils
				.getBOOLEANValue("false"));
		var_019_backOfficeRequest_txnDetails.setTransactionId(Utils
				.getSTRINGValue(""));
		f_IN_backOfficeRequest
				.setTxnDetails(var_019_backOfficeRequest_txnDetails);
	}
	private bf.com.misys.types.sadad.payment.SadadRequest f_IN_request = new bf.com.misys.types.sadad.payment.SadadRequest();
	{
		bf.com.misys.types.sadad.payment.SadadPmtDtlsRq var_019_request_transactionDtl = new bf.com.misys.types.sadad.payment.SadadPmtDtlsRq();

		var_019_request_transactionDtl.setPmtAmt(Utils.getBIGDECIMALValue("0"));
		var_019_request_transactionDtl.setPmtDt(Utils
				.getDATEValue("1970-01-01"));
		var_019_request_transactionDtl
				.setAgencyId(CommonConstants.EMPTY_STRING);
		var_019_request_transactionDtl
				.setBillInvoiceNo(CommonConstants.EMPTY_STRING);
		var_019_request_transactionDtl.setPmtRefInfo(Utils.getSTRINGValue(""));
		var_019_request_transactionDtl
				.setBillCycle(CommonConstants.EMPTY_STRING);
		bf.com.misys.types.sadad.payment.POI_Type var_019_request_transactionDtl_PayorPOI = new bf.com.misys.types.sadad.payment.POI_Type();

		var_019_request_transactionDtl_PayorPOI.setPOINum(Utils
				.getSTRINGValue(""));
		var_019_request_transactionDtl_PayorPOI.setPOIType(Utils
				.getSTRINGValue(""));
		var_019_request_transactionDtl
				.setPayorPOI(var_019_request_transactionDtl_PayorPOI);

		var_019_request_transactionDtl
				.setPmtStatusCode(CommonConstants.EMPTY_STRING);
		var_019_request_transactionDtl
				.setECollectionPmtMethod(CommonConstants.EMPTY_STRING);
		var_019_request_transactionDtl
				.setBillCategory(CommonConstants.EMPTY_STRING);
		bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls var_019_request_transactionDtl_eCollectionPmtMethodDtls = new bf.com.misys.types.sadad.payment.ECollectionPmtMethodDtls();

		var_019_request_transactionDtl_eCollectionPmtMethodDtls.setBankId(Utils
				.getSTRINGValue(""));
		var_019_request_transactionDtl_eCollectionPmtMethodDtls
				.setBankPmtId(Utils.getSTRINGValue(""));
		var_019_request_transactionDtl_eCollectionPmtMethodDtls
				.setPmtChannel(Utils.getSTRINGValue(""));
		var_019_request_transactionDtl_eCollectionPmtMethodDtls.setPmtId(Utils
				.getSTRINGValue(""));
		var_019_request_transactionDtl
				.setECollectionPmtMethodDtls(var_019_request_transactionDtl_eCollectionPmtMethodDtls);

		var_019_request_transactionDtl
				.setBillAcct(CommonConstants.EMPTY_STRING);
		f_IN_request.addTransactionDtl(0, var_019_request_transactionDtl);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private bf.com.misys.types.sadad.payment.SadadResponse f_OUT_response = new bf.com.misys.types.sadad.payment.SadadResponse();
	{
		bf.com.misys.types.sadad.payment.SadadPmtDtlsRs var_020_response_transactionRs = new bf.com.misys.types.sadad.payment.SadadPmtDtlsRs();

		var_020_response_transactionRs.setStatus(CommonConstants.EMPTY_STRING);
		var_020_response_transactionRs.setMsgRecDt(Utils
				.getDATEValue("1970-01-01"));
		var_020_response_transactionRs
				.setErrorDescription(CommonConstants.EMPTY_STRING);
		var_020_response_transactionRs
				.setBillInviceNumber(CommonConstants.EMPTY_STRING);
		var_020_response_transactionRs
				.setTransactionID(CommonConstants.EMPTY_STRING);
		f_OUT_response.addTransactionRs(0, var_020_response_transactionRs);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.com.misys.financialposting.types.BackOfficeAccountPostingRq getF_IN_backOfficeRequest() {
		return f_IN_backOfficeRequest;
	}

	public void setF_IN_backOfficeRequest(
			bf.com.misys.financialposting.types.BackOfficeAccountPostingRq param) {
		f_IN_backOfficeRequest = param;
	}

	public bf.com.misys.types.sadad.payment.SadadRequest getF_IN_request() {
		return f_IN_request;
	}

	public void setF_IN_request(
			bf.com.misys.types.sadad.payment.SadadRequest param) {
		f_IN_request = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_backOfficeRequest, f_IN_backOfficeRequest);
		dataInMap.put(IN_request, f_IN_request);
		return dataInMap;
	}

	public bf.com.misys.types.sadad.payment.SadadResponse getF_OUT_response() {
		return f_OUT_response;
	}

	public void setF_OUT_response(
			bf.com.misys.types.sadad.payment.SadadResponse param) {
		f_OUT_response = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_response, f_OUT_response);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		return dataOutMap;
	}
}