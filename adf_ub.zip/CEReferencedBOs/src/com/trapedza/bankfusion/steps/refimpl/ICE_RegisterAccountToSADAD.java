package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import java.sql.Date;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public interface ICE_RegisterAccountToSADAD extends
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_AdhocRun = "AdhocRun";
	public static final String IN_AccountOpenRunDate = "AccountOpenRunDate";
	public static final String IN_JOBID = "JOBID";
	public static final String OUT_ErrorDescription = "ErrorDescription";
	public static final String OUT_Success = "Success";
	public static final String OUT_ErrorCode = "ErrorCode";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public Boolean isF_IN_AdhocRun();

	public void setF_IN_AdhocRun(Boolean param);

	public Date getF_IN_AccountOpenRunDate();

	public void setF_IN_AccountOpenRunDate(Date param);

	public String getF_IN_JOBID();

	public void setF_IN_JOBID(String param);

	public Map getInDataMap();

	public String getF_OUT_ErrorDescription();

	public void setF_OUT_ErrorDescription(String param);

	public Boolean isF_OUT_Success();

	public void setF_OUT_Success(Boolean param);

	public String getF_OUT_ErrorCode();

	public void setF_OUT_ErrorCode(String param);

	public Map getOutDataMap();
}