
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_ValidateUniqueNationalId implements ICE_ValidateUniqueNationalId {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_ValidateUniqueNationalId(BankFusionEnvironment env) {
	}

	public AbstractCE_ValidateUniqueNationalId() {
	}

	private String f_IN_nationalId = CommonConstants.EMPTY_STRING;

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_nationalId() {
		return f_IN_nationalId;
	}

	public void setF_IN_nationalId(String param) {
		f_IN_nationalId = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_nationalId, f_IN_nationalId);
		return dataInMap;
	}
}