
package com.trapedza.bankfusion.steps.refimpl;

import com.trapedza.bankfusion.servercommon.fatoms.ActivityStepPagingState;
import java.util.Iterator;
import com.trapedza.bankfusion.core.VectorTable;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import com.trapedza.bankfusion.servercommon.fatoms.PagingHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_FIN_GetTxnDetailPaginated implements ICE_FIN_GetTxnDetailPaginated,
		com.trapedza.bankfusion.servercommon.steps.refimpl.IPagableActivityStep {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_FIN_GetTxnDetailPaginated(BankFusionEnvironment env) {
	}

	public AbstractCE_FIN_GetTxnDetailPaginated() {
	}

	private bf.com.misys.bankfusion.attributes.PagedQuery f_IN_PagedQuery = new bf.com.misys.bankfusion.attributes.PagedQuery();
	{
		bf.com.misys.bankfusion.attributes.PagingRequest var_019_PagedQuery_PagingRequest = new bf.com.misys.bankfusion.attributes.PagingRequest();

		var_019_PagedQuery_PagingRequest.setTotalPages(Utils.getINTEGERValue("0"));
		var_019_PagedQuery_PagingRequest.setRequestedPage(Utils.getINTEGERValue("0"));
		var_019_PagedQuery_PagingRequest.setNumberOfRows(Utils.getINTEGERValue("0"));
		f_IN_PagedQuery.setPagingRequest(var_019_PagedQuery_PagingRequest);

		f_IN_PagedQuery.setQueryData(CommonConstants.EMPTY_STRING);
	}
	private String f_IN_batchRef = CommonConstants.EMPTY_STRING;

	private String f_IN_filterAction = CommonConstants.EMPTY_STRING;

	private String f_IN_result_PAGINGSUPPORT = "N";

	private Integer f_IN_result_PAGENUMBER = new Integer(1);

	private String f_IN_PAGINGSUPPORT = "Y";

	private String f_IN_getUnProcessedRecs = CommonConstants.EMPTY_STRING;

	private com.misys.ce.types.BatchInfoDetails f_IN_batchInfo = new com.misys.ce.types.BatchInfoDetails();
	{
		f_IN_batchInfo.setTxnDateHijri(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setMOFDocNumber(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setNarrative(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setTxnDate(Utils.getDATEDefaultValue());
		f_IN_batchInfo.setBranchCd(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setGatewayRef(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setPlaceholder(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setAmount(Utils.getBIGDECIMALValue("0"));
		f_IN_batchInfo.setLoanAccount(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setProcessInThisBatch(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setChequeNumber(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setStatus(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setNationalId(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setPlaceholder3(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setPlaceholder2(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setRecId(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setMOFDocDate(Utils.getDATEDefaultValue());
		f_IN_batchInfo.setInternalAccount(CommonConstants.EMPTY_STRING);
		f_IN_batchInfo.setChequeDate(Utils.getDATEDefaultValue());
	}
	private Integer f_IN_result_NUMBEROFROWS = new Integer(10);
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private VectorTable f_OUT_result = new VectorTable();

	private Boolean f_OUT_result_HASMOREPAGES = Boolean.FALSE;

	private Integer f_OUT_result_TOTALPAGES = CommonConstants.INTEGER_ZERO;

	private Object f_OUT_PaginatedData = new String();

	private Integer f_OUT_result_NOOFROWS = CommonConstants.INTEGER_ZERO;

	private PagingHelper pagingHelper = new PagingHelper(this);

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.com.misys.bankfusion.attributes.PagedQuery getF_IN_PagedQuery() {
		return f_IN_PagedQuery;
	}

	public void setF_IN_PagedQuery(bf.com.misys.bankfusion.attributes.PagedQuery param) {
		f_IN_PagedQuery = param;
	}

	public String getF_IN_batchRef() {
		return f_IN_batchRef;
	}

	public void setF_IN_batchRef(String param) {
		f_IN_batchRef = param;
	}

	public String getF_IN_filterAction() {
		return f_IN_filterAction;
	}

	public void setF_IN_filterAction(String param) {
		f_IN_filterAction = param;
	}

	public String getF_IN_result_PAGINGSUPPORT() {
		return f_IN_result_PAGINGSUPPORT;
	}

	public void setF_IN_result_PAGINGSUPPORT(String param) {
		f_IN_result_PAGINGSUPPORT = param;
	}

	public Integer getF_IN_result_PAGENUMBER() {
		return f_IN_result_PAGENUMBER;
	}

	public void setF_IN_result_PAGENUMBER(Integer param) {
		f_IN_result_PAGENUMBER = param;
	}

	public String getF_IN_PAGINGSUPPORT() {
		return f_IN_PAGINGSUPPORT;
	}

	public void setF_IN_PAGINGSUPPORT(String param) {
		f_IN_PAGINGSUPPORT = param;
	}

	public String getF_IN_getUnProcessedRecs() {
		return f_IN_getUnProcessedRecs;
	}

	public void setF_IN_getUnProcessedRecs(String param) {
		f_IN_getUnProcessedRecs = param;
	}

	public com.misys.ce.types.BatchInfoDetails getF_IN_batchInfo() {
		return f_IN_batchInfo;
	}

	public void setF_IN_batchInfo(com.misys.ce.types.BatchInfoDetails param) {
		f_IN_batchInfo = param;
	}

	public Integer getF_IN_result_NUMBEROFROWS() {
		return f_IN_result_NUMBEROFROWS;
	}

	public void setF_IN_result_NUMBEROFROWS(Integer param) {
		f_IN_result_NUMBEROFROWS = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_PagedQuery, f_IN_PagedQuery);
		dataInMap.put(IN_batchRef, f_IN_batchRef);
		dataInMap.put(IN_filterAction, f_IN_filterAction);
		dataInMap.put(IN_result_PAGINGSUPPORT, f_IN_result_PAGINGSUPPORT);
		dataInMap.put(IN_result_PAGENUMBER, f_IN_result_PAGENUMBER);
		dataInMap.put(IN_PAGINGSUPPORT, f_IN_PAGINGSUPPORT);
		dataInMap.put(IN_getUnProcessedRecs, f_IN_getUnProcessedRecs);
		dataInMap.put(IN_batchInfo, f_IN_batchInfo);
		dataInMap.put(IN_result_NUMBEROFROWS, f_IN_result_NUMBEROFROWS);
		return dataInMap;
	}

	public VectorTable getF_OUT_result() {
		return f_OUT_result;
	}

	public void setF_OUT_result(VectorTable param) {
		f_OUT_result = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Boolean isF_OUT_result_HASMOREPAGES() {
		return f_OUT_result_HASMOREPAGES;
	}

	public void setF_OUT_result_HASMOREPAGES(Boolean param) {
		f_OUT_result_HASMOREPAGES = param;
	}

	public Integer getF_OUT_result_TOTALPAGES() {
		return f_OUT_result_TOTALPAGES;
	}

	public void setF_OUT_result_TOTALPAGES(Integer param) {
		f_OUT_result_TOTALPAGES = param;
	}

	public Object getF_OUT_PaginatedData() {
		return f_OUT_PaginatedData;
	}

	public void setF_OUT_PaginatedData(Object param) {
		f_OUT_PaginatedData = param;
	}

	public Integer getF_OUT_result_NOOFROWS() {
		return f_OUT_result_NOOFROWS;
	}

	public void setF_OUT_result_NOOFROWS(Integer param) {
		f_OUT_result_NOOFROWS = param;
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_result, f_OUT_result);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		dataOutMap.put(OUT_result_HASMOREPAGES, f_OUT_result_HASMOREPAGES);
		dataOutMap.put(OUT_result_TOTALPAGES, f_OUT_result_TOTALPAGES);
		dataOutMap.put(OUT_PaginatedData, f_OUT_PaginatedData);
		dataOutMap.put(OUT_result_NOOFROWS, f_OUT_result_NOOFROWS);
		return dataOutMap;
	}

	public PagingHelper getPagingHelper() {
		return pagingHelper;
	}

	public ActivityStepPagingState createActivityStepPagingState() {
		ActivityStepPagingState pagingState = new ActivityStepPagingState(this);
		return (pagingState);
	}

	public Object processPagingState(BankFusionEnvironment bankfusionenvironment,
			ActivityStepPagingState activitysteppagingstate, Map map) {
		return null;
	}

	public String getResourceID() {
		return "CE_FIN_GetTxnDetailPaginated";
	}

}