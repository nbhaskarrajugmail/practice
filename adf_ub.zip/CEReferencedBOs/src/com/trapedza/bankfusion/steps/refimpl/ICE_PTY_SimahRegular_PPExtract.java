package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.core.DataType;
import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public interface ICE_PTY_SimahRegular_PPExtract extends
		com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public void process(BankFusionEnvironment env) throws BankFusionException;
}