
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public interface ICE_SearchTitleDeedByNumber extends com.trapedza.bankfusion.servercommon.steps.refimpl.Processable {
	public static final String IN_titleDeedNumber = "titleDeedNumber";
	public static final String OUT_titleDeeddtlsList = "titleDeeddtlsList";

	public void process(BankFusionEnvironment env) throws BankFusionException;

	public String getF_IN_titleDeedNumber();

	public void setF_IN_titleDeedNumber(String param);

	public Map getInDataMap();

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_titleDeeddtlsList();

	public void setF_OUT_titleDeeddtlsList(com.misys.ce.types.ListTitleDeedIdDtlsType param);

	public Map getOutDataMap();
}