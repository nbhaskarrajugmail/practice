package com.trapedza.bankfusion.steps.refimpl;

import java.util.ArrayList;
import com.trapedza.bankfusion.microflow.ActivityStep;
import java.util.Map;
import java.util.List;
import com.trapedza.bankfusion.core.BankFusionException;
import java.util.HashMap;
import com.trapedza.bankfusion.utils.Utils;
import com.trapedza.bankfusion.core.DataType;
import com.trapedza.bankfusion.core.CommonConstants;
import java.util.Iterator;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;

/**
 * 
 * DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
 * This will be overwritten by any subsequent code-generation.
 *
 */
public abstract class AbstractCE_BillAcctReqBuilder implements
		ICE_BillAcctReqBuilder {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_BillAcctReqBuilder(BankFusionEnvironment env) {
	}

	public AbstractCE_BillAcctReqBuilder() {
	}

	private bf.org.example.ce_billacct.SadadRequest f_IN_billAcctRq = new bf.org.example.ce_billacct.SadadRequest();
	{
		bf.org.example.ce_billacct.BillAcctRq var_019_billAcctRq_transactionDtl = new bf.org.example.ce_billacct.BillAcctRq();

		var_019_billAcctRq_transactionDtl
				.setStatusCode(CommonConstants.EMPTY_STRING);
		var_019_billAcctRq_transactionDtl
				.setAgencyId(CommonConstants.EMPTY_STRING);
		var_019_billAcctRq_transactionDtl
				.setStatusDesc(CommonConstants.EMPTY_STRING);
		var_019_billAcctRq_transactionDtl
				.setBillAcctNo(CommonConstants.EMPTY_STRING);
		f_IN_billAcctRq.addTransactionDtl(0, var_019_billAcctRq_transactionDtl);
	}
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private bf.org.example.ce_billacct.SadadResponse f_OUT_billAcctRs = new bf.org.example.ce_billacct.SadadResponse();
	{
		bf.org.example.ce_billacct.BillAcctRs var_020_billAcctRs_transactionRs = new bf.org.example.ce_billacct.BillAcctRs();

		var_020_billAcctRs_transactionRs
				.setStatusCode(CommonConstants.EMPTY_STRING);
		var_020_billAcctRs_transactionRs
				.setStatusDesc(CommonConstants.EMPTY_STRING);
		f_OUT_billAcctRs.addTransactionRs(0, var_020_billAcctRs_transactionRs);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public bf.org.example.ce_billacct.SadadRequest getF_IN_billAcctRq() {
		return f_IN_billAcctRq;
	}

	public void setF_IN_billAcctRq(bf.org.example.ce_billacct.SadadRequest param) {
		f_IN_billAcctRq = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_billAcctRq, f_IN_billAcctRq);
		return dataInMap;
	}

	public bf.org.example.ce_billacct.SadadResponse getF_OUT_billAcctRs() {
		return f_OUT_billAcctRs;
	}

	public void setF_OUT_billAcctRs(
			bf.org.example.ce_billacct.SadadResponse param) {
		f_OUT_billAcctRs = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_billAcctRs, f_OUT_billAcctRs);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA,
				udfStateData);
		return dataOutMap;
	}
}