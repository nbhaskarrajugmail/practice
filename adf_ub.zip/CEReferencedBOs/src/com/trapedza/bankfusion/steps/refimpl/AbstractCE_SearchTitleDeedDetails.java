
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_SearchTitleDeedDetails implements ICE_SearchTitleDeedDetails {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_SearchTitleDeedDetails(BankFusionEnvironment env) {
	}

	public AbstractCE_SearchTitleDeedDetails() {
	}

	private String f_IN_titleDeedId = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_OUT_titleDeedDtlslist = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_020_titleDeedDtlslist_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_020_titleDeedDtlslist_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_020_titleDeedDtlslist_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_OUT_titleDeedDtlslist.addTitleDeedDetails(0, var_020_titleDeedDtlslist_titleDeedDetails);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_titleDeedId() {
		return f_IN_titleDeedId;
	}

	public void setF_IN_titleDeedId(String param) {
		f_IN_titleDeedId = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_titleDeedId, f_IN_titleDeedId);
		return dataInMap;
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_OUT_titleDeedDtlslist() {
		return f_OUT_titleDeedDtlslist;
	}

	public void setF_OUT_titleDeedDtlslist(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_OUT_titleDeedDtlslist = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_titleDeedDtlslist, f_OUT_titleDeedDtlslist);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}