
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.math.BigDecimal;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_DeleteTitleDeedDetails implements ICE_DeleteTitleDeedDetails {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_DeleteTitleDeedDetails(BankFusionEnvironment env) {
	}

	public AbstractCE_DeleteTitleDeedDetails() {
	}

	private com.misys.ce.types.ListTitleDeedIdDtlsType f_IN_listTitleDeedDtlsType = new com.misys.ce.types.ListTitleDeedIdDtlsType();
	{
		com.misys.ce.types.TitleDeedDetailsType var_019_listTitleDeedDtlsType_titleDeedDetails = new com.misys.ce.types.TitleDeedDetailsType();

		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedType(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setVersionNumber(Utils.getINTEGERValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionNotes(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidFromHijri(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionDate(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLandPlotNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidFrom(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setSplitIndicator(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedYear(Utils.getINTEGERValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setFarmLocation(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLinkedToCollateral(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTransactionType(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setNotes(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidToHijri(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedSource(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setValidTo(Utils.getDATEValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setLandPlanNumber(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setAreaSize(Utils.getBIGDECIMALValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setSelect(Utils.getBOOLEANValue("false"));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setTitleDeedIdpk(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setReasonForChange(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setDicissionStatus(Utils.getSTRINGValue(""));
		var_019_listTitleDeedDtlsType_titleDeedDetails.setRetailIndex(Utils.getSTRINGValue(""));
		f_IN_listTitleDeedDtlsType.addTitleDeedDetails(0, var_019_listTitleDeedDtlsType_titleDeedDetails);
	}

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public com.misys.ce.types.ListTitleDeedIdDtlsType getF_IN_listTitleDeedDtlsType() {
		return f_IN_listTitleDeedDtlsType;
	}

	public void setF_IN_listTitleDeedDtlsType(com.misys.ce.types.ListTitleDeedIdDtlsType param) {
		f_IN_listTitleDeedDtlsType = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_listTitleDeedDtlsType, f_IN_listTitleDeedDtlsType);
		return dataInMap;
	}
}