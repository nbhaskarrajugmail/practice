
package com.trapedza.bankfusion.steps.refimpl;

import java.util.Iterator;
import com.trapedza.bankfusion.microflow.ActivityStep;
import com.trapedza.bankfusion.core.CommonConstants;
import com.trapedza.bankfusion.core.ExtensionPointHelper;
import java.util.HashMap;
import bf.com.misys.bankfusion.attributes.UserDefinedFields;
import com.trapedza.bankfusion.servercommon.commands.BankFusionEnvironment;
import java.util.ArrayList;
import com.trapedza.bankfusion.utils.Utils;
import java.sql.Date;
import java.util.List;
import com.trapedza.bankfusion.core.DataType;
import java.util.Map;
import com.trapedza.bankfusion.core.BankFusionException;

/**
* 
* DO NOT CHANGE MANUALLY - THIS IS AUTOMATICALLY GENERATED CODE.<br>
* This will be overwritten by any subsequent code-generation.
*
*/
public abstract class AbstractCE_PopulateHijriDate implements ICE_PopulateHijriDate {
	/**
	 * @deprecated use no-argument constructor!
	 */
	public AbstractCE_PopulateHijriDate(BankFusionEnvironment env) {
	}

	public AbstractCE_PopulateHijriDate() {
	}

	private String f_IN_hijriDate = CommonConstants.EMPTY_STRING;
	private ArrayList<String> udfBoNames = new ArrayList<String>();
	private HashMap udfStateData = new HashMap();

	private Date f_OUT_fromDate = new Date(0L);

	public void process(BankFusionEnvironment env) throws BankFusionException {
	}

	public String getF_IN_hijriDate() {
		return f_IN_hijriDate;
	}

	public void setF_IN_hijriDate(String param) {
		f_IN_hijriDate = param;
	}

	public Map getInDataMap() {
		Map dataInMap = new HashMap();
		dataInMap.put(IN_hijriDate, f_IN_hijriDate);
		return dataInMap;
	}

	public Date getF_OUT_fromDate() {
		return f_OUT_fromDate;
	}

	public void setF_OUT_fromDate(Date param) {
		f_OUT_fromDate = param;
	}

	public void setUDFData(String boName, UserDefinedFields fields) {
		if (!udfBoNames.contains(boName.toUpperCase())) {
			udfBoNames.add(boName.toUpperCase());
		}
		String udfKey = boName.toUpperCase() + CommonConstants.CUSTOM_PROP;
		udfStateData.put(udfKey, fields);
	}

	public Map getOutDataMap() {
		Map dataOutMap = new HashMap();
		dataOutMap.put(OUT_fromDate, f_OUT_fromDate);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_BONAMES, udfBoNames);
		dataOutMap.put(CommonConstants.ACTIVITYSTEP_UDF_STATE_DATA, udfStateData);
		return dataOutMap;
	}
}