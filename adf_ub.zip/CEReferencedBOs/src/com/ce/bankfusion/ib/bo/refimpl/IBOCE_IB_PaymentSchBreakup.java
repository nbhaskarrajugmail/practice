
package com.ce.bankfusion.ib.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Date;

public interface IBOCE_IB_PaymentSchBreakup extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_IB_PaymentSchBreakup";
	public static final String IBBILLDATE = "f_IBBILLDATE";
	public static final String IBPAYMENTSCHBREAKUPID = "boID";
	public static final String IBSCHEDULEFEESAMTPAID = "f_IBSCHEDULEFEESAMTPAID";
	public static final String IBSUBSIDYAMNT = "f_IBSUBSIDYAMNT";
	public static final String IBASSETID = "f_IBASSETID";
	public static final String IBPRINCIPALAMT = "f_IBPRINCIPALAMT";
	public static final String IBPRINCIPALAMTPAID = "f_IBPRINCIPALAMTPAID";
	public static final String IBSCHEDULEFEEAMT = "f_IBSCHEDULEFEEAMT";
	public static final String VERSIONNUM = "versionNum";
	public static final String IBPROFITAMT = "f_IBPROFITAMT";
	public static final String IBPROFITAMTPAID = "f_IBPROFITAMTPAID";
	public static final String IBSUBSIDYAMTPAID = "f_IBSUBSIDYAMTPAID";
	public static final String IBDEALID = "f_IBDEALID";

	public Date getF_IBBILLDATE();

	public void setF_IBBILLDATE(Date param);

	public BigDecimal getF_IBSCHEDULEFEESAMTPAID();

	public void setF_IBSCHEDULEFEESAMTPAID(BigDecimal param);

	public BigDecimal getF_IBSUBSIDYAMNT();

	public void setF_IBSUBSIDYAMNT(BigDecimal param);

	public String getF_IBASSETID();

	public void setF_IBASSETID(String param);

	public BigDecimal getF_IBPRINCIPALAMT();

	public void setF_IBPRINCIPALAMT(BigDecimal param);

	public BigDecimal getF_IBPRINCIPALAMTPAID();

	public void setF_IBPRINCIPALAMTPAID(BigDecimal param);

	public BigDecimal getF_IBSCHEDULEFEEAMT();

	public void setF_IBSCHEDULEFEEAMT(BigDecimal param);

	public BigDecimal getF_IBPROFITAMT();

	public void setF_IBPROFITAMT(BigDecimal param);

	public BigDecimal getF_IBPROFITAMTPAID();

	public void setF_IBPROFITAMTPAID(BigDecimal param);

	public BigDecimal getF_IBSUBSIDYAMTPAID();

	public void setF_IBSUBSIDYAMTPAID(BigDecimal param);

	public String getF_IBDEALID();

	public void setF_IBDEALID(String param);

}