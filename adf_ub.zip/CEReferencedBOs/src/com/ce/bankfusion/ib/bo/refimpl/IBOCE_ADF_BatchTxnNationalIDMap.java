
package com.ce.bankfusion.ib.bo.refimpl;

import java.math.BigDecimal;
import java.sql.Date;

public interface IBOCE_ADF_BatchTxnNationalIDMap extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_ADF_BatchTxnNationalIDMap";
	public static final String DUEDATE = "f_DUEDATE";
	public static final String BATCHID = "f_BATCHID";
	public static final String ROLE = "f_ROLE";
	public static final String LOANACCOUNTID = "f_LOANACCOUNTID";
	public static final String VERSIONNUM = "versionNum";
	public static final String TXNNATIONALMAPID = "boID";
	public static final String DUEAMOUNTPAID = "f_DUEAMOUNTPAID";
	public static final String TRANSACTIONID = "f_TRANSACTIONID";
	public static final String PROCESS = "f_PROCESS";
	public static final String DUEAMOUNT = "f_DUEAMOUNT";

	public Date getF_DUEDATE();

	public void setF_DUEDATE(Date param);

	public String getF_BATCHID();

	public void setF_BATCHID(String param);

	public String getF_ROLE();

	public void setF_ROLE(String param);

	public String getF_LOANACCOUNTID();

	public void setF_LOANACCOUNTID(String param);

	public BigDecimal getF_DUEAMOUNTPAID();

	public void setF_DUEAMOUNTPAID(BigDecimal param);

	public String getF_TRANSACTIONID();

	public void setF_TRANSACTIONID(String param);

	public boolean isF_PROCESS();

	public void setF_PROCESS(boolean param);

	public BigDecimal getF_DUEAMOUNT();

	public void setF_DUEAMOUNT(BigDecimal param);

}