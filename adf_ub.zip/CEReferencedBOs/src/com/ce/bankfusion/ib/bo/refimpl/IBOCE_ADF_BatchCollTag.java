
package com.ce.bankfusion.ib.bo.refimpl;

public interface IBOCE_ADF_BatchCollTag extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_ADF_BatchCollTag";
	public static final String ID = "f_ID";
	public static final String ROWSEQ = "boID";
	public static final String VERSIONNUM = "versionNum";

	public String getF_ID();

	public void setF_ID(String param);

}