package com.ce.bankfusion.ib.bo.refimpl;

import java.math.BigDecimal;

public interface IBOCE_IB_FeesPaymentStatus extends com.trapedza.bankfusion.core.SimplePersistentObject {
	public static final String BONAME = "CE_IB_FeesPaymentStatus";
	public static final String IBFEESPAYMENTFAMNT = "f_IBFEESPAYMENTFAMNT";
	public static final String IBFEESPAYMENTFEESID = "f_IBFEESPAYMENTFEESID";
	public static final String IBFEESPAYMENTAMNTPAID = "f_IBFEESPAYMENTAMNTPAID";
	public static final String IBFEESPAYMENTNATIONALID = "f_IBFEESPAYMENTNATIONALID";
	public static final String IBFEESPAYMENTISCANCEL = "f_IBFEESPAYMENTISCANCEL";
	public static final String IBDEALID = "f_IBDEALID";
	public static final String VERSIONNUM = "versionNum";
	public static final String IBFEESPAYMENTINVOICENO = "boID";

	public BigDecimal getF_IBFEESPAYMENTFAMNT();

	public void setF_IBFEESPAYMENTFAMNT(BigDecimal param);

	public String getF_IBFEESPAYMENTFEESID();

	public void setF_IBFEESPAYMENTFEESID(String param);

	public BigDecimal getF_IBFEESPAYMENTAMNTPAID();

	public void setF_IBFEESPAYMENTAMNTPAID(BigDecimal param);

	public String getF_IBFEESPAYMENTNATIONALID();

	public void setF_IBFEESPAYMENTNATIONALID(String param);

	public boolean isF_IBFEESPAYMENTISCANCEL();

	public void setF_IBFEESPAYMENTISCANCEL(boolean param);

	public String getF_IBDEALID();

	public void setF_IBDEALID(String param);

}